<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-11 03:59:00 --> Config Class Initialized
INFO - 2024-12-11 03:59:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:59:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:59:00 --> Utf8 Class Initialized
INFO - 2024-12-11 03:59:00 --> URI Class Initialized
INFO - 2024-12-11 03:59:00 --> Router Class Initialized
INFO - 2024-12-11 03:59:00 --> Output Class Initialized
INFO - 2024-12-11 03:59:00 --> Security Class Initialized
DEBUG - 2024-12-11 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:59:00 --> CSRF cookie sent
INFO - 2024-12-11 03:59:00 --> Input Class Initialized
INFO - 2024-12-11 03:59:00 --> Language Class Initialized
INFO - 2024-12-11 03:59:00 --> Loader Class Initialized
INFO - 2024-12-11 03:59:00 --> Helper loaded: url_helper
INFO - 2024-12-11 03:59:00 --> Helper loaded: form_helper
INFO - 2024-12-11 03:59:00 --> Database Driver Class Initialized
DEBUG - 2024-12-11 03:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:59:01 --> Form Validation Class Initialized
INFO - 2024-12-11 03:59:01 --> Model "Culinary_model" initialized
INFO - 2024-12-11 03:59:01 --> Controller Class Initialized
INFO - 2024-12-11 03:59:01 --> Model "User_model" initialized
INFO - 2024-12-11 03:59:01 --> Model "Category_model" initialized
INFO - 2024-12-11 03:59:01 --> Model "Review_model" initialized
INFO - 2024-12-11 03:59:01 --> Model "News_model" initialized
INFO - 2024-12-11 03:59:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 03:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:59:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 03:59:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 03:59:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-11 03:59:01 --> Final output sent to browser
DEBUG - 2024-12-11 03:59:01 --> Total execution time: 0.4729
INFO - 2024-12-11 03:59:18 --> Config Class Initialized
INFO - 2024-12-11 03:59:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:59:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:59:18 --> Utf8 Class Initialized
INFO - 2024-12-11 03:59:18 --> URI Class Initialized
INFO - 2024-12-11 03:59:18 --> Router Class Initialized
INFO - 2024-12-11 03:59:18 --> Output Class Initialized
INFO - 2024-12-11 03:59:18 --> Security Class Initialized
DEBUG - 2024-12-11 03:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:59:18 --> CSRF cookie sent
INFO - 2024-12-11 03:59:18 --> Input Class Initialized
INFO - 2024-12-11 03:59:18 --> Language Class Initialized
INFO - 2024-12-11 03:59:18 --> Loader Class Initialized
INFO - 2024-12-11 03:59:18 --> Helper loaded: url_helper
INFO - 2024-12-11 03:59:18 --> Helper loaded: form_helper
INFO - 2024-12-11 03:59:18 --> Database Driver Class Initialized
DEBUG - 2024-12-11 03:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:59:18 --> Form Validation Class Initialized
INFO - 2024-12-11 03:59:18 --> Model "Culinary_model" initialized
INFO - 2024-12-11 03:59:18 --> Controller Class Initialized
INFO - 2024-12-11 03:59:18 --> Model "User_model" initialized
INFO - 2024-12-11 03:59:18 --> Model "Category_model" initialized
INFO - 2024-12-11 03:59:18 --> Model "Review_model" initialized
INFO - 2024-12-11 03:59:18 --> Model "News_model" initialized
INFO - 2024-12-11 03:59:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 03:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:59:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 03:59:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 03:59:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 03:59:18 --> Final output sent to browser
DEBUG - 2024-12-11 03:59:18 --> Total execution time: 0.0635
INFO - 2024-12-11 04:01:59 --> Config Class Initialized
INFO - 2024-12-11 04:01:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:01:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:01:59 --> Utf8 Class Initialized
INFO - 2024-12-11 04:01:59 --> URI Class Initialized
INFO - 2024-12-11 04:01:59 --> Router Class Initialized
INFO - 2024-12-11 04:01:59 --> Output Class Initialized
INFO - 2024-12-11 04:02:00 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:00 --> CSRF cookie sent
INFO - 2024-12-11 04:02:00 --> Input Class Initialized
INFO - 2024-12-11 04:02:00 --> Language Class Initialized
INFO - 2024-12-11 04:02:00 --> Loader Class Initialized
INFO - 2024-12-11 04:02:00 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:00 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:00 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:00 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:00 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:00 --> Controller Class Initialized
INFO - 2024-12-11 04:02:00 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:00 --> Config Class Initialized
INFO - 2024-12-11 04:02:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:00 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:00 --> URI Class Initialized
INFO - 2024-12-11 04:02:00 --> Router Class Initialized
INFO - 2024-12-11 04:02:00 --> Output Class Initialized
INFO - 2024-12-11 04:02:00 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:00 --> CSRF cookie sent
INFO - 2024-12-11 04:02:00 --> Input Class Initialized
INFO - 2024-12-11 04:02:00 --> Language Class Initialized
INFO - 2024-12-11 04:02:00 --> Loader Class Initialized
INFO - 2024-12-11 04:02:00 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:00 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:00 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:00 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:00 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:00 --> Controller Class Initialized
INFO - 2024-12-11 04:02:00 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 04:02:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-11 04:02:00 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:00 --> Total execution time: 0.0495
INFO - 2024-12-11 04:02:05 --> Config Class Initialized
INFO - 2024-12-11 04:02:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:05 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:05 --> URI Class Initialized
INFO - 2024-12-11 04:02:05 --> Router Class Initialized
INFO - 2024-12-11 04:02:05 --> Output Class Initialized
INFO - 2024-12-11 04:02:05 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:05 --> CSRF cookie sent
INFO - 2024-12-11 04:02:05 --> Input Class Initialized
INFO - 2024-12-11 04:02:05 --> Language Class Initialized
INFO - 2024-12-11 04:02:05 --> Loader Class Initialized
INFO - 2024-12-11 04:02:05 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:05 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:05 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:05 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:05 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:05 --> Controller Class Initialized
INFO - 2024-12-11 04:02:05 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:05 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:05 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:05 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-11 04:02:05 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:05 --> Total execution time: 0.0858
INFO - 2024-12-11 04:02:23 --> Config Class Initialized
INFO - 2024-12-11 04:02:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:23 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:23 --> URI Class Initialized
INFO - 2024-12-11 04:02:23 --> Router Class Initialized
INFO - 2024-12-11 04:02:23 --> Output Class Initialized
INFO - 2024-12-11 04:02:23 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:23 --> CSRF cookie sent
INFO - 2024-12-11 04:02:23 --> Input Class Initialized
INFO - 2024-12-11 04:02:23 --> Language Class Initialized
INFO - 2024-12-11 04:02:23 --> Loader Class Initialized
INFO - 2024-12-11 04:02:23 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:23 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:23 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:23 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:23 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:23 --> Controller Class Initialized
INFO - 2024-12-11 04:02:23 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:23 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:23 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:23 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-11 04:02:23 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:23 --> Total execution time: 0.0526
INFO - 2024-12-11 04:02:26 --> Config Class Initialized
INFO - 2024-12-11 04:02:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:26 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:26 --> URI Class Initialized
INFO - 2024-12-11 04:02:26 --> Router Class Initialized
INFO - 2024-12-11 04:02:26 --> Output Class Initialized
INFO - 2024-12-11 04:02:26 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:26 --> CSRF cookie sent
INFO - 2024-12-11 04:02:26 --> Input Class Initialized
INFO - 2024-12-11 04:02:26 --> Language Class Initialized
INFO - 2024-12-11 04:02:26 --> Loader Class Initialized
INFO - 2024-12-11 04:02:26 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:26 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:26 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:26 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:26 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:26 --> Controller Class Initialized
INFO - 2024-12-11 04:02:26 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:26 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:26 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:26 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 04:02:26 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:26 --> Total execution time: 0.0466
INFO - 2024-12-11 04:02:30 --> Config Class Initialized
INFO - 2024-12-11 04:02:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:30 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:30 --> URI Class Initialized
INFO - 2024-12-11 04:02:30 --> Router Class Initialized
INFO - 2024-12-11 04:02:30 --> Output Class Initialized
INFO - 2024-12-11 04:02:30 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:30 --> CSRF cookie sent
INFO - 2024-12-11 04:02:30 --> Input Class Initialized
INFO - 2024-12-11 04:02:30 --> Language Class Initialized
INFO - 2024-12-11 04:02:30 --> Loader Class Initialized
INFO - 2024-12-11 04:02:30 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:30 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:30 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:30 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:30 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:30 --> Controller Class Initialized
INFO - 2024-12-11 04:02:30 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:30 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:30 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:30 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 04:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-11 04:02:30 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:30 --> Total execution time: 0.0778
INFO - 2024-12-11 04:02:33 --> Config Class Initialized
INFO - 2024-12-11 04:02:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:33 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:33 --> URI Class Initialized
INFO - 2024-12-11 04:02:33 --> Router Class Initialized
INFO - 2024-12-11 04:02:33 --> Output Class Initialized
INFO - 2024-12-11 04:02:33 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:33 --> CSRF cookie sent
INFO - 2024-12-11 04:02:33 --> Input Class Initialized
INFO - 2024-12-11 04:02:33 --> Language Class Initialized
INFO - 2024-12-11 04:02:33 --> Loader Class Initialized
INFO - 2024-12-11 04:02:33 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:33 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:33 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:33 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:33 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:33 --> Controller Class Initialized
INFO - 2024-12-11 04:02:33 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:33 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:33 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:33 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 04:02:33 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:33 --> Total execution time: 0.0514
INFO - 2024-12-11 04:02:36 --> Config Class Initialized
INFO - 2024-12-11 04:02:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:36 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:36 --> URI Class Initialized
INFO - 2024-12-11 04:02:36 --> Router Class Initialized
INFO - 2024-12-11 04:02:36 --> Output Class Initialized
INFO - 2024-12-11 04:02:36 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:36 --> CSRF cookie sent
INFO - 2024-12-11 04:02:36 --> Input Class Initialized
INFO - 2024-12-11 04:02:36 --> Language Class Initialized
INFO - 2024-12-11 04:02:36 --> Loader Class Initialized
INFO - 2024-12-11 04:02:36 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:36 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:36 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:36 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:36 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:36 --> Controller Class Initialized
INFO - 2024-12-11 04:02:36 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:36 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:36 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:36 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-11 04:02:36 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:36 --> Total execution time: 0.0571
INFO - 2024-12-11 04:02:56 --> Config Class Initialized
INFO - 2024-12-11 04:02:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:56 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:56 --> URI Class Initialized
INFO - 2024-12-11 04:02:56 --> Router Class Initialized
INFO - 2024-12-11 04:02:56 --> Output Class Initialized
INFO - 2024-12-11 04:02:56 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:56 --> CSRF cookie sent
INFO - 2024-12-11 04:02:56 --> Input Class Initialized
INFO - 2024-12-11 04:02:56 --> Language Class Initialized
INFO - 2024-12-11 04:02:56 --> Loader Class Initialized
INFO - 2024-12-11 04:02:56 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:56 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:56 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:56 --> Controller Class Initialized
INFO - 2024-12-11 04:02:56 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:56 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:56 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:56 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 04:02:56 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:56 --> Total execution time: 0.0555
INFO - 2024-12-11 04:02:59 --> Config Class Initialized
INFO - 2024-12-11 04:02:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:59 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:59 --> URI Class Initialized
INFO - 2024-12-11 04:02:59 --> Router Class Initialized
INFO - 2024-12-11 04:02:59 --> Output Class Initialized
INFO - 2024-12-11 04:02:59 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:59 --> CSRF cookie sent
INFO - 2024-12-11 04:02:59 --> CSRF token verified
INFO - 2024-12-11 04:02:59 --> Input Class Initialized
INFO - 2024-12-11 04:02:59 --> Language Class Initialized
INFO - 2024-12-11 04:02:59 --> Loader Class Initialized
INFO - 2024-12-11 04:02:59 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:59 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:59 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:59 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:59 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:59 --> Controller Class Initialized
INFO - 2024-12-11 04:02:59 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:02:59 --> Config Class Initialized
INFO - 2024-12-11 04:02:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:02:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:02:59 --> Utf8 Class Initialized
INFO - 2024-12-11 04:02:59 --> URI Class Initialized
INFO - 2024-12-11 04:02:59 --> Router Class Initialized
INFO - 2024-12-11 04:02:59 --> Output Class Initialized
INFO - 2024-12-11 04:02:59 --> Security Class Initialized
DEBUG - 2024-12-11 04:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:02:59 --> CSRF cookie sent
INFO - 2024-12-11 04:02:59 --> Input Class Initialized
INFO - 2024-12-11 04:02:59 --> Language Class Initialized
INFO - 2024-12-11 04:02:59 --> Loader Class Initialized
INFO - 2024-12-11 04:02:59 --> Helper loaded: url_helper
INFO - 2024-12-11 04:02:59 --> Helper loaded: form_helper
INFO - 2024-12-11 04:02:59 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:02:59 --> Form Validation Class Initialized
INFO - 2024-12-11 04:02:59 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:02:59 --> Controller Class Initialized
INFO - 2024-12-11 04:02:59 --> Model "User_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "Category_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "Review_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "News_model" initialized
INFO - 2024-12-11 04:02:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 04:02:59 --> Query result: stdClass Object
(
    [view_count] => 122
)

INFO - 2024-12-11 04:02:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:02:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:02:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 04:02:59 --> Final output sent to browser
DEBUG - 2024-12-11 04:02:59 --> Total execution time: 0.1119
INFO - 2024-12-11 04:03:00 --> Config Class Initialized
INFO - 2024-12-11 04:03:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:03:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:03:00 --> Utf8 Class Initialized
INFO - 2024-12-11 04:03:00 --> URI Class Initialized
INFO - 2024-12-11 04:03:00 --> Router Class Initialized
INFO - 2024-12-11 04:03:00 --> Output Class Initialized
INFO - 2024-12-11 04:03:00 --> Security Class Initialized
DEBUG - 2024-12-11 04:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:03:00 --> CSRF cookie sent
INFO - 2024-12-11 04:03:00 --> Input Class Initialized
INFO - 2024-12-11 04:03:00 --> Language Class Initialized
ERROR - 2024-12-11 04:03:00 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 04:23:31 --> Config Class Initialized
INFO - 2024-12-11 04:23:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:23:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:23:31 --> Utf8 Class Initialized
INFO - 2024-12-11 04:23:31 --> URI Class Initialized
INFO - 2024-12-11 04:23:31 --> Router Class Initialized
INFO - 2024-12-11 04:23:31 --> Output Class Initialized
INFO - 2024-12-11 04:23:31 --> Security Class Initialized
DEBUG - 2024-12-11 04:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:23:31 --> CSRF cookie sent
INFO - 2024-12-11 04:23:31 --> Input Class Initialized
INFO - 2024-12-11 04:23:31 --> Language Class Initialized
INFO - 2024-12-11 04:23:31 --> Loader Class Initialized
INFO - 2024-12-11 04:23:31 --> Helper loaded: url_helper
INFO - 2024-12-11 04:23:31 --> Helper loaded: form_helper
INFO - 2024-12-11 04:23:31 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:23:31 --> Form Validation Class Initialized
INFO - 2024-12-11 04:23:31 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:23:31 --> Controller Class Initialized
INFO - 2024-12-11 04:23:31 --> Model "User_model" initialized
INFO - 2024-12-11 04:23:31 --> Model "Category_model" initialized
INFO - 2024-12-11 04:23:31 --> Model "Review_model" initialized
INFO - 2024-12-11 04:23:31 --> Model "News_model" initialized
INFO - 2024-12-11 04:23:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 04:23:31 --> Query result: stdClass Object
(
    [view_count] => 123
)

INFO - 2024-12-11 04:23:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:23:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:23:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 04:23:31 --> Final output sent to browser
DEBUG - 2024-12-11 04:23:31 --> Total execution time: 0.1334
INFO - 2024-12-11 04:23:32 --> Config Class Initialized
INFO - 2024-12-11 04:23:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:23:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:23:32 --> Utf8 Class Initialized
INFO - 2024-12-11 04:23:32 --> URI Class Initialized
INFO - 2024-12-11 04:23:32 --> Router Class Initialized
INFO - 2024-12-11 04:23:32 --> Output Class Initialized
INFO - 2024-12-11 04:23:32 --> Security Class Initialized
DEBUG - 2024-12-11 04:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:23:32 --> CSRF cookie sent
INFO - 2024-12-11 04:23:32 --> Input Class Initialized
INFO - 2024-12-11 04:23:32 --> Language Class Initialized
ERROR - 2024-12-11 04:23:32 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 04:23:34 --> Config Class Initialized
INFO - 2024-12-11 04:23:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:23:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:23:34 --> Utf8 Class Initialized
INFO - 2024-12-11 04:23:34 --> URI Class Initialized
INFO - 2024-12-11 04:23:34 --> Router Class Initialized
INFO - 2024-12-11 04:23:34 --> Output Class Initialized
INFO - 2024-12-11 04:23:34 --> Security Class Initialized
DEBUG - 2024-12-11 04:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:23:34 --> CSRF cookie sent
INFO - 2024-12-11 04:23:34 --> Input Class Initialized
INFO - 2024-12-11 04:23:34 --> Language Class Initialized
INFO - 2024-12-11 04:23:34 --> Loader Class Initialized
INFO - 2024-12-11 04:23:34 --> Helper loaded: url_helper
INFO - 2024-12-11 04:23:34 --> Helper loaded: form_helper
INFO - 2024-12-11 04:23:34 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:23:34 --> Form Validation Class Initialized
INFO - 2024-12-11 04:23:34 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:23:34 --> Controller Class Initialized
INFO - 2024-12-11 04:23:34 --> Model "User_model" initialized
INFO - 2024-12-11 04:23:34 --> Model "Category_model" initialized
INFO - 2024-12-11 04:23:34 --> Model "Review_model" initialized
INFO - 2024-12-11 04:23:34 --> Model "News_model" initialized
INFO - 2024-12-11 04:23:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:23:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 04:23:34 --> Severity: error --> Exception: Call to undefined method Culinary_model::count_all_culinaries() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 255
INFO - 2024-12-11 04:23:39 --> Config Class Initialized
INFO - 2024-12-11 04:23:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:23:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:23:39 --> Utf8 Class Initialized
INFO - 2024-12-11 04:23:39 --> URI Class Initialized
INFO - 2024-12-11 04:23:39 --> Router Class Initialized
INFO - 2024-12-11 04:23:39 --> Output Class Initialized
INFO - 2024-12-11 04:23:39 --> Security Class Initialized
DEBUG - 2024-12-11 04:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:23:39 --> CSRF cookie sent
INFO - 2024-12-11 04:23:39 --> Input Class Initialized
INFO - 2024-12-11 04:23:39 --> Language Class Initialized
INFO - 2024-12-11 04:23:39 --> Loader Class Initialized
INFO - 2024-12-11 04:23:39 --> Helper loaded: url_helper
INFO - 2024-12-11 04:23:39 --> Helper loaded: form_helper
INFO - 2024-12-11 04:23:39 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:23:39 --> Form Validation Class Initialized
INFO - 2024-12-11 04:23:39 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:23:39 --> Controller Class Initialized
INFO - 2024-12-11 04:23:39 --> Model "User_model" initialized
INFO - 2024-12-11 04:23:39 --> Model "Category_model" initialized
INFO - 2024-12-11 04:23:39 --> Model "Review_model" initialized
INFO - 2024-12-11 04:23:39 --> Model "News_model" initialized
INFO - 2024-12-11 04:23:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:23:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 04:23:39 --> Query result: stdClass Object
(
    [view_count] => 124
)

INFO - 2024-12-11 04:23:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:23:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:23:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 04:23:39 --> Final output sent to browser
DEBUG - 2024-12-11 04:23:39 --> Total execution time: 0.0693
INFO - 2024-12-11 04:23:46 --> Config Class Initialized
INFO - 2024-12-11 04:23:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:23:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:23:46 --> Utf8 Class Initialized
INFO - 2024-12-11 04:23:46 --> URI Class Initialized
INFO - 2024-12-11 04:23:46 --> Router Class Initialized
INFO - 2024-12-11 04:23:46 --> Output Class Initialized
INFO - 2024-12-11 04:23:46 --> Security Class Initialized
DEBUG - 2024-12-11 04:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:23:46 --> CSRF cookie sent
INFO - 2024-12-11 04:23:46 --> Input Class Initialized
INFO - 2024-12-11 04:23:46 --> Language Class Initialized
INFO - 2024-12-11 04:23:46 --> Loader Class Initialized
INFO - 2024-12-11 04:23:46 --> Helper loaded: url_helper
INFO - 2024-12-11 04:23:46 --> Helper loaded: form_helper
INFO - 2024-12-11 04:23:46 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:23:46 --> Form Validation Class Initialized
INFO - 2024-12-11 04:23:46 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:23:46 --> Controller Class Initialized
INFO - 2024-12-11 04:23:46 --> Model "User_model" initialized
INFO - 2024-12-11 04:23:46 --> Model "Category_model" initialized
INFO - 2024-12-11 04:23:46 --> Model "Review_model" initialized
INFO - 2024-12-11 04:23:46 --> Model "News_model" initialized
INFO - 2024-12-11 04:23:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:23:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 04:23:46 --> Severity: error --> Exception: Call to undefined method Culinary_model::count_all_culinaries() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 255
INFO - 2024-12-11 04:25:00 --> Config Class Initialized
INFO - 2024-12-11 04:25:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:25:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:25:00 --> Utf8 Class Initialized
INFO - 2024-12-11 04:25:00 --> URI Class Initialized
INFO - 2024-12-11 04:25:00 --> Router Class Initialized
INFO - 2024-12-11 04:25:00 --> Output Class Initialized
INFO - 2024-12-11 04:25:00 --> Security Class Initialized
DEBUG - 2024-12-11 04:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:25:00 --> CSRF cookie sent
INFO - 2024-12-11 04:25:00 --> Input Class Initialized
INFO - 2024-12-11 04:25:00 --> Language Class Initialized
INFO - 2024-12-11 04:25:00 --> Loader Class Initialized
INFO - 2024-12-11 04:25:00 --> Helper loaded: url_helper
INFO - 2024-12-11 04:25:00 --> Helper loaded: form_helper
INFO - 2024-12-11 04:25:00 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:25:00 --> Form Validation Class Initialized
INFO - 2024-12-11 04:25:00 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:25:00 --> Controller Class Initialized
INFO - 2024-12-11 04:25:00 --> Model "User_model" initialized
INFO - 2024-12-11 04:25:00 --> Model "Category_model" initialized
INFO - 2024-12-11 04:25:00 --> Model "Review_model" initialized
INFO - 2024-12-11 04:25:00 --> Model "News_model" initialized
INFO - 2024-12-11 04:25:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:25:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 04:25:00 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_all_categories() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 262
INFO - 2024-12-11 04:25:01 --> Config Class Initialized
INFO - 2024-12-11 04:25:01 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:25:01 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:25:01 --> Utf8 Class Initialized
INFO - 2024-12-11 04:25:01 --> URI Class Initialized
INFO - 2024-12-11 04:25:01 --> Router Class Initialized
INFO - 2024-12-11 04:25:01 --> Output Class Initialized
INFO - 2024-12-11 04:25:01 --> Security Class Initialized
DEBUG - 2024-12-11 04:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:25:01 --> CSRF cookie sent
INFO - 2024-12-11 04:25:01 --> Input Class Initialized
INFO - 2024-12-11 04:25:01 --> Language Class Initialized
INFO - 2024-12-11 04:25:01 --> Loader Class Initialized
INFO - 2024-12-11 04:25:01 --> Helper loaded: url_helper
INFO - 2024-12-11 04:25:01 --> Helper loaded: form_helper
INFO - 2024-12-11 04:25:01 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:25:01 --> Form Validation Class Initialized
INFO - 2024-12-11 04:25:01 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:25:01 --> Controller Class Initialized
INFO - 2024-12-11 04:25:01 --> Model "User_model" initialized
INFO - 2024-12-11 04:25:01 --> Model "Category_model" initialized
INFO - 2024-12-11 04:25:01 --> Model "Review_model" initialized
INFO - 2024-12-11 04:25:01 --> Model "News_model" initialized
INFO - 2024-12-11 04:25:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:25:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 04:25:01 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_all_categories() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 262
INFO - 2024-12-11 04:25:18 --> Config Class Initialized
INFO - 2024-12-11 04:25:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:25:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:25:18 --> Utf8 Class Initialized
INFO - 2024-12-11 04:25:18 --> URI Class Initialized
INFO - 2024-12-11 04:25:18 --> Router Class Initialized
INFO - 2024-12-11 04:25:18 --> Output Class Initialized
INFO - 2024-12-11 04:25:18 --> Security Class Initialized
DEBUG - 2024-12-11 04:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:25:18 --> CSRF cookie sent
INFO - 2024-12-11 04:25:18 --> Input Class Initialized
INFO - 2024-12-11 04:25:18 --> Language Class Initialized
INFO - 2024-12-11 04:25:18 --> Loader Class Initialized
INFO - 2024-12-11 04:25:18 --> Helper loaded: url_helper
INFO - 2024-12-11 04:25:18 --> Helper loaded: form_helper
INFO - 2024-12-11 04:25:18 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:25:18 --> Form Validation Class Initialized
INFO - 2024-12-11 04:25:18 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:25:18 --> Controller Class Initialized
INFO - 2024-12-11 04:25:18 --> Model "User_model" initialized
INFO - 2024-12-11 04:25:18 --> Model "Category_model" initialized
INFO - 2024-12-11 04:25:18 --> Model "Review_model" initialized
INFO - 2024-12-11 04:25:18 --> Model "News_model" initialized
INFO - 2024-12-11 04:25:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-11 04:25:18 --> Final output sent to browser
DEBUG - 2024-12-11 04:25:18 --> Total execution time: 0.0645
INFO - 2024-12-11 04:26:14 --> Config Class Initialized
INFO - 2024-12-11 04:26:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:26:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:26:14 --> Utf8 Class Initialized
INFO - 2024-12-11 04:26:14 --> URI Class Initialized
INFO - 2024-12-11 04:26:14 --> Router Class Initialized
INFO - 2024-12-11 04:26:14 --> Output Class Initialized
INFO - 2024-12-11 04:26:14 --> Security Class Initialized
DEBUG - 2024-12-11 04:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:26:14 --> CSRF cookie sent
INFO - 2024-12-11 04:26:14 --> Input Class Initialized
INFO - 2024-12-11 04:26:14 --> Language Class Initialized
INFO - 2024-12-11 04:26:14 --> Loader Class Initialized
INFO - 2024-12-11 04:26:14 --> Helper loaded: url_helper
INFO - 2024-12-11 04:26:14 --> Helper loaded: form_helper
INFO - 2024-12-11 04:26:14 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:26:14 --> Form Validation Class Initialized
INFO - 2024-12-11 04:26:14 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:26:14 --> Controller Class Initialized
INFO - 2024-12-11 04:26:14 --> Model "User_model" initialized
INFO - 2024-12-11 04:26:14 --> Model "Category_model" initialized
INFO - 2024-12-11 04:26:14 --> Model "Review_model" initialized
INFO - 2024-12-11 04:26:14 --> Model "News_model" initialized
INFO - 2024-12-11 04:26:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:26:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:26:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:26:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-11 04:26:14 --> Final output sent to browser
DEBUG - 2024-12-11 04:26:14 --> Total execution time: 0.0539
INFO - 2024-12-11 04:26:15 --> Config Class Initialized
INFO - 2024-12-11 04:26:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:26:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:26:15 --> Utf8 Class Initialized
INFO - 2024-12-11 04:26:15 --> URI Class Initialized
INFO - 2024-12-11 04:26:15 --> Router Class Initialized
INFO - 2024-12-11 04:26:15 --> Output Class Initialized
INFO - 2024-12-11 04:26:15 --> Security Class Initialized
DEBUG - 2024-12-11 04:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:26:15 --> CSRF cookie sent
INFO - 2024-12-11 04:26:15 --> Input Class Initialized
INFO - 2024-12-11 04:26:15 --> Language Class Initialized
INFO - 2024-12-11 04:26:15 --> Loader Class Initialized
INFO - 2024-12-11 04:26:15 --> Helper loaded: url_helper
INFO - 2024-12-11 04:26:15 --> Helper loaded: form_helper
INFO - 2024-12-11 04:26:15 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:26:15 --> Form Validation Class Initialized
INFO - 2024-12-11 04:26:15 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:26:15 --> Controller Class Initialized
INFO - 2024-12-11 04:26:15 --> Model "User_model" initialized
INFO - 2024-12-11 04:26:15 --> Model "Category_model" initialized
INFO - 2024-12-11 04:26:15 --> Model "Review_model" initialized
INFO - 2024-12-11 04:26:15 --> Model "News_model" initialized
INFO - 2024-12-11 04:26:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:26:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:26:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:26:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-11 04:26:15 --> Final output sent to browser
DEBUG - 2024-12-11 04:26:15 --> Total execution time: 0.0766
INFO - 2024-12-11 04:28:03 --> Config Class Initialized
INFO - 2024-12-11 04:28:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:28:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:28:03 --> Utf8 Class Initialized
INFO - 2024-12-11 04:28:03 --> URI Class Initialized
INFO - 2024-12-11 04:28:03 --> Router Class Initialized
INFO - 2024-12-11 04:28:03 --> Output Class Initialized
INFO - 2024-12-11 04:28:03 --> Security Class Initialized
DEBUG - 2024-12-11 04:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:28:03 --> CSRF cookie sent
INFO - 2024-12-11 04:28:03 --> Input Class Initialized
INFO - 2024-12-11 04:28:03 --> Language Class Initialized
INFO - 2024-12-11 04:28:03 --> Loader Class Initialized
INFO - 2024-12-11 04:28:03 --> Helper loaded: url_helper
INFO - 2024-12-11 04:28:03 --> Helper loaded: form_helper
INFO - 2024-12-11 04:28:03 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:28:03 --> Form Validation Class Initialized
INFO - 2024-12-11 04:28:03 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:28:03 --> Controller Class Initialized
INFO - 2024-12-11 04:28:03 --> Model "User_model" initialized
INFO - 2024-12-11 04:28:03 --> Model "Category_model" initialized
INFO - 2024-12-11 04:28:03 --> Model "Review_model" initialized
INFO - 2024-12-11 04:28:03 --> Model "News_model" initialized
INFO - 2024-12-11 04:28:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 04:28:03 --> Query result: stdClass Object
(
    [view_count] => 125
)

INFO - 2024-12-11 04:28:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:28:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:28:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 04:28:03 --> Final output sent to browser
DEBUG - 2024-12-11 04:28:03 --> Total execution time: 0.0575
INFO - 2024-12-11 04:28:03 --> Config Class Initialized
INFO - 2024-12-11 04:28:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:28:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:28:03 --> Utf8 Class Initialized
INFO - 2024-12-11 04:28:03 --> URI Class Initialized
INFO - 2024-12-11 04:28:03 --> Router Class Initialized
INFO - 2024-12-11 04:28:03 --> Output Class Initialized
INFO - 2024-12-11 04:28:03 --> Security Class Initialized
DEBUG - 2024-12-11 04:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:28:03 --> CSRF cookie sent
INFO - 2024-12-11 04:28:03 --> Input Class Initialized
INFO - 2024-12-11 04:28:03 --> Language Class Initialized
ERROR - 2024-12-11 04:28:03 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 04:28:05 --> Config Class Initialized
INFO - 2024-12-11 04:28:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:28:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:28:05 --> Utf8 Class Initialized
INFO - 2024-12-11 04:28:05 --> URI Class Initialized
INFO - 2024-12-11 04:28:05 --> Router Class Initialized
INFO - 2024-12-11 04:28:05 --> Output Class Initialized
INFO - 2024-12-11 04:28:05 --> Security Class Initialized
DEBUG - 2024-12-11 04:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:28:05 --> CSRF cookie sent
INFO - 2024-12-11 04:28:05 --> Input Class Initialized
INFO - 2024-12-11 04:28:05 --> Language Class Initialized
INFO - 2024-12-11 04:28:05 --> Loader Class Initialized
INFO - 2024-12-11 04:28:05 --> Helper loaded: url_helper
INFO - 2024-12-11 04:28:05 --> Helper loaded: form_helper
INFO - 2024-12-11 04:28:05 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:28:05 --> Form Validation Class Initialized
INFO - 2024-12-11 04:28:05 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:28:05 --> Controller Class Initialized
INFO - 2024-12-11 04:28:05 --> Model "User_model" initialized
INFO - 2024-12-11 04:28:05 --> Model "Category_model" initialized
INFO - 2024-12-11 04:28:05 --> Model "Review_model" initialized
INFO - 2024-12-11 04:28:05 --> Model "News_model" initialized
INFO - 2024-12-11 04:28:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:28:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 04:28:05 --> Severity: error --> Exception: Call to undefined method Culinary_model::count_all_culinaries() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 255
INFO - 2024-12-11 04:28:50 --> Config Class Initialized
INFO - 2024-12-11 04:28:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:28:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:28:50 --> Utf8 Class Initialized
INFO - 2024-12-11 04:28:50 --> URI Class Initialized
INFO - 2024-12-11 04:28:50 --> Router Class Initialized
INFO - 2024-12-11 04:28:50 --> Output Class Initialized
INFO - 2024-12-11 04:28:50 --> Security Class Initialized
DEBUG - 2024-12-11 04:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:28:50 --> CSRF cookie sent
INFO - 2024-12-11 04:28:50 --> Input Class Initialized
INFO - 2024-12-11 04:28:50 --> Language Class Initialized
INFO - 2024-12-11 04:28:50 --> Loader Class Initialized
INFO - 2024-12-11 04:28:50 --> Helper loaded: url_helper
INFO - 2024-12-11 04:28:50 --> Helper loaded: form_helper
INFO - 2024-12-11 04:28:50 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:28:50 --> Form Validation Class Initialized
INFO - 2024-12-11 04:28:50 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:28:50 --> Controller Class Initialized
INFO - 2024-12-11 04:28:50 --> Model "User_model" initialized
INFO - 2024-12-11 04:28:50 --> Model "Category_model" initialized
INFO - 2024-12-11 04:28:50 --> Model "Review_model" initialized
INFO - 2024-12-11 04:28:50 --> Model "News_model" initialized
INFO - 2024-12-11 04:28:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:28:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:28:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:28:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-11 04:28:50 --> Final output sent to browser
DEBUG - 2024-12-11 04:28:50 --> Total execution time: 0.0543
INFO - 2024-12-11 04:29:05 --> Config Class Initialized
INFO - 2024-12-11 04:29:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:29:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:29:05 --> Utf8 Class Initialized
INFO - 2024-12-11 04:29:05 --> URI Class Initialized
INFO - 2024-12-11 04:29:05 --> Router Class Initialized
INFO - 2024-12-11 04:29:05 --> Output Class Initialized
INFO - 2024-12-11 04:29:05 --> Security Class Initialized
DEBUG - 2024-12-11 04:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:29:05 --> CSRF cookie sent
INFO - 2024-12-11 04:29:05 --> Input Class Initialized
INFO - 2024-12-11 04:29:05 --> Language Class Initialized
INFO - 2024-12-11 04:29:05 --> Loader Class Initialized
INFO - 2024-12-11 04:29:05 --> Helper loaded: url_helper
INFO - 2024-12-11 04:29:05 --> Helper loaded: form_helper
INFO - 2024-12-11 04:29:05 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:29:05 --> Form Validation Class Initialized
INFO - 2024-12-11 04:29:05 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:29:05 --> Controller Class Initialized
INFO - 2024-12-11 04:29:05 --> Model "User_model" initialized
INFO - 2024-12-11 04:29:05 --> Model "Category_model" initialized
INFO - 2024-12-11 04:29:05 --> Model "Review_model" initialized
INFO - 2024-12-11 04:29:05 --> Model "News_model" initialized
INFO - 2024-12-11 04:29:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:29:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:29:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:29:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 04:29:05 --> Final output sent to browser
DEBUG - 2024-12-11 04:29:05 --> Total execution time: 0.0750
INFO - 2024-12-11 04:29:10 --> Config Class Initialized
INFO - 2024-12-11 04:29:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 04:29:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 04:29:10 --> Utf8 Class Initialized
INFO - 2024-12-11 04:29:10 --> URI Class Initialized
INFO - 2024-12-11 04:29:10 --> Router Class Initialized
INFO - 2024-12-11 04:29:10 --> Output Class Initialized
INFO - 2024-12-11 04:29:10 --> Security Class Initialized
DEBUG - 2024-12-11 04:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 04:29:10 --> CSRF cookie sent
INFO - 2024-12-11 04:29:10 --> Input Class Initialized
INFO - 2024-12-11 04:29:10 --> Language Class Initialized
INFO - 2024-12-11 04:29:10 --> Loader Class Initialized
INFO - 2024-12-11 04:29:10 --> Helper loaded: url_helper
INFO - 2024-12-11 04:29:10 --> Helper loaded: form_helper
INFO - 2024-12-11 04:29:10 --> Database Driver Class Initialized
DEBUG - 2024-12-11 04:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 04:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 04:29:10 --> Form Validation Class Initialized
INFO - 2024-12-11 04:29:10 --> Model "Culinary_model" initialized
INFO - 2024-12-11 04:29:10 --> Controller Class Initialized
INFO - 2024-12-11 04:29:10 --> Model "User_model" initialized
INFO - 2024-12-11 04:29:10 --> Model "Category_model" initialized
INFO - 2024-12-11 04:29:10 --> Model "Review_model" initialized
INFO - 2024-12-11 04:29:10 --> Model "News_model" initialized
INFO - 2024-12-11 04:29:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 04:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 04:29:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 04:29:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 04:29:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-11 04:29:10 --> Final output sent to browser
DEBUG - 2024-12-11 04:29:10 --> Total execution time: 0.0597
INFO - 2024-12-11 05:17:57 --> Config Class Initialized
INFO - 2024-12-11 05:17:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:17:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:17:57 --> Utf8 Class Initialized
INFO - 2024-12-11 05:17:57 --> URI Class Initialized
INFO - 2024-12-11 05:17:57 --> Router Class Initialized
INFO - 2024-12-11 05:17:57 --> Output Class Initialized
INFO - 2024-12-11 05:17:57 --> Security Class Initialized
DEBUG - 2024-12-11 05:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:17:57 --> CSRF cookie sent
INFO - 2024-12-11 05:17:57 --> Input Class Initialized
INFO - 2024-12-11 05:17:57 --> Language Class Initialized
INFO - 2024-12-11 05:17:57 --> Loader Class Initialized
INFO - 2024-12-11 05:17:57 --> Helper loaded: url_helper
INFO - 2024-12-11 05:17:57 --> Helper loaded: form_helper
INFO - 2024-12-11 05:17:57 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:17:57 --> Form Validation Class Initialized
INFO - 2024-12-11 05:17:57 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:17:57 --> Controller Class Initialized
INFO - 2024-12-11 05:17:57 --> Model "User_model" initialized
INFO - 2024-12-11 05:17:57 --> Model "Category_model" initialized
INFO - 2024-12-11 05:17:57 --> Model "Review_model" initialized
INFO - 2024-12-11 05:17:57 --> Model "News_model" initialized
INFO - 2024-12-11 05:17:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:17:57 --> Query result: stdClass Object
(
    [view_count] => 126
)

INFO - 2024-12-11 05:17:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:17:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:17:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 05:17:57 --> Final output sent to browser
DEBUG - 2024-12-11 05:17:57 --> Total execution time: 0.1365
INFO - 2024-12-11 05:17:57 --> Config Class Initialized
INFO - 2024-12-11 05:17:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:17:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:17:57 --> Utf8 Class Initialized
INFO - 2024-12-11 05:17:57 --> URI Class Initialized
INFO - 2024-12-11 05:17:57 --> Router Class Initialized
INFO - 2024-12-11 05:17:57 --> Output Class Initialized
INFO - 2024-12-11 05:17:57 --> Security Class Initialized
DEBUG - 2024-12-11 05:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:17:57 --> CSRF cookie sent
INFO - 2024-12-11 05:17:57 --> Input Class Initialized
INFO - 2024-12-11 05:17:57 --> Language Class Initialized
ERROR - 2024-12-11 05:17:57 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 05:18:02 --> Config Class Initialized
INFO - 2024-12-11 05:18:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:18:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:18:02 --> Utf8 Class Initialized
INFO - 2024-12-11 05:18:02 --> URI Class Initialized
INFO - 2024-12-11 05:18:02 --> Router Class Initialized
INFO - 2024-12-11 05:18:02 --> Output Class Initialized
INFO - 2024-12-11 05:18:02 --> Security Class Initialized
DEBUG - 2024-12-11 05:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:18:02 --> CSRF cookie sent
INFO - 2024-12-11 05:18:02 --> Input Class Initialized
INFO - 2024-12-11 05:18:02 --> Language Class Initialized
INFO - 2024-12-11 05:18:02 --> Loader Class Initialized
INFO - 2024-12-11 05:18:02 --> Helper loaded: url_helper
INFO - 2024-12-11 05:18:02 --> Helper loaded: form_helper
INFO - 2024-12-11 05:18:02 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:18:02 --> Form Validation Class Initialized
INFO - 2024-12-11 05:18:02 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:18:02 --> Controller Class Initialized
INFO - 2024-12-11 05:18:02 --> Model "User_model" initialized
INFO - 2024-12-11 05:18:02 --> Model "Category_model" initialized
INFO - 2024-12-11 05:18:02 --> Model "Review_model" initialized
INFO - 2024-12-11 05:18:02 --> Model "News_model" initialized
INFO - 2024-12-11 05:18:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:18:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 05:18:02 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_categories() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 244
INFO - 2024-12-11 05:19:10 --> Config Class Initialized
INFO - 2024-12-11 05:19:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:19:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:19:10 --> Utf8 Class Initialized
INFO - 2024-12-11 05:19:10 --> URI Class Initialized
INFO - 2024-12-11 05:19:10 --> Router Class Initialized
INFO - 2024-12-11 05:19:10 --> Output Class Initialized
INFO - 2024-12-11 05:19:10 --> Security Class Initialized
DEBUG - 2024-12-11 05:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:19:10 --> CSRF cookie sent
INFO - 2024-12-11 05:19:10 --> Input Class Initialized
INFO - 2024-12-11 05:19:10 --> Language Class Initialized
INFO - 2024-12-11 05:19:10 --> Loader Class Initialized
INFO - 2024-12-11 05:19:10 --> Helper loaded: url_helper
INFO - 2024-12-11 05:19:10 --> Helper loaded: form_helper
INFO - 2024-12-11 05:19:10 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:19:10 --> Form Validation Class Initialized
INFO - 2024-12-11 05:19:10 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:19:10 --> Controller Class Initialized
INFO - 2024-12-11 05:19:10 --> Model "User_model" initialized
INFO - 2024-12-11 05:19:10 --> Model "Category_model" initialized
INFO - 2024-12-11 05:19:10 --> Model "Review_model" initialized
INFO - 2024-12-11 05:19:10 --> Model "News_model" initialized
INFO - 2024-12-11 05:19:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:19:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 05:19:10 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_culinaries_grouped_by_category() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 245
INFO - 2024-12-11 05:19:11 --> Config Class Initialized
INFO - 2024-12-11 05:19:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:19:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:19:11 --> Utf8 Class Initialized
INFO - 2024-12-11 05:19:11 --> URI Class Initialized
INFO - 2024-12-11 05:19:11 --> Router Class Initialized
INFO - 2024-12-11 05:19:11 --> Output Class Initialized
INFO - 2024-12-11 05:19:11 --> Security Class Initialized
DEBUG - 2024-12-11 05:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:19:11 --> CSRF cookie sent
INFO - 2024-12-11 05:19:11 --> Input Class Initialized
INFO - 2024-12-11 05:19:11 --> Language Class Initialized
INFO - 2024-12-11 05:19:11 --> Loader Class Initialized
INFO - 2024-12-11 05:19:11 --> Helper loaded: url_helper
INFO - 2024-12-11 05:19:11 --> Helper loaded: form_helper
INFO - 2024-12-11 05:19:11 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:19:11 --> Form Validation Class Initialized
INFO - 2024-12-11 05:19:11 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:19:11 --> Controller Class Initialized
INFO - 2024-12-11 05:19:11 --> Model "User_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "Category_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "Review_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "News_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:19:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 05:19:11 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_culinaries_grouped_by_category() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 245
INFO - 2024-12-11 05:19:11 --> Config Class Initialized
INFO - 2024-12-11 05:19:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:19:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:19:11 --> Utf8 Class Initialized
INFO - 2024-12-11 05:19:11 --> URI Class Initialized
INFO - 2024-12-11 05:19:11 --> Router Class Initialized
INFO - 2024-12-11 05:19:11 --> Output Class Initialized
INFO - 2024-12-11 05:19:11 --> Security Class Initialized
DEBUG - 2024-12-11 05:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:19:11 --> CSRF cookie sent
INFO - 2024-12-11 05:19:11 --> Input Class Initialized
INFO - 2024-12-11 05:19:11 --> Language Class Initialized
INFO - 2024-12-11 05:19:11 --> Loader Class Initialized
INFO - 2024-12-11 05:19:11 --> Helper loaded: url_helper
INFO - 2024-12-11 05:19:11 --> Helper loaded: form_helper
INFO - 2024-12-11 05:19:11 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:19:11 --> Form Validation Class Initialized
INFO - 2024-12-11 05:19:11 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:19:11 --> Controller Class Initialized
INFO - 2024-12-11 05:19:11 --> Model "User_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "Category_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "Review_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "News_model" initialized
INFO - 2024-12-11 05:19:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:19:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 05:19:12 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_culinaries_grouped_by_category() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 245
INFO - 2024-12-11 05:19:12 --> Config Class Initialized
INFO - 2024-12-11 05:19:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:19:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:19:12 --> Utf8 Class Initialized
INFO - 2024-12-11 05:19:12 --> URI Class Initialized
INFO - 2024-12-11 05:19:12 --> Router Class Initialized
INFO - 2024-12-11 05:19:12 --> Output Class Initialized
INFO - 2024-12-11 05:19:12 --> Security Class Initialized
DEBUG - 2024-12-11 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:19:12 --> CSRF cookie sent
INFO - 2024-12-11 05:19:12 --> Input Class Initialized
INFO - 2024-12-11 05:19:12 --> Language Class Initialized
INFO - 2024-12-11 05:19:12 --> Loader Class Initialized
INFO - 2024-12-11 05:19:12 --> Helper loaded: url_helper
INFO - 2024-12-11 05:19:12 --> Helper loaded: form_helper
INFO - 2024-12-11 05:19:12 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:19:12 --> Form Validation Class Initialized
INFO - 2024-12-11 05:19:12 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:19:12 --> Controller Class Initialized
INFO - 2024-12-11 05:19:12 --> Model "User_model" initialized
INFO - 2024-12-11 05:19:12 --> Model "Category_model" initialized
INFO - 2024-12-11 05:19:12 --> Model "Review_model" initialized
INFO - 2024-12-11 05:19:12 --> Model "News_model" initialized
INFO - 2024-12-11 05:19:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:19:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-11 05:19:12 --> Severity: error --> Exception: Call to undefined method Culinary_model::get_culinaries_grouped_by_category() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 245
INFO - 2024-12-11 05:19:48 --> Config Class Initialized
INFO - 2024-12-11 05:19:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:19:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:19:48 --> Utf8 Class Initialized
INFO - 2024-12-11 05:19:48 --> URI Class Initialized
INFO - 2024-12-11 05:19:48 --> Router Class Initialized
INFO - 2024-12-11 05:19:48 --> Output Class Initialized
INFO - 2024-12-11 05:19:48 --> Security Class Initialized
DEBUG - 2024-12-11 05:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:19:48 --> CSRF cookie sent
INFO - 2024-12-11 05:19:48 --> Input Class Initialized
INFO - 2024-12-11 05:19:48 --> Language Class Initialized
INFO - 2024-12-11 05:19:48 --> Loader Class Initialized
INFO - 2024-12-11 05:19:48 --> Helper loaded: url_helper
INFO - 2024-12-11 05:19:48 --> Helper loaded: form_helper
INFO - 2024-12-11 05:19:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:19:48 --> Form Validation Class Initialized
INFO - 2024-12-11 05:19:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:19:48 --> Controller Class Initialized
INFO - 2024-12-11 05:19:48 --> Model "User_model" initialized
INFO - 2024-12-11 05:19:48 --> Model "Category_model" initialized
INFO - 2024-12-11 05:19:48 --> Model "Review_model" initialized
INFO - 2024-12-11 05:19:48 --> Model "News_model" initialized
INFO - 2024-12-11 05:19:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:19:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:19:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:19:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:19:48 --> Final output sent to browser
DEBUG - 2024-12-11 05:19:48 --> Total execution time: 0.0495
INFO - 2024-12-11 05:19:57 --> Config Class Initialized
INFO - 2024-12-11 05:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:19:57 --> Utf8 Class Initialized
INFO - 2024-12-11 05:19:57 --> URI Class Initialized
INFO - 2024-12-11 05:19:57 --> Router Class Initialized
INFO - 2024-12-11 05:19:57 --> Output Class Initialized
INFO - 2024-12-11 05:19:57 --> Security Class Initialized
DEBUG - 2024-12-11 05:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:19:57 --> CSRF cookie sent
INFO - 2024-12-11 05:19:57 --> Input Class Initialized
INFO - 2024-12-11 05:19:57 --> Language Class Initialized
INFO - 2024-12-11 05:19:57 --> Loader Class Initialized
INFO - 2024-12-11 05:19:57 --> Helper loaded: url_helper
INFO - 2024-12-11 05:19:57 --> Helper loaded: form_helper
INFO - 2024-12-11 05:19:57 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:19:57 --> Form Validation Class Initialized
INFO - 2024-12-11 05:19:57 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:19:57 --> Controller Class Initialized
INFO - 2024-12-11 05:19:57 --> Model "User_model" initialized
INFO - 2024-12-11 05:19:57 --> Model "Category_model" initialized
INFO - 2024-12-11 05:19:57 --> Model "Review_model" initialized
INFO - 2024-12-11 05:19:57 --> Model "News_model" initialized
INFO - 2024-12-11 05:19:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:19:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:19:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:19:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:19:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 05:19:57 --> Final output sent to browser
DEBUG - 2024-12-11 05:19:57 --> Total execution time: 0.0728
INFO - 2024-12-11 05:20:00 --> Config Class Initialized
INFO - 2024-12-11 05:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:20:00 --> Utf8 Class Initialized
INFO - 2024-12-11 05:20:00 --> URI Class Initialized
INFO - 2024-12-11 05:20:00 --> Router Class Initialized
INFO - 2024-12-11 05:20:00 --> Output Class Initialized
INFO - 2024-12-11 05:20:00 --> Security Class Initialized
DEBUG - 2024-12-11 05:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:20:00 --> CSRF cookie sent
INFO - 2024-12-11 05:20:00 --> Input Class Initialized
INFO - 2024-12-11 05:20:00 --> Language Class Initialized
INFO - 2024-12-11 05:20:00 --> Loader Class Initialized
INFO - 2024-12-11 05:20:00 --> Helper loaded: url_helper
INFO - 2024-12-11 05:20:00 --> Helper loaded: form_helper
INFO - 2024-12-11 05:20:00 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:20:00 --> Form Validation Class Initialized
INFO - 2024-12-11 05:20:00 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:20:00 --> Controller Class Initialized
INFO - 2024-12-11 05:20:00 --> Model "User_model" initialized
INFO - 2024-12-11 05:20:00 --> Model "Category_model" initialized
INFO - 2024-12-11 05:20:00 --> Model "Review_model" initialized
INFO - 2024-12-11 05:20:00 --> Model "News_model" initialized
INFO - 2024-12-11 05:20:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:20:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:20:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:20:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/minuman.php
INFO - 2024-12-11 05:20:00 --> Final output sent to browser
DEBUG - 2024-12-11 05:20:00 --> Total execution time: 0.0576
INFO - 2024-12-11 05:20:02 --> Config Class Initialized
INFO - 2024-12-11 05:20:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:20:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:20:02 --> Utf8 Class Initialized
INFO - 2024-12-11 05:20:02 --> URI Class Initialized
INFO - 2024-12-11 05:20:02 --> Router Class Initialized
INFO - 2024-12-11 05:20:02 --> Output Class Initialized
INFO - 2024-12-11 05:20:02 --> Security Class Initialized
DEBUG - 2024-12-11 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:20:02 --> CSRF cookie sent
INFO - 2024-12-11 05:20:02 --> Input Class Initialized
INFO - 2024-12-11 05:20:02 --> Language Class Initialized
INFO - 2024-12-11 05:20:02 --> Loader Class Initialized
INFO - 2024-12-11 05:20:02 --> Helper loaded: url_helper
INFO - 2024-12-11 05:20:02 --> Helper loaded: form_helper
INFO - 2024-12-11 05:20:02 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:20:02 --> Form Validation Class Initialized
INFO - 2024-12-11 05:20:02 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:20:02 --> Controller Class Initialized
INFO - 2024-12-11 05:20:02 --> Model "User_model" initialized
INFO - 2024-12-11 05:20:02 --> Model "Category_model" initialized
INFO - 2024-12-11 05:20:02 --> Model "Review_model" initialized
INFO - 2024-12-11 05:20:02 --> Model "News_model" initialized
INFO - 2024-12-11 05:20:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:21:11 --> Config Class Initialized
INFO - 2024-12-11 05:21:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:21:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:21:11 --> Utf8 Class Initialized
INFO - 2024-12-11 05:21:11 --> URI Class Initialized
INFO - 2024-12-11 05:21:11 --> Router Class Initialized
INFO - 2024-12-11 05:21:11 --> Output Class Initialized
INFO - 2024-12-11 05:21:11 --> Security Class Initialized
DEBUG - 2024-12-11 05:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:21:11 --> CSRF cookie sent
INFO - 2024-12-11 05:21:11 --> Input Class Initialized
INFO - 2024-12-11 05:21:11 --> Language Class Initialized
INFO - 2024-12-11 05:21:11 --> Loader Class Initialized
INFO - 2024-12-11 05:21:11 --> Helper loaded: url_helper
INFO - 2024-12-11 05:21:11 --> Helper loaded: form_helper
INFO - 2024-12-11 05:21:11 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:21:11 --> Form Validation Class Initialized
INFO - 2024-12-11 05:21:11 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:21:11 --> Controller Class Initialized
INFO - 2024-12-11 05:21:11 --> Model "User_model" initialized
INFO - 2024-12-11 05:21:11 --> Model "Category_model" initialized
INFO - 2024-12-11 05:21:11 --> Model "Review_model" initialized
INFO - 2024-12-11 05:21:11 --> Model "News_model" initialized
INFO - 2024-12-11 05:21:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:21:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:21:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:21:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:21:11 --> Final output sent to browser
DEBUG - 2024-12-11 05:21:11 --> Total execution time: 0.0481
INFO - 2024-12-11 05:21:24 --> Config Class Initialized
INFO - 2024-12-11 05:21:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:21:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:21:24 --> Utf8 Class Initialized
INFO - 2024-12-11 05:21:24 --> URI Class Initialized
INFO - 2024-12-11 05:21:24 --> Router Class Initialized
INFO - 2024-12-11 05:21:24 --> Output Class Initialized
INFO - 2024-12-11 05:21:24 --> Security Class Initialized
DEBUG - 2024-12-11 05:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:21:24 --> CSRF cookie sent
INFO - 2024-12-11 05:21:24 --> Input Class Initialized
INFO - 2024-12-11 05:21:24 --> Language Class Initialized
INFO - 2024-12-11 05:21:24 --> Loader Class Initialized
INFO - 2024-12-11 05:21:24 --> Helper loaded: url_helper
INFO - 2024-12-11 05:21:24 --> Helper loaded: form_helper
INFO - 2024-12-11 05:21:24 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:21:24 --> Form Validation Class Initialized
INFO - 2024-12-11 05:21:24 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:21:24 --> Controller Class Initialized
INFO - 2024-12-11 05:21:24 --> Model "User_model" initialized
INFO - 2024-12-11 05:21:24 --> Model "Category_model" initialized
INFO - 2024-12-11 05:21:24 --> Model "Review_model" initialized
INFO - 2024-12-11 05:21:24 --> Model "News_model" initialized
INFO - 2024-12-11 05:21:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:21:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:21:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:21:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:21:24 --> Final output sent to browser
DEBUG - 2024-12-11 05:21:24 --> Total execution time: 0.0692
INFO - 2024-12-11 05:26:49 --> Config Class Initialized
INFO - 2024-12-11 05:26:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:26:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:26:49 --> Utf8 Class Initialized
INFO - 2024-12-11 05:26:49 --> URI Class Initialized
INFO - 2024-12-11 05:26:49 --> Router Class Initialized
INFO - 2024-12-11 05:26:49 --> Output Class Initialized
INFO - 2024-12-11 05:26:49 --> Security Class Initialized
DEBUG - 2024-12-11 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:26:49 --> CSRF cookie sent
INFO - 2024-12-11 05:26:49 --> Input Class Initialized
INFO - 2024-12-11 05:26:49 --> Language Class Initialized
INFO - 2024-12-11 05:26:49 --> Loader Class Initialized
INFO - 2024-12-11 05:26:49 --> Helper loaded: url_helper
INFO - 2024-12-11 05:26:49 --> Helper loaded: form_helper
INFO - 2024-12-11 05:26:49 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:26:49 --> Form Validation Class Initialized
INFO - 2024-12-11 05:26:49 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:26:49 --> Controller Class Initialized
INFO - 2024-12-11 05:26:49 --> Model "User_model" initialized
INFO - 2024-12-11 05:26:49 --> Model "Category_model" initialized
INFO - 2024-12-11 05:26:49 --> Model "Review_model" initialized
INFO - 2024-12-11 05:26:49 --> Model "News_model" initialized
INFO - 2024-12-11 05:26:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:26:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:26:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:26:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:26:49 --> Final output sent to browser
DEBUG - 2024-12-11 05:26:49 --> Total execution time: 0.0868
INFO - 2024-12-11 05:27:56 --> Config Class Initialized
INFO - 2024-12-11 05:27:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:27:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:27:56 --> Utf8 Class Initialized
INFO - 2024-12-11 05:27:56 --> URI Class Initialized
INFO - 2024-12-11 05:27:56 --> Router Class Initialized
INFO - 2024-12-11 05:27:56 --> Output Class Initialized
INFO - 2024-12-11 05:27:56 --> Security Class Initialized
DEBUG - 2024-12-11 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:27:56 --> CSRF cookie sent
INFO - 2024-12-11 05:27:56 --> Input Class Initialized
INFO - 2024-12-11 05:27:56 --> Language Class Initialized
INFO - 2024-12-11 05:27:56 --> Loader Class Initialized
INFO - 2024-12-11 05:27:56 --> Helper loaded: url_helper
INFO - 2024-12-11 05:27:56 --> Helper loaded: form_helper
INFO - 2024-12-11 05:27:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:27:56 --> Form Validation Class Initialized
INFO - 2024-12-11 05:27:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:27:56 --> Controller Class Initialized
INFO - 2024-12-11 05:27:56 --> Model "User_model" initialized
INFO - 2024-12-11 05:27:56 --> Model "Category_model" initialized
INFO - 2024-12-11 05:27:56 --> Model "Review_model" initialized
INFO - 2024-12-11 05:27:56 --> Model "News_model" initialized
INFO - 2024-12-11 05:27:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:27:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:27:56 --> Query result: stdClass Object
(
    [view_count] => 127
)

INFO - 2024-12-11 05:27:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:27:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:27:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 05:27:56 --> Final output sent to browser
DEBUG - 2024-12-11 05:27:56 --> Total execution time: 0.0544
INFO - 2024-12-11 05:27:57 --> Config Class Initialized
INFO - 2024-12-11 05:27:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:27:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:27:57 --> Utf8 Class Initialized
INFO - 2024-12-11 05:27:57 --> URI Class Initialized
INFO - 2024-12-11 05:27:57 --> Router Class Initialized
INFO - 2024-12-11 05:27:57 --> Output Class Initialized
INFO - 2024-12-11 05:27:57 --> Security Class Initialized
DEBUG - 2024-12-11 05:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:27:57 --> CSRF cookie sent
INFO - 2024-12-11 05:27:57 --> Input Class Initialized
INFO - 2024-12-11 05:27:57 --> Language Class Initialized
ERROR - 2024-12-11 05:27:57 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 05:27:58 --> Config Class Initialized
INFO - 2024-12-11 05:27:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:27:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:27:58 --> Utf8 Class Initialized
INFO - 2024-12-11 05:27:58 --> URI Class Initialized
INFO - 2024-12-11 05:27:58 --> Router Class Initialized
INFO - 2024-12-11 05:27:58 --> Output Class Initialized
INFO - 2024-12-11 05:27:58 --> Security Class Initialized
DEBUG - 2024-12-11 05:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:27:58 --> CSRF cookie sent
INFO - 2024-12-11 05:27:58 --> Input Class Initialized
INFO - 2024-12-11 05:27:58 --> Language Class Initialized
INFO - 2024-12-11 05:27:58 --> Loader Class Initialized
INFO - 2024-12-11 05:27:58 --> Helper loaded: url_helper
INFO - 2024-12-11 05:27:58 --> Helper loaded: form_helper
INFO - 2024-12-11 05:27:58 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:27:58 --> Form Validation Class Initialized
INFO - 2024-12-11 05:27:58 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:27:58 --> Controller Class Initialized
INFO - 2024-12-11 05:27:58 --> Model "User_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "Category_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "Review_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "News_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:27:58 --> Config Class Initialized
INFO - 2024-12-11 05:27:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:27:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:27:58 --> Utf8 Class Initialized
INFO - 2024-12-11 05:27:58 --> URI Class Initialized
INFO - 2024-12-11 05:27:58 --> Router Class Initialized
INFO - 2024-12-11 05:27:58 --> Output Class Initialized
INFO - 2024-12-11 05:27:58 --> Security Class Initialized
DEBUG - 2024-12-11 05:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:27:58 --> CSRF cookie sent
INFO - 2024-12-11 05:27:58 --> Input Class Initialized
INFO - 2024-12-11 05:27:58 --> Language Class Initialized
INFO - 2024-12-11 05:27:58 --> Loader Class Initialized
INFO - 2024-12-11 05:27:58 --> Helper loaded: url_helper
INFO - 2024-12-11 05:27:58 --> Helper loaded: form_helper
INFO - 2024-12-11 05:27:58 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:27:58 --> Form Validation Class Initialized
INFO - 2024-12-11 05:27:58 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:27:58 --> Controller Class Initialized
INFO - 2024-12-11 05:27:58 --> Model "User_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "Category_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "Review_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "News_model" initialized
INFO - 2024-12-11 05:27:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:27:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:27:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:27:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 05:27:58 --> Final output sent to browser
DEBUG - 2024-12-11 05:27:58 --> Total execution time: 0.0500
INFO - 2024-12-11 05:28:04 --> Config Class Initialized
INFO - 2024-12-11 05:28:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:04 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:04 --> URI Class Initialized
INFO - 2024-12-11 05:28:04 --> Router Class Initialized
INFO - 2024-12-11 05:28:04 --> Output Class Initialized
INFO - 2024-12-11 05:28:04 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:04 --> CSRF cookie sent
INFO - 2024-12-11 05:28:04 --> Input Class Initialized
INFO - 2024-12-11 05:28:04 --> Language Class Initialized
INFO - 2024-12-11 05:28:04 --> Loader Class Initialized
INFO - 2024-12-11 05:28:04 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:04 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:04 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:04 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:04 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:04 --> Controller Class Initialized
INFO - 2024-12-11 05:28:04 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:04 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:04 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:04 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:28:04 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:04 --> Total execution time: 0.0461
INFO - 2024-12-11 05:28:07 --> Config Class Initialized
INFO - 2024-12-11 05:28:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:07 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:07 --> URI Class Initialized
INFO - 2024-12-11 05:28:07 --> Router Class Initialized
INFO - 2024-12-11 05:28:07 --> Output Class Initialized
INFO - 2024-12-11 05:28:07 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:07 --> CSRF cookie sent
INFO - 2024-12-11 05:28:07 --> Input Class Initialized
INFO - 2024-12-11 05:28:07 --> Language Class Initialized
INFO - 2024-12-11 05:28:07 --> Loader Class Initialized
INFO - 2024-12-11 05:28:07 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:07 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:07 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:07 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:07 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:07 --> Controller Class Initialized
INFO - 2024-12-11 05:28:07 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:07 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:07 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:07 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:28:07 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:07 --> Total execution time: 0.0636
INFO - 2024-12-11 05:28:10 --> Config Class Initialized
INFO - 2024-12-11 05:28:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:10 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:10 --> URI Class Initialized
INFO - 2024-12-11 05:28:10 --> Router Class Initialized
INFO - 2024-12-11 05:28:10 --> Output Class Initialized
INFO - 2024-12-11 05:28:10 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:10 --> CSRF cookie sent
INFO - 2024-12-11 05:28:10 --> Input Class Initialized
INFO - 2024-12-11 05:28:10 --> Language Class Initialized
INFO - 2024-12-11 05:28:10 --> Loader Class Initialized
INFO - 2024-12-11 05:28:10 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:10 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:10 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:10 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:10 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:10 --> Controller Class Initialized
INFO - 2024-12-11 05:28:10 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:10 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:10 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:10 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:28:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-11 05:28:10 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:10 --> Total execution time: 0.0548
INFO - 2024-12-11 05:28:17 --> Config Class Initialized
INFO - 2024-12-11 05:28:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:17 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:17 --> URI Class Initialized
INFO - 2024-12-11 05:28:17 --> Router Class Initialized
INFO - 2024-12-11 05:28:17 --> Output Class Initialized
INFO - 2024-12-11 05:28:17 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:17 --> CSRF cookie sent
INFO - 2024-12-11 05:28:17 --> Input Class Initialized
INFO - 2024-12-11 05:28:17 --> Language Class Initialized
INFO - 2024-12-11 05:28:17 --> Loader Class Initialized
INFO - 2024-12-11 05:28:17 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:17 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:17 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:17 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:17 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:17 --> Controller Class Initialized
INFO - 2024-12-11 05:28:17 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:17 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:17 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:17 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:28:17 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:17 --> Total execution time: 0.0566
INFO - 2024-12-11 05:28:21 --> Config Class Initialized
INFO - 2024-12-11 05:28:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:21 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:21 --> URI Class Initialized
INFO - 2024-12-11 05:28:21 --> Router Class Initialized
INFO - 2024-12-11 05:28:21 --> Output Class Initialized
INFO - 2024-12-11 05:28:21 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:21 --> CSRF cookie sent
INFO - 2024-12-11 05:28:21 --> Input Class Initialized
INFO - 2024-12-11 05:28:21 --> Language Class Initialized
INFO - 2024-12-11 05:28:21 --> Loader Class Initialized
INFO - 2024-12-11 05:28:21 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:21 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:21 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:21 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:21 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:21 --> Controller Class Initialized
INFO - 2024-12-11 05:28:21 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:21 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:21 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:22 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:28:22 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:22 --> Total execution time: 0.0469
INFO - 2024-12-11 05:28:54 --> Config Class Initialized
INFO - 2024-12-11 05:28:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:54 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:54 --> URI Class Initialized
INFO - 2024-12-11 05:28:54 --> Router Class Initialized
INFO - 2024-12-11 05:28:54 --> Output Class Initialized
INFO - 2024-12-11 05:28:54 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:54 --> CSRF cookie sent
INFO - 2024-12-11 05:28:54 --> Input Class Initialized
INFO - 2024-12-11 05:28:54 --> Language Class Initialized
INFO - 2024-12-11 05:28:54 --> Loader Class Initialized
INFO - 2024-12-11 05:28:54 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:54 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:54 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:54 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:54 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:54 --> Controller Class Initialized
INFO - 2024-12-11 05:28:54 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:54 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:54 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:54 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:28:54 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:54 --> Total execution time: 0.0579
INFO - 2024-12-11 05:28:56 --> Config Class Initialized
INFO - 2024-12-11 05:28:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:28:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:28:56 --> Utf8 Class Initialized
INFO - 2024-12-11 05:28:56 --> URI Class Initialized
INFO - 2024-12-11 05:28:56 --> Router Class Initialized
INFO - 2024-12-11 05:28:56 --> Output Class Initialized
INFO - 2024-12-11 05:28:56 --> Security Class Initialized
DEBUG - 2024-12-11 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:28:56 --> CSRF cookie sent
INFO - 2024-12-11 05:28:56 --> Input Class Initialized
INFO - 2024-12-11 05:28:56 --> Language Class Initialized
INFO - 2024-12-11 05:28:56 --> Loader Class Initialized
INFO - 2024-12-11 05:28:56 --> Helper loaded: url_helper
INFO - 2024-12-11 05:28:56 --> Helper loaded: form_helper
INFO - 2024-12-11 05:28:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:28:56 --> Form Validation Class Initialized
INFO - 2024-12-11 05:28:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:28:56 --> Controller Class Initialized
INFO - 2024-12-11 05:28:56 --> Model "User_model" initialized
INFO - 2024-12-11 05:28:56 --> Model "Category_model" initialized
INFO - 2024-12-11 05:28:56 --> Model "Review_model" initialized
INFO - 2024-12-11 05:28:56 --> Model "News_model" initialized
INFO - 2024-12-11 05:28:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:28:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:28:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:28:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:28:56 --> Final output sent to browser
DEBUG - 2024-12-11 05:28:56 --> Total execution time: 0.0439
INFO - 2024-12-11 05:29:04 --> Config Class Initialized
INFO - 2024-12-11 05:29:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:29:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:29:04 --> Utf8 Class Initialized
INFO - 2024-12-11 05:29:04 --> URI Class Initialized
INFO - 2024-12-11 05:29:04 --> Router Class Initialized
INFO - 2024-12-11 05:29:04 --> Output Class Initialized
INFO - 2024-12-11 05:29:04 --> Security Class Initialized
DEBUG - 2024-12-11 05:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:29:04 --> CSRF cookie sent
INFO - 2024-12-11 05:29:04 --> Input Class Initialized
INFO - 2024-12-11 05:29:04 --> Language Class Initialized
INFO - 2024-12-11 05:29:04 --> Loader Class Initialized
INFO - 2024-12-11 05:29:04 --> Helper loaded: url_helper
INFO - 2024-12-11 05:29:04 --> Helper loaded: form_helper
INFO - 2024-12-11 05:29:04 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:29:04 --> Form Validation Class Initialized
INFO - 2024-12-11 05:29:04 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:29:04 --> Controller Class Initialized
INFO - 2024-12-11 05:29:04 --> Model "User_model" initialized
INFO - 2024-12-11 05:29:04 --> Model "Category_model" initialized
INFO - 2024-12-11 05:29:04 --> Model "Review_model" initialized
INFO - 2024-12-11 05:29:04 --> Model "News_model" initialized
INFO - 2024-12-11 05:29:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:29:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:29:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:29:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:29:04 --> Final output sent to browser
DEBUG - 2024-12-11 05:29:04 --> Total execution time: 0.0486
INFO - 2024-12-11 05:29:25 --> Config Class Initialized
INFO - 2024-12-11 05:29:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:29:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:29:25 --> Utf8 Class Initialized
INFO - 2024-12-11 05:29:25 --> URI Class Initialized
INFO - 2024-12-11 05:29:25 --> Router Class Initialized
INFO - 2024-12-11 05:29:25 --> Output Class Initialized
INFO - 2024-12-11 05:29:25 --> Security Class Initialized
DEBUG - 2024-12-11 05:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:29:25 --> CSRF cookie sent
INFO - 2024-12-11 05:29:25 --> Input Class Initialized
INFO - 2024-12-11 05:29:25 --> Language Class Initialized
INFO - 2024-12-11 05:29:25 --> Loader Class Initialized
INFO - 2024-12-11 05:29:25 --> Helper loaded: url_helper
INFO - 2024-12-11 05:29:25 --> Helper loaded: form_helper
INFO - 2024-12-11 05:29:25 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:29:25 --> Form Validation Class Initialized
INFO - 2024-12-11 05:29:25 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:29:25 --> Controller Class Initialized
INFO - 2024-12-11 05:29:25 --> Model "User_model" initialized
INFO - 2024-12-11 05:29:25 --> Model "Category_model" initialized
INFO - 2024-12-11 05:29:25 --> Model "Review_model" initialized
INFO - 2024-12-11 05:29:25 --> Model "News_model" initialized
INFO - 2024-12-11 05:29:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:29:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:29:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:29:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:29:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 05:29:25 --> Final output sent to browser
DEBUG - 2024-12-11 05:29:25 --> Total execution time: 0.0620
INFO - 2024-12-11 05:29:27 --> Config Class Initialized
INFO - 2024-12-11 05:29:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:29:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:29:27 --> Utf8 Class Initialized
INFO - 2024-12-11 05:29:27 --> URI Class Initialized
INFO - 2024-12-11 05:29:27 --> Router Class Initialized
INFO - 2024-12-11 05:29:27 --> Output Class Initialized
INFO - 2024-12-11 05:29:27 --> Security Class Initialized
DEBUG - 2024-12-11 05:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:29:27 --> CSRF cookie sent
INFO - 2024-12-11 05:29:27 --> Input Class Initialized
INFO - 2024-12-11 05:29:27 --> Language Class Initialized
INFO - 2024-12-11 05:29:27 --> Loader Class Initialized
INFO - 2024-12-11 05:29:27 --> Helper loaded: url_helper
INFO - 2024-12-11 05:29:27 --> Helper loaded: form_helper
INFO - 2024-12-11 05:29:27 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:29:27 --> Form Validation Class Initialized
INFO - 2024-12-11 05:29:27 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:29:27 --> Controller Class Initialized
INFO - 2024-12-11 05:29:27 --> Model "User_model" initialized
INFO - 2024-12-11 05:29:27 --> Model "Category_model" initialized
INFO - 2024-12-11 05:29:27 --> Model "Review_model" initialized
INFO - 2024-12-11 05:29:27 --> Model "News_model" initialized
INFO - 2024-12-11 05:29:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:29:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:29:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:29:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:29:27 --> Final output sent to browser
DEBUG - 2024-12-11 05:29:27 --> Total execution time: 0.0618
INFO - 2024-12-11 05:33:24 --> Config Class Initialized
INFO - 2024-12-11 05:33:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:24 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:24 --> URI Class Initialized
INFO - 2024-12-11 05:33:24 --> Router Class Initialized
INFO - 2024-12-11 05:33:24 --> Output Class Initialized
INFO - 2024-12-11 05:33:24 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:24 --> CSRF cookie sent
INFO - 2024-12-11 05:33:24 --> Input Class Initialized
INFO - 2024-12-11 05:33:24 --> Language Class Initialized
INFO - 2024-12-11 05:33:24 --> Loader Class Initialized
INFO - 2024-12-11 05:33:24 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:24 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:24 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:24 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:24 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:24 --> Controller Class Initialized
INFO - 2024-12-11 05:33:24 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:24 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:24 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:24 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:33:24 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:24 --> Total execution time: 0.0440
INFO - 2024-12-11 05:33:27 --> Config Class Initialized
INFO - 2024-12-11 05:33:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:27 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:27 --> URI Class Initialized
INFO - 2024-12-11 05:33:27 --> Router Class Initialized
INFO - 2024-12-11 05:33:27 --> Output Class Initialized
INFO - 2024-12-11 05:33:27 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:27 --> CSRF cookie sent
INFO - 2024-12-11 05:33:27 --> Input Class Initialized
INFO - 2024-12-11 05:33:27 --> Language Class Initialized
INFO - 2024-12-11 05:33:27 --> Loader Class Initialized
INFO - 2024-12-11 05:33:27 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:27 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:27 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:27 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:27 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:27 --> Controller Class Initialized
INFO - 2024-12-11 05:33:27 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:27 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:27 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:27 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:33:27 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:27 --> Total execution time: 0.0482
INFO - 2024-12-11 05:33:31 --> Config Class Initialized
INFO - 2024-12-11 05:33:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:31 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:31 --> URI Class Initialized
INFO - 2024-12-11 05:33:31 --> Router Class Initialized
INFO - 2024-12-11 05:33:31 --> Output Class Initialized
INFO - 2024-12-11 05:33:31 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:31 --> CSRF cookie sent
INFO - 2024-12-11 05:33:31 --> Input Class Initialized
INFO - 2024-12-11 05:33:31 --> Language Class Initialized
INFO - 2024-12-11 05:33:31 --> Loader Class Initialized
INFO - 2024-12-11 05:33:31 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:31 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:31 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:31 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:31 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:31 --> Controller Class Initialized
INFO - 2024-12-11 05:33:31 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:31 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:31 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:31 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:33:31 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:31 --> Total execution time: 0.0472
INFO - 2024-12-11 05:33:35 --> Config Class Initialized
INFO - 2024-12-11 05:33:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:35 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:35 --> URI Class Initialized
INFO - 2024-12-11 05:33:35 --> Router Class Initialized
INFO - 2024-12-11 05:33:35 --> Output Class Initialized
INFO - 2024-12-11 05:33:35 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:35 --> CSRF cookie sent
INFO - 2024-12-11 05:33:35 --> Input Class Initialized
INFO - 2024-12-11 05:33:35 --> Language Class Initialized
INFO - 2024-12-11 05:33:35 --> Loader Class Initialized
INFO - 2024-12-11 05:33:35 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:35 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:35 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:35 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:35 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:35 --> Controller Class Initialized
INFO - 2024-12-11 05:33:35 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:35 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:35 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:35 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:33:35 --> Query result: stdClass Object
(
    [view_count] => 128
)

INFO - 2024-12-11 05:33:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 05:33:35 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:35 --> Total execution time: 0.0631
INFO - 2024-12-11 05:33:35 --> Config Class Initialized
INFO - 2024-12-11 05:33:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:35 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:35 --> URI Class Initialized
INFO - 2024-12-11 05:33:35 --> Router Class Initialized
INFO - 2024-12-11 05:33:35 --> Output Class Initialized
INFO - 2024-12-11 05:33:35 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:35 --> CSRF cookie sent
INFO - 2024-12-11 05:33:35 --> Input Class Initialized
INFO - 2024-12-11 05:33:35 --> Language Class Initialized
ERROR - 2024-12-11 05:33:35 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 05:33:37 --> Config Class Initialized
INFO - 2024-12-11 05:33:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:37 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:37 --> URI Class Initialized
INFO - 2024-12-11 05:33:37 --> Router Class Initialized
INFO - 2024-12-11 05:33:37 --> Output Class Initialized
INFO - 2024-12-11 05:33:37 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:37 --> CSRF cookie sent
INFO - 2024-12-11 05:33:37 --> Input Class Initialized
INFO - 2024-12-11 05:33:37 --> Language Class Initialized
INFO - 2024-12-11 05:33:37 --> Loader Class Initialized
INFO - 2024-12-11 05:33:37 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:37 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:37 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:37 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:37 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:37 --> Controller Class Initialized
INFO - 2024-12-11 05:33:37 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:37 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:37 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:37 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:33:37 --> Query result: stdClass Object
(
    [view_count] => 129
)

INFO - 2024-12-11 05:33:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 05:33:37 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:37 --> Total execution time: 0.0499
INFO - 2024-12-11 05:33:37 --> Config Class Initialized
INFO - 2024-12-11 05:33:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:37 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:37 --> URI Class Initialized
INFO - 2024-12-11 05:33:37 --> Router Class Initialized
INFO - 2024-12-11 05:33:37 --> Output Class Initialized
INFO - 2024-12-11 05:33:37 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:37 --> CSRF cookie sent
INFO - 2024-12-11 05:33:37 --> Input Class Initialized
INFO - 2024-12-11 05:33:37 --> Language Class Initialized
ERROR - 2024-12-11 05:33:37 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 05:33:38 --> Config Class Initialized
INFO - 2024-12-11 05:33:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:38 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:38 --> URI Class Initialized
INFO - 2024-12-11 05:33:38 --> Router Class Initialized
INFO - 2024-12-11 05:33:38 --> Output Class Initialized
INFO - 2024-12-11 05:33:38 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:38 --> CSRF cookie sent
INFO - 2024-12-11 05:33:38 --> Input Class Initialized
INFO - 2024-12-11 05:33:38 --> Language Class Initialized
INFO - 2024-12-11 05:33:38 --> Loader Class Initialized
INFO - 2024-12-11 05:33:38 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:38 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:38 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:38 --> Controller Class Initialized
INFO - 2024-12-11 05:33:38 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:38 --> Config Class Initialized
INFO - 2024-12-11 05:33:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:38 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:38 --> URI Class Initialized
INFO - 2024-12-11 05:33:38 --> Router Class Initialized
INFO - 2024-12-11 05:33:38 --> Output Class Initialized
INFO - 2024-12-11 05:33:38 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:38 --> CSRF cookie sent
INFO - 2024-12-11 05:33:38 --> Input Class Initialized
INFO - 2024-12-11 05:33:38 --> Language Class Initialized
INFO - 2024-12-11 05:33:38 --> Loader Class Initialized
INFO - 2024-12-11 05:33:38 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:38 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:38 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:38 --> Controller Class Initialized
INFO - 2024-12-11 05:33:38 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 05:33:38 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:38 --> Total execution time: 0.0424
INFO - 2024-12-11 05:33:41 --> Config Class Initialized
INFO - 2024-12-11 05:33:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:41 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:41 --> URI Class Initialized
INFO - 2024-12-11 05:33:41 --> Router Class Initialized
INFO - 2024-12-11 05:33:41 --> Output Class Initialized
INFO - 2024-12-11 05:33:41 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:41 --> CSRF cookie sent
INFO - 2024-12-11 05:33:41 --> Input Class Initialized
INFO - 2024-12-11 05:33:41 --> Language Class Initialized
INFO - 2024-12-11 05:33:41 --> Loader Class Initialized
INFO - 2024-12-11 05:33:41 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:41 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:41 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:41 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:41 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:41 --> Controller Class Initialized
INFO - 2024-12-11 05:33:41 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:41 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:41 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:41 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 05:33:41 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:41 --> Total execution time: 0.0584
INFO - 2024-12-11 05:33:43 --> Config Class Initialized
INFO - 2024-12-11 05:33:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:33:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:33:43 --> Utf8 Class Initialized
INFO - 2024-12-11 05:33:43 --> URI Class Initialized
INFO - 2024-12-11 05:33:43 --> Router Class Initialized
INFO - 2024-12-11 05:33:43 --> Output Class Initialized
INFO - 2024-12-11 05:33:43 --> Security Class Initialized
DEBUG - 2024-12-11 05:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:33:43 --> CSRF cookie sent
INFO - 2024-12-11 05:33:43 --> Input Class Initialized
INFO - 2024-12-11 05:33:43 --> Language Class Initialized
INFO - 2024-12-11 05:33:43 --> Loader Class Initialized
INFO - 2024-12-11 05:33:43 --> Helper loaded: url_helper
INFO - 2024-12-11 05:33:43 --> Helper loaded: form_helper
INFO - 2024-12-11 05:33:43 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:33:43 --> Form Validation Class Initialized
INFO - 2024-12-11 05:33:43 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:33:43 --> Controller Class Initialized
INFO - 2024-12-11 05:33:43 --> Model "User_model" initialized
INFO - 2024-12-11 05:33:43 --> Model "Category_model" initialized
INFO - 2024-12-11 05:33:43 --> Model "Review_model" initialized
INFO - 2024-12-11 05:33:43 --> Model "News_model" initialized
INFO - 2024-12-11 05:33:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:33:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:33:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:33:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:33:43 --> Final output sent to browser
DEBUG - 2024-12-11 05:33:43 --> Total execution time: 0.0443
INFO - 2024-12-11 05:35:40 --> Config Class Initialized
INFO - 2024-12-11 05:35:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:35:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:35:40 --> Utf8 Class Initialized
INFO - 2024-12-11 05:35:40 --> URI Class Initialized
INFO - 2024-12-11 05:35:40 --> Router Class Initialized
INFO - 2024-12-11 05:35:40 --> Output Class Initialized
INFO - 2024-12-11 05:35:40 --> Security Class Initialized
DEBUG - 2024-12-11 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:35:40 --> CSRF cookie sent
INFO - 2024-12-11 05:35:40 --> Input Class Initialized
INFO - 2024-12-11 05:35:40 --> Language Class Initialized
INFO - 2024-12-11 05:35:40 --> Loader Class Initialized
INFO - 2024-12-11 05:35:40 --> Helper loaded: url_helper
INFO - 2024-12-11 05:35:40 --> Helper loaded: form_helper
INFO - 2024-12-11 05:35:40 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:35:40 --> Form Validation Class Initialized
INFO - 2024-12-11 05:35:40 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:35:40 --> Controller Class Initialized
INFO - 2024-12-11 05:35:40 --> Model "User_model" initialized
INFO - 2024-12-11 05:35:40 --> Model "Category_model" initialized
INFO - 2024-12-11 05:35:40 --> Model "Review_model" initialized
INFO - 2024-12-11 05:35:40 --> Model "News_model" initialized
INFO - 2024-12-11 05:35:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:35:40 --> Final output sent to browser
DEBUG - 2024-12-11 05:35:40 --> Total execution time: 0.0461
INFO - 2024-12-11 05:35:45 --> Config Class Initialized
INFO - 2024-12-11 05:35:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:35:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:35:45 --> Utf8 Class Initialized
INFO - 2024-12-11 05:35:45 --> URI Class Initialized
INFO - 2024-12-11 05:35:45 --> Router Class Initialized
INFO - 2024-12-11 05:35:45 --> Output Class Initialized
INFO - 2024-12-11 05:35:45 --> Security Class Initialized
DEBUG - 2024-12-11 05:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:35:45 --> CSRF cookie sent
INFO - 2024-12-11 05:35:45 --> Input Class Initialized
INFO - 2024-12-11 05:35:45 --> Language Class Initialized
INFO - 2024-12-11 05:35:45 --> Loader Class Initialized
INFO - 2024-12-11 05:35:45 --> Helper loaded: url_helper
INFO - 2024-12-11 05:35:45 --> Helper loaded: form_helper
INFO - 2024-12-11 05:35:45 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:35:45 --> Form Validation Class Initialized
INFO - 2024-12-11 05:35:45 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:35:45 --> Controller Class Initialized
INFO - 2024-12-11 05:35:45 --> Model "User_model" initialized
INFO - 2024-12-11 05:35:45 --> Model "Category_model" initialized
INFO - 2024-12-11 05:35:45 --> Model "Review_model" initialized
INFO - 2024-12-11 05:35:45 --> Model "News_model" initialized
INFO - 2024-12-11 05:35:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:35:45 --> Query result: stdClass Object
(
    [view_count] => 130
)

INFO - 2024-12-11 05:35:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:35:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:35:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 05:35:45 --> Final output sent to browser
DEBUG - 2024-12-11 05:35:45 --> Total execution time: 0.0493
INFO - 2024-12-11 05:35:45 --> Config Class Initialized
INFO - 2024-12-11 05:35:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:35:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:35:45 --> Utf8 Class Initialized
INFO - 2024-12-11 05:35:45 --> URI Class Initialized
INFO - 2024-12-11 05:35:45 --> Router Class Initialized
INFO - 2024-12-11 05:35:45 --> Output Class Initialized
INFO - 2024-12-11 05:35:45 --> Security Class Initialized
DEBUG - 2024-12-11 05:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:35:45 --> CSRF cookie sent
INFO - 2024-12-11 05:35:45 --> Input Class Initialized
INFO - 2024-12-11 05:35:45 --> Language Class Initialized
ERROR - 2024-12-11 05:35:45 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 05:35:47 --> Config Class Initialized
INFO - 2024-12-11 05:35:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:35:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:35:47 --> Utf8 Class Initialized
INFO - 2024-12-11 05:35:47 --> URI Class Initialized
INFO - 2024-12-11 05:35:47 --> Router Class Initialized
INFO - 2024-12-11 05:35:47 --> Output Class Initialized
INFO - 2024-12-11 05:35:47 --> Security Class Initialized
DEBUG - 2024-12-11 05:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:35:47 --> CSRF cookie sent
INFO - 2024-12-11 05:35:47 --> Input Class Initialized
INFO - 2024-12-11 05:35:47 --> Language Class Initialized
INFO - 2024-12-11 05:35:47 --> Loader Class Initialized
INFO - 2024-12-11 05:35:47 --> Helper loaded: url_helper
INFO - 2024-12-11 05:35:47 --> Helper loaded: form_helper
INFO - 2024-12-11 05:35:47 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:35:47 --> Form Validation Class Initialized
INFO - 2024-12-11 05:35:47 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:35:47 --> Controller Class Initialized
INFO - 2024-12-11 05:35:47 --> Model "User_model" initialized
INFO - 2024-12-11 05:35:47 --> Model "Category_model" initialized
INFO - 2024-12-11 05:35:47 --> Model "Review_model" initialized
INFO - 2024-12-11 05:35:47 --> Model "News_model" initialized
INFO - 2024-12-11 05:35:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:35:47 --> Final output sent to browser
DEBUG - 2024-12-11 05:35:47 --> Total execution time: 0.0777
INFO - 2024-12-11 05:40:32 --> Config Class Initialized
INFO - 2024-12-11 05:40:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:40:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:40:32 --> Utf8 Class Initialized
INFO - 2024-12-11 05:40:32 --> URI Class Initialized
INFO - 2024-12-11 05:40:32 --> Router Class Initialized
INFO - 2024-12-11 05:40:32 --> Output Class Initialized
INFO - 2024-12-11 05:40:32 --> Security Class Initialized
DEBUG - 2024-12-11 05:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:40:32 --> CSRF cookie sent
INFO - 2024-12-11 05:40:32 --> Input Class Initialized
INFO - 2024-12-11 05:40:32 --> Language Class Initialized
INFO - 2024-12-11 05:40:32 --> Loader Class Initialized
INFO - 2024-12-11 05:40:32 --> Helper loaded: url_helper
INFO - 2024-12-11 05:40:32 --> Helper loaded: form_helper
INFO - 2024-12-11 05:40:32 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:40:32 --> Form Validation Class Initialized
INFO - 2024-12-11 05:40:32 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:40:32 --> Controller Class Initialized
INFO - 2024-12-11 05:40:32 --> Model "User_model" initialized
INFO - 2024-12-11 05:40:32 --> Model "Category_model" initialized
INFO - 2024-12-11 05:40:32 --> Model "Review_model" initialized
INFO - 2024-12-11 05:40:32 --> Model "News_model" initialized
INFO - 2024-12-11 05:40:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:40:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:40:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:40:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:40:32 --> Final output sent to browser
DEBUG - 2024-12-11 05:40:32 --> Total execution time: 0.0543
INFO - 2024-12-11 05:41:54 --> Config Class Initialized
INFO - 2024-12-11 05:41:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:41:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:41:54 --> Utf8 Class Initialized
INFO - 2024-12-11 05:41:54 --> URI Class Initialized
INFO - 2024-12-11 05:41:54 --> Router Class Initialized
INFO - 2024-12-11 05:41:54 --> Output Class Initialized
INFO - 2024-12-11 05:41:54 --> Security Class Initialized
DEBUG - 2024-12-11 05:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:41:54 --> CSRF cookie sent
INFO - 2024-12-11 05:41:54 --> Input Class Initialized
INFO - 2024-12-11 05:41:54 --> Language Class Initialized
INFO - 2024-12-11 05:41:54 --> Loader Class Initialized
INFO - 2024-12-11 05:41:54 --> Helper loaded: url_helper
INFO - 2024-12-11 05:41:54 --> Helper loaded: form_helper
INFO - 2024-12-11 05:41:54 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:41:54 --> Form Validation Class Initialized
INFO - 2024-12-11 05:41:54 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:41:54 --> Controller Class Initialized
INFO - 2024-12-11 05:41:54 --> Model "User_model" initialized
INFO - 2024-12-11 05:41:54 --> Model "Category_model" initialized
INFO - 2024-12-11 05:41:54 --> Model "Review_model" initialized
INFO - 2024-12-11 05:41:54 --> Model "News_model" initialized
INFO - 2024-12-11 05:41:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:41:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:41:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:41:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:41:54 --> Final output sent to browser
DEBUG - 2024-12-11 05:41:54 --> Total execution time: 0.0523
INFO - 2024-12-11 05:44:27 --> Config Class Initialized
INFO - 2024-12-11 05:44:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:44:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:44:27 --> Utf8 Class Initialized
INFO - 2024-12-11 05:44:27 --> URI Class Initialized
INFO - 2024-12-11 05:44:27 --> Router Class Initialized
INFO - 2024-12-11 05:44:27 --> Output Class Initialized
INFO - 2024-12-11 05:44:27 --> Security Class Initialized
DEBUG - 2024-12-11 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:44:27 --> CSRF cookie sent
INFO - 2024-12-11 05:44:27 --> Input Class Initialized
INFO - 2024-12-11 05:44:27 --> Language Class Initialized
INFO - 2024-12-11 05:44:27 --> Loader Class Initialized
INFO - 2024-12-11 05:44:27 --> Helper loaded: url_helper
INFO - 2024-12-11 05:44:27 --> Helper loaded: form_helper
INFO - 2024-12-11 05:44:27 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:44:27 --> Form Validation Class Initialized
INFO - 2024-12-11 05:44:27 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:44:27 --> Controller Class Initialized
INFO - 2024-12-11 05:44:27 --> Model "User_model" initialized
INFO - 2024-12-11 05:44:27 --> Model "Category_model" initialized
INFO - 2024-12-11 05:44:27 --> Model "Review_model" initialized
INFO - 2024-12-11 05:44:27 --> Model "News_model" initialized
INFO - 2024-12-11 05:44:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:44:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:44:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:44:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:44:27 --> Final output sent to browser
DEBUG - 2024-12-11 05:44:27 --> Total execution time: 0.0613
INFO - 2024-12-11 05:44:35 --> Config Class Initialized
INFO - 2024-12-11 05:44:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:44:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:44:35 --> Utf8 Class Initialized
INFO - 2024-12-11 05:44:35 --> URI Class Initialized
INFO - 2024-12-11 05:44:35 --> Router Class Initialized
INFO - 2024-12-11 05:44:35 --> Output Class Initialized
INFO - 2024-12-11 05:44:35 --> Security Class Initialized
DEBUG - 2024-12-11 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:44:35 --> CSRF cookie sent
INFO - 2024-12-11 05:44:35 --> Input Class Initialized
INFO - 2024-12-11 05:44:35 --> Language Class Initialized
INFO - 2024-12-11 05:44:35 --> Loader Class Initialized
INFO - 2024-12-11 05:44:35 --> Helper loaded: url_helper
INFO - 2024-12-11 05:44:35 --> Helper loaded: form_helper
INFO - 2024-12-11 05:44:35 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:44:35 --> Form Validation Class Initialized
INFO - 2024-12-11 05:44:35 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:44:35 --> Controller Class Initialized
INFO - 2024-12-11 05:44:35 --> Model "User_model" initialized
INFO - 2024-12-11 05:44:35 --> Model "Category_model" initialized
INFO - 2024-12-11 05:44:35 --> Model "Review_model" initialized
INFO - 2024-12-11 05:44:35 --> Model "News_model" initialized
INFO - 2024-12-11 05:44:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:44:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:44:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:44:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 05:44:35 --> Final output sent to browser
DEBUG - 2024-12-11 05:44:35 --> Total execution time: 0.0581
INFO - 2024-12-11 05:46:47 --> Config Class Initialized
INFO - 2024-12-11 05:46:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:46:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:46:47 --> Utf8 Class Initialized
INFO - 2024-12-11 05:46:47 --> URI Class Initialized
INFO - 2024-12-11 05:46:47 --> Router Class Initialized
INFO - 2024-12-11 05:46:47 --> Output Class Initialized
INFO - 2024-12-11 05:46:47 --> Security Class Initialized
DEBUG - 2024-12-11 05:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:46:47 --> CSRF cookie sent
INFO - 2024-12-11 05:46:47 --> Input Class Initialized
INFO - 2024-12-11 05:46:47 --> Language Class Initialized
INFO - 2024-12-11 05:46:47 --> Loader Class Initialized
INFO - 2024-12-11 05:46:47 --> Helper loaded: url_helper
INFO - 2024-12-11 05:46:47 --> Helper loaded: form_helper
INFO - 2024-12-11 05:46:47 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:46:47 --> Form Validation Class Initialized
INFO - 2024-12-11 05:46:47 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:46:47 --> Controller Class Initialized
INFO - 2024-12-11 05:46:47 --> Model "User_model" initialized
INFO - 2024-12-11 05:46:47 --> Model "Category_model" initialized
INFO - 2024-12-11 05:46:47 --> Model "Review_model" initialized
INFO - 2024-12-11 05:46:47 --> Model "News_model" initialized
INFO - 2024-12-11 05:46:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:46:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:46:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:46:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:46:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 05:46:47 --> Final output sent to browser
DEBUG - 2024-12-11 05:46:47 --> Total execution time: 0.0599
INFO - 2024-12-11 05:46:59 --> Config Class Initialized
INFO - 2024-12-11 05:46:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:46:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:46:59 --> Utf8 Class Initialized
INFO - 2024-12-11 05:46:59 --> URI Class Initialized
INFO - 2024-12-11 05:46:59 --> Router Class Initialized
INFO - 2024-12-11 05:46:59 --> Output Class Initialized
INFO - 2024-12-11 05:46:59 --> Security Class Initialized
DEBUG - 2024-12-11 05:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:46:59 --> CSRF cookie sent
INFO - 2024-12-11 05:46:59 --> Input Class Initialized
INFO - 2024-12-11 05:46:59 --> Language Class Initialized
INFO - 2024-12-11 05:46:59 --> Loader Class Initialized
INFO - 2024-12-11 05:46:59 --> Helper loaded: url_helper
INFO - 2024-12-11 05:46:59 --> Helper loaded: form_helper
INFO - 2024-12-11 05:46:59 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:46:59 --> Form Validation Class Initialized
INFO - 2024-12-11 05:46:59 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:46:59 --> Controller Class Initialized
INFO - 2024-12-11 05:46:59 --> Model "User_model" initialized
INFO - 2024-12-11 05:46:59 --> Model "Category_model" initialized
INFO - 2024-12-11 05:46:59 --> Model "Review_model" initialized
INFO - 2024-12-11 05:46:59 --> Model "News_model" initialized
INFO - 2024-12-11 05:46:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:46:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:46:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:46:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/minuman.php
INFO - 2024-12-11 05:46:59 --> Final output sent to browser
DEBUG - 2024-12-11 05:46:59 --> Total execution time: 0.0438
INFO - 2024-12-11 05:49:48 --> Config Class Initialized
INFO - 2024-12-11 05:49:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:49:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:49:48 --> Utf8 Class Initialized
INFO - 2024-12-11 05:49:48 --> URI Class Initialized
INFO - 2024-12-11 05:49:48 --> Router Class Initialized
INFO - 2024-12-11 05:49:48 --> Output Class Initialized
INFO - 2024-12-11 05:49:48 --> Security Class Initialized
DEBUG - 2024-12-11 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:49:48 --> CSRF cookie sent
INFO - 2024-12-11 05:49:48 --> Input Class Initialized
INFO - 2024-12-11 05:49:48 --> Language Class Initialized
INFO - 2024-12-11 05:49:48 --> Loader Class Initialized
INFO - 2024-12-11 05:49:48 --> Helper loaded: url_helper
INFO - 2024-12-11 05:49:48 --> Helper loaded: form_helper
INFO - 2024-12-11 05:49:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:49:48 --> Form Validation Class Initialized
INFO - 2024-12-11 05:49:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:49:48 --> Controller Class Initialized
INFO - 2024-12-11 05:49:48 --> Model "User_model" initialized
INFO - 2024-12-11 05:49:48 --> Model "Category_model" initialized
INFO - 2024-12-11 05:49:48 --> Model "Review_model" initialized
INFO - 2024-12-11 05:49:48 --> Model "News_model" initialized
INFO - 2024-12-11 05:49:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:49:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:49:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:49:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/minuman.php
INFO - 2024-12-11 05:49:48 --> Final output sent to browser
DEBUG - 2024-12-11 05:49:48 --> Total execution time: 0.0576
INFO - 2024-12-11 05:52:45 --> Config Class Initialized
INFO - 2024-12-11 05:52:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:52:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:52:45 --> Utf8 Class Initialized
INFO - 2024-12-11 05:52:45 --> URI Class Initialized
INFO - 2024-12-11 05:52:45 --> Router Class Initialized
INFO - 2024-12-11 05:52:45 --> Output Class Initialized
INFO - 2024-12-11 05:52:45 --> Security Class Initialized
DEBUG - 2024-12-11 05:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:52:45 --> CSRF cookie sent
INFO - 2024-12-11 05:52:45 --> Input Class Initialized
INFO - 2024-12-11 05:52:45 --> Language Class Initialized
INFO - 2024-12-11 05:52:45 --> Loader Class Initialized
INFO - 2024-12-11 05:52:45 --> Helper loaded: url_helper
INFO - 2024-12-11 05:52:45 --> Helper loaded: form_helper
INFO - 2024-12-11 05:52:45 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:52:45 --> Form Validation Class Initialized
INFO - 2024-12-11 05:52:45 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:52:45 --> Controller Class Initialized
INFO - 2024-12-11 05:52:45 --> Model "User_model" initialized
INFO - 2024-12-11 05:52:45 --> Model "Category_model" initialized
INFO - 2024-12-11 05:52:45 --> Model "Review_model" initialized
INFO - 2024-12-11 05:52:45 --> Model "News_model" initialized
INFO - 2024-12-11 05:52:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:52:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:52:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:52:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/minuman.php
INFO - 2024-12-11 05:52:45 --> Final output sent to browser
DEBUG - 2024-12-11 05:52:45 --> Total execution time: 0.0897
INFO - 2024-12-11 05:52:47 --> Config Class Initialized
INFO - 2024-12-11 05:52:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:52:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:52:47 --> Utf8 Class Initialized
INFO - 2024-12-11 05:52:47 --> URI Class Initialized
INFO - 2024-12-11 05:52:47 --> Router Class Initialized
INFO - 2024-12-11 05:52:47 --> Output Class Initialized
INFO - 2024-12-11 05:52:47 --> Security Class Initialized
DEBUG - 2024-12-11 05:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:52:47 --> CSRF cookie sent
INFO - 2024-12-11 05:52:47 --> Input Class Initialized
INFO - 2024-12-11 05:52:47 --> Language Class Initialized
INFO - 2024-12-11 05:52:47 --> Loader Class Initialized
INFO - 2024-12-11 05:52:47 --> Helper loaded: url_helper
INFO - 2024-12-11 05:52:47 --> Helper loaded: form_helper
INFO - 2024-12-11 05:52:47 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:52:47 --> Form Validation Class Initialized
INFO - 2024-12-11 05:52:47 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:52:47 --> Controller Class Initialized
INFO - 2024-12-11 05:52:47 --> Model "User_model" initialized
INFO - 2024-12-11 05:52:47 --> Model "Category_model" initialized
INFO - 2024-12-11 05:52:47 --> Model "Review_model" initialized
INFO - 2024-12-11 05:52:47 --> Model "News_model" initialized
INFO - 2024-12-11 05:52:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:52:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:52:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:52:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:52:47 --> Final output sent to browser
DEBUG - 2024-12-11 05:52:47 --> Total execution time: 0.0567
INFO - 2024-12-11 05:54:54 --> Config Class Initialized
INFO - 2024-12-11 05:54:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:54:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:54:54 --> Utf8 Class Initialized
INFO - 2024-12-11 05:54:54 --> URI Class Initialized
INFO - 2024-12-11 05:54:54 --> Router Class Initialized
INFO - 2024-12-11 05:54:54 --> Output Class Initialized
INFO - 2024-12-11 05:54:54 --> Security Class Initialized
DEBUG - 2024-12-11 05:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:54:54 --> CSRF cookie sent
INFO - 2024-12-11 05:54:54 --> Input Class Initialized
INFO - 2024-12-11 05:54:54 --> Language Class Initialized
INFO - 2024-12-11 05:54:54 --> Loader Class Initialized
INFO - 2024-12-11 05:54:54 --> Helper loaded: url_helper
INFO - 2024-12-11 05:54:54 --> Helper loaded: form_helper
INFO - 2024-12-11 05:54:54 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:54:54 --> Form Validation Class Initialized
INFO - 2024-12-11 05:54:54 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:54:54 --> Controller Class Initialized
INFO - 2024-12-11 05:54:54 --> Model "User_model" initialized
INFO - 2024-12-11 05:54:54 --> Model "Category_model" initialized
INFO - 2024-12-11 05:54:54 --> Model "Review_model" initialized
INFO - 2024-12-11 05:54:54 --> Model "News_model" initialized
INFO - 2024-12-11 05:54:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:54:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:54:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:54:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:54:54 --> Final output sent to browser
DEBUG - 2024-12-11 05:54:54 --> Total execution time: 0.0438
INFO - 2024-12-11 05:55:06 --> Config Class Initialized
INFO - 2024-12-11 05:55:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:55:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:55:06 --> Utf8 Class Initialized
INFO - 2024-12-11 05:55:06 --> URI Class Initialized
INFO - 2024-12-11 05:55:06 --> Router Class Initialized
INFO - 2024-12-11 05:55:06 --> Output Class Initialized
INFO - 2024-12-11 05:55:06 --> Security Class Initialized
DEBUG - 2024-12-11 05:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:55:06 --> CSRF cookie sent
INFO - 2024-12-11 05:55:06 --> Input Class Initialized
INFO - 2024-12-11 05:55:06 --> Language Class Initialized
INFO - 2024-12-11 05:55:06 --> Loader Class Initialized
INFO - 2024-12-11 05:55:06 --> Helper loaded: url_helper
INFO - 2024-12-11 05:55:06 --> Helper loaded: form_helper
INFO - 2024-12-11 05:55:06 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:55:06 --> Form Validation Class Initialized
INFO - 2024-12-11 05:55:06 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:55:06 --> Controller Class Initialized
INFO - 2024-12-11 05:55:06 --> Model "User_model" initialized
INFO - 2024-12-11 05:55:06 --> Model "Category_model" initialized
INFO - 2024-12-11 05:55:06 --> Model "Review_model" initialized
INFO - 2024-12-11 05:55:06 --> Model "News_model" initialized
INFO - 2024-12-11 05:55:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:55:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:55:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:55:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 05:55:06 --> Final output sent to browser
DEBUG - 2024-12-11 05:55:06 --> Total execution time: 0.0480
INFO - 2024-12-11 05:55:08 --> Config Class Initialized
INFO - 2024-12-11 05:55:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:55:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:55:08 --> Utf8 Class Initialized
INFO - 2024-12-11 05:55:08 --> URI Class Initialized
INFO - 2024-12-11 05:55:08 --> Router Class Initialized
INFO - 2024-12-11 05:55:08 --> Output Class Initialized
INFO - 2024-12-11 05:55:08 --> Security Class Initialized
DEBUG - 2024-12-11 05:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:55:08 --> CSRF cookie sent
INFO - 2024-12-11 05:55:08 --> Input Class Initialized
INFO - 2024-12-11 05:55:08 --> Language Class Initialized
INFO - 2024-12-11 05:55:08 --> Loader Class Initialized
INFO - 2024-12-11 05:55:08 --> Helper loaded: url_helper
INFO - 2024-12-11 05:55:08 --> Helper loaded: form_helper
INFO - 2024-12-11 05:55:08 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:55:08 --> Form Validation Class Initialized
INFO - 2024-12-11 05:55:08 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:55:08 --> Controller Class Initialized
INFO - 2024-12-11 05:55:08 --> Model "User_model" initialized
INFO - 2024-12-11 05:55:08 --> Model "Category_model" initialized
INFO - 2024-12-11 05:55:08 --> Model "Review_model" initialized
INFO - 2024-12-11 05:55:08 --> Model "News_model" initialized
INFO - 2024-12-11 05:55:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:55:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:55:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:55:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 05:55:08 --> Final output sent to browser
DEBUG - 2024-12-11 05:55:08 --> Total execution time: 0.0698
INFO - 2024-12-11 05:55:12 --> Config Class Initialized
INFO - 2024-12-11 05:55:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:55:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:55:12 --> Utf8 Class Initialized
INFO - 2024-12-11 05:55:12 --> URI Class Initialized
INFO - 2024-12-11 05:55:12 --> Router Class Initialized
INFO - 2024-12-11 05:55:12 --> Output Class Initialized
INFO - 2024-12-11 05:55:12 --> Security Class Initialized
DEBUG - 2024-12-11 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:55:12 --> CSRF cookie sent
INFO - 2024-12-11 05:55:12 --> Input Class Initialized
INFO - 2024-12-11 05:55:12 --> Language Class Initialized
INFO - 2024-12-11 05:55:12 --> Loader Class Initialized
INFO - 2024-12-11 05:55:12 --> Helper loaded: url_helper
INFO - 2024-12-11 05:55:12 --> Helper loaded: form_helper
INFO - 2024-12-11 05:55:12 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:55:12 --> Form Validation Class Initialized
INFO - 2024-12-11 05:55:12 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:55:12 --> Controller Class Initialized
INFO - 2024-12-11 05:55:12 --> Model "User_model" initialized
INFO - 2024-12-11 05:55:12 --> Model "Category_model" initialized
INFO - 2024-12-11 05:55:12 --> Model "Review_model" initialized
INFO - 2024-12-11 05:55:12 --> Model "News_model" initialized
INFO - 2024-12-11 05:55:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:55:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:55:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:55:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:55:12 --> Final output sent to browser
DEBUG - 2024-12-11 05:55:12 --> Total execution time: 0.0471
INFO - 2024-12-11 05:55:14 --> Config Class Initialized
INFO - 2024-12-11 05:55:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:55:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:55:14 --> Utf8 Class Initialized
INFO - 2024-12-11 05:55:14 --> URI Class Initialized
INFO - 2024-12-11 05:55:14 --> Router Class Initialized
INFO - 2024-12-11 05:55:14 --> Output Class Initialized
INFO - 2024-12-11 05:55:14 --> Security Class Initialized
DEBUG - 2024-12-11 05:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:55:14 --> CSRF cookie sent
INFO - 2024-12-11 05:55:14 --> Input Class Initialized
INFO - 2024-12-11 05:55:14 --> Language Class Initialized
INFO - 2024-12-11 05:55:14 --> Loader Class Initialized
INFO - 2024-12-11 05:55:14 --> Helper loaded: url_helper
INFO - 2024-12-11 05:55:14 --> Helper loaded: form_helper
INFO - 2024-12-11 05:55:14 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:55:14 --> Form Validation Class Initialized
INFO - 2024-12-11 05:55:14 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:55:14 --> Controller Class Initialized
INFO - 2024-12-11 05:55:14 --> Model "User_model" initialized
INFO - 2024-12-11 05:55:14 --> Model "Category_model" initialized
INFO - 2024-12-11 05:55:14 --> Model "Review_model" initialized
INFO - 2024-12-11 05:55:14 --> Model "News_model" initialized
INFO - 2024-12-11 05:55:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 05:55:14 --> Query result: stdClass Object
(
    [view_count] => 131
)

INFO - 2024-12-11 05:55:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:55:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:55:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 05:55:14 --> Final output sent to browser
DEBUG - 2024-12-11 05:55:14 --> Total execution time: 0.0485
INFO - 2024-12-11 05:55:14 --> Config Class Initialized
INFO - 2024-12-11 05:55:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:55:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:55:14 --> Utf8 Class Initialized
INFO - 2024-12-11 05:55:14 --> URI Class Initialized
INFO - 2024-12-11 05:55:14 --> Router Class Initialized
INFO - 2024-12-11 05:55:14 --> Output Class Initialized
INFO - 2024-12-11 05:55:14 --> Security Class Initialized
DEBUG - 2024-12-11 05:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:55:14 --> CSRF cookie sent
INFO - 2024-12-11 05:55:14 --> Input Class Initialized
INFO - 2024-12-11 05:55:14 --> Language Class Initialized
ERROR - 2024-12-11 05:55:14 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 05:55:41 --> Config Class Initialized
INFO - 2024-12-11 05:55:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 05:55:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 05:55:41 --> Utf8 Class Initialized
INFO - 2024-12-11 05:55:41 --> URI Class Initialized
INFO - 2024-12-11 05:55:41 --> Router Class Initialized
INFO - 2024-12-11 05:55:41 --> Output Class Initialized
INFO - 2024-12-11 05:55:41 --> Security Class Initialized
DEBUG - 2024-12-11 05:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 05:55:41 --> CSRF cookie sent
INFO - 2024-12-11 05:55:41 --> Input Class Initialized
INFO - 2024-12-11 05:55:41 --> Language Class Initialized
INFO - 2024-12-11 05:55:41 --> Loader Class Initialized
INFO - 2024-12-11 05:55:41 --> Helper loaded: url_helper
INFO - 2024-12-11 05:55:41 --> Helper loaded: form_helper
INFO - 2024-12-11 05:55:41 --> Database Driver Class Initialized
DEBUG - 2024-12-11 05:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 05:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 05:55:41 --> Form Validation Class Initialized
INFO - 2024-12-11 05:55:41 --> Model "Culinary_model" initialized
INFO - 2024-12-11 05:55:41 --> Controller Class Initialized
INFO - 2024-12-11 05:55:41 --> Model "User_model" initialized
INFO - 2024-12-11 05:55:41 --> Model "Category_model" initialized
INFO - 2024-12-11 05:55:41 --> Model "Review_model" initialized
INFO - 2024-12-11 05:55:41 --> Model "News_model" initialized
INFO - 2024-12-11 05:55:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 05:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 05:55:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 05:55:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 05:55:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 05:55:41 --> Final output sent to browser
DEBUG - 2024-12-11 05:55:41 --> Total execution time: 0.0665
INFO - 2024-12-11 06:06:21 --> Config Class Initialized
INFO - 2024-12-11 06:06:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:06:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:06:21 --> Utf8 Class Initialized
INFO - 2024-12-11 06:06:21 --> URI Class Initialized
INFO - 2024-12-11 06:06:21 --> Router Class Initialized
INFO - 2024-12-11 06:06:21 --> Output Class Initialized
INFO - 2024-12-11 06:06:21 --> Security Class Initialized
DEBUG - 2024-12-11 06:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:06:21 --> CSRF cookie sent
INFO - 2024-12-11 06:06:21 --> Input Class Initialized
INFO - 2024-12-11 06:06:21 --> Language Class Initialized
INFO - 2024-12-11 06:06:21 --> Loader Class Initialized
INFO - 2024-12-11 06:06:21 --> Helper loaded: url_helper
INFO - 2024-12-11 06:06:21 --> Helper loaded: form_helper
INFO - 2024-12-11 06:06:21 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:06:21 --> Form Validation Class Initialized
INFO - 2024-12-11 06:06:21 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:06:21 --> Controller Class Initialized
INFO - 2024-12-11 06:06:21 --> Model "User_model" initialized
INFO - 2024-12-11 06:06:21 --> Model "Category_model" initialized
INFO - 2024-12-11 06:06:21 --> Model "Review_model" initialized
INFO - 2024-12-11 06:06:21 --> Model "News_model" initialized
INFO - 2024-12-11 06:06:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 06:06:21 --> Query result: stdClass Object
(
    [view_count] => 132
)

INFO - 2024-12-11 06:06:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 06:06:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 06:06:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 06:06:21 --> Final output sent to browser
DEBUG - 2024-12-11 06:06:21 --> Total execution time: 0.0995
INFO - 2024-12-11 06:06:21 --> Config Class Initialized
INFO - 2024-12-11 06:06:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:06:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:06:21 --> Utf8 Class Initialized
INFO - 2024-12-11 06:06:21 --> URI Class Initialized
INFO - 2024-12-11 06:06:21 --> Router Class Initialized
INFO - 2024-12-11 06:06:21 --> Output Class Initialized
INFO - 2024-12-11 06:06:21 --> Security Class Initialized
DEBUG - 2024-12-11 06:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:06:21 --> CSRF cookie sent
INFO - 2024-12-11 06:06:21 --> Input Class Initialized
INFO - 2024-12-11 06:06:21 --> Language Class Initialized
ERROR - 2024-12-11 06:06:21 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 06:06:26 --> Config Class Initialized
INFO - 2024-12-11 06:06:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:06:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:06:26 --> Utf8 Class Initialized
INFO - 2024-12-11 06:06:26 --> URI Class Initialized
INFO - 2024-12-11 06:06:26 --> Router Class Initialized
INFO - 2024-12-11 06:06:26 --> Output Class Initialized
INFO - 2024-12-11 06:06:26 --> Security Class Initialized
DEBUG - 2024-12-11 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:06:26 --> CSRF cookie sent
INFO - 2024-12-11 06:06:26 --> Input Class Initialized
INFO - 2024-12-11 06:06:26 --> Language Class Initialized
INFO - 2024-12-11 06:06:26 --> Loader Class Initialized
INFO - 2024-12-11 06:06:26 --> Helper loaded: url_helper
INFO - 2024-12-11 06:06:26 --> Helper loaded: form_helper
INFO - 2024-12-11 06:06:26 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:06:26 --> Form Validation Class Initialized
INFO - 2024-12-11 06:06:26 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:06:26 --> Controller Class Initialized
INFO - 2024-12-11 06:06:26 --> Model "Review_model" initialized
INFO - 2024-12-11 06:06:26 --> Model "Category_model" initialized
INFO - 2024-12-11 06:06:26 --> Model "User_model" initialized
INFO - 2024-12-11 06:06:26 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 06:06:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 06:06:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 06:06:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 06:06:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-11 06:06:26 --> Final output sent to browser
DEBUG - 2024-12-11 06:06:26 --> Total execution time: 0.1086
INFO - 2024-12-11 06:06:31 --> Config Class Initialized
INFO - 2024-12-11 06:06:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:06:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:06:31 --> Utf8 Class Initialized
INFO - 2024-12-11 06:06:31 --> URI Class Initialized
INFO - 2024-12-11 06:06:31 --> Router Class Initialized
INFO - 2024-12-11 06:06:31 --> Output Class Initialized
INFO - 2024-12-11 06:06:31 --> Security Class Initialized
DEBUG - 2024-12-11 06:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:06:31 --> CSRF cookie sent
INFO - 2024-12-11 06:06:31 --> CSRF token verified
INFO - 2024-12-11 06:06:31 --> Input Class Initialized
INFO - 2024-12-11 06:06:31 --> Language Class Initialized
INFO - 2024-12-11 06:06:31 --> Loader Class Initialized
INFO - 2024-12-11 06:06:31 --> Helper loaded: url_helper
INFO - 2024-12-11 06:06:31 --> Helper loaded: form_helper
INFO - 2024-12-11 06:06:31 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:06:31 --> Form Validation Class Initialized
INFO - 2024-12-11 06:06:31 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:06:31 --> Controller Class Initialized
INFO - 2024-12-11 06:06:31 --> Model "User_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "Category_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "Review_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "News_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 06:06:31 --> Config Class Initialized
INFO - 2024-12-11 06:06:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:06:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:06:31 --> Utf8 Class Initialized
INFO - 2024-12-11 06:06:31 --> URI Class Initialized
INFO - 2024-12-11 06:06:31 --> Router Class Initialized
INFO - 2024-12-11 06:06:31 --> Output Class Initialized
INFO - 2024-12-11 06:06:31 --> Security Class Initialized
DEBUG - 2024-12-11 06:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:06:31 --> CSRF cookie sent
INFO - 2024-12-11 06:06:31 --> Input Class Initialized
INFO - 2024-12-11 06:06:31 --> Language Class Initialized
INFO - 2024-12-11 06:06:31 --> Loader Class Initialized
INFO - 2024-12-11 06:06:31 --> Helper loaded: url_helper
INFO - 2024-12-11 06:06:31 --> Helper loaded: form_helper
INFO - 2024-12-11 06:06:31 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:06:31 --> Form Validation Class Initialized
INFO - 2024-12-11 06:06:31 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:06:31 --> Controller Class Initialized
INFO - 2024-12-11 06:06:31 --> Model "Review_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "Category_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "User_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 06:06:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 06:06:31 --> Query result: stdClass Object
(
    [view_count] => 132
)

INFO - 2024-12-11 06:06:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-11 06:06:31 --> Final output sent to browser
DEBUG - 2024-12-11 06:06:31 --> Total execution time: 0.0610
INFO - 2024-12-11 06:06:35 --> Config Class Initialized
INFO - 2024-12-11 06:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:06:35 --> Utf8 Class Initialized
INFO - 2024-12-11 06:06:35 --> URI Class Initialized
INFO - 2024-12-11 06:06:35 --> Router Class Initialized
INFO - 2024-12-11 06:06:35 --> Output Class Initialized
INFO - 2024-12-11 06:06:35 --> Security Class Initialized
DEBUG - 2024-12-11 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:06:35 --> CSRF cookie sent
INFO - 2024-12-11 06:06:35 --> Input Class Initialized
INFO - 2024-12-11 06:06:35 --> Language Class Initialized
INFO - 2024-12-11 06:06:35 --> Loader Class Initialized
INFO - 2024-12-11 06:06:35 --> Helper loaded: url_helper
INFO - 2024-12-11 06:06:35 --> Helper loaded: form_helper
INFO - 2024-12-11 06:06:35 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:06:35 --> Form Validation Class Initialized
INFO - 2024-12-11 06:06:35 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:06:35 --> Controller Class Initialized
INFO - 2024-12-11 06:06:35 --> Model "Review_model" initialized
INFO - 2024-12-11 06:06:35 --> Model "Category_model" initialized
INFO - 2024-12-11 06:06:35 --> Model "User_model" initialized
INFO - 2024-12-11 06:06:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 06:06:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 06:06:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-11 06:06:35 --> Final output sent to browser
DEBUG - 2024-12-11 06:06:35 --> Total execution time: 0.0496
INFO - 2024-12-11 06:07:16 --> Config Class Initialized
INFO - 2024-12-11 06:07:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:07:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:07:16 --> Utf8 Class Initialized
INFO - 2024-12-11 06:07:16 --> URI Class Initialized
INFO - 2024-12-11 06:07:16 --> Router Class Initialized
INFO - 2024-12-11 06:07:16 --> Output Class Initialized
INFO - 2024-12-11 06:07:16 --> Security Class Initialized
DEBUG - 2024-12-11 06:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:07:16 --> CSRF cookie sent
INFO - 2024-12-11 06:07:16 --> Input Class Initialized
INFO - 2024-12-11 06:07:16 --> Language Class Initialized
INFO - 2024-12-11 06:07:16 --> Loader Class Initialized
INFO - 2024-12-11 06:07:16 --> Helper loaded: url_helper
INFO - 2024-12-11 06:07:16 --> Helper loaded: form_helper
INFO - 2024-12-11 06:07:16 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:07:16 --> Form Validation Class Initialized
INFO - 2024-12-11 06:07:16 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:07:16 --> Controller Class Initialized
INFO - 2024-12-11 06:07:16 --> Model "Review_model" initialized
INFO - 2024-12-11 06:07:16 --> Model "Category_model" initialized
INFO - 2024-12-11 06:07:16 --> Model "User_model" initialized
INFO - 2024-12-11 06:07:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 06:07:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 06:07:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-11 06:07:16 --> Final output sent to browser
DEBUG - 2024-12-11 06:07:16 --> Total execution time: 0.0546
INFO - 2024-12-11 06:07:25 --> Config Class Initialized
INFO - 2024-12-11 06:07:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 06:07:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 06:07:25 --> Utf8 Class Initialized
INFO - 2024-12-11 06:07:25 --> URI Class Initialized
INFO - 2024-12-11 06:07:25 --> Router Class Initialized
INFO - 2024-12-11 06:07:25 --> Output Class Initialized
INFO - 2024-12-11 06:07:25 --> Security Class Initialized
DEBUG - 2024-12-11 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 06:07:25 --> CSRF cookie sent
INFO - 2024-12-11 06:07:25 --> Input Class Initialized
INFO - 2024-12-11 06:07:25 --> Language Class Initialized
INFO - 2024-12-11 06:07:25 --> Loader Class Initialized
INFO - 2024-12-11 06:07:25 --> Helper loaded: url_helper
INFO - 2024-12-11 06:07:25 --> Helper loaded: form_helper
INFO - 2024-12-11 06:07:25 --> Database Driver Class Initialized
DEBUG - 2024-12-11 06:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 06:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 06:07:25 --> Form Validation Class Initialized
INFO - 2024-12-11 06:07:25 --> Model "Culinary_model" initialized
INFO - 2024-12-11 06:07:25 --> Controller Class Initialized
INFO - 2024-12-11 06:07:25 --> Model "Review_model" initialized
INFO - 2024-12-11 06:07:25 --> Model "Category_model" initialized
INFO - 2024-12-11 06:07:25 --> Model "User_model" initialized
INFO - 2024-12-11 06:07:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 06:07:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 06:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 06:07:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 06:07:25 --> Final output sent to browser
DEBUG - 2024-12-11 06:07:25 --> Total execution time: 0.0544
INFO - 2024-12-11 15:13:44 --> Config Class Initialized
INFO - 2024-12-11 15:13:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:13:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:13:44 --> Utf8 Class Initialized
INFO - 2024-12-11 15:13:45 --> URI Class Initialized
INFO - 2024-12-11 15:13:45 --> Router Class Initialized
INFO - 2024-12-11 15:13:45 --> Output Class Initialized
INFO - 2024-12-11 15:13:45 --> Security Class Initialized
DEBUG - 2024-12-11 15:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:13:45 --> CSRF cookie sent
INFO - 2024-12-11 15:13:45 --> Input Class Initialized
INFO - 2024-12-11 15:13:45 --> Language Class Initialized
INFO - 2024-12-11 15:13:45 --> Loader Class Initialized
INFO - 2024-12-11 15:13:45 --> Helper loaded: url_helper
INFO - 2024-12-11 15:13:45 --> Helper loaded: form_helper
INFO - 2024-12-11 15:13:45 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:13:45 --> Form Validation Class Initialized
INFO - 2024-12-11 15:13:45 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:13:45 --> Controller Class Initialized
INFO - 2024-12-11 15:13:45 --> Model "User_model" initialized
INFO - 2024-12-11 15:13:45 --> Model "Category_model" initialized
INFO - 2024-12-11 15:13:45 --> Model "Review_model" initialized
INFO - 2024-12-11 15:13:45 --> Model "News_model" initialized
INFO - 2024-12-11 15:13:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:13:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:13:45 --> Query result: stdClass Object
(
    [view_count] => 133
)

INFO - 2024-12-11 15:13:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:13:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:13:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:13:45 --> Final output sent to browser
DEBUG - 2024-12-11 15:13:45 --> Total execution time: 0.7806
INFO - 2024-12-11 15:14:48 --> Config Class Initialized
INFO - 2024-12-11 15:14:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:14:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:14:48 --> Utf8 Class Initialized
INFO - 2024-12-11 15:14:48 --> URI Class Initialized
INFO - 2024-12-11 15:14:48 --> Router Class Initialized
INFO - 2024-12-11 15:14:48 --> Output Class Initialized
INFO - 2024-12-11 15:14:48 --> Security Class Initialized
DEBUG - 2024-12-11 15:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:14:48 --> CSRF cookie sent
INFO - 2024-12-11 15:14:48 --> Input Class Initialized
INFO - 2024-12-11 15:14:48 --> Language Class Initialized
INFO - 2024-12-11 15:14:48 --> Loader Class Initialized
INFO - 2024-12-11 15:14:48 --> Helper loaded: url_helper
INFO - 2024-12-11 15:14:48 --> Helper loaded: form_helper
INFO - 2024-12-11 15:14:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:14:48 --> Form Validation Class Initialized
INFO - 2024-12-11 15:14:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:14:48 --> Controller Class Initialized
INFO - 2024-12-11 15:14:48 --> Model "User_model" initialized
INFO - 2024-12-11 15:14:48 --> Model "Category_model" initialized
INFO - 2024-12-11 15:14:48 --> Model "Review_model" initialized
INFO - 2024-12-11 15:14:48 --> Model "News_model" initialized
INFO - 2024-12-11 15:14:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:14:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:14:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:14:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 15:14:48 --> Final output sent to browser
DEBUG - 2024-12-11 15:14:48 --> Total execution time: 0.2909
INFO - 2024-12-11 15:26:48 --> Config Class Initialized
INFO - 2024-12-11 15:26:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:26:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:26:48 --> Utf8 Class Initialized
INFO - 2024-12-11 15:26:48 --> URI Class Initialized
INFO - 2024-12-11 15:26:48 --> Router Class Initialized
INFO - 2024-12-11 15:26:48 --> Output Class Initialized
INFO - 2024-12-11 15:26:48 --> Security Class Initialized
DEBUG - 2024-12-11 15:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:26:48 --> CSRF cookie sent
INFO - 2024-12-11 15:26:48 --> Input Class Initialized
INFO - 2024-12-11 15:26:48 --> Language Class Initialized
INFO - 2024-12-11 15:26:48 --> Loader Class Initialized
INFO - 2024-12-11 15:26:48 --> Helper loaded: url_helper
INFO - 2024-12-11 15:26:48 --> Helper loaded: form_helper
INFO - 2024-12-11 15:26:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:26:48 --> Form Validation Class Initialized
INFO - 2024-12-11 15:26:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:26:48 --> Controller Class Initialized
INFO - 2024-12-11 15:26:48 --> Model "User_model" initialized
INFO - 2024-12-11 15:26:48 --> Model "Category_model" initialized
INFO - 2024-12-11 15:26:48 --> Model "Review_model" initialized
INFO - 2024-12-11 15:26:48 --> Model "News_model" initialized
INFO - 2024-12-11 15:26:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:26:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:26:48 --> Query result: stdClass Object
(
    [view_count] => 134
)

INFO - 2024-12-11 15:26:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:26:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:26:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:26:48 --> Final output sent to browser
DEBUG - 2024-12-11 15:26:48 --> Total execution time: 0.1315
INFO - 2024-12-11 15:26:52 --> Config Class Initialized
INFO - 2024-12-11 15:26:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:26:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:26:52 --> Utf8 Class Initialized
INFO - 2024-12-11 15:26:52 --> URI Class Initialized
INFO - 2024-12-11 15:26:52 --> Router Class Initialized
INFO - 2024-12-11 15:26:52 --> Output Class Initialized
INFO - 2024-12-11 15:26:52 --> Security Class Initialized
DEBUG - 2024-12-11 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:26:52 --> CSRF cookie sent
INFO - 2024-12-11 15:26:52 --> Input Class Initialized
INFO - 2024-12-11 15:26:52 --> Language Class Initialized
INFO - 2024-12-11 15:26:52 --> Loader Class Initialized
INFO - 2024-12-11 15:26:52 --> Helper loaded: url_helper
INFO - 2024-12-11 15:26:52 --> Helper loaded: form_helper
INFO - 2024-12-11 15:26:52 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:26:52 --> Form Validation Class Initialized
INFO - 2024-12-11 15:26:52 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:26:52 --> Controller Class Initialized
INFO - 2024-12-11 15:26:52 --> Model "User_model" initialized
INFO - 2024-12-11 15:26:52 --> Model "Category_model" initialized
INFO - 2024-12-11 15:26:52 --> Model "Review_model" initialized
INFO - 2024-12-11 15:26:52 --> Model "News_model" initialized
INFO - 2024-12-11 15:26:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:26:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:26:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:26:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 15:26:52 --> Final output sent to browser
DEBUG - 2024-12-11 15:26:52 --> Total execution time: 0.0987
INFO - 2024-12-11 15:26:56 --> Config Class Initialized
INFO - 2024-12-11 15:26:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:26:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:26:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:26:56 --> URI Class Initialized
INFO - 2024-12-11 15:26:56 --> Router Class Initialized
INFO - 2024-12-11 15:26:56 --> Output Class Initialized
INFO - 2024-12-11 15:26:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:26:56 --> CSRF cookie sent
INFO - 2024-12-11 15:26:56 --> CSRF token verified
INFO - 2024-12-11 15:26:56 --> Input Class Initialized
INFO - 2024-12-11 15:26:56 --> Language Class Initialized
INFO - 2024-12-11 15:26:56 --> Loader Class Initialized
INFO - 2024-12-11 15:26:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:26:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:26:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:26:56 --> Form Validation Class Initialized
INFO - 2024-12-11 15:26:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:26:56 --> Controller Class Initialized
INFO - 2024-12-11 15:26:56 --> Model "User_model" initialized
INFO - 2024-12-11 15:26:56 --> Model "Category_model" initialized
INFO - 2024-12-11 15:26:56 --> Model "Review_model" initialized
INFO - 2024-12-11 15:26:56 --> Model "News_model" initialized
INFO - 2024-12-11 15:26:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:26:57 --> Config Class Initialized
INFO - 2024-12-11 15:26:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:26:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:26:57 --> Utf8 Class Initialized
INFO - 2024-12-11 15:26:57 --> URI Class Initialized
INFO - 2024-12-11 15:26:57 --> Router Class Initialized
INFO - 2024-12-11 15:26:57 --> Output Class Initialized
INFO - 2024-12-11 15:26:57 --> Security Class Initialized
DEBUG - 2024-12-11 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:26:57 --> CSRF cookie sent
INFO - 2024-12-11 15:26:57 --> Input Class Initialized
INFO - 2024-12-11 15:26:57 --> Language Class Initialized
INFO - 2024-12-11 15:26:57 --> Loader Class Initialized
INFO - 2024-12-11 15:26:57 --> Helper loaded: url_helper
INFO - 2024-12-11 15:26:57 --> Helper loaded: form_helper
INFO - 2024-12-11 15:26:57 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:26:57 --> Form Validation Class Initialized
INFO - 2024-12-11 15:26:57 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:26:57 --> Controller Class Initialized
INFO - 2024-12-11 15:26:57 --> Model "User_model" initialized
INFO - 2024-12-11 15:26:57 --> Model "Category_model" initialized
INFO - 2024-12-11 15:26:57 --> Model "Review_model" initialized
INFO - 2024-12-11 15:26:57 --> Model "News_model" initialized
INFO - 2024-12-11 15:26:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:26:57 --> Query result: stdClass Object
(
    [view_count] => 135
)

INFO - 2024-12-11 15:26:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:26:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:26:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:26:57 --> Final output sent to browser
DEBUG - 2024-12-11 15:26:57 --> Total execution time: 0.0674
INFO - 2024-12-11 15:26:57 --> Config Class Initialized
INFO - 2024-12-11 15:26:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:26:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:26:57 --> Utf8 Class Initialized
INFO - 2024-12-11 15:26:57 --> URI Class Initialized
INFO - 2024-12-11 15:26:57 --> Router Class Initialized
INFO - 2024-12-11 15:26:57 --> Output Class Initialized
INFO - 2024-12-11 15:26:57 --> Security Class Initialized
DEBUG - 2024-12-11 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:26:57 --> CSRF cookie sent
INFO - 2024-12-11 15:26:57 --> Input Class Initialized
INFO - 2024-12-11 15:26:57 --> Language Class Initialized
ERROR - 2024-12-11 15:26:57 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 15:26:59 --> Config Class Initialized
INFO - 2024-12-11 15:26:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:26:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:26:59 --> Utf8 Class Initialized
INFO - 2024-12-11 15:26:59 --> URI Class Initialized
INFO - 2024-12-11 15:26:59 --> Router Class Initialized
INFO - 2024-12-11 15:26:59 --> Output Class Initialized
INFO - 2024-12-11 15:26:59 --> Security Class Initialized
DEBUG - 2024-12-11 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:26:59 --> CSRF cookie sent
INFO - 2024-12-11 15:26:59 --> Input Class Initialized
INFO - 2024-12-11 15:26:59 --> Language Class Initialized
INFO - 2024-12-11 15:26:59 --> Loader Class Initialized
INFO - 2024-12-11 15:26:59 --> Helper loaded: url_helper
INFO - 2024-12-11 15:26:59 --> Helper loaded: form_helper
INFO - 2024-12-11 15:26:59 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:26:59 --> Form Validation Class Initialized
INFO - 2024-12-11 15:26:59 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:26:59 --> Controller Class Initialized
INFO - 2024-12-11 15:26:59 --> Model "User_model" initialized
INFO - 2024-12-11 15:26:59 --> Model "Category_model" initialized
INFO - 2024-12-11 15:26:59 --> Model "Review_model" initialized
INFO - 2024-12-11 15:26:59 --> Model "News_model" initialized
INFO - 2024-12-11 15:26:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:26:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:26:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:26:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:26:59 --> Final output sent to browser
DEBUG - 2024-12-11 15:26:59 --> Total execution time: 0.1178
INFO - 2024-12-11 15:27:17 --> Config Class Initialized
INFO - 2024-12-11 15:27:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:17 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:17 --> URI Class Initialized
INFO - 2024-12-11 15:27:17 --> Router Class Initialized
INFO - 2024-12-11 15:27:17 --> Output Class Initialized
INFO - 2024-12-11 15:27:17 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:17 --> CSRF cookie sent
INFO - 2024-12-11 15:27:17 --> Input Class Initialized
INFO - 2024-12-11 15:27:17 --> Language Class Initialized
INFO - 2024-12-11 15:27:17 --> Loader Class Initialized
INFO - 2024-12-11 15:27:17 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:17 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:17 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:17 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:17 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:17 --> Controller Class Initialized
INFO - 2024-12-11 15:27:17 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:17 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:17 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:27:17 --> Final output sent to browser
DEBUG - 2024-12-11 15:27:17 --> Total execution time: 0.0881
INFO - 2024-12-11 15:27:24 --> Config Class Initialized
INFO - 2024-12-11 15:27:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:24 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:24 --> URI Class Initialized
INFO - 2024-12-11 15:27:24 --> Router Class Initialized
INFO - 2024-12-11 15:27:24 --> Output Class Initialized
INFO - 2024-12-11 15:27:24 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:24 --> CSRF cookie sent
INFO - 2024-12-11 15:27:24 --> Input Class Initialized
INFO - 2024-12-11 15:27:24 --> Language Class Initialized
INFO - 2024-12-11 15:27:24 --> Loader Class Initialized
INFO - 2024-12-11 15:27:24 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:24 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:24 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:24 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:24 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:24 --> Controller Class Initialized
INFO - 2024-12-11 15:27:24 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:24 --> Config Class Initialized
INFO - 2024-12-11 15:27:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:24 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:24 --> URI Class Initialized
INFO - 2024-12-11 15:27:24 --> Router Class Initialized
INFO - 2024-12-11 15:27:24 --> Output Class Initialized
INFO - 2024-12-11 15:27:24 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:24 --> CSRF cookie sent
INFO - 2024-12-11 15:27:24 --> Input Class Initialized
INFO - 2024-12-11 15:27:24 --> Language Class Initialized
INFO - 2024-12-11 15:27:24 --> Loader Class Initialized
INFO - 2024-12-11 15:27:24 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:24 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:24 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:24 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:24 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:24 --> Controller Class Initialized
INFO - 2024-12-11 15:27:24 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:27:24 --> Final output sent to browser
DEBUG - 2024-12-11 15:27:24 --> Total execution time: 0.0615
INFO - 2024-12-11 15:27:29 --> Config Class Initialized
INFO - 2024-12-11 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:29 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:29 --> URI Class Initialized
INFO - 2024-12-11 15:27:29 --> Router Class Initialized
INFO - 2024-12-11 15:27:29 --> Output Class Initialized
INFO - 2024-12-11 15:27:29 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:29 --> CSRF cookie sent
INFO - 2024-12-11 15:27:29 --> Input Class Initialized
INFO - 2024-12-11 15:27:29 --> Language Class Initialized
INFO - 2024-12-11 15:27:29 --> Loader Class Initialized
INFO - 2024-12-11 15:27:29 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:29 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:29 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:29 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:29 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:29 --> Controller Class Initialized
INFO - 2024-12-11 15:27:29 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:29 --> Config Class Initialized
INFO - 2024-12-11 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:29 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:29 --> URI Class Initialized
INFO - 2024-12-11 15:27:29 --> Router Class Initialized
INFO - 2024-12-11 15:27:29 --> Output Class Initialized
INFO - 2024-12-11 15:27:29 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:29 --> CSRF cookie sent
INFO - 2024-12-11 15:27:29 --> Input Class Initialized
INFO - 2024-12-11 15:27:29 --> Language Class Initialized
INFO - 2024-12-11 15:27:29 --> Loader Class Initialized
INFO - 2024-12-11 15:27:29 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:29 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:29 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:29 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:29 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:29 --> Controller Class Initialized
INFO - 2024-12-11 15:27:29 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:27:29 --> Final output sent to browser
DEBUG - 2024-12-11 15:27:29 --> Total execution time: 0.0565
INFO - 2024-12-11 15:27:33 --> Config Class Initialized
INFO - 2024-12-11 15:27:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:33 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:33 --> URI Class Initialized
INFO - 2024-12-11 15:27:33 --> Router Class Initialized
INFO - 2024-12-11 15:27:33 --> Output Class Initialized
INFO - 2024-12-11 15:27:33 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:33 --> CSRF cookie sent
INFO - 2024-12-11 15:27:33 --> Input Class Initialized
INFO - 2024-12-11 15:27:33 --> Language Class Initialized
INFO - 2024-12-11 15:27:33 --> Loader Class Initialized
INFO - 2024-12-11 15:27:33 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:33 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:33 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:33 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:33 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:33 --> Controller Class Initialized
INFO - 2024-12-11 15:27:33 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:33 --> Config Class Initialized
INFO - 2024-12-11 15:27:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:33 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:33 --> URI Class Initialized
INFO - 2024-12-11 15:27:33 --> Router Class Initialized
INFO - 2024-12-11 15:27:33 --> Output Class Initialized
INFO - 2024-12-11 15:27:33 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:33 --> CSRF cookie sent
INFO - 2024-12-11 15:27:33 --> Input Class Initialized
INFO - 2024-12-11 15:27:33 --> Language Class Initialized
INFO - 2024-12-11 15:27:33 --> Loader Class Initialized
INFO - 2024-12-11 15:27:33 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:33 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:33 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:33 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:33 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:33 --> Controller Class Initialized
INFO - 2024-12-11 15:27:33 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:27:33 --> Final output sent to browser
DEBUG - 2024-12-11 15:27:33 --> Total execution time: 0.0611
INFO - 2024-12-11 15:27:37 --> Config Class Initialized
INFO - 2024-12-11 15:27:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:37 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:37 --> URI Class Initialized
INFO - 2024-12-11 15:27:37 --> Router Class Initialized
INFO - 2024-12-11 15:27:37 --> Output Class Initialized
INFO - 2024-12-11 15:27:37 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:37 --> CSRF cookie sent
INFO - 2024-12-11 15:27:37 --> Input Class Initialized
INFO - 2024-12-11 15:27:37 --> Language Class Initialized
INFO - 2024-12-11 15:27:37 --> Loader Class Initialized
INFO - 2024-12-11 15:27:37 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:37 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:38 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:38 --> Controller Class Initialized
INFO - 2024-12-11 15:27:38 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:38 --> Config Class Initialized
INFO - 2024-12-11 15:27:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:38 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:38 --> URI Class Initialized
INFO - 2024-12-11 15:27:38 --> Router Class Initialized
INFO - 2024-12-11 15:27:38 --> Output Class Initialized
INFO - 2024-12-11 15:27:38 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:38 --> CSRF cookie sent
INFO - 2024-12-11 15:27:38 --> Input Class Initialized
INFO - 2024-12-11 15:27:38 --> Language Class Initialized
INFO - 2024-12-11 15:27:38 --> Loader Class Initialized
INFO - 2024-12-11 15:27:38 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:38 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:38 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:38 --> Controller Class Initialized
INFO - 2024-12-11 15:27:38 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:27:38 --> Final output sent to browser
DEBUG - 2024-12-11 15:27:38 --> Total execution time: 0.0763
INFO - 2024-12-11 15:27:56 --> Config Class Initialized
INFO - 2024-12-11 15:27:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:27:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:27:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:27:56 --> URI Class Initialized
INFO - 2024-12-11 15:27:56 --> Router Class Initialized
INFO - 2024-12-11 15:27:56 --> Output Class Initialized
INFO - 2024-12-11 15:27:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:27:56 --> CSRF cookie sent
INFO - 2024-12-11 15:27:56 --> Input Class Initialized
INFO - 2024-12-11 15:27:56 --> Language Class Initialized
INFO - 2024-12-11 15:27:56 --> Loader Class Initialized
INFO - 2024-12-11 15:27:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:27:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:27:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:27:57 --> Form Validation Class Initialized
INFO - 2024-12-11 15:27:57 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:27:57 --> Controller Class Initialized
INFO - 2024-12-11 15:27:57 --> Model "Review_model" initialized
INFO - 2024-12-11 15:27:57 --> Model "Category_model" initialized
INFO - 2024-12-11 15:27:57 --> Model "User_model" initialized
INFO - 2024-12-11 15:27:57 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:27:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:27:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-11 15:27:57 --> Final output sent to browser
DEBUG - 2024-12-11 15:27:57 --> Total execution time: 0.0619
INFO - 2024-12-11 15:28:04 --> Config Class Initialized
INFO - 2024-12-11 15:28:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:04 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:04 --> URI Class Initialized
INFO - 2024-12-11 15:28:04 --> Router Class Initialized
INFO - 2024-12-11 15:28:04 --> Output Class Initialized
INFO - 2024-12-11 15:28:04 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:04 --> CSRF cookie sent
INFO - 2024-12-11 15:28:04 --> Input Class Initialized
INFO - 2024-12-11 15:28:04 --> Language Class Initialized
INFO - 2024-12-11 15:28:04 --> Loader Class Initialized
INFO - 2024-12-11 15:28:04 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:04 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:04 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:04 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:04 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:04 --> Controller Class Initialized
INFO - 2024-12-11 15:28:04 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:04 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:04 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:04 --> Model "News_model" initialized
INFO - 2024-12-11 15:28:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:28:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:28:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:28:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:28:04 --> Final output sent to browser
DEBUG - 2024-12-11 15:28:04 --> Total execution time: 0.0713
INFO - 2024-12-11 15:28:10 --> Config Class Initialized
INFO - 2024-12-11 15:28:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:10 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:10 --> URI Class Initialized
INFO - 2024-12-11 15:28:10 --> Router Class Initialized
INFO - 2024-12-11 15:28:10 --> Output Class Initialized
INFO - 2024-12-11 15:28:10 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:10 --> CSRF cookie sent
INFO - 2024-12-11 15:28:10 --> Input Class Initialized
INFO - 2024-12-11 15:28:10 --> Language Class Initialized
INFO - 2024-12-11 15:28:10 --> Loader Class Initialized
INFO - 2024-12-11 15:28:10 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:10 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:10 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:11 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:11 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:11 --> Controller Class Initialized
INFO - 2024-12-11 15:28:11 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:11 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:11 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:28:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:28:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:28:11 --> Final output sent to browser
DEBUG - 2024-12-11 15:28:11 --> Total execution time: 0.0562
INFO - 2024-12-11 15:28:20 --> Config Class Initialized
INFO - 2024-12-11 15:28:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:20 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:20 --> URI Class Initialized
INFO - 2024-12-11 15:28:20 --> Router Class Initialized
INFO - 2024-12-11 15:28:20 --> Output Class Initialized
INFO - 2024-12-11 15:28:20 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:20 --> CSRF cookie sent
INFO - 2024-12-11 15:28:20 --> Input Class Initialized
INFO - 2024-12-11 15:28:20 --> Language Class Initialized
INFO - 2024-12-11 15:28:20 --> Loader Class Initialized
INFO - 2024-12-11 15:28:20 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:20 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:20 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:20 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:20 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:20 --> Controller Class Initialized
INFO - 2024-12-11 15:28:20 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "News_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:28:20 --> Config Class Initialized
INFO - 2024-12-11 15:28:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:20 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:20 --> URI Class Initialized
INFO - 2024-12-11 15:28:20 --> Router Class Initialized
INFO - 2024-12-11 15:28:20 --> Output Class Initialized
INFO - 2024-12-11 15:28:20 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:20 --> CSRF cookie sent
INFO - 2024-12-11 15:28:20 --> Input Class Initialized
INFO - 2024-12-11 15:28:20 --> Language Class Initialized
INFO - 2024-12-11 15:28:20 --> Loader Class Initialized
INFO - 2024-12-11 15:28:20 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:20 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:20 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:20 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:20 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:20 --> Controller Class Initialized
INFO - 2024-12-11 15:28:20 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "News_model" initialized
INFO - 2024-12-11 15:28:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:28:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:28:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:28:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 15:28:20 --> Final output sent to browser
DEBUG - 2024-12-11 15:28:20 --> Total execution time: 0.0559
INFO - 2024-12-11 15:28:26 --> Config Class Initialized
INFO - 2024-12-11 15:28:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:26 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:26 --> URI Class Initialized
INFO - 2024-12-11 15:28:26 --> Router Class Initialized
INFO - 2024-12-11 15:28:26 --> Output Class Initialized
INFO - 2024-12-11 15:28:26 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:26 --> CSRF cookie sent
INFO - 2024-12-11 15:28:26 --> CSRF token verified
INFO - 2024-12-11 15:28:26 --> Input Class Initialized
INFO - 2024-12-11 15:28:26 --> Language Class Initialized
INFO - 2024-12-11 15:28:26 --> Loader Class Initialized
INFO - 2024-12-11 15:28:26 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:26 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:26 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:26 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:26 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:26 --> Controller Class Initialized
INFO - 2024-12-11 15:28:26 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "News_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:28:26 --> Config Class Initialized
INFO - 2024-12-11 15:28:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:26 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:26 --> URI Class Initialized
INFO - 2024-12-11 15:28:26 --> Router Class Initialized
INFO - 2024-12-11 15:28:26 --> Output Class Initialized
INFO - 2024-12-11 15:28:26 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:26 --> CSRF cookie sent
INFO - 2024-12-11 15:28:26 --> Input Class Initialized
INFO - 2024-12-11 15:28:26 --> Language Class Initialized
INFO - 2024-12-11 15:28:26 --> Loader Class Initialized
INFO - 2024-12-11 15:28:26 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:26 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:26 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:26 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:26 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:26 --> Controller Class Initialized
INFO - 2024-12-11 15:28:26 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:28:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:28:26 --> Query result: stdClass Object
(
    [view_count] => 135
)

INFO - 2024-12-11 15:28:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-11 15:28:26 --> Final output sent to browser
DEBUG - 2024-12-11 15:28:26 --> Total execution time: 0.0853
INFO - 2024-12-11 15:28:29 --> Config Class Initialized
INFO - 2024-12-11 15:28:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:29 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:29 --> URI Class Initialized
INFO - 2024-12-11 15:28:29 --> Router Class Initialized
INFO - 2024-12-11 15:28:29 --> Output Class Initialized
INFO - 2024-12-11 15:28:29 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:29 --> CSRF cookie sent
INFO - 2024-12-11 15:28:29 --> Input Class Initialized
INFO - 2024-12-11 15:28:29 --> Language Class Initialized
INFO - 2024-12-11 15:28:29 --> Loader Class Initialized
INFO - 2024-12-11 15:28:29 --> Helper loaded: url_helper
INFO - 2024-12-11 15:28:29 --> Helper loaded: form_helper
INFO - 2024-12-11 15:28:29 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:28:29 --> Form Validation Class Initialized
INFO - 2024-12-11 15:28:29 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:28:29 --> Controller Class Initialized
INFO - 2024-12-11 15:28:29 --> Model "User_model" initialized
INFO - 2024-12-11 15:28:29 --> Model "Category_model" initialized
INFO - 2024-12-11 15:28:29 --> Model "Review_model" initialized
INFO - 2024-12-11 15:28:29 --> Model "News_model" initialized
INFO - 2024-12-11 15:28:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:28:29 --> Query result: stdClass Object
(
    [view_count] => 136
)

INFO - 2024-12-11 15:28:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:28:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:28:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:28:29 --> Final output sent to browser
DEBUG - 2024-12-11 15:28:29 --> Total execution time: 0.0657
INFO - 2024-12-11 15:28:29 --> Config Class Initialized
INFO - 2024-12-11 15:28:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:28:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:28:29 --> Utf8 Class Initialized
INFO - 2024-12-11 15:28:29 --> URI Class Initialized
INFO - 2024-12-11 15:28:29 --> Router Class Initialized
INFO - 2024-12-11 15:28:29 --> Output Class Initialized
INFO - 2024-12-11 15:28:29 --> Security Class Initialized
DEBUG - 2024-12-11 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:28:29 --> CSRF cookie sent
INFO - 2024-12-11 15:28:29 --> Input Class Initialized
INFO - 2024-12-11 15:28:29 --> Language Class Initialized
ERROR - 2024-12-11 15:28:29 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 15:29:17 --> Config Class Initialized
INFO - 2024-12-11 15:29:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:17 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:17 --> URI Class Initialized
INFO - 2024-12-11 15:29:17 --> Router Class Initialized
INFO - 2024-12-11 15:29:17 --> Output Class Initialized
INFO - 2024-12-11 15:29:17 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:17 --> CSRF cookie sent
INFO - 2024-12-11 15:29:17 --> Input Class Initialized
INFO - 2024-12-11 15:29:17 --> Language Class Initialized
INFO - 2024-12-11 15:29:17 --> Loader Class Initialized
INFO - 2024-12-11 15:29:17 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:17 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:17 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:17 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:17 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:17 --> Controller Class Initialized
INFO - 2024-12-11 15:29:17 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:17 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:17 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:17 --> Model "News_model" initialized
INFO - 2024-12-11 15:29:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:29:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:29:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:29:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:29:17 --> Final output sent to browser
DEBUG - 2024-12-11 15:29:17 --> Total execution time: 0.0820
INFO - 2024-12-11 15:29:30 --> Config Class Initialized
INFO - 2024-12-11 15:29:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:30 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:30 --> URI Class Initialized
INFO - 2024-12-11 15:29:30 --> Router Class Initialized
INFO - 2024-12-11 15:29:30 --> Output Class Initialized
INFO - 2024-12-11 15:29:30 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:30 --> CSRF cookie sent
INFO - 2024-12-11 15:29:30 --> Input Class Initialized
INFO - 2024-12-11 15:29:30 --> Language Class Initialized
INFO - 2024-12-11 15:29:30 --> Loader Class Initialized
INFO - 2024-12-11 15:29:30 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:30 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:30 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:30 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:30 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:30 --> Controller Class Initialized
INFO - 2024-12-11 15:29:30 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:30 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:30 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:30 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:29:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:29:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:29:30 --> Final output sent to browser
DEBUG - 2024-12-11 15:29:30 --> Total execution time: 0.0513
INFO - 2024-12-11 15:29:46 --> Config Class Initialized
INFO - 2024-12-11 15:29:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:46 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:46 --> URI Class Initialized
DEBUG - 2024-12-11 15:29:46 --> No URI present. Default controller set.
INFO - 2024-12-11 15:29:46 --> Router Class Initialized
INFO - 2024-12-11 15:29:46 --> Output Class Initialized
INFO - 2024-12-11 15:29:46 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:46 --> CSRF cookie sent
INFO - 2024-12-11 15:29:46 --> Input Class Initialized
INFO - 2024-12-11 15:29:46 --> Language Class Initialized
INFO - 2024-12-11 15:29:46 --> Loader Class Initialized
INFO - 2024-12-11 15:29:46 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:46 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:46 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:46 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:46 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:46 --> Controller Class Initialized
INFO - 2024-12-11 15:29:46 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:46 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:46 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:46 --> Model "News_model" initialized
INFO - 2024-12-11 15:29:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:29:46 --> Query result: stdClass Object
(
    [view_count] => 137
)

INFO - 2024-12-11 15:29:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:29:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:29:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:29:46 --> Final output sent to browser
DEBUG - 2024-12-11 15:29:46 --> Total execution time: 0.0667
INFO - 2024-12-11 15:29:49 --> Config Class Initialized
INFO - 2024-12-11 15:29:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:49 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:49 --> URI Class Initialized
DEBUG - 2024-12-11 15:29:49 --> No URI present. Default controller set.
INFO - 2024-12-11 15:29:49 --> Router Class Initialized
INFO - 2024-12-11 15:29:49 --> Output Class Initialized
INFO - 2024-12-11 15:29:49 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:49 --> CSRF cookie sent
INFO - 2024-12-11 15:29:49 --> Input Class Initialized
INFO - 2024-12-11 15:29:49 --> Language Class Initialized
INFO - 2024-12-11 15:29:49 --> Loader Class Initialized
INFO - 2024-12-11 15:29:49 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:49 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:49 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:49 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:49 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:49 --> Controller Class Initialized
INFO - 2024-12-11 15:29:49 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:49 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:49 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:49 --> Model "News_model" initialized
INFO - 2024-12-11 15:29:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:29:49 --> Query result: stdClass Object
(
    [view_count] => 138
)

INFO - 2024-12-11 15:29:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:29:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:29:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:29:49 --> Final output sent to browser
DEBUG - 2024-12-11 15:29:49 --> Total execution time: 0.0564
INFO - 2024-12-11 15:29:53 --> Config Class Initialized
INFO - 2024-12-11 15:29:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:53 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:53 --> URI Class Initialized
INFO - 2024-12-11 15:29:53 --> Router Class Initialized
INFO - 2024-12-11 15:29:53 --> Output Class Initialized
INFO - 2024-12-11 15:29:53 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:53 --> CSRF cookie sent
INFO - 2024-12-11 15:29:53 --> Input Class Initialized
INFO - 2024-12-11 15:29:53 --> Language Class Initialized
INFO - 2024-12-11 15:29:53 --> Loader Class Initialized
INFO - 2024-12-11 15:29:53 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:53 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:53 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:54 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:54 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:54 --> Controller Class Initialized
INFO - 2024-12-11 15:29:54 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:54 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:54 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:54 --> Model "News_model" initialized
INFO - 2024-12-11 15:29:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:29:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:29:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:29:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 15:29:54 --> Final output sent to browser
DEBUG - 2024-12-11 15:29:54 --> Total execution time: 0.1250
INFO - 2024-12-11 15:29:56 --> Config Class Initialized
INFO - 2024-12-11 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:56 --> URI Class Initialized
INFO - 2024-12-11 15:29:56 --> Router Class Initialized
INFO - 2024-12-11 15:29:56 --> Output Class Initialized
INFO - 2024-12-11 15:29:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:56 --> CSRF cookie sent
INFO - 2024-12-11 15:29:56 --> CSRF token verified
INFO - 2024-12-11 15:29:56 --> Input Class Initialized
INFO - 2024-12-11 15:29:56 --> Language Class Initialized
INFO - 2024-12-11 15:29:56 --> Loader Class Initialized
INFO - 2024-12-11 15:29:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:56 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:56 --> Controller Class Initialized
INFO - 2024-12-11 15:29:56 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "News_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:29:56 --> Config Class Initialized
INFO - 2024-12-11 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:29:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:29:56 --> URI Class Initialized
INFO - 2024-12-11 15:29:56 --> Router Class Initialized
INFO - 2024-12-11 15:29:56 --> Output Class Initialized
INFO - 2024-12-11 15:29:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:29:56 --> CSRF cookie sent
INFO - 2024-12-11 15:29:56 --> Input Class Initialized
INFO - 2024-12-11 15:29:56 --> Language Class Initialized
INFO - 2024-12-11 15:29:56 --> Loader Class Initialized
INFO - 2024-12-11 15:29:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:29:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:29:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:29:56 --> Form Validation Class Initialized
INFO - 2024-12-11 15:29:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:29:56 --> Controller Class Initialized
INFO - 2024-12-11 15:29:56 --> Model "Review_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "Category_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "User_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:29:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:29:56 --> Query result: stdClass Object
(
    [view_count] => 138
)

INFO - 2024-12-11 15:29:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-11 15:29:56 --> Final output sent to browser
DEBUG - 2024-12-11 15:29:56 --> Total execution time: 0.0579
INFO - 2024-12-11 15:30:02 --> Config Class Initialized
INFO - 2024-12-11 15:30:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:30:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:30:02 --> Utf8 Class Initialized
INFO - 2024-12-11 15:30:03 --> URI Class Initialized
INFO - 2024-12-11 15:30:03 --> Router Class Initialized
INFO - 2024-12-11 15:30:03 --> Output Class Initialized
INFO - 2024-12-11 15:30:03 --> Security Class Initialized
DEBUG - 2024-12-11 15:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:30:03 --> CSRF cookie sent
INFO - 2024-12-11 15:30:03 --> Input Class Initialized
INFO - 2024-12-11 15:30:03 --> Language Class Initialized
INFO - 2024-12-11 15:30:03 --> Loader Class Initialized
INFO - 2024-12-11 15:30:03 --> Helper loaded: url_helper
INFO - 2024-12-11 15:30:03 --> Helper loaded: form_helper
INFO - 2024-12-11 15:30:03 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:30:03 --> Form Validation Class Initialized
INFO - 2024-12-11 15:30:03 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:30:03 --> Controller Class Initialized
INFO - 2024-12-11 15:30:03 --> Model "User_model" initialized
INFO - 2024-12-11 15:30:03 --> Model "Category_model" initialized
INFO - 2024-12-11 15:30:03 --> Model "Review_model" initialized
INFO - 2024-12-11 15:30:03 --> Model "News_model" initialized
INFO - 2024-12-11 15:30:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:30:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:30:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:30:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:30:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 15:30:03 --> Final output sent to browser
DEBUG - 2024-12-11 15:30:03 --> Total execution time: 0.0915
INFO - 2024-12-11 15:30:06 --> Config Class Initialized
INFO - 2024-12-11 15:30:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:30:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:30:06 --> Utf8 Class Initialized
INFO - 2024-12-11 15:30:06 --> URI Class Initialized
INFO - 2024-12-11 15:30:06 --> Router Class Initialized
INFO - 2024-12-11 15:30:06 --> Output Class Initialized
INFO - 2024-12-11 15:30:06 --> Security Class Initialized
DEBUG - 2024-12-11 15:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:30:06 --> CSRF cookie sent
INFO - 2024-12-11 15:30:06 --> CSRF token verified
INFO - 2024-12-11 15:30:06 --> Input Class Initialized
INFO - 2024-12-11 15:30:06 --> Language Class Initialized
INFO - 2024-12-11 15:30:06 --> Loader Class Initialized
INFO - 2024-12-11 15:30:06 --> Helper loaded: url_helper
INFO - 2024-12-11 15:30:06 --> Helper loaded: form_helper
INFO - 2024-12-11 15:30:06 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:30:06 --> Form Validation Class Initialized
INFO - 2024-12-11 15:30:06 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:30:06 --> Controller Class Initialized
INFO - 2024-12-11 15:30:06 --> Model "User_model" initialized
INFO - 2024-12-11 15:30:06 --> Model "Category_model" initialized
INFO - 2024-12-11 15:30:06 --> Model "Review_model" initialized
INFO - 2024-12-11 15:30:06 --> Model "News_model" initialized
INFO - 2024-12-11 15:30:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:30:07 --> Config Class Initialized
INFO - 2024-12-11 15:30:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:30:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:30:07 --> Utf8 Class Initialized
INFO - 2024-12-11 15:30:07 --> URI Class Initialized
INFO - 2024-12-11 15:30:07 --> Router Class Initialized
INFO - 2024-12-11 15:30:07 --> Output Class Initialized
INFO - 2024-12-11 15:30:07 --> Security Class Initialized
DEBUG - 2024-12-11 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:30:07 --> CSRF cookie sent
INFO - 2024-12-11 15:30:07 --> Input Class Initialized
INFO - 2024-12-11 15:30:07 --> Language Class Initialized
INFO - 2024-12-11 15:30:07 --> Loader Class Initialized
INFO - 2024-12-11 15:30:07 --> Helper loaded: url_helper
INFO - 2024-12-11 15:30:07 --> Helper loaded: form_helper
INFO - 2024-12-11 15:30:07 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:30:07 --> Form Validation Class Initialized
INFO - 2024-12-11 15:30:07 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:30:07 --> Controller Class Initialized
INFO - 2024-12-11 15:30:07 --> Model "User_model" initialized
INFO - 2024-12-11 15:30:07 --> Model "Category_model" initialized
INFO - 2024-12-11 15:30:07 --> Model "Review_model" initialized
INFO - 2024-12-11 15:30:07 --> Model "News_model" initialized
INFO - 2024-12-11 15:30:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:30:07 --> Query result: stdClass Object
(
    [view_count] => 139
)

INFO - 2024-12-11 15:30:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:30:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:30:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:30:07 --> Final output sent to browser
DEBUG - 2024-12-11 15:30:07 --> Total execution time: 0.0762
INFO - 2024-12-11 15:30:07 --> Config Class Initialized
INFO - 2024-12-11 15:30:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:30:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:30:07 --> Utf8 Class Initialized
INFO - 2024-12-11 15:30:07 --> URI Class Initialized
INFO - 2024-12-11 15:30:07 --> Router Class Initialized
INFO - 2024-12-11 15:30:07 --> Output Class Initialized
INFO - 2024-12-11 15:30:07 --> Security Class Initialized
DEBUG - 2024-12-11 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:30:07 --> CSRF cookie sent
INFO - 2024-12-11 15:30:07 --> Input Class Initialized
INFO - 2024-12-11 15:30:07 --> Language Class Initialized
ERROR - 2024-12-11 15:30:07 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 15:30:38 --> Config Class Initialized
INFO - 2024-12-11 15:30:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:30:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:30:38 --> Utf8 Class Initialized
INFO - 2024-12-11 15:30:38 --> URI Class Initialized
INFO - 2024-12-11 15:30:38 --> Router Class Initialized
INFO - 2024-12-11 15:30:38 --> Output Class Initialized
INFO - 2024-12-11 15:30:38 --> Security Class Initialized
DEBUG - 2024-12-11 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:30:38 --> CSRF cookie sent
INFO - 2024-12-11 15:30:38 --> Input Class Initialized
INFO - 2024-12-11 15:30:38 --> Language Class Initialized
INFO - 2024-12-11 15:30:38 --> Loader Class Initialized
INFO - 2024-12-11 15:30:38 --> Helper loaded: url_helper
INFO - 2024-12-11 15:30:38 --> Helper loaded: form_helper
INFO - 2024-12-11 15:30:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:30:38 --> Form Validation Class Initialized
INFO - 2024-12-11 15:30:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:30:38 --> Controller Class Initialized
INFO - 2024-12-11 15:30:38 --> Model "Review_model" initialized
INFO - 2024-12-11 15:30:38 --> Model "Category_model" initialized
INFO - 2024-12-11 15:30:38 --> Model "User_model" initialized
INFO - 2024-12-11 15:30:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:30:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:30:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:30:38 --> Final output sent to browser
DEBUG - 2024-12-11 15:30:38 --> Total execution time: 0.0511
INFO - 2024-12-11 15:30:46 --> Config Class Initialized
INFO - 2024-12-11 15:30:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:30:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:30:46 --> Utf8 Class Initialized
INFO - 2024-12-11 15:30:46 --> URI Class Initialized
INFO - 2024-12-11 15:30:46 --> Router Class Initialized
INFO - 2024-12-11 15:30:46 --> Output Class Initialized
INFO - 2024-12-11 15:30:46 --> Security Class Initialized
DEBUG - 2024-12-11 15:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:30:46 --> CSRF cookie sent
INFO - 2024-12-11 15:30:46 --> Input Class Initialized
INFO - 2024-12-11 15:30:46 --> Language Class Initialized
INFO - 2024-12-11 15:30:46 --> Loader Class Initialized
INFO - 2024-12-11 15:30:46 --> Helper loaded: url_helper
INFO - 2024-12-11 15:30:46 --> Helper loaded: form_helper
INFO - 2024-12-11 15:30:46 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:30:46 --> Form Validation Class Initialized
INFO - 2024-12-11 15:30:46 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:30:46 --> Controller Class Initialized
INFO - 2024-12-11 15:30:46 --> Model "User_model" initialized
INFO - 2024-12-11 15:30:46 --> Model "Category_model" initialized
INFO - 2024-12-11 15:30:46 --> Model "Review_model" initialized
INFO - 2024-12-11 15:30:46 --> Model "News_model" initialized
INFO - 2024-12-11 15:30:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:30:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:30:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:30:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:30:46 --> Final output sent to browser
DEBUG - 2024-12-11 15:30:46 --> Total execution time: 0.0627
INFO - 2024-12-11 15:31:34 --> Config Class Initialized
INFO - 2024-12-11 15:31:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:31:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:31:34 --> Utf8 Class Initialized
INFO - 2024-12-11 15:31:34 --> URI Class Initialized
INFO - 2024-12-11 15:31:34 --> Router Class Initialized
INFO - 2024-12-11 15:31:34 --> Output Class Initialized
INFO - 2024-12-11 15:31:34 --> Security Class Initialized
DEBUG - 2024-12-11 15:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:31:34 --> CSRF cookie sent
INFO - 2024-12-11 15:31:34 --> Input Class Initialized
INFO - 2024-12-11 15:31:34 --> Language Class Initialized
INFO - 2024-12-11 15:31:34 --> Loader Class Initialized
INFO - 2024-12-11 15:31:34 --> Helper loaded: url_helper
INFO - 2024-12-11 15:31:34 --> Helper loaded: form_helper
INFO - 2024-12-11 15:31:34 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:31:34 --> Form Validation Class Initialized
INFO - 2024-12-11 15:31:34 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:31:34 --> Controller Class Initialized
INFO - 2024-12-11 15:31:34 --> Model "User_model" initialized
INFO - 2024-12-11 15:31:34 --> Model "Category_model" initialized
INFO - 2024-12-11 15:31:34 --> Model "Review_model" initialized
INFO - 2024-12-11 15:31:34 --> Model "News_model" initialized
INFO - 2024-12-11 15:31:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:31:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:31:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:31:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:31:34 --> Final output sent to browser
DEBUG - 2024-12-11 15:31:34 --> Total execution time: 0.0802
INFO - 2024-12-11 15:31:41 --> Config Class Initialized
INFO - 2024-12-11 15:31:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:31:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:31:41 --> Utf8 Class Initialized
INFO - 2024-12-11 15:31:41 --> URI Class Initialized
INFO - 2024-12-11 15:31:41 --> Router Class Initialized
INFO - 2024-12-11 15:31:41 --> Output Class Initialized
INFO - 2024-12-11 15:31:41 --> Security Class Initialized
DEBUG - 2024-12-11 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:31:41 --> CSRF cookie sent
INFO - 2024-12-11 15:31:41 --> Input Class Initialized
INFO - 2024-12-11 15:31:41 --> Language Class Initialized
INFO - 2024-12-11 15:31:41 --> Loader Class Initialized
INFO - 2024-12-11 15:31:41 --> Helper loaded: url_helper
INFO - 2024-12-11 15:31:41 --> Helper loaded: form_helper
INFO - 2024-12-11 15:31:41 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:31:42 --> Form Validation Class Initialized
INFO - 2024-12-11 15:31:42 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:31:42 --> Controller Class Initialized
INFO - 2024-12-11 15:31:42 --> Model "User_model" initialized
INFO - 2024-12-11 15:31:42 --> Model "Category_model" initialized
INFO - 2024-12-11 15:31:42 --> Model "Review_model" initialized
INFO - 2024-12-11 15:31:42 --> Model "News_model" initialized
INFO - 2024-12-11 15:31:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:31:42 --> Query result: stdClass Object
(
    [view_count] => 140
)

INFO - 2024-12-11 15:31:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:31:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:31:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:31:42 --> Final output sent to browser
DEBUG - 2024-12-11 15:31:42 --> Total execution time: 0.0814
INFO - 2024-12-11 15:31:42 --> Config Class Initialized
INFO - 2024-12-11 15:31:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:31:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:31:42 --> Utf8 Class Initialized
INFO - 2024-12-11 15:31:42 --> URI Class Initialized
INFO - 2024-12-11 15:31:42 --> Router Class Initialized
INFO - 2024-12-11 15:31:42 --> Output Class Initialized
INFO - 2024-12-11 15:31:42 --> Security Class Initialized
DEBUG - 2024-12-11 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:31:42 --> CSRF cookie sent
INFO - 2024-12-11 15:31:42 --> Input Class Initialized
INFO - 2024-12-11 15:31:42 --> Language Class Initialized
ERROR - 2024-12-11 15:31:42 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 15:31:44 --> Config Class Initialized
INFO - 2024-12-11 15:31:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:31:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:31:44 --> Utf8 Class Initialized
INFO - 2024-12-11 15:31:44 --> URI Class Initialized
INFO - 2024-12-11 15:31:44 --> Router Class Initialized
INFO - 2024-12-11 15:31:44 --> Output Class Initialized
INFO - 2024-12-11 15:31:44 --> Security Class Initialized
DEBUG - 2024-12-11 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:31:44 --> CSRF cookie sent
INFO - 2024-12-11 15:31:44 --> Input Class Initialized
INFO - 2024-12-11 15:31:44 --> Language Class Initialized
INFO - 2024-12-11 15:31:44 --> Loader Class Initialized
INFO - 2024-12-11 15:31:44 --> Helper loaded: url_helper
INFO - 2024-12-11 15:31:44 --> Helper loaded: form_helper
INFO - 2024-12-11 15:31:44 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:31:44 --> Form Validation Class Initialized
INFO - 2024-12-11 15:31:44 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:31:44 --> Controller Class Initialized
INFO - 2024-12-11 15:31:44 --> Model "User_model" initialized
INFO - 2024-12-11 15:31:44 --> Model "Category_model" initialized
INFO - 2024-12-11 15:31:44 --> Model "Review_model" initialized
INFO - 2024-12-11 15:31:44 --> Model "News_model" initialized
INFO - 2024-12-11 15:31:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:31:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:31:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:31:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:31:45 --> Final output sent to browser
DEBUG - 2024-12-11 15:31:45 --> Total execution time: 0.0794
INFO - 2024-12-11 15:32:48 --> Config Class Initialized
INFO - 2024-12-11 15:32:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:32:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:32:48 --> Utf8 Class Initialized
INFO - 2024-12-11 15:32:48 --> URI Class Initialized
INFO - 2024-12-11 15:32:48 --> Router Class Initialized
INFO - 2024-12-11 15:32:48 --> Output Class Initialized
INFO - 2024-12-11 15:32:48 --> Security Class Initialized
DEBUG - 2024-12-11 15:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:32:48 --> CSRF cookie sent
INFO - 2024-12-11 15:32:48 --> Input Class Initialized
INFO - 2024-12-11 15:32:48 --> Language Class Initialized
INFO - 2024-12-11 15:32:48 --> Loader Class Initialized
INFO - 2024-12-11 15:32:48 --> Helper loaded: url_helper
INFO - 2024-12-11 15:32:48 --> Helper loaded: form_helper
INFO - 2024-12-11 15:32:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:32:48 --> Form Validation Class Initialized
INFO - 2024-12-11 15:32:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:32:48 --> Controller Class Initialized
INFO - 2024-12-11 15:32:48 --> Model "Review_model" initialized
INFO - 2024-12-11 15:32:48 --> Model "Category_model" initialized
INFO - 2024-12-11 15:32:48 --> Model "User_model" initialized
INFO - 2024-12-11 15:32:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:32:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:32:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-11 15:32:48 --> Final output sent to browser
DEBUG - 2024-12-11 15:32:48 --> Total execution time: 0.0994
INFO - 2024-12-11 15:35:30 --> Config Class Initialized
INFO - 2024-12-11 15:35:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:35:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:35:30 --> Utf8 Class Initialized
INFO - 2024-12-11 15:35:30 --> URI Class Initialized
INFO - 2024-12-11 15:35:30 --> Router Class Initialized
INFO - 2024-12-11 15:35:30 --> Output Class Initialized
INFO - 2024-12-11 15:35:30 --> Security Class Initialized
DEBUG - 2024-12-11 15:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:35:30 --> CSRF cookie sent
INFO - 2024-12-11 15:35:30 --> Input Class Initialized
INFO - 2024-12-11 15:35:30 --> Language Class Initialized
INFO - 2024-12-11 15:35:30 --> Loader Class Initialized
INFO - 2024-12-11 15:35:30 --> Helper loaded: url_helper
INFO - 2024-12-11 15:35:30 --> Helper loaded: form_helper
INFO - 2024-12-11 15:35:30 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:35:31 --> Form Validation Class Initialized
INFO - 2024-12-11 15:35:31 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:35:31 --> Controller Class Initialized
INFO - 2024-12-11 15:35:31 --> Model "Review_model" initialized
INFO - 2024-12-11 15:35:31 --> Model "Category_model" initialized
INFO - 2024-12-11 15:35:31 --> Model "User_model" initialized
INFO - 2024-12-11 15:35:31 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:35:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:35:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:35:31 --> Final output sent to browser
DEBUG - 2024-12-11 15:35:31 --> Total execution time: 0.7137
INFO - 2024-12-11 15:35:40 --> Config Class Initialized
INFO - 2024-12-11 15:35:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:35:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:35:40 --> Utf8 Class Initialized
INFO - 2024-12-11 15:35:40 --> URI Class Initialized
INFO - 2024-12-11 15:35:40 --> Router Class Initialized
INFO - 2024-12-11 15:35:40 --> Output Class Initialized
INFO - 2024-12-11 15:35:40 --> Security Class Initialized
DEBUG - 2024-12-11 15:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:35:40 --> CSRF cookie sent
INFO - 2024-12-11 15:35:40 --> Input Class Initialized
INFO - 2024-12-11 15:35:40 --> Language Class Initialized
INFO - 2024-12-11 15:35:40 --> Loader Class Initialized
INFO - 2024-12-11 15:35:40 --> Helper loaded: url_helper
INFO - 2024-12-11 15:35:40 --> Helper loaded: form_helper
INFO - 2024-12-11 15:35:40 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:35:40 --> Form Validation Class Initialized
INFO - 2024-12-11 15:35:40 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:35:40 --> Controller Class Initialized
INFO - 2024-12-11 15:35:40 --> Model "Review_model" initialized
INFO - 2024-12-11 15:35:40 --> Model "Category_model" initialized
INFO - 2024-12-11 15:35:40 --> Model "User_model" initialized
INFO - 2024-12-11 15:35:40 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:35:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-11 15:35:40 --> Final output sent to browser
DEBUG - 2024-12-11 15:35:40 --> Total execution time: 0.0845
INFO - 2024-12-11 15:35:43 --> Config Class Initialized
INFO - 2024-12-11 15:35:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:35:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:35:43 --> Utf8 Class Initialized
INFO - 2024-12-11 15:35:43 --> URI Class Initialized
INFO - 2024-12-11 15:35:43 --> Router Class Initialized
INFO - 2024-12-11 15:35:43 --> Output Class Initialized
INFO - 2024-12-11 15:35:43 --> Security Class Initialized
DEBUG - 2024-12-11 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:35:43 --> CSRF cookie sent
INFO - 2024-12-11 15:35:43 --> Input Class Initialized
INFO - 2024-12-11 15:35:43 --> Language Class Initialized
INFO - 2024-12-11 15:35:43 --> Loader Class Initialized
INFO - 2024-12-11 15:35:43 --> Helper loaded: url_helper
INFO - 2024-12-11 15:35:43 --> Helper loaded: form_helper
INFO - 2024-12-11 15:35:43 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:35:43 --> Form Validation Class Initialized
INFO - 2024-12-11 15:35:43 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:35:43 --> Controller Class Initialized
INFO - 2024-12-11 15:35:43 --> Model "News_model" initialized
INFO - 2024-12-11 15:35:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-11 15:35:43 --> Final output sent to browser
DEBUG - 2024-12-11 15:35:43 --> Total execution time: 0.0605
INFO - 2024-12-11 15:35:44 --> Config Class Initialized
INFO - 2024-12-11 15:35:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:35:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:35:44 --> Utf8 Class Initialized
INFO - 2024-12-11 15:35:44 --> URI Class Initialized
INFO - 2024-12-11 15:35:44 --> Router Class Initialized
INFO - 2024-12-11 15:35:44 --> Output Class Initialized
INFO - 2024-12-11 15:35:44 --> Security Class Initialized
DEBUG - 2024-12-11 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:35:44 --> CSRF cookie sent
INFO - 2024-12-11 15:35:44 --> Input Class Initialized
INFO - 2024-12-11 15:35:44 --> Language Class Initialized
INFO - 2024-12-11 15:35:44 --> Loader Class Initialized
INFO - 2024-12-11 15:35:44 --> Helper loaded: url_helper
INFO - 2024-12-11 15:35:44 --> Helper loaded: form_helper
INFO - 2024-12-11 15:35:44 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:35:44 --> Form Validation Class Initialized
INFO - 2024-12-11 15:35:44 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:35:44 --> Controller Class Initialized
INFO - 2024-12-11 15:35:44 --> Model "Review_model" initialized
INFO - 2024-12-11 15:35:44 --> Model "Category_model" initialized
INFO - 2024-12-11 15:35:44 --> Model "User_model" initialized
INFO - 2024-12-11 15:35:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:35:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:35:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-11 15:35:44 --> Final output sent to browser
DEBUG - 2024-12-11 15:35:44 --> Total execution time: 0.0487
INFO - 2024-12-11 15:35:47 --> Config Class Initialized
INFO - 2024-12-11 15:35:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:35:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:35:47 --> Utf8 Class Initialized
INFO - 2024-12-11 15:35:47 --> URI Class Initialized
INFO - 2024-12-11 15:35:47 --> Router Class Initialized
INFO - 2024-12-11 15:35:47 --> Output Class Initialized
INFO - 2024-12-11 15:35:47 --> Security Class Initialized
DEBUG - 2024-12-11 15:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:35:47 --> CSRF cookie sent
INFO - 2024-12-11 15:35:47 --> Input Class Initialized
INFO - 2024-12-11 15:35:47 --> Language Class Initialized
INFO - 2024-12-11 15:35:47 --> Loader Class Initialized
INFO - 2024-12-11 15:35:47 --> Helper loaded: url_helper
INFO - 2024-12-11 15:35:47 --> Helper loaded: form_helper
INFO - 2024-12-11 15:35:47 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:35:47 --> Form Validation Class Initialized
INFO - 2024-12-11 15:35:47 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:35:47 --> Controller Class Initialized
INFO - 2024-12-11 15:35:47 --> Model "Review_model" initialized
INFO - 2024-12-11 15:35:47 --> Model "Category_model" initialized
INFO - 2024-12-11 15:35:47 --> Model "User_model" initialized
INFO - 2024-12-11 15:35:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:35:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:35:47 --> Query result: stdClass Object
(
    [view_count] => 140
)

INFO - 2024-12-11 15:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-11 15:35:47 --> Final output sent to browser
DEBUG - 2024-12-11 15:35:47 --> Total execution time: 0.1432
INFO - 2024-12-11 15:37:10 --> Config Class Initialized
INFO - 2024-12-11 15:37:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:37:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:37:10 --> Utf8 Class Initialized
INFO - 2024-12-11 15:37:10 --> URI Class Initialized
INFO - 2024-12-11 15:37:10 --> Router Class Initialized
INFO - 2024-12-11 15:37:10 --> Output Class Initialized
INFO - 2024-12-11 15:37:10 --> Security Class Initialized
DEBUG - 2024-12-11 15:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:37:10 --> CSRF cookie sent
INFO - 2024-12-11 15:37:10 --> Input Class Initialized
INFO - 2024-12-11 15:37:10 --> Language Class Initialized
INFO - 2024-12-11 15:37:10 --> Loader Class Initialized
INFO - 2024-12-11 15:37:10 --> Helper loaded: url_helper
INFO - 2024-12-11 15:37:10 --> Helper loaded: form_helper
INFO - 2024-12-11 15:37:10 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:37:10 --> Form Validation Class Initialized
INFO - 2024-12-11 15:37:10 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:37:10 --> Controller Class Initialized
INFO - 2024-12-11 15:37:10 --> Model "Review_model" initialized
INFO - 2024-12-11 15:37:10 --> Model "Category_model" initialized
INFO - 2024-12-11 15:37:10 --> Model "User_model" initialized
INFO - 2024-12-11 15:37:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:37:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:37:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:37:10 --> Final output sent to browser
DEBUG - 2024-12-11 15:37:10 --> Total execution time: 0.0952
INFO - 2024-12-11 15:37:14 --> Config Class Initialized
INFO - 2024-12-11 15:37:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:37:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:37:14 --> Utf8 Class Initialized
INFO - 2024-12-11 15:37:14 --> URI Class Initialized
INFO - 2024-12-11 15:37:14 --> Router Class Initialized
INFO - 2024-12-11 15:37:14 --> Output Class Initialized
INFO - 2024-12-11 15:37:14 --> Security Class Initialized
DEBUG - 2024-12-11 15:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:37:14 --> CSRF cookie sent
INFO - 2024-12-11 15:37:14 --> Input Class Initialized
INFO - 2024-12-11 15:37:14 --> Language Class Initialized
INFO - 2024-12-11 15:37:14 --> Loader Class Initialized
INFO - 2024-12-11 15:37:14 --> Helper loaded: url_helper
INFO - 2024-12-11 15:37:14 --> Helper loaded: form_helper
INFO - 2024-12-11 15:37:14 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:37:14 --> Form Validation Class Initialized
INFO - 2024-12-11 15:37:14 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:37:14 --> Controller Class Initialized
INFO - 2024-12-11 15:37:14 --> Model "Review_model" initialized
INFO - 2024-12-11 15:37:14 --> Model "Category_model" initialized
INFO - 2024-12-11 15:37:14 --> Model "User_model" initialized
INFO - 2024-12-11 15:37:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:37:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:37:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:37:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-11 15:37:14 --> Final output sent to browser
DEBUG - 2024-12-11 15:37:14 --> Total execution time: 0.0607
INFO - 2024-12-11 15:42:42 --> Config Class Initialized
INFO - 2024-12-11 15:42:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:42:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:42:42 --> Utf8 Class Initialized
INFO - 2024-12-11 15:42:43 --> URI Class Initialized
INFO - 2024-12-11 15:42:43 --> Router Class Initialized
INFO - 2024-12-11 15:42:43 --> Output Class Initialized
INFO - 2024-12-11 15:42:43 --> Security Class Initialized
DEBUG - 2024-12-11 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:42:43 --> CSRF cookie sent
INFO - 2024-12-11 15:42:43 --> CSRF token verified
INFO - 2024-12-11 15:42:43 --> Input Class Initialized
INFO - 2024-12-11 15:42:43 --> Language Class Initialized
INFO - 2024-12-11 15:42:43 --> Loader Class Initialized
INFO - 2024-12-11 15:42:43 --> Helper loaded: url_helper
INFO - 2024-12-11 15:42:43 --> Helper loaded: form_helper
INFO - 2024-12-11 15:42:43 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:42:43 --> Form Validation Class Initialized
INFO - 2024-12-11 15:42:43 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:42:43 --> Controller Class Initialized
INFO - 2024-12-11 15:42:43 --> Model "Review_model" initialized
INFO - 2024-12-11 15:42:43 --> Model "Category_model" initialized
INFO - 2024-12-11 15:42:43 --> Model "User_model" initialized
INFO - 2024-12-11 15:42:43 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:42:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:42:43 --> Upload Class Initialized
INFO - 2024-12-11 15:42:43 --> Config Class Initialized
INFO - 2024-12-11 15:42:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:42:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:42:43 --> Utf8 Class Initialized
INFO - 2024-12-11 15:42:43 --> URI Class Initialized
INFO - 2024-12-11 15:42:43 --> Router Class Initialized
INFO - 2024-12-11 15:42:43 --> Output Class Initialized
INFO - 2024-12-11 15:42:43 --> Security Class Initialized
DEBUG - 2024-12-11 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:42:43 --> CSRF cookie sent
INFO - 2024-12-11 15:42:43 --> Input Class Initialized
INFO - 2024-12-11 15:42:43 --> Language Class Initialized
INFO - 2024-12-11 15:42:43 --> Loader Class Initialized
INFO - 2024-12-11 15:42:43 --> Helper loaded: url_helper
INFO - 2024-12-11 15:42:43 --> Helper loaded: form_helper
INFO - 2024-12-11 15:42:43 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:42:44 --> Form Validation Class Initialized
INFO - 2024-12-11 15:42:44 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:42:44 --> Controller Class Initialized
INFO - 2024-12-11 15:42:44 --> Model "Review_model" initialized
INFO - 2024-12-11 15:42:44 --> Model "Category_model" initialized
INFO - 2024-12-11 15:42:44 --> Model "User_model" initialized
INFO - 2024-12-11 15:42:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:42:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:42:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:42:44 --> Final output sent to browser
DEBUG - 2024-12-11 15:42:44 --> Total execution time: 0.0627
INFO - 2024-12-11 15:42:56 --> Config Class Initialized
INFO - 2024-12-11 15:42:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:42:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:42:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:42:56 --> URI Class Initialized
DEBUG - 2024-12-11 15:42:56 --> No URI present. Default controller set.
INFO - 2024-12-11 15:42:56 --> Router Class Initialized
INFO - 2024-12-11 15:42:56 --> Output Class Initialized
INFO - 2024-12-11 15:42:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:42:56 --> CSRF cookie sent
INFO - 2024-12-11 15:42:56 --> Input Class Initialized
INFO - 2024-12-11 15:42:56 --> Language Class Initialized
INFO - 2024-12-11 15:42:56 --> Loader Class Initialized
INFO - 2024-12-11 15:42:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:42:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:42:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:42:56 --> Form Validation Class Initialized
INFO - 2024-12-11 15:42:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:42:56 --> Controller Class Initialized
INFO - 2024-12-11 15:42:56 --> Model "User_model" initialized
INFO - 2024-12-11 15:42:56 --> Model "Category_model" initialized
INFO - 2024-12-11 15:42:56 --> Model "Review_model" initialized
INFO - 2024-12-11 15:42:56 --> Model "News_model" initialized
INFO - 2024-12-11 15:42:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:42:56 --> Query result: stdClass Object
(
    [view_count] => 141
)

INFO - 2024-12-11 15:42:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:42:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:42:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:42:56 --> Final output sent to browser
DEBUG - 2024-12-11 15:42:56 --> Total execution time: 0.1700
INFO - 2024-12-11 15:42:58 --> Config Class Initialized
INFO - 2024-12-11 15:42:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:42:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:42:58 --> Utf8 Class Initialized
INFO - 2024-12-11 15:42:58 --> URI Class Initialized
DEBUG - 2024-12-11 15:42:58 --> No URI present. Default controller set.
INFO - 2024-12-11 15:42:58 --> Router Class Initialized
INFO - 2024-12-11 15:42:58 --> Output Class Initialized
INFO - 2024-12-11 15:42:58 --> Security Class Initialized
DEBUG - 2024-12-11 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:42:58 --> CSRF cookie sent
INFO - 2024-12-11 15:42:58 --> Input Class Initialized
INFO - 2024-12-11 15:42:58 --> Language Class Initialized
INFO - 2024-12-11 15:42:58 --> Loader Class Initialized
INFO - 2024-12-11 15:42:58 --> Helper loaded: url_helper
INFO - 2024-12-11 15:42:58 --> Helper loaded: form_helper
INFO - 2024-12-11 15:42:58 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:42:58 --> Form Validation Class Initialized
INFO - 2024-12-11 15:42:58 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:42:58 --> Controller Class Initialized
INFO - 2024-12-11 15:42:58 --> Model "User_model" initialized
INFO - 2024-12-11 15:42:58 --> Model "Category_model" initialized
INFO - 2024-12-11 15:42:58 --> Model "Review_model" initialized
INFO - 2024-12-11 15:42:58 --> Model "News_model" initialized
INFO - 2024-12-11 15:42:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:42:58 --> Query result: stdClass Object
(
    [view_count] => 142
)

INFO - 2024-12-11 15:42:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:42:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:42:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:42:58 --> Final output sent to browser
DEBUG - 2024-12-11 15:42:58 --> Total execution time: 0.1421
INFO - 2024-12-11 15:43:06 --> Config Class Initialized
INFO - 2024-12-11 15:43:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:06 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:06 --> URI Class Initialized
INFO - 2024-12-11 15:43:06 --> Router Class Initialized
INFO - 2024-12-11 15:43:06 --> Output Class Initialized
INFO - 2024-12-11 15:43:06 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:06 --> CSRF cookie sent
INFO - 2024-12-11 15:43:06 --> Input Class Initialized
INFO - 2024-12-11 15:43:06 --> Language Class Initialized
INFO - 2024-12-11 15:43:06 --> Loader Class Initialized
INFO - 2024-12-11 15:43:06 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:06 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:06 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:06 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:06 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:06 --> Controller Class Initialized
INFO - 2024-12-11 15:43:06 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:06 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:06 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:06 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 15:43:06 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:06 --> Total execution time: 0.0745
INFO - 2024-12-11 15:43:09 --> Config Class Initialized
INFO - 2024-12-11 15:43:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:09 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:09 --> URI Class Initialized
INFO - 2024-12-11 15:43:09 --> Router Class Initialized
INFO - 2024-12-11 15:43:09 --> Output Class Initialized
INFO - 2024-12-11 15:43:09 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:09 --> CSRF cookie sent
INFO - 2024-12-11 15:43:09 --> CSRF token verified
INFO - 2024-12-11 15:43:09 --> Input Class Initialized
INFO - 2024-12-11 15:43:09 --> Language Class Initialized
INFO - 2024-12-11 15:43:09 --> Loader Class Initialized
INFO - 2024-12-11 15:43:09 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:09 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:09 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:09 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:09 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:09 --> Controller Class Initialized
INFO - 2024-12-11 15:43:09 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:09 --> Config Class Initialized
INFO - 2024-12-11 15:43:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:09 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:09 --> URI Class Initialized
INFO - 2024-12-11 15:43:09 --> Router Class Initialized
INFO - 2024-12-11 15:43:09 --> Output Class Initialized
INFO - 2024-12-11 15:43:09 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:09 --> CSRF cookie sent
INFO - 2024-12-11 15:43:09 --> Input Class Initialized
INFO - 2024-12-11 15:43:09 --> Language Class Initialized
INFO - 2024-12-11 15:43:09 --> Loader Class Initialized
INFO - 2024-12-11 15:43:09 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:09 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:09 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:09 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:09 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:09 --> Controller Class Initialized
INFO - 2024-12-11 15:43:09 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:43:09 --> Query result: stdClass Object
(
    [view_count] => 143
)

INFO - 2024-12-11 15:43:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:43:09 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:09 --> Total execution time: 0.0777
INFO - 2024-12-11 15:43:09 --> Config Class Initialized
INFO - 2024-12-11 15:43:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:09 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:09 --> URI Class Initialized
INFO - 2024-12-11 15:43:09 --> Router Class Initialized
INFO - 2024-12-11 15:43:09 --> Output Class Initialized
INFO - 2024-12-11 15:43:09 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:09 --> CSRF cookie sent
INFO - 2024-12-11 15:43:09 --> Input Class Initialized
INFO - 2024-12-11 15:43:09 --> Language Class Initialized
ERROR - 2024-12-11 15:43:09 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 15:43:12 --> Config Class Initialized
INFO - 2024-12-11 15:43:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:12 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:12 --> URI Class Initialized
INFO - 2024-12-11 15:43:12 --> Router Class Initialized
INFO - 2024-12-11 15:43:12 --> Output Class Initialized
INFO - 2024-12-11 15:43:12 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:12 --> CSRF cookie sent
INFO - 2024-12-11 15:43:12 --> Input Class Initialized
INFO - 2024-12-11 15:43:12 --> Language Class Initialized
INFO - 2024-12-11 15:43:12 --> Loader Class Initialized
INFO - 2024-12-11 15:43:12 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:12 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:12 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:12 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:12 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:12 --> Controller Class Initialized
INFO - 2024-12-11 15:43:12 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:12 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:12 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:12 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 15:43:12 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:12 --> Total execution time: 0.0713
INFO - 2024-12-11 15:43:15 --> Config Class Initialized
INFO - 2024-12-11 15:43:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:15 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:15 --> URI Class Initialized
INFO - 2024-12-11 15:43:15 --> Router Class Initialized
INFO - 2024-12-11 15:43:15 --> Output Class Initialized
INFO - 2024-12-11 15:43:15 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:15 --> CSRF cookie sent
INFO - 2024-12-11 15:43:15 --> CSRF token verified
INFO - 2024-12-11 15:43:15 --> Input Class Initialized
INFO - 2024-12-11 15:43:15 --> Language Class Initialized
INFO - 2024-12-11 15:43:15 --> Loader Class Initialized
INFO - 2024-12-11 15:43:15 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:15 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:15 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:15 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:15 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:15 --> Controller Class Initialized
INFO - 2024-12-11 15:43:15 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:15 --> Config Class Initialized
INFO - 2024-12-11 15:43:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:15 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:15 --> URI Class Initialized
INFO - 2024-12-11 15:43:15 --> Router Class Initialized
INFO - 2024-12-11 15:43:15 --> Output Class Initialized
INFO - 2024-12-11 15:43:15 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:15 --> CSRF cookie sent
INFO - 2024-12-11 15:43:15 --> Input Class Initialized
INFO - 2024-12-11 15:43:15 --> Language Class Initialized
INFO - 2024-12-11 15:43:15 --> Loader Class Initialized
INFO - 2024-12-11 15:43:15 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:15 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:15 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:15 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:15 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:15 --> Controller Class Initialized
INFO - 2024-12-11 15:43:15 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:43:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:43:15 --> Query result: stdClass Object
(
    [view_count] => 143
)

INFO - 2024-12-11 15:43:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-11 15:43:15 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:15 --> Total execution time: 0.0903
INFO - 2024-12-11 15:43:20 --> Config Class Initialized
INFO - 2024-12-11 15:43:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:20 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:20 --> URI Class Initialized
INFO - 2024-12-11 15:43:20 --> Router Class Initialized
INFO - 2024-12-11 15:43:20 --> Output Class Initialized
INFO - 2024-12-11 15:43:20 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:20 --> CSRF cookie sent
INFO - 2024-12-11 15:43:20 --> Input Class Initialized
INFO - 2024-12-11 15:43:20 --> Language Class Initialized
INFO - 2024-12-11 15:43:20 --> Loader Class Initialized
INFO - 2024-12-11 15:43:20 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:20 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:20 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:20 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:20 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:20 --> Controller Class Initialized
INFO - 2024-12-11 15:43:20 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:20 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:20 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:20 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:43:20 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:20 --> Total execution time: 0.0605
INFO - 2024-12-11 15:43:34 --> Config Class Initialized
INFO - 2024-12-11 15:43:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:34 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:34 --> URI Class Initialized
INFO - 2024-12-11 15:43:34 --> Router Class Initialized
INFO - 2024-12-11 15:43:34 --> Output Class Initialized
INFO - 2024-12-11 15:43:34 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:34 --> CSRF cookie sent
INFO - 2024-12-11 15:43:34 --> Input Class Initialized
INFO - 2024-12-11 15:43:34 --> Language Class Initialized
INFO - 2024-12-11 15:43:34 --> Loader Class Initialized
INFO - 2024-12-11 15:43:34 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:34 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:34 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:34 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:34 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:34 --> Controller Class Initialized
INFO - 2024-12-11 15:43:34 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:34 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:34 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:34 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 15:43:34 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:34 --> Total execution time: 0.0661
INFO - 2024-12-11 15:43:37 --> Config Class Initialized
INFO - 2024-12-11 15:43:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:37 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:37 --> URI Class Initialized
INFO - 2024-12-11 15:43:37 --> Router Class Initialized
INFO - 2024-12-11 15:43:37 --> Output Class Initialized
INFO - 2024-12-11 15:43:37 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:37 --> CSRF cookie sent
INFO - 2024-12-11 15:43:37 --> Input Class Initialized
INFO - 2024-12-11 15:43:37 --> Language Class Initialized
INFO - 2024-12-11 15:43:37 --> Loader Class Initialized
INFO - 2024-12-11 15:43:37 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:37 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:37 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:37 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:37 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:37 --> Controller Class Initialized
INFO - 2024-12-11 15:43:37 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:37 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:37 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:37 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:43:37 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:37 --> Total execution time: 0.0601
INFO - 2024-12-11 15:43:39 --> Config Class Initialized
INFO - 2024-12-11 15:43:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:39 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:39 --> URI Class Initialized
INFO - 2024-12-11 15:43:39 --> Router Class Initialized
INFO - 2024-12-11 15:43:39 --> Output Class Initialized
INFO - 2024-12-11 15:43:39 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:39 --> CSRF cookie sent
INFO - 2024-12-11 15:43:39 --> Input Class Initialized
INFO - 2024-12-11 15:43:39 --> Language Class Initialized
INFO - 2024-12-11 15:43:39 --> Loader Class Initialized
INFO - 2024-12-11 15:43:39 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:39 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:39 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:39 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:39 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:39 --> Controller Class Initialized
INFO - 2024-12-11 15:43:39 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:39 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:39 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:39 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 15:43:39 --> Query result: stdClass Object
(
    [view_count] => 144
)

INFO - 2024-12-11 15:43:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 15:43:39 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:39 --> Total execution time: 0.0589
INFO - 2024-12-11 15:43:39 --> Config Class Initialized
INFO - 2024-12-11 15:43:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:39 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:39 --> URI Class Initialized
INFO - 2024-12-11 15:43:39 --> Router Class Initialized
INFO - 2024-12-11 15:43:39 --> Output Class Initialized
INFO - 2024-12-11 15:43:39 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:39 --> CSRF cookie sent
INFO - 2024-12-11 15:43:39 --> Input Class Initialized
INFO - 2024-12-11 15:43:39 --> Language Class Initialized
ERROR - 2024-12-11 15:43:39 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 15:43:44 --> Config Class Initialized
INFO - 2024-12-11 15:43:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:44 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:44 --> URI Class Initialized
INFO - 2024-12-11 15:43:44 --> Router Class Initialized
INFO - 2024-12-11 15:43:44 --> Output Class Initialized
INFO - 2024-12-11 15:43:44 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:44 --> CSRF cookie sent
INFO - 2024-12-11 15:43:44 --> Input Class Initialized
INFO - 2024-12-11 15:43:44 --> Language Class Initialized
INFO - 2024-12-11 15:43:44 --> Loader Class Initialized
INFO - 2024-12-11 15:43:44 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:44 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:44 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:44 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:44 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:44 --> Controller Class Initialized
INFO - 2024-12-11 15:43:44 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:44 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:44 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:44 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:43:44 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:44 --> Total execution time: 0.0741
INFO - 2024-12-11 15:43:47 --> Config Class Initialized
INFO - 2024-12-11 15:43:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:47 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:47 --> URI Class Initialized
INFO - 2024-12-11 15:43:47 --> Router Class Initialized
INFO - 2024-12-11 15:43:47 --> Output Class Initialized
INFO - 2024-12-11 15:43:47 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:47 --> CSRF cookie sent
INFO - 2024-12-11 15:43:47 --> Input Class Initialized
INFO - 2024-12-11 15:43:47 --> Language Class Initialized
INFO - 2024-12-11 15:43:47 --> Loader Class Initialized
INFO - 2024-12-11 15:43:47 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:47 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:47 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:47 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:47 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:47 --> Controller Class Initialized
INFO - 2024-12-11 15:43:47 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:47 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:47 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:47 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 15:43:47 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:47 --> Total execution time: 0.0795
INFO - 2024-12-11 15:43:55 --> Config Class Initialized
INFO - 2024-12-11 15:43:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:55 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:55 --> URI Class Initialized
INFO - 2024-12-11 15:43:55 --> Router Class Initialized
INFO - 2024-12-11 15:43:55 --> Output Class Initialized
INFO - 2024-12-11 15:43:55 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:55 --> CSRF cookie sent
INFO - 2024-12-11 15:43:55 --> Input Class Initialized
INFO - 2024-12-11 15:43:55 --> Language Class Initialized
INFO - 2024-12-11 15:43:55 --> Loader Class Initialized
INFO - 2024-12-11 15:43:55 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:55 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:55 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:55 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:55 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:55 --> Controller Class Initialized
INFO - 2024-12-11 15:43:55 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:55 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:55 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:55 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:43:55 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:55 --> Total execution time: 0.0706
INFO - 2024-12-11 15:43:56 --> Config Class Initialized
INFO - 2024-12-11 15:43:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:43:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:43:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:43:56 --> URI Class Initialized
INFO - 2024-12-11 15:43:56 --> Router Class Initialized
INFO - 2024-12-11 15:43:56 --> Output Class Initialized
INFO - 2024-12-11 15:43:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:43:56 --> CSRF cookie sent
INFO - 2024-12-11 15:43:56 --> Input Class Initialized
INFO - 2024-12-11 15:43:56 --> Language Class Initialized
INFO - 2024-12-11 15:43:56 --> Loader Class Initialized
INFO - 2024-12-11 15:43:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:43:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:43:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:43:56 --> Form Validation Class Initialized
INFO - 2024-12-11 15:43:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:43:56 --> Controller Class Initialized
INFO - 2024-12-11 15:43:56 --> Model "User_model" initialized
INFO - 2024-12-11 15:43:56 --> Model "Category_model" initialized
INFO - 2024-12-11 15:43:56 --> Model "Review_model" initialized
INFO - 2024-12-11 15:43:56 --> Model "News_model" initialized
INFO - 2024-12-11 15:43:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:43:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:43:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:43:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 15:43:56 --> Final output sent to browser
DEBUG - 2024-12-11 15:43:56 --> Total execution time: 0.0815
INFO - 2024-12-11 15:44:02 --> Config Class Initialized
INFO - 2024-12-11 15:44:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:44:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:44:02 --> Utf8 Class Initialized
INFO - 2024-12-11 15:44:02 --> URI Class Initialized
INFO - 2024-12-11 15:44:02 --> Router Class Initialized
INFO - 2024-12-11 15:44:02 --> Output Class Initialized
INFO - 2024-12-11 15:44:02 --> Security Class Initialized
DEBUG - 2024-12-11 15:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:44:02 --> CSRF cookie sent
INFO - 2024-12-11 15:44:02 --> Input Class Initialized
INFO - 2024-12-11 15:44:02 --> Language Class Initialized
INFO - 2024-12-11 15:44:02 --> Loader Class Initialized
INFO - 2024-12-11 15:44:02 --> Helper loaded: url_helper
INFO - 2024-12-11 15:44:02 --> Helper loaded: form_helper
INFO - 2024-12-11 15:44:02 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:44:02 --> Form Validation Class Initialized
INFO - 2024-12-11 15:44:02 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:44:02 --> Controller Class Initialized
INFO - 2024-12-11 15:44:02 --> Model "Review_model" initialized
INFO - 2024-12-11 15:44:02 --> Model "Category_model" initialized
INFO - 2024-12-11 15:44:02 --> Model "User_model" initialized
INFO - 2024-12-11 15:44:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:44:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:44:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:44:02 --> Final output sent to browser
DEBUG - 2024-12-11 15:44:02 --> Total execution time: 0.0742
INFO - 2024-12-11 15:44:05 --> Config Class Initialized
INFO - 2024-12-11 15:44:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:44:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:44:05 --> Utf8 Class Initialized
INFO - 2024-12-11 15:44:05 --> URI Class Initialized
INFO - 2024-12-11 15:44:05 --> Router Class Initialized
INFO - 2024-12-11 15:44:05 --> Output Class Initialized
INFO - 2024-12-11 15:44:05 --> Security Class Initialized
DEBUG - 2024-12-11 15:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:44:05 --> CSRF cookie sent
INFO - 2024-12-11 15:44:05 --> Input Class Initialized
INFO - 2024-12-11 15:44:05 --> Language Class Initialized
INFO - 2024-12-11 15:44:05 --> Loader Class Initialized
INFO - 2024-12-11 15:44:05 --> Helper loaded: url_helper
INFO - 2024-12-11 15:44:05 --> Helper loaded: form_helper
INFO - 2024-12-11 15:44:05 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:44:05 --> Form Validation Class Initialized
INFO - 2024-12-11 15:44:05 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:44:05 --> Controller Class Initialized
INFO - 2024-12-11 15:44:05 --> Model "Review_model" initialized
INFO - 2024-12-11 15:44:05 --> Model "Category_model" initialized
INFO - 2024-12-11 15:44:05 --> Model "User_model" initialized
INFO - 2024-12-11 15:44:05 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:44:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:44:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-11 15:44:05 --> Final output sent to browser
DEBUG - 2024-12-11 15:44:05 --> Total execution time: 0.0573
INFO - 2024-12-11 15:50:43 --> Config Class Initialized
INFO - 2024-12-11 15:50:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:50:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:50:43 --> Utf8 Class Initialized
INFO - 2024-12-11 15:50:43 --> URI Class Initialized
INFO - 2024-12-11 15:50:43 --> Router Class Initialized
INFO - 2024-12-11 15:50:43 --> Output Class Initialized
INFO - 2024-12-11 15:50:43 --> Security Class Initialized
DEBUG - 2024-12-11 15:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:50:43 --> CSRF cookie sent
INFO - 2024-12-11 15:50:43 --> CSRF token verified
INFO - 2024-12-11 15:50:43 --> Input Class Initialized
INFO - 2024-12-11 15:50:43 --> Language Class Initialized
INFO - 2024-12-11 15:50:43 --> Loader Class Initialized
INFO - 2024-12-11 15:50:44 --> Helper loaded: url_helper
INFO - 2024-12-11 15:50:44 --> Helper loaded: form_helper
INFO - 2024-12-11 15:50:44 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:50:44 --> Form Validation Class Initialized
INFO - 2024-12-11 15:50:44 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:50:44 --> Controller Class Initialized
INFO - 2024-12-11 15:50:44 --> Model "Review_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "Category_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "User_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:50:44 --> Upload Class Initialized
INFO - 2024-12-11 15:50:44 --> Config Class Initialized
INFO - 2024-12-11 15:50:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:50:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:50:44 --> Utf8 Class Initialized
INFO - 2024-12-11 15:50:44 --> URI Class Initialized
INFO - 2024-12-11 15:50:44 --> Router Class Initialized
INFO - 2024-12-11 15:50:44 --> Output Class Initialized
INFO - 2024-12-11 15:50:44 --> Security Class Initialized
DEBUG - 2024-12-11 15:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:50:44 --> CSRF cookie sent
INFO - 2024-12-11 15:50:44 --> Input Class Initialized
INFO - 2024-12-11 15:50:44 --> Language Class Initialized
INFO - 2024-12-11 15:50:44 --> Loader Class Initialized
INFO - 2024-12-11 15:50:44 --> Helper loaded: url_helper
INFO - 2024-12-11 15:50:44 --> Helper loaded: form_helper
INFO - 2024-12-11 15:50:44 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:50:44 --> Form Validation Class Initialized
INFO - 2024-12-11 15:50:44 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:50:44 --> Controller Class Initialized
INFO - 2024-12-11 15:50:44 --> Model "Review_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "Category_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "User_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:50:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:50:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:50:44 --> Final output sent to browser
DEBUG - 2024-12-11 15:50:44 --> Total execution time: 0.0764
INFO - 2024-12-11 15:50:50 --> Config Class Initialized
INFO - 2024-12-11 15:50:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:50:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:50:50 --> Utf8 Class Initialized
INFO - 2024-12-11 15:50:50 --> URI Class Initialized
INFO - 2024-12-11 15:50:50 --> Router Class Initialized
INFO - 2024-12-11 15:50:50 --> Output Class Initialized
INFO - 2024-12-11 15:50:50 --> Security Class Initialized
DEBUG - 2024-12-11 15:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:50:50 --> CSRF cookie sent
INFO - 2024-12-11 15:50:50 --> Input Class Initialized
INFO - 2024-12-11 15:50:50 --> Language Class Initialized
INFO - 2024-12-11 15:50:50 --> Loader Class Initialized
INFO - 2024-12-11 15:50:50 --> Helper loaded: url_helper
INFO - 2024-12-11 15:50:50 --> Helper loaded: form_helper
INFO - 2024-12-11 15:50:50 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:50:50 --> Form Validation Class Initialized
INFO - 2024-12-11 15:50:50 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:50:50 --> Controller Class Initialized
INFO - 2024-12-11 15:50:50 --> Model "User_model" initialized
INFO - 2024-12-11 15:50:50 --> Model "Category_model" initialized
INFO - 2024-12-11 15:50:50 --> Model "Review_model" initialized
INFO - 2024-12-11 15:50:50 --> Model "News_model" initialized
INFO - 2024-12-11 15:50:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:50:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:50:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:50:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 15:50:50 --> Final output sent to browser
DEBUG - 2024-12-11 15:50:50 --> Total execution time: 0.1543
INFO - 2024-12-11 15:50:56 --> Config Class Initialized
INFO - 2024-12-11 15:50:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:50:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:50:56 --> Utf8 Class Initialized
INFO - 2024-12-11 15:50:56 --> URI Class Initialized
INFO - 2024-12-11 15:50:56 --> Router Class Initialized
INFO - 2024-12-11 15:50:56 --> Output Class Initialized
INFO - 2024-12-11 15:50:56 --> Security Class Initialized
DEBUG - 2024-12-11 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:50:56 --> CSRF cookie sent
INFO - 2024-12-11 15:50:56 --> Input Class Initialized
INFO - 2024-12-11 15:50:56 --> Language Class Initialized
INFO - 2024-12-11 15:50:56 --> Loader Class Initialized
INFO - 2024-12-11 15:50:56 --> Helper loaded: url_helper
INFO - 2024-12-11 15:50:56 --> Helper loaded: form_helper
INFO - 2024-12-11 15:50:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:50:56 --> Form Validation Class Initialized
INFO - 2024-12-11 15:50:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:50:56 --> Controller Class Initialized
INFO - 2024-12-11 15:50:56 --> Model "User_model" initialized
INFO - 2024-12-11 15:50:56 --> Model "Category_model" initialized
INFO - 2024-12-11 15:50:56 --> Model "Review_model" initialized
INFO - 2024-12-11 15:50:56 --> Model "News_model" initialized
INFO - 2024-12-11 15:50:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:50:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:50:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:50:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 15:50:56 --> Final output sent to browser
DEBUG - 2024-12-11 15:50:56 --> Total execution time: 0.1435
INFO - 2024-12-11 15:51:26 --> Config Class Initialized
INFO - 2024-12-11 15:51:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:51:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:51:26 --> Utf8 Class Initialized
INFO - 2024-12-11 15:51:26 --> URI Class Initialized
INFO - 2024-12-11 15:51:26 --> Router Class Initialized
INFO - 2024-12-11 15:51:26 --> Output Class Initialized
INFO - 2024-12-11 15:51:26 --> Security Class Initialized
DEBUG - 2024-12-11 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:51:26 --> CSRF cookie sent
INFO - 2024-12-11 15:51:26 --> Input Class Initialized
INFO - 2024-12-11 15:51:26 --> Language Class Initialized
INFO - 2024-12-11 15:51:26 --> Loader Class Initialized
INFO - 2024-12-11 15:51:26 --> Helper loaded: url_helper
INFO - 2024-12-11 15:51:26 --> Helper loaded: form_helper
INFO - 2024-12-11 15:51:26 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:51:26 --> Form Validation Class Initialized
INFO - 2024-12-11 15:51:26 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:51:26 --> Controller Class Initialized
INFO - 2024-12-11 15:51:26 --> Model "Review_model" initialized
INFO - 2024-12-11 15:51:26 --> Model "Category_model" initialized
INFO - 2024-12-11 15:51:26 --> Model "User_model" initialized
INFO - 2024-12-11 15:51:26 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:51:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:51:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-11 15:51:26 --> Final output sent to browser
DEBUG - 2024-12-11 15:51:26 --> Total execution time: 0.0946
INFO - 2024-12-11 15:51:38 --> Config Class Initialized
INFO - 2024-12-11 15:51:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:51:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:51:38 --> Utf8 Class Initialized
INFO - 2024-12-11 15:51:38 --> URI Class Initialized
INFO - 2024-12-11 15:51:38 --> Router Class Initialized
INFO - 2024-12-11 15:51:38 --> Output Class Initialized
INFO - 2024-12-11 15:51:38 --> Security Class Initialized
DEBUG - 2024-12-11 15:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:51:38 --> CSRF cookie sent
INFO - 2024-12-11 15:51:38 --> CSRF token verified
INFO - 2024-12-11 15:51:38 --> Input Class Initialized
INFO - 2024-12-11 15:51:38 --> Language Class Initialized
INFO - 2024-12-11 15:51:38 --> Loader Class Initialized
INFO - 2024-12-11 15:51:38 --> Helper loaded: url_helper
INFO - 2024-12-11 15:51:38 --> Helper loaded: form_helper
INFO - 2024-12-11 15:51:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:51:38 --> Form Validation Class Initialized
INFO - 2024-12-11 15:51:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:51:38 --> Controller Class Initialized
INFO - 2024-12-11 15:51:38 --> Model "Review_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "Category_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "User_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:51:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-11 15:51:38 --> Config Class Initialized
INFO - 2024-12-11 15:51:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:51:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:51:38 --> Utf8 Class Initialized
INFO - 2024-12-11 15:51:38 --> URI Class Initialized
INFO - 2024-12-11 15:51:38 --> Router Class Initialized
INFO - 2024-12-11 15:51:38 --> Output Class Initialized
INFO - 2024-12-11 15:51:38 --> Security Class Initialized
DEBUG - 2024-12-11 15:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:51:38 --> CSRF cookie sent
INFO - 2024-12-11 15:51:38 --> Input Class Initialized
INFO - 2024-12-11 15:51:38 --> Language Class Initialized
INFO - 2024-12-11 15:51:38 --> Loader Class Initialized
INFO - 2024-12-11 15:51:38 --> Helper loaded: url_helper
INFO - 2024-12-11 15:51:38 --> Helper loaded: form_helper
INFO - 2024-12-11 15:51:38 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:51:38 --> Form Validation Class Initialized
INFO - 2024-12-11 15:51:38 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:51:38 --> Controller Class Initialized
INFO - 2024-12-11 15:51:38 --> Model "Review_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "Category_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "User_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 15:51:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:51:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 15:51:38 --> Final output sent to browser
DEBUG - 2024-12-11 15:51:38 --> Total execution time: 0.0482
INFO - 2024-12-11 15:51:43 --> Config Class Initialized
INFO - 2024-12-11 15:51:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:51:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:51:43 --> Utf8 Class Initialized
INFO - 2024-12-11 15:51:43 --> URI Class Initialized
INFO - 2024-12-11 15:51:43 --> Router Class Initialized
INFO - 2024-12-11 15:51:43 --> Output Class Initialized
INFO - 2024-12-11 15:51:43 --> Security Class Initialized
DEBUG - 2024-12-11 15:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:51:43 --> CSRF cookie sent
INFO - 2024-12-11 15:51:43 --> Input Class Initialized
INFO - 2024-12-11 15:51:43 --> Language Class Initialized
INFO - 2024-12-11 15:51:43 --> Loader Class Initialized
INFO - 2024-12-11 15:51:43 --> Helper loaded: url_helper
INFO - 2024-12-11 15:51:43 --> Helper loaded: form_helper
INFO - 2024-12-11 15:51:43 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:51:43 --> Form Validation Class Initialized
INFO - 2024-12-11 15:51:43 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:51:43 --> Controller Class Initialized
INFO - 2024-12-11 15:51:43 --> Model "User_model" initialized
INFO - 2024-12-11 15:51:43 --> Model "Category_model" initialized
INFO - 2024-12-11 15:51:43 --> Model "Review_model" initialized
INFO - 2024-12-11 15:51:43 --> Model "News_model" initialized
INFO - 2024-12-11 15:51:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:51:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:51:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:51:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 15:51:43 --> Final output sent to browser
DEBUG - 2024-12-11 15:51:43 --> Total execution time: 0.0698
INFO - 2024-12-11 15:52:04 --> Config Class Initialized
INFO - 2024-12-11 15:52:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:52:04 --> Utf8 Class Initialized
INFO - 2024-12-11 15:52:04 --> URI Class Initialized
INFO - 2024-12-11 15:52:04 --> Router Class Initialized
INFO - 2024-12-11 15:52:04 --> Output Class Initialized
INFO - 2024-12-11 15:52:04 --> Security Class Initialized
DEBUG - 2024-12-11 15:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:52:04 --> CSRF cookie sent
INFO - 2024-12-11 15:52:04 --> CSRF token verified
INFO - 2024-12-11 15:52:04 --> Input Class Initialized
INFO - 2024-12-11 15:52:04 --> Language Class Initialized
INFO - 2024-12-11 15:52:04 --> Loader Class Initialized
INFO - 2024-12-11 15:52:04 --> Helper loaded: url_helper
INFO - 2024-12-11 15:52:04 --> Helper loaded: form_helper
INFO - 2024-12-11 15:52:04 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:52:04 --> Form Validation Class Initialized
INFO - 2024-12-11 15:52:04 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:52:04 --> Controller Class Initialized
INFO - 2024-12-11 15:52:04 --> Model "User_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "Category_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "Review_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "News_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:52:04 --> Config Class Initialized
INFO - 2024-12-11 15:52:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:52:04 --> Utf8 Class Initialized
INFO - 2024-12-11 15:52:04 --> URI Class Initialized
INFO - 2024-12-11 15:52:04 --> Router Class Initialized
INFO - 2024-12-11 15:52:04 --> Output Class Initialized
INFO - 2024-12-11 15:52:04 --> Security Class Initialized
DEBUG - 2024-12-11 15:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:52:04 --> CSRF cookie sent
INFO - 2024-12-11 15:52:04 --> Input Class Initialized
INFO - 2024-12-11 15:52:04 --> Language Class Initialized
INFO - 2024-12-11 15:52:04 --> Loader Class Initialized
INFO - 2024-12-11 15:52:04 --> Helper loaded: url_helper
INFO - 2024-12-11 15:52:04 --> Helper loaded: form_helper
INFO - 2024-12-11 15:52:04 --> Database Driver Class Initialized
DEBUG - 2024-12-11 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:52:04 --> Form Validation Class Initialized
INFO - 2024-12-11 15:52:04 --> Model "Culinary_model" initialized
INFO - 2024-12-11 15:52:04 --> Controller Class Initialized
INFO - 2024-12-11 15:52:04 --> Model "User_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "Category_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "Review_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "News_model" initialized
INFO - 2024-12-11 15:52:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 15:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:52:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 15:52:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 15:52:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-11 15:52:04 --> Final output sent to browser
DEBUG - 2024-12-11 15:52:04 --> Total execution time: 0.0550
INFO - 2024-12-11 16:17:27 --> Config Class Initialized
INFO - 2024-12-11 16:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:17:27 --> Utf8 Class Initialized
INFO - 2024-12-11 16:17:27 --> URI Class Initialized
INFO - 2024-12-11 16:17:27 --> Router Class Initialized
INFO - 2024-12-11 16:17:27 --> Output Class Initialized
INFO - 2024-12-11 16:17:27 --> Security Class Initialized
DEBUG - 2024-12-11 16:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:17:27 --> CSRF cookie sent
INFO - 2024-12-11 16:17:27 --> Input Class Initialized
INFO - 2024-12-11 16:17:27 --> Language Class Initialized
INFO - 2024-12-11 16:17:27 --> Loader Class Initialized
INFO - 2024-12-11 16:17:27 --> Helper loaded: url_helper
INFO - 2024-12-11 16:17:27 --> Helper loaded: form_helper
INFO - 2024-12-11 16:17:27 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:17:27 --> Form Validation Class Initialized
INFO - 2024-12-11 16:17:27 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:17:27 --> Controller Class Initialized
INFO - 2024-12-11 16:17:27 --> Model "User_model" initialized
INFO - 2024-12-11 16:17:27 --> Model "Category_model" initialized
INFO - 2024-12-11 16:17:27 --> Model "Review_model" initialized
INFO - 2024-12-11 16:17:27 --> Model "News_model" initialized
INFO - 2024-12-11 16:17:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:17:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
ERROR - 2024-12-11 16:17:27 --> Severity: Warning --> Undefined property: stdClass::$approved C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\makanan_berat.php 86
INFO - 2024-12-11 16:17:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:17:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:17:27 --> Final output sent to browser
DEBUG - 2024-12-11 16:17:27 --> Total execution time: 0.7691
INFO - 2024-12-11 16:19:03 --> Config Class Initialized
INFO - 2024-12-11 16:19:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:03 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:03 --> URI Class Initialized
INFO - 2024-12-11 16:19:03 --> Router Class Initialized
INFO - 2024-12-11 16:19:03 --> Output Class Initialized
INFO - 2024-12-11 16:19:03 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:03 --> CSRF cookie sent
INFO - 2024-12-11 16:19:03 --> Input Class Initialized
INFO - 2024-12-11 16:19:03 --> Language Class Initialized
INFO - 2024-12-11 16:19:03 --> Loader Class Initialized
INFO - 2024-12-11 16:19:03 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:03 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:03 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:03 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:03 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:03 --> Controller Class Initialized
INFO - 2024-12-11 16:19:03 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:03 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:03 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:03 --> Model "News_model" initialized
INFO - 2024-12-11 16:19:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:19:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:19:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:19:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:19:03 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:03 --> Total execution time: 0.0637
INFO - 2024-12-11 16:19:12 --> Config Class Initialized
INFO - 2024-12-11 16:19:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:12 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:12 --> URI Class Initialized
INFO - 2024-12-11 16:19:12 --> Router Class Initialized
INFO - 2024-12-11 16:19:12 --> Output Class Initialized
INFO - 2024-12-11 16:19:12 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:12 --> CSRF cookie sent
INFO - 2024-12-11 16:19:12 --> Input Class Initialized
INFO - 2024-12-11 16:19:12 --> Language Class Initialized
INFO - 2024-12-11 16:19:12 --> Loader Class Initialized
INFO - 2024-12-11 16:19:12 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:12 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:12 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:12 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:12 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:12 --> Controller Class Initialized
INFO - 2024-12-11 16:19:12 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:12 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:12 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:12 --> Model "News_model" initialized
INFO - 2024-12-11 16:19:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 16:19:12 --> Query result: stdClass Object
(
    [view_count] => 145
)

INFO - 2024-12-11 16:19:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:19:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:19:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 16:19:12 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:12 --> Total execution time: 0.1952
INFO - 2024-12-11 16:19:12 --> Config Class Initialized
INFO - 2024-12-11 16:19:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:12 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:12 --> URI Class Initialized
INFO - 2024-12-11 16:19:12 --> Router Class Initialized
INFO - 2024-12-11 16:19:12 --> Output Class Initialized
INFO - 2024-12-11 16:19:12 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:12 --> CSRF cookie sent
INFO - 2024-12-11 16:19:12 --> Input Class Initialized
INFO - 2024-12-11 16:19:12 --> Language Class Initialized
ERROR - 2024-12-11 16:19:12 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 16:19:15 --> Config Class Initialized
INFO - 2024-12-11 16:19:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:15 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:15 --> URI Class Initialized
INFO - 2024-12-11 16:19:15 --> Router Class Initialized
INFO - 2024-12-11 16:19:15 --> Output Class Initialized
INFO - 2024-12-11 16:19:15 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:15 --> CSRF cookie sent
INFO - 2024-12-11 16:19:15 --> Input Class Initialized
INFO - 2024-12-11 16:19:15 --> Language Class Initialized
INFO - 2024-12-11 16:19:15 --> Loader Class Initialized
INFO - 2024-12-11 16:19:15 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:15 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:15 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:15 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:15 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:15 --> Controller Class Initialized
INFO - 2024-12-11 16:19:15 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:15 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:15 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:15 --> Model "News_model" initialized
INFO - 2024-12-11 16:19:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:19:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:19:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:19:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 16:19:15 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:15 --> Total execution time: 0.0496
INFO - 2024-12-11 16:19:16 --> Config Class Initialized
INFO - 2024-12-11 16:19:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:16 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:16 --> URI Class Initialized
INFO - 2024-12-11 16:19:16 --> Router Class Initialized
INFO - 2024-12-11 16:19:16 --> Output Class Initialized
INFO - 2024-12-11 16:19:16 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:16 --> CSRF cookie sent
INFO - 2024-12-11 16:19:16 --> Input Class Initialized
INFO - 2024-12-11 16:19:16 --> Language Class Initialized
INFO - 2024-12-11 16:19:16 --> Loader Class Initialized
INFO - 2024-12-11 16:19:16 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:16 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:16 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:16 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:16 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:16 --> Controller Class Initialized
INFO - 2024-12-11 16:19:16 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:16 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:16 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:16 --> Model "News_model" initialized
INFO - 2024-12-11 16:19:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:19:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:19:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:19:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:19:16 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:16 --> Total execution time: 0.0525
INFO - 2024-12-11 16:19:48 --> Config Class Initialized
INFO - 2024-12-11 16:19:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:48 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:48 --> URI Class Initialized
INFO - 2024-12-11 16:19:48 --> Router Class Initialized
INFO - 2024-12-11 16:19:48 --> Output Class Initialized
INFO - 2024-12-11 16:19:48 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:48 --> CSRF cookie sent
INFO - 2024-12-11 16:19:48 --> Input Class Initialized
INFO - 2024-12-11 16:19:48 --> Language Class Initialized
INFO - 2024-12-11 16:19:48 --> Loader Class Initialized
INFO - 2024-12-11 16:19:48 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:48 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:48 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:48 --> Controller Class Initialized
INFO - 2024-12-11 16:19:48 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:48 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:48 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:48 --> Model "News_model" initialized
INFO - 2024-12-11 16:19:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:19:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:19:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:19:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:19:48 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:48 --> Total execution time: 0.0488
INFO - 2024-12-11 16:19:53 --> Config Class Initialized
INFO - 2024-12-11 16:19:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:53 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:53 --> URI Class Initialized
INFO - 2024-12-11 16:19:54 --> Router Class Initialized
INFO - 2024-12-11 16:19:54 --> Output Class Initialized
INFO - 2024-12-11 16:19:54 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:54 --> CSRF cookie sent
INFO - 2024-12-11 16:19:54 --> Input Class Initialized
INFO - 2024-12-11 16:19:54 --> Language Class Initialized
INFO - 2024-12-11 16:19:54 --> Loader Class Initialized
INFO - 2024-12-11 16:19:54 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:54 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:54 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:54 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:54 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:54 --> Controller Class Initialized
INFO - 2024-12-11 16:19:54 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:54 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:54 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:19:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:19:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 16:19:54 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:54 --> Total execution time: 0.0777
INFO - 2024-12-11 16:19:56 --> Config Class Initialized
INFO - 2024-12-11 16:19:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:19:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:19:56 --> Utf8 Class Initialized
INFO - 2024-12-11 16:19:56 --> URI Class Initialized
INFO - 2024-12-11 16:19:56 --> Router Class Initialized
INFO - 2024-12-11 16:19:56 --> Output Class Initialized
INFO - 2024-12-11 16:19:56 --> Security Class Initialized
DEBUG - 2024-12-11 16:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:19:56 --> CSRF cookie sent
INFO - 2024-12-11 16:19:56 --> Input Class Initialized
INFO - 2024-12-11 16:19:56 --> Language Class Initialized
INFO - 2024-12-11 16:19:56 --> Loader Class Initialized
INFO - 2024-12-11 16:19:56 --> Helper loaded: url_helper
INFO - 2024-12-11 16:19:56 --> Helper loaded: form_helper
INFO - 2024-12-11 16:19:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:19:56 --> Form Validation Class Initialized
INFO - 2024-12-11 16:19:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:19:56 --> Controller Class Initialized
INFO - 2024-12-11 16:19:56 --> Model "Review_model" initialized
INFO - 2024-12-11 16:19:56 --> Model "Category_model" initialized
INFO - 2024-12-11 16:19:56 --> Model "User_model" initialized
INFO - 2024-12-11 16:19:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:19:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:19:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-11 16:19:56 --> Final output sent to browser
DEBUG - 2024-12-11 16:19:56 --> Total execution time: 0.0741
INFO - 2024-12-11 16:20:49 --> Config Class Initialized
INFO - 2024-12-11 16:20:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:20:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:20:49 --> Utf8 Class Initialized
INFO - 2024-12-11 16:20:49 --> URI Class Initialized
INFO - 2024-12-11 16:20:49 --> Router Class Initialized
INFO - 2024-12-11 16:20:49 --> Output Class Initialized
INFO - 2024-12-11 16:20:49 --> Security Class Initialized
DEBUG - 2024-12-11 16:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:20:49 --> CSRF cookie sent
INFO - 2024-12-11 16:20:49 --> Input Class Initialized
INFO - 2024-12-11 16:20:49 --> Language Class Initialized
INFO - 2024-12-11 16:20:49 --> Loader Class Initialized
INFO - 2024-12-11 16:20:49 --> Helper loaded: url_helper
INFO - 2024-12-11 16:20:49 --> Helper loaded: form_helper
INFO - 2024-12-11 16:20:49 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:20:49 --> Form Validation Class Initialized
INFO - 2024-12-11 16:20:49 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:20:49 --> Controller Class Initialized
INFO - 2024-12-11 16:20:49 --> Model "User_model" initialized
INFO - 2024-12-11 16:20:49 --> Model "Category_model" initialized
INFO - 2024-12-11 16:20:49 --> Model "Review_model" initialized
INFO - 2024-12-11 16:20:49 --> Model "News_model" initialized
INFO - 2024-12-11 16:20:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:20:49 --> Config Class Initialized
INFO - 2024-12-11 16:20:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:20:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:20:49 --> Utf8 Class Initialized
INFO - 2024-12-11 16:20:49 --> URI Class Initialized
INFO - 2024-12-11 16:20:49 --> Router Class Initialized
INFO - 2024-12-11 16:20:49 --> Output Class Initialized
INFO - 2024-12-11 16:20:49 --> Security Class Initialized
DEBUG - 2024-12-11 16:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:20:49 --> CSRF cookie sent
INFO - 2024-12-11 16:20:49 --> Input Class Initialized
INFO - 2024-12-11 16:20:49 --> Language Class Initialized
INFO - 2024-12-11 16:20:49 --> Loader Class Initialized
INFO - 2024-12-11 16:20:49 --> Helper loaded: url_helper
INFO - 2024-12-11 16:20:49 --> Helper loaded: form_helper
INFO - 2024-12-11 16:20:49 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:20:50 --> Form Validation Class Initialized
INFO - 2024-12-11 16:20:50 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:20:50 --> Controller Class Initialized
INFO - 2024-12-11 16:20:50 --> Model "User_model" initialized
INFO - 2024-12-11 16:20:50 --> Model "Category_model" initialized
INFO - 2024-12-11 16:20:50 --> Model "Review_model" initialized
INFO - 2024-12-11 16:20:50 --> Model "News_model" initialized
INFO - 2024-12-11 16:20:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:20:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:20:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:20:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 16:20:50 --> Final output sent to browser
DEBUG - 2024-12-11 16:20:50 --> Total execution time: 0.0668
INFO - 2024-12-11 16:20:52 --> Config Class Initialized
INFO - 2024-12-11 16:20:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:20:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:20:52 --> Utf8 Class Initialized
INFO - 2024-12-11 16:20:52 --> URI Class Initialized
INFO - 2024-12-11 16:20:52 --> Router Class Initialized
INFO - 2024-12-11 16:20:52 --> Output Class Initialized
INFO - 2024-12-11 16:20:52 --> Security Class Initialized
DEBUG - 2024-12-11 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:20:52 --> CSRF cookie sent
INFO - 2024-12-11 16:20:52 --> Input Class Initialized
INFO - 2024-12-11 16:20:52 --> Language Class Initialized
INFO - 2024-12-11 16:20:52 --> Loader Class Initialized
INFO - 2024-12-11 16:20:52 --> Helper loaded: url_helper
INFO - 2024-12-11 16:20:52 --> Helper loaded: form_helper
INFO - 2024-12-11 16:20:52 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:20:52 --> Form Validation Class Initialized
INFO - 2024-12-11 16:20:52 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:20:52 --> Controller Class Initialized
INFO - 2024-12-11 16:20:52 --> Model "User_model" initialized
INFO - 2024-12-11 16:20:52 --> Model "Category_model" initialized
INFO - 2024-12-11 16:20:52 --> Model "Review_model" initialized
INFO - 2024-12-11 16:20:52 --> Model "News_model" initialized
INFO - 2024-12-11 16:20:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:20:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:20:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:20:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-11 16:20:52 --> Final output sent to browser
DEBUG - 2024-12-11 16:20:52 --> Total execution time: 0.0468
INFO - 2024-12-11 16:21:18 --> Config Class Initialized
INFO - 2024-12-11 16:21:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:18 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:18 --> URI Class Initialized
INFO - 2024-12-11 16:21:18 --> Router Class Initialized
INFO - 2024-12-11 16:21:18 --> Output Class Initialized
INFO - 2024-12-11 16:21:18 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:18 --> CSRF cookie sent
INFO - 2024-12-11 16:21:18 --> Input Class Initialized
INFO - 2024-12-11 16:21:18 --> Language Class Initialized
INFO - 2024-12-11 16:21:18 --> Loader Class Initialized
INFO - 2024-12-11 16:21:18 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:18 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:18 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:18 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:18 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:18 --> Controller Class Initialized
INFO - 2024-12-11 16:21:18 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:18 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:18 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:18 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-11 16:21:18 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:18 --> Total execution time: 0.0564
INFO - 2024-12-11 16:21:21 --> Config Class Initialized
INFO - 2024-12-11 16:21:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:21 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:21 --> URI Class Initialized
INFO - 2024-12-11 16:21:21 --> Router Class Initialized
INFO - 2024-12-11 16:21:21 --> Output Class Initialized
INFO - 2024-12-11 16:21:21 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:21 --> CSRF cookie sent
INFO - 2024-12-11 16:21:21 --> Input Class Initialized
INFO - 2024-12-11 16:21:21 --> Language Class Initialized
INFO - 2024-12-11 16:21:21 --> Loader Class Initialized
INFO - 2024-12-11 16:21:21 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:21 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:21 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:21 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:21 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:21 --> Controller Class Initialized
INFO - 2024-12-11 16:21:21 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:21 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:21 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:21 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 16:21:21 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:21 --> Total execution time: 0.0642
INFO - 2024-12-11 16:21:24 --> Config Class Initialized
INFO - 2024-12-11 16:21:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:24 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:24 --> URI Class Initialized
INFO - 2024-12-11 16:21:24 --> Router Class Initialized
INFO - 2024-12-11 16:21:24 --> Output Class Initialized
INFO - 2024-12-11 16:21:24 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:24 --> CSRF cookie sent
INFO - 2024-12-11 16:21:24 --> Input Class Initialized
INFO - 2024-12-11 16:21:24 --> Language Class Initialized
INFO - 2024-12-11 16:21:24 --> Loader Class Initialized
INFO - 2024-12-11 16:21:24 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:24 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:24 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:24 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:24 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:24 --> Controller Class Initialized
INFO - 2024-12-11 16:21:24 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:24 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:24 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:24 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 16:21:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-11 16:21:24 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:24 --> Total execution time: 0.0510
INFO - 2024-12-11 16:21:26 --> Config Class Initialized
INFO - 2024-12-11 16:21:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:26 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:26 --> URI Class Initialized
INFO - 2024-12-11 16:21:26 --> Router Class Initialized
INFO - 2024-12-11 16:21:26 --> Output Class Initialized
INFO - 2024-12-11 16:21:26 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:26 --> CSRF cookie sent
INFO - 2024-12-11 16:21:26 --> Input Class Initialized
INFO - 2024-12-11 16:21:26 --> Language Class Initialized
INFO - 2024-12-11 16:21:26 --> Loader Class Initialized
INFO - 2024-12-11 16:21:26 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:26 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:26 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:26 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:26 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:26 --> Controller Class Initialized
INFO - 2024-12-11 16:21:26 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:26 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:26 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:26 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 16:21:26 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:26 --> Total execution time: 0.0393
INFO - 2024-12-11 16:21:29 --> Config Class Initialized
INFO - 2024-12-11 16:21:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:29 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:29 --> URI Class Initialized
INFO - 2024-12-11 16:21:29 --> Router Class Initialized
INFO - 2024-12-11 16:21:29 --> Output Class Initialized
INFO - 2024-12-11 16:21:29 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:29 --> CSRF cookie sent
INFO - 2024-12-11 16:21:29 --> Input Class Initialized
INFO - 2024-12-11 16:21:29 --> Language Class Initialized
INFO - 2024-12-11 16:21:29 --> Loader Class Initialized
INFO - 2024-12-11 16:21:29 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:29 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:29 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:29 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:29 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:29 --> Controller Class Initialized
INFO - 2024-12-11 16:21:29 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:29 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:29 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:29 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 16:21:29 --> Query result: stdClass Object
(
    [view_count] => 146
)

INFO - 2024-12-11 16:21:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 16:21:29 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:29 --> Total execution time: 0.0531
INFO - 2024-12-11 16:21:29 --> Config Class Initialized
INFO - 2024-12-11 16:21:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:29 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:29 --> URI Class Initialized
INFO - 2024-12-11 16:21:29 --> Router Class Initialized
INFO - 2024-12-11 16:21:29 --> Output Class Initialized
INFO - 2024-12-11 16:21:29 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:29 --> CSRF cookie sent
INFO - 2024-12-11 16:21:29 --> Input Class Initialized
INFO - 2024-12-11 16:21:29 --> Language Class Initialized
ERROR - 2024-12-11 16:21:29 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 16:21:31 --> Config Class Initialized
INFO - 2024-12-11 16:21:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:31 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:31 --> URI Class Initialized
INFO - 2024-12-11 16:21:31 --> Router Class Initialized
INFO - 2024-12-11 16:21:31 --> Output Class Initialized
INFO - 2024-12-11 16:21:31 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:31 --> CSRF cookie sent
INFO - 2024-12-11 16:21:31 --> Input Class Initialized
INFO - 2024-12-11 16:21:31 --> Language Class Initialized
INFO - 2024-12-11 16:21:31 --> Loader Class Initialized
INFO - 2024-12-11 16:21:31 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:31 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:31 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:31 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:31 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:31 --> Controller Class Initialized
INFO - 2024-12-11 16:21:31 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:31 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:31 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:31 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 16:21:31 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:31 --> Total execution time: 0.0452
INFO - 2024-12-11 16:21:34 --> Config Class Initialized
INFO - 2024-12-11 16:21:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:34 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:34 --> URI Class Initialized
INFO - 2024-12-11 16:21:34 --> Router Class Initialized
INFO - 2024-12-11 16:21:34 --> Output Class Initialized
INFO - 2024-12-11 16:21:34 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:34 --> CSRF cookie sent
INFO - 2024-12-11 16:21:34 --> Input Class Initialized
INFO - 2024-12-11 16:21:34 --> Language Class Initialized
INFO - 2024-12-11 16:21:34 --> Loader Class Initialized
INFO - 2024-12-11 16:21:34 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:34 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:34 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:34 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:34 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:34 --> Controller Class Initialized
INFO - 2024-12-11 16:21:34 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:34 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:34 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:34 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-11 16:21:34 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:34 --> Total execution time: 0.0690
INFO - 2024-12-11 16:21:51 --> Config Class Initialized
INFO - 2024-12-11 16:21:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:51 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:51 --> URI Class Initialized
INFO - 2024-12-11 16:21:51 --> Router Class Initialized
INFO - 2024-12-11 16:21:51 --> Output Class Initialized
INFO - 2024-12-11 16:21:51 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:51 --> CSRF cookie sent
INFO - 2024-12-11 16:21:51 --> Input Class Initialized
INFO - 2024-12-11 16:21:51 --> Language Class Initialized
INFO - 2024-12-11 16:21:51 --> Loader Class Initialized
INFO - 2024-12-11 16:21:51 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:51 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:51 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:51 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:51 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:51 --> Controller Class Initialized
INFO - 2024-12-11 16:21:51 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:51 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:51 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:51 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-11 16:21:51 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:51 --> Total execution time: 0.0756
INFO - 2024-12-11 16:21:52 --> Config Class Initialized
INFO - 2024-12-11 16:21:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:52 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:52 --> URI Class Initialized
INFO - 2024-12-11 16:21:52 --> Router Class Initialized
INFO - 2024-12-11 16:21:53 --> Output Class Initialized
INFO - 2024-12-11 16:21:53 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:53 --> CSRF cookie sent
INFO - 2024-12-11 16:21:53 --> Input Class Initialized
INFO - 2024-12-11 16:21:53 --> Language Class Initialized
INFO - 2024-12-11 16:21:53 --> Loader Class Initialized
INFO - 2024-12-11 16:21:53 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:53 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:53 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:53 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:53 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:53 --> Controller Class Initialized
INFO - 2024-12-11 16:21:53 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:53 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:53 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:53 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 16:21:53 --> Query result: stdClass Object
(
    [view_count] => 147
)

INFO - 2024-12-11 16:21:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 16:21:53 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:53 --> Total execution time: 0.0734
INFO - 2024-12-11 16:21:53 --> Config Class Initialized
INFO - 2024-12-11 16:21:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:53 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:53 --> URI Class Initialized
INFO - 2024-12-11 16:21:53 --> Router Class Initialized
INFO - 2024-12-11 16:21:53 --> Output Class Initialized
INFO - 2024-12-11 16:21:53 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:53 --> CSRF cookie sent
INFO - 2024-12-11 16:21:53 --> Input Class Initialized
INFO - 2024-12-11 16:21:53 --> Language Class Initialized
ERROR - 2024-12-11 16:21:53 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 16:21:55 --> Config Class Initialized
INFO - 2024-12-11 16:21:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:21:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:21:55 --> Utf8 Class Initialized
INFO - 2024-12-11 16:21:55 --> URI Class Initialized
INFO - 2024-12-11 16:21:55 --> Router Class Initialized
INFO - 2024-12-11 16:21:55 --> Output Class Initialized
INFO - 2024-12-11 16:21:55 --> Security Class Initialized
DEBUG - 2024-12-11 16:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:21:55 --> CSRF cookie sent
INFO - 2024-12-11 16:21:55 --> Input Class Initialized
INFO - 2024-12-11 16:21:55 --> Language Class Initialized
INFO - 2024-12-11 16:21:55 --> Loader Class Initialized
INFO - 2024-12-11 16:21:55 --> Helper loaded: url_helper
INFO - 2024-12-11 16:21:55 --> Helper loaded: form_helper
INFO - 2024-12-11 16:21:55 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:21:55 --> Form Validation Class Initialized
INFO - 2024-12-11 16:21:55 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:21:55 --> Controller Class Initialized
INFO - 2024-12-11 16:21:55 --> Model "User_model" initialized
INFO - 2024-12-11 16:21:55 --> Model "Category_model" initialized
INFO - 2024-12-11 16:21:55 --> Model "Review_model" initialized
INFO - 2024-12-11 16:21:55 --> Model "News_model" initialized
INFO - 2024-12-11 16:21:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 16:21:55 --> Final output sent to browser
DEBUG - 2024-12-11 16:21:55 --> Total execution time: 0.0651
INFO - 2024-12-11 16:22:10 --> Config Class Initialized
INFO - 2024-12-11 16:22:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:22:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:22:10 --> Utf8 Class Initialized
INFO - 2024-12-11 16:22:10 --> URI Class Initialized
INFO - 2024-12-11 16:22:10 --> Router Class Initialized
INFO - 2024-12-11 16:22:10 --> Output Class Initialized
INFO - 2024-12-11 16:22:10 --> Security Class Initialized
DEBUG - 2024-12-11 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:22:10 --> CSRF cookie sent
INFO - 2024-12-11 16:22:10 --> Input Class Initialized
INFO - 2024-12-11 16:22:10 --> Language Class Initialized
INFO - 2024-12-11 16:22:10 --> Loader Class Initialized
INFO - 2024-12-11 16:22:10 --> Helper loaded: url_helper
INFO - 2024-12-11 16:22:10 --> Helper loaded: form_helper
INFO - 2024-12-11 16:22:10 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:22:10 --> Form Validation Class Initialized
INFO - 2024-12-11 16:22:10 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:22:10 --> Controller Class Initialized
INFO - 2024-12-11 16:22:10 --> Model "User_model" initialized
INFO - 2024-12-11 16:22:10 --> Model "Category_model" initialized
INFO - 2024-12-11 16:22:10 --> Model "Review_model" initialized
INFO - 2024-12-11 16:22:10 --> Model "News_model" initialized
INFO - 2024-12-11 16:22:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:22:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:22:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:22:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:22:10 --> Final output sent to browser
DEBUG - 2024-12-11 16:22:10 --> Total execution time: 0.0452
INFO - 2024-12-11 16:25:20 --> Config Class Initialized
INFO - 2024-12-11 16:25:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:25:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:25:20 --> Utf8 Class Initialized
INFO - 2024-12-11 16:25:20 --> URI Class Initialized
INFO - 2024-12-11 16:25:20 --> Router Class Initialized
INFO - 2024-12-11 16:25:20 --> Output Class Initialized
INFO - 2024-12-11 16:25:20 --> Security Class Initialized
DEBUG - 2024-12-11 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:25:20 --> CSRF cookie sent
INFO - 2024-12-11 16:25:20 --> CSRF token verified
INFO - 2024-12-11 16:25:20 --> Input Class Initialized
INFO - 2024-12-11 16:25:20 --> Language Class Initialized
INFO - 2024-12-11 16:25:20 --> Loader Class Initialized
INFO - 2024-12-11 16:25:20 --> Helper loaded: url_helper
INFO - 2024-12-11 16:25:20 --> Helper loaded: form_helper
INFO - 2024-12-11 16:25:20 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:25:20 --> Form Validation Class Initialized
INFO - 2024-12-11 16:25:20 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:25:20 --> Controller Class Initialized
INFO - 2024-12-11 16:25:20 --> Model "Review_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "Category_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "User_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:25:20 --> Upload Class Initialized
INFO - 2024-12-11 16:25:20 --> Config Class Initialized
INFO - 2024-12-11 16:25:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:25:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:25:20 --> Utf8 Class Initialized
INFO - 2024-12-11 16:25:20 --> URI Class Initialized
INFO - 2024-12-11 16:25:20 --> Router Class Initialized
INFO - 2024-12-11 16:25:20 --> Output Class Initialized
INFO - 2024-12-11 16:25:20 --> Security Class Initialized
DEBUG - 2024-12-11 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:25:20 --> CSRF cookie sent
INFO - 2024-12-11 16:25:20 --> Input Class Initialized
INFO - 2024-12-11 16:25:20 --> Language Class Initialized
INFO - 2024-12-11 16:25:20 --> Loader Class Initialized
INFO - 2024-12-11 16:25:20 --> Helper loaded: url_helper
INFO - 2024-12-11 16:25:20 --> Helper loaded: form_helper
INFO - 2024-12-11 16:25:20 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:25:20 --> Form Validation Class Initialized
INFO - 2024-12-11 16:25:20 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:25:20 --> Controller Class Initialized
INFO - 2024-12-11 16:25:20 --> Model "Review_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "Category_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "User_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:25:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:25:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 16:25:20 --> Final output sent to browser
DEBUG - 2024-12-11 16:25:20 --> Total execution time: 0.0742
INFO - 2024-12-11 16:25:24 --> Config Class Initialized
INFO - 2024-12-11 16:25:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:25:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:25:24 --> Utf8 Class Initialized
INFO - 2024-12-11 16:25:24 --> URI Class Initialized
INFO - 2024-12-11 16:25:24 --> Router Class Initialized
INFO - 2024-12-11 16:25:24 --> Output Class Initialized
INFO - 2024-12-11 16:25:25 --> Security Class Initialized
DEBUG - 2024-12-11 16:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:25:25 --> CSRF cookie sent
INFO - 2024-12-11 16:25:25 --> Input Class Initialized
INFO - 2024-12-11 16:25:25 --> Language Class Initialized
INFO - 2024-12-11 16:25:25 --> Loader Class Initialized
INFO - 2024-12-11 16:25:25 --> Helper loaded: url_helper
INFO - 2024-12-11 16:25:25 --> Helper loaded: form_helper
INFO - 2024-12-11 16:25:25 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:25:25 --> Form Validation Class Initialized
INFO - 2024-12-11 16:25:25 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:25:25 --> Controller Class Initialized
INFO - 2024-12-11 16:25:25 --> Model "User_model" initialized
INFO - 2024-12-11 16:25:25 --> Model "Category_model" initialized
INFO - 2024-12-11 16:25:25 --> Model "Review_model" initialized
INFO - 2024-12-11 16:25:25 --> Model "News_model" initialized
INFO - 2024-12-11 16:25:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:25:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:25:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:25:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:25:25 --> Final output sent to browser
DEBUG - 2024-12-11 16:25:25 --> Total execution time: 0.1043
INFO - 2024-12-11 16:29:12 --> Config Class Initialized
INFO - 2024-12-11 16:29:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:29:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:29:12 --> Utf8 Class Initialized
INFO - 2024-12-11 16:29:12 --> URI Class Initialized
INFO - 2024-12-11 16:29:12 --> Router Class Initialized
INFO - 2024-12-11 16:29:12 --> Output Class Initialized
INFO - 2024-12-11 16:29:12 --> Security Class Initialized
DEBUG - 2024-12-11 16:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:29:12 --> CSRF cookie sent
INFO - 2024-12-11 16:29:12 --> Input Class Initialized
INFO - 2024-12-11 16:29:12 --> Language Class Initialized
INFO - 2024-12-11 16:29:12 --> Loader Class Initialized
INFO - 2024-12-11 16:29:12 --> Helper loaded: url_helper
INFO - 2024-12-11 16:29:12 --> Helper loaded: form_helper
INFO - 2024-12-11 16:29:12 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:29:12 --> Form Validation Class Initialized
INFO - 2024-12-11 16:29:12 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:29:12 --> Controller Class Initialized
INFO - 2024-12-11 16:29:12 --> Model "Review_model" initialized
INFO - 2024-12-11 16:29:12 --> Model "Category_model" initialized
INFO - 2024-12-11 16:29:12 --> Model "User_model" initialized
INFO - 2024-12-11 16:29:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:29:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:29:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-11 16:29:12 --> Final output sent to browser
DEBUG - 2024-12-11 16:29:12 --> Total execution time: 0.1279
INFO - 2024-12-11 16:31:36 --> Config Class Initialized
INFO - 2024-12-11 16:31:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:36 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:36 --> URI Class Initialized
INFO - 2024-12-11 16:31:36 --> Router Class Initialized
INFO - 2024-12-11 16:31:36 --> Output Class Initialized
INFO - 2024-12-11 16:31:36 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:36 --> CSRF cookie sent
INFO - 2024-12-11 16:31:36 --> CSRF token verified
INFO - 2024-12-11 16:31:36 --> Input Class Initialized
INFO - 2024-12-11 16:31:36 --> Language Class Initialized
INFO - 2024-12-11 16:31:36 --> Loader Class Initialized
INFO - 2024-12-11 16:31:36 --> Helper loaded: url_helper
INFO - 2024-12-11 16:31:36 --> Helper loaded: form_helper
INFO - 2024-12-11 16:31:36 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:31:36 --> Form Validation Class Initialized
INFO - 2024-12-11 16:31:36 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:31:36 --> Controller Class Initialized
INFO - 2024-12-11 16:31:36 --> Model "Review_model" initialized
INFO - 2024-12-11 16:31:36 --> Model "Category_model" initialized
INFO - 2024-12-11 16:31:36 --> Model "User_model" initialized
INFO - 2024-12-11 16:31:36 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:31:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:31:36 --> Upload Class Initialized
INFO - 2024-12-11 16:31:37 --> Config Class Initialized
INFO - 2024-12-11 16:31:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:37 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:37 --> URI Class Initialized
INFO - 2024-12-11 16:31:37 --> Router Class Initialized
INFO - 2024-12-11 16:31:37 --> Output Class Initialized
INFO - 2024-12-11 16:31:37 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:37 --> CSRF cookie sent
INFO - 2024-12-11 16:31:37 --> Input Class Initialized
INFO - 2024-12-11 16:31:37 --> Language Class Initialized
INFO - 2024-12-11 16:31:37 --> Loader Class Initialized
INFO - 2024-12-11 16:31:37 --> Helper loaded: url_helper
INFO - 2024-12-11 16:31:37 --> Helper loaded: form_helper
INFO - 2024-12-11 16:31:37 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:31:37 --> Form Validation Class Initialized
INFO - 2024-12-11 16:31:37 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:31:37 --> Controller Class Initialized
INFO - 2024-12-11 16:31:37 --> Model "Review_model" initialized
INFO - 2024-12-11 16:31:37 --> Model "Category_model" initialized
INFO - 2024-12-11 16:31:37 --> Model "User_model" initialized
INFO - 2024-12-11 16:31:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-11 16:31:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:31:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-11 16:31:37 --> Final output sent to browser
DEBUG - 2024-12-11 16:31:37 --> Total execution time: 0.0623
INFO - 2024-12-11 16:31:39 --> Config Class Initialized
INFO - 2024-12-11 16:31:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:39 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:40 --> URI Class Initialized
INFO - 2024-12-11 16:31:40 --> Router Class Initialized
INFO - 2024-12-11 16:31:40 --> Output Class Initialized
INFO - 2024-12-11 16:31:40 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:40 --> CSRF cookie sent
INFO - 2024-12-11 16:31:40 --> Input Class Initialized
INFO - 2024-12-11 16:31:40 --> Language Class Initialized
INFO - 2024-12-11 16:31:40 --> Loader Class Initialized
INFO - 2024-12-11 16:31:40 --> Helper loaded: url_helper
INFO - 2024-12-11 16:31:40 --> Helper loaded: form_helper
INFO - 2024-12-11 16:31:40 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:31:40 --> Form Validation Class Initialized
INFO - 2024-12-11 16:31:40 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:31:40 --> Controller Class Initialized
INFO - 2024-12-11 16:31:40 --> Model "User_model" initialized
INFO - 2024-12-11 16:31:40 --> Model "Category_model" initialized
INFO - 2024-12-11 16:31:40 --> Model "Review_model" initialized
INFO - 2024-12-11 16:31:40 --> Model "News_model" initialized
INFO - 2024-12-11 16:31:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:31:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:31:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:31:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-11 16:31:40 --> Final output sent to browser
DEBUG - 2024-12-11 16:31:40 --> Total execution time: 0.2266
INFO - 2024-12-11 16:31:48 --> Config Class Initialized
INFO - 2024-12-11 16:31:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:48 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:48 --> URI Class Initialized
INFO - 2024-12-11 16:31:48 --> Router Class Initialized
INFO - 2024-12-11 16:31:48 --> Output Class Initialized
INFO - 2024-12-11 16:31:48 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:48 --> CSRF cookie sent
INFO - 2024-12-11 16:31:48 --> Input Class Initialized
INFO - 2024-12-11 16:31:48 --> Language Class Initialized
INFO - 2024-12-11 16:31:48 --> Loader Class Initialized
INFO - 2024-12-11 16:31:48 --> Helper loaded: url_helper
INFO - 2024-12-11 16:31:48 --> Helper loaded: form_helper
INFO - 2024-12-11 16:31:48 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:31:48 --> Form Validation Class Initialized
INFO - 2024-12-11 16:31:48 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:31:48 --> Controller Class Initialized
INFO - 2024-12-11 16:31:48 --> Model "User_model" initialized
INFO - 2024-12-11 16:31:48 --> Model "Category_model" initialized
INFO - 2024-12-11 16:31:48 --> Model "Review_model" initialized
INFO - 2024-12-11 16:31:48 --> Model "News_model" initialized
INFO - 2024-12-11 16:31:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:31:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:31:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:31:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-11 16:31:48 --> Final output sent to browser
DEBUG - 2024-12-11 16:31:48 --> Total execution time: 0.0717
INFO - 2024-12-11 16:31:56 --> Config Class Initialized
INFO - 2024-12-11 16:31:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:56 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:56 --> URI Class Initialized
INFO - 2024-12-11 16:31:56 --> Router Class Initialized
INFO - 2024-12-11 16:31:56 --> Output Class Initialized
INFO - 2024-12-11 16:31:56 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:56 --> CSRF cookie sent
INFO - 2024-12-11 16:31:56 --> Input Class Initialized
INFO - 2024-12-11 16:31:56 --> Language Class Initialized
INFO - 2024-12-11 16:31:56 --> Loader Class Initialized
INFO - 2024-12-11 16:31:56 --> Helper loaded: url_helper
INFO - 2024-12-11 16:31:56 --> Helper loaded: form_helper
INFO - 2024-12-11 16:31:56 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:31:56 --> Form Validation Class Initialized
INFO - 2024-12-11 16:31:56 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:31:56 --> Controller Class Initialized
INFO - 2024-12-11 16:31:56 --> Model "User_model" initialized
INFO - 2024-12-11 16:31:56 --> Model "Category_model" initialized
INFO - 2024-12-11 16:31:56 --> Model "Review_model" initialized
INFO - 2024-12-11 16:31:56 --> Model "News_model" initialized
INFO - 2024-12-11 16:31:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:31:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:31:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:31:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-11 16:31:56 --> Final output sent to browser
DEBUG - 2024-12-11 16:31:56 --> Total execution time: 0.0815
INFO - 2024-12-11 16:31:58 --> Config Class Initialized
INFO - 2024-12-11 16:31:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:58 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:58 --> URI Class Initialized
INFO - 2024-12-11 16:31:58 --> Router Class Initialized
INFO - 2024-12-11 16:31:58 --> Output Class Initialized
INFO - 2024-12-11 16:31:58 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:58 --> CSRF cookie sent
INFO - 2024-12-11 16:31:58 --> Input Class Initialized
INFO - 2024-12-11 16:31:58 --> Language Class Initialized
INFO - 2024-12-11 16:31:58 --> Loader Class Initialized
INFO - 2024-12-11 16:31:58 --> Helper loaded: url_helper
INFO - 2024-12-11 16:31:58 --> Helper loaded: form_helper
INFO - 2024-12-11 16:31:58 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:31:58 --> Form Validation Class Initialized
INFO - 2024-12-11 16:31:58 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:31:58 --> Controller Class Initialized
INFO - 2024-12-11 16:31:58 --> Model "User_model" initialized
INFO - 2024-12-11 16:31:58 --> Model "Category_model" initialized
INFO - 2024-12-11 16:31:58 --> Model "Review_model" initialized
INFO - 2024-12-11 16:31:58 --> Model "News_model" initialized
INFO - 2024-12-11 16:31:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:31:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-11 16:31:58 --> Query result: stdClass Object
(
    [view_count] => 148
)

INFO - 2024-12-11 16:31:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:31:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:31:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-11 16:31:58 --> Final output sent to browser
DEBUG - 2024-12-11 16:31:58 --> Total execution time: 0.1355
INFO - 2024-12-11 16:31:58 --> Config Class Initialized
INFO - 2024-12-11 16:31:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:31:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:31:58 --> Utf8 Class Initialized
INFO - 2024-12-11 16:31:58 --> URI Class Initialized
INFO - 2024-12-11 16:31:58 --> Router Class Initialized
INFO - 2024-12-11 16:31:58 --> Output Class Initialized
INFO - 2024-12-11 16:31:58 --> Security Class Initialized
DEBUG - 2024-12-11 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:31:58 --> CSRF cookie sent
INFO - 2024-12-11 16:31:58 --> Input Class Initialized
INFO - 2024-12-11 16:31:58 --> Language Class Initialized
ERROR - 2024-12-11 16:31:58 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-11 16:32:02 --> Config Class Initialized
INFO - 2024-12-11 16:32:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:32:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:32:02 --> Utf8 Class Initialized
INFO - 2024-12-11 16:32:02 --> URI Class Initialized
INFO - 2024-12-11 16:32:02 --> Router Class Initialized
INFO - 2024-12-11 16:32:02 --> Output Class Initialized
INFO - 2024-12-11 16:32:02 --> Security Class Initialized
DEBUG - 2024-12-11 16:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:32:02 --> CSRF cookie sent
INFO - 2024-12-11 16:32:02 --> Input Class Initialized
INFO - 2024-12-11 16:32:02 --> Language Class Initialized
INFO - 2024-12-11 16:32:02 --> Loader Class Initialized
INFO - 2024-12-11 16:32:02 --> Helper loaded: url_helper
INFO - 2024-12-11 16:32:02 --> Helper loaded: form_helper
INFO - 2024-12-11 16:32:02 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:32:02 --> Form Validation Class Initialized
INFO - 2024-12-11 16:32:02 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:32:02 --> Controller Class Initialized
INFO - 2024-12-11 16:32:02 --> Model "User_model" initialized
INFO - 2024-12-11 16:32:02 --> Model "Category_model" initialized
INFO - 2024-12-11 16:32:02 --> Model "Review_model" initialized
INFO - 2024-12-11 16:32:02 --> Model "News_model" initialized
INFO - 2024-12-11 16:32:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:32:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:32:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:32:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_ringan.php
INFO - 2024-12-11 16:32:02 --> Final output sent to browser
DEBUG - 2024-12-11 16:32:02 --> Total execution time: 0.0578
INFO - 2024-12-11 16:35:54 --> Config Class Initialized
INFO - 2024-12-11 16:35:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:35:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:35:54 --> Utf8 Class Initialized
INFO - 2024-12-11 16:35:54 --> URI Class Initialized
INFO - 2024-12-11 16:35:54 --> Router Class Initialized
INFO - 2024-12-11 16:35:54 --> Output Class Initialized
INFO - 2024-12-11 16:35:54 --> Security Class Initialized
DEBUG - 2024-12-11 16:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:35:54 --> CSRF cookie sent
INFO - 2024-12-11 16:35:54 --> Input Class Initialized
INFO - 2024-12-11 16:35:54 --> Language Class Initialized
INFO - 2024-12-11 16:35:54 --> Loader Class Initialized
INFO - 2024-12-11 16:35:54 --> Helper loaded: url_helper
INFO - 2024-12-11 16:35:54 --> Helper loaded: form_helper
INFO - 2024-12-11 16:35:54 --> Database Driver Class Initialized
DEBUG - 2024-12-11 16:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:35:54 --> Form Validation Class Initialized
INFO - 2024-12-11 16:35:54 --> Model "Culinary_model" initialized
INFO - 2024-12-11 16:35:54 --> Controller Class Initialized
INFO - 2024-12-11 16:35:54 --> Model "User_model" initialized
INFO - 2024-12-11 16:35:54 --> Model "Category_model" initialized
INFO - 2024-12-11 16:35:54 --> Model "Review_model" initialized
INFO - 2024-12-11 16:35:54 --> Model "News_model" initialized
INFO - 2024-12-11 16:35:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-11 16:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:35:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-11 16:35:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-11 16:35:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/minuman.php
INFO - 2024-12-11 16:35:54 --> Final output sent to browser
DEBUG - 2024-12-11 16:35:54 --> Total execution time: 0.1143
