<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-09 04:48:18 --> Config Class Initialized
INFO - 2024-12-09 04:48:18 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:48:18 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:48:18 --> Utf8 Class Initialized
INFO - 2024-12-09 04:48:18 --> URI Class Initialized
INFO - 2024-12-09 04:48:18 --> Router Class Initialized
INFO - 2024-12-09 04:48:18 --> Output Class Initialized
INFO - 2024-12-09 04:48:18 --> Security Class Initialized
DEBUG - 2024-12-09 04:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:48:18 --> CSRF cookie sent
INFO - 2024-12-09 04:48:18 --> Input Class Initialized
INFO - 2024-12-09 04:48:18 --> Language Class Initialized
INFO - 2024-12-09 04:48:18 --> Loader Class Initialized
INFO - 2024-12-09 04:48:18 --> Helper loaded: url_helper
INFO - 2024-12-09 04:48:18 --> Helper loaded: form_helper
INFO - 2024-12-09 04:48:18 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:48:18 --> Form Validation Class Initialized
INFO - 2024-12-09 04:48:18 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:48:18 --> Controller Class Initialized
INFO - 2024-12-09 04:48:18 --> Model "Review_model" initialized
INFO - 2024-12-09 04:48:18 --> Model "Category_model" initialized
INFO - 2024-12-09 04:48:18 --> Model "User_model" initialized
INFO - 2024-12-09 04:48:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 04:48:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:48:19 --> Config Class Initialized
INFO - 2024-12-09 04:48:19 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:48:19 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:48:19 --> Utf8 Class Initialized
INFO - 2024-12-09 04:48:19 --> URI Class Initialized
INFO - 2024-12-09 04:48:19 --> Router Class Initialized
INFO - 2024-12-09 04:48:19 --> Output Class Initialized
INFO - 2024-12-09 04:48:19 --> Security Class Initialized
DEBUG - 2024-12-09 04:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:48:19 --> CSRF cookie sent
INFO - 2024-12-09 04:48:19 --> Input Class Initialized
INFO - 2024-12-09 04:48:19 --> Language Class Initialized
INFO - 2024-12-09 04:48:19 --> Loader Class Initialized
INFO - 2024-12-09 04:48:19 --> Helper loaded: url_helper
INFO - 2024-12-09 04:48:19 --> Helper loaded: form_helper
INFO - 2024-12-09 04:48:19 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:48:19 --> Form Validation Class Initialized
INFO - 2024-12-09 04:48:19 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:48:19 --> Controller Class Initialized
INFO - 2024-12-09 04:48:19 --> Model "Review_model" initialized
INFO - 2024-12-09 04:48:19 --> Model "Category_model" initialized
INFO - 2024-12-09 04:48:19 --> Model "User_model" initialized
INFO - 2024-12-09 04:48:19 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 04:48:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:48:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:48:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:48:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-09 04:48:19 --> Final output sent to browser
DEBUG - 2024-12-09 04:48:19 --> Total execution time: 0.0559
INFO - 2024-12-09 04:48:51 --> Config Class Initialized
INFO - 2024-12-09 04:48:51 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:48:51 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:48:51 --> Utf8 Class Initialized
INFO - 2024-12-09 04:48:51 --> URI Class Initialized
INFO - 2024-12-09 04:48:51 --> Router Class Initialized
INFO - 2024-12-09 04:48:51 --> Output Class Initialized
INFO - 2024-12-09 04:48:51 --> Security Class Initialized
DEBUG - 2024-12-09 04:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:48:51 --> CSRF cookie sent
INFO - 2024-12-09 04:48:51 --> Input Class Initialized
INFO - 2024-12-09 04:48:51 --> Language Class Initialized
INFO - 2024-12-09 04:48:51 --> Loader Class Initialized
INFO - 2024-12-09 04:48:51 --> Helper loaded: url_helper
INFO - 2024-12-09 04:48:51 --> Helper loaded: form_helper
INFO - 2024-12-09 04:48:51 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:48:51 --> Form Validation Class Initialized
INFO - 2024-12-09 04:48:51 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:48:51 --> Controller Class Initialized
INFO - 2024-12-09 04:48:51 --> Model "User_model" initialized
INFO - 2024-12-09 04:48:51 --> Model "Category_model" initialized
INFO - 2024-12-09 04:48:51 --> Model "Review_model" initialized
INFO - 2024-12-09 04:48:51 --> Model "News_model" initialized
INFO - 2024-12-09 04:48:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:48:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:48:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:48:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 04:48:51 --> Final output sent to browser
DEBUG - 2024-12-09 04:48:51 --> Total execution time: 0.0858
INFO - 2024-12-09 04:48:52 --> Config Class Initialized
INFO - 2024-12-09 04:48:52 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:48:52 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:48:52 --> Utf8 Class Initialized
INFO - 2024-12-09 04:48:52 --> URI Class Initialized
INFO - 2024-12-09 04:48:52 --> Router Class Initialized
INFO - 2024-12-09 04:48:52 --> Output Class Initialized
INFO - 2024-12-09 04:48:52 --> Security Class Initialized
DEBUG - 2024-12-09 04:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:48:52 --> CSRF cookie sent
INFO - 2024-12-09 04:48:52 --> Input Class Initialized
INFO - 2024-12-09 04:48:52 --> Language Class Initialized
INFO - 2024-12-09 04:48:52 --> Loader Class Initialized
INFO - 2024-12-09 04:48:52 --> Helper loaded: url_helper
INFO - 2024-12-09 04:48:52 --> Helper loaded: form_helper
INFO - 2024-12-09 04:48:52 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:48:52 --> Form Validation Class Initialized
INFO - 2024-12-09 04:48:52 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:48:52 --> Controller Class Initialized
INFO - 2024-12-09 04:48:52 --> Model "User_model" initialized
INFO - 2024-12-09 04:48:52 --> Model "Category_model" initialized
INFO - 2024-12-09 04:48:52 --> Model "Review_model" initialized
INFO - 2024-12-09 04:48:52 --> Model "News_model" initialized
INFO - 2024-12-09 04:48:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 04:48:52 --> Query result: stdClass Object
(
    [view_count] => 97
)

INFO - 2024-12-09 04:48:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:48:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:48:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 04:48:52 --> Final output sent to browser
DEBUG - 2024-12-09 04:48:52 --> Total execution time: 0.3334
INFO - 2024-12-09 04:49:00 --> Config Class Initialized
INFO - 2024-12-09 04:49:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:00 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:00 --> URI Class Initialized
INFO - 2024-12-09 04:49:00 --> Router Class Initialized
INFO - 2024-12-09 04:49:00 --> Output Class Initialized
INFO - 2024-12-09 04:49:00 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:00 --> CSRF cookie sent
INFO - 2024-12-09 04:49:00 --> CSRF token verified
INFO - 2024-12-09 04:49:00 --> Input Class Initialized
INFO - 2024-12-09 04:49:00 --> Language Class Initialized
INFO - 2024-12-09 04:49:00 --> Loader Class Initialized
INFO - 2024-12-09 04:49:00 --> Helper loaded: url_helper
INFO - 2024-12-09 04:49:00 --> Helper loaded: form_helper
INFO - 2024-12-09 04:49:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:49:00 --> Form Validation Class Initialized
INFO - 2024-12-09 04:49:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:49:00 --> Controller Class Initialized
INFO - 2024-12-09 04:49:00 --> Model "User_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "Category_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "Review_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "News_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:49:00 --> Config Class Initialized
INFO - 2024-12-09 04:49:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:00 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:00 --> URI Class Initialized
INFO - 2024-12-09 04:49:00 --> Router Class Initialized
INFO - 2024-12-09 04:49:00 --> Output Class Initialized
INFO - 2024-12-09 04:49:00 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:00 --> CSRF cookie sent
INFO - 2024-12-09 04:49:00 --> Input Class Initialized
INFO - 2024-12-09 04:49:00 --> Language Class Initialized
INFO - 2024-12-09 04:49:00 --> Loader Class Initialized
INFO - 2024-12-09 04:49:00 --> Helper loaded: url_helper
INFO - 2024-12-09 04:49:00 --> Helper loaded: form_helper
INFO - 2024-12-09 04:49:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:49:00 --> Form Validation Class Initialized
INFO - 2024-12-09 04:49:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:49:00 --> Controller Class Initialized
INFO - 2024-12-09 04:49:00 --> Model "Review_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "Category_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "User_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 04:49:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 04:49:00 --> Query result: stdClass Object
(
    [view_count] => 97
)

INFO - 2024-12-09 04:49:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-09 04:49:00 --> Final output sent to browser
DEBUG - 2024-12-09 04:49:00 --> Total execution time: 0.0692
INFO - 2024-12-09 04:49:51 --> Config Class Initialized
INFO - 2024-12-09 04:49:51 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:51 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:51 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:51 --> URI Class Initialized
INFO - 2024-12-09 04:49:51 --> Router Class Initialized
INFO - 2024-12-09 04:49:51 --> Output Class Initialized
INFO - 2024-12-09 04:49:51 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:51 --> CSRF cookie sent
INFO - 2024-12-09 04:49:51 --> Input Class Initialized
INFO - 2024-12-09 04:49:51 --> Language Class Initialized
INFO - 2024-12-09 04:49:51 --> Loader Class Initialized
INFO - 2024-12-09 04:49:51 --> Helper loaded: url_helper
INFO - 2024-12-09 04:49:51 --> Helper loaded: form_helper
INFO - 2024-12-09 04:49:51 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:49:51 --> Form Validation Class Initialized
INFO - 2024-12-09 04:49:51 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:49:51 --> Controller Class Initialized
INFO - 2024-12-09 04:49:51 --> Model "User_model" initialized
INFO - 2024-12-09 04:49:51 --> Model "Category_model" initialized
INFO - 2024-12-09 04:49:51 --> Model "Review_model" initialized
INFO - 2024-12-09 04:49:51 --> Model "News_model" initialized
INFO - 2024-12-09 04:49:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:49:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 04:49:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:49:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:49:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:49:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-09 04:49:51 --> Final output sent to browser
DEBUG - 2024-12-09 04:49:51 --> Total execution time: 0.0963
INFO - 2024-12-09 04:49:53 --> Config Class Initialized
INFO - 2024-12-09 04:49:53 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:53 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:53 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:53 --> URI Class Initialized
INFO - 2024-12-09 04:49:53 --> Router Class Initialized
INFO - 2024-12-09 04:49:53 --> Output Class Initialized
INFO - 2024-12-09 04:49:53 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:53 --> CSRF cookie sent
INFO - 2024-12-09 04:49:53 --> Input Class Initialized
INFO - 2024-12-09 04:49:53 --> Language Class Initialized
INFO - 2024-12-09 04:49:53 --> Loader Class Initialized
INFO - 2024-12-09 04:49:53 --> Helper loaded: url_helper
INFO - 2024-12-09 04:49:53 --> Helper loaded: form_helper
INFO - 2024-12-09 04:49:53 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:49:53 --> Form Validation Class Initialized
INFO - 2024-12-09 04:49:53 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:49:53 --> Controller Class Initialized
INFO - 2024-12-09 04:49:53 --> Model "User_model" initialized
INFO - 2024-12-09 04:49:53 --> Model "Category_model" initialized
INFO - 2024-12-09 04:49:53 --> Model "Review_model" initialized
INFO - 2024-12-09 04:49:53 --> Model "News_model" initialized
INFO - 2024-12-09 04:49:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:49:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:49:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:49:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 04:49:53 --> Final output sent to browser
DEBUG - 2024-12-09 04:49:53 --> Total execution time: 0.0427
INFO - 2024-12-09 04:49:57 --> Config Class Initialized
INFO - 2024-12-09 04:49:57 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:57 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:57 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:57 --> URI Class Initialized
INFO - 2024-12-09 04:49:57 --> Router Class Initialized
INFO - 2024-12-09 04:49:57 --> Output Class Initialized
INFO - 2024-12-09 04:49:57 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:57 --> CSRF cookie sent
INFO - 2024-12-09 04:49:57 --> CSRF token verified
INFO - 2024-12-09 04:49:57 --> Input Class Initialized
INFO - 2024-12-09 04:49:57 --> Language Class Initialized
INFO - 2024-12-09 04:49:57 --> Loader Class Initialized
INFO - 2024-12-09 04:49:57 --> Helper loaded: url_helper
INFO - 2024-12-09 04:49:57 --> Helper loaded: form_helper
INFO - 2024-12-09 04:49:57 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:49:57 --> Form Validation Class Initialized
INFO - 2024-12-09 04:49:57 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:49:57 --> Controller Class Initialized
INFO - 2024-12-09 04:49:57 --> Model "User_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "Category_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "Review_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "News_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:49:57 --> Config Class Initialized
INFO - 2024-12-09 04:49:57 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:57 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:57 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:57 --> URI Class Initialized
INFO - 2024-12-09 04:49:57 --> Router Class Initialized
INFO - 2024-12-09 04:49:57 --> Output Class Initialized
INFO - 2024-12-09 04:49:57 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:57 --> CSRF cookie sent
INFO - 2024-12-09 04:49:57 --> Input Class Initialized
INFO - 2024-12-09 04:49:57 --> Language Class Initialized
INFO - 2024-12-09 04:49:57 --> Loader Class Initialized
INFO - 2024-12-09 04:49:57 --> Helper loaded: url_helper
INFO - 2024-12-09 04:49:57 --> Helper loaded: form_helper
INFO - 2024-12-09 04:49:57 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:49:57 --> Form Validation Class Initialized
INFO - 2024-12-09 04:49:57 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:49:57 --> Controller Class Initialized
INFO - 2024-12-09 04:49:57 --> Model "User_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "Category_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "Review_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "News_model" initialized
INFO - 2024-12-09 04:49:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:49:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 04:49:57 --> Query result: stdClass Object
(
    [view_count] => 98
)

INFO - 2024-12-09 04:49:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:49:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:49:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 04:49:57 --> Final output sent to browser
DEBUG - 2024-12-09 04:49:57 --> Total execution time: 0.0461
INFO - 2024-12-09 04:49:57 --> Config Class Initialized
INFO - 2024-12-09 04:49:57 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:49:57 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:49:57 --> Utf8 Class Initialized
INFO - 2024-12-09 04:49:57 --> URI Class Initialized
INFO - 2024-12-09 04:49:57 --> Router Class Initialized
INFO - 2024-12-09 04:49:57 --> Output Class Initialized
INFO - 2024-12-09 04:49:57 --> Security Class Initialized
DEBUG - 2024-12-09 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:49:57 --> CSRF cookie sent
INFO - 2024-12-09 04:49:57 --> Input Class Initialized
INFO - 2024-12-09 04:49:57 --> Language Class Initialized
ERROR - 2024-12-09 04:49:57 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 04:50:12 --> Config Class Initialized
INFO - 2024-12-09 04:50:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:50:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:50:12 --> Utf8 Class Initialized
INFO - 2024-12-09 04:50:12 --> URI Class Initialized
INFO - 2024-12-09 04:50:12 --> Router Class Initialized
INFO - 2024-12-09 04:50:12 --> Output Class Initialized
INFO - 2024-12-09 04:50:12 --> Security Class Initialized
DEBUG - 2024-12-09 04:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:50:12 --> CSRF cookie sent
INFO - 2024-12-09 04:50:12 --> Input Class Initialized
INFO - 2024-12-09 04:50:12 --> Language Class Initialized
INFO - 2024-12-09 04:50:12 --> Loader Class Initialized
INFO - 2024-12-09 04:50:12 --> Helper loaded: url_helper
INFO - 2024-12-09 04:50:12 --> Helper loaded: form_helper
INFO - 2024-12-09 04:50:12 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:50:12 --> Form Validation Class Initialized
INFO - 2024-12-09 04:50:12 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:50:12 --> Controller Class Initialized
INFO - 2024-12-09 04:50:12 --> Model "User_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "Category_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "Review_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "News_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:50:12 --> Config Class Initialized
INFO - 2024-12-09 04:50:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:50:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:50:12 --> Utf8 Class Initialized
INFO - 2024-12-09 04:50:12 --> URI Class Initialized
INFO - 2024-12-09 04:50:12 --> Router Class Initialized
INFO - 2024-12-09 04:50:12 --> Output Class Initialized
INFO - 2024-12-09 04:50:12 --> Security Class Initialized
DEBUG - 2024-12-09 04:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:50:12 --> CSRF cookie sent
INFO - 2024-12-09 04:50:12 --> Input Class Initialized
INFO - 2024-12-09 04:50:12 --> Language Class Initialized
INFO - 2024-12-09 04:50:12 --> Loader Class Initialized
INFO - 2024-12-09 04:50:12 --> Helper loaded: url_helper
INFO - 2024-12-09 04:50:12 --> Helper loaded: form_helper
INFO - 2024-12-09 04:50:12 --> Database Driver Class Initialized
DEBUG - 2024-12-09 04:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:50:12 --> Form Validation Class Initialized
INFO - 2024-12-09 04:50:12 --> Model "Culinary_model" initialized
INFO - 2024-12-09 04:50:12 --> Controller Class Initialized
INFO - 2024-12-09 04:50:12 --> Model "User_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "Category_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "Review_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "News_model" initialized
INFO - 2024-12-09 04:50:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 04:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:50:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 04:50:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 04:50:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 04:50:12 --> Final output sent to browser
DEBUG - 2024-12-09 04:50:12 --> Total execution time: 0.0470
INFO - 2024-12-09 06:43:34 --> Config Class Initialized
INFO - 2024-12-09 06:43:34 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:34 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:34 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:34 --> URI Class Initialized
INFO - 2024-12-09 06:43:34 --> Router Class Initialized
INFO - 2024-12-09 06:43:34 --> Output Class Initialized
INFO - 2024-12-09 06:43:34 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:34 --> CSRF cookie sent
INFO - 2024-12-09 06:43:34 --> Input Class Initialized
INFO - 2024-12-09 06:43:34 --> Language Class Initialized
INFO - 2024-12-09 06:43:34 --> Loader Class Initialized
INFO - 2024-12-09 06:43:34 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:34 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:34 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:34 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:34 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:34 --> Controller Class Initialized
INFO - 2024-12-09 06:43:34 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:34 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:34 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 06:43:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:43:34 --> Config Class Initialized
INFO - 2024-12-09 06:43:34 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:34 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:34 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:34 --> URI Class Initialized
INFO - 2024-12-09 06:43:34 --> Router Class Initialized
INFO - 2024-12-09 06:43:34 --> Output Class Initialized
INFO - 2024-12-09 06:43:34 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:34 --> CSRF cookie sent
INFO - 2024-12-09 06:43:34 --> Input Class Initialized
INFO - 2024-12-09 06:43:34 --> Language Class Initialized
INFO - 2024-12-09 06:43:34 --> Loader Class Initialized
INFO - 2024-12-09 06:43:34 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:34 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:35 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:35 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:35 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:35 --> Controller Class Initialized
INFO - 2024-12-09 06:43:35 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:35 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:35 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 06:43:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:43:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 06:43:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 06:43:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-09 06:43:35 --> Final output sent to browser
DEBUG - 2024-12-09 06:43:35 --> Total execution time: 0.0971
INFO - 2024-12-09 06:43:45 --> Config Class Initialized
INFO - 2024-12-09 06:43:45 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:45 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:45 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:45 --> URI Class Initialized
INFO - 2024-12-09 06:43:45 --> Router Class Initialized
INFO - 2024-12-09 06:43:45 --> Output Class Initialized
INFO - 2024-12-09 06:43:45 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:45 --> CSRF cookie sent
INFO - 2024-12-09 06:43:45 --> CSRF token verified
INFO - 2024-12-09 06:43:45 --> Input Class Initialized
INFO - 2024-12-09 06:43:45 --> Language Class Initialized
INFO - 2024-12-09 06:43:45 --> Loader Class Initialized
INFO - 2024-12-09 06:43:45 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:45 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:45 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:45 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:45 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:45 --> Controller Class Initialized
INFO - 2024-12-09 06:43:45 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "News_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:43:45 --> Config Class Initialized
INFO - 2024-12-09 06:43:45 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:45 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:45 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:45 --> URI Class Initialized
INFO - 2024-12-09 06:43:45 --> Router Class Initialized
INFO - 2024-12-09 06:43:45 --> Output Class Initialized
INFO - 2024-12-09 06:43:45 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:45 --> CSRF cookie sent
INFO - 2024-12-09 06:43:45 --> Input Class Initialized
INFO - 2024-12-09 06:43:45 --> Language Class Initialized
INFO - 2024-12-09 06:43:45 --> Loader Class Initialized
INFO - 2024-12-09 06:43:45 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:45 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:45 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:45 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:45 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:45 --> Controller Class Initialized
INFO - 2024-12-09 06:43:45 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 06:43:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 06:43:45 --> Query result: stdClass Object
(
    [view_count] => 98
)

INFO - 2024-12-09 06:43:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-09 06:43:45 --> Final output sent to browser
DEBUG - 2024-12-09 06:43:45 --> Total execution time: 0.1399
INFO - 2024-12-09 06:43:47 --> Config Class Initialized
INFO - 2024-12-09 06:43:47 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:47 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:47 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:47 --> URI Class Initialized
INFO - 2024-12-09 06:43:47 --> Router Class Initialized
INFO - 2024-12-09 06:43:47 --> Output Class Initialized
INFO - 2024-12-09 06:43:47 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:47 --> CSRF cookie sent
INFO - 2024-12-09 06:43:47 --> Input Class Initialized
INFO - 2024-12-09 06:43:47 --> Language Class Initialized
INFO - 2024-12-09 06:43:47 --> Loader Class Initialized
INFO - 2024-12-09 06:43:47 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:47 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:47 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:47 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:47 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:47 --> Controller Class Initialized
INFO - 2024-12-09 06:43:47 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:47 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:47 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:47 --> Model "News_model" initialized
INFO - 2024-12-09 06:43:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:43:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 06:43:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 06:43:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 06:43:47 --> Final output sent to browser
DEBUG - 2024-12-09 06:43:47 --> Total execution time: 0.1042
INFO - 2024-12-09 06:43:55 --> Config Class Initialized
INFO - 2024-12-09 06:43:55 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:55 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:55 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:56 --> URI Class Initialized
INFO - 2024-12-09 06:43:56 --> Router Class Initialized
INFO - 2024-12-09 06:43:56 --> Output Class Initialized
INFO - 2024-12-09 06:43:56 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:56 --> CSRF cookie sent
INFO - 2024-12-09 06:43:56 --> CSRF token verified
INFO - 2024-12-09 06:43:56 --> Input Class Initialized
INFO - 2024-12-09 06:43:56 --> Language Class Initialized
INFO - 2024-12-09 06:43:56 --> Loader Class Initialized
INFO - 2024-12-09 06:43:56 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:56 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:56 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:56 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:56 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:56 --> Controller Class Initialized
INFO - 2024-12-09 06:43:56 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:56 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:56 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:56 --> Model "News_model" initialized
INFO - 2024-12-09 06:43:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:43:57 --> Config Class Initialized
INFO - 2024-12-09 06:43:57 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:43:57 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:43:57 --> Utf8 Class Initialized
INFO - 2024-12-09 06:43:57 --> URI Class Initialized
INFO - 2024-12-09 06:43:57 --> Router Class Initialized
INFO - 2024-12-09 06:43:57 --> Output Class Initialized
INFO - 2024-12-09 06:43:57 --> Security Class Initialized
DEBUG - 2024-12-09 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:43:57 --> CSRF cookie sent
INFO - 2024-12-09 06:43:57 --> Input Class Initialized
INFO - 2024-12-09 06:43:57 --> Language Class Initialized
INFO - 2024-12-09 06:43:57 --> Loader Class Initialized
INFO - 2024-12-09 06:43:57 --> Helper loaded: url_helper
INFO - 2024-12-09 06:43:57 --> Helper loaded: form_helper
INFO - 2024-12-09 06:43:57 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:43:57 --> Form Validation Class Initialized
INFO - 2024-12-09 06:43:57 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:43:57 --> Controller Class Initialized
INFO - 2024-12-09 06:43:57 --> Model "User_model" initialized
INFO - 2024-12-09 06:43:57 --> Model "Category_model" initialized
INFO - 2024-12-09 06:43:57 --> Model "Review_model" initialized
INFO - 2024-12-09 06:43:57 --> Model "News_model" initialized
INFO - 2024-12-09 06:43:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 06:43:57 --> Query result: stdClass Object
(
    [view_count] => 99
)

INFO - 2024-12-09 06:43:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 06:43:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 06:43:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 06:43:57 --> Final output sent to browser
DEBUG - 2024-12-09 06:43:57 --> Total execution time: 0.3344
INFO - 2024-12-09 06:44:01 --> Config Class Initialized
INFO - 2024-12-09 06:44:01 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:44:01 --> Utf8 Class Initialized
INFO - 2024-12-09 06:44:01 --> URI Class Initialized
INFO - 2024-12-09 06:44:01 --> Router Class Initialized
INFO - 2024-12-09 06:44:01 --> Output Class Initialized
INFO - 2024-12-09 06:44:01 --> Security Class Initialized
DEBUG - 2024-12-09 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:44:01 --> CSRF cookie sent
INFO - 2024-12-09 06:44:01 --> Input Class Initialized
INFO - 2024-12-09 06:44:01 --> Language Class Initialized
ERROR - 2024-12-09 06:44:01 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 06:53:07 --> Config Class Initialized
INFO - 2024-12-09 06:53:07 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:53:07 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:53:07 --> Utf8 Class Initialized
INFO - 2024-12-09 06:53:07 --> URI Class Initialized
INFO - 2024-12-09 06:53:07 --> Router Class Initialized
INFO - 2024-12-09 06:53:07 --> Output Class Initialized
INFO - 2024-12-09 06:53:07 --> Security Class Initialized
DEBUG - 2024-12-09 06:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:53:07 --> CSRF cookie sent
INFO - 2024-12-09 06:53:07 --> Input Class Initialized
INFO - 2024-12-09 06:53:07 --> Language Class Initialized
INFO - 2024-12-09 06:53:07 --> Loader Class Initialized
INFO - 2024-12-09 06:53:07 --> Helper loaded: url_helper
INFO - 2024-12-09 06:53:07 --> Helper loaded: form_helper
INFO - 2024-12-09 06:53:07 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:53:07 --> Form Validation Class Initialized
INFO - 2024-12-09 06:53:07 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:53:07 --> Controller Class Initialized
INFO - 2024-12-09 06:53:07 --> Model "Review_model" initialized
INFO - 2024-12-09 06:53:07 --> Model "Category_model" initialized
INFO - 2024-12-09 06:53:07 --> Model "User_model" initialized
INFO - 2024-12-09 06:53:07 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 06:53:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:53:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-09 06:53:07 --> Final output sent to browser
DEBUG - 2024-12-09 06:53:07 --> Total execution time: 0.0970
INFO - 2024-12-09 06:53:10 --> Config Class Initialized
INFO - 2024-12-09 06:53:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:53:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:53:10 --> Utf8 Class Initialized
INFO - 2024-12-09 06:53:10 --> URI Class Initialized
INFO - 2024-12-09 06:53:10 --> Router Class Initialized
INFO - 2024-12-09 06:53:10 --> Output Class Initialized
INFO - 2024-12-09 06:53:10 --> Security Class Initialized
DEBUG - 2024-12-09 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:53:10 --> CSRF cookie sent
INFO - 2024-12-09 06:53:10 --> Input Class Initialized
INFO - 2024-12-09 06:53:10 --> Language Class Initialized
INFO - 2024-12-09 06:53:10 --> Loader Class Initialized
INFO - 2024-12-09 06:53:10 --> Helper loaded: url_helper
INFO - 2024-12-09 06:53:10 --> Helper loaded: form_helper
INFO - 2024-12-09 06:53:10 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:53:10 --> Form Validation Class Initialized
INFO - 2024-12-09 06:53:10 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:53:10 --> Controller Class Initialized
INFO - 2024-12-09 06:53:10 --> Model "News_model" initialized
INFO - 2024-12-09 06:53:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-09 06:53:10 --> Final output sent to browser
DEBUG - 2024-12-09 06:53:10 --> Total execution time: 0.0687
INFO - 2024-12-09 06:53:13 --> Config Class Initialized
INFO - 2024-12-09 06:53:13 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:53:13 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:53:13 --> Utf8 Class Initialized
INFO - 2024-12-09 06:53:13 --> URI Class Initialized
INFO - 2024-12-09 06:53:13 --> Router Class Initialized
INFO - 2024-12-09 06:53:13 --> Output Class Initialized
INFO - 2024-12-09 06:53:13 --> Security Class Initialized
DEBUG - 2024-12-09 06:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:53:13 --> CSRF cookie sent
INFO - 2024-12-09 06:53:13 --> Input Class Initialized
INFO - 2024-12-09 06:53:13 --> Language Class Initialized
INFO - 2024-12-09 06:53:13 --> Loader Class Initialized
INFO - 2024-12-09 06:53:13 --> Helper loaded: url_helper
INFO - 2024-12-09 06:53:13 --> Helper loaded: form_helper
INFO - 2024-12-09 06:53:13 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:53:13 --> Form Validation Class Initialized
INFO - 2024-12-09 06:53:13 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:53:13 --> Controller Class Initialized
INFO - 2024-12-09 06:53:13 --> Model "Review_model" initialized
INFO - 2024-12-09 06:53:13 --> Model "Category_model" initialized
INFO - 2024-12-09 06:53:13 --> Model "User_model" initialized
INFO - 2024-12-09 06:53:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 06:53:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:53:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-09 06:53:13 --> Final output sent to browser
DEBUG - 2024-12-09 06:53:13 --> Total execution time: 0.0590
INFO - 2024-12-09 06:53:15 --> Config Class Initialized
INFO - 2024-12-09 06:53:15 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:53:15 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:53:15 --> Utf8 Class Initialized
INFO - 2024-12-09 06:53:15 --> URI Class Initialized
INFO - 2024-12-09 06:53:15 --> Router Class Initialized
INFO - 2024-12-09 06:53:15 --> Output Class Initialized
INFO - 2024-12-09 06:53:15 --> Security Class Initialized
DEBUG - 2024-12-09 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:53:15 --> CSRF cookie sent
INFO - 2024-12-09 06:53:15 --> Input Class Initialized
INFO - 2024-12-09 06:53:15 --> Language Class Initialized
INFO - 2024-12-09 06:53:15 --> Loader Class Initialized
INFO - 2024-12-09 06:53:15 --> Helper loaded: url_helper
INFO - 2024-12-09 06:53:15 --> Helper loaded: form_helper
INFO - 2024-12-09 06:53:15 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:53:15 --> Form Validation Class Initialized
INFO - 2024-12-09 06:53:15 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:53:15 --> Controller Class Initialized
INFO - 2024-12-09 06:53:15 --> Model "Review_model" initialized
INFO - 2024-12-09 06:53:15 --> Model "Category_model" initialized
INFO - 2024-12-09 06:53:15 --> Model "User_model" initialized
INFO - 2024-12-09 06:53:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 06:53:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:53:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-09 06:53:15 --> Final output sent to browser
DEBUG - 2024-12-09 06:53:15 --> Total execution time: 0.0752
INFO - 2024-12-09 06:53:32 --> Config Class Initialized
INFO - 2024-12-09 06:53:32 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:53:32 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:53:32 --> Utf8 Class Initialized
INFO - 2024-12-09 06:53:32 --> URI Class Initialized
INFO - 2024-12-09 06:53:32 --> Router Class Initialized
INFO - 2024-12-09 06:53:32 --> Output Class Initialized
INFO - 2024-12-09 06:53:32 --> Security Class Initialized
DEBUG - 2024-12-09 06:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:53:32 --> CSRF cookie sent
INFO - 2024-12-09 06:53:32 --> Input Class Initialized
INFO - 2024-12-09 06:53:32 --> Language Class Initialized
INFO - 2024-12-09 06:53:32 --> Loader Class Initialized
INFO - 2024-12-09 06:53:32 --> Helper loaded: url_helper
INFO - 2024-12-09 06:53:32 --> Helper loaded: form_helper
INFO - 2024-12-09 06:53:32 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:53:32 --> Form Validation Class Initialized
INFO - 2024-12-09 06:53:32 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:53:32 --> Controller Class Initialized
INFO - 2024-12-09 06:53:32 --> Model "User_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "Category_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "Review_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "News_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:53:32 --> Config Class Initialized
INFO - 2024-12-09 06:53:32 --> Hooks Class Initialized
DEBUG - 2024-12-09 06:53:32 --> UTF-8 Support Enabled
INFO - 2024-12-09 06:53:32 --> Utf8 Class Initialized
INFO - 2024-12-09 06:53:32 --> URI Class Initialized
INFO - 2024-12-09 06:53:32 --> Router Class Initialized
INFO - 2024-12-09 06:53:32 --> Output Class Initialized
INFO - 2024-12-09 06:53:32 --> Security Class Initialized
DEBUG - 2024-12-09 06:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 06:53:32 --> CSRF cookie sent
INFO - 2024-12-09 06:53:32 --> Input Class Initialized
INFO - 2024-12-09 06:53:32 --> Language Class Initialized
INFO - 2024-12-09 06:53:32 --> Loader Class Initialized
INFO - 2024-12-09 06:53:32 --> Helper loaded: url_helper
INFO - 2024-12-09 06:53:32 --> Helper loaded: form_helper
INFO - 2024-12-09 06:53:32 --> Database Driver Class Initialized
DEBUG - 2024-12-09 06:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 06:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 06:53:32 --> Form Validation Class Initialized
INFO - 2024-12-09 06:53:32 --> Model "Culinary_model" initialized
INFO - 2024-12-09 06:53:32 --> Controller Class Initialized
INFO - 2024-12-09 06:53:32 --> Model "User_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "Category_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "Review_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "News_model" initialized
INFO - 2024-12-09 06:53:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 06:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 06:53:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 06:53:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 06:53:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 06:53:32 --> Final output sent to browser
DEBUG - 2024-12-09 06:53:32 --> Total execution time: 0.0538
INFO - 2024-12-09 07:24:07 --> Config Class Initialized
INFO - 2024-12-09 07:24:07 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:07 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:07 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:07 --> URI Class Initialized
INFO - 2024-12-09 07:24:07 --> Router Class Initialized
INFO - 2024-12-09 07:24:07 --> Output Class Initialized
INFO - 2024-12-09 07:24:07 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:07 --> CSRF cookie sent
INFO - 2024-12-09 07:24:07 --> Input Class Initialized
INFO - 2024-12-09 07:24:07 --> Language Class Initialized
INFO - 2024-12-09 07:24:07 --> Loader Class Initialized
INFO - 2024-12-09 07:24:07 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:07 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:07 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:07 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:07 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:07 --> Controller Class Initialized
INFO - 2024-12-09 07:24:07 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:07 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:07 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:07 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:24:07 --> Query result: stdClass Object
(
    [view_count] => 100
)

INFO - 2024-12-09 07:24:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:24:07 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:07 --> Total execution time: 0.1252
INFO - 2024-12-09 07:24:08 --> Config Class Initialized
INFO - 2024-12-09 07:24:08 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:08 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:08 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:08 --> URI Class Initialized
INFO - 2024-12-09 07:24:08 --> Router Class Initialized
INFO - 2024-12-09 07:24:08 --> Output Class Initialized
INFO - 2024-12-09 07:24:08 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:08 --> CSRF cookie sent
INFO - 2024-12-09 07:24:08 --> Input Class Initialized
INFO - 2024-12-09 07:24:08 --> Language Class Initialized
ERROR - 2024-12-09 07:24:08 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:24:13 --> Config Class Initialized
INFO - 2024-12-09 07:24:13 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:13 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:13 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:13 --> URI Class Initialized
INFO - 2024-12-09 07:24:13 --> Router Class Initialized
INFO - 2024-12-09 07:24:13 --> Output Class Initialized
INFO - 2024-12-09 07:24:13 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:13 --> CSRF cookie sent
INFO - 2024-12-09 07:24:13 --> Input Class Initialized
INFO - 2024-12-09 07:24:13 --> Language Class Initialized
INFO - 2024-12-09 07:24:13 --> Loader Class Initialized
INFO - 2024-12-09 07:24:13 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:13 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:13 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:13 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:13 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:13 --> Controller Class Initialized
INFO - 2024-12-09 07:24:13 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:13 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:13 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:13 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:24:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 07:24:13 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:13 --> Total execution time: 0.0776
INFO - 2024-12-09 07:24:17 --> Config Class Initialized
INFO - 2024-12-09 07:24:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:17 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:17 --> URI Class Initialized
INFO - 2024-12-09 07:24:17 --> Router Class Initialized
INFO - 2024-12-09 07:24:17 --> Output Class Initialized
INFO - 2024-12-09 07:24:17 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:17 --> CSRF cookie sent
INFO - 2024-12-09 07:24:17 --> CSRF token verified
INFO - 2024-12-09 07:24:17 --> Input Class Initialized
INFO - 2024-12-09 07:24:17 --> Language Class Initialized
INFO - 2024-12-09 07:24:17 --> Loader Class Initialized
INFO - 2024-12-09 07:24:17 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:17 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:17 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:17 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:17 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:17 --> Controller Class Initialized
INFO - 2024-12-09 07:24:17 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:24:17 --> Config Class Initialized
INFO - 2024-12-09 07:24:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:17 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:17 --> URI Class Initialized
INFO - 2024-12-09 07:24:17 --> Router Class Initialized
INFO - 2024-12-09 07:24:17 --> Output Class Initialized
INFO - 2024-12-09 07:24:17 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:17 --> CSRF cookie sent
INFO - 2024-12-09 07:24:17 --> Input Class Initialized
INFO - 2024-12-09 07:24:17 --> Language Class Initialized
INFO - 2024-12-09 07:24:17 --> Loader Class Initialized
INFO - 2024-12-09 07:24:17 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:17 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:17 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:17 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:17 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:17 --> Controller Class Initialized
INFO - 2024-12-09 07:24:17 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:24:17 --> Query result: stdClass Object
(
    [view_count] => 101
)

INFO - 2024-12-09 07:24:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:24:17 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:17 --> Total execution time: 0.0620
INFO - 2024-12-09 07:24:17 --> Config Class Initialized
INFO - 2024-12-09 07:24:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:17 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:17 --> URI Class Initialized
INFO - 2024-12-09 07:24:17 --> Router Class Initialized
INFO - 2024-12-09 07:24:17 --> Output Class Initialized
INFO - 2024-12-09 07:24:17 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:17 --> CSRF cookie sent
INFO - 2024-12-09 07:24:17 --> Input Class Initialized
INFO - 2024-12-09 07:24:17 --> Language Class Initialized
ERROR - 2024-12-09 07:24:17 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:24:19 --> Config Class Initialized
INFO - 2024-12-09 07:24:19 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:19 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:19 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:19 --> URI Class Initialized
INFO - 2024-12-09 07:24:19 --> Router Class Initialized
INFO - 2024-12-09 07:24:19 --> Output Class Initialized
INFO - 2024-12-09 07:24:19 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:19 --> CSRF cookie sent
INFO - 2024-12-09 07:24:19 --> Input Class Initialized
INFO - 2024-12-09 07:24:19 --> Language Class Initialized
INFO - 2024-12-09 07:24:19 --> Loader Class Initialized
INFO - 2024-12-09 07:24:19 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:19 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:19 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:19 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:19 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:19 --> Controller Class Initialized
INFO - 2024-12-09 07:24:19 --> Model "User_model" initialized
DEBUG - 2024-12-09 07:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:24:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-09 07:24:19 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:19 --> Total execution time: 0.0674
INFO - 2024-12-09 07:24:23 --> Config Class Initialized
INFO - 2024-12-09 07:24:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:23 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:23 --> URI Class Initialized
INFO - 2024-12-09 07:24:23 --> Router Class Initialized
INFO - 2024-12-09 07:24:23 --> Output Class Initialized
INFO - 2024-12-09 07:24:23 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:23 --> CSRF cookie sent
INFO - 2024-12-09 07:24:23 --> Input Class Initialized
INFO - 2024-12-09 07:24:23 --> Language Class Initialized
INFO - 2024-12-09 07:24:23 --> Loader Class Initialized
INFO - 2024-12-09 07:24:23 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:23 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:23 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:23 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:23 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:23 --> Controller Class Initialized
INFO - 2024-12-09 07:24:23 --> Model "User_model" initialized
DEBUG - 2024-12-09 07:24:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:24:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:24:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-09 07:24:23 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:23 --> Total execution time: 0.0600
INFO - 2024-12-09 07:24:35 --> Config Class Initialized
INFO - 2024-12-09 07:24:35 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:35 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:35 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:35 --> URI Class Initialized
INFO - 2024-12-09 07:24:35 --> Router Class Initialized
INFO - 2024-12-09 07:24:35 --> Output Class Initialized
INFO - 2024-12-09 07:24:35 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:35 --> CSRF cookie sent
INFO - 2024-12-09 07:24:35 --> Input Class Initialized
INFO - 2024-12-09 07:24:35 --> Language Class Initialized
INFO - 2024-12-09 07:24:35 --> Loader Class Initialized
INFO - 2024-12-09 07:24:35 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:35 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:35 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:35 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:35 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:35 --> Controller Class Initialized
INFO - 2024-12-09 07:24:35 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:35 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:35 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:35 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:24:35 --> Query result: stdClass Object
(
    [view_count] => 102
)

INFO - 2024-12-09 07:24:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:24:35 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:35 --> Total execution time: 0.0809
INFO - 2024-12-09 07:24:35 --> Config Class Initialized
INFO - 2024-12-09 07:24:35 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:35 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:35 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:35 --> URI Class Initialized
INFO - 2024-12-09 07:24:35 --> Router Class Initialized
INFO - 2024-12-09 07:24:35 --> Output Class Initialized
INFO - 2024-12-09 07:24:35 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:35 --> CSRF cookie sent
INFO - 2024-12-09 07:24:35 --> Input Class Initialized
INFO - 2024-12-09 07:24:35 --> Language Class Initialized
ERROR - 2024-12-09 07:24:35 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:24:44 --> Config Class Initialized
INFO - 2024-12-09 07:24:44 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:44 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:44 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:44 --> URI Class Initialized
INFO - 2024-12-09 07:24:44 --> Router Class Initialized
INFO - 2024-12-09 07:24:44 --> Output Class Initialized
INFO - 2024-12-09 07:24:44 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:44 --> CSRF cookie sent
INFO - 2024-12-09 07:24:44 --> Input Class Initialized
INFO - 2024-12-09 07:24:44 --> Language Class Initialized
INFO - 2024-12-09 07:24:44 --> Loader Class Initialized
INFO - 2024-12-09 07:24:44 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:44 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:44 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:44 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:44 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:44 --> Controller Class Initialized
INFO - 2024-12-09 07:24:44 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:24:44 --> Config Class Initialized
INFO - 2024-12-09 07:24:44 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:44 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:44 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:44 --> URI Class Initialized
INFO - 2024-12-09 07:24:44 --> Router Class Initialized
INFO - 2024-12-09 07:24:44 --> Output Class Initialized
INFO - 2024-12-09 07:24:44 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:44 --> CSRF cookie sent
INFO - 2024-12-09 07:24:44 --> Input Class Initialized
INFO - 2024-12-09 07:24:44 --> Language Class Initialized
INFO - 2024-12-09 07:24:44 --> Loader Class Initialized
INFO - 2024-12-09 07:24:44 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:44 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:44 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:44 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:44 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:44 --> Controller Class Initialized
INFO - 2024-12-09 07:24:44 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:24:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 07:24:44 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:44 --> Total execution time: 0.0517
INFO - 2024-12-09 07:24:46 --> Config Class Initialized
INFO - 2024-12-09 07:24:46 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:46 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:46 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:46 --> URI Class Initialized
INFO - 2024-12-09 07:24:46 --> Router Class Initialized
INFO - 2024-12-09 07:24:46 --> Output Class Initialized
INFO - 2024-12-09 07:24:46 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:46 --> CSRF cookie sent
INFO - 2024-12-09 07:24:46 --> Input Class Initialized
INFO - 2024-12-09 07:24:46 --> Language Class Initialized
INFO - 2024-12-09 07:24:46 --> Loader Class Initialized
INFO - 2024-12-09 07:24:46 --> Helper loaded: url_helper
INFO - 2024-12-09 07:24:46 --> Helper loaded: form_helper
INFO - 2024-12-09 07:24:46 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:24:46 --> Form Validation Class Initialized
INFO - 2024-12-09 07:24:46 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:24:46 --> Controller Class Initialized
INFO - 2024-12-09 07:24:46 --> Model "User_model" initialized
INFO - 2024-12-09 07:24:46 --> Model "Category_model" initialized
INFO - 2024-12-09 07:24:46 --> Model "Review_model" initialized
INFO - 2024-12-09 07:24:46 --> Model "News_model" initialized
INFO - 2024-12-09 07:24:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:24:46 --> Query result: stdClass Object
(
    [view_count] => 103
)

INFO - 2024-12-09 07:24:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:24:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:24:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:24:46 --> Final output sent to browser
DEBUG - 2024-12-09 07:24:46 --> Total execution time: 0.0634
INFO - 2024-12-09 07:24:46 --> Config Class Initialized
INFO - 2024-12-09 07:24:46 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:24:46 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:24:46 --> Utf8 Class Initialized
INFO - 2024-12-09 07:24:46 --> URI Class Initialized
INFO - 2024-12-09 07:24:46 --> Router Class Initialized
INFO - 2024-12-09 07:24:46 --> Output Class Initialized
INFO - 2024-12-09 07:24:46 --> Security Class Initialized
DEBUG - 2024-12-09 07:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:24:46 --> CSRF cookie sent
INFO - 2024-12-09 07:24:46 --> Input Class Initialized
INFO - 2024-12-09 07:24:46 --> Language Class Initialized
ERROR - 2024-12-09 07:24:46 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:25:00 --> Config Class Initialized
INFO - 2024-12-09 07:25:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:00 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:00 --> URI Class Initialized
INFO - 2024-12-09 07:25:00 --> Router Class Initialized
INFO - 2024-12-09 07:25:00 --> Output Class Initialized
INFO - 2024-12-09 07:25:00 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:00 --> CSRF cookie sent
INFO - 2024-12-09 07:25:00 --> Input Class Initialized
INFO - 2024-12-09 07:25:00 --> Language Class Initialized
INFO - 2024-12-09 07:25:00 --> Loader Class Initialized
INFO - 2024-12-09 07:25:00 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:00 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:00 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:00 --> Controller Class Initialized
INFO - 2024-12-09 07:25:00 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:00 --> Config Class Initialized
INFO - 2024-12-09 07:25:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:00 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:00 --> URI Class Initialized
INFO - 2024-12-09 07:25:00 --> Router Class Initialized
INFO - 2024-12-09 07:25:00 --> Output Class Initialized
INFO - 2024-12-09 07:25:00 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:00 --> CSRF cookie sent
INFO - 2024-12-09 07:25:00 --> Input Class Initialized
INFO - 2024-12-09 07:25:00 --> Language Class Initialized
INFO - 2024-12-09 07:25:00 --> Loader Class Initialized
INFO - 2024-12-09 07:25:00 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:00 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:00 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:00 --> Controller Class Initialized
INFO - 2024-12-09 07:25:00 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 07:25:00 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:00 --> Total execution time: 0.0508
INFO - 2024-12-09 07:25:04 --> Config Class Initialized
INFO - 2024-12-09 07:25:04 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:04 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:04 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:04 --> URI Class Initialized
INFO - 2024-12-09 07:25:04 --> Router Class Initialized
INFO - 2024-12-09 07:25:04 --> Output Class Initialized
INFO - 2024-12-09 07:25:04 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:04 --> CSRF cookie sent
INFO - 2024-12-09 07:25:04 --> Input Class Initialized
INFO - 2024-12-09 07:25:04 --> Language Class Initialized
INFO - 2024-12-09 07:25:04 --> Loader Class Initialized
INFO - 2024-12-09 07:25:04 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:04 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:04 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:04 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:04 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:04 --> Controller Class Initialized
INFO - 2024-12-09 07:25:04 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:04 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:04 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:04 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:25:04 --> Query result: stdClass Object
(
    [view_count] => 104
)

INFO - 2024-12-09 07:25:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:25:04 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:04 --> Total execution time: 0.0854
INFO - 2024-12-09 07:25:04 --> Config Class Initialized
INFO - 2024-12-09 07:25:04 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:04 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:04 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:04 --> URI Class Initialized
INFO - 2024-12-09 07:25:04 --> Router Class Initialized
INFO - 2024-12-09 07:25:04 --> Output Class Initialized
INFO - 2024-12-09 07:25:04 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:04 --> CSRF cookie sent
INFO - 2024-12-09 07:25:04 --> Input Class Initialized
INFO - 2024-12-09 07:25:04 --> Language Class Initialized
ERROR - 2024-12-09 07:25:04 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:25:12 --> Config Class Initialized
INFO - 2024-12-09 07:25:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:12 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:12 --> URI Class Initialized
INFO - 2024-12-09 07:25:12 --> Router Class Initialized
INFO - 2024-12-09 07:25:12 --> Output Class Initialized
INFO - 2024-12-09 07:25:12 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:12 --> CSRF cookie sent
INFO - 2024-12-09 07:25:12 --> Input Class Initialized
INFO - 2024-12-09 07:25:12 --> Language Class Initialized
INFO - 2024-12-09 07:25:12 --> Loader Class Initialized
INFO - 2024-12-09 07:25:12 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:12 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:12 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:12 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:12 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:12 --> Controller Class Initialized
INFO - 2024-12-09 07:25:12 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:12 --> Config Class Initialized
INFO - 2024-12-09 07:25:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:12 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:12 --> URI Class Initialized
INFO - 2024-12-09 07:25:12 --> Router Class Initialized
INFO - 2024-12-09 07:25:12 --> Output Class Initialized
INFO - 2024-12-09 07:25:12 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:12 --> CSRF cookie sent
INFO - 2024-12-09 07:25:12 --> Input Class Initialized
INFO - 2024-12-09 07:25:12 --> Language Class Initialized
INFO - 2024-12-09 07:25:12 --> Loader Class Initialized
INFO - 2024-12-09 07:25:12 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:12 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:12 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:12 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:12 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:12 --> Controller Class Initialized
INFO - 2024-12-09 07:25:12 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 07:25:12 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:12 --> Total execution time: 0.0644
INFO - 2024-12-09 07:25:18 --> Config Class Initialized
INFO - 2024-12-09 07:25:18 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:18 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:18 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:18 --> URI Class Initialized
INFO - 2024-12-09 07:25:18 --> Router Class Initialized
INFO - 2024-12-09 07:25:18 --> Output Class Initialized
INFO - 2024-12-09 07:25:18 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:18 --> CSRF cookie sent
INFO - 2024-12-09 07:25:18 --> CSRF token verified
INFO - 2024-12-09 07:25:18 --> Input Class Initialized
INFO - 2024-12-09 07:25:18 --> Language Class Initialized
INFO - 2024-12-09 07:25:18 --> Loader Class Initialized
INFO - 2024-12-09 07:25:18 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:18 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:18 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:18 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:18 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:18 --> Controller Class Initialized
INFO - 2024-12-09 07:25:18 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:18 --> Config Class Initialized
INFO - 2024-12-09 07:25:18 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:18 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:18 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:18 --> URI Class Initialized
INFO - 2024-12-09 07:25:18 --> Router Class Initialized
INFO - 2024-12-09 07:25:18 --> Output Class Initialized
INFO - 2024-12-09 07:25:18 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:18 --> CSRF cookie sent
INFO - 2024-12-09 07:25:18 --> Input Class Initialized
INFO - 2024-12-09 07:25:18 --> Language Class Initialized
INFO - 2024-12-09 07:25:18 --> Loader Class Initialized
INFO - 2024-12-09 07:25:18 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:18 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:18 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:18 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:18 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:18 --> Controller Class Initialized
INFO - 2024-12-09 07:25:18 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:25:18 --> Query result: stdClass Object
(
    [view_count] => 105
)

INFO - 2024-12-09 07:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:25:18 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:18 --> Total execution time: 0.0651
INFO - 2024-12-09 07:25:18 --> Config Class Initialized
INFO - 2024-12-09 07:25:18 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:18 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:18 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:18 --> URI Class Initialized
INFO - 2024-12-09 07:25:18 --> Router Class Initialized
INFO - 2024-12-09 07:25:18 --> Output Class Initialized
INFO - 2024-12-09 07:25:18 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:18 --> CSRF cookie sent
INFO - 2024-12-09 07:25:18 --> Input Class Initialized
INFO - 2024-12-09 07:25:18 --> Language Class Initialized
ERROR - 2024-12-09 07:25:18 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:25:21 --> Config Class Initialized
INFO - 2024-12-09 07:25:21 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:21 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:21 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:21 --> URI Class Initialized
INFO - 2024-12-09 07:25:21 --> Router Class Initialized
INFO - 2024-12-09 07:25:21 --> Output Class Initialized
INFO - 2024-12-09 07:25:21 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:21 --> CSRF cookie sent
INFO - 2024-12-09 07:25:21 --> Input Class Initialized
INFO - 2024-12-09 07:25:21 --> Language Class Initialized
INFO - 2024-12-09 07:25:21 --> Loader Class Initialized
INFO - 2024-12-09 07:25:21 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:21 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:21 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:21 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:21 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:21 --> Controller Class Initialized
INFO - 2024-12-09 07:25:21 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:21 --> Config Class Initialized
INFO - 2024-12-09 07:25:21 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:21 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:21 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:21 --> URI Class Initialized
INFO - 2024-12-09 07:25:21 --> Router Class Initialized
INFO - 2024-12-09 07:25:21 --> Output Class Initialized
INFO - 2024-12-09 07:25:21 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:21 --> CSRF cookie sent
INFO - 2024-12-09 07:25:21 --> Input Class Initialized
INFO - 2024-12-09 07:25:21 --> Language Class Initialized
INFO - 2024-12-09 07:25:21 --> Loader Class Initialized
INFO - 2024-12-09 07:25:21 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:21 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:21 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:21 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:21 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:21 --> Controller Class Initialized
INFO - 2024-12-09 07:25:21 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 07:25:21 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:21 --> Total execution time: 0.0724
INFO - 2024-12-09 07:25:23 --> Config Class Initialized
INFO - 2024-12-09 07:25:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:23 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:23 --> URI Class Initialized
INFO - 2024-12-09 07:25:23 --> Router Class Initialized
INFO - 2024-12-09 07:25:23 --> Output Class Initialized
INFO - 2024-12-09 07:25:23 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:23 --> CSRF cookie sent
INFO - 2024-12-09 07:25:23 --> Input Class Initialized
INFO - 2024-12-09 07:25:23 --> Language Class Initialized
INFO - 2024-12-09 07:25:23 --> Loader Class Initialized
INFO - 2024-12-09 07:25:23 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:23 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:23 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:23 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:23 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:23 --> Controller Class Initialized
INFO - 2024-12-09 07:25:23 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:23 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:23 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:24 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:25:24 --> Query result: stdClass Object
(
    [view_count] => 106
)

INFO - 2024-12-09 07:25:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:25:24 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:24 --> Total execution time: 0.0814
INFO - 2024-12-09 07:25:24 --> Config Class Initialized
INFO - 2024-12-09 07:25:24 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:24 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:24 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:24 --> URI Class Initialized
INFO - 2024-12-09 07:25:24 --> Router Class Initialized
INFO - 2024-12-09 07:25:24 --> Output Class Initialized
INFO - 2024-12-09 07:25:24 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:24 --> CSRF cookie sent
INFO - 2024-12-09 07:25:24 --> Input Class Initialized
INFO - 2024-12-09 07:25:24 --> Language Class Initialized
ERROR - 2024-12-09 07:25:24 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:25:59 --> Config Class Initialized
INFO - 2024-12-09 07:25:59 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:25:59 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:25:59 --> Utf8 Class Initialized
INFO - 2024-12-09 07:25:59 --> URI Class Initialized
INFO - 2024-12-09 07:25:59 --> Router Class Initialized
INFO - 2024-12-09 07:25:59 --> Output Class Initialized
INFO - 2024-12-09 07:25:59 --> Security Class Initialized
DEBUG - 2024-12-09 07:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:25:59 --> CSRF cookie sent
INFO - 2024-12-09 07:25:59 --> Input Class Initialized
INFO - 2024-12-09 07:25:59 --> Language Class Initialized
INFO - 2024-12-09 07:25:59 --> Loader Class Initialized
INFO - 2024-12-09 07:25:59 --> Helper loaded: url_helper
INFO - 2024-12-09 07:25:59 --> Helper loaded: form_helper
INFO - 2024-12-09 07:25:59 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:25:59 --> Form Validation Class Initialized
INFO - 2024-12-09 07:25:59 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:25:59 --> Controller Class Initialized
INFO - 2024-12-09 07:25:59 --> Model "User_model" initialized
INFO - 2024-12-09 07:25:59 --> Model "Category_model" initialized
INFO - 2024-12-09 07:25:59 --> Model "Review_model" initialized
INFO - 2024-12-09 07:25:59 --> Model "News_model" initialized
INFO - 2024-12-09 07:25:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:25:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:25:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:25:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-09 07:25:59 --> Final output sent to browser
DEBUG - 2024-12-09 07:25:59 --> Total execution time: 0.0857
INFO - 2024-12-09 07:26:03 --> Config Class Initialized
INFO - 2024-12-09 07:26:03 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:03 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:03 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:03 --> URI Class Initialized
INFO - 2024-12-09 07:26:03 --> Router Class Initialized
INFO - 2024-12-09 07:26:03 --> Output Class Initialized
INFO - 2024-12-09 07:26:03 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:03 --> CSRF cookie sent
INFO - 2024-12-09 07:26:03 --> Input Class Initialized
INFO - 2024-12-09 07:26:03 --> Language Class Initialized
INFO - 2024-12-09 07:26:03 --> Loader Class Initialized
INFO - 2024-12-09 07:26:03 --> Helper loaded: url_helper
INFO - 2024-12-09 07:26:03 --> Helper loaded: form_helper
INFO - 2024-12-09 07:26:03 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:26:03 --> Form Validation Class Initialized
INFO - 2024-12-09 07:26:03 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:26:03 --> Controller Class Initialized
INFO - 2024-12-09 07:26:03 --> Model "User_model" initialized
INFO - 2024-12-09 07:26:03 --> Model "Category_model" initialized
INFO - 2024-12-09 07:26:03 --> Model "Review_model" initialized
INFO - 2024-12-09 07:26:03 --> Model "News_model" initialized
INFO - 2024-12-09 07:26:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:26:03 --> Query result: stdClass Object
(
    [view_count] => 107
)

INFO - 2024-12-09 07:26:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:26:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:26:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:26:03 --> Final output sent to browser
DEBUG - 2024-12-09 07:26:03 --> Total execution time: 0.0672
INFO - 2024-12-09 07:26:03 --> Config Class Initialized
INFO - 2024-12-09 07:26:03 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:03 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:03 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:03 --> URI Class Initialized
INFO - 2024-12-09 07:26:03 --> Router Class Initialized
INFO - 2024-12-09 07:26:03 --> Output Class Initialized
INFO - 2024-12-09 07:26:03 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:03 --> CSRF cookie sent
INFO - 2024-12-09 07:26:03 --> Input Class Initialized
INFO - 2024-12-09 07:26:03 --> Language Class Initialized
ERROR - 2024-12-09 07:26:03 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:26:12 --> Config Class Initialized
INFO - 2024-12-09 07:26:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:12 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:12 --> URI Class Initialized
INFO - 2024-12-09 07:26:12 --> Router Class Initialized
INFO - 2024-12-09 07:26:12 --> Output Class Initialized
INFO - 2024-12-09 07:26:12 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:12 --> CSRF cookie sent
INFO - 2024-12-09 07:26:12 --> Input Class Initialized
INFO - 2024-12-09 07:26:12 --> Language Class Initialized
INFO - 2024-12-09 07:26:12 --> Loader Class Initialized
INFO - 2024-12-09 07:26:12 --> Helper loaded: url_helper
INFO - 2024-12-09 07:26:12 --> Helper loaded: form_helper
INFO - 2024-12-09 07:26:12 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:26:12 --> Form Validation Class Initialized
INFO - 2024-12-09 07:26:12 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:26:12 --> Controller Class Initialized
INFO - 2024-12-09 07:26:12 --> Model "User_model" initialized
INFO - 2024-12-09 07:26:12 --> Model "Category_model" initialized
INFO - 2024-12-09 07:26:12 --> Model "Review_model" initialized
INFO - 2024-12-09 07:26:12 --> Model "News_model" initialized
INFO - 2024-12-09 07:26:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:26:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:26:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:26:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:26:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:26:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-09 07:26:12 --> Final output sent to browser
DEBUG - 2024-12-09 07:26:12 --> Total execution time: 0.0664
INFO - 2024-12-09 07:26:15 --> Config Class Initialized
INFO - 2024-12-09 07:26:15 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:15 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:15 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:15 --> URI Class Initialized
INFO - 2024-12-09 07:26:15 --> Router Class Initialized
INFO - 2024-12-09 07:26:15 --> Output Class Initialized
INFO - 2024-12-09 07:26:15 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:15 --> CSRF cookie sent
INFO - 2024-12-09 07:26:15 --> Input Class Initialized
INFO - 2024-12-09 07:26:15 --> Language Class Initialized
INFO - 2024-12-09 07:26:15 --> Loader Class Initialized
INFO - 2024-12-09 07:26:15 --> Helper loaded: url_helper
INFO - 2024-12-09 07:26:15 --> Helper loaded: form_helper
INFO - 2024-12-09 07:26:15 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:26:15 --> Form Validation Class Initialized
INFO - 2024-12-09 07:26:15 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:26:15 --> Controller Class Initialized
INFO - 2024-12-09 07:26:15 --> Model "User_model" initialized
INFO - 2024-12-09 07:26:15 --> Model "Category_model" initialized
INFO - 2024-12-09 07:26:15 --> Model "Review_model" initialized
INFO - 2024-12-09 07:26:15 --> Model "News_model" initialized
INFO - 2024-12-09 07:26:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:26:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:26:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:26:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-09 07:26:15 --> Final output sent to browser
DEBUG - 2024-12-09 07:26:15 --> Total execution time: 0.0541
INFO - 2024-12-09 07:26:16 --> Config Class Initialized
INFO - 2024-12-09 07:26:16 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:16 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:16 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:16 --> URI Class Initialized
INFO - 2024-12-09 07:26:16 --> Router Class Initialized
INFO - 2024-12-09 07:26:16 --> Output Class Initialized
INFO - 2024-12-09 07:26:16 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:16 --> CSRF cookie sent
INFO - 2024-12-09 07:26:16 --> CSRF token verified
INFO - 2024-12-09 07:26:16 --> Input Class Initialized
INFO - 2024-12-09 07:26:16 --> Language Class Initialized
INFO - 2024-12-09 07:26:16 --> Loader Class Initialized
INFO - 2024-12-09 07:26:16 --> Helper loaded: url_helper
INFO - 2024-12-09 07:26:16 --> Helper loaded: form_helper
INFO - 2024-12-09 07:26:16 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:26:17 --> Form Validation Class Initialized
INFO - 2024-12-09 07:26:17 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:26:17 --> Controller Class Initialized
INFO - 2024-12-09 07:26:17 --> Model "User_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "Category_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "Review_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "News_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:26:17 --> Config Class Initialized
INFO - 2024-12-09 07:26:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:17 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:17 --> URI Class Initialized
INFO - 2024-12-09 07:26:17 --> Router Class Initialized
INFO - 2024-12-09 07:26:17 --> Output Class Initialized
INFO - 2024-12-09 07:26:17 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:17 --> CSRF cookie sent
INFO - 2024-12-09 07:26:17 --> Input Class Initialized
INFO - 2024-12-09 07:26:17 --> Language Class Initialized
INFO - 2024-12-09 07:26:17 --> Loader Class Initialized
INFO - 2024-12-09 07:26:17 --> Helper loaded: url_helper
INFO - 2024-12-09 07:26:17 --> Helper loaded: form_helper
INFO - 2024-12-09 07:26:17 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:26:17 --> Form Validation Class Initialized
INFO - 2024-12-09 07:26:17 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:26:17 --> Controller Class Initialized
INFO - 2024-12-09 07:26:17 --> Model "User_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "Category_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "Review_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "News_model" initialized
INFO - 2024-12-09 07:26:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:26:17 --> Query result: stdClass Object
(
    [view_count] => 108
)

INFO - 2024-12-09 07:26:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:26:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:26:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:26:17 --> Final output sent to browser
DEBUG - 2024-12-09 07:26:17 --> Total execution time: 0.0662
INFO - 2024-12-09 07:26:17 --> Config Class Initialized
INFO - 2024-12-09 07:26:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:17 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:17 --> URI Class Initialized
INFO - 2024-12-09 07:26:17 --> Router Class Initialized
INFO - 2024-12-09 07:26:17 --> Output Class Initialized
INFO - 2024-12-09 07:26:17 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:17 --> CSRF cookie sent
INFO - 2024-12-09 07:26:17 --> Input Class Initialized
INFO - 2024-12-09 07:26:17 --> Language Class Initialized
ERROR - 2024-12-09 07:26:17 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:26:27 --> Config Class Initialized
INFO - 2024-12-09 07:26:27 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:26:27 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:26:27 --> Utf8 Class Initialized
INFO - 2024-12-09 07:26:27 --> URI Class Initialized
INFO - 2024-12-09 07:26:27 --> Router Class Initialized
INFO - 2024-12-09 07:26:27 --> Output Class Initialized
INFO - 2024-12-09 07:26:27 --> Security Class Initialized
DEBUG - 2024-12-09 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:26:27 --> CSRF cookie sent
INFO - 2024-12-09 07:26:27 --> Input Class Initialized
INFO - 2024-12-09 07:26:27 --> Language Class Initialized
INFO - 2024-12-09 07:26:27 --> Loader Class Initialized
INFO - 2024-12-09 07:26:27 --> Helper loaded: url_helper
INFO - 2024-12-09 07:26:27 --> Helper loaded: form_helper
INFO - 2024-12-09 07:26:27 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:26:27 --> Form Validation Class Initialized
INFO - 2024-12-09 07:26:27 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:26:27 --> Controller Class Initialized
INFO - 2024-12-09 07:26:27 --> Model "User_model" initialized
INFO - 2024-12-09 07:26:27 --> Model "Category_model" initialized
INFO - 2024-12-09 07:26:27 --> Model "Review_model" initialized
INFO - 2024-12-09 07:26:27 --> Model "News_model" initialized
INFO - 2024-12-09 07:26:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:26:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:26:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:26:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-09 07:26:27 --> Final output sent to browser
DEBUG - 2024-12-09 07:26:27 --> Total execution time: 0.0824
INFO - 2024-12-09 07:28:35 --> Config Class Initialized
INFO - 2024-12-09 07:28:35 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:35 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:35 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:35 --> URI Class Initialized
INFO - 2024-12-09 07:28:35 --> Router Class Initialized
INFO - 2024-12-09 07:28:35 --> Output Class Initialized
INFO - 2024-12-09 07:28:35 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:35 --> CSRF cookie sent
INFO - 2024-12-09 07:28:35 --> CSRF token verified
INFO - 2024-12-09 07:28:35 --> Input Class Initialized
INFO - 2024-12-09 07:28:35 --> Language Class Initialized
INFO - 2024-12-09 07:28:35 --> Loader Class Initialized
INFO - 2024-12-09 07:28:35 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:35 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:35 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:35 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:35 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:35 --> Controller Class Initialized
INFO - 2024-12-09 07:28:35 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "News_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:28:35 --> Upload Class Initialized
INFO - 2024-12-09 07:28:35 --> Config Class Initialized
INFO - 2024-12-09 07:28:35 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:35 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:35 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:35 --> URI Class Initialized
INFO - 2024-12-09 07:28:35 --> Router Class Initialized
INFO - 2024-12-09 07:28:35 --> Output Class Initialized
INFO - 2024-12-09 07:28:35 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:35 --> CSRF cookie sent
INFO - 2024-12-09 07:28:35 --> Input Class Initialized
INFO - 2024-12-09 07:28:35 --> Language Class Initialized
INFO - 2024-12-09 07:28:35 --> Loader Class Initialized
INFO - 2024-12-09 07:28:35 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:35 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:35 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:35 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:35 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:35 --> Controller Class Initialized
INFO - 2024-12-09 07:28:35 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "News_model" initialized
INFO - 2024-12-09 07:28:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:28:35 --> Query result: stdClass Object
(
    [view_count] => 109
)

INFO - 2024-12-09 07:28:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:28:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:28:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:28:35 --> Final output sent to browser
DEBUG - 2024-12-09 07:28:35 --> Total execution time: 0.1797
INFO - 2024-12-09 07:28:37 --> Config Class Initialized
INFO - 2024-12-09 07:28:37 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:37 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:37 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:37 --> URI Class Initialized
INFO - 2024-12-09 07:28:37 --> Router Class Initialized
INFO - 2024-12-09 07:28:37 --> Output Class Initialized
INFO - 2024-12-09 07:28:37 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:37 --> CSRF cookie sent
INFO - 2024-12-09 07:28:37 --> Input Class Initialized
INFO - 2024-12-09 07:28:37 --> Language Class Initialized
ERROR - 2024-12-09 07:28:37 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-09 07:28:47 --> Config Class Initialized
INFO - 2024-12-09 07:28:47 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:47 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:47 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:47 --> URI Class Initialized
INFO - 2024-12-09 07:28:47 --> Router Class Initialized
INFO - 2024-12-09 07:28:47 --> Output Class Initialized
INFO - 2024-12-09 07:28:47 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:47 --> CSRF cookie sent
INFO - 2024-12-09 07:28:47 --> Input Class Initialized
INFO - 2024-12-09 07:28:47 --> Language Class Initialized
INFO - 2024-12-09 07:28:47 --> Loader Class Initialized
INFO - 2024-12-09 07:28:47 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:47 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:47 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:47 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:47 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:47 --> Controller Class Initialized
INFO - 2024-12-09 07:28:47 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:28:47 --> Config Class Initialized
INFO - 2024-12-09 07:28:47 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:47 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:47 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:47 --> URI Class Initialized
INFO - 2024-12-09 07:28:47 --> Router Class Initialized
INFO - 2024-12-09 07:28:47 --> Output Class Initialized
INFO - 2024-12-09 07:28:47 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:47 --> CSRF cookie sent
INFO - 2024-12-09 07:28:47 --> Input Class Initialized
INFO - 2024-12-09 07:28:47 --> Language Class Initialized
INFO - 2024-12-09 07:28:47 --> Loader Class Initialized
INFO - 2024-12-09 07:28:47 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:47 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:47 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:47 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:47 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:47 --> Controller Class Initialized
INFO - 2024-12-09 07:28:47 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:28:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:28:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:28:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:28:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-09 07:28:47 --> Final output sent to browser
DEBUG - 2024-12-09 07:28:47 --> Total execution time: 0.0483
INFO - 2024-12-09 07:28:52 --> Config Class Initialized
INFO - 2024-12-09 07:28:52 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:52 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:52 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:52 --> URI Class Initialized
INFO - 2024-12-09 07:28:52 --> Router Class Initialized
INFO - 2024-12-09 07:28:52 --> Output Class Initialized
INFO - 2024-12-09 07:28:52 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:52 --> CSRF cookie sent
INFO - 2024-12-09 07:28:52 --> CSRF token verified
INFO - 2024-12-09 07:28:52 --> Input Class Initialized
INFO - 2024-12-09 07:28:52 --> Language Class Initialized
INFO - 2024-12-09 07:28:52 --> Loader Class Initialized
INFO - 2024-12-09 07:28:52 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:52 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:52 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:52 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:52 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:52 --> Controller Class Initialized
INFO - 2024-12-09 07:28:52 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "News_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:28:52 --> Config Class Initialized
INFO - 2024-12-09 07:28:52 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:52 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:52 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:52 --> URI Class Initialized
INFO - 2024-12-09 07:28:52 --> Router Class Initialized
INFO - 2024-12-09 07:28:52 --> Output Class Initialized
INFO - 2024-12-09 07:28:52 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:52 --> CSRF cookie sent
INFO - 2024-12-09 07:28:52 --> Input Class Initialized
INFO - 2024-12-09 07:28:52 --> Language Class Initialized
INFO - 2024-12-09 07:28:52 --> Loader Class Initialized
INFO - 2024-12-09 07:28:52 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:52 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:52 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:52 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:52 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:52 --> Controller Class Initialized
INFO - 2024-12-09 07:28:52 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:28:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:28:52 --> Query result: stdClass Object
(
    [view_count] => 109
)

INFO - 2024-12-09 07:28:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-09 07:28:52 --> Final output sent to browser
DEBUG - 2024-12-09 07:28:52 --> Total execution time: 0.0560
INFO - 2024-12-09 07:28:55 --> Config Class Initialized
INFO - 2024-12-09 07:28:55 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:28:55 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:28:55 --> Utf8 Class Initialized
INFO - 2024-12-09 07:28:55 --> URI Class Initialized
INFO - 2024-12-09 07:28:55 --> Router Class Initialized
INFO - 2024-12-09 07:28:55 --> Output Class Initialized
INFO - 2024-12-09 07:28:55 --> Security Class Initialized
DEBUG - 2024-12-09 07:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:28:55 --> CSRF cookie sent
INFO - 2024-12-09 07:28:55 --> Input Class Initialized
INFO - 2024-12-09 07:28:55 --> Language Class Initialized
INFO - 2024-12-09 07:28:55 --> Loader Class Initialized
INFO - 2024-12-09 07:28:55 --> Helper loaded: url_helper
INFO - 2024-12-09 07:28:55 --> Helper loaded: form_helper
INFO - 2024-12-09 07:28:55 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:28:55 --> Form Validation Class Initialized
INFO - 2024-12-09 07:28:55 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:28:55 --> Controller Class Initialized
INFO - 2024-12-09 07:28:55 --> Model "Review_model" initialized
INFO - 2024-12-09 07:28:55 --> Model "Category_model" initialized
INFO - 2024-12-09 07:28:55 --> Model "User_model" initialized
INFO - 2024-12-09 07:28:55 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:28:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:28:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-09 07:28:55 --> Final output sent to browser
DEBUG - 2024-12-09 07:28:55 --> Total execution time: 0.0721
INFO - 2024-12-09 07:29:00 --> Config Class Initialized
INFO - 2024-12-09 07:29:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:00 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:00 --> URI Class Initialized
INFO - 2024-12-09 07:29:00 --> Router Class Initialized
INFO - 2024-12-09 07:29:00 --> Output Class Initialized
INFO - 2024-12-09 07:29:00 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:00 --> CSRF cookie sent
INFO - 2024-12-09 07:29:00 --> Input Class Initialized
INFO - 2024-12-09 07:29:00 --> Language Class Initialized
INFO - 2024-12-09 07:29:00 --> Loader Class Initialized
INFO - 2024-12-09 07:29:00 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:00 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:00 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:00 --> Controller Class Initialized
INFO - 2024-12-09 07:29:00 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:00 --> Config Class Initialized
INFO - 2024-12-09 07:29:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:00 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:00 --> URI Class Initialized
INFO - 2024-12-09 07:29:00 --> Router Class Initialized
INFO - 2024-12-09 07:29:00 --> Output Class Initialized
INFO - 2024-12-09 07:29:00 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:00 --> CSRF cookie sent
INFO - 2024-12-09 07:29:00 --> Input Class Initialized
INFO - 2024-12-09 07:29:00 --> Language Class Initialized
INFO - 2024-12-09 07:29:00 --> Loader Class Initialized
INFO - 2024-12-09 07:29:00 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:00 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:00 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:00 --> Controller Class Initialized
INFO - 2024-12-09 07:29:00 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:29:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-09 07:29:00 --> Final output sent to browser
DEBUG - 2024-12-09 07:29:00 --> Total execution time: 0.0499
INFO - 2024-12-09 07:29:02 --> Config Class Initialized
INFO - 2024-12-09 07:29:02 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:02 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:02 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:02 --> URI Class Initialized
INFO - 2024-12-09 07:29:02 --> Router Class Initialized
INFO - 2024-12-09 07:29:02 --> Output Class Initialized
INFO - 2024-12-09 07:29:02 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:02 --> CSRF cookie sent
INFO - 2024-12-09 07:29:02 --> Input Class Initialized
INFO - 2024-12-09 07:29:02 --> Language Class Initialized
INFO - 2024-12-09 07:29:02 --> Loader Class Initialized
INFO - 2024-12-09 07:29:02 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:02 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:02 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:02 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:02 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:02 --> Controller Class Initialized
INFO - 2024-12-09 07:29:02 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:02 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:02 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:29:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-09 07:29:02 --> Final output sent to browser
DEBUG - 2024-12-09 07:29:02 --> Total execution time: 0.0505
INFO - 2024-12-09 07:29:15 --> Config Class Initialized
INFO - 2024-12-09 07:29:15 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:15 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:15 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:15 --> URI Class Initialized
INFO - 2024-12-09 07:29:15 --> Router Class Initialized
INFO - 2024-12-09 07:29:15 --> Output Class Initialized
INFO - 2024-12-09 07:29:15 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:15 --> CSRF cookie sent
INFO - 2024-12-09 07:29:15 --> Input Class Initialized
INFO - 2024-12-09 07:29:15 --> Language Class Initialized
INFO - 2024-12-09 07:29:15 --> Loader Class Initialized
INFO - 2024-12-09 07:29:15 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:15 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:15 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:15 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:15 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:15 --> Controller Class Initialized
INFO - 2024-12-09 07:29:15 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:15 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:15 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:15 --> Model "News_model" initialized
INFO - 2024-12-09 07:29:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:29:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:29:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-09 07:29:15 --> Final output sent to browser
DEBUG - 2024-12-09 07:29:15 --> Total execution time: 0.0917
INFO - 2024-12-09 07:29:22 --> Config Class Initialized
INFO - 2024-12-09 07:29:22 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:22 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:22 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:22 --> URI Class Initialized
INFO - 2024-12-09 07:29:22 --> Router Class Initialized
INFO - 2024-12-09 07:29:22 --> Output Class Initialized
INFO - 2024-12-09 07:29:22 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:22 --> CSRF cookie sent
INFO - 2024-12-09 07:29:22 --> Input Class Initialized
INFO - 2024-12-09 07:29:22 --> Language Class Initialized
INFO - 2024-12-09 07:29:22 --> Loader Class Initialized
INFO - 2024-12-09 07:29:22 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:22 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:22 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:22 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:22 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:22 --> Controller Class Initialized
INFO - 2024-12-09 07:29:22 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:22 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:22 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:22 --> Model "News_model" initialized
INFO - 2024-12-09 07:29:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:29:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:29:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-09 07:29:22 --> Final output sent to browser
DEBUG - 2024-12-09 07:29:22 --> Total execution time: 0.0648
INFO - 2024-12-09 07:29:52 --> Config Class Initialized
INFO - 2024-12-09 07:29:52 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:52 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:52 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:52 --> URI Class Initialized
INFO - 2024-12-09 07:29:52 --> Router Class Initialized
INFO - 2024-12-09 07:29:52 --> Output Class Initialized
INFO - 2024-12-09 07:29:52 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:52 --> CSRF cookie sent
INFO - 2024-12-09 07:29:52 --> CSRF token verified
INFO - 2024-12-09 07:29:52 --> Input Class Initialized
INFO - 2024-12-09 07:29:52 --> Language Class Initialized
INFO - 2024-12-09 07:29:52 --> Loader Class Initialized
INFO - 2024-12-09 07:29:52 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:52 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:52 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:52 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:52 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:52 --> Controller Class Initialized
INFO - 2024-12-09 07:29:52 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "News_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:52 --> Config Class Initialized
INFO - 2024-12-09 07:29:52 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:29:52 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:29:52 --> Utf8 Class Initialized
INFO - 2024-12-09 07:29:52 --> URI Class Initialized
INFO - 2024-12-09 07:29:52 --> Router Class Initialized
INFO - 2024-12-09 07:29:52 --> Output Class Initialized
INFO - 2024-12-09 07:29:52 --> Security Class Initialized
DEBUG - 2024-12-09 07:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:29:52 --> CSRF cookie sent
INFO - 2024-12-09 07:29:52 --> Input Class Initialized
INFO - 2024-12-09 07:29:52 --> Language Class Initialized
INFO - 2024-12-09 07:29:52 --> Loader Class Initialized
INFO - 2024-12-09 07:29:52 --> Helper loaded: url_helper
INFO - 2024-12-09 07:29:52 --> Helper loaded: form_helper
INFO - 2024-12-09 07:29:52 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:29:52 --> Form Validation Class Initialized
INFO - 2024-12-09 07:29:52 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:29:52 --> Controller Class Initialized
INFO - 2024-12-09 07:29:52 --> Model "User_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "Category_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "Review_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "News_model" initialized
INFO - 2024-12-09 07:29:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:29:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:29:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:29:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-09 07:29:52 --> Final output sent to browser
DEBUG - 2024-12-09 07:29:52 --> Total execution time: 0.0693
INFO - 2024-12-09 07:30:08 --> Config Class Initialized
INFO - 2024-12-09 07:30:08 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:30:08 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:30:08 --> Utf8 Class Initialized
INFO - 2024-12-09 07:30:08 --> URI Class Initialized
INFO - 2024-12-09 07:30:08 --> Router Class Initialized
INFO - 2024-12-09 07:30:08 --> Output Class Initialized
INFO - 2024-12-09 07:30:08 --> Security Class Initialized
DEBUG - 2024-12-09 07:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:30:08 --> CSRF cookie sent
INFO - 2024-12-09 07:30:08 --> Input Class Initialized
INFO - 2024-12-09 07:30:08 --> Language Class Initialized
INFO - 2024-12-09 07:30:08 --> Loader Class Initialized
INFO - 2024-12-09 07:30:08 --> Helper loaded: url_helper
INFO - 2024-12-09 07:30:08 --> Helper loaded: form_helper
INFO - 2024-12-09 07:30:08 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:30:08 --> Form Validation Class Initialized
INFO - 2024-12-09 07:30:08 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:30:08 --> Controller Class Initialized
INFO - 2024-12-09 07:30:08 --> Model "User_model" initialized
INFO - 2024-12-09 07:30:08 --> Model "Category_model" initialized
INFO - 2024-12-09 07:30:08 --> Model "Review_model" initialized
INFO - 2024-12-09 07:30:08 --> Model "News_model" initialized
INFO - 2024-12-09 07:30:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:30:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:30:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:30:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-09 07:30:08 --> Final output sent to browser
DEBUG - 2024-12-09 07:30:08 --> Total execution time: 0.0838
INFO - 2024-12-09 07:32:06 --> Config Class Initialized
INFO - 2024-12-09 07:32:06 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:06 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:06 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:06 --> URI Class Initialized
INFO - 2024-12-09 07:32:07 --> Router Class Initialized
INFO - 2024-12-09 07:32:07 --> Output Class Initialized
INFO - 2024-12-09 07:32:07 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:07 --> CSRF cookie sent
INFO - 2024-12-09 07:32:07 --> Input Class Initialized
INFO - 2024-12-09 07:32:07 --> Language Class Initialized
INFO - 2024-12-09 07:32:07 --> Loader Class Initialized
INFO - 2024-12-09 07:32:07 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:07 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:07 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:07 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:07 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:07 --> Controller Class Initialized
INFO - 2024-12-09 07:32:07 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:07 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:07 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:07 --> Model "News_model" initialized
INFO - 2024-12-09 07:32:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:32:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:32:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:32:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-09 07:32:07 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:07 --> Total execution time: 0.0583
INFO - 2024-12-09 07:32:12 --> Config Class Initialized
INFO - 2024-12-09 07:32:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:12 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:12 --> URI Class Initialized
INFO - 2024-12-09 07:32:12 --> Router Class Initialized
INFO - 2024-12-09 07:32:12 --> Output Class Initialized
INFO - 2024-12-09 07:32:12 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:12 --> CSRF cookie sent
INFO - 2024-12-09 07:32:12 --> Input Class Initialized
INFO - 2024-12-09 07:32:12 --> Language Class Initialized
INFO - 2024-12-09 07:32:12 --> Loader Class Initialized
INFO - 2024-12-09 07:32:12 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:12 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:12 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:12 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:12 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:12 --> Controller Class Initialized
INFO - 2024-12-09 07:32:12 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:12 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:12 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:12 --> Model "News_model" initialized
INFO - 2024-12-09 07:32:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:32:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:32:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:32:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-09 07:32:12 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:12 --> Total execution time: 0.0493
INFO - 2024-12-09 07:32:21 --> Config Class Initialized
INFO - 2024-12-09 07:32:21 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:21 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:21 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:21 --> URI Class Initialized
INFO - 2024-12-09 07:32:21 --> Router Class Initialized
INFO - 2024-12-09 07:32:21 --> Output Class Initialized
INFO - 2024-12-09 07:32:21 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:21 --> CSRF cookie sent
INFO - 2024-12-09 07:32:21 --> Input Class Initialized
INFO - 2024-12-09 07:32:21 --> Language Class Initialized
INFO - 2024-12-09 07:32:21 --> Loader Class Initialized
INFO - 2024-12-09 07:32:21 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:21 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:21 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:21 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:21 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:21 --> Controller Class Initialized
INFO - 2024-12-09 07:32:21 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:21 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:21 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:32:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:32:21 --> Query result: stdClass Object
(
    [view_count] => 109
)

INFO - 2024-12-09 07:32:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-09 07:32:21 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:21 --> Total execution time: 0.0713
INFO - 2024-12-09 07:32:25 --> Config Class Initialized
INFO - 2024-12-09 07:32:25 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:25 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:25 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:25 --> URI Class Initialized
INFO - 2024-12-09 07:32:25 --> Router Class Initialized
INFO - 2024-12-09 07:32:25 --> Output Class Initialized
INFO - 2024-12-09 07:32:25 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:25 --> CSRF cookie sent
INFO - 2024-12-09 07:32:25 --> Input Class Initialized
INFO - 2024-12-09 07:32:25 --> Language Class Initialized
INFO - 2024-12-09 07:32:25 --> Loader Class Initialized
INFO - 2024-12-09 07:32:25 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:25 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:25 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:25 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:25 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:25 --> Controller Class Initialized
INFO - 2024-12-09 07:32:25 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:25 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:25 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:32:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:32:25 --> Model "Contact_model" initialized
INFO - 2024-12-09 07:32:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-09 07:32:25 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:25 --> Total execution time: 0.0490
INFO - 2024-12-09 07:32:41 --> Config Class Initialized
INFO - 2024-12-09 07:32:41 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:41 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:41 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:41 --> URI Class Initialized
INFO - 2024-12-09 07:32:41 --> Router Class Initialized
INFO - 2024-12-09 07:32:41 --> Output Class Initialized
INFO - 2024-12-09 07:32:41 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:41 --> CSRF cookie sent
INFO - 2024-12-09 07:32:41 --> Input Class Initialized
INFO - 2024-12-09 07:32:41 --> Language Class Initialized
INFO - 2024-12-09 07:32:41 --> Loader Class Initialized
INFO - 2024-12-09 07:32:41 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:41 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:41 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:41 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:41 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:41 --> Controller Class Initialized
INFO - 2024-12-09 07:32:41 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:41 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:41 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:41 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:32:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:32:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-09 07:32:41 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:41 --> Total execution time: 0.1766
INFO - 2024-12-09 07:32:44 --> Config Class Initialized
INFO - 2024-12-09 07:32:44 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:44 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:44 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:44 --> URI Class Initialized
INFO - 2024-12-09 07:32:44 --> Router Class Initialized
INFO - 2024-12-09 07:32:44 --> Output Class Initialized
INFO - 2024-12-09 07:32:44 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:44 --> CSRF cookie sent
INFO - 2024-12-09 07:32:44 --> Input Class Initialized
INFO - 2024-12-09 07:32:44 --> Language Class Initialized
INFO - 2024-12-09 07:32:44 --> Loader Class Initialized
INFO - 2024-12-09 07:32:44 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:44 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:44 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:44 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:44 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:44 --> Controller Class Initialized
INFO - 2024-12-09 07:32:44 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:44 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:44 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:32:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:32:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-09 07:32:44 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:44 --> Total execution time: 0.0610
INFO - 2024-12-09 07:32:52 --> Config Class Initialized
INFO - 2024-12-09 07:32:52 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:52 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:52 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:52 --> URI Class Initialized
INFO - 2024-12-09 07:32:52 --> Router Class Initialized
INFO - 2024-12-09 07:32:52 --> Output Class Initialized
INFO - 2024-12-09 07:32:52 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:52 --> CSRF cookie sent
INFO - 2024-12-09 07:32:52 --> Input Class Initialized
INFO - 2024-12-09 07:32:52 --> Language Class Initialized
INFO - 2024-12-09 07:32:52 --> Loader Class Initialized
INFO - 2024-12-09 07:32:52 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:52 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:52 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:52 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:52 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:52 --> Controller Class Initialized
INFO - 2024-12-09 07:32:52 --> Model "Review_model" initialized
INFO - 2024-12-09 07:32:52 --> Model "Category_model" initialized
INFO - 2024-12-09 07:32:52 --> Model "User_model" initialized
INFO - 2024-12-09 07:32:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:32:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:32:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-09 07:32:52 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:52 --> Total execution time: 0.0754
INFO - 2024-12-09 07:32:54 --> Config Class Initialized
INFO - 2024-12-09 07:32:54 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:32:54 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:32:54 --> Utf8 Class Initialized
INFO - 2024-12-09 07:32:54 --> URI Class Initialized
INFO - 2024-12-09 07:32:54 --> Router Class Initialized
INFO - 2024-12-09 07:32:54 --> Output Class Initialized
INFO - 2024-12-09 07:32:54 --> Security Class Initialized
DEBUG - 2024-12-09 07:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:32:54 --> CSRF cookie sent
INFO - 2024-12-09 07:32:54 --> Input Class Initialized
INFO - 2024-12-09 07:32:54 --> Language Class Initialized
INFO - 2024-12-09 07:32:54 --> Loader Class Initialized
INFO - 2024-12-09 07:32:54 --> Helper loaded: url_helper
INFO - 2024-12-09 07:32:54 --> Helper loaded: form_helper
INFO - 2024-12-09 07:32:54 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:32:54 --> Form Validation Class Initialized
INFO - 2024-12-09 07:32:54 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:32:54 --> Controller Class Initialized
INFO - 2024-12-09 07:32:54 --> Model "News_model" initialized
INFO - 2024-12-09 07:32:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-09 07:32:54 --> Final output sent to browser
DEBUG - 2024-12-09 07:32:54 --> Total execution time: 0.0532
INFO - 2024-12-09 07:33:00 --> Config Class Initialized
INFO - 2024-12-09 07:33:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:33:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:33:00 --> Utf8 Class Initialized
INFO - 2024-12-09 07:33:00 --> URI Class Initialized
INFO - 2024-12-09 07:33:00 --> Router Class Initialized
INFO - 2024-12-09 07:33:00 --> Output Class Initialized
INFO - 2024-12-09 07:33:00 --> Security Class Initialized
DEBUG - 2024-12-09 07:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:33:00 --> CSRF cookie sent
INFO - 2024-12-09 07:33:00 --> Input Class Initialized
INFO - 2024-12-09 07:33:00 --> Language Class Initialized
INFO - 2024-12-09 07:33:00 --> Loader Class Initialized
INFO - 2024-12-09 07:33:00 --> Helper loaded: url_helper
INFO - 2024-12-09 07:33:00 --> Helper loaded: form_helper
INFO - 2024-12-09 07:33:00 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:33:00 --> Form Validation Class Initialized
INFO - 2024-12-09 07:33:00 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:33:00 --> Controller Class Initialized
INFO - 2024-12-09 07:33:00 --> Model "User_model" initialized
INFO - 2024-12-09 07:33:00 --> Model "Category_model" initialized
INFO - 2024-12-09 07:33:00 --> Model "Review_model" initialized
INFO - 2024-12-09 07:33:00 --> Model "News_model" initialized
INFO - 2024-12-09 07:33:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:33:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-09 07:33:00 --> Query result: stdClass Object
(
    [view_count] => 110
)

INFO - 2024-12-09 07:33:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-09 07:33:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-09 07:33:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-09 07:33:00 --> Final output sent to browser
DEBUG - 2024-12-09 07:33:00 --> Total execution time: 0.1292
INFO - 2024-12-09 07:33:10 --> Config Class Initialized
INFO - 2024-12-09 07:33:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:33:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:33:10 --> Utf8 Class Initialized
INFO - 2024-12-09 07:33:10 --> URI Class Initialized
INFO - 2024-12-09 07:33:10 --> Router Class Initialized
INFO - 2024-12-09 07:33:10 --> Output Class Initialized
INFO - 2024-12-09 07:33:10 --> Security Class Initialized
DEBUG - 2024-12-09 07:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:33:10 --> CSRF cookie sent
INFO - 2024-12-09 07:33:10 --> Input Class Initialized
INFO - 2024-12-09 07:33:10 --> Language Class Initialized
ERROR - 2024-12-09 07:33:10 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-09 07:33:23 --> Config Class Initialized
INFO - 2024-12-09 07:33:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:33:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:33:23 --> Utf8 Class Initialized
INFO - 2024-12-09 07:33:23 --> URI Class Initialized
INFO - 2024-12-09 07:33:23 --> Router Class Initialized
INFO - 2024-12-09 07:33:23 --> Output Class Initialized
INFO - 2024-12-09 07:33:23 --> Security Class Initialized
DEBUG - 2024-12-09 07:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:33:23 --> CSRF cookie sent
INFO - 2024-12-09 07:33:23 --> Input Class Initialized
INFO - 2024-12-09 07:33:23 --> Language Class Initialized
INFO - 2024-12-09 07:33:23 --> Loader Class Initialized
INFO - 2024-12-09 07:33:23 --> Helper loaded: url_helper
INFO - 2024-12-09 07:33:23 --> Helper loaded: form_helper
INFO - 2024-12-09 07:33:23 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:33:23 --> Form Validation Class Initialized
INFO - 2024-12-09 07:33:23 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:33:23 --> Controller Class Initialized
INFO - 2024-12-09 07:33:23 --> Model "Review_model" initialized
INFO - 2024-12-09 07:33:23 --> Model "Category_model" initialized
INFO - 2024-12-09 07:33:23 --> Model "User_model" initialized
INFO - 2024-12-09 07:33:23 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:33:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:33:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-09 07:33:23 --> Final output sent to browser
DEBUG - 2024-12-09 07:33:23 --> Total execution time: 0.2179
INFO - 2024-12-09 07:33:24 --> Config Class Initialized
INFO - 2024-12-09 07:33:24 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:33:24 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:33:24 --> Utf8 Class Initialized
INFO - 2024-12-09 07:33:24 --> URI Class Initialized
INFO - 2024-12-09 07:33:24 --> Router Class Initialized
INFO - 2024-12-09 07:33:24 --> Output Class Initialized
INFO - 2024-12-09 07:33:24 --> Security Class Initialized
DEBUG - 2024-12-09 07:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:33:24 --> CSRF cookie sent
INFO - 2024-12-09 07:33:24 --> Input Class Initialized
INFO - 2024-12-09 07:33:24 --> Language Class Initialized
INFO - 2024-12-09 07:33:24 --> Loader Class Initialized
INFO - 2024-12-09 07:33:24 --> Helper loaded: url_helper
INFO - 2024-12-09 07:33:24 --> Helper loaded: form_helper
INFO - 2024-12-09 07:33:24 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:33:24 --> Form Validation Class Initialized
INFO - 2024-12-09 07:33:24 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:33:24 --> Controller Class Initialized
INFO - 2024-12-09 07:33:24 --> Model "Review_model" initialized
INFO - 2024-12-09 07:33:24 --> Model "Category_model" initialized
INFO - 2024-12-09 07:33:24 --> Model "User_model" initialized
INFO - 2024-12-09 07:33:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:33:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:33:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-09 07:33:24 --> Final output sent to browser
DEBUG - 2024-12-09 07:33:24 --> Total execution time: 0.0653
INFO - 2024-12-09 07:33:25 --> Config Class Initialized
INFO - 2024-12-09 07:33:25 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:33:25 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:33:25 --> Utf8 Class Initialized
INFO - 2024-12-09 07:33:25 --> URI Class Initialized
INFO - 2024-12-09 07:33:25 --> Router Class Initialized
INFO - 2024-12-09 07:33:25 --> Output Class Initialized
INFO - 2024-12-09 07:33:25 --> Security Class Initialized
DEBUG - 2024-12-09 07:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:33:25 --> CSRF cookie sent
INFO - 2024-12-09 07:33:25 --> Input Class Initialized
INFO - 2024-12-09 07:33:25 --> Language Class Initialized
INFO - 2024-12-09 07:33:25 --> Loader Class Initialized
INFO - 2024-12-09 07:33:25 --> Helper loaded: url_helper
INFO - 2024-12-09 07:33:25 --> Helper loaded: form_helper
INFO - 2024-12-09 07:33:25 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:33:25 --> Form Validation Class Initialized
INFO - 2024-12-09 07:33:25 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:33:25 --> Controller Class Initialized
INFO - 2024-12-09 07:33:25 --> Model "Review_model" initialized
INFO - 2024-12-09 07:33:25 --> Model "Category_model" initialized
INFO - 2024-12-09 07:33:25 --> Model "User_model" initialized
INFO - 2024-12-09 07:33:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:33:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:33:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-09 07:33:25 --> Final output sent to browser
DEBUG - 2024-12-09 07:33:25 --> Total execution time: 0.2314
INFO - 2024-12-09 07:33:51 --> Config Class Initialized
INFO - 2024-12-09 07:33:51 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:33:51 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:33:51 --> Utf8 Class Initialized
INFO - 2024-12-09 07:33:51 --> URI Class Initialized
INFO - 2024-12-09 07:33:51 --> Router Class Initialized
INFO - 2024-12-09 07:33:51 --> Output Class Initialized
INFO - 2024-12-09 07:33:51 --> Security Class Initialized
DEBUG - 2024-12-09 07:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:33:51 --> CSRF cookie sent
INFO - 2024-12-09 07:33:51 --> Input Class Initialized
INFO - 2024-12-09 07:33:51 --> Language Class Initialized
INFO - 2024-12-09 07:33:51 --> Loader Class Initialized
INFO - 2024-12-09 07:33:51 --> Helper loaded: url_helper
INFO - 2024-12-09 07:33:51 --> Helper loaded: form_helper
INFO - 2024-12-09 07:33:51 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:33:51 --> Form Validation Class Initialized
INFO - 2024-12-09 07:33:51 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:33:51 --> Controller Class Initialized
INFO - 2024-12-09 07:33:51 --> Model "Review_model" initialized
INFO - 2024-12-09 07:33:51 --> Model "Category_model" initialized
INFO - 2024-12-09 07:33:51 --> Model "User_model" initialized
INFO - 2024-12-09 07:33:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:33:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:33:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-09 07:33:51 --> Final output sent to browser
DEBUG - 2024-12-09 07:33:51 --> Total execution time: 0.2243
INFO - 2024-12-09 07:34:30 --> Config Class Initialized
INFO - 2024-12-09 07:34:30 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:34:30 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:34:30 --> Utf8 Class Initialized
INFO - 2024-12-09 07:34:30 --> URI Class Initialized
INFO - 2024-12-09 07:34:30 --> Router Class Initialized
INFO - 2024-12-09 07:34:30 --> Output Class Initialized
INFO - 2024-12-09 07:34:30 --> Security Class Initialized
DEBUG - 2024-12-09 07:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:34:30 --> CSRF cookie sent
INFO - 2024-12-09 07:34:30 --> Input Class Initialized
INFO - 2024-12-09 07:34:30 --> Language Class Initialized
INFO - 2024-12-09 07:34:30 --> Loader Class Initialized
INFO - 2024-12-09 07:34:30 --> Helper loaded: url_helper
INFO - 2024-12-09 07:34:30 --> Helper loaded: form_helper
INFO - 2024-12-09 07:34:30 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:34:30 --> Form Validation Class Initialized
INFO - 2024-12-09 07:34:30 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:34:30 --> Controller Class Initialized
INFO - 2024-12-09 07:34:30 --> Model "Review_model" initialized
INFO - 2024-12-09 07:34:30 --> Model "Category_model" initialized
INFO - 2024-12-09 07:34:30 --> Model "User_model" initialized
INFO - 2024-12-09 07:34:30 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:34:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:34:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-09 07:34:30 --> Final output sent to browser
DEBUG - 2024-12-09 07:34:30 --> Total execution time: 0.1801
INFO - 2024-12-09 07:34:51 --> Config Class Initialized
INFO - 2024-12-09 07:34:51 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:34:51 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:34:51 --> Utf8 Class Initialized
INFO - 2024-12-09 07:34:51 --> URI Class Initialized
INFO - 2024-12-09 07:34:51 --> Router Class Initialized
INFO - 2024-12-09 07:34:51 --> Output Class Initialized
INFO - 2024-12-09 07:34:51 --> Security Class Initialized
DEBUG - 2024-12-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:34:51 --> CSRF cookie sent
INFO - 2024-12-09 07:34:51 --> Input Class Initialized
INFO - 2024-12-09 07:34:51 --> Language Class Initialized
INFO - 2024-12-09 07:34:51 --> Loader Class Initialized
INFO - 2024-12-09 07:34:51 --> Helper loaded: url_helper
INFO - 2024-12-09 07:34:51 --> Helper loaded: form_helper
INFO - 2024-12-09 07:34:51 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:34:51 --> Form Validation Class Initialized
INFO - 2024-12-09 07:34:51 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:34:51 --> Controller Class Initialized
INFO - 2024-12-09 07:34:51 --> Model "Review_model" initialized
INFO - 2024-12-09 07:34:51 --> Model "Category_model" initialized
INFO - 2024-12-09 07:34:51 --> Model "User_model" initialized
INFO - 2024-12-09 07:34:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:34:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:34:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-09 07:34:51 --> Final output sent to browser
DEBUG - 2024-12-09 07:34:51 --> Total execution time: 0.1090
INFO - 2024-12-09 07:34:58 --> Config Class Initialized
INFO - 2024-12-09 07:34:58 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:34:58 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:34:58 --> Utf8 Class Initialized
INFO - 2024-12-09 07:34:58 --> URI Class Initialized
INFO - 2024-12-09 07:34:58 --> Router Class Initialized
INFO - 2024-12-09 07:34:58 --> Output Class Initialized
INFO - 2024-12-09 07:34:58 --> Security Class Initialized
DEBUG - 2024-12-09 07:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:34:58 --> CSRF cookie sent
INFO - 2024-12-09 07:34:58 --> Input Class Initialized
INFO - 2024-12-09 07:34:58 --> Language Class Initialized
INFO - 2024-12-09 07:34:58 --> Loader Class Initialized
INFO - 2024-12-09 07:34:58 --> Helper loaded: url_helper
INFO - 2024-12-09 07:34:58 --> Helper loaded: form_helper
INFO - 2024-12-09 07:34:58 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:34:58 --> Form Validation Class Initialized
INFO - 2024-12-09 07:34:58 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:34:58 --> Controller Class Initialized
INFO - 2024-12-09 07:34:58 --> Model "Review_model" initialized
INFO - 2024-12-09 07:34:58 --> Model "Category_model" initialized
INFO - 2024-12-09 07:34:58 --> Model "User_model" initialized
INFO - 2024-12-09 07:34:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:34:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:34:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-09 07:34:58 --> Final output sent to browser
DEBUG - 2024-12-09 07:34:58 --> Total execution time: 0.1765
INFO - 2024-12-09 07:35:10 --> Config Class Initialized
INFO - 2024-12-09 07:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:35:10 --> Utf8 Class Initialized
INFO - 2024-12-09 07:35:10 --> URI Class Initialized
INFO - 2024-12-09 07:35:10 --> Router Class Initialized
INFO - 2024-12-09 07:35:10 --> Output Class Initialized
INFO - 2024-12-09 07:35:10 --> Security Class Initialized
DEBUG - 2024-12-09 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:35:10 --> CSRF cookie sent
INFO - 2024-12-09 07:35:10 --> CSRF token verified
INFO - 2024-12-09 07:35:10 --> Input Class Initialized
INFO - 2024-12-09 07:35:10 --> Language Class Initialized
INFO - 2024-12-09 07:35:10 --> Loader Class Initialized
INFO - 2024-12-09 07:35:10 --> Helper loaded: url_helper
INFO - 2024-12-09 07:35:10 --> Helper loaded: form_helper
INFO - 2024-12-09 07:35:10 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:35:10 --> Form Validation Class Initialized
INFO - 2024-12-09 07:35:10 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:35:10 --> Controller Class Initialized
INFO - 2024-12-09 07:35:10 --> Model "Review_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "Category_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "User_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:35:10 --> Config Class Initialized
INFO - 2024-12-09 07:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 07:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 07:35:10 --> Utf8 Class Initialized
INFO - 2024-12-09 07:35:10 --> URI Class Initialized
INFO - 2024-12-09 07:35:10 --> Router Class Initialized
INFO - 2024-12-09 07:35:10 --> Output Class Initialized
INFO - 2024-12-09 07:35:10 --> Security Class Initialized
DEBUG - 2024-12-09 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 07:35:10 --> CSRF cookie sent
INFO - 2024-12-09 07:35:10 --> Input Class Initialized
INFO - 2024-12-09 07:35:10 --> Language Class Initialized
INFO - 2024-12-09 07:35:10 --> Loader Class Initialized
INFO - 2024-12-09 07:35:10 --> Helper loaded: url_helper
INFO - 2024-12-09 07:35:10 --> Helper loaded: form_helper
INFO - 2024-12-09 07:35:10 --> Database Driver Class Initialized
DEBUG - 2024-12-09 07:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 07:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 07:35:10 --> Form Validation Class Initialized
INFO - 2024-12-09 07:35:10 --> Model "Culinary_model" initialized
INFO - 2024-12-09 07:35:10 --> Controller Class Initialized
INFO - 2024-12-09 07:35:10 --> Model "Review_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "Category_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "User_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-09 07:35:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-09 07:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-09 07:35:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-09 07:35:10 --> Final output sent to browser
DEBUG - 2024-12-09 07:35:10 --> Total execution time: 0.0616
