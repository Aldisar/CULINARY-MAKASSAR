<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-04 03:30:01 --> Config Class Initialized
INFO - 2024-12-04 03:30:01 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:01 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:01 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:02 --> URI Class Initialized
INFO - 2024-12-04 03:30:02 --> Router Class Initialized
INFO - 2024-12-04 03:30:02 --> Output Class Initialized
INFO - 2024-12-04 03:30:02 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:02 --> CSRF cookie sent
INFO - 2024-12-04 03:30:02 --> Input Class Initialized
INFO - 2024-12-04 03:30:02 --> Language Class Initialized
INFO - 2024-12-04 03:30:02 --> Loader Class Initialized
INFO - 2024-12-04 03:30:02 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:02 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:02 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:02 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:02 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:02 --> Controller Class Initialized
INFO - 2024-12-04 03:30:02 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:02 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:02 --> Config Class Initialized
INFO - 2024-12-04 03:30:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:02 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:02 --> URI Class Initialized
INFO - 2024-12-04 03:30:02 --> Router Class Initialized
INFO - 2024-12-04 03:30:02 --> Output Class Initialized
INFO - 2024-12-04 03:30:02 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:02 --> CSRF cookie sent
INFO - 2024-12-04 03:30:02 --> Input Class Initialized
INFO - 2024-12-04 03:30:02 --> Language Class Initialized
INFO - 2024-12-04 03:30:02 --> Loader Class Initialized
INFO - 2024-12-04 03:30:02 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:02 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:02 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:02 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:02 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:02 --> Controller Class Initialized
INFO - 2024-12-04 03:30:02 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:02 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 03:30:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 03:30:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-04 03:30:02 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:02 --> Total execution time: 0.1546
INFO - 2024-12-04 03:30:25 --> Config Class Initialized
INFO - 2024-12-04 03:30:25 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:25 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:25 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:25 --> URI Class Initialized
INFO - 2024-12-04 03:30:25 --> Router Class Initialized
INFO - 2024-12-04 03:30:25 --> Output Class Initialized
INFO - 2024-12-04 03:30:25 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:25 --> CSRF cookie sent
INFO - 2024-12-04 03:30:25 --> CSRF token verified
INFO - 2024-12-04 03:30:25 --> Input Class Initialized
INFO - 2024-12-04 03:30:25 --> Language Class Initialized
INFO - 2024-12-04 03:30:25 --> Loader Class Initialized
INFO - 2024-12-04 03:30:25 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:25 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:25 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:25 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:25 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:25 --> Controller Class Initialized
INFO - 2024-12-04 03:30:25 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "Review_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "News_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:25 --> Config Class Initialized
INFO - 2024-12-04 03:30:25 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:25 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:25 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:25 --> URI Class Initialized
INFO - 2024-12-04 03:30:25 --> Router Class Initialized
INFO - 2024-12-04 03:30:25 --> Output Class Initialized
INFO - 2024-12-04 03:30:25 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:25 --> CSRF cookie sent
INFO - 2024-12-04 03:30:25 --> Input Class Initialized
INFO - 2024-12-04 03:30:25 --> Language Class Initialized
INFO - 2024-12-04 03:30:25 --> Loader Class Initialized
INFO - 2024-12-04 03:30:25 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:25 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:25 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:25 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:25 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:25 --> Controller Class Initialized
INFO - 2024-12-04 03:30:25 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 03:30:25 --> Query result: stdClass Object
(
    [view_count] => 27
)

INFO - 2024-12-04 03:30:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 03:30:25 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:25 --> Total execution time: 0.2242
INFO - 2024-12-04 03:30:29 --> Config Class Initialized
INFO - 2024-12-04 03:30:29 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:29 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:29 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:29 --> URI Class Initialized
INFO - 2024-12-04 03:30:29 --> Router Class Initialized
INFO - 2024-12-04 03:30:29 --> Output Class Initialized
INFO - 2024-12-04 03:30:29 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:29 --> CSRF cookie sent
INFO - 2024-12-04 03:30:29 --> Input Class Initialized
INFO - 2024-12-04 03:30:29 --> Language Class Initialized
INFO - 2024-12-04 03:30:29 --> Loader Class Initialized
INFO - 2024-12-04 03:30:29 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:29 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:29 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:29 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:29 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:29 --> Controller Class Initialized
INFO - 2024-12-04 03:30:29 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:29 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 03:30:29 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:29 --> Total execution time: 0.1596
INFO - 2024-12-04 03:30:32 --> Config Class Initialized
INFO - 2024-12-04 03:30:32 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:32 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:32 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:32 --> URI Class Initialized
INFO - 2024-12-04 03:30:32 --> Router Class Initialized
INFO - 2024-12-04 03:30:32 --> Output Class Initialized
INFO - 2024-12-04 03:30:32 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:32 --> CSRF cookie sent
INFO - 2024-12-04 03:30:32 --> Input Class Initialized
INFO - 2024-12-04 03:30:32 --> Language Class Initialized
INFO - 2024-12-04 03:30:32 --> Loader Class Initialized
INFO - 2024-12-04 03:30:32 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:32 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:32 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:32 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:32 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:32 --> Controller Class Initialized
INFO - 2024-12-04 03:30:32 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:32 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-04 03:30:32 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:32 --> Total execution time: 0.1098
INFO - 2024-12-04 03:30:33 --> Config Class Initialized
INFO - 2024-12-04 03:30:33 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:33 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:33 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:33 --> URI Class Initialized
INFO - 2024-12-04 03:30:33 --> Router Class Initialized
INFO - 2024-12-04 03:30:33 --> Output Class Initialized
INFO - 2024-12-04 03:30:33 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:33 --> CSRF cookie sent
INFO - 2024-12-04 03:30:33 --> CSRF token verified
INFO - 2024-12-04 03:30:33 --> Input Class Initialized
INFO - 2024-12-04 03:30:33 --> Language Class Initialized
INFO - 2024-12-04 03:30:33 --> Loader Class Initialized
INFO - 2024-12-04 03:30:33 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:33 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:33 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:33 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:33 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:33 --> Controller Class Initialized
INFO - 2024-12-04 03:30:33 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:33 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:33 --> Config Class Initialized
INFO - 2024-12-04 03:30:33 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:33 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:33 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:33 --> URI Class Initialized
INFO - 2024-12-04 03:30:33 --> Router Class Initialized
INFO - 2024-12-04 03:30:33 --> Output Class Initialized
INFO - 2024-12-04 03:30:33 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:33 --> CSRF cookie sent
INFO - 2024-12-04 03:30:33 --> Input Class Initialized
INFO - 2024-12-04 03:30:33 --> Language Class Initialized
INFO - 2024-12-04 03:30:33 --> Loader Class Initialized
INFO - 2024-12-04 03:30:33 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:33 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:33 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:33 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:33 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:33 --> Controller Class Initialized
INFO - 2024-12-04 03:30:33 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:33 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 03:30:33 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:33 --> Total execution time: 0.0678
INFO - 2024-12-04 03:30:36 --> Config Class Initialized
INFO - 2024-12-04 03:30:36 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:36 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:36 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:36 --> URI Class Initialized
INFO - 2024-12-04 03:30:36 --> Router Class Initialized
INFO - 2024-12-04 03:30:36 --> Output Class Initialized
INFO - 2024-12-04 03:30:36 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:36 --> CSRF cookie sent
INFO - 2024-12-04 03:30:36 --> Input Class Initialized
INFO - 2024-12-04 03:30:36 --> Language Class Initialized
INFO - 2024-12-04 03:30:36 --> Loader Class Initialized
INFO - 2024-12-04 03:30:36 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:36 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:36 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:36 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:36 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:36 --> Controller Class Initialized
INFO - 2024-12-04 03:30:36 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:36 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:36 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 03:30:36 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:36 --> Total execution time: 0.0624
INFO - 2024-12-04 03:30:38 --> Config Class Initialized
INFO - 2024-12-04 03:30:38 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:38 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:38 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:38 --> URI Class Initialized
INFO - 2024-12-04 03:30:38 --> Router Class Initialized
INFO - 2024-12-04 03:30:38 --> Output Class Initialized
INFO - 2024-12-04 03:30:38 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:38 --> CSRF cookie sent
INFO - 2024-12-04 03:30:38 --> Input Class Initialized
INFO - 2024-12-04 03:30:38 --> Language Class Initialized
INFO - 2024-12-04 03:30:38 --> Loader Class Initialized
INFO - 2024-12-04 03:30:38 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:38 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:38 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:38 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:38 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:38 --> Controller Class Initialized
INFO - 2024-12-04 03:30:38 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:38 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 03:30:38 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:38 --> Total execution time: 0.0842
INFO - 2024-12-04 03:30:49 --> Config Class Initialized
INFO - 2024-12-04 03:30:49 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:49 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:49 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:49 --> URI Class Initialized
INFO - 2024-12-04 03:30:49 --> Router Class Initialized
INFO - 2024-12-04 03:30:49 --> Output Class Initialized
INFO - 2024-12-04 03:30:49 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:49 --> CSRF cookie sent
INFO - 2024-12-04 03:30:49 --> Input Class Initialized
INFO - 2024-12-04 03:30:49 --> Language Class Initialized
INFO - 2024-12-04 03:30:49 --> Loader Class Initialized
INFO - 2024-12-04 03:30:49 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:49 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:49 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:49 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:49 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:49 --> Controller Class Initialized
INFO - 2024-12-04 03:30:49 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:49 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:49 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 03:30:49 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:49 --> Total execution time: 0.0801
INFO - 2024-12-04 03:30:50 --> Config Class Initialized
INFO - 2024-12-04 03:30:50 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:50 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:50 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:50 --> URI Class Initialized
INFO - 2024-12-04 03:30:50 --> Router Class Initialized
INFO - 2024-12-04 03:30:50 --> Output Class Initialized
INFO - 2024-12-04 03:30:50 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:50 --> CSRF cookie sent
INFO - 2024-12-04 03:30:50 --> Input Class Initialized
INFO - 2024-12-04 03:30:50 --> Language Class Initialized
INFO - 2024-12-04 03:30:50 --> Loader Class Initialized
INFO - 2024-12-04 03:30:50 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:50 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:50 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:50 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:50 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:50 --> Controller Class Initialized
INFO - 2024-12-04 03:30:50 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:50 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:50 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-04 03:30:50 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:50 --> Total execution time: 0.0737
INFO - 2024-12-04 03:30:52 --> Config Class Initialized
INFO - 2024-12-04 03:30:52 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:52 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:52 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:52 --> URI Class Initialized
INFO - 2024-12-04 03:30:52 --> Router Class Initialized
INFO - 2024-12-04 03:30:52 --> Output Class Initialized
INFO - 2024-12-04 03:30:52 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:52 --> CSRF cookie sent
INFO - 2024-12-04 03:30:52 --> Input Class Initialized
INFO - 2024-12-04 03:30:52 --> Language Class Initialized
INFO - 2024-12-04 03:30:52 --> Loader Class Initialized
INFO - 2024-12-04 03:30:52 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:52 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:52 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:52 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:52 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:52 --> Controller Class Initialized
INFO - 2024-12-04 03:30:52 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:52 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 03:30:52 --> Query result: stdClass Object
(
    [view_count] => 27
)

INFO - 2024-12-04 03:30:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 03:30:53 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:53 --> Total execution time: 0.0753
INFO - 2024-12-04 03:30:53 --> Config Class Initialized
INFO - 2024-12-04 03:30:53 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:30:53 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:30:53 --> Utf8 Class Initialized
INFO - 2024-12-04 03:30:53 --> URI Class Initialized
INFO - 2024-12-04 03:30:53 --> Router Class Initialized
INFO - 2024-12-04 03:30:53 --> Output Class Initialized
INFO - 2024-12-04 03:30:53 --> Security Class Initialized
DEBUG - 2024-12-04 03:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:30:53 --> CSRF cookie sent
INFO - 2024-12-04 03:30:53 --> Input Class Initialized
INFO - 2024-12-04 03:30:53 --> Language Class Initialized
INFO - 2024-12-04 03:30:53 --> Loader Class Initialized
INFO - 2024-12-04 03:30:53 --> Helper loaded: url_helper
INFO - 2024-12-04 03:30:53 --> Helper loaded: form_helper
INFO - 2024-12-04 03:30:53 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:30:53 --> Form Validation Class Initialized
INFO - 2024-12-04 03:30:53 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:30:53 --> Controller Class Initialized
INFO - 2024-12-04 03:30:53 --> Model "Category_model" initialized
INFO - 2024-12-04 03:30:53 --> Model "User_model" initialized
INFO - 2024-12-04 03:30:53 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:30:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:30:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:30:53 --> Model "Contact_model" initialized
INFO - 2024-12-04 03:30:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-04 03:30:53 --> Final output sent to browser
DEBUG - 2024-12-04 03:30:53 --> Total execution time: 0.1019
INFO - 2024-12-04 03:31:11 --> Config Class Initialized
INFO - 2024-12-04 03:31:11 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:31:11 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:31:11 --> Utf8 Class Initialized
INFO - 2024-12-04 03:31:11 --> URI Class Initialized
INFO - 2024-12-04 03:31:11 --> Router Class Initialized
INFO - 2024-12-04 03:31:11 --> Output Class Initialized
INFO - 2024-12-04 03:31:11 --> Security Class Initialized
DEBUG - 2024-12-04 03:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:31:11 --> CSRF cookie sent
INFO - 2024-12-04 03:31:11 --> Input Class Initialized
INFO - 2024-12-04 03:31:11 --> Language Class Initialized
INFO - 2024-12-04 03:31:11 --> Loader Class Initialized
INFO - 2024-12-04 03:31:11 --> Helper loaded: url_helper
INFO - 2024-12-04 03:31:11 --> Helper loaded: form_helper
INFO - 2024-12-04 03:31:11 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:31:11 --> Form Validation Class Initialized
INFO - 2024-12-04 03:31:11 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:31:11 --> Controller Class Initialized
INFO - 2024-12-04 03:31:11 --> Model "Category_model" initialized
INFO - 2024-12-04 03:31:11 --> Model "User_model" initialized
INFO - 2024-12-04 03:31:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:31:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:31:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 03:31:11 --> Query result: stdClass Object
(
    [view_count] => 27
)

INFO - 2024-12-04 03:31:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 03:31:11 --> Final output sent to browser
DEBUG - 2024-12-04 03:31:11 --> Total execution time: 0.1130
INFO - 2024-12-04 03:31:14 --> Config Class Initialized
INFO - 2024-12-04 03:31:14 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:31:14 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:31:14 --> Utf8 Class Initialized
INFO - 2024-12-04 03:31:14 --> URI Class Initialized
INFO - 2024-12-04 03:31:14 --> Router Class Initialized
INFO - 2024-12-04 03:31:14 --> Output Class Initialized
INFO - 2024-12-04 03:31:14 --> Security Class Initialized
DEBUG - 2024-12-04 03:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:31:14 --> CSRF cookie sent
INFO - 2024-12-04 03:31:14 --> Input Class Initialized
INFO - 2024-12-04 03:31:14 --> Language Class Initialized
INFO - 2024-12-04 03:31:14 --> Loader Class Initialized
INFO - 2024-12-04 03:31:14 --> Helper loaded: url_helper
INFO - 2024-12-04 03:31:14 --> Helper loaded: form_helper
INFO - 2024-12-04 03:31:14 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:31:14 --> Form Validation Class Initialized
INFO - 2024-12-04 03:31:14 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:31:14 --> Controller Class Initialized
INFO - 2024-12-04 03:31:14 --> Model "Category_model" initialized
INFO - 2024-12-04 03:31:14 --> Model "User_model" initialized
INFO - 2024-12-04 03:31:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:31:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:31:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 03:31:14 --> Final output sent to browser
DEBUG - 2024-12-04 03:31:14 --> Total execution time: 0.0731
INFO - 2024-12-04 03:31:15 --> Config Class Initialized
INFO - 2024-12-04 03:31:15 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:31:15 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:31:15 --> Utf8 Class Initialized
INFO - 2024-12-04 03:31:15 --> URI Class Initialized
INFO - 2024-12-04 03:31:15 --> Router Class Initialized
INFO - 2024-12-04 03:31:15 --> Output Class Initialized
INFO - 2024-12-04 03:31:15 --> Security Class Initialized
DEBUG - 2024-12-04 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:31:15 --> CSRF cookie sent
INFO - 2024-12-04 03:31:15 --> Input Class Initialized
INFO - 2024-12-04 03:31:15 --> Language Class Initialized
INFO - 2024-12-04 03:31:15 --> Loader Class Initialized
INFO - 2024-12-04 03:31:15 --> Helper loaded: url_helper
INFO - 2024-12-04 03:31:15 --> Helper loaded: form_helper
INFO - 2024-12-04 03:31:15 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:31:15 --> Form Validation Class Initialized
INFO - 2024-12-04 03:31:15 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:31:15 --> Controller Class Initialized
INFO - 2024-12-04 03:31:15 --> Model "Category_model" initialized
INFO - 2024-12-04 03:31:15 --> Model "User_model" initialized
INFO - 2024-12-04 03:31:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:31:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:31:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:31:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 03:31:15 --> Final output sent to browser
DEBUG - 2024-12-04 03:31:15 --> Total execution time: 0.1010
INFO - 2024-12-04 03:31:17 --> Config Class Initialized
INFO - 2024-12-04 03:31:17 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:31:17 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:31:17 --> Utf8 Class Initialized
INFO - 2024-12-04 03:31:17 --> URI Class Initialized
INFO - 2024-12-04 03:31:17 --> Router Class Initialized
INFO - 2024-12-04 03:31:17 --> Output Class Initialized
INFO - 2024-12-04 03:31:17 --> Security Class Initialized
DEBUG - 2024-12-04 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:31:17 --> CSRF cookie sent
INFO - 2024-12-04 03:31:17 --> Input Class Initialized
INFO - 2024-12-04 03:31:17 --> Language Class Initialized
INFO - 2024-12-04 03:31:17 --> Loader Class Initialized
INFO - 2024-12-04 03:31:17 --> Helper loaded: url_helper
INFO - 2024-12-04 03:31:17 --> Helper loaded: form_helper
INFO - 2024-12-04 03:31:17 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:31:17 --> Form Validation Class Initialized
INFO - 2024-12-04 03:31:17 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:31:17 --> Controller Class Initialized
INFO - 2024-12-04 03:31:17 --> Model "Category_model" initialized
INFO - 2024-12-04 03:31:17 --> Model "User_model" initialized
INFO - 2024-12-04 03:31:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 03:31:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:31:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 03:31:17 --> Final output sent to browser
DEBUG - 2024-12-04 03:31:17 --> Total execution time: 0.0672
INFO - 2024-12-04 03:34:29 --> Config Class Initialized
INFO - 2024-12-04 03:34:29 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:29 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:29 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:29 --> URI Class Initialized
INFO - 2024-12-04 03:34:29 --> Router Class Initialized
INFO - 2024-12-04 03:34:29 --> Output Class Initialized
INFO - 2024-12-04 03:34:29 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:29 --> CSRF cookie sent
INFO - 2024-12-04 03:34:29 --> Input Class Initialized
INFO - 2024-12-04 03:34:29 --> Language Class Initialized
INFO - 2024-12-04 03:34:29 --> Loader Class Initialized
INFO - 2024-12-04 03:34:29 --> Helper loaded: url_helper
INFO - 2024-12-04 03:34:29 --> Helper loaded: form_helper
INFO - 2024-12-04 03:34:29 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:34:29 --> Form Validation Class Initialized
INFO - 2024-12-04 03:34:29 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:34:29 --> Controller Class Initialized
INFO - 2024-12-04 03:34:29 --> Model "News_model" initialized
INFO - 2024-12-04 03:34:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 03:34:30 --> Final output sent to browser
DEBUG - 2024-12-04 03:34:30 --> Total execution time: 0.8117
INFO - 2024-12-04 03:34:35 --> Config Class Initialized
INFO - 2024-12-04 03:34:35 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:35 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:35 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:35 --> URI Class Initialized
INFO - 2024-12-04 03:34:35 --> Router Class Initialized
INFO - 2024-12-04 03:34:35 --> Output Class Initialized
INFO - 2024-12-04 03:34:35 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:35 --> CSRF cookie sent
INFO - 2024-12-04 03:34:35 --> Input Class Initialized
INFO - 2024-12-04 03:34:35 --> Language Class Initialized
INFO - 2024-12-04 03:34:35 --> Loader Class Initialized
INFO - 2024-12-04 03:34:35 --> Helper loaded: url_helper
INFO - 2024-12-04 03:34:35 --> Helper loaded: form_helper
INFO - 2024-12-04 03:34:35 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:34:35 --> Form Validation Class Initialized
INFO - 2024-12-04 03:34:35 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:34:35 --> Controller Class Initialized
INFO - 2024-12-04 03:34:35 --> Model "User_model" initialized
INFO - 2024-12-04 03:34:35 --> Model "Category_model" initialized
INFO - 2024-12-04 03:34:35 --> Model "Review_model" initialized
INFO - 2024-12-04 03:34:35 --> Model "News_model" initialized
INFO - 2024-12-04 03:34:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:34:35 --> Config Class Initialized
INFO - 2024-12-04 03:34:35 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:35 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:35 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:35 --> URI Class Initialized
INFO - 2024-12-04 03:34:35 --> Router Class Initialized
INFO - 2024-12-04 03:34:35 --> Output Class Initialized
INFO - 2024-12-04 03:34:35 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:35 --> CSRF cookie sent
INFO - 2024-12-04 03:34:35 --> Input Class Initialized
INFO - 2024-12-04 03:34:36 --> Language Class Initialized
INFO - 2024-12-04 03:34:36 --> Loader Class Initialized
INFO - 2024-12-04 03:34:36 --> Helper loaded: url_helper
INFO - 2024-12-04 03:34:36 --> Helper loaded: form_helper
INFO - 2024-12-04 03:34:36 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:34:36 --> Form Validation Class Initialized
INFO - 2024-12-04 03:34:36 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:34:36 --> Controller Class Initialized
INFO - 2024-12-04 03:34:36 --> Model "User_model" initialized
INFO - 2024-12-04 03:34:36 --> Model "Category_model" initialized
INFO - 2024-12-04 03:34:36 --> Model "Review_model" initialized
INFO - 2024-12-04 03:34:36 --> Model "News_model" initialized
INFO - 2024-12-04 03:34:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:34:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 03:34:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 03:34:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-04 03:34:36 --> Final output sent to browser
DEBUG - 2024-12-04 03:34:36 --> Total execution time: 0.1933
INFO - 2024-12-04 03:34:41 --> Config Class Initialized
INFO - 2024-12-04 03:34:41 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:41 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:41 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:41 --> URI Class Initialized
INFO - 2024-12-04 03:34:41 --> Router Class Initialized
INFO - 2024-12-04 03:34:41 --> Output Class Initialized
INFO - 2024-12-04 03:34:41 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:41 --> CSRF cookie sent
INFO - 2024-12-04 03:34:41 --> CSRF token verified
INFO - 2024-12-04 03:34:41 --> Input Class Initialized
INFO - 2024-12-04 03:34:41 --> Language Class Initialized
INFO - 2024-12-04 03:34:41 --> Loader Class Initialized
INFO - 2024-12-04 03:34:41 --> Helper loaded: url_helper
INFO - 2024-12-04 03:34:41 --> Helper loaded: form_helper
INFO - 2024-12-04 03:34:41 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:34:41 --> Form Validation Class Initialized
INFO - 2024-12-04 03:34:41 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:34:41 --> Controller Class Initialized
INFO - 2024-12-04 03:34:41 --> Model "User_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "Category_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "Review_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "News_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:34:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:34:41 --> Config Class Initialized
INFO - 2024-12-04 03:34:41 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:41 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:41 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:41 --> URI Class Initialized
INFO - 2024-12-04 03:34:41 --> Router Class Initialized
INFO - 2024-12-04 03:34:41 --> Output Class Initialized
INFO - 2024-12-04 03:34:41 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:41 --> CSRF cookie sent
INFO - 2024-12-04 03:34:41 --> Input Class Initialized
INFO - 2024-12-04 03:34:41 --> Language Class Initialized
INFO - 2024-12-04 03:34:41 --> Loader Class Initialized
INFO - 2024-12-04 03:34:41 --> Helper loaded: url_helper
INFO - 2024-12-04 03:34:41 --> Helper loaded: form_helper
INFO - 2024-12-04 03:34:41 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:34:41 --> Form Validation Class Initialized
INFO - 2024-12-04 03:34:41 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:34:41 --> Controller Class Initialized
INFO - 2024-12-04 03:34:41 --> Model "User_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "Category_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "Review_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "News_model" initialized
INFO - 2024-12-04 03:34:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 03:34:41 --> Query result: stdClass Object
(
    [view_count] => 28
)

INFO - 2024-12-04 03:34:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 03:34:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 03:34:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 03:34:41 --> Final output sent to browser
DEBUG - 2024-12-04 03:34:41 --> Total execution time: 0.1487
INFO - 2024-12-04 03:34:41 --> Config Class Initialized
INFO - 2024-12-04 03:34:41 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:41 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:41 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:41 --> URI Class Initialized
INFO - 2024-12-04 03:34:41 --> Router Class Initialized
INFO - 2024-12-04 03:34:41 --> Output Class Initialized
INFO - 2024-12-04 03:34:41 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:41 --> CSRF cookie sent
INFO - 2024-12-04 03:34:41 --> Input Class Initialized
INFO - 2024-12-04 03:34:41 --> Language Class Initialized
ERROR - 2024-12-04 03:34:41 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-04 03:34:51 --> Config Class Initialized
INFO - 2024-12-04 03:34:51 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:34:51 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:34:51 --> Utf8 Class Initialized
INFO - 2024-12-04 03:34:51 --> URI Class Initialized
INFO - 2024-12-04 03:34:51 --> Router Class Initialized
INFO - 2024-12-04 03:34:52 --> Output Class Initialized
INFO - 2024-12-04 03:34:52 --> Security Class Initialized
DEBUG - 2024-12-04 03:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:34:52 --> CSRF cookie sent
INFO - 2024-12-04 03:34:52 --> Input Class Initialized
INFO - 2024-12-04 03:34:52 --> Language Class Initialized
INFO - 2024-12-04 03:34:52 --> Loader Class Initialized
INFO - 2024-12-04 03:34:52 --> Helper loaded: url_helper
INFO - 2024-12-04 03:34:52 --> Helper loaded: form_helper
INFO - 2024-12-04 03:34:52 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:34:52 --> Form Validation Class Initialized
INFO - 2024-12-04 03:34:52 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:34:52 --> Controller Class Initialized
INFO - 2024-12-04 03:34:52 --> Model "User_model" initialized
DEBUG - 2024-12-04 03:34:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 03:34:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 03:34:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 03:34:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 03:34:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-04 03:34:52 --> Final output sent to browser
DEBUG - 2024-12-04 03:34:52 --> Total execution time: 0.2447
INFO - 2024-12-04 03:37:23 --> Config Class Initialized
INFO - 2024-12-04 03:37:23 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:37:23 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:37:23 --> Utf8 Class Initialized
INFO - 2024-12-04 03:37:23 --> URI Class Initialized
INFO - 2024-12-04 03:37:23 --> Router Class Initialized
INFO - 2024-12-04 03:37:23 --> Output Class Initialized
INFO - 2024-12-04 03:37:23 --> Security Class Initialized
DEBUG - 2024-12-04 03:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:37:23 --> CSRF cookie sent
INFO - 2024-12-04 03:37:23 --> Input Class Initialized
INFO - 2024-12-04 03:37:23 --> Language Class Initialized
INFO - 2024-12-04 03:37:23 --> Loader Class Initialized
INFO - 2024-12-04 03:37:23 --> Helper loaded: url_helper
INFO - 2024-12-04 03:37:23 --> Helper loaded: form_helper
INFO - 2024-12-04 03:37:23 --> Database Driver Class Initialized
DEBUG - 2024-12-04 03:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 03:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 03:37:23 --> Form Validation Class Initialized
INFO - 2024-12-04 03:37:23 --> Model "Culinary_model" initialized
INFO - 2024-12-04 03:37:23 --> Controller Class Initialized
INFO - 2024-12-04 03:37:23 --> Model "User_model" initialized
INFO - 2024-12-04 03:37:23 --> Model "Category_model" initialized
INFO - 2024-12-04 03:37:23 --> Model "Review_model" initialized
INFO - 2024-12-04 03:37:23 --> Model "News_model" initialized
INFO - 2024-12-04 03:37:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 03:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 03:37:23 --> Query result: stdClass Object
(
    [view_count] => 29
)

INFO - 2024-12-04 03:37:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 03:37:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 03:37:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 03:37:23 --> Final output sent to browser
DEBUG - 2024-12-04 03:37:23 --> Total execution time: 0.2741
INFO - 2024-12-04 03:37:24 --> Config Class Initialized
INFO - 2024-12-04 03:37:24 --> Hooks Class Initialized
DEBUG - 2024-12-04 03:37:24 --> UTF-8 Support Enabled
INFO - 2024-12-04 03:37:24 --> Utf8 Class Initialized
INFO - 2024-12-04 03:37:24 --> URI Class Initialized
INFO - 2024-12-04 03:37:24 --> Router Class Initialized
INFO - 2024-12-04 03:37:24 --> Output Class Initialized
INFO - 2024-12-04 03:37:24 --> Security Class Initialized
DEBUG - 2024-12-04 03:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 03:37:24 --> CSRF cookie sent
INFO - 2024-12-04 03:37:24 --> Input Class Initialized
INFO - 2024-12-04 03:37:24 --> Language Class Initialized
ERROR - 2024-12-04 03:37:24 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-04 04:42:02 --> Config Class Initialized
INFO - 2024-12-04 04:42:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 04:42:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 04:42:02 --> Utf8 Class Initialized
INFO - 2024-12-04 04:42:02 --> URI Class Initialized
INFO - 2024-12-04 04:42:03 --> Router Class Initialized
INFO - 2024-12-04 04:42:03 --> Output Class Initialized
INFO - 2024-12-04 04:42:03 --> Security Class Initialized
DEBUG - 2024-12-04 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 04:42:03 --> CSRF cookie sent
INFO - 2024-12-04 04:42:03 --> Input Class Initialized
INFO - 2024-12-04 04:42:03 --> Language Class Initialized
INFO - 2024-12-04 04:42:04 --> Loader Class Initialized
INFO - 2024-12-04 04:42:04 --> Helper loaded: url_helper
INFO - 2024-12-04 04:42:04 --> Helper loaded: form_helper
INFO - 2024-12-04 04:42:04 --> Database Driver Class Initialized
DEBUG - 2024-12-04 04:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 04:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 04:42:06 --> Form Validation Class Initialized
INFO - 2024-12-04 04:42:06 --> Model "Culinary_model" initialized
INFO - 2024-12-04 04:42:06 --> Controller Class Initialized
INFO - 2024-12-04 04:42:06 --> Model "User_model" initialized
INFO - 2024-12-04 04:42:06 --> Model "Category_model" initialized
INFO - 2024-12-04 04:42:06 --> Model "Review_model" initialized
INFO - 2024-12-04 04:42:06 --> Model "News_model" initialized
INFO - 2024-12-04 04:42:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 04:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 04:42:07 --> Query result: stdClass Object
(
    [view_count] => 30
)

INFO - 2024-12-04 04:42:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 04:42:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 04:42:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 04:42:08 --> Final output sent to browser
DEBUG - 2024-12-04 04:42:08 --> Total execution time: 6.2969
INFO - 2024-12-04 08:31:31 --> Config Class Initialized
INFO - 2024-12-04 08:31:31 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:31:31 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:31:31 --> Utf8 Class Initialized
INFO - 2024-12-04 08:31:31 --> URI Class Initialized
INFO - 2024-12-04 08:31:32 --> Router Class Initialized
INFO - 2024-12-04 08:31:32 --> Output Class Initialized
INFO - 2024-12-04 08:31:32 --> Security Class Initialized
DEBUG - 2024-12-04 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:31:32 --> CSRF cookie sent
INFO - 2024-12-04 08:31:32 --> Input Class Initialized
INFO - 2024-12-04 08:31:32 --> Language Class Initialized
INFO - 2024-12-04 08:31:32 --> Loader Class Initialized
INFO - 2024-12-04 08:31:32 --> Helper loaded: url_helper
INFO - 2024-12-04 08:31:32 --> Helper loaded: form_helper
INFO - 2024-12-04 08:31:32 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:31:34 --> Form Validation Class Initialized
INFO - 2024-12-04 08:31:34 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:31:34 --> Controller Class Initialized
INFO - 2024-12-04 08:31:34 --> Model "User_model" initialized
INFO - 2024-12-04 08:31:34 --> Model "Category_model" initialized
INFO - 2024-12-04 08:31:34 --> Model "Review_model" initialized
INFO - 2024-12-04 08:31:34 --> Model "News_model" initialized
INFO - 2024-12-04 08:31:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 08:31:34 --> Query result: stdClass Object
(
    [view_count] => 31
)

INFO - 2024-12-04 08:31:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 08:31:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 08:31:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 08:31:34 --> Final output sent to browser
DEBUG - 2024-12-04 08:31:34 --> Total execution time: 4.0929
INFO - 2024-12-04 08:31:51 --> Config Class Initialized
INFO - 2024-12-04 08:31:51 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:31:51 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:31:51 --> Utf8 Class Initialized
INFO - 2024-12-04 08:31:51 --> URI Class Initialized
INFO - 2024-12-04 08:31:51 --> Router Class Initialized
INFO - 2024-12-04 08:31:51 --> Output Class Initialized
INFO - 2024-12-04 08:31:51 --> Security Class Initialized
DEBUG - 2024-12-04 08:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:31:51 --> CSRF cookie sent
INFO - 2024-12-04 08:31:51 --> Input Class Initialized
INFO - 2024-12-04 08:31:51 --> Language Class Initialized
INFO - 2024-12-04 08:31:51 --> Loader Class Initialized
INFO - 2024-12-04 08:31:51 --> Helper loaded: url_helper
INFO - 2024-12-04 08:31:51 --> Helper loaded: form_helper
INFO - 2024-12-04 08:31:51 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:31:52 --> Form Validation Class Initialized
INFO - 2024-12-04 08:31:52 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:31:52 --> Controller Class Initialized
INFO - 2024-12-04 08:31:52 --> Model "User_model" initialized
INFO - 2024-12-04 08:31:52 --> Model "Category_model" initialized
INFO - 2024-12-04 08:31:52 --> Model "Review_model" initialized
INFO - 2024-12-04 08:31:52 --> Model "News_model" initialized
INFO - 2024-12-04 08:31:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:31:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 08:31:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 08:31:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-04 08:31:52 --> Final output sent to browser
DEBUG - 2024-12-04 08:31:52 --> Total execution time: 1.6237
INFO - 2024-12-04 08:32:09 --> Config Class Initialized
INFO - 2024-12-04 08:32:09 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:10 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:10 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:10 --> URI Class Initialized
INFO - 2024-12-04 08:32:10 --> Router Class Initialized
INFO - 2024-12-04 08:32:10 --> Output Class Initialized
INFO - 2024-12-04 08:32:10 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:10 --> CSRF cookie sent
INFO - 2024-12-04 08:32:10 --> CSRF token verified
INFO - 2024-12-04 08:32:10 --> Input Class Initialized
INFO - 2024-12-04 08:32:10 --> Language Class Initialized
INFO - 2024-12-04 08:32:10 --> Loader Class Initialized
INFO - 2024-12-04 08:32:10 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:10 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:10 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:10 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:10 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:10 --> Controller Class Initialized
INFO - 2024-12-04 08:32:10 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "Review_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "News_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:10 --> Config Class Initialized
INFO - 2024-12-04 08:32:10 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:10 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:10 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:10 --> URI Class Initialized
INFO - 2024-12-04 08:32:10 --> Router Class Initialized
INFO - 2024-12-04 08:32:10 --> Output Class Initialized
INFO - 2024-12-04 08:32:10 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:10 --> CSRF cookie sent
INFO - 2024-12-04 08:32:10 --> Input Class Initialized
INFO - 2024-12-04 08:32:10 --> Language Class Initialized
INFO - 2024-12-04 08:32:10 --> Loader Class Initialized
INFO - 2024-12-04 08:32:10 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:10 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:10 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:10 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:10 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:10 --> Controller Class Initialized
INFO - 2024-12-04 08:32:10 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 08:32:10 --> Query result: stdClass Object
(
    [view_count] => 31
)

INFO - 2024-12-04 08:32:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 08:32:10 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:10 --> Total execution time: 0.1333
INFO - 2024-12-04 08:32:15 --> Config Class Initialized
INFO - 2024-12-04 08:32:15 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:15 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:15 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:15 --> URI Class Initialized
INFO - 2024-12-04 08:32:15 --> Router Class Initialized
INFO - 2024-12-04 08:32:15 --> Output Class Initialized
INFO - 2024-12-04 08:32:15 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:15 --> CSRF cookie sent
INFO - 2024-12-04 08:32:15 --> Input Class Initialized
INFO - 2024-12-04 08:32:15 --> Language Class Initialized
INFO - 2024-12-04 08:32:15 --> Loader Class Initialized
INFO - 2024-12-04 08:32:15 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:15 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:15 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:15 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:15 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:15 --> Controller Class Initialized
INFO - 2024-12-04 08:32:15 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:15 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 08:32:15 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:15 --> Total execution time: 0.0758
INFO - 2024-12-04 08:32:16 --> Config Class Initialized
INFO - 2024-12-04 08:32:16 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:16 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:16 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:16 --> URI Class Initialized
INFO - 2024-12-04 08:32:16 --> Router Class Initialized
INFO - 2024-12-04 08:32:16 --> Output Class Initialized
INFO - 2024-12-04 08:32:16 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:16 --> CSRF cookie sent
INFO - 2024-12-04 08:32:16 --> Input Class Initialized
INFO - 2024-12-04 08:32:16 --> Language Class Initialized
INFO - 2024-12-04 08:32:16 --> Loader Class Initialized
INFO - 2024-12-04 08:32:16 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:16 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:16 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:16 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:16 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:16 --> Controller Class Initialized
INFO - 2024-12-04 08:32:16 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:16 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 08:32:16 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:16 --> Total execution time: 0.0579
INFO - 2024-12-04 08:32:18 --> Config Class Initialized
INFO - 2024-12-04 08:32:18 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:18 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:18 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:18 --> URI Class Initialized
INFO - 2024-12-04 08:32:18 --> Router Class Initialized
INFO - 2024-12-04 08:32:18 --> Output Class Initialized
INFO - 2024-12-04 08:32:18 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:18 --> CSRF cookie sent
INFO - 2024-12-04 08:32:18 --> Input Class Initialized
INFO - 2024-12-04 08:32:18 --> Language Class Initialized
INFO - 2024-12-04 08:32:18 --> Loader Class Initialized
INFO - 2024-12-04 08:32:18 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:18 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:18 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:18 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:18 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:18 --> Controller Class Initialized
INFO - 2024-12-04 08:32:18 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:18 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 08:32:19 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:19 --> Total execution time: 0.3852
INFO - 2024-12-04 08:32:29 --> Config Class Initialized
INFO - 2024-12-04 08:32:29 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:29 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:29 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:29 --> URI Class Initialized
INFO - 2024-12-04 08:32:29 --> Router Class Initialized
INFO - 2024-12-04 08:32:29 --> Output Class Initialized
INFO - 2024-12-04 08:32:29 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:29 --> CSRF cookie sent
INFO - 2024-12-04 08:32:29 --> Input Class Initialized
INFO - 2024-12-04 08:32:29 --> Language Class Initialized
INFO - 2024-12-04 08:32:29 --> Loader Class Initialized
INFO - 2024-12-04 08:32:29 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:29 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:29 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:29 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:29 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:29 --> Controller Class Initialized
INFO - 2024-12-04 08:32:29 --> Model "News_model" initialized
INFO - 2024-12-04 08:32:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 08:32:29 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:29 --> Total execution time: 0.1467
INFO - 2024-12-04 08:32:37 --> Config Class Initialized
INFO - 2024-12-04 08:32:37 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:37 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:37 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:37 --> URI Class Initialized
INFO - 2024-12-04 08:32:37 --> Router Class Initialized
INFO - 2024-12-04 08:32:37 --> Output Class Initialized
INFO - 2024-12-04 08:32:37 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:37 --> CSRF cookie sent
INFO - 2024-12-04 08:32:37 --> Input Class Initialized
INFO - 2024-12-04 08:32:37 --> Language Class Initialized
INFO - 2024-12-04 08:32:37 --> Loader Class Initialized
INFO - 2024-12-04 08:32:37 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:37 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:37 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:37 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:37 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:37 --> Controller Class Initialized
INFO - 2024-12-04 08:32:37 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:37 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:37 --> Model "Contact_model" initialized
INFO - 2024-12-04 08:32:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-04 08:32:37 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:37 --> Total execution time: 0.1155
INFO - 2024-12-04 08:32:39 --> Config Class Initialized
INFO - 2024-12-04 08:32:39 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:39 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:39 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:39 --> URI Class Initialized
INFO - 2024-12-04 08:32:39 --> Router Class Initialized
INFO - 2024-12-04 08:32:39 --> Output Class Initialized
INFO - 2024-12-04 08:32:39 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:40 --> CSRF cookie sent
INFO - 2024-12-04 08:32:40 --> Input Class Initialized
INFO - 2024-12-04 08:32:40 --> Language Class Initialized
INFO - 2024-12-04 08:32:40 --> Loader Class Initialized
INFO - 2024-12-04 08:32:40 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:40 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:40 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:40 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:40 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:40 --> Controller Class Initialized
INFO - 2024-12-04 08:32:40 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "Review_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "News_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:40 --> Config Class Initialized
INFO - 2024-12-04 08:32:40 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:40 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:40 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:40 --> URI Class Initialized
INFO - 2024-12-04 08:32:40 --> Router Class Initialized
INFO - 2024-12-04 08:32:40 --> Output Class Initialized
INFO - 2024-12-04 08:32:40 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:40 --> CSRF cookie sent
INFO - 2024-12-04 08:32:40 --> Input Class Initialized
INFO - 2024-12-04 08:32:40 --> Language Class Initialized
INFO - 2024-12-04 08:32:40 --> Loader Class Initialized
INFO - 2024-12-04 08:32:40 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:40 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:40 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:40 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:40 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:40 --> Controller Class Initialized
INFO - 2024-12-04 08:32:40 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "Review_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "News_model" initialized
INFO - 2024-12-04 08:32:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 08:32:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 08:32:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-04 08:32:41 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:41 --> Total execution time: 0.4146
INFO - 2024-12-04 08:32:44 --> Config Class Initialized
INFO - 2024-12-04 08:32:44 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:44 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:44 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:44 --> URI Class Initialized
INFO - 2024-12-04 08:32:44 --> Router Class Initialized
INFO - 2024-12-04 08:32:44 --> Output Class Initialized
INFO - 2024-12-04 08:32:44 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:44 --> CSRF cookie sent
INFO - 2024-12-04 08:32:44 --> CSRF token verified
INFO - 2024-12-04 08:32:44 --> Input Class Initialized
INFO - 2024-12-04 08:32:44 --> Language Class Initialized
INFO - 2024-12-04 08:32:44 --> Loader Class Initialized
INFO - 2024-12-04 08:32:44 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:44 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:44 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:44 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:44 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:44 --> Controller Class Initialized
INFO - 2024-12-04 08:32:44 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "Review_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "News_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:44 --> Config Class Initialized
INFO - 2024-12-04 08:32:44 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:44 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:44 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:44 --> URI Class Initialized
INFO - 2024-12-04 08:32:44 --> Router Class Initialized
INFO - 2024-12-04 08:32:44 --> Output Class Initialized
INFO - 2024-12-04 08:32:44 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:44 --> CSRF cookie sent
INFO - 2024-12-04 08:32:44 --> Input Class Initialized
INFO - 2024-12-04 08:32:44 --> Language Class Initialized
INFO - 2024-12-04 08:32:44 --> Loader Class Initialized
INFO - 2024-12-04 08:32:44 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:44 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:44 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:44 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:44 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:44 --> Controller Class Initialized
INFO - 2024-12-04 08:32:44 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 08:32:44 --> Query result: stdClass Object
(
    [view_count] => 31
)

INFO - 2024-12-04 08:32:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 08:32:44 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:44 --> Total execution time: 0.0624
INFO - 2024-12-04 08:32:47 --> Config Class Initialized
INFO - 2024-12-04 08:32:47 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:32:47 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:32:47 --> Utf8 Class Initialized
INFO - 2024-12-04 08:32:47 --> URI Class Initialized
INFO - 2024-12-04 08:32:47 --> Router Class Initialized
INFO - 2024-12-04 08:32:47 --> Output Class Initialized
INFO - 2024-12-04 08:32:47 --> Security Class Initialized
DEBUG - 2024-12-04 08:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:32:47 --> CSRF cookie sent
INFO - 2024-12-04 08:32:47 --> Input Class Initialized
INFO - 2024-12-04 08:32:47 --> Language Class Initialized
INFO - 2024-12-04 08:32:47 --> Loader Class Initialized
INFO - 2024-12-04 08:32:47 --> Helper loaded: url_helper
INFO - 2024-12-04 08:32:47 --> Helper loaded: form_helper
INFO - 2024-12-04 08:32:47 --> Database Driver Class Initialized
DEBUG - 2024-12-04 08:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:32:47 --> Form Validation Class Initialized
INFO - 2024-12-04 08:32:47 --> Model "Culinary_model" initialized
INFO - 2024-12-04 08:32:47 --> Controller Class Initialized
INFO - 2024-12-04 08:32:47 --> Model "Category_model" initialized
INFO - 2024-12-04 08:32:47 --> Model "User_model" initialized
INFO - 2024-12-04 08:32:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 08:32:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 08:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:32:47 --> Model "Contact_model" initialized
INFO - 2024-12-04 08:32:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-04 08:32:47 --> Final output sent to browser
DEBUG - 2024-12-04 08:32:47 --> Total execution time: 0.0607
INFO - 2024-12-04 14:15:12 --> Config Class Initialized
INFO - 2024-12-04 14:15:12 --> Hooks Class Initialized
DEBUG - 2024-12-04 14:15:12 --> UTF-8 Support Enabled
INFO - 2024-12-04 14:15:12 --> Utf8 Class Initialized
INFO - 2024-12-04 14:15:12 --> URI Class Initialized
INFO - 2024-12-04 14:15:12 --> Router Class Initialized
INFO - 2024-12-04 14:15:12 --> Output Class Initialized
INFO - 2024-12-04 14:15:12 --> Security Class Initialized
DEBUG - 2024-12-04 14:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 14:15:12 --> CSRF cookie sent
INFO - 2024-12-04 14:15:12 --> Input Class Initialized
INFO - 2024-12-04 14:15:12 --> Language Class Initialized
INFO - 2024-12-04 14:15:12 --> Loader Class Initialized
INFO - 2024-12-04 14:15:12 --> Helper loaded: url_helper
INFO - 2024-12-04 14:15:12 --> Helper loaded: form_helper
INFO - 2024-12-04 14:15:12 --> Database Driver Class Initialized
DEBUG - 2024-12-04 14:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 14:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 14:15:13 --> Form Validation Class Initialized
INFO - 2024-12-04 14:15:13 --> Model "Culinary_model" initialized
INFO - 2024-12-04 14:15:13 --> Controller Class Initialized
INFO - 2024-12-04 14:15:13 --> Model "User_model" initialized
INFO - 2024-12-04 14:15:13 --> Model "Category_model" initialized
INFO - 2024-12-04 14:15:13 --> Model "Review_model" initialized
INFO - 2024-12-04 14:15:13 --> Model "News_model" initialized
INFO - 2024-12-04 14:15:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 14:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 14:15:13 --> Query result: stdClass Object
(
    [view_count] => 32
)

INFO - 2024-12-04 14:15:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 14:15:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 14:15:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 14:15:13 --> Final output sent to browser
DEBUG - 2024-12-04 14:15:13 --> Total execution time: 0.8040
INFO - 2024-12-04 14:58:54 --> Config Class Initialized
INFO - 2024-12-04 14:58:54 --> Hooks Class Initialized
DEBUG - 2024-12-04 14:58:55 --> UTF-8 Support Enabled
INFO - 2024-12-04 14:58:55 --> Utf8 Class Initialized
INFO - 2024-12-04 14:58:55 --> URI Class Initialized
INFO - 2024-12-04 14:58:55 --> Router Class Initialized
INFO - 2024-12-04 14:58:55 --> Output Class Initialized
INFO - 2024-12-04 14:58:55 --> Security Class Initialized
DEBUG - 2024-12-04 14:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 14:58:55 --> CSRF cookie sent
INFO - 2024-12-04 14:58:55 --> Input Class Initialized
INFO - 2024-12-04 14:58:55 --> Language Class Initialized
INFO - 2024-12-04 14:58:55 --> Loader Class Initialized
INFO - 2024-12-04 14:58:55 --> Helper loaded: url_helper
INFO - 2024-12-04 14:58:55 --> Helper loaded: form_helper
INFO - 2024-12-04 14:58:55 --> Database Driver Class Initialized
DEBUG - 2024-12-04 14:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 14:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 14:58:55 --> Form Validation Class Initialized
INFO - 2024-12-04 14:58:55 --> Model "Culinary_model" initialized
INFO - 2024-12-04 14:58:55 --> Controller Class Initialized
INFO - 2024-12-04 14:58:55 --> Model "User_model" initialized
INFO - 2024-12-04 14:58:55 --> Model "Category_model" initialized
INFO - 2024-12-04 14:58:55 --> Model "Review_model" initialized
INFO - 2024-12-04 14:58:55 --> Model "News_model" initialized
INFO - 2024-12-04 14:58:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 14:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 14:58:55 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 14:58:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 14:58:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 14:58:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 14:58:55 --> Final output sent to browser
DEBUG - 2024-12-04 14:58:55 --> Total execution time: 0.9680
INFO - 2024-12-04 17:14:15 --> Config Class Initialized
INFO - 2024-12-04 17:14:15 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:14:15 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:14:15 --> Utf8 Class Initialized
INFO - 2024-12-04 17:14:16 --> URI Class Initialized
INFO - 2024-12-04 17:14:16 --> Router Class Initialized
INFO - 2024-12-04 17:14:16 --> Output Class Initialized
INFO - 2024-12-04 17:14:16 --> Security Class Initialized
DEBUG - 2024-12-04 17:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:14:16 --> CSRF cookie sent
INFO - 2024-12-04 17:14:16 --> Input Class Initialized
INFO - 2024-12-04 17:14:16 --> Language Class Initialized
INFO - 2024-12-04 17:14:16 --> Loader Class Initialized
INFO - 2024-12-04 17:14:16 --> Helper loaded: url_helper
INFO - 2024-12-04 17:14:16 --> Helper loaded: form_helper
INFO - 2024-12-04 17:14:16 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:14:16 --> Form Validation Class Initialized
INFO - 2024-12-04 17:14:16 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:14:16 --> Controller Class Initialized
INFO - 2024-12-04 17:14:16 --> Model "Category_model" initialized
INFO - 2024-12-04 17:14:16 --> Model "User_model" initialized
INFO - 2024-12-04 17:14:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:14:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:14:16 --> Config Class Initialized
INFO - 2024-12-04 17:14:16 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:14:16 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:14:16 --> Utf8 Class Initialized
INFO - 2024-12-04 17:14:16 --> URI Class Initialized
INFO - 2024-12-04 17:14:16 --> Router Class Initialized
INFO - 2024-12-04 17:14:16 --> Output Class Initialized
INFO - 2024-12-04 17:14:16 --> Security Class Initialized
DEBUG - 2024-12-04 17:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:14:16 --> CSRF cookie sent
INFO - 2024-12-04 17:14:16 --> Input Class Initialized
INFO - 2024-12-04 17:14:16 --> Language Class Initialized
INFO - 2024-12-04 17:14:16 --> Loader Class Initialized
INFO - 2024-12-04 17:14:16 --> Helper loaded: url_helper
INFO - 2024-12-04 17:14:16 --> Helper loaded: form_helper
INFO - 2024-12-04 17:14:16 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:14:16 --> Form Validation Class Initialized
INFO - 2024-12-04 17:14:16 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:14:16 --> Controller Class Initialized
INFO - 2024-12-04 17:14:16 --> Model "Category_model" initialized
INFO - 2024-12-04 17:14:16 --> Model "User_model" initialized
INFO - 2024-12-04 17:14:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:14:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:14:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:14:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:14:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-04 17:14:16 --> Final output sent to browser
DEBUG - 2024-12-04 17:14:16 --> Total execution time: 0.0977
INFO - 2024-12-04 17:14:19 --> Config Class Initialized
INFO - 2024-12-04 17:14:19 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:14:19 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:14:19 --> Utf8 Class Initialized
INFO - 2024-12-04 17:14:19 --> URI Class Initialized
INFO - 2024-12-04 17:14:19 --> Router Class Initialized
INFO - 2024-12-04 17:14:19 --> Output Class Initialized
INFO - 2024-12-04 17:14:19 --> Security Class Initialized
DEBUG - 2024-12-04 17:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:14:19 --> CSRF cookie sent
INFO - 2024-12-04 17:14:19 --> CSRF token verified
INFO - 2024-12-04 17:14:19 --> Input Class Initialized
INFO - 2024-12-04 17:14:19 --> Language Class Initialized
INFO - 2024-12-04 17:14:19 --> Loader Class Initialized
INFO - 2024-12-04 17:14:19 --> Helper loaded: url_helper
INFO - 2024-12-04 17:14:19 --> Helper loaded: form_helper
INFO - 2024-12-04 17:14:19 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:14:19 --> Form Validation Class Initialized
INFO - 2024-12-04 17:14:19 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:14:19 --> Controller Class Initialized
INFO - 2024-12-04 17:14:19 --> Model "User_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "Category_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "Review_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "News_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:14:19 --> Config Class Initialized
INFO - 2024-12-04 17:14:19 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:14:19 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:14:19 --> Utf8 Class Initialized
INFO - 2024-12-04 17:14:19 --> URI Class Initialized
INFO - 2024-12-04 17:14:19 --> Router Class Initialized
INFO - 2024-12-04 17:14:19 --> Output Class Initialized
INFO - 2024-12-04 17:14:19 --> Security Class Initialized
DEBUG - 2024-12-04 17:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:14:19 --> CSRF cookie sent
INFO - 2024-12-04 17:14:19 --> Input Class Initialized
INFO - 2024-12-04 17:14:19 --> Language Class Initialized
INFO - 2024-12-04 17:14:19 --> Loader Class Initialized
INFO - 2024-12-04 17:14:19 --> Helper loaded: url_helper
INFO - 2024-12-04 17:14:19 --> Helper loaded: form_helper
INFO - 2024-12-04 17:14:19 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:14:19 --> Form Validation Class Initialized
INFO - 2024-12-04 17:14:19 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:14:19 --> Controller Class Initialized
INFO - 2024-12-04 17:14:19 --> Model "Category_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "User_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:14:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:14:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:14:19 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 17:14:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:14:19 --> Final output sent to browser
DEBUG - 2024-12-04 17:14:19 --> Total execution time: 0.1240
INFO - 2024-12-04 17:17:15 --> Config Class Initialized
INFO - 2024-12-04 17:17:15 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:17:15 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:17:15 --> Utf8 Class Initialized
INFO - 2024-12-04 17:17:15 --> URI Class Initialized
INFO - 2024-12-04 17:17:15 --> Router Class Initialized
INFO - 2024-12-04 17:17:15 --> Output Class Initialized
INFO - 2024-12-04 17:17:16 --> Security Class Initialized
DEBUG - 2024-12-04 17:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:17:16 --> CSRF cookie sent
INFO - 2024-12-04 17:17:16 --> Input Class Initialized
INFO - 2024-12-04 17:17:16 --> Language Class Initialized
INFO - 2024-12-04 17:17:16 --> Loader Class Initialized
INFO - 2024-12-04 17:17:16 --> Helper loaded: url_helper
INFO - 2024-12-04 17:17:16 --> Helper loaded: form_helper
INFO - 2024-12-04 17:17:17 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:17:17 --> Config Class Initialized
INFO - 2024-12-04 17:17:17 --> Hooks Class Initialized
INFO - 2024-12-04 17:17:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-12-04 17:17:17 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:17:17 --> Utf8 Class Initialized
INFO - 2024-12-04 17:17:17 --> URI Class Initialized
INFO - 2024-12-04 17:17:17 --> Form Validation Class Initialized
INFO - 2024-12-04 17:17:17 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:17:17 --> Controller Class Initialized
INFO - 2024-12-04 17:17:17 --> Router Class Initialized
INFO - 2024-12-04 17:17:17 --> Model "Category_model" initialized
INFO - 2024-12-04 17:17:17 --> Model "User_model" initialized
INFO - 2024-12-04 17:17:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:17:17 --> Output Class Initialized
INFO - 2024-12-04 17:17:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:17:17 --> Security Class Initialized
DEBUG - 2024-12-04 17:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:17:17 --> CSRF cookie sent
INFO - 2024-12-04 17:17:17 --> Input Class Initialized
INFO - 2024-12-04 17:17:18 --> Language Class Initialized
INFO - 2024-12-04 17:17:18 --> Loader Class Initialized
INFO - 2024-12-04 17:17:18 --> Helper loaded: url_helper
INFO - 2024-12-04 17:17:18 --> Helper loaded: form_helper
INFO - 2024-12-04 17:17:18 --> Database Driver Class Initialized
INFO - 2024-12-04 17:17:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
DEBUG - 2024-12-04 17:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:17:18 --> Final output sent to browser
DEBUG - 2024-12-04 17:17:18 --> Total execution time: 2.8799
INFO - 2024-12-04 17:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:17:18 --> Form Validation Class Initialized
INFO - 2024-12-04 17:17:18 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:17:18 --> Controller Class Initialized
INFO - 2024-12-04 17:17:18 --> Model "Category_model" initialized
INFO - 2024-12-04 17:17:18 --> Model "User_model" initialized
INFO - 2024-12-04 17:17:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:17:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:17:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:17:18 --> Final output sent to browser
DEBUG - 2024-12-04 17:17:18 --> Total execution time: 1.3003
INFO - 2024-12-04 17:18:00 --> Config Class Initialized
INFO - 2024-12-04 17:18:00 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:01 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:01 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:01 --> URI Class Initialized
INFO - 2024-12-04 17:18:01 --> Router Class Initialized
INFO - 2024-12-04 17:18:01 --> Output Class Initialized
INFO - 2024-12-04 17:18:01 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:01 --> CSRF cookie sent
INFO - 2024-12-04 17:18:01 --> Input Class Initialized
INFO - 2024-12-04 17:18:01 --> Language Class Initialized
INFO - 2024-12-04 17:18:01 --> Loader Class Initialized
INFO - 2024-12-04 17:18:01 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:01 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:01 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:01 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:01 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:01 --> Controller Class Initialized
INFO - 2024-12-04 17:18:01 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:01 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kategori.php
INFO - 2024-12-04 17:18:01 --> Final output sent to browser
DEBUG - 2024-12-04 17:18:01 --> Total execution time: 0.4961
INFO - 2024-12-04 17:18:32 --> Config Class Initialized
INFO - 2024-12-04 17:18:32 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:32 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:32 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:32 --> URI Class Initialized
INFO - 2024-12-04 17:18:32 --> Router Class Initialized
INFO - 2024-12-04 17:18:32 --> Output Class Initialized
INFO - 2024-12-04 17:18:32 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:32 --> CSRF cookie sent
INFO - 2024-12-04 17:18:32 --> CSRF token verified
INFO - 2024-12-04 17:18:32 --> Input Class Initialized
INFO - 2024-12-04 17:18:32 --> Language Class Initialized
INFO - 2024-12-04 17:18:32 --> Loader Class Initialized
INFO - 2024-12-04 17:18:32 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:32 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:32 --> Database Driver Class Initialized
INFO - 2024-12-04 17:18:32 --> Config Class Initialized
INFO - 2024-12-04 17:18:32 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:32 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:32 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:32 --> URI Class Initialized
INFO - 2024-12-04 17:18:32 --> Router Class Initialized
INFO - 2024-12-04 17:18:32 --> Output Class Initialized
INFO - 2024-12-04 17:18:32 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:32 --> CSRF cookie sent
INFO - 2024-12-04 17:18:32 --> CSRF token verified
INFO - 2024-12-04 17:18:32 --> Input Class Initialized
INFO - 2024-12-04 17:18:32 --> Language Class Initialized
INFO - 2024-12-04 17:18:32 --> Loader Class Initialized
INFO - 2024-12-04 17:18:32 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:32 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:32 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-12-04 17:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:32 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:32 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:32 --> Controller Class Initialized
INFO - 2024-12-04 17:18:32 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:32 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:33 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:33 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:33 --> Controller Class Initialized
INFO - 2024-12-04 17:18:33 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:33 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:33 --> Config Class Initialized
INFO - 2024-12-04 17:18:33 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:33 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:33 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:33 --> URI Class Initialized
INFO - 2024-12-04 17:18:33 --> Router Class Initialized
INFO - 2024-12-04 17:18:33 --> Output Class Initialized
INFO - 2024-12-04 17:18:33 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:33 --> CSRF cookie sent
INFO - 2024-12-04 17:18:33 --> Input Class Initialized
INFO - 2024-12-04 17:18:33 --> Language Class Initialized
INFO - 2024-12-04 17:18:33 --> Loader Class Initialized
INFO - 2024-12-04 17:18:33 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:33 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:33 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:33 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:33 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:33 --> Controller Class Initialized
INFO - 2024-12-04 17:18:33 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:33 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:18:33 --> Final output sent to browser
DEBUG - 2024-12-04 17:18:33 --> Total execution time: 0.1383
INFO - 2024-12-04 17:18:37 --> Config Class Initialized
INFO - 2024-12-04 17:18:37 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:37 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:37 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:37 --> URI Class Initialized
INFO - 2024-12-04 17:18:37 --> Router Class Initialized
INFO - 2024-12-04 17:18:37 --> Output Class Initialized
INFO - 2024-12-04 17:18:37 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:37 --> CSRF cookie sent
INFO - 2024-12-04 17:18:37 --> Input Class Initialized
INFO - 2024-12-04 17:18:37 --> Language Class Initialized
INFO - 2024-12-04 17:18:37 --> Loader Class Initialized
INFO - 2024-12-04 17:18:37 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:37 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:37 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:37 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:37 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:37 --> Controller Class Initialized
INFO - 2024-12-04 17:18:37 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:37 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:37 --> Config Class Initialized
INFO - 2024-12-04 17:18:37 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:37 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:37 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:37 --> URI Class Initialized
INFO - 2024-12-04 17:18:37 --> Router Class Initialized
INFO - 2024-12-04 17:18:37 --> Output Class Initialized
INFO - 2024-12-04 17:18:37 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:37 --> CSRF cookie sent
INFO - 2024-12-04 17:18:37 --> Input Class Initialized
INFO - 2024-12-04 17:18:37 --> Language Class Initialized
INFO - 2024-12-04 17:18:37 --> Loader Class Initialized
INFO - 2024-12-04 17:18:37 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:37 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:37 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:37 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:37 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:37 --> Controller Class Initialized
INFO - 2024-12-04 17:18:37 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:37 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:18:37 --> Final output sent to browser
DEBUG - 2024-12-04 17:18:37 --> Total execution time: 0.0750
INFO - 2024-12-04 17:18:39 --> Config Class Initialized
INFO - 2024-12-04 17:18:39 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:39 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:39 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:39 --> URI Class Initialized
INFO - 2024-12-04 17:18:39 --> Router Class Initialized
INFO - 2024-12-04 17:18:39 --> Output Class Initialized
INFO - 2024-12-04 17:18:39 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:39 --> CSRF cookie sent
INFO - 2024-12-04 17:18:39 --> Input Class Initialized
INFO - 2024-12-04 17:18:39 --> Language Class Initialized
INFO - 2024-12-04 17:18:39 --> Loader Class Initialized
INFO - 2024-12-04 17:18:39 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:39 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:39 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:39 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:39 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:39 --> Controller Class Initialized
INFO - 2024-12-04 17:18:39 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:39 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:39 --> Config Class Initialized
INFO - 2024-12-04 17:18:39 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:39 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:39 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:39 --> URI Class Initialized
INFO - 2024-12-04 17:18:39 --> Router Class Initialized
INFO - 2024-12-04 17:18:39 --> Output Class Initialized
INFO - 2024-12-04 17:18:39 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:39 --> CSRF cookie sent
INFO - 2024-12-04 17:18:39 --> Input Class Initialized
INFO - 2024-12-04 17:18:39 --> Language Class Initialized
INFO - 2024-12-04 17:18:39 --> Loader Class Initialized
INFO - 2024-12-04 17:18:39 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:39 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:39 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:39 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:39 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:39 --> Controller Class Initialized
INFO - 2024-12-04 17:18:39 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:39 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:18:39 --> Final output sent to browser
DEBUG - 2024-12-04 17:18:39 --> Total execution time: 0.0665
INFO - 2024-12-04 17:18:42 --> Config Class Initialized
INFO - 2024-12-04 17:18:42 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:18:42 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:18:42 --> Utf8 Class Initialized
INFO - 2024-12-04 17:18:42 --> URI Class Initialized
INFO - 2024-12-04 17:18:42 --> Router Class Initialized
INFO - 2024-12-04 17:18:42 --> Output Class Initialized
INFO - 2024-12-04 17:18:42 --> Security Class Initialized
DEBUG - 2024-12-04 17:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:18:42 --> CSRF cookie sent
INFO - 2024-12-04 17:18:42 --> Input Class Initialized
INFO - 2024-12-04 17:18:42 --> Language Class Initialized
INFO - 2024-12-04 17:18:42 --> Loader Class Initialized
INFO - 2024-12-04 17:18:42 --> Helper loaded: url_helper
INFO - 2024-12-04 17:18:42 --> Helper loaded: form_helper
INFO - 2024-12-04 17:18:42 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:18:42 --> Form Validation Class Initialized
INFO - 2024-12-04 17:18:42 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:18:42 --> Controller Class Initialized
INFO - 2024-12-04 17:18:42 --> Model "Category_model" initialized
INFO - 2024-12-04 17:18:42 --> Model "User_model" initialized
INFO - 2024-12-04 17:18:42 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:18:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:18:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-04 17:18:42 --> Final output sent to browser
DEBUG - 2024-12-04 17:18:42 --> Total execution time: 0.0772
INFO - 2024-12-04 17:19:32 --> Config Class Initialized
INFO - 2024-12-04 17:19:32 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:32 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:32 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:32 --> URI Class Initialized
INFO - 2024-12-04 17:19:32 --> Router Class Initialized
INFO - 2024-12-04 17:19:32 --> Output Class Initialized
INFO - 2024-12-04 17:19:32 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:32 --> CSRF cookie sent
INFO - 2024-12-04 17:19:32 --> CSRF token verified
INFO - 2024-12-04 17:19:32 --> Input Class Initialized
INFO - 2024-12-04 17:19:32 --> Language Class Initialized
INFO - 2024-12-04 17:19:32 --> Loader Class Initialized
INFO - 2024-12-04 17:19:32 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:32 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:32 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:33 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:33 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:33 --> Controller Class Initialized
INFO - 2024-12-04 17:19:33 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:33 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:33 --> Config Class Initialized
INFO - 2024-12-04 17:19:33 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:33 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:33 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:33 --> URI Class Initialized
INFO - 2024-12-04 17:19:33 --> Router Class Initialized
INFO - 2024-12-04 17:19:33 --> Output Class Initialized
INFO - 2024-12-04 17:19:33 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:33 --> CSRF cookie sent
INFO - 2024-12-04 17:19:33 --> Input Class Initialized
INFO - 2024-12-04 17:19:33 --> Language Class Initialized
INFO - 2024-12-04 17:19:33 --> Loader Class Initialized
INFO - 2024-12-04 17:19:33 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:33 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:33 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:33 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:33 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:33 --> Controller Class Initialized
INFO - 2024-12-04 17:19:33 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:33 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:19:33 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:33 --> Total execution time: 0.1329
INFO - 2024-12-04 17:19:39 --> Config Class Initialized
INFO - 2024-12-04 17:19:39 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:39 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:39 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:39 --> URI Class Initialized
INFO - 2024-12-04 17:19:39 --> Router Class Initialized
INFO - 2024-12-04 17:19:39 --> Output Class Initialized
INFO - 2024-12-04 17:19:39 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:39 --> CSRF cookie sent
INFO - 2024-12-04 17:19:39 --> Input Class Initialized
INFO - 2024-12-04 17:19:39 --> Language Class Initialized
INFO - 2024-12-04 17:19:39 --> Loader Class Initialized
INFO - 2024-12-04 17:19:39 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:39 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:39 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:39 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:39 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:39 --> Controller Class Initialized
INFO - 2024-12-04 17:19:39 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:39 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:39 --> Config Class Initialized
INFO - 2024-12-04 17:19:39 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:39 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:39 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:39 --> URI Class Initialized
INFO - 2024-12-04 17:19:39 --> Router Class Initialized
INFO - 2024-12-04 17:19:39 --> Output Class Initialized
INFO - 2024-12-04 17:19:39 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:39 --> CSRF cookie sent
INFO - 2024-12-04 17:19:39 --> Input Class Initialized
INFO - 2024-12-04 17:19:39 --> Language Class Initialized
INFO - 2024-12-04 17:19:39 --> Loader Class Initialized
INFO - 2024-12-04 17:19:39 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:39 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:39 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:39 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:39 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:39 --> Controller Class Initialized
INFO - 2024-12-04 17:19:39 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:39 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:19:39 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:39 --> Total execution time: 0.0611
INFO - 2024-12-04 17:19:41 --> Config Class Initialized
INFO - 2024-12-04 17:19:41 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:41 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:41 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:41 --> URI Class Initialized
INFO - 2024-12-04 17:19:41 --> Router Class Initialized
INFO - 2024-12-04 17:19:41 --> Output Class Initialized
INFO - 2024-12-04 17:19:41 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:41 --> CSRF cookie sent
INFO - 2024-12-04 17:19:41 --> Input Class Initialized
INFO - 2024-12-04 17:19:41 --> Language Class Initialized
INFO - 2024-12-04 17:19:41 --> Loader Class Initialized
INFO - 2024-12-04 17:19:41 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:41 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:41 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:41 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:41 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:41 --> Controller Class Initialized
INFO - 2024-12-04 17:19:41 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:41 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:41 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kategori.php
INFO - 2024-12-04 17:19:41 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:41 --> Total execution time: 0.0684
INFO - 2024-12-04 17:19:46 --> Config Class Initialized
INFO - 2024-12-04 17:19:46 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:46 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:46 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:46 --> URI Class Initialized
INFO - 2024-12-04 17:19:46 --> Router Class Initialized
INFO - 2024-12-04 17:19:46 --> Output Class Initialized
INFO - 2024-12-04 17:19:46 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:46 --> CSRF cookie sent
INFO - 2024-12-04 17:19:46 --> CSRF token verified
INFO - 2024-12-04 17:19:46 --> Input Class Initialized
INFO - 2024-12-04 17:19:46 --> Language Class Initialized
INFO - 2024-12-04 17:19:46 --> Loader Class Initialized
INFO - 2024-12-04 17:19:46 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:46 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:46 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:46 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:46 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:46 --> Controller Class Initialized
INFO - 2024-12-04 17:19:46 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:46 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:46 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:46 --> Config Class Initialized
INFO - 2024-12-04 17:19:46 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:46 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:46 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:46 --> URI Class Initialized
INFO - 2024-12-04 17:19:46 --> Router Class Initialized
INFO - 2024-12-04 17:19:46 --> Output Class Initialized
INFO - 2024-12-04 17:19:46 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:46 --> CSRF cookie sent
INFO - 2024-12-04 17:19:46 --> Input Class Initialized
INFO - 2024-12-04 17:19:46 --> Language Class Initialized
INFO - 2024-12-04 17:19:46 --> Loader Class Initialized
INFO - 2024-12-04 17:19:46 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:46 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:46 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:46 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:46 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:46 --> Controller Class Initialized
INFO - 2024-12-04 17:19:46 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:46 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:46 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:19:47 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:47 --> Total execution time: 0.1027
INFO - 2024-12-04 17:19:51 --> Config Class Initialized
INFO - 2024-12-04 17:19:51 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:51 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:51 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:51 --> URI Class Initialized
INFO - 2024-12-04 17:19:51 --> Router Class Initialized
INFO - 2024-12-04 17:19:51 --> Output Class Initialized
INFO - 2024-12-04 17:19:51 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:51 --> CSRF cookie sent
INFO - 2024-12-04 17:19:51 --> Input Class Initialized
INFO - 2024-12-04 17:19:51 --> Language Class Initialized
INFO - 2024-12-04 17:19:51 --> Loader Class Initialized
INFO - 2024-12-04 17:19:51 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:51 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:51 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:51 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:51 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:51 --> Controller Class Initialized
INFO - 2024-12-04 17:19:51 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:51 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:19:51 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:51 --> Total execution time: 0.1070
INFO - 2024-12-04 17:19:53 --> Config Class Initialized
INFO - 2024-12-04 17:19:53 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:53 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:53 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:53 --> URI Class Initialized
INFO - 2024-12-04 17:19:53 --> Router Class Initialized
INFO - 2024-12-04 17:19:53 --> Output Class Initialized
INFO - 2024-12-04 17:19:53 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:53 --> CSRF cookie sent
INFO - 2024-12-04 17:19:53 --> Input Class Initialized
INFO - 2024-12-04 17:19:53 --> Language Class Initialized
INFO - 2024-12-04 17:19:53 --> Loader Class Initialized
INFO - 2024-12-04 17:19:53 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:53 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:53 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:54 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:54 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:54 --> Controller Class Initialized
INFO - 2024-12-04 17:19:54 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:54 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:19:54 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:54 --> Total execution time: 0.9200
INFO - 2024-12-04 17:19:56 --> Config Class Initialized
INFO - 2024-12-04 17:19:56 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:56 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:56 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:56 --> URI Class Initialized
INFO - 2024-12-04 17:19:56 --> Router Class Initialized
INFO - 2024-12-04 17:19:56 --> Output Class Initialized
INFO - 2024-12-04 17:19:56 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:56 --> CSRF cookie sent
INFO - 2024-12-04 17:19:56 --> Input Class Initialized
INFO - 2024-12-04 17:19:56 --> Language Class Initialized
INFO - 2024-12-04 17:19:56 --> Loader Class Initialized
INFO - 2024-12-04 17:19:56 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:56 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:56 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:56 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:56 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:56 --> Controller Class Initialized
INFO - 2024-12-04 17:19:56 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:56 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:19:56 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 17:19:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:19:57 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:57 --> Total execution time: 0.1625
INFO - 2024-12-04 17:19:59 --> Config Class Initialized
INFO - 2024-12-04 17:19:59 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:19:59 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:19:59 --> Utf8 Class Initialized
INFO - 2024-12-04 17:19:59 --> URI Class Initialized
INFO - 2024-12-04 17:19:59 --> Router Class Initialized
INFO - 2024-12-04 17:19:59 --> Output Class Initialized
INFO - 2024-12-04 17:19:59 --> Security Class Initialized
DEBUG - 2024-12-04 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:19:59 --> CSRF cookie sent
INFO - 2024-12-04 17:19:59 --> Input Class Initialized
INFO - 2024-12-04 17:19:59 --> Language Class Initialized
INFO - 2024-12-04 17:19:59 --> Loader Class Initialized
INFO - 2024-12-04 17:19:59 --> Helper loaded: url_helper
INFO - 2024-12-04 17:19:59 --> Helper loaded: form_helper
INFO - 2024-12-04 17:19:59 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:19:59 --> Form Validation Class Initialized
INFO - 2024-12-04 17:19:59 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:19:59 --> Controller Class Initialized
INFO - 2024-12-04 17:19:59 --> Model "Category_model" initialized
INFO - 2024-12-04 17:19:59 --> Model "User_model" initialized
INFO - 2024-12-04 17:19:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:19:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:19:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:19:59 --> Final output sent to browser
DEBUG - 2024-12-04 17:19:59 --> Total execution time: 0.0651
INFO - 2024-12-04 17:20:02 --> Config Class Initialized
INFO - 2024-12-04 17:20:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:02 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:02 --> URI Class Initialized
INFO - 2024-12-04 17:20:02 --> Router Class Initialized
INFO - 2024-12-04 17:20:02 --> Output Class Initialized
INFO - 2024-12-04 17:20:02 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:02 --> CSRF cookie sent
INFO - 2024-12-04 17:20:02 --> Input Class Initialized
INFO - 2024-12-04 17:20:02 --> Language Class Initialized
INFO - 2024-12-04 17:20:02 --> Loader Class Initialized
INFO - 2024-12-04 17:20:02 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:02 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:02 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:02 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:02 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:02 --> Controller Class Initialized
INFO - 2024-12-04 17:20:02 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:02 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:20:02 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 17:20:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:20:02 --> Final output sent to browser
DEBUG - 2024-12-04 17:20:02 --> Total execution time: 0.0614
INFO - 2024-12-04 17:20:03 --> Config Class Initialized
INFO - 2024-12-04 17:20:03 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:03 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:03 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:03 --> URI Class Initialized
INFO - 2024-12-04 17:20:03 --> Router Class Initialized
INFO - 2024-12-04 17:20:03 --> Output Class Initialized
INFO - 2024-12-04 17:20:03 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:03 --> CSRF cookie sent
INFO - 2024-12-04 17:20:03 --> Input Class Initialized
INFO - 2024-12-04 17:20:03 --> Language Class Initialized
INFO - 2024-12-04 17:20:03 --> Loader Class Initialized
INFO - 2024-12-04 17:20:03 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:03 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:03 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:03 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:03 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:03 --> Controller Class Initialized
INFO - 2024-12-04 17:20:03 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:03 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:03 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:20:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:20:03 --> Final output sent to browser
DEBUG - 2024-12-04 17:20:03 --> Total execution time: 0.0753
INFO - 2024-12-04 17:20:05 --> Config Class Initialized
INFO - 2024-12-04 17:20:05 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:05 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:05 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:05 --> URI Class Initialized
INFO - 2024-12-04 17:20:05 --> Router Class Initialized
INFO - 2024-12-04 17:20:05 --> Output Class Initialized
INFO - 2024-12-04 17:20:05 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:05 --> CSRF cookie sent
INFO - 2024-12-04 17:20:05 --> Input Class Initialized
INFO - 2024-12-04 17:20:05 --> Language Class Initialized
INFO - 2024-12-04 17:20:05 --> Loader Class Initialized
INFO - 2024-12-04 17:20:05 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:05 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:05 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:05 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:05 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:05 --> Controller Class Initialized
INFO - 2024-12-04 17:20:05 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:05 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:05 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:20:05 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 17:20:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:20:05 --> Final output sent to browser
DEBUG - 2024-12-04 17:20:05 --> Total execution time: 0.0808
INFO - 2024-12-04 17:20:06 --> Config Class Initialized
INFO - 2024-12-04 17:20:06 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:06 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:06 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:06 --> URI Class Initialized
INFO - 2024-12-04 17:20:06 --> Router Class Initialized
INFO - 2024-12-04 17:20:06 --> Output Class Initialized
INFO - 2024-12-04 17:20:06 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:06 --> CSRF cookie sent
INFO - 2024-12-04 17:20:06 --> Input Class Initialized
INFO - 2024-12-04 17:20:06 --> Language Class Initialized
INFO - 2024-12-04 17:20:06 --> Loader Class Initialized
INFO - 2024-12-04 17:20:06 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:06 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:06 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:06 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:06 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:06 --> Controller Class Initialized
INFO - 2024-12-04 17:20:06 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:06 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:06 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:20:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:20:06 --> Final output sent to browser
DEBUG - 2024-12-04 17:20:06 --> Total execution time: 0.0594
INFO - 2024-12-04 17:20:26 --> Config Class Initialized
INFO - 2024-12-04 17:20:27 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:27 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:27 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:27 --> URI Class Initialized
INFO - 2024-12-04 17:20:27 --> Router Class Initialized
INFO - 2024-12-04 17:20:27 --> Output Class Initialized
INFO - 2024-12-04 17:20:27 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:27 --> CSRF cookie sent
INFO - 2024-12-04 17:20:27 --> Input Class Initialized
INFO - 2024-12-04 17:20:27 --> Language Class Initialized
INFO - 2024-12-04 17:20:27 --> Loader Class Initialized
INFO - 2024-12-04 17:20:27 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:27 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:27 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:28 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:28 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:28 --> Controller Class Initialized
INFO - 2024-12-04 17:20:28 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:28 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:20:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-04 17:20:28 --> Final output sent to browser
DEBUG - 2024-12-04 17:20:28 --> Total execution time: 1.6404
INFO - 2024-12-04 17:20:57 --> Config Class Initialized
INFO - 2024-12-04 17:20:57 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:57 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:57 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:57 --> URI Class Initialized
INFO - 2024-12-04 17:20:57 --> Router Class Initialized
INFO - 2024-12-04 17:20:57 --> Output Class Initialized
INFO - 2024-12-04 17:20:57 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:57 --> CSRF cookie sent
INFO - 2024-12-04 17:20:57 --> CSRF token verified
INFO - 2024-12-04 17:20:57 --> Input Class Initialized
INFO - 2024-12-04 17:20:57 --> Language Class Initialized
INFO - 2024-12-04 17:20:57 --> Loader Class Initialized
INFO - 2024-12-04 17:20:58 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:58 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:58 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:58 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:58 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:58 --> Controller Class Initialized
INFO - 2024-12-04 17:20:58 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:58 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:20:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-04 17:20:58 --> Config Class Initialized
INFO - 2024-12-04 17:20:58 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:20:58 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:20:58 --> Utf8 Class Initialized
INFO - 2024-12-04 17:20:58 --> URI Class Initialized
INFO - 2024-12-04 17:20:58 --> Router Class Initialized
INFO - 2024-12-04 17:20:58 --> Output Class Initialized
INFO - 2024-12-04 17:20:58 --> Security Class Initialized
DEBUG - 2024-12-04 17:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:20:58 --> CSRF cookie sent
INFO - 2024-12-04 17:20:58 --> Input Class Initialized
INFO - 2024-12-04 17:20:58 --> Language Class Initialized
INFO - 2024-12-04 17:20:58 --> Loader Class Initialized
INFO - 2024-12-04 17:20:58 --> Helper loaded: url_helper
INFO - 2024-12-04 17:20:58 --> Helper loaded: form_helper
INFO - 2024-12-04 17:20:58 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:20:58 --> Form Validation Class Initialized
INFO - 2024-12-04 17:20:58 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:20:58 --> Controller Class Initialized
INFO - 2024-12-04 17:20:58 --> Model "Category_model" initialized
INFO - 2024-12-04 17:20:58 --> Model "User_model" initialized
INFO - 2024-12-04 17:20:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:20:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:20:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:20:58 --> Final output sent to browser
DEBUG - 2024-12-04 17:20:58 --> Total execution time: 0.1602
INFO - 2024-12-04 17:21:02 --> Config Class Initialized
INFO - 2024-12-04 17:21:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:21:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:21:02 --> Utf8 Class Initialized
INFO - 2024-12-04 17:21:02 --> URI Class Initialized
INFO - 2024-12-04 17:21:02 --> Router Class Initialized
INFO - 2024-12-04 17:21:02 --> Output Class Initialized
INFO - 2024-12-04 17:21:02 --> Security Class Initialized
DEBUG - 2024-12-04 17:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:21:02 --> CSRF cookie sent
INFO - 2024-12-04 17:21:02 --> Input Class Initialized
INFO - 2024-12-04 17:21:02 --> Language Class Initialized
INFO - 2024-12-04 17:21:02 --> Loader Class Initialized
INFO - 2024-12-04 17:21:02 --> Helper loaded: url_helper
INFO - 2024-12-04 17:21:02 --> Helper loaded: form_helper
INFO - 2024-12-04 17:21:02 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:21:02 --> Form Validation Class Initialized
INFO - 2024-12-04 17:21:02 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:21:02 --> Controller Class Initialized
INFO - 2024-12-04 17:21:02 --> Model "Category_model" initialized
INFO - 2024-12-04 17:21:02 --> Model "User_model" initialized
INFO - 2024-12-04 17:21:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:21:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:21:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-04 17:21:02 --> Final output sent to browser
DEBUG - 2024-12-04 17:21:02 --> Total execution time: 0.1057
INFO - 2024-12-04 17:21:38 --> Config Class Initialized
INFO - 2024-12-04 17:21:38 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:21:38 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:21:38 --> Utf8 Class Initialized
INFO - 2024-12-04 17:21:38 --> URI Class Initialized
INFO - 2024-12-04 17:21:38 --> Router Class Initialized
INFO - 2024-12-04 17:21:38 --> Output Class Initialized
INFO - 2024-12-04 17:21:38 --> Security Class Initialized
DEBUG - 2024-12-04 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:21:38 --> CSRF cookie sent
INFO - 2024-12-04 17:21:38 --> Input Class Initialized
INFO - 2024-12-04 17:21:38 --> Language Class Initialized
INFO - 2024-12-04 17:21:38 --> Loader Class Initialized
INFO - 2024-12-04 17:21:38 --> Helper loaded: url_helper
INFO - 2024-12-04 17:21:38 --> Helper loaded: form_helper
INFO - 2024-12-04 17:21:38 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:21:38 --> Form Validation Class Initialized
INFO - 2024-12-04 17:21:38 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:21:38 --> Controller Class Initialized
INFO - 2024-12-04 17:21:38 --> Model "Category_model" initialized
INFO - 2024-12-04 17:21:38 --> Model "User_model" initialized
INFO - 2024-12-04 17:21:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:21:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:21:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:21:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 17:21:38 --> Final output sent to browser
DEBUG - 2024-12-04 17:21:38 --> Total execution time: 0.5544
INFO - 2024-12-04 17:23:12 --> Config Class Initialized
INFO - 2024-12-04 17:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:23:12 --> Utf8 Class Initialized
INFO - 2024-12-04 17:23:12 --> URI Class Initialized
INFO - 2024-12-04 17:23:12 --> Router Class Initialized
INFO - 2024-12-04 17:23:12 --> Output Class Initialized
INFO - 2024-12-04 17:23:12 --> Security Class Initialized
DEBUG - 2024-12-04 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:23:12 --> CSRF cookie sent
INFO - 2024-12-04 17:23:12 --> Input Class Initialized
INFO - 2024-12-04 17:23:12 --> Language Class Initialized
INFO - 2024-12-04 17:23:12 --> Loader Class Initialized
INFO - 2024-12-04 17:23:12 --> Helper loaded: url_helper
INFO - 2024-12-04 17:23:12 --> Helper loaded: form_helper
INFO - 2024-12-04 17:23:12 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:23:12 --> Form Validation Class Initialized
INFO - 2024-12-04 17:23:12 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:23:12 --> Controller Class Initialized
INFO - 2024-12-04 17:23:12 --> Model "Category_model" initialized
INFO - 2024-12-04 17:23:12 --> Model "User_model" initialized
INFO - 2024-12-04 17:23:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:23:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:23:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-04 17:23:12 --> Final output sent to browser
DEBUG - 2024-12-04 17:23:12 --> Total execution time: 0.5306
INFO - 2024-12-04 17:24:23 --> Config Class Initialized
INFO - 2024-12-04 17:24:23 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:24:23 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:24:23 --> Utf8 Class Initialized
INFO - 2024-12-04 17:24:23 --> URI Class Initialized
INFO - 2024-12-04 17:24:23 --> Router Class Initialized
INFO - 2024-12-04 17:24:23 --> Output Class Initialized
INFO - 2024-12-04 17:24:23 --> Security Class Initialized
DEBUG - 2024-12-04 17:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:24:23 --> CSRF cookie sent
INFO - 2024-12-04 17:24:23 --> CSRF token verified
INFO - 2024-12-04 17:24:23 --> Input Class Initialized
INFO - 2024-12-04 17:24:23 --> Language Class Initialized
INFO - 2024-12-04 17:24:23 --> Loader Class Initialized
INFO - 2024-12-04 17:24:23 --> Helper loaded: url_helper
INFO - 2024-12-04 17:24:23 --> Helper loaded: form_helper
INFO - 2024-12-04 17:24:23 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:24:24 --> Form Validation Class Initialized
INFO - 2024-12-04 17:24:24 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:24:24 --> Controller Class Initialized
INFO - 2024-12-04 17:24:24 --> Model "Category_model" initialized
INFO - 2024-12-04 17:24:24 --> Model "User_model" initialized
INFO - 2024-12-04 17:24:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:24:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:24:24 --> Config Class Initialized
INFO - 2024-12-04 17:24:24 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:24:24 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:24:24 --> Utf8 Class Initialized
INFO - 2024-12-04 17:24:24 --> URI Class Initialized
INFO - 2024-12-04 17:24:24 --> Router Class Initialized
INFO - 2024-12-04 17:24:24 --> Output Class Initialized
INFO - 2024-12-04 17:24:24 --> Security Class Initialized
DEBUG - 2024-12-04 17:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:24:24 --> CSRF cookie sent
INFO - 2024-12-04 17:24:24 --> Input Class Initialized
INFO - 2024-12-04 17:24:24 --> Language Class Initialized
INFO - 2024-12-04 17:24:24 --> Loader Class Initialized
INFO - 2024-12-04 17:24:24 --> Helper loaded: url_helper
INFO - 2024-12-04 17:24:24 --> Helper loaded: form_helper
INFO - 2024-12-04 17:24:24 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:24:24 --> Form Validation Class Initialized
INFO - 2024-12-04 17:24:24 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:24:24 --> Controller Class Initialized
INFO - 2024-12-04 17:24:24 --> Model "Category_model" initialized
INFO - 2024-12-04 17:24:24 --> Model "User_model" initialized
INFO - 2024-12-04 17:24:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:24:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:24:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 17:24:24 --> Final output sent to browser
DEBUG - 2024-12-04 17:24:24 --> Total execution time: 0.1292
INFO - 2024-12-04 17:24:27 --> Config Class Initialized
INFO - 2024-12-04 17:24:27 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:24:27 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:24:27 --> Utf8 Class Initialized
INFO - 2024-12-04 17:24:27 --> URI Class Initialized
INFO - 2024-12-04 17:24:27 --> Router Class Initialized
INFO - 2024-12-04 17:24:27 --> Output Class Initialized
INFO - 2024-12-04 17:24:27 --> Security Class Initialized
DEBUG - 2024-12-04 17:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:24:27 --> CSRF cookie sent
INFO - 2024-12-04 17:24:27 --> Input Class Initialized
INFO - 2024-12-04 17:24:27 --> Language Class Initialized
INFO - 2024-12-04 17:24:27 --> Loader Class Initialized
INFO - 2024-12-04 17:24:27 --> Helper loaded: url_helper
INFO - 2024-12-04 17:24:27 --> Helper loaded: form_helper
INFO - 2024-12-04 17:24:27 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:24:27 --> Form Validation Class Initialized
INFO - 2024-12-04 17:24:27 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:24:27 --> Controller Class Initialized
INFO - 2024-12-04 17:24:27 --> Model "Category_model" initialized
INFO - 2024-12-04 17:24:27 --> Model "User_model" initialized
INFO - 2024-12-04 17:24:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:24:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:24:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-04 17:24:27 --> Final output sent to browser
DEBUG - 2024-12-04 17:24:27 --> Total execution time: 0.1204
INFO - 2024-12-04 17:24:30 --> Config Class Initialized
INFO - 2024-12-04 17:24:30 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:24:30 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:24:30 --> Utf8 Class Initialized
INFO - 2024-12-04 17:24:30 --> URI Class Initialized
INFO - 2024-12-04 17:24:30 --> Router Class Initialized
INFO - 2024-12-04 17:24:30 --> Output Class Initialized
INFO - 2024-12-04 17:24:30 --> Security Class Initialized
DEBUG - 2024-12-04 17:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:24:30 --> CSRF cookie sent
INFO - 2024-12-04 17:24:30 --> Input Class Initialized
INFO - 2024-12-04 17:24:30 --> Language Class Initialized
INFO - 2024-12-04 17:24:30 --> Loader Class Initialized
INFO - 2024-12-04 17:24:30 --> Helper loaded: url_helper
INFO - 2024-12-04 17:24:30 --> Helper loaded: form_helper
INFO - 2024-12-04 17:24:30 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:24:30 --> Form Validation Class Initialized
INFO - 2024-12-04 17:24:30 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:24:30 --> Controller Class Initialized
INFO - 2024-12-04 17:24:30 --> Model "News_model" initialized
INFO - 2024-12-04 17:24:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 17:24:30 --> Final output sent to browser
DEBUG - 2024-12-04 17:24:30 --> Total execution time: 0.0627
INFO - 2024-12-04 17:24:58 --> Config Class Initialized
INFO - 2024-12-04 17:24:58 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:24:58 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:24:58 --> Utf8 Class Initialized
INFO - 2024-12-04 17:24:58 --> URI Class Initialized
INFO - 2024-12-04 17:24:58 --> Router Class Initialized
INFO - 2024-12-04 17:24:58 --> Output Class Initialized
INFO - 2024-12-04 17:24:58 --> Security Class Initialized
DEBUG - 2024-12-04 17:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:24:58 --> CSRF cookie sent
INFO - 2024-12-04 17:24:58 --> Input Class Initialized
INFO - 2024-12-04 17:24:58 --> Language Class Initialized
INFO - 2024-12-04 17:24:58 --> Loader Class Initialized
INFO - 2024-12-04 17:24:58 --> Helper loaded: url_helper
INFO - 2024-12-04 17:24:58 --> Helper loaded: form_helper
INFO - 2024-12-04 17:24:59 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:24:59 --> Form Validation Class Initialized
INFO - 2024-12-04 17:24:59 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:24:59 --> Controller Class Initialized
INFO - 2024-12-04 17:24:59 --> Model "News_model" initialized
INFO - 2024-12-04 17:24:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-04 17:24:59 --> Final output sent to browser
DEBUG - 2024-12-04 17:24:59 --> Total execution time: 0.8024
INFO - 2024-12-04 17:25:10 --> Config Class Initialized
INFO - 2024-12-04 17:25:10 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:10 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:10 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:10 --> URI Class Initialized
INFO - 2024-12-04 17:25:10 --> Router Class Initialized
INFO - 2024-12-04 17:25:10 --> Output Class Initialized
INFO - 2024-12-04 17:25:10 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:10 --> CSRF cookie sent
INFO - 2024-12-04 17:25:10 --> CSRF token verified
INFO - 2024-12-04 17:25:10 --> Input Class Initialized
INFO - 2024-12-04 17:25:10 --> Language Class Initialized
INFO - 2024-12-04 17:25:10 --> Loader Class Initialized
INFO - 2024-12-04 17:25:10 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:10 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:10 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:10 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:10 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:10 --> Controller Class Initialized
INFO - 2024-12-04 17:25:10 --> Model "News_model" initialized
INFO - 2024-12-04 17:25:10 --> Config Class Initialized
INFO - 2024-12-04 17:25:10 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:10 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:10 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:10 --> URI Class Initialized
INFO - 2024-12-04 17:25:10 --> Router Class Initialized
INFO - 2024-12-04 17:25:10 --> Output Class Initialized
INFO - 2024-12-04 17:25:10 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:10 --> CSRF cookie sent
INFO - 2024-12-04 17:25:10 --> Input Class Initialized
INFO - 2024-12-04 17:25:10 --> Language Class Initialized
INFO - 2024-12-04 17:25:10 --> Loader Class Initialized
INFO - 2024-12-04 17:25:10 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:10 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:10 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:10 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:10 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:10 --> Controller Class Initialized
INFO - 2024-12-04 17:25:10 --> Model "News_model" initialized
INFO - 2024-12-04 17:25:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 17:25:10 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:10 --> Total execution time: 0.1124
INFO - 2024-12-04 17:25:14 --> Config Class Initialized
INFO - 2024-12-04 17:25:14 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:14 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:14 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:14 --> URI Class Initialized
INFO - 2024-12-04 17:25:14 --> Router Class Initialized
INFO - 2024-12-04 17:25:14 --> Output Class Initialized
INFO - 2024-12-04 17:25:14 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:14 --> CSRF cookie sent
INFO - 2024-12-04 17:25:14 --> Input Class Initialized
INFO - 2024-12-04 17:25:14 --> Language Class Initialized
INFO - 2024-12-04 17:25:14 --> Loader Class Initialized
INFO - 2024-12-04 17:25:14 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:14 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:14 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:14 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:14 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:14 --> Controller Class Initialized
INFO - 2024-12-04 17:25:14 --> Model "Category_model" initialized
INFO - 2024-12-04 17:25:14 --> Model "User_model" initialized
INFO - 2024-12-04 17:25:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:25:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:25:15 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 17:25:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:25:15 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:15 --> Total execution time: 0.1233
INFO - 2024-12-04 17:25:18 --> Config Class Initialized
INFO - 2024-12-04 17:25:18 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:18 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:18 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:18 --> URI Class Initialized
INFO - 2024-12-04 17:25:18 --> Router Class Initialized
INFO - 2024-12-04 17:25:18 --> Output Class Initialized
INFO - 2024-12-04 17:25:18 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:18 --> CSRF cookie sent
INFO - 2024-12-04 17:25:18 --> Input Class Initialized
INFO - 2024-12-04 17:25:18 --> Language Class Initialized
INFO - 2024-12-04 17:25:18 --> Loader Class Initialized
INFO - 2024-12-04 17:25:18 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:18 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:18 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:18 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:18 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:18 --> Controller Class Initialized
INFO - 2024-12-04 17:25:18 --> Model "Category_model" initialized
INFO - 2024-12-04 17:25:18 --> Model "User_model" initialized
INFO - 2024-12-04 17:25:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:25:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:25:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:25:18 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-04 17:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:25:18 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:18 --> Total execution time: 0.1802
INFO - 2024-12-04 17:25:19 --> Config Class Initialized
INFO - 2024-12-04 17:25:19 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:19 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:19 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:19 --> URI Class Initialized
INFO - 2024-12-04 17:25:19 --> Router Class Initialized
INFO - 2024-12-04 17:25:19 --> Output Class Initialized
INFO - 2024-12-04 17:25:19 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:19 --> CSRF cookie sent
INFO - 2024-12-04 17:25:19 --> Input Class Initialized
INFO - 2024-12-04 17:25:19 --> Language Class Initialized
INFO - 2024-12-04 17:25:19 --> Loader Class Initialized
INFO - 2024-12-04 17:25:19 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:19 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:19 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:19 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:19 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:19 --> Controller Class Initialized
INFO - 2024-12-04 17:25:19 --> Model "Category_model" initialized
INFO - 2024-12-04 17:25:19 --> Model "User_model" initialized
INFO - 2024-12-04 17:25:19 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:25:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:25:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-04 17:25:19 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:19 --> Total execution time: 0.0960
INFO - 2024-12-04 17:25:20 --> Config Class Initialized
INFO - 2024-12-04 17:25:20 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:20 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:20 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:20 --> URI Class Initialized
INFO - 2024-12-04 17:25:20 --> Router Class Initialized
INFO - 2024-12-04 17:25:20 --> Output Class Initialized
INFO - 2024-12-04 17:25:20 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:20 --> CSRF cookie sent
INFO - 2024-12-04 17:25:20 --> Input Class Initialized
INFO - 2024-12-04 17:25:20 --> Language Class Initialized
INFO - 2024-12-04 17:25:20 --> Loader Class Initialized
INFO - 2024-12-04 17:25:20 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:20 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:20 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:20 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:20 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:20 --> Controller Class Initialized
INFO - 2024-12-04 17:25:20 --> Model "Category_model" initialized
INFO - 2024-12-04 17:25:20 --> Model "User_model" initialized
INFO - 2024-12-04 17:25:20 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:25:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:25:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:25:20 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:20 --> Total execution time: 0.0902
INFO - 2024-12-04 17:25:21 --> Config Class Initialized
INFO - 2024-12-04 17:25:21 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:21 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:21 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:21 --> URI Class Initialized
INFO - 2024-12-04 17:25:21 --> Router Class Initialized
INFO - 2024-12-04 17:25:21 --> Output Class Initialized
INFO - 2024-12-04 17:25:21 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:21 --> CSRF cookie sent
INFO - 2024-12-04 17:25:21 --> Input Class Initialized
INFO - 2024-12-04 17:25:21 --> Language Class Initialized
INFO - 2024-12-04 17:25:21 --> Loader Class Initialized
INFO - 2024-12-04 17:25:21 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:21 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:21 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:21 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:21 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:21 --> Controller Class Initialized
INFO - 2024-12-04 17:25:21 --> Model "Category_model" initialized
INFO - 2024-12-04 17:25:21 --> Model "User_model" initialized
INFO - 2024-12-04 17:25:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:25:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:25:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-04 17:25:21 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:21 --> Total execution time: 0.1020
INFO - 2024-12-04 17:25:23 --> Config Class Initialized
INFO - 2024-12-04 17:25:23 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:23 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:23 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:23 --> URI Class Initialized
INFO - 2024-12-04 17:25:23 --> Router Class Initialized
INFO - 2024-12-04 17:25:23 --> Output Class Initialized
INFO - 2024-12-04 17:25:23 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:23 --> CSRF cookie sent
INFO - 2024-12-04 17:25:23 --> Input Class Initialized
INFO - 2024-12-04 17:25:23 --> Language Class Initialized
INFO - 2024-12-04 17:25:23 --> Loader Class Initialized
INFO - 2024-12-04 17:25:23 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:23 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:23 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:23 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:23 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:23 --> Controller Class Initialized
INFO - 2024-12-04 17:25:23 --> Model "Category_model" initialized
INFO - 2024-12-04 17:25:23 --> Model "User_model" initialized
INFO - 2024-12-04 17:25:23 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:25:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:25:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-04 17:25:23 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:23 --> Total execution time: 0.0658
INFO - 2024-12-04 17:25:25 --> Config Class Initialized
INFO - 2024-12-04 17:25:25 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:25 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:25 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:25 --> URI Class Initialized
INFO - 2024-12-04 17:25:25 --> Router Class Initialized
INFO - 2024-12-04 17:25:25 --> Output Class Initialized
INFO - 2024-12-04 17:25:25 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:25 --> CSRF cookie sent
INFO - 2024-12-04 17:25:25 --> Input Class Initialized
INFO - 2024-12-04 17:25:25 --> Language Class Initialized
INFO - 2024-12-04 17:25:25 --> Loader Class Initialized
INFO - 2024-12-04 17:25:25 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:25 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:25 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:25 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:25 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:25 --> Controller Class Initialized
INFO - 2024-12-04 17:25:25 --> Model "News_model" initialized
INFO - 2024-12-04 17:25:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 17:25:25 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:25 --> Total execution time: 0.0565
INFO - 2024-12-04 17:25:27 --> Config Class Initialized
INFO - 2024-12-04 17:25:27 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:25:27 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:25:27 --> Utf8 Class Initialized
INFO - 2024-12-04 17:25:27 --> URI Class Initialized
INFO - 2024-12-04 17:25:27 --> Router Class Initialized
INFO - 2024-12-04 17:25:27 --> Output Class Initialized
INFO - 2024-12-04 17:25:27 --> Security Class Initialized
DEBUG - 2024-12-04 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:25:27 --> CSRF cookie sent
INFO - 2024-12-04 17:25:27 --> Input Class Initialized
INFO - 2024-12-04 17:25:27 --> Language Class Initialized
INFO - 2024-12-04 17:25:27 --> Loader Class Initialized
INFO - 2024-12-04 17:25:27 --> Helper loaded: url_helper
INFO - 2024-12-04 17:25:27 --> Helper loaded: form_helper
INFO - 2024-12-04 17:25:27 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:25:27 --> Form Validation Class Initialized
INFO - 2024-12-04 17:25:27 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:25:27 --> Controller Class Initialized
INFO - 2024-12-04 17:25:27 --> Model "News_model" initialized
INFO - 2024-12-04 17:25:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-04 17:25:27 --> Final output sent to browser
DEBUG - 2024-12-04 17:25:27 --> Total execution time: 0.0987
INFO - 2024-12-04 17:26:21 --> Config Class Initialized
INFO - 2024-12-04 17:26:21 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:26:21 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:26:21 --> Utf8 Class Initialized
INFO - 2024-12-04 17:26:21 --> URI Class Initialized
INFO - 2024-12-04 17:26:21 --> Router Class Initialized
INFO - 2024-12-04 17:26:21 --> Output Class Initialized
INFO - 2024-12-04 17:26:21 --> Security Class Initialized
DEBUG - 2024-12-04 17:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:26:21 --> CSRF cookie sent
INFO - 2024-12-04 17:26:21 --> Input Class Initialized
INFO - 2024-12-04 17:26:21 --> Language Class Initialized
INFO - 2024-12-04 17:26:21 --> Loader Class Initialized
INFO - 2024-12-04 17:26:21 --> Helper loaded: url_helper
INFO - 2024-12-04 17:26:21 --> Helper loaded: form_helper
INFO - 2024-12-04 17:26:21 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:26:21 --> Form Validation Class Initialized
INFO - 2024-12-04 17:26:21 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:26:21 --> Controller Class Initialized
INFO - 2024-12-04 17:26:21 --> Model "News_model" initialized
INFO - 2024-12-04 17:26:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 17:26:21 --> Final output sent to browser
DEBUG - 2024-12-04 17:26:21 --> Total execution time: 0.4355
INFO - 2024-12-04 17:26:29 --> Config Class Initialized
INFO - 2024-12-04 17:26:29 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:26:29 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:26:29 --> Utf8 Class Initialized
INFO - 2024-12-04 17:26:29 --> URI Class Initialized
INFO - 2024-12-04 17:26:29 --> Router Class Initialized
INFO - 2024-12-04 17:26:29 --> Output Class Initialized
INFO - 2024-12-04 17:26:29 --> Security Class Initialized
DEBUG - 2024-12-04 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:26:29 --> CSRF cookie sent
INFO - 2024-12-04 17:26:29 --> Input Class Initialized
INFO - 2024-12-04 17:26:29 --> Language Class Initialized
INFO - 2024-12-04 17:26:29 --> Loader Class Initialized
INFO - 2024-12-04 17:26:29 --> Helper loaded: url_helper
INFO - 2024-12-04 17:26:29 --> Helper loaded: form_helper
INFO - 2024-12-04 17:26:29 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:26:29 --> Form Validation Class Initialized
INFO - 2024-12-04 17:26:29 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:26:29 --> Controller Class Initialized
INFO - 2024-12-04 17:26:29 --> Model "Category_model" initialized
INFO - 2024-12-04 17:26:29 --> Model "User_model" initialized
INFO - 2024-12-04 17:26:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:26:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:26:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-04 17:26:29 --> Final output sent to browser
DEBUG - 2024-12-04 17:26:29 --> Total execution time: 0.0713
INFO - 2024-12-04 17:26:30 --> Config Class Initialized
INFO - 2024-12-04 17:26:30 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:26:30 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:26:30 --> Utf8 Class Initialized
INFO - 2024-12-04 17:26:30 --> URI Class Initialized
INFO - 2024-12-04 17:26:30 --> Router Class Initialized
INFO - 2024-12-04 17:26:30 --> Output Class Initialized
INFO - 2024-12-04 17:26:30 --> Security Class Initialized
DEBUG - 2024-12-04 17:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:26:30 --> CSRF cookie sent
INFO - 2024-12-04 17:26:30 --> Input Class Initialized
INFO - 2024-12-04 17:26:30 --> Language Class Initialized
INFO - 2024-12-04 17:26:30 --> Loader Class Initialized
INFO - 2024-12-04 17:26:30 --> Helper loaded: url_helper
INFO - 2024-12-04 17:26:30 --> Helper loaded: form_helper
INFO - 2024-12-04 17:26:30 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:26:30 --> Form Validation Class Initialized
INFO - 2024-12-04 17:26:30 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:26:30 --> Controller Class Initialized
INFO - 2024-12-04 17:26:30 --> Model "News_model" initialized
INFO - 2024-12-04 17:26:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-04 17:26:30 --> Final output sent to browser
DEBUG - 2024-12-04 17:26:30 --> Total execution time: 0.0687
INFO - 2024-12-04 17:26:32 --> Config Class Initialized
INFO - 2024-12-04 17:26:32 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:26:32 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:26:32 --> Utf8 Class Initialized
INFO - 2024-12-04 17:26:32 --> URI Class Initialized
INFO - 2024-12-04 17:26:32 --> Router Class Initialized
INFO - 2024-12-04 17:26:32 --> Output Class Initialized
INFO - 2024-12-04 17:26:32 --> Security Class Initialized
DEBUG - 2024-12-04 17:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:26:32 --> CSRF cookie sent
INFO - 2024-12-04 17:26:32 --> Input Class Initialized
INFO - 2024-12-04 17:26:32 --> Language Class Initialized
INFO - 2024-12-04 17:26:32 --> Loader Class Initialized
INFO - 2024-12-04 17:26:32 --> Helper loaded: url_helper
INFO - 2024-12-04 17:26:32 --> Helper loaded: form_helper
INFO - 2024-12-04 17:26:32 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:26:32 --> Form Validation Class Initialized
INFO - 2024-12-04 17:26:32 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:26:32 --> Controller Class Initialized
INFO - 2024-12-04 17:26:32 --> Model "Category_model" initialized
INFO - 2024-12-04 17:26:32 --> Model "User_model" initialized
INFO - 2024-12-04 17:26:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:26:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:26:32 --> Model "Contact_model" initialized
INFO - 2024-12-04 17:26:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-04 17:26:32 --> Final output sent to browser
DEBUG - 2024-12-04 17:26:32 --> Total execution time: 0.0928
INFO - 2024-12-04 17:33:44 --> Config Class Initialized
INFO - 2024-12-04 17:33:44 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:33:44 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:33:44 --> Utf8 Class Initialized
INFO - 2024-12-04 17:33:44 --> URI Class Initialized
INFO - 2024-12-04 17:33:44 --> Router Class Initialized
INFO - 2024-12-04 17:33:44 --> Output Class Initialized
INFO - 2024-12-04 17:33:44 --> Security Class Initialized
DEBUG - 2024-12-04 17:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:33:44 --> CSRF cookie sent
INFO - 2024-12-04 17:33:44 --> Input Class Initialized
INFO - 2024-12-04 17:33:44 --> Language Class Initialized
INFO - 2024-12-04 17:33:44 --> Loader Class Initialized
INFO - 2024-12-04 17:33:44 --> Helper loaded: url_helper
INFO - 2024-12-04 17:33:44 --> Helper loaded: form_helper
INFO - 2024-12-04 17:33:44 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:33:44 --> Form Validation Class Initialized
INFO - 2024-12-04 17:33:44 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:33:44 --> Controller Class Initialized
INFO - 2024-12-04 17:33:44 --> Model "Category_model" initialized
INFO - 2024-12-04 17:33:44 --> Model "User_model" initialized
INFO - 2024-12-04 17:33:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:33:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:33:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:33:44 --> Final output sent to browser
DEBUG - 2024-12-04 17:33:44 --> Total execution time: 0.8815
INFO - 2024-12-04 17:33:48 --> Config Class Initialized
INFO - 2024-12-04 17:33:48 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:33:48 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:33:48 --> Utf8 Class Initialized
INFO - 2024-12-04 17:33:48 --> URI Class Initialized
INFO - 2024-12-04 17:33:48 --> Router Class Initialized
INFO - 2024-12-04 17:33:48 --> Output Class Initialized
INFO - 2024-12-04 17:33:48 --> Security Class Initialized
DEBUG - 2024-12-04 17:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:33:48 --> CSRF cookie sent
INFO - 2024-12-04 17:33:48 --> Input Class Initialized
INFO - 2024-12-04 17:33:48 --> Language Class Initialized
INFO - 2024-12-04 17:33:48 --> Loader Class Initialized
INFO - 2024-12-04 17:33:48 --> Helper loaded: url_helper
INFO - 2024-12-04 17:33:48 --> Helper loaded: form_helper
INFO - 2024-12-04 17:33:48 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:33:48 --> Form Validation Class Initialized
INFO - 2024-12-04 17:33:48 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:33:48 --> Controller Class Initialized
INFO - 2024-12-04 17:33:48 --> Model "Category_model" initialized
INFO - 2024-12-04 17:33:48 --> Model "User_model" initialized
INFO - 2024-12-04 17:33:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:33:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:33:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-04 17:33:48 --> Final output sent to browser
DEBUG - 2024-12-04 17:33:48 --> Total execution time: 0.1766
INFO - 2024-12-04 17:35:27 --> Config Class Initialized
INFO - 2024-12-04 17:35:27 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:35:27 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:35:27 --> Utf8 Class Initialized
INFO - 2024-12-04 17:35:27 --> URI Class Initialized
INFO - 2024-12-04 17:35:27 --> Router Class Initialized
INFO - 2024-12-04 17:35:27 --> Output Class Initialized
INFO - 2024-12-04 17:35:27 --> Security Class Initialized
DEBUG - 2024-12-04 17:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:35:27 --> CSRF cookie sent
INFO - 2024-12-04 17:35:27 --> Input Class Initialized
INFO - 2024-12-04 17:35:27 --> Language Class Initialized
INFO - 2024-12-04 17:35:27 --> Loader Class Initialized
INFO - 2024-12-04 17:35:27 --> Helper loaded: url_helper
INFO - 2024-12-04 17:35:27 --> Helper loaded: form_helper
INFO - 2024-12-04 17:35:27 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:35:27 --> Form Validation Class Initialized
INFO - 2024-12-04 17:35:27 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:35:27 --> Controller Class Initialized
INFO - 2024-12-04 17:35:27 --> Model "Category_model" initialized
INFO - 2024-12-04 17:35:27 --> Model "User_model" initialized
INFO - 2024-12-04 17:35:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:35:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:35:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:35:27 --> Model "Contact_model" initialized
INFO - 2024-12-04 17:35:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-04 17:35:27 --> Final output sent to browser
DEBUG - 2024-12-04 17:35:27 --> Total execution time: 0.9255
INFO - 2024-12-04 17:35:30 --> Config Class Initialized
INFO - 2024-12-04 17:35:30 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:35:30 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:35:30 --> Utf8 Class Initialized
INFO - 2024-12-04 17:35:30 --> URI Class Initialized
INFO - 2024-12-04 17:35:30 --> Router Class Initialized
INFO - 2024-12-04 17:35:30 --> Output Class Initialized
INFO - 2024-12-04 17:35:30 --> Security Class Initialized
DEBUG - 2024-12-04 17:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:35:30 --> CSRF cookie sent
INFO - 2024-12-04 17:35:30 --> Input Class Initialized
INFO - 2024-12-04 17:35:30 --> Language Class Initialized
INFO - 2024-12-04 17:35:30 --> Loader Class Initialized
INFO - 2024-12-04 17:35:30 --> Helper loaded: url_helper
INFO - 2024-12-04 17:35:30 --> Helper loaded: form_helper
INFO - 2024-12-04 17:35:30 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:35:30 --> Form Validation Class Initialized
INFO - 2024-12-04 17:35:30 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:35:30 --> Controller Class Initialized
INFO - 2024-12-04 17:35:30 --> Model "Category_model" initialized
INFO - 2024-12-04 17:35:30 --> Model "User_model" initialized
INFO - 2024-12-04 17:35:30 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:35:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:35:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:35:30 --> Final output sent to browser
DEBUG - 2024-12-04 17:35:30 --> Total execution time: 0.1486
INFO - 2024-12-04 17:35:32 --> Config Class Initialized
INFO - 2024-12-04 17:35:32 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:35:32 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:35:32 --> Utf8 Class Initialized
INFO - 2024-12-04 17:35:32 --> URI Class Initialized
INFO - 2024-12-04 17:35:32 --> Router Class Initialized
INFO - 2024-12-04 17:35:32 --> Output Class Initialized
INFO - 2024-12-04 17:35:32 --> Security Class Initialized
DEBUG - 2024-12-04 17:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:35:32 --> CSRF cookie sent
INFO - 2024-12-04 17:35:32 --> Input Class Initialized
INFO - 2024-12-04 17:35:32 --> Language Class Initialized
INFO - 2024-12-04 17:35:32 --> Loader Class Initialized
INFO - 2024-12-04 17:35:32 --> Helper loaded: url_helper
INFO - 2024-12-04 17:35:32 --> Helper loaded: form_helper
INFO - 2024-12-04 17:35:32 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:35:32 --> Form Validation Class Initialized
INFO - 2024-12-04 17:35:32 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:35:32 --> Controller Class Initialized
INFO - 2024-12-04 17:35:32 --> Model "Category_model" initialized
INFO - 2024-12-04 17:35:32 --> Model "User_model" initialized
INFO - 2024-12-04 17:35:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:35:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:35:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-04 17:35:32 --> Final output sent to browser
DEBUG - 2024-12-04 17:35:32 --> Total execution time: 0.1455
INFO - 2024-12-04 17:35:51 --> Config Class Initialized
INFO - 2024-12-04 17:35:51 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:35:51 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:35:51 --> Utf8 Class Initialized
INFO - 2024-12-04 17:35:51 --> URI Class Initialized
INFO - 2024-12-04 17:35:51 --> Router Class Initialized
INFO - 2024-12-04 17:35:51 --> Output Class Initialized
INFO - 2024-12-04 17:35:51 --> Security Class Initialized
DEBUG - 2024-12-04 17:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:35:51 --> CSRF cookie sent
INFO - 2024-12-04 17:35:51 --> CSRF token verified
INFO - 2024-12-04 17:35:51 --> Input Class Initialized
INFO - 2024-12-04 17:35:51 --> Language Class Initialized
INFO - 2024-12-04 17:35:51 --> Loader Class Initialized
INFO - 2024-12-04 17:35:51 --> Helper loaded: url_helper
INFO - 2024-12-04 17:35:51 --> Helper loaded: form_helper
INFO - 2024-12-04 17:35:51 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:35:51 --> Form Validation Class Initialized
INFO - 2024-12-04 17:35:51 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:35:51 --> Controller Class Initialized
INFO - 2024-12-04 17:35:51 --> Model "Category_model" initialized
INFO - 2024-12-04 17:35:51 --> Model "User_model" initialized
INFO - 2024-12-04 17:35:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:35:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:35:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-04 17:35:51 --> Config Class Initialized
INFO - 2024-12-04 17:35:51 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:35:51 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:35:51 --> Utf8 Class Initialized
INFO - 2024-12-04 17:35:51 --> URI Class Initialized
INFO - 2024-12-04 17:35:51 --> Router Class Initialized
INFO - 2024-12-04 17:35:51 --> Output Class Initialized
INFO - 2024-12-04 17:35:51 --> Security Class Initialized
DEBUG - 2024-12-04 17:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:35:51 --> CSRF cookie sent
INFO - 2024-12-04 17:35:51 --> Input Class Initialized
INFO - 2024-12-04 17:35:51 --> Language Class Initialized
INFO - 2024-12-04 17:35:51 --> Loader Class Initialized
INFO - 2024-12-04 17:35:51 --> Helper loaded: url_helper
INFO - 2024-12-04 17:35:51 --> Helper loaded: form_helper
INFO - 2024-12-04 17:35:51 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:35:51 --> Form Validation Class Initialized
INFO - 2024-12-04 17:35:51 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:35:51 --> Controller Class Initialized
INFO - 2024-12-04 17:35:51 --> Model "Category_model" initialized
INFO - 2024-12-04 17:35:51 --> Model "User_model" initialized
INFO - 2024-12-04 17:35:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:35:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:35:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:35:51 --> Final output sent to browser
DEBUG - 2024-12-04 17:35:51 --> Total execution time: 0.0841
INFO - 2024-12-04 17:36:02 --> Config Class Initialized
INFO - 2024-12-04 17:36:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:02 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:02 --> URI Class Initialized
INFO - 2024-12-04 17:36:02 --> Router Class Initialized
INFO - 2024-12-04 17:36:02 --> Output Class Initialized
INFO - 2024-12-04 17:36:02 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:02 --> CSRF cookie sent
INFO - 2024-12-04 17:36:02 --> Input Class Initialized
INFO - 2024-12-04 17:36:02 --> Language Class Initialized
INFO - 2024-12-04 17:36:02 --> Loader Class Initialized
INFO - 2024-12-04 17:36:02 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:02 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:02 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:02 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:02 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:02 --> Controller Class Initialized
INFO - 2024-12-04 17:36:02 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:02 --> Config Class Initialized
INFO - 2024-12-04 17:36:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:02 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:02 --> URI Class Initialized
INFO - 2024-12-04 17:36:02 --> Router Class Initialized
INFO - 2024-12-04 17:36:02 --> Output Class Initialized
INFO - 2024-12-04 17:36:02 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:02 --> CSRF cookie sent
INFO - 2024-12-04 17:36:02 --> Input Class Initialized
INFO - 2024-12-04 17:36:02 --> Language Class Initialized
INFO - 2024-12-04 17:36:02 --> Loader Class Initialized
INFO - 2024-12-04 17:36:02 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:02 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:02 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:02 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:02 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:02 --> Controller Class Initialized
INFO - 2024-12-04 17:36:02 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:36:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:36:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-04 17:36:02 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:02 --> Total execution time: 0.0690
INFO - 2024-12-04 17:36:06 --> Config Class Initialized
INFO - 2024-12-04 17:36:06 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:06 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:06 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:06 --> URI Class Initialized
INFO - 2024-12-04 17:36:06 --> Router Class Initialized
INFO - 2024-12-04 17:36:06 --> Output Class Initialized
INFO - 2024-12-04 17:36:06 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:06 --> CSRF cookie sent
INFO - 2024-12-04 17:36:06 --> CSRF token verified
INFO - 2024-12-04 17:36:06 --> Input Class Initialized
INFO - 2024-12-04 17:36:06 --> Language Class Initialized
INFO - 2024-12-04 17:36:06 --> Loader Class Initialized
INFO - 2024-12-04 17:36:06 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:06 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:06 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:06 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:06 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:06 --> Controller Class Initialized
INFO - 2024-12-04 17:36:06 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:06 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:06 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:06 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:06 --> Config Class Initialized
INFO - 2024-12-04 17:36:06 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:06 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:06 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:06 --> URI Class Initialized
INFO - 2024-12-04 17:36:06 --> Router Class Initialized
INFO - 2024-12-04 17:36:07 --> Output Class Initialized
INFO - 2024-12-04 17:36:07 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:07 --> CSRF cookie sent
INFO - 2024-12-04 17:36:07 --> Input Class Initialized
INFO - 2024-12-04 17:36:07 --> Language Class Initialized
INFO - 2024-12-04 17:36:07 --> Loader Class Initialized
INFO - 2024-12-04 17:36:07 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:07 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:07 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:07 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:07 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:07 --> Controller Class Initialized
INFO - 2024-12-04 17:36:07 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:07 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:07 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:07 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:36:07 --> Query result: stdClass Object
(
    [view_count] => 34
)

INFO - 2024-12-04 17:36:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:36:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:36:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 17:36:07 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:07 --> Total execution time: 0.1146
INFO - 2024-12-04 17:36:08 --> Config Class Initialized
INFO - 2024-12-04 17:36:08 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:08 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:08 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:08 --> URI Class Initialized
INFO - 2024-12-04 17:36:08 --> Router Class Initialized
INFO - 2024-12-04 17:36:08 --> Output Class Initialized
INFO - 2024-12-04 17:36:08 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:08 --> CSRF cookie sent
INFO - 2024-12-04 17:36:08 --> Input Class Initialized
INFO - 2024-12-04 17:36:08 --> Language Class Initialized
ERROR - 2024-12-04 17:36:08 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-04 17:36:13 --> Config Class Initialized
INFO - 2024-12-04 17:36:13 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:13 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:13 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:13 --> URI Class Initialized
INFO - 2024-12-04 17:36:13 --> Router Class Initialized
INFO - 2024-12-04 17:36:13 --> Output Class Initialized
INFO - 2024-12-04 17:36:13 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:13 --> CSRF cookie sent
INFO - 2024-12-04 17:36:13 --> Input Class Initialized
INFO - 2024-12-04 17:36:13 --> Language Class Initialized
INFO - 2024-12-04 17:36:13 --> Loader Class Initialized
INFO - 2024-12-04 17:36:13 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:13 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:13 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:13 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:13 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:13 --> Controller Class Initialized
INFO - 2024-12-04 17:36:13 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:13 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:13 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:13 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:36:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:36:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-04 17:36:13 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:13 --> Total execution time: 0.5908
INFO - 2024-12-04 17:36:22 --> Config Class Initialized
INFO - 2024-12-04 17:36:22 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:22 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:22 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:22 --> URI Class Initialized
INFO - 2024-12-04 17:36:22 --> Router Class Initialized
INFO - 2024-12-04 17:36:22 --> Output Class Initialized
INFO - 2024-12-04 17:36:22 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:22 --> CSRF cookie sent
INFO - 2024-12-04 17:36:22 --> Input Class Initialized
INFO - 2024-12-04 17:36:22 --> Language Class Initialized
INFO - 2024-12-04 17:36:22 --> Loader Class Initialized
INFO - 2024-12-04 17:36:22 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:22 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:22 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:22 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:22 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:22 --> Controller Class Initialized
INFO - 2024-12-04 17:36:22 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:22 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:22 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:22 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:36:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:36:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-04 17:36:22 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:22 --> Total execution time: 0.1908
INFO - 2024-12-04 17:36:47 --> Config Class Initialized
INFO - 2024-12-04 17:36:47 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:47 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:47 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:47 --> URI Class Initialized
INFO - 2024-12-04 17:36:47 --> Router Class Initialized
INFO - 2024-12-04 17:36:47 --> Output Class Initialized
INFO - 2024-12-04 17:36:47 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:47 --> CSRF cookie sent
INFO - 2024-12-04 17:36:47 --> Input Class Initialized
INFO - 2024-12-04 17:36:47 --> Language Class Initialized
INFO - 2024-12-04 17:36:47 --> Loader Class Initialized
INFO - 2024-12-04 17:36:47 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:47 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:47 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:47 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:47 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:47 --> Controller Class Initialized
INFO - 2024-12-04 17:36:47 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:47 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:36:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:47 --> Config Class Initialized
INFO - 2024-12-04 17:36:47 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:47 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:47 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:47 --> URI Class Initialized
INFO - 2024-12-04 17:36:47 --> Router Class Initialized
INFO - 2024-12-04 17:36:47 --> Output Class Initialized
INFO - 2024-12-04 17:36:47 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:47 --> CSRF cookie sent
INFO - 2024-12-04 17:36:47 --> Input Class Initialized
INFO - 2024-12-04 17:36:47 --> Language Class Initialized
INFO - 2024-12-04 17:36:47 --> Loader Class Initialized
INFO - 2024-12-04 17:36:47 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:47 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:47 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:47 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:47 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:47 --> Controller Class Initialized
INFO - 2024-12-04 17:36:47 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:47 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:36:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:36:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:36:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-04 17:36:47 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:47 --> Total execution time: 0.0744
INFO - 2024-12-04 17:36:53 --> Config Class Initialized
INFO - 2024-12-04 17:36:53 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:53 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:53 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:53 --> URI Class Initialized
INFO - 2024-12-04 17:36:53 --> Router Class Initialized
INFO - 2024-12-04 17:36:53 --> Output Class Initialized
INFO - 2024-12-04 17:36:53 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:53 --> CSRF cookie sent
INFO - 2024-12-04 17:36:53 --> CSRF token verified
INFO - 2024-12-04 17:36:53 --> Input Class Initialized
INFO - 2024-12-04 17:36:53 --> Language Class Initialized
INFO - 2024-12-04 17:36:53 --> Loader Class Initialized
INFO - 2024-12-04 17:36:53 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:53 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:53 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:53 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:53 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:53 --> Controller Class Initialized
INFO - 2024-12-04 17:36:53 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "Review_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "News_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:53 --> Config Class Initialized
INFO - 2024-12-04 17:36:53 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:53 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:53 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:53 --> URI Class Initialized
INFO - 2024-12-04 17:36:53 --> Router Class Initialized
INFO - 2024-12-04 17:36:53 --> Output Class Initialized
INFO - 2024-12-04 17:36:53 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:53 --> CSRF cookie sent
INFO - 2024-12-04 17:36:53 --> Input Class Initialized
INFO - 2024-12-04 17:36:53 --> Language Class Initialized
INFO - 2024-12-04 17:36:53 --> Loader Class Initialized
INFO - 2024-12-04 17:36:53 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:53 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:53 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:53 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:53 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:53 --> Controller Class Initialized
INFO - 2024-12-04 17:36:53 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:36:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:36:53 --> Query result: stdClass Object
(
    [view_count] => 34
)

INFO - 2024-12-04 17:36:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-04 17:36:53 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:53 --> Total execution time: 0.1090
INFO - 2024-12-04 17:36:57 --> Config Class Initialized
INFO - 2024-12-04 17:36:57 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:57 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:57 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:57 --> URI Class Initialized
INFO - 2024-12-04 17:36:57 --> Router Class Initialized
INFO - 2024-12-04 17:36:57 --> Output Class Initialized
INFO - 2024-12-04 17:36:57 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:57 --> CSRF cookie sent
INFO - 2024-12-04 17:36:57 --> Input Class Initialized
INFO - 2024-12-04 17:36:57 --> Language Class Initialized
INFO - 2024-12-04 17:36:57 --> Loader Class Initialized
INFO - 2024-12-04 17:36:57 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:57 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:57 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:57 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:57 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:57 --> Controller Class Initialized
INFO - 2024-12-04 17:36:57 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:57 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:57 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:36:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:36:57 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:57 --> Total execution time: 0.0925
INFO - 2024-12-04 17:36:58 --> Config Class Initialized
INFO - 2024-12-04 17:36:58 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:36:58 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:36:58 --> Utf8 Class Initialized
INFO - 2024-12-04 17:36:58 --> URI Class Initialized
INFO - 2024-12-04 17:36:59 --> Router Class Initialized
INFO - 2024-12-04 17:36:59 --> Output Class Initialized
INFO - 2024-12-04 17:36:59 --> Security Class Initialized
DEBUG - 2024-12-04 17:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:36:59 --> CSRF cookie sent
INFO - 2024-12-04 17:36:59 --> Input Class Initialized
INFO - 2024-12-04 17:36:59 --> Language Class Initialized
INFO - 2024-12-04 17:36:59 --> Loader Class Initialized
INFO - 2024-12-04 17:36:59 --> Helper loaded: url_helper
INFO - 2024-12-04 17:36:59 --> Helper loaded: form_helper
INFO - 2024-12-04 17:36:59 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:36:59 --> Form Validation Class Initialized
INFO - 2024-12-04 17:36:59 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:36:59 --> Controller Class Initialized
INFO - 2024-12-04 17:36:59 --> Model "Category_model" initialized
INFO - 2024-12-04 17:36:59 --> Model "User_model" initialized
INFO - 2024-12-04 17:36:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:36:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:36:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-04 17:36:59 --> Final output sent to browser
DEBUG - 2024-12-04 17:36:59 --> Total execution time: 0.1016
INFO - 2024-12-04 17:37:59 --> Config Class Initialized
INFO - 2024-12-04 17:37:59 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:37:59 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:37:59 --> Utf8 Class Initialized
INFO - 2024-12-04 17:37:59 --> URI Class Initialized
INFO - 2024-12-04 17:37:59 --> Router Class Initialized
INFO - 2024-12-04 17:37:59 --> Output Class Initialized
INFO - 2024-12-04 17:37:59 --> Security Class Initialized
DEBUG - 2024-12-04 17:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:37:59 --> CSRF cookie sent
INFO - 2024-12-04 17:37:59 --> Input Class Initialized
INFO - 2024-12-04 17:37:59 --> Language Class Initialized
INFO - 2024-12-04 17:37:59 --> Loader Class Initialized
INFO - 2024-12-04 17:37:59 --> Helper loaded: url_helper
INFO - 2024-12-04 17:37:59 --> Helper loaded: form_helper
INFO - 2024-12-04 17:37:59 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:38:00 --> Form Validation Class Initialized
INFO - 2024-12-04 17:38:00 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:38:00 --> Controller Class Initialized
INFO - 2024-12-04 17:38:00 --> Model "User_model" initialized
INFO - 2024-12-04 17:38:00 --> Model "Category_model" initialized
INFO - 2024-12-04 17:38:00 --> Model "Review_model" initialized
INFO - 2024-12-04 17:38:00 --> Model "News_model" initialized
INFO - 2024-12-04 17:38:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:38:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-04 17:38:00 --> Query result: stdClass Object
(
    [view_count] => 35
)

INFO - 2024-12-04 17:38:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:38:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:38:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-04 17:38:00 --> Final output sent to browser
DEBUG - 2024-12-04 17:38:00 --> Total execution time: 0.9481
INFO - 2024-12-04 17:38:18 --> Config Class Initialized
INFO - 2024-12-04 17:38:18 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:38:18 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:38:18 --> Utf8 Class Initialized
INFO - 2024-12-04 17:38:18 --> URI Class Initialized
INFO - 2024-12-04 17:38:18 --> Router Class Initialized
INFO - 2024-12-04 17:38:18 --> Output Class Initialized
INFO - 2024-12-04 17:38:18 --> Security Class Initialized
DEBUG - 2024-12-04 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:38:18 --> CSRF cookie sent
INFO - 2024-12-04 17:38:18 --> CSRF token verified
INFO - 2024-12-04 17:38:18 --> Input Class Initialized
INFO - 2024-12-04 17:38:18 --> Language Class Initialized
INFO - 2024-12-04 17:38:18 --> Loader Class Initialized
INFO - 2024-12-04 17:38:18 --> Helper loaded: url_helper
INFO - 2024-12-04 17:38:18 --> Helper loaded: form_helper
INFO - 2024-12-04 17:38:18 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:38:18 --> Form Validation Class Initialized
INFO - 2024-12-04 17:38:18 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:38:18 --> Controller Class Initialized
INFO - 2024-12-04 17:38:18 --> Model "Category_model" initialized
INFO - 2024-12-04 17:38:18 --> Model "User_model" initialized
INFO - 2024-12-04 17:38:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:38:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:38:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-04 17:38:18 --> Config Class Initialized
INFO - 2024-12-04 17:38:18 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:38:18 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:38:18 --> Utf8 Class Initialized
INFO - 2024-12-04 17:38:18 --> URI Class Initialized
INFO - 2024-12-04 17:38:18 --> Router Class Initialized
INFO - 2024-12-04 17:38:18 --> Output Class Initialized
INFO - 2024-12-04 17:38:18 --> Security Class Initialized
DEBUG - 2024-12-04 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:38:18 --> CSRF cookie sent
INFO - 2024-12-04 17:38:18 --> Input Class Initialized
INFO - 2024-12-04 17:38:18 --> Language Class Initialized
INFO - 2024-12-04 17:38:18 --> Loader Class Initialized
INFO - 2024-12-04 17:38:18 --> Helper loaded: url_helper
INFO - 2024-12-04 17:38:18 --> Helper loaded: form_helper
INFO - 2024-12-04 17:38:18 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:38:18 --> Form Validation Class Initialized
INFO - 2024-12-04 17:38:18 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:38:18 --> Controller Class Initialized
INFO - 2024-12-04 17:38:18 --> Model "Category_model" initialized
INFO - 2024-12-04 17:38:18 --> Model "User_model" initialized
INFO - 2024-12-04 17:38:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-04 17:38:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:38:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-04 17:38:18 --> Final output sent to browser
DEBUG - 2024-12-04 17:38:18 --> Total execution time: 0.0748
INFO - 2024-12-04 17:38:29 --> Config Class Initialized
INFO - 2024-12-04 17:38:29 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:38:29 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:38:29 --> Utf8 Class Initialized
INFO - 2024-12-04 17:38:29 --> URI Class Initialized
INFO - 2024-12-04 17:38:29 --> Router Class Initialized
INFO - 2024-12-04 17:38:29 --> Output Class Initialized
INFO - 2024-12-04 17:38:29 --> Security Class Initialized
DEBUG - 2024-12-04 17:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:38:29 --> CSRF cookie sent
INFO - 2024-12-04 17:38:29 --> Input Class Initialized
INFO - 2024-12-04 17:38:29 --> Language Class Initialized
INFO - 2024-12-04 17:38:29 --> Loader Class Initialized
INFO - 2024-12-04 17:38:29 --> Helper loaded: url_helper
INFO - 2024-12-04 17:38:29 --> Helper loaded: form_helper
INFO - 2024-12-04 17:38:29 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:38:29 --> Form Validation Class Initialized
INFO - 2024-12-04 17:38:29 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:38:29 --> Controller Class Initialized
INFO - 2024-12-04 17:38:29 --> Model "User_model" initialized
INFO - 2024-12-04 17:38:29 --> Model "Category_model" initialized
INFO - 2024-12-04 17:38:29 --> Model "Review_model" initialized
INFO - 2024-12-04 17:38:29 --> Model "News_model" initialized
INFO - 2024-12-04 17:38:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:38:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:38:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:38:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-04 17:38:29 --> Final output sent to browser
DEBUG - 2024-12-04 17:38:29 --> Total execution time: 0.1186
INFO - 2024-12-04 17:40:53 --> Config Class Initialized
INFO - 2024-12-04 17:40:53 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:40:53 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:40:53 --> Utf8 Class Initialized
INFO - 2024-12-04 17:40:53 --> URI Class Initialized
INFO - 2024-12-04 17:40:53 --> Router Class Initialized
INFO - 2024-12-04 17:40:53 --> Output Class Initialized
INFO - 2024-12-04 17:40:53 --> Security Class Initialized
DEBUG - 2024-12-04 17:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:40:53 --> CSRF cookie sent
INFO - 2024-12-04 17:40:53 --> Input Class Initialized
INFO - 2024-12-04 17:40:53 --> Language Class Initialized
INFO - 2024-12-04 17:40:53 --> Loader Class Initialized
INFO - 2024-12-04 17:40:53 --> Helper loaded: url_helper
INFO - 2024-12-04 17:40:53 --> Helper loaded: form_helper
INFO - 2024-12-04 17:40:53 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:40:54 --> Form Validation Class Initialized
INFO - 2024-12-04 17:40:54 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:40:54 --> Controller Class Initialized
INFO - 2024-12-04 17:40:54 --> Model "User_model" initialized
INFO - 2024-12-04 17:40:54 --> Model "Category_model" initialized
INFO - 2024-12-04 17:40:54 --> Model "Review_model" initialized
INFO - 2024-12-04 17:40:54 --> Model "News_model" initialized
INFO - 2024-12-04 17:40:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:40:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:40:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:40:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-04 17:40:54 --> Final output sent to browser
DEBUG - 2024-12-04 17:40:54 --> Total execution time: 0.6462
INFO - 2024-12-04 17:40:58 --> Config Class Initialized
INFO - 2024-12-04 17:40:58 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:40:58 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:40:58 --> Utf8 Class Initialized
INFO - 2024-12-04 17:40:58 --> URI Class Initialized
INFO - 2024-12-04 17:40:58 --> Router Class Initialized
INFO - 2024-12-04 17:40:58 --> Output Class Initialized
INFO - 2024-12-04 17:40:58 --> Security Class Initialized
DEBUG - 2024-12-04 17:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:40:58 --> CSRF cookie sent
INFO - 2024-12-04 17:40:58 --> Input Class Initialized
INFO - 2024-12-04 17:40:58 --> Language Class Initialized
INFO - 2024-12-04 17:40:58 --> Loader Class Initialized
INFO - 2024-12-04 17:40:58 --> Helper loaded: url_helper
INFO - 2024-12-04 17:40:58 --> Helper loaded: form_helper
INFO - 2024-12-04 17:40:58 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:40:58 --> Form Validation Class Initialized
INFO - 2024-12-04 17:40:58 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:40:58 --> Controller Class Initialized
INFO - 2024-12-04 17:40:58 --> Model "User_model" initialized
INFO - 2024-12-04 17:40:58 --> Model "Category_model" initialized
INFO - 2024-12-04 17:40:58 --> Model "Review_model" initialized
INFO - 2024-12-04 17:40:58 --> Model "News_model" initialized
INFO - 2024-12-04 17:40:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:40:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:40:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:40:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-04 17:40:58 --> Final output sent to browser
DEBUG - 2024-12-04 17:40:58 --> Total execution time: 0.1650
INFO - 2024-12-04 17:42:28 --> Config Class Initialized
INFO - 2024-12-04 17:42:28 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:42:28 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:42:28 --> Utf8 Class Initialized
INFO - 2024-12-04 17:42:28 --> URI Class Initialized
INFO - 2024-12-04 17:42:28 --> Router Class Initialized
INFO - 2024-12-04 17:42:28 --> Output Class Initialized
INFO - 2024-12-04 17:42:28 --> Security Class Initialized
DEBUG - 2024-12-04 17:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:42:28 --> CSRF cookie sent
INFO - 2024-12-04 17:42:28 --> Input Class Initialized
INFO - 2024-12-04 17:42:28 --> Language Class Initialized
INFO - 2024-12-04 17:42:28 --> Loader Class Initialized
INFO - 2024-12-04 17:42:28 --> Helper loaded: url_helper
INFO - 2024-12-04 17:42:28 --> Helper loaded: form_helper
INFO - 2024-12-04 17:42:28 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:42:28 --> Form Validation Class Initialized
INFO - 2024-12-04 17:42:28 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:42:28 --> Controller Class Initialized
INFO - 2024-12-04 17:42:28 --> Model "User_model" initialized
INFO - 2024-12-04 17:42:28 --> Model "Category_model" initialized
INFO - 2024-12-04 17:42:28 --> Model "Review_model" initialized
INFO - 2024-12-04 17:42:28 --> Model "News_model" initialized
INFO - 2024-12-04 17:42:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:42:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:42:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:42:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-04 17:42:29 --> Final output sent to browser
DEBUG - 2024-12-04 17:42:29 --> Total execution time: 0.5683
INFO - 2024-12-04 17:43:19 --> Config Class Initialized
INFO - 2024-12-04 17:43:19 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:43:19 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:43:19 --> Utf8 Class Initialized
INFO - 2024-12-04 17:43:19 --> URI Class Initialized
INFO - 2024-12-04 17:43:19 --> Router Class Initialized
INFO - 2024-12-04 17:43:19 --> Output Class Initialized
INFO - 2024-12-04 17:43:19 --> Security Class Initialized
DEBUG - 2024-12-04 17:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:43:19 --> CSRF cookie sent
INFO - 2024-12-04 17:43:19 --> Input Class Initialized
INFO - 2024-12-04 17:43:19 --> Language Class Initialized
INFO - 2024-12-04 17:43:19 --> Loader Class Initialized
INFO - 2024-12-04 17:43:19 --> Helper loaded: url_helper
INFO - 2024-12-04 17:43:19 --> Helper loaded: form_helper
INFO - 2024-12-04 17:43:19 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:43:19 --> Form Validation Class Initialized
INFO - 2024-12-04 17:43:19 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:43:19 --> Controller Class Initialized
INFO - 2024-12-04 17:43:19 --> Model "User_model" initialized
INFO - 2024-12-04 17:43:19 --> Model "Category_model" initialized
INFO - 2024-12-04 17:43:19 --> Model "Review_model" initialized
INFO - 2024-12-04 17:43:19 --> Model "News_model" initialized
INFO - 2024-12-04 17:43:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:43:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:43:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:43:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-04 17:43:19 --> Final output sent to browser
DEBUG - 2024-12-04 17:43:19 --> Total execution time: 0.1650
INFO - 2024-12-04 17:43:23 --> Config Class Initialized
INFO - 2024-12-04 17:43:23 --> Hooks Class Initialized
DEBUG - 2024-12-04 17:43:23 --> UTF-8 Support Enabled
INFO - 2024-12-04 17:43:23 --> Utf8 Class Initialized
INFO - 2024-12-04 17:43:23 --> URI Class Initialized
INFO - 2024-12-04 17:43:23 --> Router Class Initialized
INFO - 2024-12-04 17:43:23 --> Output Class Initialized
INFO - 2024-12-04 17:43:23 --> Security Class Initialized
DEBUG - 2024-12-04 17:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 17:43:23 --> CSRF cookie sent
INFO - 2024-12-04 17:43:23 --> Input Class Initialized
INFO - 2024-12-04 17:43:23 --> Language Class Initialized
INFO - 2024-12-04 17:43:23 --> Loader Class Initialized
INFO - 2024-12-04 17:43:23 --> Helper loaded: url_helper
INFO - 2024-12-04 17:43:23 --> Helper loaded: form_helper
INFO - 2024-12-04 17:43:23 --> Database Driver Class Initialized
DEBUG - 2024-12-04 17:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 17:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 17:43:23 --> Form Validation Class Initialized
INFO - 2024-12-04 17:43:23 --> Model "Culinary_model" initialized
INFO - 2024-12-04 17:43:23 --> Controller Class Initialized
INFO - 2024-12-04 17:43:23 --> Model "User_model" initialized
INFO - 2024-12-04 17:43:23 --> Model "Category_model" initialized
INFO - 2024-12-04 17:43:23 --> Model "Review_model" initialized
INFO - 2024-12-04 17:43:23 --> Model "News_model" initialized
INFO - 2024-12-04 17:43:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-04 17:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-04 17:43:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-04 17:43:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-04 17:43:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-04 17:43:23 --> Final output sent to browser
DEBUG - 2024-12-04 17:43:23 --> Total execution time: 0.0930
