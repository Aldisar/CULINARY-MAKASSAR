<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-10 14:52:03 --> Config Class Initialized
INFO - 2024-12-10 14:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:52:03 --> Utf8 Class Initialized
INFO - 2024-12-10 14:52:03 --> URI Class Initialized
DEBUG - 2024-12-10 14:52:03 --> No URI present. Default controller set.
INFO - 2024-12-10 14:52:03 --> Router Class Initialized
INFO - 2024-12-10 14:52:03 --> Output Class Initialized
INFO - 2024-12-10 14:52:03 --> Security Class Initialized
DEBUG - 2024-12-10 14:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:52:03 --> CSRF cookie sent
INFO - 2024-12-10 14:52:03 --> Input Class Initialized
INFO - 2024-12-10 14:52:03 --> Language Class Initialized
INFO - 2024-12-10 14:52:03 --> Loader Class Initialized
INFO - 2024-12-10 14:52:03 --> Helper loaded: url_helper
INFO - 2024-12-10 14:52:03 --> Helper loaded: form_helper
INFO - 2024-12-10 14:52:03 --> Database Driver Class Initialized
ERROR - 2024-12-10 14:52:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\CAMA\Culinary\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-10 14:52:08 --> Unable to connect to the database
INFO - 2024-12-10 14:52:08 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-10 14:52:09 --> Config Class Initialized
INFO - 2024-12-10 14:52:09 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:52:09 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:52:09 --> Utf8 Class Initialized
INFO - 2024-12-10 14:52:09 --> URI Class Initialized
DEBUG - 2024-12-10 14:52:09 --> No URI present. Default controller set.
INFO - 2024-12-10 14:52:09 --> Router Class Initialized
INFO - 2024-12-10 14:52:09 --> Output Class Initialized
INFO - 2024-12-10 14:52:09 --> Security Class Initialized
DEBUG - 2024-12-10 14:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:52:09 --> CSRF cookie sent
INFO - 2024-12-10 14:52:09 --> Input Class Initialized
INFO - 2024-12-10 14:52:09 --> Language Class Initialized
INFO - 2024-12-10 14:52:09 --> Loader Class Initialized
INFO - 2024-12-10 14:52:09 --> Helper loaded: url_helper
INFO - 2024-12-10 14:52:09 --> Helper loaded: form_helper
INFO - 2024-12-10 14:52:09 --> Database Driver Class Initialized
ERROR - 2024-12-10 14:52:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\CAMA\Culinary\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-10 14:52:13 --> Unable to connect to the database
INFO - 2024-12-10 14:52:13 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-10 14:53:09 --> Config Class Initialized
INFO - 2024-12-10 14:53:09 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:53:09 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:53:09 --> Utf8 Class Initialized
INFO - 2024-12-10 14:53:09 --> URI Class Initialized
DEBUG - 2024-12-10 14:53:09 --> No URI present. Default controller set.
INFO - 2024-12-10 14:53:09 --> Router Class Initialized
INFO - 2024-12-10 14:53:09 --> Output Class Initialized
INFO - 2024-12-10 14:53:09 --> Security Class Initialized
DEBUG - 2024-12-10 14:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:53:09 --> CSRF cookie sent
INFO - 2024-12-10 14:53:09 --> Input Class Initialized
INFO - 2024-12-10 14:53:09 --> Language Class Initialized
INFO - 2024-12-10 14:53:09 --> Loader Class Initialized
INFO - 2024-12-10 14:53:09 --> Helper loaded: url_helper
INFO - 2024-12-10 14:53:09 --> Helper loaded: form_helper
INFO - 2024-12-10 14:53:09 --> Database Driver Class Initialized
DEBUG - 2024-12-10 14:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 14:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:53:09 --> Form Validation Class Initialized
INFO - 2024-12-10 14:53:09 --> Model "Culinary_model" initialized
INFO - 2024-12-10 14:53:09 --> Controller Class Initialized
INFO - 2024-12-10 14:53:09 --> Model "User_model" initialized
INFO - 2024-12-10 14:53:09 --> Model "Category_model" initialized
INFO - 2024-12-10 14:53:09 --> Model "Review_model" initialized
INFO - 2024-12-10 14:53:09 --> Model "News_model" initialized
INFO - 2024-12-10 14:53:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 14:53:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 14:53:09 --> Query result: stdClass Object
(
    [view_count] => 111
)

INFO - 2024-12-10 14:53:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 14:53:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 14:53:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 14:53:09 --> Final output sent to browser
DEBUG - 2024-12-10 14:53:09 --> Total execution time: 0.2812
INFO - 2024-12-10 14:53:12 --> Config Class Initialized
INFO - 2024-12-10 14:53:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:53:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:53:12 --> Utf8 Class Initialized
INFO - 2024-12-10 14:53:12 --> URI Class Initialized
DEBUG - 2024-12-10 14:53:12 --> No URI present. Default controller set.
INFO - 2024-12-10 14:53:12 --> Router Class Initialized
INFO - 2024-12-10 14:53:12 --> Output Class Initialized
INFO - 2024-12-10 14:53:12 --> Security Class Initialized
DEBUG - 2024-12-10 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:53:12 --> CSRF cookie sent
INFO - 2024-12-10 14:53:12 --> Input Class Initialized
INFO - 2024-12-10 14:53:12 --> Language Class Initialized
INFO - 2024-12-10 14:53:12 --> Loader Class Initialized
INFO - 2024-12-10 14:53:12 --> Helper loaded: url_helper
INFO - 2024-12-10 14:53:12 --> Helper loaded: form_helper
INFO - 2024-12-10 14:53:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 14:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 14:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:53:12 --> Form Validation Class Initialized
INFO - 2024-12-10 14:53:12 --> Model "Culinary_model" initialized
INFO - 2024-12-10 14:53:12 --> Controller Class Initialized
INFO - 2024-12-10 14:53:12 --> Model "User_model" initialized
INFO - 2024-12-10 14:53:12 --> Model "Category_model" initialized
INFO - 2024-12-10 14:53:12 --> Model "Review_model" initialized
INFO - 2024-12-10 14:53:12 --> Model "News_model" initialized
INFO - 2024-12-10 14:53:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 14:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 14:53:12 --> Query result: stdClass Object
(
    [view_count] => 112
)

INFO - 2024-12-10 14:53:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 14:53:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 14:53:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 14:53:12 --> Final output sent to browser
DEBUG - 2024-12-10 14:53:12 --> Total execution time: 0.0645
INFO - 2024-12-10 15:05:54 --> Config Class Initialized
INFO - 2024-12-10 15:05:54 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:05:54 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:05:54 --> Utf8 Class Initialized
INFO - 2024-12-10 15:05:54 --> URI Class Initialized
DEBUG - 2024-12-10 15:05:54 --> No URI present. Default controller set.
INFO - 2024-12-10 15:05:54 --> Router Class Initialized
INFO - 2024-12-10 15:05:54 --> Output Class Initialized
INFO - 2024-12-10 15:05:54 --> Security Class Initialized
DEBUG - 2024-12-10 15:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:05:54 --> CSRF cookie sent
INFO - 2024-12-10 15:05:54 --> Input Class Initialized
INFO - 2024-12-10 15:05:54 --> Language Class Initialized
INFO - 2024-12-10 15:05:54 --> Loader Class Initialized
INFO - 2024-12-10 15:05:54 --> Helper loaded: url_helper
INFO - 2024-12-10 15:05:54 --> Helper loaded: form_helper
INFO - 2024-12-10 15:05:54 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:05:54 --> Form Validation Class Initialized
INFO - 2024-12-10 15:05:54 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:05:54 --> Controller Class Initialized
INFO - 2024-12-10 15:05:54 --> Model "User_model" initialized
INFO - 2024-12-10 15:05:54 --> Model "Category_model" initialized
INFO - 2024-12-10 15:05:54 --> Model "Review_model" initialized
INFO - 2024-12-10 15:05:54 --> Model "News_model" initialized
INFO - 2024-12-10 15:05:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:05:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 15:05:54 --> Query result: stdClass Object
(
    [view_count] => 113
)

INFO - 2024-12-10 15:05:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:05:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:05:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 15:05:54 --> Final output sent to browser
DEBUG - 2024-12-10 15:05:54 --> Total execution time: 0.1416
INFO - 2024-12-10 15:05:57 --> Config Class Initialized
INFO - 2024-12-10 15:05:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:05:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:05:57 --> Utf8 Class Initialized
INFO - 2024-12-10 15:05:58 --> URI Class Initialized
INFO - 2024-12-10 15:05:58 --> Router Class Initialized
INFO - 2024-12-10 15:05:58 --> Output Class Initialized
INFO - 2024-12-10 15:05:58 --> Security Class Initialized
DEBUG - 2024-12-10 15:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:05:58 --> CSRF cookie sent
INFO - 2024-12-10 15:05:58 --> Input Class Initialized
INFO - 2024-12-10 15:05:58 --> Language Class Initialized
INFO - 2024-12-10 15:05:58 --> Loader Class Initialized
INFO - 2024-12-10 15:05:58 --> Helper loaded: url_helper
INFO - 2024-12-10 15:05:58 --> Helper loaded: form_helper
INFO - 2024-12-10 15:05:58 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:05:58 --> Form Validation Class Initialized
INFO - 2024-12-10 15:05:58 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:05:58 --> Controller Class Initialized
INFO - 2024-12-10 15:05:58 --> Model "User_model" initialized
INFO - 2024-12-10 15:05:58 --> Model "Category_model" initialized
INFO - 2024-12-10 15:05:58 --> Model "Review_model" initialized
INFO - 2024-12-10 15:05:58 --> Model "News_model" initialized
INFO - 2024-12-10 15:05:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:05:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:05:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:05:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-10 15:05:58 --> Final output sent to browser
DEBUG - 2024-12-10 15:05:58 --> Total execution time: 0.1294
INFO - 2024-12-10 15:06:18 --> Config Class Initialized
INFO - 2024-12-10 15:06:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:06:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:06:18 --> Utf8 Class Initialized
INFO - 2024-12-10 15:06:18 --> URI Class Initialized
INFO - 2024-12-10 15:06:18 --> Router Class Initialized
INFO - 2024-12-10 15:06:18 --> Output Class Initialized
INFO - 2024-12-10 15:06:18 --> Security Class Initialized
DEBUG - 2024-12-10 15:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:06:18 --> CSRF cookie sent
INFO - 2024-12-10 15:06:18 --> Input Class Initialized
INFO - 2024-12-10 15:06:18 --> Language Class Initialized
INFO - 2024-12-10 15:06:18 --> Loader Class Initialized
INFO - 2024-12-10 15:06:18 --> Helper loaded: url_helper
INFO - 2024-12-10 15:06:18 --> Helper loaded: form_helper
INFO - 2024-12-10 15:06:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:06:18 --> Form Validation Class Initialized
INFO - 2024-12-10 15:06:18 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:06:18 --> Controller Class Initialized
INFO - 2024-12-10 15:06:18 --> Model "User_model" initialized
INFO - 2024-12-10 15:06:18 --> Model "Category_model" initialized
INFO - 2024-12-10 15:06:18 --> Model "Review_model" initialized
INFO - 2024-12-10 15:06:18 --> Model "News_model" initialized
INFO - 2024-12-10 15:06:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:06:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:06:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:06:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:06:18 --> Final output sent to browser
DEBUG - 2024-12-10 15:06:18 --> Total execution time: 0.0791
INFO - 2024-12-10 15:06:21 --> Config Class Initialized
INFO - 2024-12-10 15:06:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:06:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:06:21 --> Utf8 Class Initialized
INFO - 2024-12-10 15:06:21 --> URI Class Initialized
INFO - 2024-12-10 15:06:21 --> Router Class Initialized
INFO - 2024-12-10 15:06:21 --> Output Class Initialized
INFO - 2024-12-10 15:06:21 --> Security Class Initialized
DEBUG - 2024-12-10 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:06:21 --> CSRF cookie sent
INFO - 2024-12-10 15:06:21 --> CSRF token verified
INFO - 2024-12-10 15:06:21 --> Input Class Initialized
INFO - 2024-12-10 15:06:21 --> Language Class Initialized
INFO - 2024-12-10 15:06:21 --> Loader Class Initialized
INFO - 2024-12-10 15:06:21 --> Helper loaded: url_helper
INFO - 2024-12-10 15:06:21 --> Helper loaded: form_helper
INFO - 2024-12-10 15:06:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:06:21 --> Form Validation Class Initialized
INFO - 2024-12-10 15:06:21 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:06:21 --> Controller Class Initialized
INFO - 2024-12-10 15:06:21 --> Model "User_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "Category_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "Review_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "News_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:06:21 --> Config Class Initialized
INFO - 2024-12-10 15:06:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:06:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:06:21 --> Utf8 Class Initialized
INFO - 2024-12-10 15:06:21 --> URI Class Initialized
INFO - 2024-12-10 15:06:21 --> Router Class Initialized
INFO - 2024-12-10 15:06:21 --> Output Class Initialized
INFO - 2024-12-10 15:06:21 --> Security Class Initialized
DEBUG - 2024-12-10 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:06:21 --> CSRF cookie sent
INFO - 2024-12-10 15:06:21 --> Input Class Initialized
INFO - 2024-12-10 15:06:21 --> Language Class Initialized
INFO - 2024-12-10 15:06:21 --> Loader Class Initialized
INFO - 2024-12-10 15:06:21 --> Helper loaded: url_helper
INFO - 2024-12-10 15:06:21 --> Helper loaded: form_helper
INFO - 2024-12-10 15:06:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:06:21 --> Form Validation Class Initialized
INFO - 2024-12-10 15:06:21 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:06:21 --> Controller Class Initialized
INFO - 2024-12-10 15:06:21 --> Model "Review_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "Category_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "User_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:06:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 15:06:21 --> Query result: stdClass Object
(
    [view_count] => 113
)

INFO - 2024-12-10 15:06:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-10 15:06:21 --> Final output sent to browser
DEBUG - 2024-12-10 15:06:21 --> Total execution time: 0.0836
INFO - 2024-12-10 15:07:11 --> Config Class Initialized
INFO - 2024-12-10 15:07:11 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:11 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:11 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:11 --> URI Class Initialized
INFO - 2024-12-10 15:07:11 --> Router Class Initialized
INFO - 2024-12-10 15:07:11 --> Output Class Initialized
INFO - 2024-12-10 15:07:11 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:11 --> CSRF cookie sent
INFO - 2024-12-10 15:07:11 --> Input Class Initialized
INFO - 2024-12-10 15:07:11 --> Language Class Initialized
INFO - 2024-12-10 15:07:11 --> Loader Class Initialized
INFO - 2024-12-10 15:07:11 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:11 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:11 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:11 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:11 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:11 --> Controller Class Initialized
INFO - 2024-12-10 15:07:11 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:11 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:11 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:07:11 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:11 --> Total execution time: 0.0611
INFO - 2024-12-10 15:07:12 --> Config Class Initialized
INFO - 2024-12-10 15:07:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:12 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:12 --> URI Class Initialized
INFO - 2024-12-10 15:07:12 --> Router Class Initialized
INFO - 2024-12-10 15:07:12 --> Output Class Initialized
INFO - 2024-12-10 15:07:12 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:12 --> CSRF cookie sent
INFO - 2024-12-10 15:07:12 --> Input Class Initialized
INFO - 2024-12-10 15:07:12 --> Language Class Initialized
INFO - 2024-12-10 15:07:12 --> Loader Class Initialized
INFO - 2024-12-10 15:07:12 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:12 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:12 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:12 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:12 --> Controller Class Initialized
INFO - 2024-12-10 15:07:12 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:12 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:12 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-10 15:07:12 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:12 --> Total execution time: 0.0681
INFO - 2024-12-10 15:07:14 --> Config Class Initialized
INFO - 2024-12-10 15:07:14 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:14 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:14 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:14 --> URI Class Initialized
INFO - 2024-12-10 15:07:14 --> Router Class Initialized
INFO - 2024-12-10 15:07:14 --> Output Class Initialized
INFO - 2024-12-10 15:07:14 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:14 --> CSRF cookie sent
INFO - 2024-12-10 15:07:14 --> Input Class Initialized
INFO - 2024-12-10 15:07:14 --> Language Class Initialized
INFO - 2024-12-10 15:07:14 --> Loader Class Initialized
INFO - 2024-12-10 15:07:14 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:14 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:14 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:14 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:14 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:14 --> Controller Class Initialized
INFO - 2024-12-10 15:07:14 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:14 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:14 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:07:14 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:14 --> Total execution time: 0.0600
INFO - 2024-12-10 15:07:15 --> Config Class Initialized
INFO - 2024-12-10 15:07:15 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:15 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:15 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:15 --> URI Class Initialized
INFO - 2024-12-10 15:07:15 --> Router Class Initialized
INFO - 2024-12-10 15:07:15 --> Output Class Initialized
INFO - 2024-12-10 15:07:15 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:15 --> CSRF cookie sent
INFO - 2024-12-10 15:07:15 --> Input Class Initialized
INFO - 2024-12-10 15:07:15 --> Language Class Initialized
INFO - 2024-12-10 15:07:15 --> Loader Class Initialized
INFO - 2024-12-10 15:07:15 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:15 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:15 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:15 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:15 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:15 --> Controller Class Initialized
INFO - 2024-12-10 15:07:15 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:15 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:15 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:07:15 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:15 --> Total execution time: 0.0575
INFO - 2024-12-10 15:07:16 --> Config Class Initialized
INFO - 2024-12-10 15:07:16 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:16 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:16 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:16 --> URI Class Initialized
INFO - 2024-12-10 15:07:16 --> Router Class Initialized
INFO - 2024-12-10 15:07:16 --> Output Class Initialized
INFO - 2024-12-10 15:07:16 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:16 --> CSRF cookie sent
INFO - 2024-12-10 15:07:16 --> Input Class Initialized
INFO - 2024-12-10 15:07:16 --> Language Class Initialized
INFO - 2024-12-10 15:07:16 --> Loader Class Initialized
INFO - 2024-12-10 15:07:16 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:16 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:16 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:16 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:16 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:16 --> Controller Class Initialized
INFO - 2024-12-10 15:07:16 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:16 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:16 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:07:16 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:16 --> Total execution time: 0.0465
INFO - 2024-12-10 15:07:17 --> Config Class Initialized
INFO - 2024-12-10 15:07:17 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:17 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:17 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:17 --> URI Class Initialized
INFO - 2024-12-10 15:07:17 --> Router Class Initialized
INFO - 2024-12-10 15:07:17 --> Output Class Initialized
INFO - 2024-12-10 15:07:17 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:17 --> CSRF cookie sent
INFO - 2024-12-10 15:07:17 --> Input Class Initialized
INFO - 2024-12-10 15:07:17 --> Language Class Initialized
INFO - 2024-12-10 15:07:17 --> Loader Class Initialized
INFO - 2024-12-10 15:07:17 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:17 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:17 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:17 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:17 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:17 --> Controller Class Initialized
INFO - 2024-12-10 15:07:17 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:17 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:17 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:07:17 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:17 --> Total execution time: 0.0512
INFO - 2024-12-10 15:07:21 --> Config Class Initialized
INFO - 2024-12-10 15:07:21 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:21 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:21 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:21 --> URI Class Initialized
INFO - 2024-12-10 15:07:21 --> Router Class Initialized
INFO - 2024-12-10 15:07:21 --> Output Class Initialized
INFO - 2024-12-10 15:07:21 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:21 --> CSRF cookie sent
INFO - 2024-12-10 15:07:21 --> Input Class Initialized
INFO - 2024-12-10 15:07:21 --> Language Class Initialized
INFO - 2024-12-10 15:07:21 --> Loader Class Initialized
INFO - 2024-12-10 15:07:21 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:21 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:21 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:21 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:21 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:21 --> Controller Class Initialized
INFO - 2024-12-10 15:07:21 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:21 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:21 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:07:21 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:21 --> Total execution time: 0.0733
INFO - 2024-12-10 15:07:23 --> Config Class Initialized
INFO - 2024-12-10 15:07:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:23 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:23 --> URI Class Initialized
INFO - 2024-12-10 15:07:23 --> Router Class Initialized
INFO - 2024-12-10 15:07:23 --> Output Class Initialized
INFO - 2024-12-10 15:07:23 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:23 --> CSRF cookie sent
INFO - 2024-12-10 15:07:23 --> Input Class Initialized
INFO - 2024-12-10 15:07:23 --> Language Class Initialized
INFO - 2024-12-10 15:07:23 --> Loader Class Initialized
INFO - 2024-12-10 15:07:23 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:23 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:23 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:23 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:23 --> Controller Class Initialized
INFO - 2024-12-10 15:07:23 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:23 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:23 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:23 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-10 15:07:23 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:23 --> Total execution time: 0.0449
INFO - 2024-12-10 15:07:38 --> Config Class Initialized
INFO - 2024-12-10 15:07:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:38 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:38 --> URI Class Initialized
INFO - 2024-12-10 15:07:38 --> Router Class Initialized
INFO - 2024-12-10 15:07:38 --> Output Class Initialized
INFO - 2024-12-10 15:07:38 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:38 --> CSRF cookie sent
INFO - 2024-12-10 15:07:38 --> CSRF token verified
INFO - 2024-12-10 15:07:38 --> Input Class Initialized
INFO - 2024-12-10 15:07:38 --> Language Class Initialized
INFO - 2024-12-10 15:07:38 --> Loader Class Initialized
INFO - 2024-12-10 15:07:38 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:38 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:38 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:38 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:38 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:38 --> Controller Class Initialized
INFO - 2024-12-10 15:07:38 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:38 --> Upload Class Initialized
INFO - 2024-12-10 15:07:38 --> Config Class Initialized
INFO - 2024-12-10 15:07:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:38 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:38 --> URI Class Initialized
INFO - 2024-12-10 15:07:38 --> Router Class Initialized
INFO - 2024-12-10 15:07:38 --> Output Class Initialized
INFO - 2024-12-10 15:07:38 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:38 --> CSRF cookie sent
INFO - 2024-12-10 15:07:38 --> Input Class Initialized
INFO - 2024-12-10 15:07:38 --> Language Class Initialized
INFO - 2024-12-10 15:07:38 --> Loader Class Initialized
INFO - 2024-12-10 15:07:38 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:38 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:38 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:38 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:38 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:38 --> Controller Class Initialized
INFO - 2024-12-10 15:07:38 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:07:38 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:38 --> Total execution time: 0.0503
INFO - 2024-12-10 15:07:41 --> Config Class Initialized
INFO - 2024-12-10 15:07:41 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:07:41 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:07:41 --> Utf8 Class Initialized
INFO - 2024-12-10 15:07:41 --> URI Class Initialized
INFO - 2024-12-10 15:07:41 --> Router Class Initialized
INFO - 2024-12-10 15:07:41 --> Output Class Initialized
INFO - 2024-12-10 15:07:41 --> Security Class Initialized
DEBUG - 2024-12-10 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:07:41 --> CSRF cookie sent
INFO - 2024-12-10 15:07:41 --> Input Class Initialized
INFO - 2024-12-10 15:07:41 --> Language Class Initialized
INFO - 2024-12-10 15:07:41 --> Loader Class Initialized
INFO - 2024-12-10 15:07:41 --> Helper loaded: url_helper
INFO - 2024-12-10 15:07:41 --> Helper loaded: form_helper
INFO - 2024-12-10 15:07:41 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:07:41 --> Form Validation Class Initialized
INFO - 2024-12-10 15:07:41 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:07:41 --> Controller Class Initialized
INFO - 2024-12-10 15:07:41 --> Model "Review_model" initialized
INFO - 2024-12-10 15:07:41 --> Model "Category_model" initialized
INFO - 2024-12-10 15:07:41 --> Model "User_model" initialized
INFO - 2024-12-10 15:07:41 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:07:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:07:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-10 15:07:41 --> Final output sent to browser
DEBUG - 2024-12-10 15:07:41 --> Total execution time: 0.0472
INFO - 2024-12-10 15:08:29 --> Config Class Initialized
INFO - 2024-12-10 15:08:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:08:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:08:29 --> Utf8 Class Initialized
INFO - 2024-12-10 15:08:29 --> URI Class Initialized
INFO - 2024-12-10 15:08:29 --> Router Class Initialized
INFO - 2024-12-10 15:08:29 --> Output Class Initialized
INFO - 2024-12-10 15:08:29 --> Security Class Initialized
DEBUG - 2024-12-10 15:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:08:29 --> CSRF cookie sent
INFO - 2024-12-10 15:08:29 --> CSRF token verified
INFO - 2024-12-10 15:08:29 --> Input Class Initialized
INFO - 2024-12-10 15:08:29 --> Language Class Initialized
INFO - 2024-12-10 15:08:29 --> Loader Class Initialized
INFO - 2024-12-10 15:08:29 --> Helper loaded: url_helper
INFO - 2024-12-10 15:08:29 --> Helper loaded: form_helper
INFO - 2024-12-10 15:08:29 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:08:29 --> Form Validation Class Initialized
INFO - 2024-12-10 15:08:29 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:08:29 --> Controller Class Initialized
INFO - 2024-12-10 15:08:29 --> Model "Review_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "Category_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "User_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:08:29 --> Upload Class Initialized
INFO - 2024-12-10 15:08:29 --> Config Class Initialized
INFO - 2024-12-10 15:08:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:08:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:08:29 --> Utf8 Class Initialized
INFO - 2024-12-10 15:08:29 --> URI Class Initialized
INFO - 2024-12-10 15:08:29 --> Router Class Initialized
INFO - 2024-12-10 15:08:29 --> Output Class Initialized
INFO - 2024-12-10 15:08:29 --> Security Class Initialized
DEBUG - 2024-12-10 15:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:08:29 --> CSRF cookie sent
INFO - 2024-12-10 15:08:29 --> Input Class Initialized
INFO - 2024-12-10 15:08:29 --> Language Class Initialized
INFO - 2024-12-10 15:08:29 --> Loader Class Initialized
INFO - 2024-12-10 15:08:29 --> Helper loaded: url_helper
INFO - 2024-12-10 15:08:29 --> Helper loaded: form_helper
INFO - 2024-12-10 15:08:29 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:08:29 --> Form Validation Class Initialized
INFO - 2024-12-10 15:08:29 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:08:29 --> Controller Class Initialized
INFO - 2024-12-10 15:08:29 --> Model "Review_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "Category_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "User_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:08:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:08:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:08:29 --> Final output sent to browser
DEBUG - 2024-12-10 15:08:29 --> Total execution time: 0.0614
INFO - 2024-12-10 15:08:33 --> Config Class Initialized
INFO - 2024-12-10 15:08:33 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:08:33 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:08:33 --> Utf8 Class Initialized
INFO - 2024-12-10 15:08:33 --> URI Class Initialized
INFO - 2024-12-10 15:08:33 --> Router Class Initialized
INFO - 2024-12-10 15:08:33 --> Output Class Initialized
INFO - 2024-12-10 15:08:33 --> Security Class Initialized
DEBUG - 2024-12-10 15:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:08:33 --> CSRF cookie sent
INFO - 2024-12-10 15:08:33 --> Input Class Initialized
INFO - 2024-12-10 15:08:33 --> Language Class Initialized
INFO - 2024-12-10 15:08:33 --> Loader Class Initialized
INFO - 2024-12-10 15:08:33 --> Helper loaded: url_helper
INFO - 2024-12-10 15:08:33 --> Helper loaded: form_helper
INFO - 2024-12-10 15:08:33 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:08:33 --> Form Validation Class Initialized
INFO - 2024-12-10 15:08:33 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:08:33 --> Controller Class Initialized
INFO - 2024-12-10 15:08:33 --> Model "Review_model" initialized
INFO - 2024-12-10 15:08:33 --> Model "Category_model" initialized
INFO - 2024-12-10 15:08:33 --> Model "User_model" initialized
INFO - 2024-12-10 15:08:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:08:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:08:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-10 15:08:33 --> Final output sent to browser
DEBUG - 2024-12-10 15:08:33 --> Total execution time: 0.0703
INFO - 2024-12-10 15:08:48 --> Config Class Initialized
INFO - 2024-12-10 15:08:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:08:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:08:48 --> Utf8 Class Initialized
INFO - 2024-12-10 15:08:48 --> URI Class Initialized
INFO - 2024-12-10 15:08:48 --> Router Class Initialized
INFO - 2024-12-10 15:08:48 --> Output Class Initialized
INFO - 2024-12-10 15:08:48 --> Security Class Initialized
DEBUG - 2024-12-10 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:08:48 --> CSRF cookie sent
INFO - 2024-12-10 15:08:48 --> CSRF token verified
INFO - 2024-12-10 15:08:48 --> Input Class Initialized
INFO - 2024-12-10 15:08:48 --> Language Class Initialized
INFO - 2024-12-10 15:08:48 --> Loader Class Initialized
INFO - 2024-12-10 15:08:48 --> Helper loaded: url_helper
INFO - 2024-12-10 15:08:48 --> Helper loaded: form_helper
INFO - 2024-12-10 15:08:48 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:08:48 --> Form Validation Class Initialized
INFO - 2024-12-10 15:08:48 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:08:48 --> Controller Class Initialized
INFO - 2024-12-10 15:08:48 --> Model "Review_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "Category_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "User_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:08:48 --> Upload Class Initialized
INFO - 2024-12-10 15:08:48 --> Config Class Initialized
INFO - 2024-12-10 15:08:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:08:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:08:48 --> Utf8 Class Initialized
INFO - 2024-12-10 15:08:48 --> URI Class Initialized
INFO - 2024-12-10 15:08:48 --> Router Class Initialized
INFO - 2024-12-10 15:08:48 --> Output Class Initialized
INFO - 2024-12-10 15:08:48 --> Security Class Initialized
DEBUG - 2024-12-10 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:08:48 --> CSRF cookie sent
INFO - 2024-12-10 15:08:48 --> Input Class Initialized
INFO - 2024-12-10 15:08:48 --> Language Class Initialized
INFO - 2024-12-10 15:08:48 --> Loader Class Initialized
INFO - 2024-12-10 15:08:48 --> Helper loaded: url_helper
INFO - 2024-12-10 15:08:48 --> Helper loaded: form_helper
INFO - 2024-12-10 15:08:48 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:08:48 --> Form Validation Class Initialized
INFO - 2024-12-10 15:08:48 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:08:48 --> Controller Class Initialized
INFO - 2024-12-10 15:08:48 --> Model "Review_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "Category_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "User_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:08:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:08:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:08:48 --> Final output sent to browser
DEBUG - 2024-12-10 15:08:48 --> Total execution time: 0.0583
INFO - 2024-12-10 15:08:54 --> Config Class Initialized
INFO - 2024-12-10 15:08:54 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:08:54 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:08:54 --> Utf8 Class Initialized
INFO - 2024-12-10 15:08:54 --> URI Class Initialized
INFO - 2024-12-10 15:08:54 --> Router Class Initialized
INFO - 2024-12-10 15:08:54 --> Output Class Initialized
INFO - 2024-12-10 15:08:54 --> Security Class Initialized
DEBUG - 2024-12-10 15:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:08:54 --> CSRF cookie sent
INFO - 2024-12-10 15:08:54 --> Input Class Initialized
INFO - 2024-12-10 15:08:54 --> Language Class Initialized
INFO - 2024-12-10 15:08:54 --> Loader Class Initialized
INFO - 2024-12-10 15:08:54 --> Helper loaded: url_helper
INFO - 2024-12-10 15:08:54 --> Helper loaded: form_helper
INFO - 2024-12-10 15:08:54 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:08:54 --> Form Validation Class Initialized
INFO - 2024-12-10 15:08:54 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:08:54 --> Controller Class Initialized
INFO - 2024-12-10 15:08:54 --> Model "Review_model" initialized
INFO - 2024-12-10 15:08:54 --> Model "Category_model" initialized
INFO - 2024-12-10 15:08:54 --> Model "User_model" initialized
INFO - 2024-12-10 15:08:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:08:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:08:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-10 15:08:54 --> Final output sent to browser
DEBUG - 2024-12-10 15:08:54 --> Total execution time: 0.0455
INFO - 2024-12-10 15:09:10 --> Config Class Initialized
INFO - 2024-12-10 15:09:10 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:09:10 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:09:10 --> Utf8 Class Initialized
INFO - 2024-12-10 15:09:10 --> URI Class Initialized
INFO - 2024-12-10 15:09:10 --> Router Class Initialized
INFO - 2024-12-10 15:09:10 --> Output Class Initialized
INFO - 2024-12-10 15:09:10 --> Security Class Initialized
DEBUG - 2024-12-10 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:09:10 --> CSRF cookie sent
INFO - 2024-12-10 15:09:10 --> CSRF token verified
INFO - 2024-12-10 15:09:10 --> Input Class Initialized
INFO - 2024-12-10 15:09:10 --> Language Class Initialized
INFO - 2024-12-10 15:09:10 --> Loader Class Initialized
INFO - 2024-12-10 15:09:10 --> Helper loaded: url_helper
INFO - 2024-12-10 15:09:10 --> Helper loaded: form_helper
INFO - 2024-12-10 15:09:10 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:09:10 --> Form Validation Class Initialized
INFO - 2024-12-10 15:09:10 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:09:10 --> Controller Class Initialized
INFO - 2024-12-10 15:09:10 --> Model "Review_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "Category_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "User_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:09:10 --> Upload Class Initialized
INFO - 2024-12-10 15:09:10 --> Config Class Initialized
INFO - 2024-12-10 15:09:10 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:09:10 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:09:10 --> Utf8 Class Initialized
INFO - 2024-12-10 15:09:10 --> URI Class Initialized
INFO - 2024-12-10 15:09:10 --> Router Class Initialized
INFO - 2024-12-10 15:09:10 --> Output Class Initialized
INFO - 2024-12-10 15:09:10 --> Security Class Initialized
DEBUG - 2024-12-10 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:09:10 --> CSRF cookie sent
INFO - 2024-12-10 15:09:10 --> Input Class Initialized
INFO - 2024-12-10 15:09:10 --> Language Class Initialized
INFO - 2024-12-10 15:09:10 --> Loader Class Initialized
INFO - 2024-12-10 15:09:10 --> Helper loaded: url_helper
INFO - 2024-12-10 15:09:10 --> Helper loaded: form_helper
INFO - 2024-12-10 15:09:10 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:09:10 --> Form Validation Class Initialized
INFO - 2024-12-10 15:09:10 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:09:10 --> Controller Class Initialized
INFO - 2024-12-10 15:09:10 --> Model "Review_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "Category_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "User_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:09:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:09:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-10 15:09:10 --> Final output sent to browser
DEBUG - 2024-12-10 15:09:10 --> Total execution time: 0.0382
INFO - 2024-12-10 15:09:14 --> Config Class Initialized
INFO - 2024-12-10 15:09:14 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:09:14 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:09:14 --> Utf8 Class Initialized
INFO - 2024-12-10 15:09:14 --> URI Class Initialized
INFO - 2024-12-10 15:09:14 --> Router Class Initialized
INFO - 2024-12-10 15:09:14 --> Output Class Initialized
INFO - 2024-12-10 15:09:14 --> Security Class Initialized
DEBUG - 2024-12-10 15:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:09:14 --> CSRF cookie sent
INFO - 2024-12-10 15:09:14 --> Input Class Initialized
INFO - 2024-12-10 15:09:14 --> Language Class Initialized
INFO - 2024-12-10 15:09:14 --> Loader Class Initialized
INFO - 2024-12-10 15:09:14 --> Helper loaded: url_helper
INFO - 2024-12-10 15:09:14 --> Helper loaded: form_helper
INFO - 2024-12-10 15:09:14 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:09:14 --> Form Validation Class Initialized
INFO - 2024-12-10 15:09:14 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:09:14 --> Controller Class Initialized
INFO - 2024-12-10 15:09:14 --> Model "User_model" initialized
INFO - 2024-12-10 15:09:14 --> Model "Category_model" initialized
INFO - 2024-12-10 15:09:14 --> Model "Review_model" initialized
INFO - 2024-12-10 15:09:14 --> Model "News_model" initialized
INFO - 2024-12-10 15:09:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:09:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:09:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:09:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-10 15:09:14 --> Final output sent to browser
DEBUG - 2024-12-10 15:09:14 --> Total execution time: 0.0542
INFO - 2024-12-10 15:15:24 --> Config Class Initialized
INFO - 2024-12-10 15:15:24 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:15:24 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:15:24 --> Utf8 Class Initialized
INFO - 2024-12-10 15:15:24 --> URI Class Initialized
INFO - 2024-12-10 15:15:24 --> Router Class Initialized
INFO - 2024-12-10 15:15:24 --> Output Class Initialized
INFO - 2024-12-10 15:15:24 --> Security Class Initialized
DEBUG - 2024-12-10 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:15:24 --> CSRF cookie sent
INFO - 2024-12-10 15:15:24 --> Input Class Initialized
INFO - 2024-12-10 15:15:24 --> Language Class Initialized
INFO - 2024-12-10 15:15:24 --> Loader Class Initialized
INFO - 2024-12-10 15:15:24 --> Helper loaded: url_helper
INFO - 2024-12-10 15:15:24 --> Helper loaded: form_helper
INFO - 2024-12-10 15:15:24 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:15:24 --> Form Validation Class Initialized
INFO - 2024-12-10 15:15:24 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:15:24 --> Controller Class Initialized
INFO - 2024-12-10 15:15:24 --> Model "Review_model" initialized
INFO - 2024-12-10 15:15:24 --> Model "Category_model" initialized
INFO - 2024-12-10 15:15:24 --> Model "User_model" initialized
INFO - 2024-12-10 15:15:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:15:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:15:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:15:24 --> Final output sent to browser
DEBUG - 2024-12-10 15:15:24 --> Total execution time: 0.0586
INFO - 2024-12-10 15:25:08 --> Config Class Initialized
INFO - 2024-12-10 15:25:08 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:25:08 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:25:08 --> Utf8 Class Initialized
INFO - 2024-12-10 15:25:08 --> URI Class Initialized
INFO - 2024-12-10 15:25:08 --> Router Class Initialized
INFO - 2024-12-10 15:25:08 --> Output Class Initialized
INFO - 2024-12-10 15:25:08 --> Security Class Initialized
DEBUG - 2024-12-10 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:25:08 --> CSRF cookie sent
INFO - 2024-12-10 15:25:08 --> Input Class Initialized
INFO - 2024-12-10 15:25:08 --> Language Class Initialized
INFO - 2024-12-10 15:25:08 --> Loader Class Initialized
INFO - 2024-12-10 15:25:08 --> Helper loaded: url_helper
INFO - 2024-12-10 15:25:08 --> Helper loaded: form_helper
INFO - 2024-12-10 15:25:08 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:25:08 --> Form Validation Class Initialized
INFO - 2024-12-10 15:25:08 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:25:08 --> Controller Class Initialized
INFO - 2024-12-10 15:25:08 --> Model "Review_model" initialized
INFO - 2024-12-10 15:25:08 --> Model "Category_model" initialized
INFO - 2024-12-10 15:25:08 --> Model "User_model" initialized
INFO - 2024-12-10 15:25:08 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:25:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:25:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-10 15:25:08 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\CAMA\Culinary\application\views\admin\pengguna.php 103
ERROR - 2024-12-10 15:25:08 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\CAMA\Culinary\application\views\admin\pengguna.php 104
INFO - 2024-12-10 15:25:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:25:08 --> Final output sent to browser
DEBUG - 2024-12-10 15:25:08 --> Total execution time: 0.0907
INFO - 2024-12-10 15:28:10 --> Config Class Initialized
INFO - 2024-12-10 15:28:10 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:28:10 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:28:10 --> Utf8 Class Initialized
INFO - 2024-12-10 15:28:10 --> URI Class Initialized
INFO - 2024-12-10 15:28:10 --> Router Class Initialized
INFO - 2024-12-10 15:28:10 --> Output Class Initialized
INFO - 2024-12-10 15:28:10 --> Security Class Initialized
DEBUG - 2024-12-10 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:28:10 --> CSRF cookie sent
INFO - 2024-12-10 15:28:10 --> Input Class Initialized
INFO - 2024-12-10 15:28:10 --> Language Class Initialized
INFO - 2024-12-10 15:28:10 --> Loader Class Initialized
INFO - 2024-12-10 15:28:10 --> Helper loaded: url_helper
INFO - 2024-12-10 15:28:10 --> Helper loaded: form_helper
INFO - 2024-12-10 15:28:10 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:28:10 --> Form Validation Class Initialized
INFO - 2024-12-10 15:28:10 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:28:10 --> Controller Class Initialized
INFO - 2024-12-10 15:28:10 --> Model "Review_model" initialized
INFO - 2024-12-10 15:28:10 --> Model "Category_model" initialized
INFO - 2024-12-10 15:28:10 --> Model "User_model" initialized
INFO - 2024-12-10 15:28:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:28:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:28:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:28:10 --> Final output sent to browser
DEBUG - 2024-12-10 15:28:10 --> Total execution time: 0.1107
INFO - 2024-12-10 15:30:22 --> Config Class Initialized
INFO - 2024-12-10 15:30:22 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:30:22 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:30:22 --> Utf8 Class Initialized
INFO - 2024-12-10 15:30:22 --> URI Class Initialized
INFO - 2024-12-10 15:30:22 --> Router Class Initialized
INFO - 2024-12-10 15:30:22 --> Output Class Initialized
INFO - 2024-12-10 15:30:22 --> Security Class Initialized
DEBUG - 2024-12-10 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:30:22 --> CSRF cookie sent
INFO - 2024-12-10 15:30:22 --> Input Class Initialized
INFO - 2024-12-10 15:30:22 --> Language Class Initialized
INFO - 2024-12-10 15:30:22 --> Loader Class Initialized
INFO - 2024-12-10 15:30:22 --> Helper loaded: url_helper
INFO - 2024-12-10 15:30:22 --> Helper loaded: form_helper
INFO - 2024-12-10 15:30:22 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:30:22 --> Form Validation Class Initialized
INFO - 2024-12-10 15:30:22 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:30:22 --> Controller Class Initialized
INFO - 2024-12-10 15:30:22 --> Model "Review_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "Category_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "User_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:30:22 --> User data with ID 3 successfully deleted.
INFO - 2024-12-10 15:30:22 --> Config Class Initialized
INFO - 2024-12-10 15:30:22 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:30:22 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:30:22 --> Utf8 Class Initialized
INFO - 2024-12-10 15:30:22 --> URI Class Initialized
INFO - 2024-12-10 15:30:22 --> Router Class Initialized
INFO - 2024-12-10 15:30:22 --> Output Class Initialized
INFO - 2024-12-10 15:30:22 --> Security Class Initialized
DEBUG - 2024-12-10 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:30:22 --> CSRF cookie sent
INFO - 2024-12-10 15:30:22 --> Input Class Initialized
INFO - 2024-12-10 15:30:22 --> Language Class Initialized
INFO - 2024-12-10 15:30:22 --> Loader Class Initialized
INFO - 2024-12-10 15:30:22 --> Helper loaded: url_helper
INFO - 2024-12-10 15:30:22 --> Helper loaded: form_helper
INFO - 2024-12-10 15:30:22 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:30:22 --> Form Validation Class Initialized
INFO - 2024-12-10 15:30:22 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:30:22 --> Controller Class Initialized
INFO - 2024-12-10 15:30:22 --> Model "Review_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "Category_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "User_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:30:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:30:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:30:22 --> Final output sent to browser
DEBUG - 2024-12-10 15:30:22 --> Total execution time: 0.0766
INFO - 2024-12-10 15:32:24 --> Config Class Initialized
INFO - 2024-12-10 15:32:24 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:32:24 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:32:24 --> Utf8 Class Initialized
INFO - 2024-12-10 15:32:24 --> URI Class Initialized
INFO - 2024-12-10 15:32:24 --> Router Class Initialized
INFO - 2024-12-10 15:32:24 --> Output Class Initialized
INFO - 2024-12-10 15:32:24 --> Security Class Initialized
DEBUG - 2024-12-10 15:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:32:24 --> CSRF cookie sent
INFO - 2024-12-10 15:32:24 --> Input Class Initialized
INFO - 2024-12-10 15:32:24 --> Language Class Initialized
INFO - 2024-12-10 15:32:24 --> Loader Class Initialized
INFO - 2024-12-10 15:32:24 --> Helper loaded: url_helper
INFO - 2024-12-10 15:32:24 --> Helper loaded: form_helper
INFO - 2024-12-10 15:32:24 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:32:24 --> Form Validation Class Initialized
INFO - 2024-12-10 15:32:24 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:32:24 --> Controller Class Initialized
INFO - 2024-12-10 15:32:24 --> Model "Review_model" initialized
INFO - 2024-12-10 15:32:24 --> Model "Category_model" initialized
INFO - 2024-12-10 15:32:24 --> Model "User_model" initialized
INFO - 2024-12-10 15:32:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:32:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:32:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:32:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-10 15:32:24 --> Final output sent to browser
DEBUG - 2024-12-10 15:32:24 --> Total execution time: 0.0458
INFO - 2024-12-10 15:35:30 --> Config Class Initialized
INFO - 2024-12-10 15:35:30 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:30 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:30 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:30 --> URI Class Initialized
INFO - 2024-12-10 15:35:30 --> Router Class Initialized
INFO - 2024-12-10 15:35:30 --> Output Class Initialized
INFO - 2024-12-10 15:35:30 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:30 --> CSRF cookie sent
INFO - 2024-12-10 15:35:30 --> Input Class Initialized
INFO - 2024-12-10 15:35:30 --> Language Class Initialized
INFO - 2024-12-10 15:35:30 --> Loader Class Initialized
INFO - 2024-12-10 15:35:30 --> Helper loaded: url_helper
INFO - 2024-12-10 15:35:30 --> Helper loaded: form_helper
INFO - 2024-12-10 15:35:30 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:35:30 --> Form Validation Class Initialized
INFO - 2024-12-10 15:35:30 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:35:30 --> Controller Class Initialized
INFO - 2024-12-10 15:35:30 --> Model "User_model" initialized
INFO - 2024-12-10 15:35:30 --> Model "Category_model" initialized
INFO - 2024-12-10 15:35:30 --> Model "Review_model" initialized
INFO - 2024-12-10 15:35:30 --> Model "News_model" initialized
INFO - 2024-12-10 15:35:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:35:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:35:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:35:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:35:30 --> Final output sent to browser
DEBUG - 2024-12-10 15:35:30 --> Total execution time: 0.0589
INFO - 2024-12-10 15:35:37 --> Config Class Initialized
INFO - 2024-12-10 15:35:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:37 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:37 --> URI Class Initialized
INFO - 2024-12-10 15:35:37 --> Router Class Initialized
INFO - 2024-12-10 15:35:37 --> Output Class Initialized
INFO - 2024-12-10 15:35:37 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:37 --> CSRF cookie sent
INFO - 2024-12-10 15:35:37 --> CSRF token verified
INFO - 2024-12-10 15:35:37 --> Input Class Initialized
INFO - 2024-12-10 15:35:37 --> Language Class Initialized
INFO - 2024-12-10 15:35:37 --> Loader Class Initialized
INFO - 2024-12-10 15:35:37 --> Helper loaded: url_helper
INFO - 2024-12-10 15:35:37 --> Helper loaded: form_helper
INFO - 2024-12-10 15:35:37 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:35:37 --> Form Validation Class Initialized
INFO - 2024-12-10 15:35:37 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:35:37 --> Controller Class Initialized
INFO - 2024-12-10 15:35:37 --> Model "User_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "Category_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "Review_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "News_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:35:37 --> Config Class Initialized
INFO - 2024-12-10 15:35:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:37 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:37 --> URI Class Initialized
INFO - 2024-12-10 15:35:37 --> Router Class Initialized
INFO - 2024-12-10 15:35:37 --> Output Class Initialized
INFO - 2024-12-10 15:35:37 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:37 --> CSRF cookie sent
INFO - 2024-12-10 15:35:37 --> Input Class Initialized
INFO - 2024-12-10 15:35:37 --> Language Class Initialized
INFO - 2024-12-10 15:35:37 --> Loader Class Initialized
INFO - 2024-12-10 15:35:37 --> Helper loaded: url_helper
INFO - 2024-12-10 15:35:37 --> Helper loaded: form_helper
INFO - 2024-12-10 15:35:37 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:35:37 --> Form Validation Class Initialized
INFO - 2024-12-10 15:35:37 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:35:37 --> Controller Class Initialized
INFO - 2024-12-10 15:35:37 --> Model "Review_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "Category_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "User_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:35:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 15:35:37 --> Query result: stdClass Object
(
    [view_count] => 113
)

INFO - 2024-12-10 15:35:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-10 15:35:37 --> Final output sent to browser
DEBUG - 2024-12-10 15:35:37 --> Total execution time: 0.0697
INFO - 2024-12-10 15:35:41 --> Config Class Initialized
INFO - 2024-12-10 15:35:41 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:41 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:41 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:41 --> URI Class Initialized
INFO - 2024-12-10 15:35:41 --> Router Class Initialized
INFO - 2024-12-10 15:35:41 --> Output Class Initialized
INFO - 2024-12-10 15:35:41 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:41 --> CSRF cookie sent
INFO - 2024-12-10 15:35:41 --> Input Class Initialized
INFO - 2024-12-10 15:35:41 --> Language Class Initialized
INFO - 2024-12-10 15:35:41 --> Loader Class Initialized
INFO - 2024-12-10 15:35:41 --> Helper loaded: url_helper
INFO - 2024-12-10 15:35:41 --> Helper loaded: form_helper
INFO - 2024-12-10 15:35:41 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:35:41 --> Form Validation Class Initialized
INFO - 2024-12-10 15:35:41 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:35:41 --> Controller Class Initialized
INFO - 2024-12-10 15:35:41 --> Model "User_model" initialized
INFO - 2024-12-10 15:35:41 --> Model "Category_model" initialized
INFO - 2024-12-10 15:35:41 --> Model "Review_model" initialized
INFO - 2024-12-10 15:35:41 --> Model "News_model" initialized
INFO - 2024-12-10 15:35:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:35:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:35:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:35:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:35:41 --> Final output sent to browser
DEBUG - 2024-12-10 15:35:41 --> Total execution time: 0.0441
INFO - 2024-12-10 15:35:44 --> Config Class Initialized
INFO - 2024-12-10 15:35:44 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:44 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:44 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:44 --> URI Class Initialized
INFO - 2024-12-10 15:35:44 --> Router Class Initialized
INFO - 2024-12-10 15:35:44 --> Output Class Initialized
INFO - 2024-12-10 15:35:44 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:44 --> CSRF cookie sent
INFO - 2024-12-10 15:35:44 --> Input Class Initialized
INFO - 2024-12-10 15:35:44 --> Language Class Initialized
INFO - 2024-12-10 15:35:44 --> Loader Class Initialized
INFO - 2024-12-10 15:35:44 --> Helper loaded: url_helper
INFO - 2024-12-10 15:35:44 --> Helper loaded: form_helper
INFO - 2024-12-10 15:35:44 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:35:44 --> Form Validation Class Initialized
INFO - 2024-12-10 15:35:44 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:35:44 --> Controller Class Initialized
INFO - 2024-12-10 15:35:44 --> Model "User_model" initialized
INFO - 2024-12-10 15:35:44 --> Model "Category_model" initialized
INFO - 2024-12-10 15:35:44 --> Model "Review_model" initialized
INFO - 2024-12-10 15:35:44 --> Model "News_model" initialized
INFO - 2024-12-10 15:35:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 15:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:35:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:35:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:35:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-10 15:35:44 --> Final output sent to browser
DEBUG - 2024-12-10 15:35:44 --> Total execution time: 0.0536
INFO - 2024-12-10 15:35:47 --> Config Class Initialized
INFO - 2024-12-10 15:35:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:47 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:47 --> URI Class Initialized
INFO - 2024-12-10 15:35:47 --> Router Class Initialized
INFO - 2024-12-10 15:35:47 --> Output Class Initialized
INFO - 2024-12-10 15:35:47 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:47 --> CSRF cookie sent
INFO - 2024-12-10 15:35:47 --> Input Class Initialized
INFO - 2024-12-10 15:35:47 --> Language Class Initialized
INFO - 2024-12-10 15:35:47 --> Loader Class Initialized
INFO - 2024-12-10 15:35:47 --> Helper loaded: url_helper
INFO - 2024-12-10 15:35:47 --> Helper loaded: form_helper
INFO - 2024-12-10 15:35:47 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:35:47 --> Form Validation Class Initialized
INFO - 2024-12-10 15:35:47 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:35:47 --> Controller Class Initialized
INFO - 2024-12-10 15:35:47 --> Model "User_model" initialized
INFO - 2024-12-10 15:35:47 --> Model "Category_model" initialized
INFO - 2024-12-10 15:35:47 --> Model "Review_model" initialized
INFO - 2024-12-10 15:35:47 --> Model "News_model" initialized
INFO - 2024-12-10 15:35:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:35:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:35:47 --> Final output sent to browser
DEBUG - 2024-12-10 15:35:47 --> Total execution time: 0.0467
INFO - 2024-12-10 15:35:49 --> Config Class Initialized
INFO - 2024-12-10 15:35:49 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:35:49 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:35:49 --> Utf8 Class Initialized
INFO - 2024-12-10 15:35:49 --> URI Class Initialized
INFO - 2024-12-10 15:35:49 --> Router Class Initialized
INFO - 2024-12-10 15:35:49 --> Output Class Initialized
INFO - 2024-12-10 15:35:49 --> Security Class Initialized
DEBUG - 2024-12-10 15:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:35:49 --> CSRF cookie sent
INFO - 2024-12-10 15:35:49 --> Input Class Initialized
INFO - 2024-12-10 15:35:49 --> Language Class Initialized
ERROR - 2024-12-10 15:35:49 --> 404 Page Not Found: Culinary/reset_password
INFO - 2024-12-10 15:42:07 --> Config Class Initialized
INFO - 2024-12-10 15:42:07 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:42:07 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:42:07 --> Utf8 Class Initialized
INFO - 2024-12-10 15:42:07 --> URI Class Initialized
INFO - 2024-12-10 15:42:07 --> Router Class Initialized
INFO - 2024-12-10 15:42:07 --> Output Class Initialized
INFO - 2024-12-10 15:42:07 --> Security Class Initialized
DEBUG - 2024-12-10 15:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:42:07 --> CSRF cookie sent
INFO - 2024-12-10 15:42:07 --> Input Class Initialized
INFO - 2024-12-10 15:42:07 --> Language Class Initialized
INFO - 2024-12-10 15:42:07 --> Loader Class Initialized
INFO - 2024-12-10 15:42:07 --> Helper loaded: url_helper
INFO - 2024-12-10 15:42:07 --> Helper loaded: form_helper
INFO - 2024-12-10 15:42:07 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:42:07 --> Form Validation Class Initialized
INFO - 2024-12-10 15:42:07 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:42:07 --> Controller Class Initialized
INFO - 2024-12-10 15:42:07 --> Model "User_model" initialized
INFO - 2024-12-10 15:42:07 --> Model "Category_model" initialized
INFO - 2024-12-10 15:42:07 --> Model "Review_model" initialized
INFO - 2024-12-10 15:42:07 --> Model "News_model" initialized
INFO - 2024-12-10 15:42:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:42:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:42:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:42:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:42:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:42:07 --> Final output sent to browser
DEBUG - 2024-12-10 15:42:07 --> Total execution time: 0.0982
INFO - 2024-12-10 15:42:10 --> Config Class Initialized
INFO - 2024-12-10 15:42:10 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:42:10 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:42:10 --> Utf8 Class Initialized
INFO - 2024-12-10 15:42:10 --> URI Class Initialized
INFO - 2024-12-10 15:42:10 --> Router Class Initialized
INFO - 2024-12-10 15:42:10 --> Output Class Initialized
INFO - 2024-12-10 15:42:10 --> Security Class Initialized
DEBUG - 2024-12-10 15:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:42:10 --> CSRF cookie sent
INFO - 2024-12-10 15:42:10 --> Input Class Initialized
INFO - 2024-12-10 15:42:10 --> Language Class Initialized
INFO - 2024-12-10 15:42:10 --> Loader Class Initialized
INFO - 2024-12-10 15:42:10 --> Helper loaded: url_helper
INFO - 2024-12-10 15:42:10 --> Helper loaded: form_helper
INFO - 2024-12-10 15:42:10 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:42:10 --> Form Validation Class Initialized
INFO - 2024-12-10 15:42:10 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:42:10 --> Controller Class Initialized
INFO - 2024-12-10 15:42:10 --> Model "User_model" initialized
INFO - 2024-12-10 15:42:10 --> Model "Category_model" initialized
INFO - 2024-12-10 15:42:10 --> Model "Review_model" initialized
INFO - 2024-12-10 15:42:10 --> Model "News_model" initialized
INFO - 2024-12-10 15:42:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:42:12 --> Config Class Initialized
INFO - 2024-12-10 15:42:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:42:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:42:12 --> Utf8 Class Initialized
INFO - 2024-12-10 15:42:12 --> URI Class Initialized
INFO - 2024-12-10 15:42:12 --> Router Class Initialized
INFO - 2024-12-10 15:42:12 --> Output Class Initialized
INFO - 2024-12-10 15:42:12 --> Security Class Initialized
DEBUG - 2024-12-10 15:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:42:12 --> CSRF cookie sent
INFO - 2024-12-10 15:42:12 --> Input Class Initialized
INFO - 2024-12-10 15:42:12 --> Language Class Initialized
INFO - 2024-12-10 15:42:12 --> Loader Class Initialized
INFO - 2024-12-10 15:42:12 --> Helper loaded: url_helper
INFO - 2024-12-10 15:42:12 --> Helper loaded: form_helper
INFO - 2024-12-10 15:42:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:42:12 --> Form Validation Class Initialized
INFO - 2024-12-10 15:42:12 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:42:12 --> Controller Class Initialized
INFO - 2024-12-10 15:42:12 --> Model "User_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "Category_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "Review_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "News_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:42:12 --> Config Class Initialized
INFO - 2024-12-10 15:42:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:42:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:42:12 --> Utf8 Class Initialized
INFO - 2024-12-10 15:42:12 --> URI Class Initialized
INFO - 2024-12-10 15:42:12 --> Router Class Initialized
INFO - 2024-12-10 15:42:12 --> Output Class Initialized
INFO - 2024-12-10 15:42:12 --> Security Class Initialized
DEBUG - 2024-12-10 15:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:42:12 --> CSRF cookie sent
INFO - 2024-12-10 15:42:12 --> Input Class Initialized
INFO - 2024-12-10 15:42:12 --> Language Class Initialized
INFO - 2024-12-10 15:42:12 --> Loader Class Initialized
INFO - 2024-12-10 15:42:12 --> Helper loaded: url_helper
INFO - 2024-12-10 15:42:12 --> Helper loaded: form_helper
INFO - 2024-12-10 15:42:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:42:12 --> Form Validation Class Initialized
INFO - 2024-12-10 15:42:12 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:42:12 --> Controller Class Initialized
INFO - 2024-12-10 15:42:12 --> Model "User_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "Category_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "Review_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "News_model" initialized
INFO - 2024-12-10 15:42:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:42:13 --> Config Class Initialized
INFO - 2024-12-10 15:42:13 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:42:13 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:42:13 --> Utf8 Class Initialized
INFO - 2024-12-10 15:42:13 --> URI Class Initialized
INFO - 2024-12-10 15:42:13 --> Router Class Initialized
INFO - 2024-12-10 15:42:13 --> Output Class Initialized
INFO - 2024-12-10 15:42:13 --> Security Class Initialized
DEBUG - 2024-12-10 15:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:42:13 --> CSRF cookie sent
INFO - 2024-12-10 15:42:13 --> Input Class Initialized
INFO - 2024-12-10 15:42:13 --> Language Class Initialized
INFO - 2024-12-10 15:42:13 --> Loader Class Initialized
INFO - 2024-12-10 15:42:13 --> Helper loaded: url_helper
INFO - 2024-12-10 15:42:13 --> Helper loaded: form_helper
INFO - 2024-12-10 15:42:13 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:42:13 --> Form Validation Class Initialized
INFO - 2024-12-10 15:42:13 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:42:13 --> Controller Class Initialized
INFO - 2024-12-10 15:42:13 --> Model "User_model" initialized
INFO - 2024-12-10 15:42:13 --> Model "Category_model" initialized
INFO - 2024-12-10 15:42:13 --> Model "Review_model" initialized
INFO - 2024-12-10 15:42:13 --> Model "News_model" initialized
INFO - 2024-12-10 15:42:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:43:18 --> Config Class Initialized
INFO - 2024-12-10 15:43:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:43:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:43:18 --> Utf8 Class Initialized
INFO - 2024-12-10 15:43:18 --> URI Class Initialized
INFO - 2024-12-10 15:43:18 --> Router Class Initialized
INFO - 2024-12-10 15:43:18 --> Output Class Initialized
INFO - 2024-12-10 15:43:18 --> Security Class Initialized
DEBUG - 2024-12-10 15:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:43:18 --> CSRF cookie sent
INFO - 2024-12-10 15:43:18 --> Input Class Initialized
INFO - 2024-12-10 15:43:18 --> Language Class Initialized
INFO - 2024-12-10 15:43:18 --> Loader Class Initialized
INFO - 2024-12-10 15:43:18 --> Helper loaded: url_helper
INFO - 2024-12-10 15:43:18 --> Helper loaded: form_helper
INFO - 2024-12-10 15:43:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:43:18 --> Form Validation Class Initialized
INFO - 2024-12-10 15:43:18 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:43:18 --> Controller Class Initialized
INFO - 2024-12-10 15:43:18 --> Model "User_model" initialized
INFO - 2024-12-10 15:43:18 --> Model "Category_model" initialized
INFO - 2024-12-10 15:43:18 --> Model "Review_model" initialized
INFO - 2024-12-10 15:43:18 --> Model "News_model" initialized
INFO - 2024-12-10 15:43:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:43:19 --> Config Class Initialized
INFO - 2024-12-10 15:43:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:43:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:43:19 --> Utf8 Class Initialized
INFO - 2024-12-10 15:43:19 --> URI Class Initialized
INFO - 2024-12-10 15:43:19 --> Router Class Initialized
INFO - 2024-12-10 15:43:19 --> Output Class Initialized
INFO - 2024-12-10 15:43:19 --> Security Class Initialized
DEBUG - 2024-12-10 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:43:19 --> CSRF cookie sent
INFO - 2024-12-10 15:43:19 --> Input Class Initialized
INFO - 2024-12-10 15:43:19 --> Language Class Initialized
INFO - 2024-12-10 15:43:19 --> Loader Class Initialized
INFO - 2024-12-10 15:43:19 --> Helper loaded: url_helper
INFO - 2024-12-10 15:43:19 --> Helper loaded: form_helper
INFO - 2024-12-10 15:43:19 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:43:19 --> Form Validation Class Initialized
INFO - 2024-12-10 15:43:19 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:43:19 --> Controller Class Initialized
INFO - 2024-12-10 15:43:19 --> Model "User_model" initialized
INFO - 2024-12-10 15:43:19 --> Model "Category_model" initialized
INFO - 2024-12-10 15:43:19 --> Model "Review_model" initialized
INFO - 2024-12-10 15:43:19 --> Model "News_model" initialized
INFO - 2024-12-10 15:43:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:43:20 --> Config Class Initialized
INFO - 2024-12-10 15:43:20 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:43:20 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:43:20 --> Utf8 Class Initialized
INFO - 2024-12-10 15:43:20 --> URI Class Initialized
INFO - 2024-12-10 15:43:20 --> Router Class Initialized
INFO - 2024-12-10 15:43:20 --> Output Class Initialized
INFO - 2024-12-10 15:43:20 --> Security Class Initialized
DEBUG - 2024-12-10 15:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:43:20 --> CSRF cookie sent
INFO - 2024-12-10 15:43:20 --> Input Class Initialized
INFO - 2024-12-10 15:43:20 --> Language Class Initialized
INFO - 2024-12-10 15:43:20 --> Loader Class Initialized
INFO - 2024-12-10 15:43:20 --> Helper loaded: url_helper
INFO - 2024-12-10 15:43:20 --> Helper loaded: form_helper
INFO - 2024-12-10 15:43:20 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:43:20 --> Form Validation Class Initialized
INFO - 2024-12-10 15:43:20 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:43:20 --> Controller Class Initialized
INFO - 2024-12-10 15:43:20 --> Model "User_model" initialized
INFO - 2024-12-10 15:43:20 --> Model "Category_model" initialized
INFO - 2024-12-10 15:43:20 --> Model "Review_model" initialized
INFO - 2024-12-10 15:43:20 --> Model "News_model" initialized
INFO - 2024-12-10 15:43:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:43:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:43:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:43:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:43:20 --> Final output sent to browser
DEBUG - 2024-12-10 15:43:20 --> Total execution time: 0.0465
INFO - 2024-12-10 15:43:22 --> Config Class Initialized
INFO - 2024-12-10 15:43:22 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:43:22 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:43:22 --> Utf8 Class Initialized
INFO - 2024-12-10 15:43:22 --> URI Class Initialized
INFO - 2024-12-10 15:43:22 --> Router Class Initialized
INFO - 2024-12-10 15:43:22 --> Output Class Initialized
INFO - 2024-12-10 15:43:22 --> Security Class Initialized
DEBUG - 2024-12-10 15:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:43:22 --> CSRF cookie sent
INFO - 2024-12-10 15:43:22 --> Input Class Initialized
INFO - 2024-12-10 15:43:22 --> Language Class Initialized
INFO - 2024-12-10 15:43:22 --> Loader Class Initialized
INFO - 2024-12-10 15:43:22 --> Helper loaded: url_helper
INFO - 2024-12-10 15:43:22 --> Helper loaded: form_helper
INFO - 2024-12-10 15:43:22 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:43:22 --> Form Validation Class Initialized
INFO - 2024-12-10 15:43:22 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:43:22 --> Controller Class Initialized
INFO - 2024-12-10 15:43:22 --> Model "User_model" initialized
INFO - 2024-12-10 15:43:22 --> Model "Category_model" initialized
INFO - 2024-12-10 15:43:22 --> Model "Review_model" initialized
INFO - 2024-12-10 15:43:22 --> Model "News_model" initialized
INFO - 2024-12-10 15:43:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:43:24 --> Config Class Initialized
INFO - 2024-12-10 15:43:24 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:43:24 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:43:24 --> Utf8 Class Initialized
INFO - 2024-12-10 15:43:24 --> URI Class Initialized
INFO - 2024-12-10 15:43:24 --> Router Class Initialized
INFO - 2024-12-10 15:43:24 --> Output Class Initialized
INFO - 2024-12-10 15:43:24 --> Security Class Initialized
DEBUG - 2024-12-10 15:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:43:24 --> CSRF cookie sent
INFO - 2024-12-10 15:43:24 --> Input Class Initialized
INFO - 2024-12-10 15:43:24 --> Language Class Initialized
INFO - 2024-12-10 15:43:24 --> Loader Class Initialized
INFO - 2024-12-10 15:43:24 --> Helper loaded: url_helper
INFO - 2024-12-10 15:43:24 --> Helper loaded: form_helper
INFO - 2024-12-10 15:43:24 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:43:24 --> Form Validation Class Initialized
INFO - 2024-12-10 15:43:24 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:43:24 --> Controller Class Initialized
INFO - 2024-12-10 15:43:24 --> Model "User_model" initialized
INFO - 2024-12-10 15:43:24 --> Model "Category_model" initialized
INFO - 2024-12-10 15:43:24 --> Model "Review_model" initialized
INFO - 2024-12-10 15:43:24 --> Model "News_model" initialized
INFO - 2024-12-10 15:43:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:16 --> Config Class Initialized
INFO - 2024-12-10 15:47:16 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:16 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:16 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:16 --> URI Class Initialized
INFO - 2024-12-10 15:47:16 --> Router Class Initialized
INFO - 2024-12-10 15:47:16 --> Output Class Initialized
INFO - 2024-12-10 15:47:16 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:16 --> CSRF cookie sent
INFO - 2024-12-10 15:47:16 --> Input Class Initialized
INFO - 2024-12-10 15:47:16 --> Language Class Initialized
INFO - 2024-12-10 15:47:16 --> Loader Class Initialized
INFO - 2024-12-10 15:47:16 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:16 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:16 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:16 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:16 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:16 --> Controller Class Initialized
INFO - 2024-12-10 15:47:16 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:16 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:16 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:16 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:47:16 --> Final output sent to browser
DEBUG - 2024-12-10 15:47:16 --> Total execution time: 0.0617
INFO - 2024-12-10 15:47:25 --> Config Class Initialized
INFO - 2024-12-10 15:47:25 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:25 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:25 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:25 --> URI Class Initialized
INFO - 2024-12-10 15:47:25 --> Router Class Initialized
INFO - 2024-12-10 15:47:25 --> Output Class Initialized
INFO - 2024-12-10 15:47:25 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:25 --> CSRF cookie sent
INFO - 2024-12-10 15:47:25 --> CSRF token verified
INFO - 2024-12-10 15:47:25 --> Input Class Initialized
INFO - 2024-12-10 15:47:25 --> Language Class Initialized
INFO - 2024-12-10 15:47:25 --> Loader Class Initialized
INFO - 2024-12-10 15:47:25 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:25 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:25 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:25 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:25 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:25 --> Controller Class Initialized
INFO - 2024-12-10 15:47:25 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:25 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:25 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:25 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-10 15:47:25 --> Query error: Unknown column 'reset_token' in 'field list' - Invalid query: UPDATE `users` SET `reset_token` = '5470f8dc3a052fce2f4e920f96b03c19f869ca8c34135a9c48ce26fc3176393e', `token_created_at` = '2024-12-10 15:47:25'
WHERE `email` = 'aldisar2000@gmail.com'
INFO - 2024-12-10 15:47:25 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-10 15:47:28 --> Config Class Initialized
INFO - 2024-12-10 15:47:28 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:28 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:28 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:28 --> URI Class Initialized
INFO - 2024-12-10 15:47:28 --> Router Class Initialized
INFO - 2024-12-10 15:47:28 --> Output Class Initialized
INFO - 2024-12-10 15:47:28 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:28 --> CSRF cookie sent
INFO - 2024-12-10 15:47:28 --> Input Class Initialized
INFO - 2024-12-10 15:47:28 --> Language Class Initialized
INFO - 2024-12-10 15:47:28 --> Loader Class Initialized
INFO - 2024-12-10 15:47:28 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:28 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:28 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:29 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:29 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:29 --> Controller Class Initialized
INFO - 2024-12-10 15:47:29 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:29 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:29 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:29 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:47:29 --> Final output sent to browser
DEBUG - 2024-12-10 15:47:29 --> Total execution time: 0.0719
INFO - 2024-12-10 15:47:45 --> Config Class Initialized
INFO - 2024-12-10 15:47:45 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:45 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:45 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:45 --> URI Class Initialized
INFO - 2024-12-10 15:47:45 --> Router Class Initialized
INFO - 2024-12-10 15:47:45 --> Output Class Initialized
INFO - 2024-12-10 15:47:45 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:45 --> CSRF cookie sent
INFO - 2024-12-10 15:47:45 --> Input Class Initialized
INFO - 2024-12-10 15:47:45 --> Language Class Initialized
INFO - 2024-12-10 15:47:45 --> Loader Class Initialized
INFO - 2024-12-10 15:47:45 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:45 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:45 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:45 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:45 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:45 --> Controller Class Initialized
INFO - 2024-12-10 15:47:45 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:45 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:45 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:45 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:47:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:47:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:47:45 --> Final output sent to browser
DEBUG - 2024-12-10 15:47:45 --> Total execution time: 0.0534
INFO - 2024-12-10 15:47:48 --> Config Class Initialized
INFO - 2024-12-10 15:47:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:48 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:48 --> URI Class Initialized
INFO - 2024-12-10 15:47:48 --> Router Class Initialized
INFO - 2024-12-10 15:47:48 --> Output Class Initialized
INFO - 2024-12-10 15:47:48 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:48 --> CSRF cookie sent
INFO - 2024-12-10 15:47:48 --> CSRF token verified
INFO - 2024-12-10 15:47:48 --> Input Class Initialized
INFO - 2024-12-10 15:47:48 --> Language Class Initialized
INFO - 2024-12-10 15:47:48 --> Loader Class Initialized
INFO - 2024-12-10 15:47:48 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:48 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:48 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:48 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:48 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:48 --> Controller Class Initialized
INFO - 2024-12-10 15:47:48 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:48 --> Config Class Initialized
INFO - 2024-12-10 15:47:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:48 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:48 --> URI Class Initialized
INFO - 2024-12-10 15:47:48 --> Router Class Initialized
INFO - 2024-12-10 15:47:48 --> Output Class Initialized
INFO - 2024-12-10 15:47:48 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:48 --> CSRF cookie sent
INFO - 2024-12-10 15:47:48 --> Input Class Initialized
INFO - 2024-12-10 15:47:48 --> Language Class Initialized
INFO - 2024-12-10 15:47:48 --> Loader Class Initialized
INFO - 2024-12-10 15:47:48 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:48 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:48 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:48 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:48 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:48 --> Controller Class Initialized
INFO - 2024-12-10 15:47:48 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-10 15:47:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 15:47:48 --> Query result: stdClass Object
(
    [view_count] => 113
)

INFO - 2024-12-10 15:47:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-10 15:47:48 --> Final output sent to browser
DEBUG - 2024-12-10 15:47:48 --> Total execution time: 0.0542
INFO - 2024-12-10 15:47:53 --> Config Class Initialized
INFO - 2024-12-10 15:47:53 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:53 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:53 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:53 --> URI Class Initialized
INFO - 2024-12-10 15:47:53 --> Router Class Initialized
INFO - 2024-12-10 15:47:53 --> Output Class Initialized
INFO - 2024-12-10 15:47:53 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:53 --> CSRF cookie sent
INFO - 2024-12-10 15:47:53 --> Input Class Initialized
INFO - 2024-12-10 15:47:53 --> Language Class Initialized
INFO - 2024-12-10 15:47:53 --> Loader Class Initialized
INFO - 2024-12-10 15:47:53 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:53 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:53 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:53 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:53 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:53 --> Controller Class Initialized
INFO - 2024-12-10 15:47:53 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:53 --> Config Class Initialized
INFO - 2024-12-10 15:47:53 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:53 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:53 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:53 --> URI Class Initialized
INFO - 2024-12-10 15:47:53 --> Router Class Initialized
INFO - 2024-12-10 15:47:53 --> Output Class Initialized
INFO - 2024-12-10 15:47:53 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:53 --> CSRF cookie sent
INFO - 2024-12-10 15:47:53 --> Input Class Initialized
INFO - 2024-12-10 15:47:53 --> Language Class Initialized
INFO - 2024-12-10 15:47:53 --> Loader Class Initialized
INFO - 2024-12-10 15:47:53 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:53 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:53 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:53 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:53 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:53 --> Controller Class Initialized
INFO - 2024-12-10 15:47:53 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:47:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:47:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:47:53 --> Final output sent to browser
DEBUG - 2024-12-10 15:47:53 --> Total execution time: 0.0457
INFO - 2024-12-10 15:47:57 --> Config Class Initialized
INFO - 2024-12-10 15:47:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:57 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:57 --> URI Class Initialized
INFO - 2024-12-10 15:47:57 --> Router Class Initialized
INFO - 2024-12-10 15:47:57 --> Output Class Initialized
INFO - 2024-12-10 15:47:57 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:57 --> CSRF cookie sent
INFO - 2024-12-10 15:47:57 --> CSRF token verified
INFO - 2024-12-10 15:47:57 --> Input Class Initialized
INFO - 2024-12-10 15:47:57 --> Language Class Initialized
INFO - 2024-12-10 15:47:57 --> Loader Class Initialized
INFO - 2024-12-10 15:47:57 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:57 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:57 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:57 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:57 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:57 --> Controller Class Initialized
INFO - 2024-12-10 15:47:57 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:47:57 --> Config Class Initialized
INFO - 2024-12-10 15:47:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:57 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:57 --> URI Class Initialized
INFO - 2024-12-10 15:47:57 --> Router Class Initialized
INFO - 2024-12-10 15:47:57 --> Output Class Initialized
INFO - 2024-12-10 15:47:57 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:57 --> CSRF cookie sent
INFO - 2024-12-10 15:47:57 --> Input Class Initialized
INFO - 2024-12-10 15:47:57 --> Language Class Initialized
INFO - 2024-12-10 15:47:57 --> Loader Class Initialized
INFO - 2024-12-10 15:47:57 --> Helper loaded: url_helper
INFO - 2024-12-10 15:47:57 --> Helper loaded: form_helper
INFO - 2024-12-10 15:47:57 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:47:57 --> Form Validation Class Initialized
INFO - 2024-12-10 15:47:57 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:47:57 --> Controller Class Initialized
INFO - 2024-12-10 15:47:57 --> Model "User_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "Category_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "Review_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "News_model" initialized
INFO - 2024-12-10 15:47:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 15:47:58 --> Query result: stdClass Object
(
    [view_count] => 114
)

INFO - 2024-12-10 15:47:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:47:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:47:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 15:47:58 --> Final output sent to browser
DEBUG - 2024-12-10 15:47:58 --> Total execution time: 0.2203
INFO - 2024-12-10 15:47:58 --> Config Class Initialized
INFO - 2024-12-10 15:47:58 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:47:58 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:47:58 --> Utf8 Class Initialized
INFO - 2024-12-10 15:47:58 --> URI Class Initialized
INFO - 2024-12-10 15:47:58 --> Router Class Initialized
INFO - 2024-12-10 15:47:58 --> Output Class Initialized
INFO - 2024-12-10 15:47:58 --> Security Class Initialized
DEBUG - 2024-12-10 15:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:47:58 --> CSRF cookie sent
INFO - 2024-12-10 15:47:58 --> Input Class Initialized
INFO - 2024-12-10 15:47:58 --> Language Class Initialized
ERROR - 2024-12-10 15:47:58 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 15:48:03 --> Config Class Initialized
INFO - 2024-12-10 15:48:03 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:48:03 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:48:03 --> Utf8 Class Initialized
INFO - 2024-12-10 15:48:03 --> URI Class Initialized
INFO - 2024-12-10 15:48:03 --> Router Class Initialized
INFO - 2024-12-10 15:48:03 --> Output Class Initialized
INFO - 2024-12-10 15:48:03 --> Security Class Initialized
DEBUG - 2024-12-10 15:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:48:03 --> CSRF cookie sent
INFO - 2024-12-10 15:48:03 --> Input Class Initialized
INFO - 2024-12-10 15:48:03 --> Language Class Initialized
INFO - 2024-12-10 15:48:03 --> Loader Class Initialized
INFO - 2024-12-10 15:48:03 --> Helper loaded: url_helper
INFO - 2024-12-10 15:48:03 --> Helper loaded: form_helper
INFO - 2024-12-10 15:48:03 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:48:03 --> Form Validation Class Initialized
INFO - 2024-12-10 15:48:03 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:48:03 --> Controller Class Initialized
INFO - 2024-12-10 15:48:03 --> Model "User_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "Category_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "Review_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "News_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:48:03 --> Config Class Initialized
INFO - 2024-12-10 15:48:03 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:48:03 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:48:03 --> Utf8 Class Initialized
INFO - 2024-12-10 15:48:03 --> URI Class Initialized
INFO - 2024-12-10 15:48:03 --> Router Class Initialized
INFO - 2024-12-10 15:48:03 --> Output Class Initialized
INFO - 2024-12-10 15:48:03 --> Security Class Initialized
DEBUG - 2024-12-10 15:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:48:03 --> CSRF cookie sent
INFO - 2024-12-10 15:48:03 --> Input Class Initialized
INFO - 2024-12-10 15:48:03 --> Language Class Initialized
INFO - 2024-12-10 15:48:03 --> Loader Class Initialized
INFO - 2024-12-10 15:48:03 --> Helper loaded: url_helper
INFO - 2024-12-10 15:48:03 --> Helper loaded: form_helper
INFO - 2024-12-10 15:48:03 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:48:03 --> Form Validation Class Initialized
INFO - 2024-12-10 15:48:03 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:48:03 --> Controller Class Initialized
INFO - 2024-12-10 15:48:03 --> Model "User_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "Category_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "Review_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "News_model" initialized
INFO - 2024-12-10 15:48:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:48:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 15:48:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 15:48:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 15:48:03 --> Final output sent to browser
DEBUG - 2024-12-10 15:48:03 --> Total execution time: 0.0526
INFO - 2024-12-10 15:48:05 --> Config Class Initialized
INFO - 2024-12-10 15:48:05 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:48:05 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:48:05 --> Utf8 Class Initialized
INFO - 2024-12-10 15:48:05 --> URI Class Initialized
INFO - 2024-12-10 15:48:05 --> Router Class Initialized
INFO - 2024-12-10 15:48:05 --> Output Class Initialized
INFO - 2024-12-10 15:48:05 --> Security Class Initialized
DEBUG - 2024-12-10 15:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:48:05 --> CSRF cookie sent
INFO - 2024-12-10 15:48:05 --> Input Class Initialized
INFO - 2024-12-10 15:48:05 --> Language Class Initialized
INFO - 2024-12-10 15:48:05 --> Loader Class Initialized
INFO - 2024-12-10 15:48:05 --> Helper loaded: url_helper
INFO - 2024-12-10 15:48:05 --> Helper loaded: form_helper
INFO - 2024-12-10 15:48:05 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:48:05 --> Form Validation Class Initialized
INFO - 2024-12-10 15:48:05 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:48:05 --> Controller Class Initialized
INFO - 2024-12-10 15:48:05 --> Model "User_model" initialized
INFO - 2024-12-10 15:48:05 --> Model "Category_model" initialized
INFO - 2024-12-10 15:48:05 --> Model "Review_model" initialized
INFO - 2024-12-10 15:48:05 --> Model "News_model" initialized
INFO - 2024-12-10 15:48:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:48:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:48:05 --> Final output sent to browser
DEBUG - 2024-12-10 15:48:05 --> Total execution time: 0.0601
INFO - 2024-12-10 15:50:17 --> Config Class Initialized
INFO - 2024-12-10 15:50:17 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:50:17 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:50:17 --> Utf8 Class Initialized
INFO - 2024-12-10 15:50:17 --> URI Class Initialized
INFO - 2024-12-10 15:50:17 --> Router Class Initialized
INFO - 2024-12-10 15:50:17 --> Output Class Initialized
INFO - 2024-12-10 15:50:17 --> Security Class Initialized
DEBUG - 2024-12-10 15:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:50:17 --> CSRF cookie sent
INFO - 2024-12-10 15:50:17 --> Input Class Initialized
INFO - 2024-12-10 15:50:17 --> Language Class Initialized
INFO - 2024-12-10 15:50:17 --> Loader Class Initialized
INFO - 2024-12-10 15:50:17 --> Helper loaded: url_helper
INFO - 2024-12-10 15:50:17 --> Helper loaded: form_helper
INFO - 2024-12-10 15:50:17 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:50:17 --> Form Validation Class Initialized
INFO - 2024-12-10 15:50:17 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:50:17 --> Controller Class Initialized
INFO - 2024-12-10 15:50:17 --> Model "User_model" initialized
INFO - 2024-12-10 15:50:17 --> Model "Category_model" initialized
INFO - 2024-12-10 15:50:17 --> Model "Review_model" initialized
INFO - 2024-12-10 15:50:17 --> Model "News_model" initialized
INFO - 2024-12-10 15:50:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:50:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:50:17 --> Final output sent to browser
DEBUG - 2024-12-10 15:50:17 --> Total execution time: 0.0573
INFO - 2024-12-10 15:50:26 --> Config Class Initialized
INFO - 2024-12-10 15:50:26 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:50:26 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:50:26 --> Utf8 Class Initialized
INFO - 2024-12-10 15:50:26 --> URI Class Initialized
INFO - 2024-12-10 15:50:26 --> Router Class Initialized
INFO - 2024-12-10 15:50:26 --> Output Class Initialized
INFO - 2024-12-10 15:50:26 --> Security Class Initialized
DEBUG - 2024-12-10 15:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:50:26 --> CSRF cookie sent
INFO - 2024-12-10 15:50:26 --> CSRF token verified
INFO - 2024-12-10 15:50:26 --> Input Class Initialized
INFO - 2024-12-10 15:50:26 --> Language Class Initialized
ERROR - 2024-12-10 15:50:26 --> 404 Page Not Found: Culinary/reset_password_action
INFO - 2024-12-10 15:50:29 --> Config Class Initialized
INFO - 2024-12-10 15:50:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:50:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:50:29 --> Utf8 Class Initialized
INFO - 2024-12-10 15:50:29 --> URI Class Initialized
INFO - 2024-12-10 15:50:29 --> Router Class Initialized
INFO - 2024-12-10 15:50:29 --> Output Class Initialized
INFO - 2024-12-10 15:50:29 --> Security Class Initialized
DEBUG - 2024-12-10 15:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:50:29 --> CSRF cookie sent
INFO - 2024-12-10 15:50:29 --> Input Class Initialized
INFO - 2024-12-10 15:50:29 --> Language Class Initialized
INFO - 2024-12-10 15:50:29 --> Loader Class Initialized
INFO - 2024-12-10 15:50:29 --> Helper loaded: url_helper
INFO - 2024-12-10 15:50:29 --> Helper loaded: form_helper
INFO - 2024-12-10 15:50:29 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:50:29 --> Form Validation Class Initialized
INFO - 2024-12-10 15:50:29 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:50:29 --> Controller Class Initialized
INFO - 2024-12-10 15:50:29 --> Model "User_model" initialized
INFO - 2024-12-10 15:50:29 --> Model "Category_model" initialized
INFO - 2024-12-10 15:50:29 --> Model "Review_model" initialized
INFO - 2024-12-10 15:50:29 --> Model "News_model" initialized
INFO - 2024-12-10 15:50:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:50:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:50:29 --> Final output sent to browser
DEBUG - 2024-12-10 15:50:29 --> Total execution time: 0.0468
INFO - 2024-12-10 15:50:34 --> Config Class Initialized
INFO - 2024-12-10 15:50:34 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:50:34 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:50:34 --> Utf8 Class Initialized
INFO - 2024-12-10 15:50:34 --> URI Class Initialized
INFO - 2024-12-10 15:50:34 --> Router Class Initialized
INFO - 2024-12-10 15:50:34 --> Output Class Initialized
INFO - 2024-12-10 15:50:34 --> Security Class Initialized
DEBUG - 2024-12-10 15:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:50:34 --> CSRF cookie sent
INFO - 2024-12-10 15:50:34 --> CSRF token verified
INFO - 2024-12-10 15:50:34 --> Input Class Initialized
INFO - 2024-12-10 15:50:34 --> Language Class Initialized
ERROR - 2024-12-10 15:50:34 --> 404 Page Not Found: Culinary/reset_password_action
INFO - 2024-12-10 15:50:37 --> Config Class Initialized
INFO - 2024-12-10 15:50:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:50:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:50:37 --> Utf8 Class Initialized
INFO - 2024-12-10 15:50:37 --> URI Class Initialized
INFO - 2024-12-10 15:50:37 --> Router Class Initialized
INFO - 2024-12-10 15:50:37 --> Output Class Initialized
INFO - 2024-12-10 15:50:37 --> Security Class Initialized
DEBUG - 2024-12-10 15:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:50:37 --> CSRF cookie sent
INFO - 2024-12-10 15:50:37 --> Input Class Initialized
INFO - 2024-12-10 15:50:37 --> Language Class Initialized
INFO - 2024-12-10 15:50:37 --> Loader Class Initialized
INFO - 2024-12-10 15:50:37 --> Helper loaded: url_helper
INFO - 2024-12-10 15:50:37 --> Helper loaded: form_helper
INFO - 2024-12-10 15:50:37 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:50:37 --> Form Validation Class Initialized
INFO - 2024-12-10 15:50:37 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:50:37 --> Controller Class Initialized
INFO - 2024-12-10 15:50:37 --> Model "User_model" initialized
INFO - 2024-12-10 15:50:37 --> Model "Category_model" initialized
INFO - 2024-12-10 15:50:37 --> Model "Review_model" initialized
INFO - 2024-12-10 15:50:37 --> Model "News_model" initialized
INFO - 2024-12-10 15:50:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:50:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:50:37 --> Final output sent to browser
DEBUG - 2024-12-10 15:50:37 --> Total execution time: 0.0498
INFO - 2024-12-10 15:50:43 --> Config Class Initialized
INFO - 2024-12-10 15:50:43 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:50:43 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:50:43 --> Utf8 Class Initialized
INFO - 2024-12-10 15:50:43 --> URI Class Initialized
INFO - 2024-12-10 15:50:43 --> Router Class Initialized
INFO - 2024-12-10 15:50:43 --> Output Class Initialized
INFO - 2024-12-10 15:50:43 --> Security Class Initialized
DEBUG - 2024-12-10 15:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:50:43 --> CSRF cookie sent
INFO - 2024-12-10 15:50:43 --> CSRF token verified
INFO - 2024-12-10 15:50:43 --> Input Class Initialized
INFO - 2024-12-10 15:50:43 --> Language Class Initialized
ERROR - 2024-12-10 15:50:43 --> 404 Page Not Found: Culinary/reset_password_action
INFO - 2024-12-10 15:52:08 --> Config Class Initialized
INFO - 2024-12-10 15:52:08 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:52:08 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:52:08 --> Utf8 Class Initialized
INFO - 2024-12-10 15:52:08 --> URI Class Initialized
INFO - 2024-12-10 15:52:08 --> Router Class Initialized
INFO - 2024-12-10 15:52:08 --> Output Class Initialized
INFO - 2024-12-10 15:52:08 --> Security Class Initialized
DEBUG - 2024-12-10 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:52:08 --> CSRF cookie sent
INFO - 2024-12-10 15:54:25 --> Config Class Initialized
INFO - 2024-12-10 15:54:25 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:54:25 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:54:25 --> Utf8 Class Initialized
INFO - 2024-12-10 15:54:25 --> URI Class Initialized
INFO - 2024-12-10 15:54:25 --> Router Class Initialized
INFO - 2024-12-10 15:54:25 --> Output Class Initialized
INFO - 2024-12-10 15:54:25 --> Security Class Initialized
DEBUG - 2024-12-10 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:54:25 --> CSRF cookie sent
INFO - 2024-12-10 15:54:27 --> Config Class Initialized
INFO - 2024-12-10 15:54:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:54:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:54:27 --> Utf8 Class Initialized
INFO - 2024-12-10 15:54:27 --> URI Class Initialized
INFO - 2024-12-10 15:54:27 --> Router Class Initialized
INFO - 2024-12-10 15:54:27 --> Output Class Initialized
INFO - 2024-12-10 15:54:27 --> Security Class Initialized
DEBUG - 2024-12-10 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:54:27 --> CSRF cookie sent
INFO - 2024-12-10 15:54:27 --> Input Class Initialized
INFO - 2024-12-10 15:54:27 --> Language Class Initialized
INFO - 2024-12-10 15:54:27 --> Loader Class Initialized
INFO - 2024-12-10 15:54:27 --> Helper loaded: url_helper
INFO - 2024-12-10 15:54:27 --> Helper loaded: form_helper
INFO - 2024-12-10 15:54:27 --> Database Driver Class Initialized
DEBUG - 2024-12-10 15:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 15:54:27 --> Form Validation Class Initialized
INFO - 2024-12-10 15:54:27 --> Model "Culinary_model" initialized
INFO - 2024-12-10 15:54:27 --> Controller Class Initialized
INFO - 2024-12-10 15:54:27 --> Model "User_model" initialized
INFO - 2024-12-10 15:54:27 --> Model "Category_model" initialized
INFO - 2024-12-10 15:54:27 --> Model "Review_model" initialized
INFO - 2024-12-10 15:54:27 --> Model "News_model" initialized
INFO - 2024-12-10 15:54:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 15:54:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 15:54:27 --> Final output sent to browser
DEBUG - 2024-12-10 15:54:27 --> Total execution time: 0.0698
INFO - 2024-12-10 15:54:29 --> Config Class Initialized
INFO - 2024-12-10 15:54:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:54:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:54:29 --> Utf8 Class Initialized
INFO - 2024-12-10 15:54:29 --> URI Class Initialized
INFO - 2024-12-10 15:54:29 --> Router Class Initialized
INFO - 2024-12-10 15:54:29 --> Output Class Initialized
INFO - 2024-12-10 15:54:29 --> Security Class Initialized
DEBUG - 2024-12-10 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:54:29 --> CSRF cookie sent
INFO - 2024-12-10 15:54:29 --> CSRF token verified
INFO - 2024-12-10 15:54:29 --> Input Class Initialized
INFO - 2024-12-10 15:54:29 --> Language Class Initialized
ERROR - 2024-12-10 15:54:29 --> 404 Page Not Found: Culinary/reset_password_action
INFO - 2024-12-10 15:54:34 --> Config Class Initialized
INFO - 2024-12-10 15:54:34 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:54:34 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:54:34 --> Utf8 Class Initialized
INFO - 2024-12-10 15:54:34 --> URI Class Initialized
INFO - 2024-12-10 15:54:34 --> Router Class Initialized
INFO - 2024-12-10 15:54:34 --> Output Class Initialized
INFO - 2024-12-10 15:54:34 --> Security Class Initialized
DEBUG - 2024-12-10 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:54:34 --> CSRF cookie sent
INFO - 2024-12-10 15:54:38 --> Config Class Initialized
INFO - 2024-12-10 15:54:38 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:54:38 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:54:38 --> Utf8 Class Initialized
INFO - 2024-12-10 15:54:38 --> URI Class Initialized
INFO - 2024-12-10 15:54:38 --> Router Class Initialized
INFO - 2024-12-10 15:54:38 --> Output Class Initialized
INFO - 2024-12-10 15:54:38 --> Security Class Initialized
DEBUG - 2024-12-10 15:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:54:38 --> CSRF cookie sent
INFO - 2024-12-10 15:55:12 --> Config Class Initialized
INFO - 2024-12-10 15:55:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 15:55:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 15:55:12 --> Utf8 Class Initialized
INFO - 2024-12-10 15:55:12 --> URI Class Initialized
INFO - 2024-12-10 15:55:12 --> Router Class Initialized
INFO - 2024-12-10 15:55:12 --> Output Class Initialized
INFO - 2024-12-10 15:55:12 --> Security Class Initialized
DEBUG - 2024-12-10 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 15:55:12 --> CSRF cookie sent
INFO - 2024-12-10 16:00:32 --> Config Class Initialized
INFO - 2024-12-10 16:00:32 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:32 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:32 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:32 --> URI Class Initialized
INFO - 2024-12-10 16:00:32 --> Router Class Initialized
INFO - 2024-12-10 16:00:32 --> Output Class Initialized
INFO - 2024-12-10 16:00:32 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:32 --> CSRF cookie sent
INFO - 2024-12-10 16:00:36 --> Config Class Initialized
INFO - 2024-12-10 16:00:36 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:36 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:36 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:36 --> URI Class Initialized
INFO - 2024-12-10 16:00:36 --> Router Class Initialized
INFO - 2024-12-10 16:00:36 --> Output Class Initialized
INFO - 2024-12-10 16:00:36 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:36 --> CSRF cookie sent
INFO - 2024-12-10 16:00:37 --> Config Class Initialized
INFO - 2024-12-10 16:00:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:37 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:37 --> URI Class Initialized
INFO - 2024-12-10 16:00:37 --> Router Class Initialized
INFO - 2024-12-10 16:00:37 --> Output Class Initialized
INFO - 2024-12-10 16:00:37 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:37 --> CSRF cookie sent
INFO - 2024-12-10 16:00:37 --> Input Class Initialized
INFO - 2024-12-10 16:00:37 --> Language Class Initialized
INFO - 2024-12-10 16:00:37 --> Loader Class Initialized
INFO - 2024-12-10 16:00:37 --> Helper loaded: url_helper
INFO - 2024-12-10 16:00:37 --> Helper loaded: form_helper
INFO - 2024-12-10 16:00:37 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:00:37 --> Form Validation Class Initialized
INFO - 2024-12-10 16:00:37 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:00:37 --> Controller Class Initialized
INFO - 2024-12-10 16:00:37 --> Model "User_model" initialized
INFO - 2024-12-10 16:00:37 --> Model "Category_model" initialized
INFO - 2024-12-10 16:00:37 --> Model "Review_model" initialized
INFO - 2024-12-10 16:00:37 --> Model "News_model" initialized
INFO - 2024-12-10 16:00:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:00:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:00:37 --> Final output sent to browser
DEBUG - 2024-12-10 16:00:37 --> Total execution time: 0.0495
INFO - 2024-12-10 16:00:39 --> Config Class Initialized
INFO - 2024-12-10 16:00:39 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:39 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:39 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:39 --> URI Class Initialized
INFO - 2024-12-10 16:00:39 --> Router Class Initialized
INFO - 2024-12-10 16:00:39 --> Output Class Initialized
INFO - 2024-12-10 16:00:39 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:39 --> CSRF cookie sent
INFO - 2024-12-10 16:00:39 --> CSRF token verified
INFO - 2024-12-10 16:00:39 --> Input Class Initialized
INFO - 2024-12-10 16:00:39 --> Language Class Initialized
ERROR - 2024-12-10 16:00:39 --> 404 Page Not Found: Culinary/reset_password_action
INFO - 2024-12-10 16:00:43 --> Config Class Initialized
INFO - 2024-12-10 16:00:43 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:43 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:43 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:43 --> URI Class Initialized
INFO - 2024-12-10 16:00:43 --> Router Class Initialized
INFO - 2024-12-10 16:00:43 --> Output Class Initialized
INFO - 2024-12-10 16:00:43 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:43 --> CSRF cookie sent
INFO - 2024-12-10 16:00:46 --> Config Class Initialized
INFO - 2024-12-10 16:00:46 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:46 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:46 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:46 --> URI Class Initialized
INFO - 2024-12-10 16:00:46 --> Router Class Initialized
INFO - 2024-12-10 16:00:46 --> Output Class Initialized
INFO - 2024-12-10 16:00:46 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:46 --> CSRF cookie sent
INFO - 2024-12-10 16:00:47 --> Config Class Initialized
INFO - 2024-12-10 16:00:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:47 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:47 --> URI Class Initialized
INFO - 2024-12-10 16:00:47 --> Router Class Initialized
INFO - 2024-12-10 16:00:47 --> Output Class Initialized
INFO - 2024-12-10 16:00:47 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:47 --> CSRF cookie sent
INFO - 2024-12-10 16:00:47 --> Input Class Initialized
INFO - 2024-12-10 16:00:47 --> Language Class Initialized
INFO - 2024-12-10 16:00:47 --> Loader Class Initialized
INFO - 2024-12-10 16:00:47 --> Helper loaded: url_helper
INFO - 2024-12-10 16:00:47 --> Helper loaded: form_helper
INFO - 2024-12-10 16:00:47 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:00:47 --> Form Validation Class Initialized
INFO - 2024-12-10 16:00:47 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:00:47 --> Controller Class Initialized
INFO - 2024-12-10 16:00:47 --> Model "User_model" initialized
INFO - 2024-12-10 16:00:47 --> Model "Category_model" initialized
INFO - 2024-12-10 16:00:47 --> Model "Review_model" initialized
INFO - 2024-12-10 16:00:47 --> Model "News_model" initialized
INFO - 2024-12-10 16:00:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:00:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:00:47 --> Final output sent to browser
DEBUG - 2024-12-10 16:00:47 --> Total execution time: 0.0614
INFO - 2024-12-10 16:00:48 --> Config Class Initialized
INFO - 2024-12-10 16:00:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:48 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:48 --> URI Class Initialized
INFO - 2024-12-10 16:00:48 --> Router Class Initialized
INFO - 2024-12-10 16:00:48 --> Output Class Initialized
INFO - 2024-12-10 16:00:48 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:48 --> CSRF cookie sent
INFO - 2024-12-10 16:00:48 --> CSRF token verified
INFO - 2024-12-10 16:00:48 --> Input Class Initialized
INFO - 2024-12-10 16:00:48 --> Language Class Initialized
ERROR - 2024-12-10 16:00:48 --> 404 Page Not Found: Culinary/reset_password_action
INFO - 2024-12-10 16:00:53 --> Config Class Initialized
INFO - 2024-12-10 16:00:53 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:00:53 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:00:53 --> Utf8 Class Initialized
INFO - 2024-12-10 16:00:53 --> URI Class Initialized
INFO - 2024-12-10 16:00:53 --> Router Class Initialized
INFO - 2024-12-10 16:00:53 --> Output Class Initialized
INFO - 2024-12-10 16:00:53 --> Security Class Initialized
DEBUG - 2024-12-10 16:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:00:53 --> CSRF cookie sent
INFO - 2024-12-10 16:05:53 --> Config Class Initialized
INFO - 2024-12-10 16:05:53 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:05:53 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:05:53 --> Utf8 Class Initialized
INFO - 2024-12-10 16:05:53 --> URI Class Initialized
INFO - 2024-12-10 16:05:53 --> Router Class Initialized
INFO - 2024-12-10 16:05:53 --> Output Class Initialized
INFO - 2024-12-10 16:05:53 --> Security Class Initialized
DEBUG - 2024-12-10 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:05:53 --> CSRF cookie sent
INFO - 2024-12-10 16:05:53 --> Input Class Initialized
INFO - 2024-12-10 16:05:53 --> Language Class Initialized
INFO - 2024-12-10 16:05:53 --> Loader Class Initialized
INFO - 2024-12-10 16:05:53 --> Helper loaded: url_helper
INFO - 2024-12-10 16:05:53 --> Helper loaded: form_helper
INFO - 2024-12-10 16:05:53 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:05:53 --> Form Validation Class Initialized
INFO - 2024-12-10 16:05:53 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:05:53 --> Controller Class Initialized
INFO - 2024-12-10 16:05:53 --> Model "User_model" initialized
INFO - 2024-12-10 16:05:53 --> Model "Category_model" initialized
INFO - 2024-12-10 16:05:53 --> Model "Review_model" initialized
INFO - 2024-12-10 16:05:53 --> Model "News_model" initialized
INFO - 2024-12-10 16:05:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:05:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:05:53 --> Final output sent to browser
DEBUG - 2024-12-10 16:05:53 --> Total execution time: 0.0500
INFO - 2024-12-10 16:05:54 --> Config Class Initialized
INFO - 2024-12-10 16:05:54 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:05:54 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:05:54 --> Utf8 Class Initialized
INFO - 2024-12-10 16:05:54 --> URI Class Initialized
INFO - 2024-12-10 16:05:54 --> Router Class Initialized
INFO - 2024-12-10 16:05:54 --> Output Class Initialized
INFO - 2024-12-10 16:05:54 --> Security Class Initialized
DEBUG - 2024-12-10 16:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:05:54 --> CSRF cookie sent
INFO - 2024-12-10 16:05:54 --> Input Class Initialized
INFO - 2024-12-10 16:05:54 --> Language Class Initialized
INFO - 2024-12-10 16:05:54 --> Loader Class Initialized
INFO - 2024-12-10 16:05:54 --> Helper loaded: url_helper
INFO - 2024-12-10 16:05:54 --> Helper loaded: form_helper
INFO - 2024-12-10 16:05:54 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:05:54 --> Form Validation Class Initialized
INFO - 2024-12-10 16:05:54 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:05:54 --> Controller Class Initialized
INFO - 2024-12-10 16:05:54 --> Model "User_model" initialized
INFO - 2024-12-10 16:05:54 --> Model "Category_model" initialized
INFO - 2024-12-10 16:05:54 --> Model "Review_model" initialized
INFO - 2024-12-10 16:05:54 --> Model "News_model" initialized
INFO - 2024-12-10 16:05:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:05:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:05:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:05:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:05:54 --> Final output sent to browser
DEBUG - 2024-12-10 16:05:54 --> Total execution time: 0.0421
INFO - 2024-12-10 16:05:57 --> Config Class Initialized
INFO - 2024-12-10 16:05:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:05:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:05:57 --> Utf8 Class Initialized
INFO - 2024-12-10 16:05:57 --> URI Class Initialized
INFO - 2024-12-10 16:05:57 --> Router Class Initialized
INFO - 2024-12-10 16:05:57 --> Output Class Initialized
INFO - 2024-12-10 16:05:57 --> Security Class Initialized
DEBUG - 2024-12-10 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:05:57 --> CSRF cookie sent
INFO - 2024-12-10 16:05:57 --> Input Class Initialized
INFO - 2024-12-10 16:05:57 --> Language Class Initialized
INFO - 2024-12-10 16:05:57 --> Loader Class Initialized
INFO - 2024-12-10 16:05:57 --> Helper loaded: url_helper
INFO - 2024-12-10 16:05:57 --> Helper loaded: form_helper
INFO - 2024-12-10 16:05:57 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:05:57 --> Form Validation Class Initialized
INFO - 2024-12-10 16:05:57 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:05:57 --> Controller Class Initialized
INFO - 2024-12-10 16:05:57 --> Model "User_model" initialized
INFO - 2024-12-10 16:05:57 --> Model "Category_model" initialized
INFO - 2024-12-10 16:05:57 --> Model "Review_model" initialized
INFO - 2024-12-10 16:05:57 --> Model "News_model" initialized
INFO - 2024-12-10 16:05:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:05:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:05:57 --> Final output sent to browser
DEBUG - 2024-12-10 16:05:57 --> Total execution time: 0.0588
INFO - 2024-12-10 16:06:01 --> Config Class Initialized
INFO - 2024-12-10 16:06:01 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:01 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:01 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:01 --> URI Class Initialized
INFO - 2024-12-10 16:06:01 --> Router Class Initialized
INFO - 2024-12-10 16:06:01 --> Output Class Initialized
INFO - 2024-12-10 16:06:01 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:01 --> CSRF cookie sent
INFO - 2024-12-10 16:06:01 --> CSRF token verified
INFO - 2024-12-10 16:06:01 --> Input Class Initialized
INFO - 2024-12-10 16:06:01 --> Language Class Initialized
INFO - 2024-12-10 16:06:01 --> Loader Class Initialized
INFO - 2024-12-10 16:06:01 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:01 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:01 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:01 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:01 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:01 --> Controller Class Initialized
INFO - 2024-12-10 16:06:01 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:01 --> Config Class Initialized
INFO - 2024-12-10 16:06:01 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:01 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:01 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:01 --> URI Class Initialized
INFO - 2024-12-10 16:06:01 --> Router Class Initialized
INFO - 2024-12-10 16:06:01 --> Output Class Initialized
INFO - 2024-12-10 16:06:01 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:01 --> CSRF cookie sent
INFO - 2024-12-10 16:06:01 --> Input Class Initialized
INFO - 2024-12-10 16:06:01 --> Language Class Initialized
INFO - 2024-12-10 16:06:01 --> Loader Class Initialized
INFO - 2024-12-10 16:06:01 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:01 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:01 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:01 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:01 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:01 --> Controller Class Initialized
INFO - 2024-12-10 16:06:01 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:06:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:06:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:06:01 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:01 --> Total execution time: 0.0492
INFO - 2024-12-10 16:06:04 --> Config Class Initialized
INFO - 2024-12-10 16:06:04 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:04 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:04 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:04 --> URI Class Initialized
INFO - 2024-12-10 16:06:04 --> Router Class Initialized
INFO - 2024-12-10 16:06:04 --> Output Class Initialized
INFO - 2024-12-10 16:06:04 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:04 --> CSRF cookie sent
INFO - 2024-12-10 16:06:04 --> CSRF token verified
INFO - 2024-12-10 16:06:04 --> Input Class Initialized
INFO - 2024-12-10 16:06:04 --> Language Class Initialized
INFO - 2024-12-10 16:06:04 --> Loader Class Initialized
INFO - 2024-12-10 16:06:04 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:04 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:04 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:04 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:04 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:04 --> Controller Class Initialized
INFO - 2024-12-10 16:06:04 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:04 --> Config Class Initialized
INFO - 2024-12-10 16:06:04 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:04 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:04 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:04 --> URI Class Initialized
INFO - 2024-12-10 16:06:04 --> Router Class Initialized
INFO - 2024-12-10 16:06:04 --> Output Class Initialized
INFO - 2024-12-10 16:06:04 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:04 --> CSRF cookie sent
INFO - 2024-12-10 16:06:04 --> Input Class Initialized
INFO - 2024-12-10 16:06:04 --> Language Class Initialized
INFO - 2024-12-10 16:06:04 --> Loader Class Initialized
INFO - 2024-12-10 16:06:04 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:04 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:04 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:04 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:04 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:04 --> Controller Class Initialized
INFO - 2024-12-10 16:06:04 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:06:04 --> Query result: stdClass Object
(
    [view_count] => 115
)

INFO - 2024-12-10 16:06:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:06:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:06:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:06:04 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:04 --> Total execution time: 0.0854
INFO - 2024-12-10 16:06:04 --> Config Class Initialized
INFO - 2024-12-10 16:06:04 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:04 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:04 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:04 --> URI Class Initialized
INFO - 2024-12-10 16:06:04 --> Router Class Initialized
INFO - 2024-12-10 16:06:04 --> Output Class Initialized
INFO - 2024-12-10 16:06:04 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:04 --> CSRF cookie sent
INFO - 2024-12-10 16:06:04 --> Input Class Initialized
INFO - 2024-12-10 16:06:04 --> Language Class Initialized
ERROR - 2024-12-10 16:06:04 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 16:06:06 --> Config Class Initialized
INFO - 2024-12-10 16:06:06 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:06 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:06 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:06 --> URI Class Initialized
INFO - 2024-12-10 16:06:06 --> Router Class Initialized
INFO - 2024-12-10 16:06:06 --> Output Class Initialized
INFO - 2024-12-10 16:06:06 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:06 --> CSRF cookie sent
INFO - 2024-12-10 16:06:06 --> Input Class Initialized
INFO - 2024-12-10 16:06:06 --> Language Class Initialized
INFO - 2024-12-10 16:06:06 --> Loader Class Initialized
INFO - 2024-12-10 16:06:06 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:06 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:06 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:06 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:06 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:06 --> Controller Class Initialized
INFO - 2024-12-10 16:06:06 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:06 --> Config Class Initialized
INFO - 2024-12-10 16:06:06 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:06 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:06 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:06 --> URI Class Initialized
INFO - 2024-12-10 16:06:06 --> Router Class Initialized
INFO - 2024-12-10 16:06:06 --> Output Class Initialized
INFO - 2024-12-10 16:06:06 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:06 --> CSRF cookie sent
INFO - 2024-12-10 16:06:06 --> Input Class Initialized
INFO - 2024-12-10 16:06:06 --> Language Class Initialized
INFO - 2024-12-10 16:06:06 --> Loader Class Initialized
INFO - 2024-12-10 16:06:06 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:06 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:06 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:06 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:06 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:06 --> Controller Class Initialized
INFO - 2024-12-10 16:06:06 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:06:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:06:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:06:06 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:06 --> Total execution time: 0.0793
INFO - 2024-12-10 16:06:08 --> Config Class Initialized
INFO - 2024-12-10 16:06:08 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:08 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:08 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:08 --> URI Class Initialized
INFO - 2024-12-10 16:06:08 --> Router Class Initialized
INFO - 2024-12-10 16:06:08 --> Output Class Initialized
INFO - 2024-12-10 16:06:08 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:08 --> CSRF cookie sent
INFO - 2024-12-10 16:06:08 --> Input Class Initialized
INFO - 2024-12-10 16:06:08 --> Language Class Initialized
INFO - 2024-12-10 16:06:08 --> Loader Class Initialized
INFO - 2024-12-10 16:06:08 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:08 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:08 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:08 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:08 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:08 --> Controller Class Initialized
INFO - 2024-12-10 16:06:08 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:08 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:08 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:08 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:06:08 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:08 --> Total execution time: 0.0676
INFO - 2024-12-10 16:06:16 --> Config Class Initialized
INFO - 2024-12-10 16:06:16 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:16 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:16 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:16 --> URI Class Initialized
INFO - 2024-12-10 16:06:16 --> Router Class Initialized
INFO - 2024-12-10 16:06:16 --> Output Class Initialized
INFO - 2024-12-10 16:06:16 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:16 --> CSRF cookie sent
INFO - 2024-12-10 16:06:16 --> CSRF token verified
INFO - 2024-12-10 16:06:16 --> Input Class Initialized
INFO - 2024-12-10 16:06:16 --> Language Class Initialized
INFO - 2024-12-10 16:06:16 --> Loader Class Initialized
INFO - 2024-12-10 16:06:16 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:16 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:16 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:16 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:16 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:16 --> Controller Class Initialized
INFO - 2024-12-10 16:06:16 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:16 --> Config Class Initialized
INFO - 2024-12-10 16:06:16 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:16 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:16 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:16 --> URI Class Initialized
INFO - 2024-12-10 16:06:16 --> Router Class Initialized
INFO - 2024-12-10 16:06:16 --> Output Class Initialized
INFO - 2024-12-10 16:06:16 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:16 --> CSRF cookie sent
INFO - 2024-12-10 16:06:16 --> Input Class Initialized
INFO - 2024-12-10 16:06:16 --> Language Class Initialized
INFO - 2024-12-10 16:06:16 --> Loader Class Initialized
INFO - 2024-12-10 16:06:16 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:16 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:16 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:16 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:16 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:16 --> Controller Class Initialized
INFO - 2024-12-10 16:06:16 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:06:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:06:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:06:16 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:16 --> Total execution time: 0.0487
INFO - 2024-12-10 16:06:18 --> Config Class Initialized
INFO - 2024-12-10 16:06:18 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:18 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:18 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:18 --> URI Class Initialized
INFO - 2024-12-10 16:06:18 --> Router Class Initialized
INFO - 2024-12-10 16:06:18 --> Output Class Initialized
INFO - 2024-12-10 16:06:18 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:18 --> CSRF cookie sent
INFO - 2024-12-10 16:06:18 --> CSRF token verified
INFO - 2024-12-10 16:06:18 --> Input Class Initialized
INFO - 2024-12-10 16:06:18 --> Language Class Initialized
INFO - 2024-12-10 16:06:18 --> Loader Class Initialized
INFO - 2024-12-10 16:06:18 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:18 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:18 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:18 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:18 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:18 --> Controller Class Initialized
INFO - 2024-12-10 16:06:18 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:18 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:18 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:18 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:06:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:06:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:06:18 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:18 --> Total execution time: 0.1437
INFO - 2024-12-10 16:06:23 --> Config Class Initialized
INFO - 2024-12-10 16:06:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:23 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:23 --> URI Class Initialized
INFO - 2024-12-10 16:06:23 --> Router Class Initialized
INFO - 2024-12-10 16:06:23 --> Output Class Initialized
INFO - 2024-12-10 16:06:23 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:23 --> CSRF cookie sent
INFO - 2024-12-10 16:06:23 --> CSRF token verified
INFO - 2024-12-10 16:06:23 --> Input Class Initialized
INFO - 2024-12-10 16:06:23 --> Language Class Initialized
INFO - 2024-12-10 16:06:23 --> Loader Class Initialized
INFO - 2024-12-10 16:06:23 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:23 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:23 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:23 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:23 --> Controller Class Initialized
INFO - 2024-12-10 16:06:23 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:06:23 --> Config Class Initialized
INFO - 2024-12-10 16:06:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:23 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:23 --> URI Class Initialized
INFO - 2024-12-10 16:06:23 --> Router Class Initialized
INFO - 2024-12-10 16:06:23 --> Output Class Initialized
INFO - 2024-12-10 16:06:23 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:23 --> CSRF cookie sent
INFO - 2024-12-10 16:06:23 --> Input Class Initialized
INFO - 2024-12-10 16:06:23 --> Language Class Initialized
INFO - 2024-12-10 16:06:23 --> Loader Class Initialized
INFO - 2024-12-10 16:06:23 --> Helper loaded: url_helper
INFO - 2024-12-10 16:06:23 --> Helper loaded: form_helper
INFO - 2024-12-10 16:06:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:06:23 --> Form Validation Class Initialized
INFO - 2024-12-10 16:06:23 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:06:23 --> Controller Class Initialized
INFO - 2024-12-10 16:06:23 --> Model "User_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "Category_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "Review_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "News_model" initialized
INFO - 2024-12-10 16:06:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:06:23 --> Query result: stdClass Object
(
    [view_count] => 116
)

INFO - 2024-12-10 16:06:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:06:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:06:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:06:23 --> Final output sent to browser
DEBUG - 2024-12-10 16:06:23 --> Total execution time: 0.0610
INFO - 2024-12-10 16:06:23 --> Config Class Initialized
INFO - 2024-12-10 16:06:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:06:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:06:23 --> Utf8 Class Initialized
INFO - 2024-12-10 16:06:23 --> URI Class Initialized
INFO - 2024-12-10 16:06:23 --> Router Class Initialized
INFO - 2024-12-10 16:06:23 --> Output Class Initialized
INFO - 2024-12-10 16:06:23 --> Security Class Initialized
DEBUG - 2024-12-10 16:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:06:23 --> CSRF cookie sent
INFO - 2024-12-10 16:06:23 --> Input Class Initialized
INFO - 2024-12-10 16:06:23 --> Language Class Initialized
ERROR - 2024-12-10 16:06:23 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 16:11:44 --> Config Class Initialized
INFO - 2024-12-10 16:11:44 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:11:44 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:11:44 --> Utf8 Class Initialized
INFO - 2024-12-10 16:11:44 --> URI Class Initialized
INFO - 2024-12-10 16:11:44 --> Router Class Initialized
INFO - 2024-12-10 16:11:44 --> Output Class Initialized
INFO - 2024-12-10 16:11:44 --> Security Class Initialized
DEBUG - 2024-12-10 16:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:11:44 --> CSRF cookie sent
INFO - 2024-12-10 16:11:44 --> Input Class Initialized
INFO - 2024-12-10 16:11:44 --> Language Class Initialized
INFO - 2024-12-10 16:11:44 --> Loader Class Initialized
INFO - 2024-12-10 16:11:44 --> Helper loaded: url_helper
INFO - 2024-12-10 16:11:44 --> Helper loaded: form_helper
INFO - 2024-12-10 16:11:44 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:11:44 --> Form Validation Class Initialized
INFO - 2024-12-10 16:11:44 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:11:44 --> Controller Class Initialized
INFO - 2024-12-10 16:11:44 --> Model "User_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "Category_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "Review_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "News_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:11:44 --> Config Class Initialized
INFO - 2024-12-10 16:11:44 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:11:44 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:11:44 --> Utf8 Class Initialized
INFO - 2024-12-10 16:11:44 --> URI Class Initialized
INFO - 2024-12-10 16:11:44 --> Router Class Initialized
INFO - 2024-12-10 16:11:44 --> Output Class Initialized
INFO - 2024-12-10 16:11:44 --> Security Class Initialized
DEBUG - 2024-12-10 16:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:11:44 --> CSRF cookie sent
INFO - 2024-12-10 16:11:44 --> Input Class Initialized
INFO - 2024-12-10 16:11:44 --> Language Class Initialized
INFO - 2024-12-10 16:11:44 --> Loader Class Initialized
INFO - 2024-12-10 16:11:44 --> Helper loaded: url_helper
INFO - 2024-12-10 16:11:44 --> Helper loaded: form_helper
INFO - 2024-12-10 16:11:44 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:11:44 --> Form Validation Class Initialized
INFO - 2024-12-10 16:11:44 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:11:44 --> Controller Class Initialized
INFO - 2024-12-10 16:11:44 --> Model "User_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "Category_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "Review_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "News_model" initialized
INFO - 2024-12-10 16:11:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:11:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:11:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:11:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:11:44 --> Final output sent to browser
DEBUG - 2024-12-10 16:11:44 --> Total execution time: 0.0463
INFO - 2024-12-10 16:11:50 --> Config Class Initialized
INFO - 2024-12-10 16:11:50 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:11:50 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:11:50 --> Utf8 Class Initialized
INFO - 2024-12-10 16:11:50 --> URI Class Initialized
INFO - 2024-12-10 16:11:50 --> Router Class Initialized
INFO - 2024-12-10 16:11:50 --> Output Class Initialized
INFO - 2024-12-10 16:11:50 --> Security Class Initialized
DEBUG - 2024-12-10 16:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:11:50 --> CSRF cookie sent
INFO - 2024-12-10 16:11:50 --> CSRF token verified
INFO - 2024-12-10 16:11:50 --> Input Class Initialized
INFO - 2024-12-10 16:11:50 --> Language Class Initialized
INFO - 2024-12-10 16:11:50 --> Loader Class Initialized
INFO - 2024-12-10 16:11:50 --> Helper loaded: url_helper
INFO - 2024-12-10 16:11:50 --> Helper loaded: form_helper
INFO - 2024-12-10 16:11:50 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:11:50 --> Form Validation Class Initialized
INFO - 2024-12-10 16:11:50 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:11:50 --> Controller Class Initialized
INFO - 2024-12-10 16:11:50 --> Model "User_model" initialized
INFO - 2024-12-10 16:11:50 --> Model "Category_model" initialized
INFO - 2024-12-10 16:11:50 --> Model "Review_model" initialized
INFO - 2024-12-10 16:11:50 --> Model "News_model" initialized
INFO - 2024-12-10 16:11:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:11:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:11:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:11:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:11:51 --> Final output sent to browser
DEBUG - 2024-12-10 16:11:51 --> Total execution time: 0.1177
INFO - 2024-12-10 16:11:53 --> Config Class Initialized
INFO - 2024-12-10 16:11:53 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:11:53 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:11:53 --> Utf8 Class Initialized
INFO - 2024-12-10 16:11:53 --> URI Class Initialized
INFO - 2024-12-10 16:11:53 --> Router Class Initialized
INFO - 2024-12-10 16:11:53 --> Output Class Initialized
INFO - 2024-12-10 16:11:53 --> Security Class Initialized
DEBUG - 2024-12-10 16:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:11:53 --> CSRF cookie sent
INFO - 2024-12-10 16:11:53 --> Input Class Initialized
INFO - 2024-12-10 16:11:53 --> Language Class Initialized
INFO - 2024-12-10 16:11:53 --> Loader Class Initialized
INFO - 2024-12-10 16:11:53 --> Helper loaded: url_helper
INFO - 2024-12-10 16:11:53 --> Helper loaded: form_helper
INFO - 2024-12-10 16:11:53 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:11:53 --> Form Validation Class Initialized
INFO - 2024-12-10 16:11:53 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:11:53 --> Controller Class Initialized
INFO - 2024-12-10 16:11:53 --> Model "User_model" initialized
INFO - 2024-12-10 16:11:53 --> Model "Category_model" initialized
INFO - 2024-12-10 16:11:53 --> Model "Review_model" initialized
INFO - 2024-12-10 16:11:53 --> Model "News_model" initialized
INFO - 2024-12-10 16:11:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:11:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:11:53 --> Final output sent to browser
DEBUG - 2024-12-10 16:11:53 --> Total execution time: 0.0598
INFO - 2024-12-10 16:12:02 --> Config Class Initialized
INFO - 2024-12-10 16:12:02 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:02 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:02 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:02 --> URI Class Initialized
INFO - 2024-12-10 16:12:02 --> Router Class Initialized
INFO - 2024-12-10 16:12:02 --> Output Class Initialized
INFO - 2024-12-10 16:12:02 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:02 --> CSRF cookie sent
INFO - 2024-12-10 16:12:02 --> CSRF token verified
INFO - 2024-12-10 16:12:02 --> Input Class Initialized
INFO - 2024-12-10 16:12:02 --> Language Class Initialized
INFO - 2024-12-10 16:12:02 --> Loader Class Initialized
INFO - 2024-12-10 16:12:02 --> Helper loaded: url_helper
INFO - 2024-12-10 16:12:02 --> Helper loaded: form_helper
INFO - 2024-12-10 16:12:02 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:12:02 --> Form Validation Class Initialized
INFO - 2024-12-10 16:12:02 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:12:02 --> Controller Class Initialized
INFO - 2024-12-10 16:12:02 --> Model "User_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "Category_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "Review_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "News_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:12:02 --> Config Class Initialized
INFO - 2024-12-10 16:12:02 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:02 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:02 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:02 --> URI Class Initialized
INFO - 2024-12-10 16:12:02 --> Router Class Initialized
INFO - 2024-12-10 16:12:02 --> Output Class Initialized
INFO - 2024-12-10 16:12:02 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:02 --> CSRF cookie sent
INFO - 2024-12-10 16:12:02 --> Input Class Initialized
INFO - 2024-12-10 16:12:02 --> Language Class Initialized
INFO - 2024-12-10 16:12:02 --> Loader Class Initialized
INFO - 2024-12-10 16:12:02 --> Helper loaded: url_helper
INFO - 2024-12-10 16:12:02 --> Helper loaded: form_helper
INFO - 2024-12-10 16:12:02 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:12:02 --> Form Validation Class Initialized
INFO - 2024-12-10 16:12:02 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:12:02 --> Controller Class Initialized
INFO - 2024-12-10 16:12:02 --> Model "User_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "Category_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "Review_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "News_model" initialized
INFO - 2024-12-10 16:12:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:12:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:12:02 --> Final output sent to browser
DEBUG - 2024-12-10 16:12:02 --> Total execution time: 0.0639
INFO - 2024-12-10 16:12:11 --> Config Class Initialized
INFO - 2024-12-10 16:12:11 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:11 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:11 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:11 --> URI Class Initialized
INFO - 2024-12-10 16:12:11 --> Router Class Initialized
INFO - 2024-12-10 16:12:11 --> Output Class Initialized
INFO - 2024-12-10 16:12:11 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:11 --> CSRF cookie sent
INFO - 2024-12-10 16:12:11 --> CSRF token verified
INFO - 2024-12-10 16:12:11 --> Input Class Initialized
INFO - 2024-12-10 16:12:11 --> Language Class Initialized
INFO - 2024-12-10 16:12:11 --> Loader Class Initialized
INFO - 2024-12-10 16:12:11 --> Helper loaded: url_helper
INFO - 2024-12-10 16:12:11 --> Helper loaded: form_helper
INFO - 2024-12-10 16:12:11 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:12:11 --> Form Validation Class Initialized
INFO - 2024-12-10 16:12:11 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:12:11 --> Controller Class Initialized
INFO - 2024-12-10 16:12:11 --> Model "User_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "Category_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "Review_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "News_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:12:11 --> Config Class Initialized
INFO - 2024-12-10 16:12:11 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:11 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:11 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:11 --> URI Class Initialized
INFO - 2024-12-10 16:12:11 --> Router Class Initialized
INFO - 2024-12-10 16:12:11 --> Output Class Initialized
INFO - 2024-12-10 16:12:11 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:11 --> CSRF cookie sent
INFO - 2024-12-10 16:12:11 --> Input Class Initialized
INFO - 2024-12-10 16:12:11 --> Language Class Initialized
INFO - 2024-12-10 16:12:11 --> Loader Class Initialized
INFO - 2024-12-10 16:12:11 --> Helper loaded: url_helper
INFO - 2024-12-10 16:12:11 --> Helper loaded: form_helper
INFO - 2024-12-10 16:12:11 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:12:11 --> Form Validation Class Initialized
INFO - 2024-12-10 16:12:11 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:12:11 --> Controller Class Initialized
INFO - 2024-12-10 16:12:11 --> Model "User_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "Category_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "Review_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "News_model" initialized
INFO - 2024-12-10 16:12:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:12:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:12:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:12:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:12:11 --> Final output sent to browser
DEBUG - 2024-12-10 16:12:11 --> Total execution time: 0.0349
INFO - 2024-12-10 16:12:13 --> Config Class Initialized
INFO - 2024-12-10 16:12:13 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:13 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:13 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:13 --> URI Class Initialized
INFO - 2024-12-10 16:12:13 --> Router Class Initialized
INFO - 2024-12-10 16:12:13 --> Output Class Initialized
INFO - 2024-12-10 16:12:13 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:13 --> CSRF cookie sent
INFO - 2024-12-10 16:12:13 --> CSRF token verified
INFO - 2024-12-10 16:12:13 --> Input Class Initialized
INFO - 2024-12-10 16:12:13 --> Language Class Initialized
INFO - 2024-12-10 16:12:13 --> Loader Class Initialized
INFO - 2024-12-10 16:12:13 --> Helper loaded: url_helper
INFO - 2024-12-10 16:12:13 --> Helper loaded: form_helper
INFO - 2024-12-10 16:12:13 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:12:13 --> Form Validation Class Initialized
INFO - 2024-12-10 16:12:13 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:12:13 --> Controller Class Initialized
INFO - 2024-12-10 16:12:13 --> Model "User_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "Category_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "Review_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "News_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:12:13 --> Config Class Initialized
INFO - 2024-12-10 16:12:13 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:13 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:13 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:13 --> URI Class Initialized
INFO - 2024-12-10 16:12:13 --> Router Class Initialized
INFO - 2024-12-10 16:12:13 --> Output Class Initialized
INFO - 2024-12-10 16:12:13 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:13 --> CSRF cookie sent
INFO - 2024-12-10 16:12:13 --> Input Class Initialized
INFO - 2024-12-10 16:12:13 --> Language Class Initialized
INFO - 2024-12-10 16:12:13 --> Loader Class Initialized
INFO - 2024-12-10 16:12:13 --> Helper loaded: url_helper
INFO - 2024-12-10 16:12:13 --> Helper loaded: form_helper
INFO - 2024-12-10 16:12:13 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:12:13 --> Form Validation Class Initialized
INFO - 2024-12-10 16:12:13 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:12:13 --> Controller Class Initialized
INFO - 2024-12-10 16:12:13 --> Model "User_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "Category_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "Review_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "News_model" initialized
INFO - 2024-12-10 16:12:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:12:13 --> Query result: stdClass Object
(
    [view_count] => 117
)

INFO - 2024-12-10 16:12:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:12:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:12:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:12:13 --> Final output sent to browser
DEBUG - 2024-12-10 16:12:13 --> Total execution time: 0.0687
INFO - 2024-12-10 16:12:14 --> Config Class Initialized
INFO - 2024-12-10 16:12:14 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:12:14 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:12:14 --> Utf8 Class Initialized
INFO - 2024-12-10 16:12:14 --> URI Class Initialized
INFO - 2024-12-10 16:12:14 --> Router Class Initialized
INFO - 2024-12-10 16:12:14 --> Output Class Initialized
INFO - 2024-12-10 16:12:14 --> Security Class Initialized
DEBUG - 2024-12-10 16:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:12:14 --> CSRF cookie sent
INFO - 2024-12-10 16:12:14 --> Input Class Initialized
INFO - 2024-12-10 16:12:14 --> Language Class Initialized
ERROR - 2024-12-10 16:12:14 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 16:15:23 --> Config Class Initialized
INFO - 2024-12-10 16:15:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:15:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:15:23 --> Utf8 Class Initialized
INFO - 2024-12-10 16:15:23 --> URI Class Initialized
INFO - 2024-12-10 16:15:23 --> Router Class Initialized
INFO - 2024-12-10 16:15:23 --> Output Class Initialized
INFO - 2024-12-10 16:15:23 --> Security Class Initialized
DEBUG - 2024-12-10 16:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:15:23 --> CSRF cookie sent
INFO - 2024-12-10 16:15:23 --> Input Class Initialized
INFO - 2024-12-10 16:15:23 --> Language Class Initialized
INFO - 2024-12-10 16:15:23 --> Loader Class Initialized
INFO - 2024-12-10 16:15:23 --> Helper loaded: url_helper
INFO - 2024-12-10 16:15:23 --> Helper loaded: form_helper
INFO - 2024-12-10 16:15:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:15:23 --> Form Validation Class Initialized
INFO - 2024-12-10 16:15:23 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:15:23 --> Controller Class Initialized
INFO - 2024-12-10 16:15:23 --> Model "User_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "Category_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "Review_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "News_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:15:23 --> Config Class Initialized
INFO - 2024-12-10 16:15:23 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:15:23 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:15:23 --> Utf8 Class Initialized
INFO - 2024-12-10 16:15:23 --> URI Class Initialized
INFO - 2024-12-10 16:15:23 --> Router Class Initialized
INFO - 2024-12-10 16:15:23 --> Output Class Initialized
INFO - 2024-12-10 16:15:23 --> Security Class Initialized
DEBUG - 2024-12-10 16:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:15:23 --> CSRF cookie sent
INFO - 2024-12-10 16:15:23 --> Input Class Initialized
INFO - 2024-12-10 16:15:23 --> Language Class Initialized
INFO - 2024-12-10 16:15:23 --> Loader Class Initialized
INFO - 2024-12-10 16:15:23 --> Helper loaded: url_helper
INFO - 2024-12-10 16:15:23 --> Helper loaded: form_helper
INFO - 2024-12-10 16:15:23 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:15:23 --> Form Validation Class Initialized
INFO - 2024-12-10 16:15:23 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:15:23 --> Controller Class Initialized
INFO - 2024-12-10 16:15:23 --> Model "User_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "Category_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "Review_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "News_model" initialized
INFO - 2024-12-10 16:15:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:15:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:15:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:15:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:15:23 --> Final output sent to browser
DEBUG - 2024-12-10 16:15:23 --> Total execution time: 0.0470
INFO - 2024-12-10 16:15:27 --> Config Class Initialized
INFO - 2024-12-10 16:15:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:15:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:15:27 --> Utf8 Class Initialized
INFO - 2024-12-10 16:15:27 --> URI Class Initialized
INFO - 2024-12-10 16:15:27 --> Router Class Initialized
INFO - 2024-12-10 16:15:27 --> Output Class Initialized
INFO - 2024-12-10 16:15:27 --> Security Class Initialized
DEBUG - 2024-12-10 16:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:15:27 --> CSRF cookie sent
INFO - 2024-12-10 16:15:27 --> Input Class Initialized
INFO - 2024-12-10 16:15:27 --> Language Class Initialized
INFO - 2024-12-10 16:15:27 --> Loader Class Initialized
INFO - 2024-12-10 16:15:27 --> Helper loaded: url_helper
INFO - 2024-12-10 16:15:27 --> Helper loaded: form_helper
INFO - 2024-12-10 16:15:27 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:15:27 --> Form Validation Class Initialized
INFO - 2024-12-10 16:15:27 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:15:27 --> Controller Class Initialized
INFO - 2024-12-10 16:15:27 --> Model "User_model" initialized
INFO - 2024-12-10 16:15:27 --> Model "Category_model" initialized
INFO - 2024-12-10 16:15:27 --> Model "Review_model" initialized
INFO - 2024-12-10 16:15:27 --> Model "News_model" initialized
INFO - 2024-12-10 16:15:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:15:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:15:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:15:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-10 16:15:27 --> Final output sent to browser
DEBUG - 2024-12-10 16:15:27 --> Total execution time: 0.0513
INFO - 2024-12-10 16:18:57 --> Config Class Initialized
INFO - 2024-12-10 16:18:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:18:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:18:57 --> Utf8 Class Initialized
INFO - 2024-12-10 16:18:57 --> URI Class Initialized
INFO - 2024-12-10 16:18:57 --> Router Class Initialized
INFO - 2024-12-10 16:18:57 --> Output Class Initialized
INFO - 2024-12-10 16:18:57 --> Security Class Initialized
DEBUG - 2024-12-10 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:18:57 --> CSRF cookie sent
INFO - 2024-12-10 16:18:57 --> Input Class Initialized
INFO - 2024-12-10 16:18:57 --> Language Class Initialized
INFO - 2024-12-10 16:18:57 --> Loader Class Initialized
INFO - 2024-12-10 16:18:57 --> Helper loaded: url_helper
INFO - 2024-12-10 16:18:57 --> Helper loaded: form_helper
INFO - 2024-12-10 16:18:57 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:18:57 --> Form Validation Class Initialized
INFO - 2024-12-10 16:18:57 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:18:57 --> Controller Class Initialized
INFO - 2024-12-10 16:18:57 --> Model "User_model" initialized
INFO - 2024-12-10 16:18:57 --> Model "Category_model" initialized
INFO - 2024-12-10 16:18:57 --> Model "Review_model" initialized
INFO - 2024-12-10 16:18:57 --> Model "News_model" initialized
INFO - 2024-12-10 16:18:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:18:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:18:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:18:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:18:57 --> Final output sent to browser
DEBUG - 2024-12-10 16:18:57 --> Total execution time: 0.0796
INFO - 2024-12-10 16:19:00 --> Config Class Initialized
INFO - 2024-12-10 16:19:00 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:19:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:19:00 --> Utf8 Class Initialized
INFO - 2024-12-10 16:19:00 --> URI Class Initialized
INFO - 2024-12-10 16:19:00 --> Router Class Initialized
INFO - 2024-12-10 16:19:00 --> Output Class Initialized
INFO - 2024-12-10 16:19:00 --> Security Class Initialized
DEBUG - 2024-12-10 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:19:00 --> CSRF cookie sent
INFO - 2024-12-10 16:19:00 --> Input Class Initialized
INFO - 2024-12-10 16:19:00 --> Language Class Initialized
INFO - 2024-12-10 16:19:00 --> Loader Class Initialized
INFO - 2024-12-10 16:19:00 --> Helper loaded: url_helper
INFO - 2024-12-10 16:19:00 --> Helper loaded: form_helper
INFO - 2024-12-10 16:19:00 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:19:00 --> Form Validation Class Initialized
INFO - 2024-12-10 16:19:00 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:19:00 --> Controller Class Initialized
INFO - 2024-12-10 16:19:00 --> Model "User_model" initialized
INFO - 2024-12-10 16:19:00 --> Model "Category_model" initialized
INFO - 2024-12-10 16:19:00 --> Model "Review_model" initialized
INFO - 2024-12-10 16:19:00 --> Model "News_model" initialized
INFO - 2024-12-10 16:19:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:19:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:19:00 --> Final output sent to browser
DEBUG - 2024-12-10 16:19:00 --> Total execution time: 0.0476
INFO - 2024-12-10 16:21:12 --> Config Class Initialized
INFO - 2024-12-10 16:21:12 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:21:12 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:21:12 --> Utf8 Class Initialized
INFO - 2024-12-10 16:21:12 --> URI Class Initialized
INFO - 2024-12-10 16:21:12 --> Router Class Initialized
INFO - 2024-12-10 16:21:12 --> Output Class Initialized
INFO - 2024-12-10 16:21:12 --> Security Class Initialized
DEBUG - 2024-12-10 16:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:21:12 --> CSRF cookie sent
INFO - 2024-12-10 16:21:12 --> Input Class Initialized
INFO - 2024-12-10 16:21:12 --> Language Class Initialized
INFO - 2024-12-10 16:21:12 --> Loader Class Initialized
INFO - 2024-12-10 16:21:12 --> Helper loaded: url_helper
INFO - 2024-12-10 16:21:12 --> Helper loaded: form_helper
INFO - 2024-12-10 16:21:12 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:21:12 --> Form Validation Class Initialized
INFO - 2024-12-10 16:21:12 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:21:12 --> Controller Class Initialized
INFO - 2024-12-10 16:21:12 --> Model "User_model" initialized
INFO - 2024-12-10 16:21:12 --> Model "Category_model" initialized
INFO - 2024-12-10 16:21:12 --> Model "Review_model" initialized
INFO - 2024-12-10 16:21:12 --> Model "News_model" initialized
INFO - 2024-12-10 16:21:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:21:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:21:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:21:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:21:12 --> Final output sent to browser
DEBUG - 2024-12-10 16:21:12 --> Total execution time: 0.0403
INFO - 2024-12-10 16:21:22 --> Config Class Initialized
INFO - 2024-12-10 16:21:22 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:21:22 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:21:22 --> Utf8 Class Initialized
INFO - 2024-12-10 16:21:22 --> URI Class Initialized
INFO - 2024-12-10 16:21:22 --> Router Class Initialized
INFO - 2024-12-10 16:21:22 --> Output Class Initialized
INFO - 2024-12-10 16:21:22 --> Security Class Initialized
DEBUG - 2024-12-10 16:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:21:22 --> CSRF cookie sent
INFO - 2024-12-10 16:21:22 --> Input Class Initialized
INFO - 2024-12-10 16:21:22 --> Language Class Initialized
INFO - 2024-12-10 16:21:22 --> Loader Class Initialized
INFO - 2024-12-10 16:21:22 --> Helper loaded: url_helper
INFO - 2024-12-10 16:21:22 --> Helper loaded: form_helper
INFO - 2024-12-10 16:21:22 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:21:22 --> Form Validation Class Initialized
INFO - 2024-12-10 16:21:22 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:21:22 --> Controller Class Initialized
INFO - 2024-12-10 16:21:22 --> Model "User_model" initialized
INFO - 2024-12-10 16:21:22 --> Model "Category_model" initialized
INFO - 2024-12-10 16:21:22 --> Model "Review_model" initialized
INFO - 2024-12-10 16:21:22 --> Model "News_model" initialized
INFO - 2024-12-10 16:21:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:21:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:21:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:21:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:21:22 --> Final output sent to browser
DEBUG - 2024-12-10 16:21:22 --> Total execution time: 0.0607
INFO - 2024-12-10 16:21:49 --> Config Class Initialized
INFO - 2024-12-10 16:21:49 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:21:49 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:21:49 --> Utf8 Class Initialized
INFO - 2024-12-10 16:21:49 --> URI Class Initialized
INFO - 2024-12-10 16:21:49 --> Router Class Initialized
INFO - 2024-12-10 16:21:49 --> Output Class Initialized
INFO - 2024-12-10 16:21:49 --> Security Class Initialized
DEBUG - 2024-12-10 16:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:21:49 --> CSRF cookie sent
INFO - 2024-12-10 16:21:49 --> Input Class Initialized
INFO - 2024-12-10 16:21:49 --> Language Class Initialized
INFO - 2024-12-10 16:21:49 --> Loader Class Initialized
INFO - 2024-12-10 16:21:49 --> Helper loaded: url_helper
INFO - 2024-12-10 16:21:49 --> Helper loaded: form_helper
INFO - 2024-12-10 16:21:49 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:21:49 --> Form Validation Class Initialized
INFO - 2024-12-10 16:21:49 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:21:49 --> Controller Class Initialized
INFO - 2024-12-10 16:21:49 --> Model "User_model" initialized
INFO - 2024-12-10 16:21:49 --> Model "Category_model" initialized
INFO - 2024-12-10 16:21:49 --> Model "Review_model" initialized
INFO - 2024-12-10 16:21:49 --> Model "News_model" initialized
INFO - 2024-12-10 16:21:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:21:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:21:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:21:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-10 16:21:49 --> Final output sent to browser
DEBUG - 2024-12-10 16:21:49 --> Total execution time: 0.0462
INFO - 2024-12-10 16:21:57 --> Config Class Initialized
INFO - 2024-12-10 16:21:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:21:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:21:57 --> Utf8 Class Initialized
INFO - 2024-12-10 16:21:57 --> URI Class Initialized
INFO - 2024-12-10 16:21:57 --> Router Class Initialized
INFO - 2024-12-10 16:21:57 --> Output Class Initialized
INFO - 2024-12-10 16:21:57 --> Security Class Initialized
DEBUG - 2024-12-10 16:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:21:57 --> CSRF cookie sent
INFO - 2024-12-10 16:21:57 --> CSRF token verified
INFO - 2024-12-10 16:21:57 --> Input Class Initialized
INFO - 2024-12-10 16:21:57 --> Language Class Initialized
INFO - 2024-12-10 16:21:57 --> Loader Class Initialized
INFO - 2024-12-10 16:21:57 --> Helper loaded: url_helper
INFO - 2024-12-10 16:21:57 --> Helper loaded: form_helper
INFO - 2024-12-10 16:21:57 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:21:57 --> Form Validation Class Initialized
INFO - 2024-12-10 16:21:57 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:21:57 --> Controller Class Initialized
INFO - 2024-12-10 16:21:57 --> Model "User_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "Category_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "Review_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "News_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:21:57 --> Config Class Initialized
INFO - 2024-12-10 16:21:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:21:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:21:57 --> Utf8 Class Initialized
INFO - 2024-12-10 16:21:57 --> URI Class Initialized
INFO - 2024-12-10 16:21:57 --> Router Class Initialized
INFO - 2024-12-10 16:21:57 --> Output Class Initialized
INFO - 2024-12-10 16:21:57 --> Security Class Initialized
DEBUG - 2024-12-10 16:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:21:57 --> CSRF cookie sent
INFO - 2024-12-10 16:21:57 --> Input Class Initialized
INFO - 2024-12-10 16:21:57 --> Language Class Initialized
INFO - 2024-12-10 16:21:57 --> Loader Class Initialized
INFO - 2024-12-10 16:21:57 --> Helper loaded: url_helper
INFO - 2024-12-10 16:21:57 --> Helper loaded: form_helper
INFO - 2024-12-10 16:21:57 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:21:57 --> Form Validation Class Initialized
INFO - 2024-12-10 16:21:57 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:21:57 --> Controller Class Initialized
INFO - 2024-12-10 16:21:57 --> Model "User_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "Category_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "Review_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "News_model" initialized
INFO - 2024-12-10 16:21:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:21:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:21:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:21:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-10 16:21:57 --> Final output sent to browser
DEBUG - 2024-12-10 16:21:57 --> Total execution time: 0.0369
INFO - 2024-12-10 16:22:01 --> Config Class Initialized
INFO - 2024-12-10 16:22:01 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:22:01 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:22:01 --> Utf8 Class Initialized
INFO - 2024-12-10 16:22:01 --> URI Class Initialized
INFO - 2024-12-10 16:22:01 --> Router Class Initialized
INFO - 2024-12-10 16:22:01 --> Output Class Initialized
INFO - 2024-12-10 16:22:01 --> Security Class Initialized
DEBUG - 2024-12-10 16:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:22:01 --> CSRF cookie sent
INFO - 2024-12-10 16:22:01 --> CSRF token verified
INFO - 2024-12-10 16:22:01 --> Input Class Initialized
INFO - 2024-12-10 16:22:01 --> Language Class Initialized
INFO - 2024-12-10 16:22:01 --> Loader Class Initialized
INFO - 2024-12-10 16:22:01 --> Helper loaded: url_helper
INFO - 2024-12-10 16:22:01 --> Helper loaded: form_helper
INFO - 2024-12-10 16:22:01 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:22:01 --> Form Validation Class Initialized
INFO - 2024-12-10 16:22:01 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:22:01 --> Controller Class Initialized
INFO - 2024-12-10 16:22:01 --> Model "User_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "Category_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "Review_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "News_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-10 16:22:01 --> Config Class Initialized
INFO - 2024-12-10 16:22:01 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:22:01 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:22:01 --> Utf8 Class Initialized
INFO - 2024-12-10 16:22:01 --> URI Class Initialized
INFO - 2024-12-10 16:22:01 --> Router Class Initialized
INFO - 2024-12-10 16:22:01 --> Output Class Initialized
INFO - 2024-12-10 16:22:01 --> Security Class Initialized
DEBUG - 2024-12-10 16:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:22:01 --> CSRF cookie sent
INFO - 2024-12-10 16:22:01 --> Input Class Initialized
INFO - 2024-12-10 16:22:01 --> Language Class Initialized
INFO - 2024-12-10 16:22:01 --> Loader Class Initialized
INFO - 2024-12-10 16:22:01 --> Helper loaded: url_helper
INFO - 2024-12-10 16:22:01 --> Helper loaded: form_helper
INFO - 2024-12-10 16:22:01 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:22:01 --> Form Validation Class Initialized
INFO - 2024-12-10 16:22:01 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:22:01 --> Controller Class Initialized
INFO - 2024-12-10 16:22:01 --> Model "User_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "Category_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "Review_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "News_model" initialized
INFO - 2024-12-10 16:22:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:22:01 --> Query result: stdClass Object
(
    [view_count] => 118
)

INFO - 2024-12-10 16:22:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:22:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:22:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:22:01 --> Final output sent to browser
DEBUG - 2024-12-10 16:22:01 --> Total execution time: 0.0620
INFO - 2024-12-10 16:22:02 --> Config Class Initialized
INFO - 2024-12-10 16:22:02 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:22:02 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:22:02 --> Utf8 Class Initialized
INFO - 2024-12-10 16:22:02 --> URI Class Initialized
INFO - 2024-12-10 16:22:02 --> Router Class Initialized
INFO - 2024-12-10 16:22:02 --> Output Class Initialized
INFO - 2024-12-10 16:22:02 --> Security Class Initialized
DEBUG - 2024-12-10 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:22:02 --> CSRF cookie sent
INFO - 2024-12-10 16:22:02 --> Input Class Initialized
INFO - 2024-12-10 16:22:02 --> Language Class Initialized
ERROR - 2024-12-10 16:22:02 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 16:25:35 --> Config Class Initialized
INFO - 2024-12-10 16:25:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:25:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:25:35 --> Utf8 Class Initialized
INFO - 2024-12-10 16:25:35 --> URI Class Initialized
INFO - 2024-12-10 16:25:35 --> Router Class Initialized
INFO - 2024-12-10 16:25:35 --> Output Class Initialized
INFO - 2024-12-10 16:25:35 --> Security Class Initialized
DEBUG - 2024-12-10 16:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:25:35 --> CSRF cookie sent
INFO - 2024-12-10 16:25:35 --> Input Class Initialized
INFO - 2024-12-10 16:25:35 --> Language Class Initialized
INFO - 2024-12-10 16:25:35 --> Loader Class Initialized
INFO - 2024-12-10 16:25:35 --> Helper loaded: url_helper
INFO - 2024-12-10 16:25:35 --> Helper loaded: form_helper
INFO - 2024-12-10 16:25:35 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:25:35 --> Form Validation Class Initialized
INFO - 2024-12-10 16:25:35 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:25:35 --> Controller Class Initialized
INFO - 2024-12-10 16:25:35 --> Model "User_model" initialized
INFO - 2024-12-10 16:25:35 --> Model "Category_model" initialized
INFO - 2024-12-10 16:25:35 --> Model "Review_model" initialized
INFO - 2024-12-10 16:25:35 --> Model "News_model" initialized
INFO - 2024-12-10 16:25:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:25:35 --> Query result: stdClass Object
(
    [view_count] => 119
)

INFO - 2024-12-10 16:25:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:25:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:25:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:25:35 --> Final output sent to browser
DEBUG - 2024-12-10 16:25:35 --> Total execution time: 0.0650
INFO - 2024-12-10 16:25:35 --> Config Class Initialized
INFO - 2024-12-10 16:25:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:25:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:25:35 --> Utf8 Class Initialized
INFO - 2024-12-10 16:25:35 --> URI Class Initialized
INFO - 2024-12-10 16:25:35 --> Router Class Initialized
INFO - 2024-12-10 16:25:35 --> Output Class Initialized
INFO - 2024-12-10 16:25:35 --> Security Class Initialized
DEBUG - 2024-12-10 16:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:25:35 --> CSRF cookie sent
INFO - 2024-12-10 16:25:35 --> Input Class Initialized
INFO - 2024-12-10 16:25:35 --> Language Class Initialized
ERROR - 2024-12-10 16:25:35 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 16:26:19 --> Config Class Initialized
INFO - 2024-12-10 16:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:26:19 --> Utf8 Class Initialized
INFO - 2024-12-10 16:26:19 --> URI Class Initialized
INFO - 2024-12-10 16:26:19 --> Router Class Initialized
INFO - 2024-12-10 16:26:19 --> Output Class Initialized
INFO - 2024-12-10 16:26:19 --> Security Class Initialized
DEBUG - 2024-12-10 16:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:26:19 --> CSRF cookie sent
INFO - 2024-12-10 16:26:19 --> Input Class Initialized
INFO - 2024-12-10 16:26:19 --> Language Class Initialized
INFO - 2024-12-10 16:26:19 --> Loader Class Initialized
INFO - 2024-12-10 16:26:19 --> Helper loaded: url_helper
INFO - 2024-12-10 16:26:19 --> Helper loaded: form_helper
INFO - 2024-12-10 16:26:19 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:26:19 --> Form Validation Class Initialized
INFO - 2024-12-10 16:26:19 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:26:19 --> Controller Class Initialized
INFO - 2024-12-10 16:26:19 --> Model "User_model" initialized
INFO - 2024-12-10 16:26:19 --> Model "Category_model" initialized
INFO - 2024-12-10 16:26:19 --> Model "Review_model" initialized
INFO - 2024-12-10 16:26:19 --> Model "News_model" initialized
INFO - 2024-12-10 16:26:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:26:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:26:19 --> Query result: stdClass Object
(
    [view_count] => 120
)

INFO - 2024-12-10 16:26:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:26:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:26:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:26:19 --> Final output sent to browser
DEBUG - 2024-12-10 16:26:19 --> Total execution time: 0.0530
INFO - 2024-12-10 16:26:19 --> Config Class Initialized
INFO - 2024-12-10 16:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:26:19 --> Utf8 Class Initialized
INFO - 2024-12-10 16:26:19 --> URI Class Initialized
INFO - 2024-12-10 16:26:19 --> Router Class Initialized
INFO - 2024-12-10 16:26:19 --> Output Class Initialized
INFO - 2024-12-10 16:26:19 --> Security Class Initialized
DEBUG - 2024-12-10 16:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:26:19 --> CSRF cookie sent
INFO - 2024-12-10 16:26:19 --> Input Class Initialized
INFO - 2024-12-10 16:26:19 --> Language Class Initialized
ERROR - 2024-12-10 16:26:19 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-10 16:27:50 --> Config Class Initialized
INFO - 2024-12-10 16:27:50 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:27:50 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:27:50 --> Utf8 Class Initialized
INFO - 2024-12-10 16:27:50 --> URI Class Initialized
INFO - 2024-12-10 16:27:50 --> Router Class Initialized
INFO - 2024-12-10 16:27:50 --> Output Class Initialized
INFO - 2024-12-10 16:27:50 --> Security Class Initialized
DEBUG - 2024-12-10 16:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:27:50 --> CSRF cookie sent
INFO - 2024-12-10 16:27:50 --> Input Class Initialized
INFO - 2024-12-10 16:27:50 --> Language Class Initialized
INFO - 2024-12-10 16:27:50 --> Loader Class Initialized
INFO - 2024-12-10 16:27:50 --> Helper loaded: url_helper
INFO - 2024-12-10 16:27:50 --> Helper loaded: form_helper
INFO - 2024-12-10 16:27:50 --> Database Driver Class Initialized
DEBUG - 2024-12-10 16:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 16:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 16:27:50 --> Form Validation Class Initialized
INFO - 2024-12-10 16:27:50 --> Model "Culinary_model" initialized
INFO - 2024-12-10 16:27:50 --> Controller Class Initialized
INFO - 2024-12-10 16:27:50 --> Model "User_model" initialized
INFO - 2024-12-10 16:27:50 --> Model "Category_model" initialized
INFO - 2024-12-10 16:27:50 --> Model "Review_model" initialized
INFO - 2024-12-10 16:27:50 --> Model "News_model" initialized
INFO - 2024-12-10 16:27:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-10 16:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-10 16:27:50 --> Query result: stdClass Object
(
    [view_count] => 121
)

INFO - 2024-12-10 16:27:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-10 16:27:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-10 16:27:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-10 16:27:50 --> Final output sent to browser
DEBUG - 2024-12-10 16:27:50 --> Total execution time: 0.0784
INFO - 2024-12-10 16:27:50 --> Config Class Initialized
INFO - 2024-12-10 16:27:50 --> Hooks Class Initialized
DEBUG - 2024-12-10 16:27:50 --> UTF-8 Support Enabled
INFO - 2024-12-10 16:27:50 --> Utf8 Class Initialized
INFO - 2024-12-10 16:27:50 --> URI Class Initialized
INFO - 2024-12-10 16:27:50 --> Router Class Initialized
INFO - 2024-12-10 16:27:50 --> Output Class Initialized
INFO - 2024-12-10 16:27:50 --> Security Class Initialized
DEBUG - 2024-12-10 16:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 16:27:50 --> CSRF cookie sent
INFO - 2024-12-10 16:27:50 --> Input Class Initialized
INFO - 2024-12-10 16:27:50 --> Language Class Initialized
ERROR - 2024-12-10 16:27:50 --> 404 Page Not Found: Path-to-your-imagejpg/index
