<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-15 09:40:35 --> Config Class Initialized
INFO - 2024-12-15 09:40:35 --> Hooks Class Initialized
DEBUG - 2024-12-15 09:40:35 --> UTF-8 Support Enabled
INFO - 2024-12-15 09:40:35 --> Utf8 Class Initialized
INFO - 2024-12-15 09:40:35 --> URI Class Initialized
DEBUG - 2024-12-15 09:40:35 --> No URI present. Default controller set.
INFO - 2024-12-15 09:40:35 --> Router Class Initialized
INFO - 2024-12-15 09:40:35 --> Output Class Initialized
INFO - 2024-12-15 09:40:35 --> Security Class Initialized
DEBUG - 2024-12-15 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 09:40:35 --> CSRF cookie sent
INFO - 2024-12-15 09:40:35 --> Input Class Initialized
INFO - 2024-12-15 09:40:35 --> Language Class Initialized
INFO - 2024-12-15 09:40:35 --> Loader Class Initialized
INFO - 2024-12-15 09:40:35 --> Helper loaded: url_helper
INFO - 2024-12-15 09:40:35 --> Helper loaded: form_helper
INFO - 2024-12-15 09:40:35 --> Database Driver Class Initialized
DEBUG - 2024-12-15 09:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 09:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 09:40:35 --> Form Validation Class Initialized
INFO - 2024-12-15 09:40:35 --> Model "Culinary_model" initialized
INFO - 2024-12-15 09:40:35 --> Controller Class Initialized
INFO - 2024-12-15 09:40:35 --> Model "User_model" initialized
INFO - 2024-12-15 09:40:35 --> Model "Category_model" initialized
INFO - 2024-12-15 09:40:35 --> Model "Review_model" initialized
INFO - 2024-12-15 09:40:35 --> Model "News_model" initialized
INFO - 2024-12-15 09:40:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 09:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-15 09:40:35 --> Query result: stdClass Object
(
    [view_count] => 181
)

INFO - 2024-12-15 09:40:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-15 09:40:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-15 09:40:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-15 09:40:35 --> Final output sent to browser
DEBUG - 2024-12-15 09:40:35 --> Total execution time: 0.3667
INFO - 2024-12-15 14:57:52 --> Config Class Initialized
INFO - 2024-12-15 14:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:57:52 --> Utf8 Class Initialized
INFO - 2024-12-15 14:57:52 --> URI Class Initialized
DEBUG - 2024-12-15 14:57:52 --> No URI present. Default controller set.
INFO - 2024-12-15 14:57:52 --> Router Class Initialized
INFO - 2024-12-15 14:57:52 --> Output Class Initialized
INFO - 2024-12-15 14:57:52 --> Security Class Initialized
DEBUG - 2024-12-15 14:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:57:52 --> CSRF cookie sent
INFO - 2024-12-15 14:57:52 --> Input Class Initialized
INFO - 2024-12-15 14:57:52 --> Language Class Initialized
INFO - 2024-12-15 14:57:52 --> Loader Class Initialized
INFO - 2024-12-15 14:57:52 --> Helper loaded: url_helper
INFO - 2024-12-15 14:57:52 --> Helper loaded: form_helper
INFO - 2024-12-15 14:57:53 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:57:53 --> Form Validation Class Initialized
INFO - 2024-12-15 14:57:53 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:57:53 --> Controller Class Initialized
INFO - 2024-12-15 14:57:53 --> Model "User_model" initialized
INFO - 2024-12-15 14:57:53 --> Model "Category_model" initialized
INFO - 2024-12-15 14:57:53 --> Model "Review_model" initialized
INFO - 2024-12-15 14:57:53 --> Model "News_model" initialized
INFO - 2024-12-15 14:57:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:57:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-15 14:57:53 --> Query result: stdClass Object
(
    [view_count] => 182
)

INFO - 2024-12-15 14:57:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-15 14:57:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-15 14:57:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-15 14:57:53 --> Final output sent to browser
DEBUG - 2024-12-15 14:57:53 --> Total execution time: 1.0256
INFO - 2024-12-15 14:57:56 --> Config Class Initialized
INFO - 2024-12-15 14:57:56 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:57:56 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:57:56 --> Utf8 Class Initialized
INFO - 2024-12-15 14:57:56 --> URI Class Initialized
INFO - 2024-12-15 14:57:56 --> Router Class Initialized
INFO - 2024-12-15 14:57:56 --> Output Class Initialized
INFO - 2024-12-15 14:57:56 --> Security Class Initialized
DEBUG - 2024-12-15 14:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:57:56 --> CSRF cookie sent
INFO - 2024-12-15 14:57:56 --> Input Class Initialized
INFO - 2024-12-15 14:57:56 --> Language Class Initialized
INFO - 2024-12-15 14:57:56 --> Loader Class Initialized
INFO - 2024-12-15 14:57:56 --> Helper loaded: url_helper
INFO - 2024-12-15 14:57:56 --> Helper loaded: form_helper
INFO - 2024-12-15 14:57:56 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:57:56 --> Form Validation Class Initialized
INFO - 2024-12-15 14:57:56 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:57:56 --> Controller Class Initialized
INFO - 2024-12-15 14:57:56 --> Model "User_model" initialized
INFO - 2024-12-15 14:57:56 --> Model "Category_model" initialized
INFO - 2024-12-15 14:57:56 --> Model "Review_model" initialized
INFO - 2024-12-15 14:57:56 --> Model "News_model" initialized
INFO - 2024-12-15 14:57:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:57:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-15 14:57:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-15 14:57:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-15 14:57:56 --> Final output sent to browser
DEBUG - 2024-12-15 14:57:56 --> Total execution time: 0.4812
INFO - 2024-12-15 14:57:59 --> Config Class Initialized
INFO - 2024-12-15 14:57:59 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:57:59 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:57:59 --> Utf8 Class Initialized
INFO - 2024-12-15 14:57:59 --> URI Class Initialized
INFO - 2024-12-15 14:57:59 --> Router Class Initialized
INFO - 2024-12-15 14:57:59 --> Output Class Initialized
INFO - 2024-12-15 14:57:59 --> Security Class Initialized
DEBUG - 2024-12-15 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:57:59 --> CSRF cookie sent
INFO - 2024-12-15 14:57:59 --> CSRF token verified
INFO - 2024-12-15 14:57:59 --> Input Class Initialized
INFO - 2024-12-15 14:57:59 --> Language Class Initialized
INFO - 2024-12-15 14:57:59 --> Loader Class Initialized
INFO - 2024-12-15 14:57:59 --> Helper loaded: url_helper
INFO - 2024-12-15 14:57:59 --> Helper loaded: form_helper
INFO - 2024-12-15 14:57:59 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:57:59 --> Form Validation Class Initialized
INFO - 2024-12-15 14:57:59 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:57:59 --> Controller Class Initialized
INFO - 2024-12-15 14:57:59 --> Model "User_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "Category_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "Review_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "News_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:57:59 --> Config Class Initialized
INFO - 2024-12-15 14:57:59 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:57:59 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:57:59 --> Utf8 Class Initialized
INFO - 2024-12-15 14:57:59 --> URI Class Initialized
INFO - 2024-12-15 14:57:59 --> Router Class Initialized
INFO - 2024-12-15 14:57:59 --> Output Class Initialized
INFO - 2024-12-15 14:57:59 --> Security Class Initialized
DEBUG - 2024-12-15 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:57:59 --> CSRF cookie sent
INFO - 2024-12-15 14:57:59 --> Input Class Initialized
INFO - 2024-12-15 14:57:59 --> Language Class Initialized
INFO - 2024-12-15 14:57:59 --> Loader Class Initialized
INFO - 2024-12-15 14:57:59 --> Helper loaded: url_helper
INFO - 2024-12-15 14:57:59 --> Helper loaded: form_helper
INFO - 2024-12-15 14:57:59 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:57:59 --> Form Validation Class Initialized
INFO - 2024-12-15 14:57:59 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:57:59 --> Controller Class Initialized
INFO - 2024-12-15 14:57:59 --> Model "Review_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "Category_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "User_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 14:57:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:57:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-15 14:57:59 --> Query result: stdClass Object
(
    [view_count] => 182
)

INFO - 2024-12-15 14:58:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-15 14:58:00 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:00 --> Total execution time: 0.2406
INFO - 2024-12-15 14:58:04 --> Config Class Initialized
INFO - 2024-12-15 14:58:04 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:58:04 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:58:04 --> Utf8 Class Initialized
INFO - 2024-12-15 14:58:04 --> URI Class Initialized
INFO - 2024-12-15 14:58:04 --> Router Class Initialized
INFO - 2024-12-15 14:58:04 --> Output Class Initialized
INFO - 2024-12-15 14:58:04 --> Security Class Initialized
DEBUG - 2024-12-15 14:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:58:04 --> CSRF cookie sent
INFO - 2024-12-15 14:58:04 --> Input Class Initialized
INFO - 2024-12-15 14:58:04 --> Language Class Initialized
INFO - 2024-12-15 14:58:04 --> Loader Class Initialized
INFO - 2024-12-15 14:58:04 --> Helper loaded: url_helper
INFO - 2024-12-15 14:58:04 --> Helper loaded: form_helper
INFO - 2024-12-15 14:58:04 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:58:04 --> Form Validation Class Initialized
INFO - 2024-12-15 14:58:04 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:58:04 --> Controller Class Initialized
INFO - 2024-12-15 14:58:04 --> Model "Review_model" initialized
INFO - 2024-12-15 14:58:04 --> Model "Category_model" initialized
INFO - 2024-12-15 14:58:04 --> Model "User_model" initialized
INFO - 2024-12-15 14:58:04 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 14:58:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-15 14:58:04 --> Pagination Class Initialized
INFO - 2024-12-15 14:58:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-15 14:58:04 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:04 --> Total execution time: 0.0866
INFO - 2024-12-15 14:58:13 --> Config Class Initialized
INFO - 2024-12-15 14:58:13 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:58:13 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:58:13 --> Utf8 Class Initialized
INFO - 2024-12-15 14:58:13 --> URI Class Initialized
INFO - 2024-12-15 14:58:13 --> Router Class Initialized
INFO - 2024-12-15 14:58:13 --> Output Class Initialized
INFO - 2024-12-15 14:58:13 --> Security Class Initialized
DEBUG - 2024-12-15 14:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:58:13 --> CSRF cookie sent
INFO - 2024-12-15 14:58:13 --> Input Class Initialized
INFO - 2024-12-15 14:58:13 --> Language Class Initialized
INFO - 2024-12-15 14:58:13 --> Loader Class Initialized
INFO - 2024-12-15 14:58:13 --> Helper loaded: url_helper
INFO - 2024-12-15 14:58:13 --> Helper loaded: form_helper
INFO - 2024-12-15 14:58:13 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:58:13 --> Form Validation Class Initialized
INFO - 2024-12-15 14:58:13 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:58:13 --> Controller Class Initialized
INFO - 2024-12-15 14:58:13 --> Model "Review_model" initialized
INFO - 2024-12-15 14:58:13 --> Model "Category_model" initialized
INFO - 2024-12-15 14:58:13 --> Model "User_model" initialized
INFO - 2024-12-15 14:58:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 14:58:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-15 14:58:13 --> Pagination Class Initialized
INFO - 2024-12-15 14:58:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-15 14:58:13 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:13 --> Total execution time: 0.3360
INFO - 2024-12-15 14:58:14 --> Config Class Initialized
INFO - 2024-12-15 14:58:14 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:58:14 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:58:14 --> Utf8 Class Initialized
INFO - 2024-12-15 14:58:14 --> URI Class Initialized
INFO - 2024-12-15 14:58:14 --> Router Class Initialized
INFO - 2024-12-15 14:58:14 --> Output Class Initialized
INFO - 2024-12-15 14:58:14 --> Security Class Initialized
DEBUG - 2024-12-15 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:58:14 --> CSRF cookie sent
INFO - 2024-12-15 14:58:14 --> Input Class Initialized
INFO - 2024-12-15 14:58:14 --> Language Class Initialized
INFO - 2024-12-15 14:58:14 --> Loader Class Initialized
INFO - 2024-12-15 14:58:14 --> Helper loaded: url_helper
INFO - 2024-12-15 14:58:14 --> Helper loaded: form_helper
INFO - 2024-12-15 14:58:14 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:58:14 --> Form Validation Class Initialized
INFO - 2024-12-15 14:58:14 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:58:14 --> Controller Class Initialized
INFO - 2024-12-15 14:58:14 --> Model "Review_model" initialized
INFO - 2024-12-15 14:58:14 --> Model "Category_model" initialized
INFO - 2024-12-15 14:58:14 --> Model "User_model" initialized
INFO - 2024-12-15 14:58:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 14:58:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:58:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-15 14:58:14 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:14 --> Total execution time: 0.0713
INFO - 2024-12-15 14:58:15 --> Config Class Initialized
INFO - 2024-12-15 14:58:15 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:58:15 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:58:15 --> Utf8 Class Initialized
INFO - 2024-12-15 14:58:15 --> URI Class Initialized
INFO - 2024-12-15 14:58:15 --> Router Class Initialized
INFO - 2024-12-15 14:58:15 --> Output Class Initialized
INFO - 2024-12-15 14:58:15 --> Security Class Initialized
DEBUG - 2024-12-15 14:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:58:15 --> CSRF cookie sent
INFO - 2024-12-15 14:58:15 --> Input Class Initialized
INFO - 2024-12-15 14:58:15 --> Language Class Initialized
INFO - 2024-12-15 14:58:15 --> Loader Class Initialized
INFO - 2024-12-15 14:58:15 --> Helper loaded: url_helper
INFO - 2024-12-15 14:58:15 --> Helper loaded: form_helper
INFO - 2024-12-15 14:58:15 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:58:15 --> Form Validation Class Initialized
INFO - 2024-12-15 14:58:15 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:58:15 --> Controller Class Initialized
INFO - 2024-12-15 14:58:15 --> Model "Review_model" initialized
INFO - 2024-12-15 14:58:15 --> Model "Category_model" initialized
INFO - 2024-12-15 14:58:15 --> Model "User_model" initialized
INFO - 2024-12-15 14:58:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 14:58:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:58:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-15 14:58:15 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:15 --> Total execution time: 0.0614
INFO - 2024-12-15 14:58:16 --> Config Class Initialized
INFO - 2024-12-15 14:58:16 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:58:16 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:58:16 --> Utf8 Class Initialized
INFO - 2024-12-15 14:58:16 --> URI Class Initialized
INFO - 2024-12-15 14:58:16 --> Router Class Initialized
INFO - 2024-12-15 14:58:16 --> Output Class Initialized
INFO - 2024-12-15 14:58:16 --> Security Class Initialized
DEBUG - 2024-12-15 14:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:58:16 --> CSRF cookie sent
INFO - 2024-12-15 14:58:16 --> Input Class Initialized
INFO - 2024-12-15 14:58:16 --> Language Class Initialized
INFO - 2024-12-15 14:58:16 --> Loader Class Initialized
INFO - 2024-12-15 14:58:16 --> Helper loaded: url_helper
INFO - 2024-12-15 14:58:16 --> Helper loaded: form_helper
INFO - 2024-12-15 14:58:16 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:58:16 --> Form Validation Class Initialized
INFO - 2024-12-15 14:58:16 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:58:16 --> Controller Class Initialized
INFO - 2024-12-15 14:58:16 --> Model "News_model" initialized
INFO - 2024-12-15 14:58:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-15 14:58:16 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:16 --> Total execution time: 0.0776
INFO - 2024-12-15 14:58:18 --> Config Class Initialized
INFO - 2024-12-15 14:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-15 14:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-15 14:58:18 --> Utf8 Class Initialized
INFO - 2024-12-15 14:58:18 --> URI Class Initialized
INFO - 2024-12-15 14:58:18 --> Router Class Initialized
INFO - 2024-12-15 14:58:18 --> Output Class Initialized
INFO - 2024-12-15 14:58:18 --> Security Class Initialized
DEBUG - 2024-12-15 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 14:58:18 --> CSRF cookie sent
INFO - 2024-12-15 14:58:18 --> Input Class Initialized
INFO - 2024-12-15 14:58:18 --> Language Class Initialized
INFO - 2024-12-15 14:58:18 --> Loader Class Initialized
INFO - 2024-12-15 14:58:18 --> Helper loaded: url_helper
INFO - 2024-12-15 14:58:18 --> Helper loaded: form_helper
INFO - 2024-12-15 14:58:18 --> Database Driver Class Initialized
DEBUG - 2024-12-15 14:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 14:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 14:58:18 --> Form Validation Class Initialized
INFO - 2024-12-15 14:58:18 --> Model "Culinary_model" initialized
INFO - 2024-12-15 14:58:18 --> Controller Class Initialized
INFO - 2024-12-15 14:58:18 --> Model "Review_model" initialized
INFO - 2024-12-15 14:58:18 --> Model "Category_model" initialized
INFO - 2024-12-15 14:58:18 --> Model "User_model" initialized
INFO - 2024-12-15 14:58:18 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 14:58:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 14:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 14:58:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-15 14:58:18 --> Final output sent to browser
DEBUG - 2024-12-15 14:58:18 --> Total execution time: 0.1113
INFO - 2024-12-15 15:01:56 --> Config Class Initialized
INFO - 2024-12-15 15:01:56 --> Hooks Class Initialized
DEBUG - 2024-12-15 15:01:56 --> UTF-8 Support Enabled
INFO - 2024-12-15 15:01:56 --> Utf8 Class Initialized
INFO - 2024-12-15 15:01:56 --> URI Class Initialized
INFO - 2024-12-15 15:01:56 --> Router Class Initialized
INFO - 2024-12-15 15:01:56 --> Output Class Initialized
INFO - 2024-12-15 15:01:56 --> Security Class Initialized
DEBUG - 2024-12-15 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 15:01:56 --> CSRF cookie sent
INFO - 2024-12-15 15:01:56 --> Input Class Initialized
INFO - 2024-12-15 15:01:56 --> Language Class Initialized
INFO - 2024-12-15 15:01:56 --> Loader Class Initialized
INFO - 2024-12-15 15:01:56 --> Helper loaded: url_helper
INFO - 2024-12-15 15:01:56 --> Helper loaded: form_helper
INFO - 2024-12-15 15:01:56 --> Database Driver Class Initialized
DEBUG - 2024-12-15 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 15:01:56 --> Form Validation Class Initialized
INFO - 2024-12-15 15:01:56 --> Model "Culinary_model" initialized
INFO - 2024-12-15 15:01:56 --> Controller Class Initialized
INFO - 2024-12-15 15:01:56 --> Model "Review_model" initialized
INFO - 2024-12-15 15:01:56 --> Model "Category_model" initialized
INFO - 2024-12-15 15:01:56 --> Model "User_model" initialized
INFO - 2024-12-15 15:01:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 15:01:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 15:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 15:01:56 --> Model "Contact_model" initialized
INFO - 2024-12-15 15:01:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-15 15:01:56 --> Final output sent to browser
DEBUG - 2024-12-15 15:01:56 --> Total execution time: 0.2002
INFO - 2024-12-15 15:02:00 --> Config Class Initialized
INFO - 2024-12-15 15:02:00 --> Hooks Class Initialized
DEBUG - 2024-12-15 15:02:00 --> UTF-8 Support Enabled
INFO - 2024-12-15 15:02:00 --> Utf8 Class Initialized
INFO - 2024-12-15 15:02:00 --> URI Class Initialized
INFO - 2024-12-15 15:02:00 --> Router Class Initialized
INFO - 2024-12-15 15:02:00 --> Output Class Initialized
INFO - 2024-12-15 15:02:00 --> Security Class Initialized
DEBUG - 2024-12-15 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 15:02:00 --> CSRF cookie sent
INFO - 2024-12-15 15:02:00 --> Input Class Initialized
INFO - 2024-12-15 15:02:00 --> Language Class Initialized
INFO - 2024-12-15 15:02:00 --> Loader Class Initialized
INFO - 2024-12-15 15:02:00 --> Helper loaded: url_helper
INFO - 2024-12-15 15:02:00 --> Helper loaded: form_helper
INFO - 2024-12-15 15:02:00 --> Database Driver Class Initialized
DEBUG - 2024-12-15 15:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-15 15:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 15:02:00 --> Form Validation Class Initialized
INFO - 2024-12-15 15:02:01 --> Model "Culinary_model" initialized
INFO - 2024-12-15 15:02:01 --> Controller Class Initialized
INFO - 2024-12-15 15:02:01 --> Model "Review_model" initialized
INFO - 2024-12-15 15:02:01 --> Model "Category_model" initialized
INFO - 2024-12-15 15:02:01 --> Model "User_model" initialized
INFO - 2024-12-15 15:02:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-15 15:02:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-15 15:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-15 15:02:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-15 15:02:01 --> Final output sent to browser
DEBUG - 2024-12-15 15:02:01 --> Total execution time: 0.9844
