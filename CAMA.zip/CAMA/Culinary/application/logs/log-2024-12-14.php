<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-14 10:51:36 --> Config Class Initialized
INFO - 2024-12-14 10:51:36 --> Hooks Class Initialized
DEBUG - 2024-12-14 10:51:36 --> UTF-8 Support Enabled
INFO - 2024-12-14 10:51:36 --> Utf8 Class Initialized
INFO - 2024-12-14 10:51:36 --> URI Class Initialized
DEBUG - 2024-12-14 10:51:36 --> No URI present. Default controller set.
INFO - 2024-12-14 10:51:36 --> Router Class Initialized
INFO - 2024-12-14 10:51:36 --> Output Class Initialized
INFO - 2024-12-14 10:51:36 --> Security Class Initialized
DEBUG - 2024-12-14 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 10:51:36 --> CSRF cookie sent
INFO - 2024-12-14 10:51:36 --> Input Class Initialized
INFO - 2024-12-14 10:51:36 --> Language Class Initialized
INFO - 2024-12-14 10:51:36 --> Loader Class Initialized
INFO - 2024-12-14 10:51:36 --> Helper loaded: url_helper
INFO - 2024-12-14 10:51:36 --> Helper loaded: form_helper
INFO - 2024-12-14 10:51:36 --> Database Driver Class Initialized
DEBUG - 2024-12-14 10:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 10:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 10:51:37 --> Form Validation Class Initialized
INFO - 2024-12-14 10:51:37 --> Model "Culinary_model" initialized
INFO - 2024-12-14 10:51:37 --> Controller Class Initialized
INFO - 2024-12-14 10:51:37 --> Model "User_model" initialized
INFO - 2024-12-14 10:51:37 --> Model "Category_model" initialized
INFO - 2024-12-14 10:51:37 --> Model "Review_model" initialized
INFO - 2024-12-14 10:51:37 --> Model "News_model" initialized
INFO - 2024-12-14 10:51:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-14 10:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-14 10:51:37 --> Query result: stdClass Object
(
    [view_count] => 180
)

INFO - 2024-12-14 10:51:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-14 10:51:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-14 10:51:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-14 10:51:37 --> Final output sent to browser
DEBUG - 2024-12-14 10:51:37 --> Total execution time: 0.5777
