<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-01 04:47:19 --> Config Class Initialized
INFO - 2024-12-01 04:47:19 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:19 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:19 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:19 --> URI Class Initialized
INFO - 2024-12-01 04:47:19 --> Router Class Initialized
INFO - 2024-12-01 04:47:19 --> Output Class Initialized
INFO - 2024-12-01 04:47:19 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:19 --> CSRF cookie sent
INFO - 2024-12-01 04:47:19 --> Input Class Initialized
INFO - 2024-12-01 04:47:19 --> Language Class Initialized
INFO - 2024-12-01 04:47:19 --> Loader Class Initialized
INFO - 2024-12-01 04:47:19 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:19 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:19 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:20 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:20 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:20 --> Controller Class Initialized
INFO - 2024-12-01 04:47:20 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:20 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:20 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 04:47:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 04:47:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-01 04:47:20 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:20 --> Total execution time: 1.2549
INFO - 2024-12-01 04:47:27 --> Config Class Initialized
INFO - 2024-12-01 04:47:27 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:27 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:27 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:27 --> URI Class Initialized
INFO - 2024-12-01 04:47:27 --> Router Class Initialized
INFO - 2024-12-01 04:47:27 --> Output Class Initialized
INFO - 2024-12-01 04:47:27 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:27 --> CSRF cookie sent
INFO - 2024-12-01 04:47:27 --> CSRF token verified
INFO - 2024-12-01 04:47:27 --> Input Class Initialized
INFO - 2024-12-01 04:47:27 --> Language Class Initialized
INFO - 2024-12-01 04:47:27 --> Loader Class Initialized
INFO - 2024-12-01 04:47:27 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:27 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:27 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:27 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:27 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:27 --> Controller Class Initialized
INFO - 2024-12-01 04:47:27 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:27 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:27 --> Model "Review_model" initialized
DEBUG - 2024-12-01 04:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:28 --> Config Class Initialized
INFO - 2024-12-01 04:47:28 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:28 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:28 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:28 --> URI Class Initialized
INFO - 2024-12-01 04:47:28 --> Router Class Initialized
INFO - 2024-12-01 04:47:28 --> Output Class Initialized
INFO - 2024-12-01 04:47:28 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:28 --> CSRF cookie sent
INFO - 2024-12-01 04:47:28 --> Input Class Initialized
INFO - 2024-12-01 04:47:28 --> Language Class Initialized
INFO - 2024-12-01 04:47:28 --> Loader Class Initialized
INFO - 2024-12-01 04:47:28 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:28 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:28 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:28 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:28 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:28 --> Controller Class Initialized
INFO - 2024-12-01 04:47:28 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:28 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 04:47:28 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:28 --> Total execution time: 0.2140
INFO - 2024-12-01 04:47:33 --> Config Class Initialized
INFO - 2024-12-01 04:47:33 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:33 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:33 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:33 --> URI Class Initialized
INFO - 2024-12-01 04:47:33 --> Router Class Initialized
INFO - 2024-12-01 04:47:33 --> Output Class Initialized
INFO - 2024-12-01 04:47:33 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:33 --> CSRF cookie sent
INFO - 2024-12-01 04:47:33 --> Input Class Initialized
INFO - 2024-12-01 04:47:33 --> Language Class Initialized
INFO - 2024-12-01 04:47:33 --> Loader Class Initialized
INFO - 2024-12-01 04:47:33 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:33 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:33 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:33 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:33 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:33 --> Controller Class Initialized
INFO - 2024-12-01 04:47:33 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:33 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:33 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 04:47:33 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:33 --> Total execution time: 0.0692
INFO - 2024-12-01 04:47:36 --> Config Class Initialized
INFO - 2024-12-01 04:47:36 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:36 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:36 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:36 --> URI Class Initialized
INFO - 2024-12-01 04:47:36 --> Router Class Initialized
INFO - 2024-12-01 04:47:36 --> Output Class Initialized
INFO - 2024-12-01 04:47:36 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:36 --> CSRF cookie sent
INFO - 2024-12-01 04:47:36 --> Input Class Initialized
INFO - 2024-12-01 04:47:36 --> Language Class Initialized
INFO - 2024-12-01 04:47:36 --> Loader Class Initialized
INFO - 2024-12-01 04:47:36 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:36 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:36 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:36 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:36 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:36 --> Controller Class Initialized
INFO - 2024-12-01 04:47:36 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:36 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kategori.php
INFO - 2024-12-01 04:47:36 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:36 --> Total execution time: 0.0670
INFO - 2024-12-01 04:47:41 --> Config Class Initialized
INFO - 2024-12-01 04:47:41 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:41 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:41 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:41 --> URI Class Initialized
INFO - 2024-12-01 04:47:41 --> Router Class Initialized
INFO - 2024-12-01 04:47:41 --> Output Class Initialized
INFO - 2024-12-01 04:47:41 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:41 --> CSRF cookie sent
INFO - 2024-12-01 04:47:41 --> Input Class Initialized
INFO - 2024-12-01 04:47:41 --> Language Class Initialized
INFO - 2024-12-01 04:47:41 --> Loader Class Initialized
INFO - 2024-12-01 04:47:41 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:41 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:41 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:41 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:41 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:41 --> Controller Class Initialized
INFO - 2024-12-01 04:47:41 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:41 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:41 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 04:47:41 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:41 --> Total execution time: 0.1059
INFO - 2024-12-01 04:47:43 --> Config Class Initialized
INFO - 2024-12-01 04:47:43 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:43 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:43 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:43 --> URI Class Initialized
INFO - 2024-12-01 04:47:43 --> Router Class Initialized
INFO - 2024-12-01 04:47:43 --> Output Class Initialized
INFO - 2024-12-01 04:47:43 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:43 --> CSRF cookie sent
INFO - 2024-12-01 04:47:43 --> Input Class Initialized
INFO - 2024-12-01 04:47:43 --> Language Class Initialized
INFO - 2024-12-01 04:47:43 --> Loader Class Initialized
INFO - 2024-12-01 04:47:43 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:43 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:43 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:43 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:43 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:43 --> Controller Class Initialized
INFO - 2024-12-01 04:47:43 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:43 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-01 04:47:43 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:43 --> Total execution time: 0.1108
INFO - 2024-12-01 04:47:44 --> Config Class Initialized
INFO - 2024-12-01 04:47:44 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:44 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:44 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:44 --> URI Class Initialized
INFO - 2024-12-01 04:47:44 --> Router Class Initialized
INFO - 2024-12-01 04:47:44 --> Output Class Initialized
INFO - 2024-12-01 04:47:44 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:44 --> CSRF cookie sent
INFO - 2024-12-01 04:47:44 --> CSRF token verified
INFO - 2024-12-01 04:47:44 --> Input Class Initialized
INFO - 2024-12-01 04:47:44 --> Language Class Initialized
INFO - 2024-12-01 04:47:44 --> Loader Class Initialized
INFO - 2024-12-01 04:47:44 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:44 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:44 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:44 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:44 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:44 --> Controller Class Initialized
INFO - 2024-12-01 04:47:44 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:44 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:44 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:44 --> Config Class Initialized
INFO - 2024-12-01 04:47:44 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:44 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:44 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:44 --> URI Class Initialized
INFO - 2024-12-01 04:47:44 --> Router Class Initialized
INFO - 2024-12-01 04:47:44 --> Output Class Initialized
INFO - 2024-12-01 04:47:44 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:44 --> CSRF cookie sent
INFO - 2024-12-01 04:47:44 --> Input Class Initialized
INFO - 2024-12-01 04:47:44 --> Language Class Initialized
INFO - 2024-12-01 04:47:44 --> Loader Class Initialized
INFO - 2024-12-01 04:47:44 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:44 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:44 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:44 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:44 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:44 --> Controller Class Initialized
INFO - 2024-12-01 04:47:44 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:44 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:44 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 04:47:44 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:44 --> Total execution time: 0.0864
INFO - 2024-12-01 04:47:48 --> Config Class Initialized
INFO - 2024-12-01 04:47:48 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:48 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:48 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:48 --> URI Class Initialized
INFO - 2024-12-01 04:47:48 --> Router Class Initialized
INFO - 2024-12-01 04:47:48 --> Output Class Initialized
INFO - 2024-12-01 04:47:48 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:48 --> CSRF cookie sent
INFO - 2024-12-01 04:47:48 --> Input Class Initialized
INFO - 2024-12-01 04:47:48 --> Language Class Initialized
INFO - 2024-12-01 04:47:48 --> Loader Class Initialized
INFO - 2024-12-01 04:47:48 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:48 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:48 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:48 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:48 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:48 --> Controller Class Initialized
INFO - 2024-12-01 04:47:48 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:48 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:48 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-01 04:47:48 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:48 --> Total execution time: 0.0535
INFO - 2024-12-01 04:47:53 --> Config Class Initialized
INFO - 2024-12-01 04:47:53 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:53 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:53 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:53 --> URI Class Initialized
INFO - 2024-12-01 04:47:53 --> Router Class Initialized
INFO - 2024-12-01 04:47:53 --> Output Class Initialized
INFO - 2024-12-01 04:47:53 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:53 --> CSRF cookie sent
INFO - 2024-12-01 04:47:53 --> CSRF token verified
INFO - 2024-12-01 04:47:53 --> Input Class Initialized
INFO - 2024-12-01 04:47:53 --> Language Class Initialized
INFO - 2024-12-01 04:47:53 --> Loader Class Initialized
INFO - 2024-12-01 04:47:53 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:53 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:53 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:53 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:53 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:53 --> Controller Class Initialized
INFO - 2024-12-01 04:47:53 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:53 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:54 --> Config Class Initialized
INFO - 2024-12-01 04:47:54 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:54 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:54 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:54 --> URI Class Initialized
INFO - 2024-12-01 04:47:54 --> Router Class Initialized
INFO - 2024-12-01 04:47:54 --> Output Class Initialized
INFO - 2024-12-01 04:47:54 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:54 --> CSRF cookie sent
INFO - 2024-12-01 04:47:54 --> Input Class Initialized
INFO - 2024-12-01 04:47:54 --> Language Class Initialized
INFO - 2024-12-01 04:47:54 --> Loader Class Initialized
INFO - 2024-12-01 04:47:54 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:54 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:54 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:54 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:54 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:54 --> Controller Class Initialized
INFO - 2024-12-01 04:47:54 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:54 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:54 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 04:47:54 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:54 --> Total execution time: 0.0716
INFO - 2024-12-01 04:47:56 --> Config Class Initialized
INFO - 2024-12-01 04:47:56 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:47:56 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:47:56 --> Utf8 Class Initialized
INFO - 2024-12-01 04:47:56 --> URI Class Initialized
INFO - 2024-12-01 04:47:56 --> Router Class Initialized
INFO - 2024-12-01 04:47:56 --> Output Class Initialized
INFO - 2024-12-01 04:47:56 --> Security Class Initialized
DEBUG - 2024-12-01 04:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:47:56 --> CSRF cookie sent
INFO - 2024-12-01 04:47:56 --> Input Class Initialized
INFO - 2024-12-01 04:47:56 --> Language Class Initialized
INFO - 2024-12-01 04:47:56 --> Loader Class Initialized
INFO - 2024-12-01 04:47:56 --> Helper loaded: url_helper
INFO - 2024-12-01 04:47:56 --> Helper loaded: form_helper
INFO - 2024-12-01 04:47:56 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:47:56 --> Form Validation Class Initialized
INFO - 2024-12-01 04:47:56 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:47:56 --> Controller Class Initialized
INFO - 2024-12-01 04:47:56 --> Model "Category_model" initialized
INFO - 2024-12-01 04:47:56 --> Model "User_model" initialized
INFO - 2024-12-01 04:47:56 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:47:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-01 04:47:56 --> Final output sent to browser
DEBUG - 2024-12-01 04:47:56 --> Total execution time: 0.0543
INFO - 2024-12-01 04:48:08 --> Config Class Initialized
INFO - 2024-12-01 04:48:08 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:08 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:08 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:08 --> URI Class Initialized
INFO - 2024-12-01 04:48:08 --> Router Class Initialized
INFO - 2024-12-01 04:48:08 --> Output Class Initialized
INFO - 2024-12-01 04:48:08 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:08 --> CSRF cookie sent
INFO - 2024-12-01 04:48:08 --> CSRF token verified
INFO - 2024-12-01 04:48:08 --> Input Class Initialized
INFO - 2024-12-01 04:48:08 --> Language Class Initialized
INFO - 2024-12-01 04:48:08 --> Loader Class Initialized
INFO - 2024-12-01 04:48:08 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:08 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:08 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:08 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:08 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:08 --> Controller Class Initialized
INFO - 2024-12-01 04:48:08 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:08 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:08 --> Config Class Initialized
INFO - 2024-12-01 04:48:08 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:08 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:08 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:08 --> URI Class Initialized
INFO - 2024-12-01 04:48:08 --> Router Class Initialized
INFO - 2024-12-01 04:48:08 --> Output Class Initialized
INFO - 2024-12-01 04:48:08 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:08 --> CSRF cookie sent
INFO - 2024-12-01 04:48:08 --> Input Class Initialized
INFO - 2024-12-01 04:48:08 --> Language Class Initialized
INFO - 2024-12-01 04:48:08 --> Loader Class Initialized
INFO - 2024-12-01 04:48:08 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:08 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:08 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:08 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:08 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:08 --> Controller Class Initialized
INFO - 2024-12-01 04:48:08 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:08 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 04:48:08 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:08 --> Total execution time: 0.0523
INFO - 2024-12-01 04:48:12 --> Config Class Initialized
INFO - 2024-12-01 04:48:12 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:12 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:12 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:12 --> URI Class Initialized
INFO - 2024-12-01 04:48:12 --> Router Class Initialized
INFO - 2024-12-01 04:48:12 --> Output Class Initialized
INFO - 2024-12-01 04:48:12 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:12 --> CSRF cookie sent
INFO - 2024-12-01 04:48:12 --> Input Class Initialized
INFO - 2024-12-01 04:48:12 --> Language Class Initialized
INFO - 2024-12-01 04:48:12 --> Loader Class Initialized
INFO - 2024-12-01 04:48:12 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:12 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:12 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:12 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:12 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:12 --> Controller Class Initialized
INFO - 2024-12-01 04:48:12 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:12 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 04:48:12 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:12 --> Total execution time: 0.0733
INFO - 2024-12-01 04:48:18 --> Config Class Initialized
INFO - 2024-12-01 04:48:18 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:18 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:18 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:18 --> URI Class Initialized
INFO - 2024-12-01 04:48:18 --> Router Class Initialized
INFO - 2024-12-01 04:48:18 --> Output Class Initialized
INFO - 2024-12-01 04:48:18 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:18 --> CSRF cookie sent
INFO - 2024-12-01 04:48:18 --> Input Class Initialized
INFO - 2024-12-01 04:48:18 --> Language Class Initialized
INFO - 2024-12-01 04:48:18 --> Loader Class Initialized
INFO - 2024-12-01 04:48:18 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:18 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:18 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:18 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:18 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:18 --> Controller Class Initialized
INFO - 2024-12-01 04:48:18 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:18 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:18 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-01 04:48:18 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:18 --> Total execution time: 0.1584
INFO - 2024-12-01 04:48:21 --> Config Class Initialized
INFO - 2024-12-01 04:48:21 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:21 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:21 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:21 --> URI Class Initialized
INFO - 2024-12-01 04:48:21 --> Router Class Initialized
INFO - 2024-12-01 04:48:21 --> Output Class Initialized
INFO - 2024-12-01 04:48:21 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:21 --> CSRF cookie sent
INFO - 2024-12-01 04:48:21 --> CSRF token verified
INFO - 2024-12-01 04:48:21 --> Input Class Initialized
INFO - 2024-12-01 04:48:21 --> Language Class Initialized
INFO - 2024-12-01 04:48:21 --> Loader Class Initialized
INFO - 2024-12-01 04:48:21 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:21 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:21 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:21 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:21 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:21 --> Controller Class Initialized
INFO - 2024-12-01 04:48:21 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:21 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-01 04:48:21 --> Config Class Initialized
INFO - 2024-12-01 04:48:21 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:21 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:21 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:21 --> URI Class Initialized
INFO - 2024-12-01 04:48:21 --> Router Class Initialized
INFO - 2024-12-01 04:48:21 --> Output Class Initialized
INFO - 2024-12-01 04:48:21 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:21 --> CSRF cookie sent
INFO - 2024-12-01 04:48:21 --> Input Class Initialized
INFO - 2024-12-01 04:48:21 --> Language Class Initialized
INFO - 2024-12-01 04:48:21 --> Loader Class Initialized
INFO - 2024-12-01 04:48:21 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:21 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:21 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:21 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:21 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:21 --> Controller Class Initialized
INFO - 2024-12-01 04:48:21 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:21 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 04:48:21 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:21 --> Total execution time: 0.0565
INFO - 2024-12-01 04:48:29 --> Config Class Initialized
INFO - 2024-12-01 04:48:29 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:29 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:29 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:29 --> URI Class Initialized
INFO - 2024-12-01 04:48:29 --> Router Class Initialized
INFO - 2024-12-01 04:48:29 --> Output Class Initialized
INFO - 2024-12-01 04:48:29 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:29 --> CSRF cookie sent
INFO - 2024-12-01 04:48:29 --> Input Class Initialized
INFO - 2024-12-01 04:48:29 --> Language Class Initialized
INFO - 2024-12-01 04:48:29 --> Loader Class Initialized
INFO - 2024-12-01 04:48:29 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:29 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:29 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:29 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:29 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:29 --> Controller Class Initialized
INFO - 2024-12-01 04:48:29 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:29 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:29 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 04:48:29 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:29 --> Total execution time: 0.0732
INFO - 2024-12-01 04:48:35 --> Config Class Initialized
INFO - 2024-12-01 04:48:35 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:35 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:35 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:35 --> URI Class Initialized
INFO - 2024-12-01 04:48:35 --> Router Class Initialized
INFO - 2024-12-01 04:48:35 --> Output Class Initialized
INFO - 2024-12-01 04:48:35 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:35 --> CSRF cookie sent
INFO - 2024-12-01 04:48:35 --> Input Class Initialized
INFO - 2024-12-01 04:48:35 --> Language Class Initialized
INFO - 2024-12-01 04:48:35 --> Loader Class Initialized
INFO - 2024-12-01 04:48:35 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:35 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:35 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:35 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:35 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:35 --> Controller Class Initialized
INFO - 2024-12-01 04:48:35 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:35 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:35 --> Model "Contact_model" initialized
INFO - 2024-12-01 04:48:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-01 04:48:35 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:35 --> Total execution time: 0.0641
INFO - 2024-12-01 04:48:38 --> Config Class Initialized
INFO - 2024-12-01 04:48:38 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:38 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:38 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:38 --> URI Class Initialized
INFO - 2024-12-01 04:48:38 --> Router Class Initialized
INFO - 2024-12-01 04:48:38 --> Output Class Initialized
INFO - 2024-12-01 04:48:38 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:38 --> CSRF cookie sent
INFO - 2024-12-01 04:48:38 --> Input Class Initialized
INFO - 2024-12-01 04:48:38 --> Language Class Initialized
INFO - 2024-12-01 04:48:38 --> Loader Class Initialized
INFO - 2024-12-01 04:48:38 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:38 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:38 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:38 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:38 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:38 --> Controller Class Initialized
INFO - 2024-12-01 04:48:38 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:38 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:38 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-01 04:48:38 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:38 --> Total execution time: 0.0615
INFO - 2024-12-01 04:48:38 --> Config Class Initialized
INFO - 2024-12-01 04:48:38 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:38 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:38 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:38 --> URI Class Initialized
INFO - 2024-12-01 04:48:38 --> Router Class Initialized
INFO - 2024-12-01 04:48:38 --> Output Class Initialized
INFO - 2024-12-01 04:48:38 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:38 --> CSRF cookie sent
INFO - 2024-12-01 04:48:38 --> Input Class Initialized
INFO - 2024-12-01 04:48:38 --> Language Class Initialized
INFO - 2024-12-01 04:48:38 --> Loader Class Initialized
INFO - 2024-12-01 04:48:38 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:38 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:38 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:38 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:38 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:38 --> Controller Class Initialized
INFO - 2024-12-01 04:48:38 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:38 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:38 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-01 04:48:38 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:38 --> Total execution time: 0.0736
INFO - 2024-12-01 04:48:40 --> Config Class Initialized
INFO - 2024-12-01 04:48:40 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:40 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:40 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:40 --> URI Class Initialized
INFO - 2024-12-01 04:48:40 --> Router Class Initialized
INFO - 2024-12-01 04:48:40 --> Output Class Initialized
INFO - 2024-12-01 04:48:40 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:40 --> CSRF cookie sent
INFO - 2024-12-01 04:48:40 --> Input Class Initialized
INFO - 2024-12-01 04:48:40 --> Language Class Initialized
INFO - 2024-12-01 04:48:40 --> Loader Class Initialized
INFO - 2024-12-01 04:48:40 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:40 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:40 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:40 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:40 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:40 --> Controller Class Initialized
INFO - 2024-12-01 04:48:40 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:40 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:40 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 04:48:40 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:40 --> Total execution time: 0.0525
INFO - 2024-12-01 04:48:41 --> Config Class Initialized
INFO - 2024-12-01 04:48:41 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:41 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:41 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:41 --> URI Class Initialized
INFO - 2024-12-01 04:48:41 --> Router Class Initialized
INFO - 2024-12-01 04:48:41 --> Output Class Initialized
INFO - 2024-12-01 04:48:41 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:41 --> CSRF cookie sent
INFO - 2024-12-01 04:48:41 --> Input Class Initialized
INFO - 2024-12-01 04:48:41 --> Language Class Initialized
INFO - 2024-12-01 04:48:41 --> Loader Class Initialized
INFO - 2024-12-01 04:48:41 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:41 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:41 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:41 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:41 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:41 --> Controller Class Initialized
INFO - 2024-12-01 04:48:41 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:41 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:41 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 04:48:41 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:41 --> Total execution time: 0.0773
INFO - 2024-12-01 04:48:44 --> Config Class Initialized
INFO - 2024-12-01 04:48:44 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:48:44 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:48:44 --> Utf8 Class Initialized
INFO - 2024-12-01 04:48:44 --> URI Class Initialized
INFO - 2024-12-01 04:48:44 --> Router Class Initialized
INFO - 2024-12-01 04:48:44 --> Output Class Initialized
INFO - 2024-12-01 04:48:44 --> Security Class Initialized
DEBUG - 2024-12-01 04:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:48:44 --> CSRF cookie sent
INFO - 2024-12-01 04:48:44 --> Input Class Initialized
INFO - 2024-12-01 04:48:44 --> Language Class Initialized
INFO - 2024-12-01 04:48:44 --> Loader Class Initialized
INFO - 2024-12-01 04:48:44 --> Helper loaded: url_helper
INFO - 2024-12-01 04:48:44 --> Helper loaded: form_helper
INFO - 2024-12-01 04:48:44 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:48:44 --> Form Validation Class Initialized
INFO - 2024-12-01 04:48:44 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:48:44 --> Controller Class Initialized
INFO - 2024-12-01 04:48:44 --> Model "Category_model" initialized
INFO - 2024-12-01 04:48:44 --> Model "User_model" initialized
INFO - 2024-12-01 04:48:44 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:48:44 --> Model "Contact_model" initialized
INFO - 2024-12-01 04:48:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-01 04:48:44 --> Final output sent to browser
DEBUG - 2024-12-01 04:48:44 --> Total execution time: 0.0649
INFO - 2024-12-01 04:53:39 --> Config Class Initialized
INFO - 2024-12-01 04:53:39 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:53:39 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:53:39 --> Utf8 Class Initialized
INFO - 2024-12-01 04:53:39 --> URI Class Initialized
INFO - 2024-12-01 04:53:39 --> Router Class Initialized
INFO - 2024-12-01 04:53:39 --> Output Class Initialized
INFO - 2024-12-01 04:53:39 --> Security Class Initialized
DEBUG - 2024-12-01 04:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:53:39 --> CSRF cookie sent
INFO - 2024-12-01 04:53:39 --> Input Class Initialized
INFO - 2024-12-01 04:53:39 --> Language Class Initialized
INFO - 2024-12-01 04:53:39 --> Loader Class Initialized
INFO - 2024-12-01 04:53:39 --> Helper loaded: url_helper
INFO - 2024-12-01 04:53:39 --> Helper loaded: form_helper
INFO - 2024-12-01 04:53:39 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:53:40 --> Form Validation Class Initialized
INFO - 2024-12-01 04:53:40 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:53:40 --> Controller Class Initialized
INFO - 2024-12-01 04:53:40 --> Model "Category_model" initialized
INFO - 2024-12-01 04:53:40 --> Model "User_model" initialized
INFO - 2024-12-01 04:53:40 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:53:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 04:53:40 --> Final output sent to browser
DEBUG - 2024-12-01 04:53:40 --> Total execution time: 0.9471
INFO - 2024-12-01 04:53:46 --> Config Class Initialized
INFO - 2024-12-01 04:53:46 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:53:46 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:53:46 --> Utf8 Class Initialized
INFO - 2024-12-01 04:53:46 --> URI Class Initialized
INFO - 2024-12-01 04:53:46 --> Router Class Initialized
INFO - 2024-12-01 04:53:46 --> Output Class Initialized
INFO - 2024-12-01 04:53:46 --> Security Class Initialized
DEBUG - 2024-12-01 04:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:53:46 --> CSRF cookie sent
INFO - 2024-12-01 04:53:46 --> Input Class Initialized
INFO - 2024-12-01 04:53:46 --> Language Class Initialized
INFO - 2024-12-01 04:53:46 --> Loader Class Initialized
INFO - 2024-12-01 04:53:46 --> Helper loaded: url_helper
INFO - 2024-12-01 04:53:46 --> Helper loaded: form_helper
INFO - 2024-12-01 04:53:46 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:53:46 --> Form Validation Class Initialized
INFO - 2024-12-01 04:53:46 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:53:46 --> Controller Class Initialized
INFO - 2024-12-01 04:53:46 --> Model "Category_model" initialized
INFO - 2024-12-01 04:53:46 --> Model "User_model" initialized
INFO - 2024-12-01 04:53:46 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:53:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 04:53:46 --> Final output sent to browser
DEBUG - 2024-12-01 04:53:46 --> Total execution time: 0.1628
INFO - 2024-12-01 04:53:48 --> Config Class Initialized
INFO - 2024-12-01 04:53:48 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:53:48 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:53:48 --> Utf8 Class Initialized
INFO - 2024-12-01 04:53:48 --> URI Class Initialized
INFO - 2024-12-01 04:53:48 --> Router Class Initialized
INFO - 2024-12-01 04:53:48 --> Output Class Initialized
INFO - 2024-12-01 04:53:48 --> Security Class Initialized
DEBUG - 2024-12-01 04:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:53:48 --> CSRF cookie sent
INFO - 2024-12-01 04:53:48 --> Input Class Initialized
INFO - 2024-12-01 04:53:48 --> Language Class Initialized
INFO - 2024-12-01 04:53:48 --> Loader Class Initialized
INFO - 2024-12-01 04:53:48 --> Helper loaded: url_helper
INFO - 2024-12-01 04:53:48 --> Helper loaded: form_helper
INFO - 2024-12-01 04:53:48 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:53:48 --> Form Validation Class Initialized
INFO - 2024-12-01 04:53:48 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:53:48 --> Controller Class Initialized
INFO - 2024-12-01 04:53:48 --> Model "Category_model" initialized
INFO - 2024-12-01 04:53:48 --> Model "User_model" initialized
INFO - 2024-12-01 04:53:48 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:53:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 04:53:48 --> Final output sent to browser
DEBUG - 2024-12-01 04:53:48 --> Total execution time: 0.0760
INFO - 2024-12-01 04:57:18 --> Config Class Initialized
INFO - 2024-12-01 04:57:18 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:57:18 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:57:18 --> Utf8 Class Initialized
INFO - 2024-12-01 04:57:18 --> URI Class Initialized
INFO - 2024-12-01 04:57:18 --> Router Class Initialized
INFO - 2024-12-01 04:57:18 --> Output Class Initialized
INFO - 2024-12-01 04:57:18 --> Security Class Initialized
DEBUG - 2024-12-01 04:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:57:18 --> CSRF cookie sent
INFO - 2024-12-01 04:57:18 --> Input Class Initialized
INFO - 2024-12-01 04:57:18 --> Language Class Initialized
INFO - 2024-12-01 04:57:18 --> Loader Class Initialized
INFO - 2024-12-01 04:57:18 --> Helper loaded: url_helper
INFO - 2024-12-01 04:57:18 --> Helper loaded: form_helper
INFO - 2024-12-01 04:57:18 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:57:18 --> Form Validation Class Initialized
INFO - 2024-12-01 04:57:18 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:57:18 --> Controller Class Initialized
INFO - 2024-12-01 04:57:18 --> Model "Category_model" initialized
INFO - 2024-12-01 04:57:18 --> Model "User_model" initialized
INFO - 2024-12-01 04:57:18 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:57:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 04:57:18 --> Final output sent to browser
DEBUG - 2024-12-01 04:57:18 --> Total execution time: 0.1288
INFO - 2024-12-01 04:57:21 --> Config Class Initialized
INFO - 2024-12-01 04:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-01 04:57:22 --> UTF-8 Support Enabled
INFO - 2024-12-01 04:57:22 --> Utf8 Class Initialized
INFO - 2024-12-01 04:57:22 --> URI Class Initialized
INFO - 2024-12-01 04:57:22 --> Router Class Initialized
INFO - 2024-12-01 04:57:22 --> Output Class Initialized
INFO - 2024-12-01 04:57:22 --> Security Class Initialized
DEBUG - 2024-12-01 04:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 04:57:22 --> CSRF cookie sent
INFO - 2024-12-01 04:57:22 --> Input Class Initialized
INFO - 2024-12-01 04:57:22 --> Language Class Initialized
INFO - 2024-12-01 04:57:22 --> Loader Class Initialized
INFO - 2024-12-01 04:57:22 --> Helper loaded: url_helper
INFO - 2024-12-01 04:57:22 --> Helper loaded: form_helper
INFO - 2024-12-01 04:57:22 --> Database Driver Class Initialized
DEBUG - 2024-12-01 04:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 04:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 04:57:22 --> Form Validation Class Initialized
INFO - 2024-12-01 04:57:22 --> Model "Culinary_model" initialized
INFO - 2024-12-01 04:57:22 --> Controller Class Initialized
INFO - 2024-12-01 04:57:22 --> Model "Category_model" initialized
INFO - 2024-12-01 04:57:22 --> Model "User_model" initialized
INFO - 2024-12-01 04:57:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 04:57:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 04:57:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 04:57:22 --> Final output sent to browser
DEBUG - 2024-12-01 04:57:22 --> Total execution time: 0.3947
INFO - 2024-12-01 05:04:10 --> Config Class Initialized
INFO - 2024-12-01 05:04:10 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:10 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:10 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:10 --> URI Class Initialized
INFO - 2024-12-01 05:04:10 --> Router Class Initialized
INFO - 2024-12-01 05:04:10 --> Output Class Initialized
INFO - 2024-12-01 05:04:10 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:10 --> CSRF cookie sent
INFO - 2024-12-01 05:04:10 --> Input Class Initialized
INFO - 2024-12-01 05:04:10 --> Language Class Initialized
INFO - 2024-12-01 05:04:10 --> Loader Class Initialized
INFO - 2024-12-01 05:04:10 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:10 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:10 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:12 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:12 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:12 --> Controller Class Initialized
INFO - 2024-12-01 05:04:12 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:12 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 05:04:13 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:13 --> Total execution time: 3.4656
INFO - 2024-12-01 05:04:18 --> Config Class Initialized
INFO - 2024-12-01 05:04:18 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:18 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:18 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:18 --> URI Class Initialized
INFO - 2024-12-01 05:04:18 --> Router Class Initialized
INFO - 2024-12-01 05:04:18 --> Output Class Initialized
INFO - 2024-12-01 05:04:18 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:18 --> CSRF cookie sent
INFO - 2024-12-01 05:04:18 --> Input Class Initialized
INFO - 2024-12-01 05:04:18 --> Language Class Initialized
INFO - 2024-12-01 05:04:18 --> Loader Class Initialized
INFO - 2024-12-01 05:04:18 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:18 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:18 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:18 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:18 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:18 --> Controller Class Initialized
INFO - 2024-12-01 05:04:18 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:18 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:18 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:04:18 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:18 --> Total execution time: 0.1860
INFO - 2024-12-01 05:04:22 --> Config Class Initialized
INFO - 2024-12-01 05:04:22 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:22 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:22 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:22 --> URI Class Initialized
INFO - 2024-12-01 05:04:22 --> Router Class Initialized
INFO - 2024-12-01 05:04:22 --> Output Class Initialized
INFO - 2024-12-01 05:04:22 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:22 --> CSRF cookie sent
INFO - 2024-12-01 05:04:22 --> Input Class Initialized
INFO - 2024-12-01 05:04:22 --> Language Class Initialized
INFO - 2024-12-01 05:04:22 --> Loader Class Initialized
INFO - 2024-12-01 05:04:22 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:22 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:22 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:22 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:22 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:22 --> Controller Class Initialized
INFO - 2024-12-01 05:04:22 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:22 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 05:04:22 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:22 --> Total execution time: 0.0775
INFO - 2024-12-01 05:04:23 --> Config Class Initialized
INFO - 2024-12-01 05:04:23 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:23 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:23 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:23 --> URI Class Initialized
INFO - 2024-12-01 05:04:23 --> Router Class Initialized
INFO - 2024-12-01 05:04:23 --> Output Class Initialized
INFO - 2024-12-01 05:04:23 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:23 --> CSRF cookie sent
INFO - 2024-12-01 05:04:23 --> Input Class Initialized
INFO - 2024-12-01 05:04:23 --> Language Class Initialized
INFO - 2024-12-01 05:04:23 --> Loader Class Initialized
INFO - 2024-12-01 05:04:23 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:23 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:23 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:23 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:23 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:23 --> Controller Class Initialized
INFO - 2024-12-01 05:04:23 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:23 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:04:23 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:23 --> Total execution time: 0.0593
INFO - 2024-12-01 05:04:25 --> Config Class Initialized
INFO - 2024-12-01 05:04:25 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:25 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:25 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:25 --> URI Class Initialized
INFO - 2024-12-01 05:04:25 --> Router Class Initialized
INFO - 2024-12-01 05:04:25 --> Output Class Initialized
INFO - 2024-12-01 05:04:25 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:25 --> CSRF cookie sent
INFO - 2024-12-01 05:04:25 --> Input Class Initialized
INFO - 2024-12-01 05:04:25 --> Language Class Initialized
INFO - 2024-12-01 05:04:25 --> Loader Class Initialized
INFO - 2024-12-01 05:04:25 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:25 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:25 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:25 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:25 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:25 --> Controller Class Initialized
INFO - 2024-12-01 05:04:25 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:25 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:25 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-01 05:04:25 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:25 --> Total execution time: 0.0697
INFO - 2024-12-01 05:04:26 --> Config Class Initialized
INFO - 2024-12-01 05:04:26 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:26 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:26 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:26 --> URI Class Initialized
INFO - 2024-12-01 05:04:26 --> Router Class Initialized
INFO - 2024-12-01 05:04:26 --> Output Class Initialized
INFO - 2024-12-01 05:04:26 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:26 --> CSRF cookie sent
INFO - 2024-12-01 05:04:26 --> Input Class Initialized
INFO - 2024-12-01 05:04:26 --> Language Class Initialized
INFO - 2024-12-01 05:04:26 --> Loader Class Initialized
INFO - 2024-12-01 05:04:26 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:26 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:26 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:26 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:26 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:26 --> Controller Class Initialized
INFO - 2024-12-01 05:04:26 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:26 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-01 05:04:26 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:26 --> Total execution time: 0.0741
INFO - 2024-12-01 05:04:28 --> Config Class Initialized
INFO - 2024-12-01 05:04:28 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:28 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:28 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:28 --> URI Class Initialized
INFO - 2024-12-01 05:04:28 --> Router Class Initialized
INFO - 2024-12-01 05:04:28 --> Output Class Initialized
INFO - 2024-12-01 05:04:28 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:28 --> CSRF cookie sent
INFO - 2024-12-01 05:04:28 --> Input Class Initialized
INFO - 2024-12-01 05:04:28 --> Language Class Initialized
INFO - 2024-12-01 05:04:28 --> Loader Class Initialized
INFO - 2024-12-01 05:04:28 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:28 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:28 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:28 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:28 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:28 --> Controller Class Initialized
INFO - 2024-12-01 05:04:28 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:28 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:04:28 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:28 --> Total execution time: 0.1069
INFO - 2024-12-01 05:04:29 --> Config Class Initialized
INFO - 2024-12-01 05:04:29 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:29 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:29 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:29 --> URI Class Initialized
INFO - 2024-12-01 05:04:29 --> Router Class Initialized
INFO - 2024-12-01 05:04:29 --> Output Class Initialized
INFO - 2024-12-01 05:04:29 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:29 --> CSRF cookie sent
INFO - 2024-12-01 05:04:29 --> Input Class Initialized
INFO - 2024-12-01 05:04:29 --> Language Class Initialized
INFO - 2024-12-01 05:04:29 --> Loader Class Initialized
INFO - 2024-12-01 05:04:29 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:29 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:29 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:29 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:29 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:29 --> Controller Class Initialized
INFO - 2024-12-01 05:04:29 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:29 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:29 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-01 05:04:29 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:29 --> Total execution time: 0.0648
INFO - 2024-12-01 05:04:31 --> Config Class Initialized
INFO - 2024-12-01 05:04:31 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:31 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:31 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:31 --> URI Class Initialized
INFO - 2024-12-01 05:04:31 --> Router Class Initialized
INFO - 2024-12-01 05:04:31 --> Output Class Initialized
INFO - 2024-12-01 05:04:31 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:31 --> CSRF cookie sent
INFO - 2024-12-01 05:04:31 --> Input Class Initialized
INFO - 2024-12-01 05:04:31 --> Language Class Initialized
INFO - 2024-12-01 05:04:31 --> Loader Class Initialized
INFO - 2024-12-01 05:04:31 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:31 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:31 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:31 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:31 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:31 --> Controller Class Initialized
INFO - 2024-12-01 05:04:31 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:31 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:04:31 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:31 --> Total execution time: 0.0635
INFO - 2024-12-01 05:04:32 --> Config Class Initialized
INFO - 2024-12-01 05:04:32 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:04:32 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:04:32 --> Utf8 Class Initialized
INFO - 2024-12-01 05:04:32 --> URI Class Initialized
INFO - 2024-12-01 05:04:32 --> Router Class Initialized
INFO - 2024-12-01 05:04:32 --> Output Class Initialized
INFO - 2024-12-01 05:04:32 --> Security Class Initialized
DEBUG - 2024-12-01 05:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:04:32 --> CSRF cookie sent
INFO - 2024-12-01 05:04:32 --> Input Class Initialized
INFO - 2024-12-01 05:04:32 --> Language Class Initialized
INFO - 2024-12-01 05:04:32 --> Loader Class Initialized
INFO - 2024-12-01 05:04:32 --> Helper loaded: url_helper
INFO - 2024-12-01 05:04:32 --> Helper loaded: form_helper
INFO - 2024-12-01 05:04:32 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:04:32 --> Form Validation Class Initialized
INFO - 2024-12-01 05:04:32 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:04:32 --> Controller Class Initialized
INFO - 2024-12-01 05:04:32 --> Model "Category_model" initialized
INFO - 2024-12-01 05:04:32 --> Model "User_model" initialized
INFO - 2024-12-01 05:04:32 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:04:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-01 05:04:32 --> Final output sent to browser
DEBUG - 2024-12-01 05:04:32 --> Total execution time: 0.0555
INFO - 2024-12-01 05:05:11 --> Config Class Initialized
INFO - 2024-12-01 05:05:11 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:11 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:11 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:11 --> URI Class Initialized
INFO - 2024-12-01 05:05:11 --> Router Class Initialized
INFO - 2024-12-01 05:05:11 --> Output Class Initialized
INFO - 2024-12-01 05:05:11 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:11 --> CSRF cookie sent
INFO - 2024-12-01 05:05:11 --> Input Class Initialized
INFO - 2024-12-01 05:05:11 --> Language Class Initialized
INFO - 2024-12-01 05:05:11 --> Loader Class Initialized
INFO - 2024-12-01 05:05:11 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:11 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:11 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:11 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:11 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:11 --> Controller Class Initialized
INFO - 2024-12-01 05:05:11 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:11 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:11 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 05:05:12 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:12 --> Total execution time: 0.4941
INFO - 2024-12-01 05:05:15 --> Config Class Initialized
INFO - 2024-12-01 05:05:15 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:15 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:15 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:15 --> URI Class Initialized
INFO - 2024-12-01 05:05:15 --> Router Class Initialized
INFO - 2024-12-01 05:05:15 --> Output Class Initialized
INFO - 2024-12-01 05:05:15 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:15 --> CSRF cookie sent
INFO - 2024-12-01 05:05:15 --> Input Class Initialized
INFO - 2024-12-01 05:05:15 --> Language Class Initialized
INFO - 2024-12-01 05:05:15 --> Loader Class Initialized
INFO - 2024-12-01 05:05:15 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:15 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:15 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:15 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:15 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:15 --> Controller Class Initialized
INFO - 2024-12-01 05:05:15 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:15 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:15 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 05:05:15 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:15 --> Total execution time: 0.0828
INFO - 2024-12-01 05:05:16 --> Config Class Initialized
INFO - 2024-12-01 05:05:16 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:16 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:16 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:16 --> URI Class Initialized
INFO - 2024-12-01 05:05:16 --> Router Class Initialized
INFO - 2024-12-01 05:05:16 --> Output Class Initialized
INFO - 2024-12-01 05:05:16 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:16 --> CSRF cookie sent
INFO - 2024-12-01 05:05:16 --> Input Class Initialized
INFO - 2024-12-01 05:05:16 --> Language Class Initialized
INFO - 2024-12-01 05:05:16 --> Loader Class Initialized
INFO - 2024-12-01 05:05:16 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:16 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:16 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:16 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:16 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:16 --> Controller Class Initialized
INFO - 2024-12-01 05:05:16 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:16 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:16 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 05:05:16 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:16 --> Total execution time: 0.0874
INFO - 2024-12-01 05:05:17 --> Config Class Initialized
INFO - 2024-12-01 05:05:17 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:17 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:17 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:17 --> URI Class Initialized
INFO - 2024-12-01 05:05:17 --> Router Class Initialized
INFO - 2024-12-01 05:05:17 --> Output Class Initialized
INFO - 2024-12-01 05:05:17 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:17 --> CSRF cookie sent
INFO - 2024-12-01 05:05:17 --> Input Class Initialized
INFO - 2024-12-01 05:05:17 --> Language Class Initialized
INFO - 2024-12-01 05:05:17 --> Loader Class Initialized
INFO - 2024-12-01 05:05:17 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:17 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:17 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:17 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:17 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:17 --> Controller Class Initialized
INFO - 2024-12-01 05:05:17 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:17 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:05:17 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:17 --> Total execution time: 0.0576
INFO - 2024-12-01 05:05:19 --> Config Class Initialized
INFO - 2024-12-01 05:05:19 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:19 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:19 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:19 --> URI Class Initialized
INFO - 2024-12-01 05:05:19 --> Router Class Initialized
INFO - 2024-12-01 05:05:19 --> Output Class Initialized
INFO - 2024-12-01 05:05:19 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:19 --> CSRF cookie sent
INFO - 2024-12-01 05:05:19 --> Input Class Initialized
INFO - 2024-12-01 05:05:19 --> Language Class Initialized
INFO - 2024-12-01 05:05:19 --> Loader Class Initialized
INFO - 2024-12-01 05:05:19 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:19 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:19 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:19 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:19 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:19 --> Controller Class Initialized
INFO - 2024-12-01 05:05:19 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:19 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-01 05:05:19 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:19 --> Total execution time: 0.0506
INFO - 2024-12-01 05:05:20 --> Config Class Initialized
INFO - 2024-12-01 05:05:20 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:20 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:20 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:20 --> URI Class Initialized
INFO - 2024-12-01 05:05:20 --> Router Class Initialized
INFO - 2024-12-01 05:05:20 --> Output Class Initialized
INFO - 2024-12-01 05:05:20 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:20 --> CSRF cookie sent
INFO - 2024-12-01 05:05:20 --> Input Class Initialized
INFO - 2024-12-01 05:05:20 --> Language Class Initialized
INFO - 2024-12-01 05:05:20 --> Loader Class Initialized
INFO - 2024-12-01 05:05:20 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:20 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:20 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:20 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:20 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:20 --> Controller Class Initialized
INFO - 2024-12-01 05:05:20 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:20 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:20 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-01 05:05:21 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:21 --> Total execution time: 0.1978
INFO - 2024-12-01 05:05:22 --> Config Class Initialized
INFO - 2024-12-01 05:05:22 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:22 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:22 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:22 --> URI Class Initialized
INFO - 2024-12-01 05:05:22 --> Router Class Initialized
INFO - 2024-12-01 05:05:22 --> Output Class Initialized
INFO - 2024-12-01 05:05:22 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:22 --> CSRF cookie sent
INFO - 2024-12-01 05:05:22 --> Input Class Initialized
INFO - 2024-12-01 05:05:22 --> Language Class Initialized
INFO - 2024-12-01 05:05:22 --> Loader Class Initialized
INFO - 2024-12-01 05:05:22 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:22 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:22 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:22 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:22 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:22 --> Controller Class Initialized
INFO - 2024-12-01 05:05:22 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:22 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:22 --> Model "Contact_model" initialized
INFO - 2024-12-01 05:05:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-01 05:05:22 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:22 --> Total execution time: 0.0684
INFO - 2024-12-01 05:05:26 --> Config Class Initialized
INFO - 2024-12-01 05:05:26 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:26 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:26 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:26 --> URI Class Initialized
INFO - 2024-12-01 05:05:26 --> Router Class Initialized
INFO - 2024-12-01 05:05:26 --> Output Class Initialized
INFO - 2024-12-01 05:05:26 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:26 --> CSRF cookie sent
INFO - 2024-12-01 05:05:26 --> Input Class Initialized
INFO - 2024-12-01 05:05:26 --> Language Class Initialized
INFO - 2024-12-01 05:05:26 --> Loader Class Initialized
INFO - 2024-12-01 05:05:26 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:26 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:26 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:26 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:26 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:26 --> Controller Class Initialized
INFO - 2024-12-01 05:05:26 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:26 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:05:26 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:26 --> Total execution time: 0.0592
INFO - 2024-12-01 05:05:30 --> Config Class Initialized
INFO - 2024-12-01 05:05:30 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:30 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:30 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:30 --> URI Class Initialized
INFO - 2024-12-01 05:05:30 --> Router Class Initialized
INFO - 2024-12-01 05:05:30 --> Output Class Initialized
INFO - 2024-12-01 05:05:30 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:30 --> CSRF cookie sent
INFO - 2024-12-01 05:05:30 --> Input Class Initialized
INFO - 2024-12-01 05:05:30 --> Language Class Initialized
INFO - 2024-12-01 05:05:30 --> Loader Class Initialized
INFO - 2024-12-01 05:05:30 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:30 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:30 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:30 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:30 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:30 --> Controller Class Initialized
INFO - 2024-12-01 05:05:30 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:30 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:30 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-01 05:05:30 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:30 --> Total execution time: 0.0543
INFO - 2024-12-01 05:05:32 --> Config Class Initialized
INFO - 2024-12-01 05:05:32 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:32 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:32 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:32 --> URI Class Initialized
INFO - 2024-12-01 05:05:32 --> Router Class Initialized
INFO - 2024-12-01 05:05:32 --> Output Class Initialized
INFO - 2024-12-01 05:05:32 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:32 --> CSRF cookie sent
INFO - 2024-12-01 05:05:32 --> Input Class Initialized
INFO - 2024-12-01 05:05:32 --> Language Class Initialized
INFO - 2024-12-01 05:05:32 --> Loader Class Initialized
INFO - 2024-12-01 05:05:32 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:32 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:32 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:32 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:32 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:32 --> Controller Class Initialized
INFO - 2024-12-01 05:05:32 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:32 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:32 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:05:32 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:32 --> Total execution time: 0.0651
INFO - 2024-12-01 05:05:33 --> Config Class Initialized
INFO - 2024-12-01 05:05:33 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:33 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:33 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:33 --> URI Class Initialized
INFO - 2024-12-01 05:05:33 --> Router Class Initialized
INFO - 2024-12-01 05:05:33 --> Output Class Initialized
INFO - 2024-12-01 05:05:33 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:33 --> CSRF cookie sent
INFO - 2024-12-01 05:05:33 --> Input Class Initialized
INFO - 2024-12-01 05:05:33 --> Language Class Initialized
INFO - 2024-12-01 05:05:33 --> Loader Class Initialized
INFO - 2024-12-01 05:05:33 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:33 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:33 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:34 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:34 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:34 --> Controller Class Initialized
INFO - 2024-12-01 05:05:34 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:34 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:34 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:34 --> Model "Contact_model" initialized
INFO - 2024-12-01 05:05:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-01 05:05:34 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:34 --> Total execution time: 0.0630
INFO - 2024-12-01 05:05:35 --> Config Class Initialized
INFO - 2024-12-01 05:05:35 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:35 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:35 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:35 --> URI Class Initialized
INFO - 2024-12-01 05:05:35 --> Router Class Initialized
INFO - 2024-12-01 05:05:35 --> Output Class Initialized
INFO - 2024-12-01 05:05:35 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:35 --> CSRF cookie sent
INFO - 2024-12-01 05:05:35 --> Input Class Initialized
INFO - 2024-12-01 05:05:35 --> Language Class Initialized
INFO - 2024-12-01 05:05:35 --> Loader Class Initialized
INFO - 2024-12-01 05:05:35 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:35 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:35 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:35 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:35 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:35 --> Controller Class Initialized
INFO - 2024-12-01 05:05:35 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:35 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-01 05:05:35 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:35 --> Total execution time: 0.0509
INFO - 2024-12-01 05:05:42 --> Config Class Initialized
INFO - 2024-12-01 05:05:42 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:42 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:42 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:42 --> URI Class Initialized
INFO - 2024-12-01 05:05:42 --> Router Class Initialized
INFO - 2024-12-01 05:05:42 --> Output Class Initialized
INFO - 2024-12-01 05:05:42 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:42 --> CSRF cookie sent
INFO - 2024-12-01 05:05:42 --> Input Class Initialized
INFO - 2024-12-01 05:05:42 --> Language Class Initialized
INFO - 2024-12-01 05:05:42 --> Loader Class Initialized
INFO - 2024-12-01 05:05:42 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:42 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:42 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:42 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:42 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:42 --> Controller Class Initialized
INFO - 2024-12-01 05:05:42 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:42 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:42 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 05:05:42 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:42 --> Total execution time: 0.0556
INFO - 2024-12-01 05:05:43 --> Config Class Initialized
INFO - 2024-12-01 05:05:43 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:43 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:43 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:43 --> URI Class Initialized
INFO - 2024-12-01 05:05:43 --> Router Class Initialized
INFO - 2024-12-01 05:05:43 --> Output Class Initialized
INFO - 2024-12-01 05:05:43 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:43 --> CSRF cookie sent
INFO - 2024-12-01 05:05:43 --> Input Class Initialized
INFO - 2024-12-01 05:05:43 --> Language Class Initialized
INFO - 2024-12-01 05:05:43 --> Loader Class Initialized
INFO - 2024-12-01 05:05:43 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:43 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:43 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:43 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:43 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:43 --> Controller Class Initialized
INFO - 2024-12-01 05:05:43 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:43 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 05:05:43 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:43 --> Total execution time: 0.0617
INFO - 2024-12-01 05:05:44 --> Config Class Initialized
INFO - 2024-12-01 05:05:44 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:44 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:44 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:44 --> URI Class Initialized
INFO - 2024-12-01 05:05:44 --> Router Class Initialized
INFO - 2024-12-01 05:05:44 --> Output Class Initialized
INFO - 2024-12-01 05:05:44 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:44 --> CSRF cookie sent
INFO - 2024-12-01 05:05:44 --> Input Class Initialized
INFO - 2024-12-01 05:05:44 --> Language Class Initialized
INFO - 2024-12-01 05:05:44 --> Loader Class Initialized
INFO - 2024-12-01 05:05:44 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:44 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:44 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:45 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:45 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:45 --> Controller Class Initialized
INFO - 2024-12-01 05:05:45 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:45 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:45 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 05:05:45 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:45 --> Total execution time: 0.0526
INFO - 2024-12-01 05:05:47 --> Config Class Initialized
INFO - 2024-12-01 05:05:47 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:47 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:47 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:47 --> URI Class Initialized
INFO - 2024-12-01 05:05:47 --> Router Class Initialized
INFO - 2024-12-01 05:05:47 --> Output Class Initialized
INFO - 2024-12-01 05:05:47 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:47 --> CSRF cookie sent
INFO - 2024-12-01 05:05:47 --> Input Class Initialized
INFO - 2024-12-01 05:05:47 --> Language Class Initialized
INFO - 2024-12-01 05:05:47 --> Loader Class Initialized
INFO - 2024-12-01 05:05:47 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:47 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:47 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:47 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:47 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:47 --> Controller Class Initialized
INFO - 2024-12-01 05:05:47 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:47 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-01 05:05:47 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:47 --> Total execution time: 0.0549
INFO - 2024-12-01 05:05:49 --> Config Class Initialized
INFO - 2024-12-01 05:05:49 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:49 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:49 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:49 --> URI Class Initialized
INFO - 2024-12-01 05:05:49 --> Router Class Initialized
INFO - 2024-12-01 05:05:49 --> Output Class Initialized
INFO - 2024-12-01 05:05:49 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:49 --> CSRF cookie sent
INFO - 2024-12-01 05:05:49 --> Input Class Initialized
INFO - 2024-12-01 05:05:49 --> Language Class Initialized
INFO - 2024-12-01 05:05:49 --> Loader Class Initialized
INFO - 2024-12-01 05:05:49 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:49 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:49 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:49 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:49 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:49 --> Controller Class Initialized
INFO - 2024-12-01 05:05:49 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:49 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:49 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 05:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 05:05:49 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:49 --> Total execution time: 0.0611
INFO - 2024-12-01 05:05:52 --> Config Class Initialized
INFO - 2024-12-01 05:05:52 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:05:52 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:05:52 --> Utf8 Class Initialized
INFO - 2024-12-01 05:05:52 --> URI Class Initialized
INFO - 2024-12-01 05:05:52 --> Router Class Initialized
INFO - 2024-12-01 05:05:52 --> Output Class Initialized
INFO - 2024-12-01 05:05:52 --> Security Class Initialized
DEBUG - 2024-12-01 05:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:05:52 --> CSRF cookie sent
INFO - 2024-12-01 05:05:52 --> Input Class Initialized
INFO - 2024-12-01 05:05:52 --> Language Class Initialized
INFO - 2024-12-01 05:05:52 --> Loader Class Initialized
INFO - 2024-12-01 05:05:52 --> Helper loaded: url_helper
INFO - 2024-12-01 05:05:52 --> Helper loaded: form_helper
INFO - 2024-12-01 05:05:52 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:05:52 --> Form Validation Class Initialized
INFO - 2024-12-01 05:05:52 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:05:52 --> Controller Class Initialized
INFO - 2024-12-01 05:05:52 --> Model "User_model" initialized
INFO - 2024-12-01 05:05:52 --> Model "Category_model" initialized
INFO - 2024-12-01 05:05:52 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:05:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 05:05:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 05:05:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 05:05:52 --> Final output sent to browser
DEBUG - 2024-12-01 05:05:52 --> Total execution time: 0.3067
INFO - 2024-12-01 05:42:47 --> Config Class Initialized
INFO - 2024-12-01 05:42:47 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:42:47 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:42:47 --> Utf8 Class Initialized
INFO - 2024-12-01 05:42:47 --> URI Class Initialized
INFO - 2024-12-01 05:42:47 --> Router Class Initialized
INFO - 2024-12-01 05:42:47 --> Output Class Initialized
INFO - 2024-12-01 05:42:47 --> Security Class Initialized
DEBUG - 2024-12-01 05:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:42:47 --> CSRF cookie sent
INFO - 2024-12-01 05:42:47 --> Input Class Initialized
INFO - 2024-12-01 05:42:47 --> Language Class Initialized
INFO - 2024-12-01 05:42:47 --> Loader Class Initialized
INFO - 2024-12-01 05:42:47 --> Helper loaded: url_helper
INFO - 2024-12-01 05:42:47 --> Helper loaded: form_helper
INFO - 2024-12-01 05:42:47 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:42:48 --> Form Validation Class Initialized
INFO - 2024-12-01 05:42:48 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:42:48 --> Controller Class Initialized
INFO - 2024-12-01 05:42:48 --> Model "User_model" initialized
INFO - 2024-12-01 05:42:48 --> Model "Category_model" initialized
INFO - 2024-12-01 05:42:48 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:42:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:42:48 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 121
ERROR - 2024-12-01 05:42:48 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 121
INFO - 2024-12-01 05:45:02 --> Config Class Initialized
INFO - 2024-12-01 05:45:02 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:45:02 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:45:02 --> Utf8 Class Initialized
INFO - 2024-12-01 05:45:02 --> URI Class Initialized
INFO - 2024-12-01 05:45:02 --> Router Class Initialized
INFO - 2024-12-01 05:45:02 --> Output Class Initialized
INFO - 2024-12-01 05:45:02 --> Security Class Initialized
DEBUG - 2024-12-01 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:45:02 --> CSRF cookie sent
INFO - 2024-12-01 05:45:02 --> Input Class Initialized
INFO - 2024-12-01 05:45:02 --> Language Class Initialized
INFO - 2024-12-01 05:45:02 --> Loader Class Initialized
INFO - 2024-12-01 05:45:02 --> Helper loaded: url_helper
INFO - 2024-12-01 05:45:02 --> Helper loaded: form_helper
INFO - 2024-12-01 05:45:02 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:45:02 --> Form Validation Class Initialized
INFO - 2024-12-01 05:45:02 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:45:02 --> Controller Class Initialized
INFO - 2024-12-01 05:45:02 --> Model "User_model" initialized
INFO - 2024-12-01 05:45:02 --> Model "Category_model" initialized
INFO - 2024-12-01 05:45:02 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:45:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:45:02 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:45:02 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:46:24 --> Config Class Initialized
INFO - 2024-12-01 05:46:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:46:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:46:24 --> Utf8 Class Initialized
INFO - 2024-12-01 05:46:24 --> URI Class Initialized
INFO - 2024-12-01 05:46:24 --> Router Class Initialized
INFO - 2024-12-01 05:46:24 --> Output Class Initialized
INFO - 2024-12-01 05:46:24 --> Security Class Initialized
DEBUG - 2024-12-01 05:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:46:24 --> CSRF cookie sent
INFO - 2024-12-01 05:46:24 --> Input Class Initialized
INFO - 2024-12-01 05:46:24 --> Language Class Initialized
INFO - 2024-12-01 05:46:24 --> Loader Class Initialized
INFO - 2024-12-01 05:46:24 --> Helper loaded: url_helper
INFO - 2024-12-01 05:46:24 --> Helper loaded: form_helper
INFO - 2024-12-01 05:46:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:46:24 --> Form Validation Class Initialized
INFO - 2024-12-01 05:46:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:46:24 --> Controller Class Initialized
INFO - 2024-12-01 05:46:24 --> Model "User_model" initialized
INFO - 2024-12-01 05:46:24 --> Model "Category_model" initialized
INFO - 2024-12-01 05:46:24 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:46:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:46:24 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:46:24 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:46:27 --> Config Class Initialized
INFO - 2024-12-01 05:46:27 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:46:27 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:46:27 --> Utf8 Class Initialized
INFO - 2024-12-01 05:46:27 --> URI Class Initialized
INFO - 2024-12-01 05:46:27 --> Router Class Initialized
INFO - 2024-12-01 05:46:27 --> Output Class Initialized
INFO - 2024-12-01 05:46:27 --> Security Class Initialized
DEBUG - 2024-12-01 05:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:46:27 --> CSRF cookie sent
INFO - 2024-12-01 05:46:27 --> Input Class Initialized
INFO - 2024-12-01 05:46:27 --> Language Class Initialized
INFO - 2024-12-01 05:46:27 --> Loader Class Initialized
INFO - 2024-12-01 05:46:27 --> Helper loaded: url_helper
INFO - 2024-12-01 05:46:27 --> Helper loaded: form_helper
INFO - 2024-12-01 05:46:27 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:46:27 --> Form Validation Class Initialized
INFO - 2024-12-01 05:46:27 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:46:27 --> Controller Class Initialized
INFO - 2024-12-01 05:46:27 --> Model "User_model" initialized
INFO - 2024-12-01 05:46:27 --> Model "Category_model" initialized
INFO - 2024-12-01 05:46:27 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:46:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:46:27 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:46:27 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:48:01 --> Config Class Initialized
INFO - 2024-12-01 05:48:01 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:48:01 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:48:01 --> Utf8 Class Initialized
INFO - 2024-12-01 05:48:01 --> URI Class Initialized
INFO - 2024-12-01 05:48:01 --> Router Class Initialized
INFO - 2024-12-01 05:48:01 --> Output Class Initialized
INFO - 2024-12-01 05:48:01 --> Security Class Initialized
DEBUG - 2024-12-01 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:48:01 --> CSRF cookie sent
INFO - 2024-12-01 05:48:01 --> Input Class Initialized
INFO - 2024-12-01 05:48:01 --> Language Class Initialized
INFO - 2024-12-01 05:48:01 --> Loader Class Initialized
INFO - 2024-12-01 05:48:01 --> Helper loaded: url_helper
INFO - 2024-12-01 05:48:01 --> Helper loaded: form_helper
INFO - 2024-12-01 05:48:01 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:48:01 --> Form Validation Class Initialized
INFO - 2024-12-01 05:48:01 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:48:01 --> Controller Class Initialized
INFO - 2024-12-01 05:48:01 --> Model "User_model" initialized
INFO - 2024-12-01 05:48:01 --> Model "Category_model" initialized
INFO - 2024-12-01 05:48:01 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:48:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:48:01 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
ERROR - 2024-12-01 05:48:01 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
INFO - 2024-12-01 05:48:05 --> Config Class Initialized
INFO - 2024-12-01 05:48:05 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:48:05 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:48:05 --> Utf8 Class Initialized
INFO - 2024-12-01 05:48:05 --> URI Class Initialized
INFO - 2024-12-01 05:48:05 --> Router Class Initialized
INFO - 2024-12-01 05:48:05 --> Output Class Initialized
INFO - 2024-12-01 05:48:05 --> Security Class Initialized
DEBUG - 2024-12-01 05:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:48:05 --> CSRF cookie sent
INFO - 2024-12-01 05:48:05 --> Input Class Initialized
INFO - 2024-12-01 05:48:05 --> Language Class Initialized
INFO - 2024-12-01 05:48:05 --> Loader Class Initialized
INFO - 2024-12-01 05:48:05 --> Helper loaded: url_helper
INFO - 2024-12-01 05:48:05 --> Helper loaded: form_helper
INFO - 2024-12-01 05:48:05 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:48:05 --> Form Validation Class Initialized
INFO - 2024-12-01 05:48:05 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:48:05 --> Controller Class Initialized
INFO - 2024-12-01 05:48:05 --> Model "User_model" initialized
INFO - 2024-12-01 05:48:05 --> Model "Category_model" initialized
INFO - 2024-12-01 05:48:05 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:48:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:48:05 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
ERROR - 2024-12-01 05:48:05 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
INFO - 2024-12-01 05:48:05 --> Config Class Initialized
INFO - 2024-12-01 05:48:05 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:48:05 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:48:05 --> Utf8 Class Initialized
INFO - 2024-12-01 05:48:05 --> URI Class Initialized
INFO - 2024-12-01 05:48:05 --> Router Class Initialized
INFO - 2024-12-01 05:48:05 --> Output Class Initialized
INFO - 2024-12-01 05:48:05 --> Security Class Initialized
DEBUG - 2024-12-01 05:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:48:05 --> CSRF cookie sent
INFO - 2024-12-01 05:48:05 --> Input Class Initialized
INFO - 2024-12-01 05:48:05 --> Language Class Initialized
INFO - 2024-12-01 05:48:05 --> Loader Class Initialized
INFO - 2024-12-01 05:48:05 --> Helper loaded: url_helper
INFO - 2024-12-01 05:48:05 --> Helper loaded: form_helper
INFO - 2024-12-01 05:48:05 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:48:05 --> Form Validation Class Initialized
INFO - 2024-12-01 05:48:05 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:48:05 --> Controller Class Initialized
INFO - 2024-12-01 05:48:05 --> Model "User_model" initialized
INFO - 2024-12-01 05:48:05 --> Model "Category_model" initialized
INFO - 2024-12-01 05:48:05 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:48:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:48:05 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
ERROR - 2024-12-01 05:48:05 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
INFO - 2024-12-01 05:49:35 --> Config Class Initialized
INFO - 2024-12-01 05:49:35 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:49:35 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:49:35 --> Utf8 Class Initialized
INFO - 2024-12-01 05:49:35 --> URI Class Initialized
INFO - 2024-12-01 05:49:35 --> Router Class Initialized
INFO - 2024-12-01 05:49:35 --> Output Class Initialized
INFO - 2024-12-01 05:49:35 --> Security Class Initialized
DEBUG - 2024-12-01 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:49:35 --> CSRF cookie sent
INFO - 2024-12-01 05:49:35 --> Input Class Initialized
INFO - 2024-12-01 05:49:35 --> Language Class Initialized
INFO - 2024-12-01 05:49:35 --> Loader Class Initialized
INFO - 2024-12-01 05:49:35 --> Helper loaded: url_helper
INFO - 2024-12-01 05:49:35 --> Helper loaded: form_helper
INFO - 2024-12-01 05:49:35 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:49:36 --> Form Validation Class Initialized
INFO - 2024-12-01 05:49:36 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:49:36 --> Controller Class Initialized
INFO - 2024-12-01 05:49:36 --> Model "User_model" initialized
INFO - 2024-12-01 05:49:36 --> Model "Category_model" initialized
INFO - 2024-12-01 05:49:36 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:49:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:49:36 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
ERROR - 2024-12-01 05:49:36 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 123
INFO - 2024-12-01 05:53:06 --> Config Class Initialized
INFO - 2024-12-01 05:53:06 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:53:06 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:53:06 --> Utf8 Class Initialized
INFO - 2024-12-01 05:53:06 --> URI Class Initialized
INFO - 2024-12-01 05:53:06 --> Router Class Initialized
INFO - 2024-12-01 05:53:06 --> Output Class Initialized
INFO - 2024-12-01 05:53:06 --> Security Class Initialized
DEBUG - 2024-12-01 05:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:53:06 --> CSRF cookie sent
INFO - 2024-12-01 05:53:06 --> Input Class Initialized
INFO - 2024-12-01 05:53:06 --> Language Class Initialized
INFO - 2024-12-01 05:53:06 --> Loader Class Initialized
INFO - 2024-12-01 05:53:06 --> Helper loaded: url_helper
INFO - 2024-12-01 05:53:06 --> Helper loaded: form_helper
INFO - 2024-12-01 05:53:06 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:53:06 --> Form Validation Class Initialized
INFO - 2024-12-01 05:53:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:53:06 --> Model "News_model" initialized
INFO - 2024-12-01 05:53:06 --> Controller Class Initialized
INFO - 2024-12-01 05:53:06 --> Model "User_model" initialized
INFO - 2024-12-01 05:53:06 --> Model "Category_model" initialized
INFO - 2024-12-01 05:53:06 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:53:19 --> Config Class Initialized
INFO - 2024-12-01 05:53:19 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:53:19 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:53:19 --> Utf8 Class Initialized
INFO - 2024-12-01 05:53:19 --> URI Class Initialized
DEBUG - 2024-12-01 05:53:19 --> No URI present. Default controller set.
INFO - 2024-12-01 05:53:19 --> Router Class Initialized
INFO - 2024-12-01 05:53:19 --> Output Class Initialized
INFO - 2024-12-01 05:53:19 --> Security Class Initialized
DEBUG - 2024-12-01 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:53:19 --> CSRF cookie sent
INFO - 2024-12-01 05:53:19 --> Input Class Initialized
INFO - 2024-12-01 05:53:19 --> Language Class Initialized
INFO - 2024-12-01 05:53:19 --> Loader Class Initialized
INFO - 2024-12-01 05:53:19 --> Helper loaded: url_helper
INFO - 2024-12-01 05:53:19 --> Helper loaded: form_helper
INFO - 2024-12-01 05:53:19 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:53:19 --> Form Validation Class Initialized
INFO - 2024-12-01 05:53:19 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:53:19 --> Model "News_model" initialized
INFO - 2024-12-01 05:53:19 --> Controller Class Initialized
INFO - 2024-12-01 05:53:19 --> Model "User_model" initialized
INFO - 2024-12-01 05:53:19 --> Model "Category_model" initialized
INFO - 2024-12-01 05:53:19 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:54:05 --> Config Class Initialized
INFO - 2024-12-01 05:54:05 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:54:05 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:54:05 --> Utf8 Class Initialized
INFO - 2024-12-01 05:54:05 --> URI Class Initialized
DEBUG - 2024-12-01 05:54:05 --> No URI present. Default controller set.
INFO - 2024-12-01 05:54:05 --> Router Class Initialized
INFO - 2024-12-01 05:54:05 --> Output Class Initialized
INFO - 2024-12-01 05:54:05 --> Security Class Initialized
DEBUG - 2024-12-01 05:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:54:05 --> CSRF cookie sent
INFO - 2024-12-01 05:54:05 --> Input Class Initialized
INFO - 2024-12-01 05:54:05 --> Language Class Initialized
INFO - 2024-12-01 05:54:05 --> Loader Class Initialized
INFO - 2024-12-01 05:54:05 --> Helper loaded: url_helper
INFO - 2024-12-01 05:54:05 --> Helper loaded: form_helper
INFO - 2024-12-01 05:54:05 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:54:06 --> Form Validation Class Initialized
INFO - 2024-12-01 05:54:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:54:06 --> Controller Class Initialized
INFO - 2024-12-01 05:54:06 --> Model "User_model" initialized
INFO - 2024-12-01 05:54:06 --> Model "Category_model" initialized
INFO - 2024-12-01 05:54:06 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:54:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:54:06 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:54:06 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:54:58 --> Config Class Initialized
INFO - 2024-12-01 05:54:58 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:54:58 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:54:58 --> Utf8 Class Initialized
INFO - 2024-12-01 05:54:58 --> URI Class Initialized
DEBUG - 2024-12-01 05:54:58 --> No URI present. Default controller set.
INFO - 2024-12-01 05:54:58 --> Router Class Initialized
INFO - 2024-12-01 05:54:58 --> Output Class Initialized
INFO - 2024-12-01 05:54:58 --> Security Class Initialized
DEBUG - 2024-12-01 05:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:54:58 --> CSRF cookie sent
INFO - 2024-12-01 05:54:58 --> Input Class Initialized
INFO - 2024-12-01 05:54:58 --> Language Class Initialized
INFO - 2024-12-01 05:54:58 --> Loader Class Initialized
INFO - 2024-12-01 05:54:58 --> Helper loaded: url_helper
INFO - 2024-12-01 05:54:58 --> Helper loaded: form_helper
INFO - 2024-12-01 05:54:58 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:54:58 --> Form Validation Class Initialized
INFO - 2024-12-01 05:54:58 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:54:58 --> Controller Class Initialized
INFO - 2024-12-01 05:54:58 --> Model "User_model" initialized
INFO - 2024-12-01 05:54:58 --> Model "Category_model" initialized
INFO - 2024-12-01 05:54:58 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:54:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:54:58 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:54:58 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:54:59 --> Config Class Initialized
INFO - 2024-12-01 05:54:59 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:54:59 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:54:59 --> Utf8 Class Initialized
INFO - 2024-12-01 05:54:59 --> URI Class Initialized
DEBUG - 2024-12-01 05:54:59 --> No URI present. Default controller set.
INFO - 2024-12-01 05:54:59 --> Router Class Initialized
INFO - 2024-12-01 05:54:59 --> Output Class Initialized
INFO - 2024-12-01 05:54:59 --> Security Class Initialized
DEBUG - 2024-12-01 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:54:59 --> CSRF cookie sent
INFO - 2024-12-01 05:54:59 --> Input Class Initialized
INFO - 2024-12-01 05:54:59 --> Language Class Initialized
INFO - 2024-12-01 05:54:59 --> Loader Class Initialized
INFO - 2024-12-01 05:54:59 --> Helper loaded: url_helper
INFO - 2024-12-01 05:54:59 --> Helper loaded: form_helper
INFO - 2024-12-01 05:54:59 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:54:59 --> Form Validation Class Initialized
INFO - 2024-12-01 05:54:59 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:54:59 --> Controller Class Initialized
INFO - 2024-12-01 05:54:59 --> Model "User_model" initialized
INFO - 2024-12-01 05:54:59 --> Model "Category_model" initialized
INFO - 2024-12-01 05:54:59 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:54:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:54:59 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:54:59 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:55:02 --> Config Class Initialized
INFO - 2024-12-01 05:55:02 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:55:02 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:55:02 --> Utf8 Class Initialized
INFO - 2024-12-01 05:55:02 --> URI Class Initialized
DEBUG - 2024-12-01 05:55:02 --> No URI present. Default controller set.
INFO - 2024-12-01 05:55:02 --> Router Class Initialized
INFO - 2024-12-01 05:55:02 --> Output Class Initialized
INFO - 2024-12-01 05:55:02 --> Security Class Initialized
DEBUG - 2024-12-01 05:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:55:02 --> CSRF cookie sent
INFO - 2024-12-01 05:55:02 --> Input Class Initialized
INFO - 2024-12-01 05:55:02 --> Language Class Initialized
INFO - 2024-12-01 05:55:02 --> Loader Class Initialized
INFO - 2024-12-01 05:55:02 --> Helper loaded: url_helper
INFO - 2024-12-01 05:55:02 --> Helper loaded: form_helper
INFO - 2024-12-01 05:55:02 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:55:02 --> Form Validation Class Initialized
INFO - 2024-12-01 05:55:02 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:55:02 --> Controller Class Initialized
INFO - 2024-12-01 05:55:02 --> Model "User_model" initialized
INFO - 2024-12-01 05:55:02 --> Model "Category_model" initialized
INFO - 2024-12-01 05:55:02 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:55:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:55:02 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:55:02 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:55:08 --> Config Class Initialized
INFO - 2024-12-01 05:55:08 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:55:08 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:55:08 --> Utf8 Class Initialized
INFO - 2024-12-01 05:55:08 --> URI Class Initialized
DEBUG - 2024-12-01 05:55:08 --> No URI present. Default controller set.
INFO - 2024-12-01 05:55:08 --> Router Class Initialized
INFO - 2024-12-01 05:55:08 --> Output Class Initialized
INFO - 2024-12-01 05:55:08 --> Security Class Initialized
DEBUG - 2024-12-01 05:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:55:08 --> CSRF cookie sent
INFO - 2024-12-01 05:55:08 --> Input Class Initialized
INFO - 2024-12-01 05:55:08 --> Language Class Initialized
INFO - 2024-12-01 05:55:08 --> Loader Class Initialized
INFO - 2024-12-01 05:55:08 --> Helper loaded: url_helper
INFO - 2024-12-01 05:55:08 --> Helper loaded: form_helper
INFO - 2024-12-01 05:55:08 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:55:08 --> Form Validation Class Initialized
INFO - 2024-12-01 05:55:08 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:55:08 --> Controller Class Initialized
INFO - 2024-12-01 05:55:08 --> Model "User_model" initialized
INFO - 2024-12-01 05:55:08 --> Model "Category_model" initialized
INFO - 2024-12-01 05:55:08 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:55:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:55:08 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 05:55:08 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:56:12 --> Config Class Initialized
INFO - 2024-12-01 05:56:12 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:56:12 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:56:12 --> Utf8 Class Initialized
INFO - 2024-12-01 05:56:12 --> URI Class Initialized
DEBUG - 2024-12-01 05:56:12 --> No URI present. Default controller set.
INFO - 2024-12-01 05:56:12 --> Router Class Initialized
INFO - 2024-12-01 05:56:12 --> Output Class Initialized
INFO - 2024-12-01 05:56:12 --> Security Class Initialized
DEBUG - 2024-12-01 05:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:56:12 --> CSRF cookie sent
INFO - 2024-12-01 05:56:12 --> Input Class Initialized
INFO - 2024-12-01 05:56:12 --> Language Class Initialized
INFO - 2024-12-01 05:56:12 --> Loader Class Initialized
INFO - 2024-12-01 05:56:12 --> Helper loaded: url_helper
INFO - 2024-12-01 05:56:12 --> Helper loaded: form_helper
INFO - 2024-12-01 05:56:12 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:56:12 --> Form Validation Class Initialized
INFO - 2024-12-01 05:56:12 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:56:12 --> Controller Class Initialized
INFO - 2024-12-01 05:56:12 --> Model "User_model" initialized
INFO - 2024-12-01 05:56:12 --> Model "Category_model" initialized
INFO - 2024-12-01 05:56:12 --> Model "Review_model" initialized
INFO - 2024-12-01 05:56:12 --> Model "News_model" initialized
DEBUG - 2024-12-01 05:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:56:24 --> Config Class Initialized
INFO - 2024-12-01 05:56:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:56:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:56:24 --> Utf8 Class Initialized
INFO - 2024-12-01 05:56:24 --> URI Class Initialized
DEBUG - 2024-12-01 05:56:24 --> No URI present. Default controller set.
INFO - 2024-12-01 05:56:24 --> Router Class Initialized
INFO - 2024-12-01 05:56:24 --> Output Class Initialized
INFO - 2024-12-01 05:56:24 --> Security Class Initialized
DEBUG - 2024-12-01 05:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:56:24 --> CSRF cookie sent
INFO - 2024-12-01 05:56:24 --> Input Class Initialized
INFO - 2024-12-01 05:56:24 --> Language Class Initialized
INFO - 2024-12-01 05:56:24 --> Loader Class Initialized
INFO - 2024-12-01 05:56:24 --> Helper loaded: url_helper
INFO - 2024-12-01 05:56:24 --> Helper loaded: form_helper
INFO - 2024-12-01 05:56:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:56:24 --> Form Validation Class Initialized
INFO - 2024-12-01 05:56:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:56:24 --> Controller Class Initialized
INFO - 2024-12-01 05:56:24 --> Model "User_model" initialized
INFO - 2024-12-01 05:56:24 --> Model "Category_model" initialized
INFO - 2024-12-01 05:56:24 --> Model "Review_model" initialized
INFO - 2024-12-01 05:56:24 --> Model "News_model" initialized
DEBUG - 2024-12-01 05:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 05:58:24 --> Config Class Initialized
INFO - 2024-12-01 05:58:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:58:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:58:24 --> Utf8 Class Initialized
INFO - 2024-12-01 05:58:24 --> URI Class Initialized
DEBUG - 2024-12-01 05:58:24 --> No URI present. Default controller set.
INFO - 2024-12-01 05:58:24 --> Router Class Initialized
INFO - 2024-12-01 05:58:24 --> Output Class Initialized
INFO - 2024-12-01 05:58:24 --> Security Class Initialized
DEBUG - 2024-12-01 05:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:58:24 --> CSRF cookie sent
INFO - 2024-12-01 05:58:24 --> Input Class Initialized
INFO - 2024-12-01 05:58:24 --> Language Class Initialized
INFO - 2024-12-01 05:58:24 --> Loader Class Initialized
INFO - 2024-12-01 05:58:24 --> Helper loaded: url_helper
INFO - 2024-12-01 05:58:24 --> Helper loaded: form_helper
INFO - 2024-12-01 05:58:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:58:24 --> Form Validation Class Initialized
INFO - 2024-12-01 05:58:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:58:24 --> Controller Class Initialized
INFO - 2024-12-01 05:58:24 --> Model "User_model" initialized
INFO - 2024-12-01 05:58:24 --> Model "Category_model" initialized
INFO - 2024-12-01 05:58:24 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:58:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:58:24 --> Severity: error --> Exception: Call to undefined method User_model::get_all_news() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 05:59:34 --> Config Class Initialized
INFO - 2024-12-01 05:59:34 --> Hooks Class Initialized
DEBUG - 2024-12-01 05:59:34 --> UTF-8 Support Enabled
INFO - 2024-12-01 05:59:34 --> Utf8 Class Initialized
INFO - 2024-12-01 05:59:34 --> URI Class Initialized
DEBUG - 2024-12-01 05:59:34 --> No URI present. Default controller set.
INFO - 2024-12-01 05:59:34 --> Router Class Initialized
INFO - 2024-12-01 05:59:34 --> Output Class Initialized
INFO - 2024-12-01 05:59:34 --> Security Class Initialized
DEBUG - 2024-12-01 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 05:59:34 --> CSRF cookie sent
INFO - 2024-12-01 05:59:34 --> Input Class Initialized
INFO - 2024-12-01 05:59:34 --> Language Class Initialized
INFO - 2024-12-01 05:59:34 --> Loader Class Initialized
INFO - 2024-12-01 05:59:34 --> Helper loaded: url_helper
INFO - 2024-12-01 05:59:34 --> Helper loaded: form_helper
INFO - 2024-12-01 05:59:34 --> Database Driver Class Initialized
DEBUG - 2024-12-01 05:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 05:59:34 --> Form Validation Class Initialized
INFO - 2024-12-01 05:59:34 --> Model "Culinary_model" initialized
INFO - 2024-12-01 05:59:34 --> Controller Class Initialized
INFO - 2024-12-01 05:59:34 --> Model "User_model" initialized
INFO - 2024-12-01 05:59:34 --> Model "Category_model" initialized
INFO - 2024-12-01 05:59:34 --> Model "Review_model" initialized
DEBUG - 2024-12-01 05:59:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 05:59:34 --> Severity: error --> Exception: Call to undefined method User_model::get_all_news() C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 06:02:02 --> Config Class Initialized
INFO - 2024-12-01 06:02:02 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:02:02 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:02:02 --> Utf8 Class Initialized
INFO - 2024-12-01 06:02:02 --> URI Class Initialized
DEBUG - 2024-12-01 06:02:02 --> No URI present. Default controller set.
INFO - 2024-12-01 06:02:02 --> Router Class Initialized
INFO - 2024-12-01 06:02:02 --> Output Class Initialized
INFO - 2024-12-01 06:02:02 --> Security Class Initialized
DEBUG - 2024-12-01 06:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:02:02 --> CSRF cookie sent
INFO - 2024-12-01 06:02:02 --> Input Class Initialized
INFO - 2024-12-01 06:02:02 --> Language Class Initialized
INFO - 2024-12-01 06:02:02 --> Loader Class Initialized
INFO - 2024-12-01 06:02:02 --> Helper loaded: url_helper
INFO - 2024-12-01 06:02:02 --> Helper loaded: form_helper
INFO - 2024-12-01 06:02:02 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:02:02 --> Form Validation Class Initialized
INFO - 2024-12-01 06:02:02 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:02:02 --> Controller Class Initialized
INFO - 2024-12-01 06:02:02 --> Model "User_model" initialized
INFO - 2024-12-01 06:02:02 --> Model "Category_model" initialized
INFO - 2024-12-01 06:02:02 --> Model "Review_model" initialized
DEBUG - 2024-12-01 06:02:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-01 06:02:02 --> Severity: Warning --> Undefined property: Culinary::$News_model C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
ERROR - 2024-12-01 06:02:02 --> Severity: error --> Exception: Call to a member function get_all_news() on null C:\xampp\htdocs\CAMA\Culinary\application\controllers\Culinary.php 122
INFO - 2024-12-01 06:02:41 --> Config Class Initialized
INFO - 2024-12-01 06:02:41 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:02:41 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:02:41 --> Utf8 Class Initialized
INFO - 2024-12-01 06:02:41 --> URI Class Initialized
DEBUG - 2024-12-01 06:02:41 --> No URI present. Default controller set.
INFO - 2024-12-01 06:02:41 --> Router Class Initialized
INFO - 2024-12-01 06:02:41 --> Output Class Initialized
INFO - 2024-12-01 06:02:41 --> Security Class Initialized
DEBUG - 2024-12-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:02:41 --> CSRF cookie sent
INFO - 2024-12-01 06:02:41 --> Input Class Initialized
INFO - 2024-12-01 06:02:41 --> Language Class Initialized
INFO - 2024-12-01 06:02:41 --> Loader Class Initialized
INFO - 2024-12-01 06:02:41 --> Helper loaded: url_helper
INFO - 2024-12-01 06:02:41 --> Helper loaded: form_helper
INFO - 2024-12-01 06:02:41 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:02:41 --> Form Validation Class Initialized
INFO - 2024-12-01 06:02:41 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:02:41 --> Controller Class Initialized
INFO - 2024-12-01 06:02:41 --> Model "User_model" initialized
INFO - 2024-12-01 06:02:41 --> Model "Category_model" initialized
INFO - 2024-12-01 06:02:41 --> Model "Review_model" initialized
INFO - 2024-12-01 06:02:41 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:02:48 --> Config Class Initialized
INFO - 2024-12-01 06:02:48 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:02:48 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:02:48 --> Utf8 Class Initialized
INFO - 2024-12-01 06:02:48 --> URI Class Initialized
DEBUG - 2024-12-01 06:02:48 --> No URI present. Default controller set.
INFO - 2024-12-01 06:02:48 --> Router Class Initialized
INFO - 2024-12-01 06:02:48 --> Output Class Initialized
INFO - 2024-12-01 06:02:48 --> Security Class Initialized
DEBUG - 2024-12-01 06:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:02:48 --> CSRF cookie sent
INFO - 2024-12-01 06:02:48 --> Input Class Initialized
INFO - 2024-12-01 06:02:48 --> Language Class Initialized
INFO - 2024-12-01 06:02:48 --> Loader Class Initialized
INFO - 2024-12-01 06:02:48 --> Helper loaded: url_helper
INFO - 2024-12-01 06:02:48 --> Helper loaded: form_helper
INFO - 2024-12-01 06:02:48 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:02:48 --> Form Validation Class Initialized
INFO - 2024-12-01 06:02:48 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:02:48 --> Controller Class Initialized
INFO - 2024-12-01 06:02:48 --> Model "User_model" initialized
INFO - 2024-12-01 06:02:48 --> Model "Category_model" initialized
INFO - 2024-12-01 06:02:48 --> Model "Review_model" initialized
INFO - 2024-12-01 06:02:48 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:06:53 --> Config Class Initialized
INFO - 2024-12-01 06:06:53 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:06:53 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:06:53 --> Utf8 Class Initialized
INFO - 2024-12-01 06:06:53 --> URI Class Initialized
DEBUG - 2024-12-01 06:06:53 --> No URI present. Default controller set.
INFO - 2024-12-01 06:06:53 --> Router Class Initialized
INFO - 2024-12-01 06:06:53 --> Output Class Initialized
INFO - 2024-12-01 06:06:53 --> Security Class Initialized
DEBUG - 2024-12-01 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:06:53 --> CSRF cookie sent
INFO - 2024-12-01 06:06:53 --> Input Class Initialized
INFO - 2024-12-01 06:06:53 --> Language Class Initialized
INFO - 2024-12-01 06:06:53 --> Loader Class Initialized
INFO - 2024-12-01 06:06:53 --> Helper loaded: url_helper
INFO - 2024-12-01 06:06:53 --> Helper loaded: form_helper
INFO - 2024-12-01 06:06:53 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:06:54 --> Form Validation Class Initialized
INFO - 2024-12-01 06:06:54 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:06:54 --> Controller Class Initialized
INFO - 2024-12-01 06:06:54 --> Model "User_model" initialized
INFO - 2024-12-01 06:06:54 --> Model "Category_model" initialized
INFO - 2024-12-01 06:06:54 --> Model "Review_model" initialized
INFO - 2024-12-01 06:06:54 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:06:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:06:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:06:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:06:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:06:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
ERROR - 2024-12-01 06:06:54 --> Severity: Compile Error --> Cannot declare class Admin, because the name is already in use C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 359
INFO - 2024-12-01 06:10:34 --> Config Class Initialized
INFO - 2024-12-01 06:10:34 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:10:34 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:10:34 --> Utf8 Class Initialized
INFO - 2024-12-01 06:10:34 --> URI Class Initialized
DEBUG - 2024-12-01 06:10:34 --> No URI present. Default controller set.
INFO - 2024-12-01 06:10:34 --> Router Class Initialized
INFO - 2024-12-01 06:10:34 --> Output Class Initialized
INFO - 2024-12-01 06:10:34 --> Security Class Initialized
DEBUG - 2024-12-01 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:10:34 --> CSRF cookie sent
INFO - 2024-12-01 06:10:34 --> Input Class Initialized
INFO - 2024-12-01 06:10:34 --> Language Class Initialized
INFO - 2024-12-01 06:10:34 --> Loader Class Initialized
INFO - 2024-12-01 06:10:34 --> Helper loaded: url_helper
INFO - 2024-12-01 06:10:34 --> Helper loaded: form_helper
INFO - 2024-12-01 06:10:34 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:10:34 --> Form Validation Class Initialized
INFO - 2024-12-01 06:10:34 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:10:34 --> Controller Class Initialized
INFO - 2024-12-01 06:10:34 --> Model "User_model" initialized
INFO - 2024-12-01 06:10:34 --> Model "Category_model" initialized
INFO - 2024-12-01 06:10:34 --> Model "Review_model" initialized
INFO - 2024-12-01 06:10:34 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:10:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:10:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:10:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:10:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:10:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
ERROR - 2024-12-01 06:10:35 --> Severity: Compile Error --> Cannot declare class Admin, because the name is already in use C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 359
INFO - 2024-12-01 06:11:30 --> Config Class Initialized
INFO - 2024-12-01 06:11:30 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:11:30 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:11:30 --> Utf8 Class Initialized
INFO - 2024-12-01 06:11:30 --> URI Class Initialized
DEBUG - 2024-12-01 06:11:30 --> No URI present. Default controller set.
INFO - 2024-12-01 06:11:30 --> Router Class Initialized
INFO - 2024-12-01 06:11:30 --> Output Class Initialized
INFO - 2024-12-01 06:11:30 --> Security Class Initialized
DEBUG - 2024-12-01 06:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:11:30 --> CSRF cookie sent
INFO - 2024-12-01 06:11:30 --> Input Class Initialized
INFO - 2024-12-01 06:11:30 --> Language Class Initialized
INFO - 2024-12-01 06:11:30 --> Loader Class Initialized
INFO - 2024-12-01 06:11:30 --> Helper loaded: url_helper
INFO - 2024-12-01 06:11:30 --> Helper loaded: form_helper
INFO - 2024-12-01 06:11:30 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:11:30 --> Form Validation Class Initialized
INFO - 2024-12-01 06:11:30 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:11:30 --> Controller Class Initialized
INFO - 2024-12-01 06:11:30 --> Model "User_model" initialized
INFO - 2024-12-01 06:11:30 --> Model "Category_model" initialized
INFO - 2024-12-01 06:11:30 --> Model "Review_model" initialized
INFO - 2024-12-01 06:11:30 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:11:30 --> Final output sent to browser
DEBUG - 2024-12-01 06:11:30 --> Total execution time: 0.2294
INFO - 2024-12-01 06:12:06 --> Config Class Initialized
INFO - 2024-12-01 06:12:06 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:06 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:06 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:06 --> URI Class Initialized
DEBUG - 2024-12-01 06:12:06 --> No URI present. Default controller set.
INFO - 2024-12-01 06:12:06 --> Router Class Initialized
INFO - 2024-12-01 06:12:06 --> Output Class Initialized
INFO - 2024-12-01 06:12:06 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:06 --> CSRF cookie sent
INFO - 2024-12-01 06:12:06 --> Input Class Initialized
INFO - 2024-12-01 06:12:06 --> Language Class Initialized
INFO - 2024-12-01 06:12:06 --> Loader Class Initialized
INFO - 2024-12-01 06:12:06 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:06 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:06 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:06 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:06 --> Controller Class Initialized
INFO - 2024-12-01 06:12:06 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:06 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:06 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:06 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:12:06 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:06 --> Total execution time: 0.1173
INFO - 2024-12-01 06:12:15 --> Config Class Initialized
INFO - 2024-12-01 06:12:15 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:15 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:15 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:15 --> URI Class Initialized
INFO - 2024-12-01 06:12:15 --> Router Class Initialized
INFO - 2024-12-01 06:12:15 --> Output Class Initialized
INFO - 2024-12-01 06:12:15 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:15 --> CSRF cookie sent
INFO - 2024-12-01 06:12:15 --> Input Class Initialized
INFO - 2024-12-01 06:12:15 --> Language Class Initialized
INFO - 2024-12-01 06:12:15 --> Loader Class Initialized
INFO - 2024-12-01 06:12:15 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:15 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:15 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:15 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:15 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:15 --> Controller Class Initialized
INFO - 2024-12-01 06:12:15 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:15 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:15 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:15 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-01 06:12:15 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:15 --> Total execution time: 0.2039
INFO - 2024-12-01 06:12:20 --> Config Class Initialized
INFO - 2024-12-01 06:12:20 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:20 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:20 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:20 --> URI Class Initialized
INFO - 2024-12-01 06:12:20 --> Router Class Initialized
INFO - 2024-12-01 06:12:20 --> Output Class Initialized
INFO - 2024-12-01 06:12:20 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:20 --> CSRF cookie sent
INFO - 2024-12-01 06:12:20 --> Input Class Initialized
INFO - 2024-12-01 06:12:20 --> Language Class Initialized
INFO - 2024-12-01 06:12:20 --> Loader Class Initialized
INFO - 2024-12-01 06:12:20 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:20 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:20 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:20 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:20 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:20 --> Controller Class Initialized
INFO - 2024-12-01 06:12:20 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:20 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:20 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:20 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:12:20 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:20 --> Total execution time: 0.0800
INFO - 2024-12-01 06:12:24 --> Config Class Initialized
INFO - 2024-12-01 06:12:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:24 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:24 --> URI Class Initialized
INFO - 2024-12-01 06:12:24 --> Router Class Initialized
INFO - 2024-12-01 06:12:24 --> Output Class Initialized
INFO - 2024-12-01 06:12:24 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:24 --> CSRF cookie sent
INFO - 2024-12-01 06:12:24 --> Input Class Initialized
INFO - 2024-12-01 06:12:24 --> Language Class Initialized
INFO - 2024-12-01 06:12:24 --> Loader Class Initialized
INFO - 2024-12-01 06:12:24 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:24 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:24 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:24 --> Controller Class Initialized
INFO - 2024-12-01 06:12:24 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:24 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:24 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:24 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:12:24 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:24 --> Total execution time: 0.0822
INFO - 2024-12-01 06:12:28 --> Config Class Initialized
INFO - 2024-12-01 06:12:28 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:28 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:28 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:28 --> URI Class Initialized
INFO - 2024-12-01 06:12:28 --> Router Class Initialized
INFO - 2024-12-01 06:12:28 --> Output Class Initialized
INFO - 2024-12-01 06:12:28 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:28 --> CSRF cookie sent
INFO - 2024-12-01 06:12:28 --> CSRF token verified
INFO - 2024-12-01 06:12:28 --> Input Class Initialized
INFO - 2024-12-01 06:12:28 --> Language Class Initialized
INFO - 2024-12-01 06:12:28 --> Loader Class Initialized
INFO - 2024-12-01 06:12:28 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:28 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:28 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:28 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:28 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:28 --> Controller Class Initialized
INFO - 2024-12-01 06:12:28 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:28 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:28 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:28 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:12:28 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:28 --> Total execution time: 0.1637
INFO - 2024-12-01 06:12:34 --> Config Class Initialized
INFO - 2024-12-01 06:12:34 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:34 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:34 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:34 --> URI Class Initialized
INFO - 2024-12-01 06:12:34 --> Router Class Initialized
INFO - 2024-12-01 06:12:34 --> Output Class Initialized
INFO - 2024-12-01 06:12:34 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:34 --> CSRF cookie sent
INFO - 2024-12-01 06:12:34 --> CSRF token verified
INFO - 2024-12-01 06:12:34 --> Input Class Initialized
INFO - 2024-12-01 06:12:34 --> Language Class Initialized
INFO - 2024-12-01 06:12:34 --> Loader Class Initialized
INFO - 2024-12-01 06:12:34 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:34 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:34 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:34 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:34 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:34 --> Controller Class Initialized
INFO - 2024-12-01 06:12:34 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:34 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:34 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:34 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:12:34 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:34 --> Total execution time: 0.0606
INFO - 2024-12-01 06:12:45 --> Config Class Initialized
INFO - 2024-12-01 06:12:45 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:45 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:45 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:45 --> URI Class Initialized
INFO - 2024-12-01 06:12:45 --> Router Class Initialized
INFO - 2024-12-01 06:12:45 --> Output Class Initialized
INFO - 2024-12-01 06:12:45 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:45 --> CSRF cookie sent
INFO - 2024-12-01 06:12:45 --> CSRF token verified
INFO - 2024-12-01 06:12:45 --> Input Class Initialized
INFO - 2024-12-01 06:12:45 --> Language Class Initialized
INFO - 2024-12-01 06:12:45 --> Loader Class Initialized
INFO - 2024-12-01 06:12:45 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:45 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:45 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:45 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:45 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:45 --> Controller Class Initialized
INFO - 2024-12-01 06:12:45 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:45 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:45 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:45 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:12:45 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:45 --> Total execution time: 0.1160
INFO - 2024-12-01 06:12:49 --> Config Class Initialized
INFO - 2024-12-01 06:12:49 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:49 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:49 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:49 --> URI Class Initialized
INFO - 2024-12-01 06:12:49 --> Router Class Initialized
INFO - 2024-12-01 06:12:49 --> Output Class Initialized
INFO - 2024-12-01 06:12:49 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:49 --> CSRF cookie sent
INFO - 2024-12-01 06:12:49 --> CSRF token verified
INFO - 2024-12-01 06:12:49 --> Input Class Initialized
INFO - 2024-12-01 06:12:49 --> Language Class Initialized
INFO - 2024-12-01 06:12:49 --> Loader Class Initialized
INFO - 2024-12-01 06:12:49 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:49 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:49 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:50 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:50 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:50 --> Controller Class Initialized
INFO - 2024-12-01 06:12:50 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:50 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:50 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:50 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:12:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:12:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:12:50 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:50 --> Total execution time: 0.1104
INFO - 2024-12-01 06:12:57 --> Config Class Initialized
INFO - 2024-12-01 06:12:57 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:57 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:57 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:57 --> URI Class Initialized
INFO - 2024-12-01 06:12:57 --> Router Class Initialized
INFO - 2024-12-01 06:12:57 --> Output Class Initialized
INFO - 2024-12-01 06:12:57 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:57 --> CSRF cookie sent
INFO - 2024-12-01 06:12:57 --> CSRF token verified
INFO - 2024-12-01 06:12:57 --> Input Class Initialized
INFO - 2024-12-01 06:12:57 --> Language Class Initialized
INFO - 2024-12-01 06:12:57 --> Loader Class Initialized
INFO - 2024-12-01 06:12:57 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:57 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:57 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:57 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:57 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:57 --> Controller Class Initialized
INFO - 2024-12-01 06:12:57 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:57 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:57 --> Model "Review_model" initialized
INFO - 2024-12-01 06:12:57 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:57 --> Config Class Initialized
INFO - 2024-12-01 06:12:57 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:12:57 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:12:57 --> Utf8 Class Initialized
INFO - 2024-12-01 06:12:57 --> URI Class Initialized
INFO - 2024-12-01 06:12:57 --> Router Class Initialized
INFO - 2024-12-01 06:12:57 --> Output Class Initialized
INFO - 2024-12-01 06:12:57 --> Security Class Initialized
DEBUG - 2024-12-01 06:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:12:57 --> CSRF cookie sent
INFO - 2024-12-01 06:12:57 --> Input Class Initialized
INFO - 2024-12-01 06:12:57 --> Language Class Initialized
INFO - 2024-12-01 06:12:57 --> Loader Class Initialized
INFO - 2024-12-01 06:12:57 --> Helper loaded: url_helper
INFO - 2024-12-01 06:12:57 --> Helper loaded: form_helper
INFO - 2024-12-01 06:12:57 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:12:57 --> Form Validation Class Initialized
INFO - 2024-12-01 06:12:57 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:12:57 --> Controller Class Initialized
INFO - 2024-12-01 06:12:57 --> Model "Category_model" initialized
INFO - 2024-12-01 06:12:57 --> Model "User_model" initialized
INFO - 2024-12-01 06:12:57 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 06:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:12:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-01 06:12:57 --> Final output sent to browser
DEBUG - 2024-12-01 06:12:57 --> Total execution time: 0.1241
INFO - 2024-12-01 06:13:01 --> Config Class Initialized
INFO - 2024-12-01 06:13:01 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:01 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:01 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:01 --> URI Class Initialized
INFO - 2024-12-01 06:13:01 --> Router Class Initialized
INFO - 2024-12-01 06:13:01 --> Output Class Initialized
INFO - 2024-12-01 06:13:01 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:01 --> CSRF cookie sent
INFO - 2024-12-01 06:13:01 --> Input Class Initialized
INFO - 2024-12-01 06:13:01 --> Language Class Initialized
INFO - 2024-12-01 06:13:01 --> Loader Class Initialized
INFO - 2024-12-01 06:13:01 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:01 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:01 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:01 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:01 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:01 --> Controller Class Initialized
INFO - 2024-12-01 06:13:01 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:01 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:01 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:01 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:01 --> Config Class Initialized
INFO - 2024-12-01 06:13:01 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:01 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:01 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:01 --> URI Class Initialized
INFO - 2024-12-01 06:13:01 --> Router Class Initialized
INFO - 2024-12-01 06:13:01 --> Output Class Initialized
INFO - 2024-12-01 06:13:01 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:01 --> CSRF cookie sent
INFO - 2024-12-01 06:13:01 --> Input Class Initialized
INFO - 2024-12-01 06:13:01 --> Language Class Initialized
INFO - 2024-12-01 06:13:01 --> Loader Class Initialized
INFO - 2024-12-01 06:13:01 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:01 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:01 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:01 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:01 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:01 --> Controller Class Initialized
INFO - 2024-12-01 06:13:01 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:01 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:01 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:01 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:13:01 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:01 --> Total execution time: 0.0355
INFO - 2024-12-01 06:13:03 --> Config Class Initialized
INFO - 2024-12-01 06:13:03 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:03 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:03 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:03 --> URI Class Initialized
INFO - 2024-12-01 06:13:03 --> Router Class Initialized
INFO - 2024-12-01 06:13:03 --> Output Class Initialized
INFO - 2024-12-01 06:13:03 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:03 --> CSRF cookie sent
INFO - 2024-12-01 06:13:03 --> Input Class Initialized
INFO - 2024-12-01 06:13:03 --> Language Class Initialized
INFO - 2024-12-01 06:13:03 --> Loader Class Initialized
INFO - 2024-12-01 06:13:03 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:03 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:03 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:03 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:03 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:03 --> Controller Class Initialized
INFO - 2024-12-01 06:13:03 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:03 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:03 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:03 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 06:13:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-01 06:13:03 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:03 --> Total execution time: 0.0660
INFO - 2024-12-01 06:13:24 --> Config Class Initialized
INFO - 2024-12-01 06:13:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:24 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:24 --> URI Class Initialized
INFO - 2024-12-01 06:13:24 --> Router Class Initialized
INFO - 2024-12-01 06:13:24 --> Output Class Initialized
INFO - 2024-12-01 06:13:24 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:24 --> CSRF cookie sent
INFO - 2024-12-01 06:13:24 --> CSRF token verified
INFO - 2024-12-01 06:13:24 --> Input Class Initialized
INFO - 2024-12-01 06:13:24 --> Language Class Initialized
INFO - 2024-12-01 06:13:24 --> Loader Class Initialized
INFO - 2024-12-01 06:13:24 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:24 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:24 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:24 --> Controller Class Initialized
INFO - 2024-12-01 06:13:24 --> Model "User_model" initialized
DEBUG - 2024-12-01 06:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:24 --> User activity log successfully inserted into the user_activity_logs table.
INFO - 2024-12-01 06:13:24 --> Config Class Initialized
INFO - 2024-12-01 06:13:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:24 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:24 --> URI Class Initialized
INFO - 2024-12-01 06:13:24 --> Router Class Initialized
INFO - 2024-12-01 06:13:24 --> Output Class Initialized
INFO - 2024-12-01 06:13:24 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:24 --> CSRF cookie sent
INFO - 2024-12-01 06:13:24 --> Input Class Initialized
INFO - 2024-12-01 06:13:24 --> Language Class Initialized
INFO - 2024-12-01 06:13:24 --> Loader Class Initialized
INFO - 2024-12-01 06:13:24 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:24 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:24 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:24 --> Controller Class Initialized
INFO - 2024-12-01 06:13:24 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:24 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:24 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:24 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:13:24 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:24 --> Total execution time: 0.2454
INFO - 2024-12-01 06:13:31 --> Config Class Initialized
INFO - 2024-12-01 06:13:31 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:31 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:31 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:31 --> URI Class Initialized
INFO - 2024-12-01 06:13:31 --> Router Class Initialized
INFO - 2024-12-01 06:13:31 --> Output Class Initialized
INFO - 2024-12-01 06:13:31 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:31 --> CSRF cookie sent
INFO - 2024-12-01 06:13:31 --> CSRF token verified
INFO - 2024-12-01 06:13:31 --> Input Class Initialized
INFO - 2024-12-01 06:13:31 --> Language Class Initialized
INFO - 2024-12-01 06:13:31 --> Loader Class Initialized
INFO - 2024-12-01 06:13:31 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:31 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:31 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:31 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:31 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:31 --> Controller Class Initialized
INFO - 2024-12-01 06:13:31 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:31 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:31 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:31 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 06:13:31 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:31 --> Total execution time: 0.1583
INFO - 2024-12-01 06:13:43 --> Config Class Initialized
INFO - 2024-12-01 06:13:43 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:43 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:43 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:43 --> URI Class Initialized
INFO - 2024-12-01 06:13:43 --> Router Class Initialized
INFO - 2024-12-01 06:13:43 --> Output Class Initialized
INFO - 2024-12-01 06:13:43 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:43 --> CSRF cookie sent
INFO - 2024-12-01 06:13:43 --> CSRF token verified
INFO - 2024-12-01 06:13:43 --> Input Class Initialized
INFO - 2024-12-01 06:13:43 --> Language Class Initialized
INFO - 2024-12-01 06:13:43 --> Loader Class Initialized
INFO - 2024-12-01 06:13:43 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:43 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:43 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:43 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:43 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:43 --> Controller Class Initialized
INFO - 2024-12-01 06:13:43 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:43 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:43 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:43 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:43 --> Config Class Initialized
INFO - 2024-12-01 06:13:43 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:43 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:43 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:43 --> URI Class Initialized
INFO - 2024-12-01 06:13:43 --> Router Class Initialized
INFO - 2024-12-01 06:13:43 --> Output Class Initialized
INFO - 2024-12-01 06:13:43 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:43 --> CSRF cookie sent
INFO - 2024-12-01 06:13:43 --> Input Class Initialized
INFO - 2024-12-01 06:13:43 --> Language Class Initialized
INFO - 2024-12-01 06:13:43 --> Loader Class Initialized
INFO - 2024-12-01 06:13:43 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:43 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:43 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:43 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:43 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:43 --> Controller Class Initialized
INFO - 2024-12-01 06:13:43 --> Model "User_model" initialized
INFO - 2024-12-01 06:13:43 --> Model "Category_model" initialized
INFO - 2024-12-01 06:13:43 --> Model "Review_model" initialized
INFO - 2024-12-01 06:13:43 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:13:43 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:43 --> Total execution time: 0.0573
INFO - 2024-12-01 06:13:45 --> Config Class Initialized
INFO - 2024-12-01 06:13:45 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:45 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:45 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:45 --> URI Class Initialized
INFO - 2024-12-01 06:13:45 --> Router Class Initialized
INFO - 2024-12-01 06:13:45 --> Output Class Initialized
INFO - 2024-12-01 06:13:45 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:45 --> CSRF cookie sent
INFO - 2024-12-01 06:13:45 --> Input Class Initialized
INFO - 2024-12-01 06:13:45 --> Language Class Initialized
INFO - 2024-12-01 06:13:45 --> Loader Class Initialized
INFO - 2024-12-01 06:13:45 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:45 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:45 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:45 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:45 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:45 --> Controller Class Initialized
INFO - 2024-12-01 06:13:45 --> Model "User_model" initialized
DEBUG - 2024-12-01 06:13:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 06:13:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-01 06:13:45 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:45 --> Total execution time: 0.0707
INFO - 2024-12-01 06:13:49 --> Config Class Initialized
INFO - 2024-12-01 06:13:49 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:13:49 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:13:49 --> Utf8 Class Initialized
INFO - 2024-12-01 06:13:49 --> URI Class Initialized
INFO - 2024-12-01 06:13:49 --> Router Class Initialized
INFO - 2024-12-01 06:13:49 --> Output Class Initialized
INFO - 2024-12-01 06:13:49 --> Security Class Initialized
DEBUG - 2024-12-01 06:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:13:49 --> CSRF cookie sent
INFO - 2024-12-01 06:13:49 --> Input Class Initialized
INFO - 2024-12-01 06:13:49 --> Language Class Initialized
INFO - 2024-12-01 06:13:49 --> Loader Class Initialized
INFO - 2024-12-01 06:13:49 --> Helper loaded: url_helper
INFO - 2024-12-01 06:13:49 --> Helper loaded: form_helper
INFO - 2024-12-01 06:13:49 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:13:49 --> Form Validation Class Initialized
INFO - 2024-12-01 06:13:49 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:13:49 --> Controller Class Initialized
INFO - 2024-12-01 06:13:49 --> Model "User_model" initialized
DEBUG - 2024-12-01 06:13:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 06:13:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:13:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:13:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:13:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-01 06:13:49 --> Final output sent to browser
DEBUG - 2024-12-01 06:13:49 --> Total execution time: 0.0782
INFO - 2024-12-01 06:14:02 --> Config Class Initialized
INFO - 2024-12-01 06:14:02 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:14:02 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:14:02 --> Utf8 Class Initialized
INFO - 2024-12-01 06:14:02 --> URI Class Initialized
INFO - 2024-12-01 06:14:02 --> Router Class Initialized
INFO - 2024-12-01 06:14:02 --> Output Class Initialized
INFO - 2024-12-01 06:14:02 --> Security Class Initialized
DEBUG - 2024-12-01 06:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:14:02 --> CSRF cookie sent
INFO - 2024-12-01 06:14:02 --> CSRF token verified
INFO - 2024-12-01 06:14:02 --> Input Class Initialized
INFO - 2024-12-01 06:14:02 --> Language Class Initialized
INFO - 2024-12-01 06:14:02 --> Loader Class Initialized
INFO - 2024-12-01 06:14:02 --> Helper loaded: url_helper
INFO - 2024-12-01 06:14:02 --> Helper loaded: form_helper
INFO - 2024-12-01 06:14:02 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:14:02 --> Form Validation Class Initialized
INFO - 2024-12-01 06:14:02 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:14:02 --> Controller Class Initialized
INFO - 2024-12-01 06:14:02 --> Model "User_model" initialized
DEBUG - 2024-12-01 06:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 06:14:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:14:02 --> User data with ID 13 successfully updated.
INFO - 2024-12-01 06:14:02 --> Config Class Initialized
INFO - 2024-12-01 06:14:02 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:14:02 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:14:02 --> Utf8 Class Initialized
INFO - 2024-12-01 06:14:02 --> URI Class Initialized
INFO - 2024-12-01 06:14:02 --> Router Class Initialized
INFO - 2024-12-01 06:14:02 --> Output Class Initialized
INFO - 2024-12-01 06:14:02 --> Security Class Initialized
DEBUG - 2024-12-01 06:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:14:02 --> CSRF cookie sent
INFO - 2024-12-01 06:14:02 --> Input Class Initialized
INFO - 2024-12-01 06:14:02 --> Language Class Initialized
INFO - 2024-12-01 06:14:02 --> Loader Class Initialized
INFO - 2024-12-01 06:14:03 --> Helper loaded: url_helper
INFO - 2024-12-01 06:14:03 --> Helper loaded: form_helper
INFO - 2024-12-01 06:14:03 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:14:03 --> Form Validation Class Initialized
INFO - 2024-12-01 06:14:03 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:14:03 --> Controller Class Initialized
INFO - 2024-12-01 06:14:03 --> Model "User_model" initialized
DEBUG - 2024-12-01 06:14:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 06:14:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:14:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:14:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:14:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-01 06:14:03 --> Final output sent to browser
DEBUG - 2024-12-01 06:14:03 --> Total execution time: 0.0435
INFO - 2024-12-01 06:14:06 --> Config Class Initialized
INFO - 2024-12-01 06:14:06 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:14:06 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:14:06 --> Utf8 Class Initialized
INFO - 2024-12-01 06:14:06 --> URI Class Initialized
INFO - 2024-12-01 06:14:06 --> Router Class Initialized
INFO - 2024-12-01 06:14:06 --> Output Class Initialized
INFO - 2024-12-01 06:14:06 --> Security Class Initialized
DEBUG - 2024-12-01 06:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:14:06 --> CSRF cookie sent
INFO - 2024-12-01 06:14:06 --> Input Class Initialized
INFO - 2024-12-01 06:14:06 --> Language Class Initialized
INFO - 2024-12-01 06:14:06 --> Loader Class Initialized
INFO - 2024-12-01 06:14:06 --> Helper loaded: url_helper
INFO - 2024-12-01 06:14:06 --> Helper loaded: form_helper
INFO - 2024-12-01 06:14:06 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:14:06 --> Form Validation Class Initialized
INFO - 2024-12-01 06:14:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:14:06 --> Controller Class Initialized
INFO - 2024-12-01 06:14:06 --> Model "User_model" initialized
DEBUG - 2024-12-01 06:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 06:14:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:14:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:14:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:14:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-01 06:14:06 --> Final output sent to browser
DEBUG - 2024-12-01 06:14:06 --> Total execution time: 0.0633
INFO - 2024-12-01 06:14:13 --> Config Class Initialized
INFO - 2024-12-01 06:14:13 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:14:13 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:14:13 --> Utf8 Class Initialized
INFO - 2024-12-01 06:14:13 --> URI Class Initialized
INFO - 2024-12-01 06:14:13 --> Router Class Initialized
INFO - 2024-12-01 06:14:13 --> Output Class Initialized
INFO - 2024-12-01 06:14:13 --> Security Class Initialized
DEBUG - 2024-12-01 06:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:14:13 --> CSRF cookie sent
INFO - 2024-12-01 06:14:13 --> Input Class Initialized
INFO - 2024-12-01 06:14:13 --> Language Class Initialized
INFO - 2024-12-01 06:14:13 --> Loader Class Initialized
INFO - 2024-12-01 06:14:13 --> Helper loaded: url_helper
INFO - 2024-12-01 06:14:13 --> Helper loaded: form_helper
INFO - 2024-12-01 06:14:13 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:14:13 --> Form Validation Class Initialized
INFO - 2024-12-01 06:14:13 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:14:13 --> Controller Class Initialized
INFO - 2024-12-01 06:14:13 --> Model "User_model" initialized
INFO - 2024-12-01 06:14:13 --> Model "Category_model" initialized
INFO - 2024-12-01 06:14:13 --> Model "Review_model" initialized
INFO - 2024-12-01 06:14:13 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:14:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:14:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:14:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-01 06:14:13 --> Final output sent to browser
DEBUG - 2024-12-01 06:14:13 --> Total execution time: 0.0573
INFO - 2024-12-01 06:14:22 --> Config Class Initialized
INFO - 2024-12-01 06:14:22 --> Hooks Class Initialized
DEBUG - 2024-12-01 06:14:22 --> UTF-8 Support Enabled
INFO - 2024-12-01 06:14:22 --> Utf8 Class Initialized
INFO - 2024-12-01 06:14:22 --> URI Class Initialized
INFO - 2024-12-01 06:14:22 --> Router Class Initialized
INFO - 2024-12-01 06:14:22 --> Output Class Initialized
INFO - 2024-12-01 06:14:22 --> Security Class Initialized
DEBUG - 2024-12-01 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 06:14:22 --> CSRF cookie sent
INFO - 2024-12-01 06:14:22 --> Input Class Initialized
INFO - 2024-12-01 06:14:22 --> Language Class Initialized
INFO - 2024-12-01 06:14:22 --> Loader Class Initialized
INFO - 2024-12-01 06:14:22 --> Helper loaded: url_helper
INFO - 2024-12-01 06:14:22 --> Helper loaded: form_helper
INFO - 2024-12-01 06:14:22 --> Database Driver Class Initialized
DEBUG - 2024-12-01 06:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 06:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 06:14:22 --> Form Validation Class Initialized
INFO - 2024-12-01 06:14:22 --> Model "Culinary_model" initialized
INFO - 2024-12-01 06:14:22 --> Controller Class Initialized
INFO - 2024-12-01 06:14:22 --> Model "User_model" initialized
INFO - 2024-12-01 06:14:22 --> Model "Category_model" initialized
INFO - 2024-12-01 06:14:22 --> Model "Review_model" initialized
INFO - 2024-12-01 06:14:22 --> Model "News_model" initialized
DEBUG - 2024-12-01 06:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 06:14:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 06:14:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 06:14:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 06:14:22 --> Final output sent to browser
DEBUG - 2024-12-01 06:14:22 --> Total execution time: 0.0542
INFO - 2024-12-01 15:40:02 --> Config Class Initialized
INFO - 2024-12-01 15:40:02 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:40:02 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:40:02 --> Utf8 Class Initialized
INFO - 2024-12-01 15:40:02 --> URI Class Initialized
INFO - 2024-12-01 15:40:02 --> Router Class Initialized
INFO - 2024-12-01 15:40:02 --> Output Class Initialized
INFO - 2024-12-01 15:40:02 --> Security Class Initialized
DEBUG - 2024-12-01 15:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:40:02 --> CSRF cookie sent
INFO - 2024-12-01 15:40:02 --> Input Class Initialized
INFO - 2024-12-01 15:40:02 --> Language Class Initialized
INFO - 2024-12-01 15:40:02 --> Loader Class Initialized
INFO - 2024-12-01 15:40:02 --> Helper loaded: url_helper
INFO - 2024-12-01 15:40:02 --> Helper loaded: form_helper
INFO - 2024-12-01 15:40:02 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:40:03 --> Form Validation Class Initialized
INFO - 2024-12-01 15:40:03 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:40:03 --> Controller Class Initialized
INFO - 2024-12-01 15:40:03 --> Model "User_model" initialized
INFO - 2024-12-01 15:40:03 --> Model "Category_model" initialized
INFO - 2024-12-01 15:40:03 --> Model "Review_model" initialized
INFO - 2024-12-01 15:40:03 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:40:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:40:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:40:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:40:03 --> Final output sent to browser
DEBUG - 2024-12-01 15:40:03 --> Total execution time: 0.6518
INFO - 2024-12-01 15:41:37 --> Config Class Initialized
INFO - 2024-12-01 15:41:37 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:41:37 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:41:37 --> Utf8 Class Initialized
INFO - 2024-12-01 15:41:37 --> URI Class Initialized
INFO - 2024-12-01 15:41:37 --> Router Class Initialized
INFO - 2024-12-01 15:41:37 --> Output Class Initialized
INFO - 2024-12-01 15:41:37 --> Security Class Initialized
DEBUG - 2024-12-01 15:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:41:37 --> CSRF cookie sent
INFO - 2024-12-01 15:41:37 --> Input Class Initialized
INFO - 2024-12-01 15:41:37 --> Language Class Initialized
INFO - 2024-12-01 15:41:37 --> Loader Class Initialized
INFO - 2024-12-01 15:41:37 --> Helper loaded: url_helper
INFO - 2024-12-01 15:41:37 --> Helper loaded: form_helper
INFO - 2024-12-01 15:41:37 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:41:37 --> Form Validation Class Initialized
INFO - 2024-12-01 15:41:37 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:41:37 --> Controller Class Initialized
INFO - 2024-12-01 15:41:37 --> Model "User_model" initialized
INFO - 2024-12-01 15:41:37 --> Model "Category_model" initialized
INFO - 2024-12-01 15:41:37 --> Model "Review_model" initialized
INFO - 2024-12-01 15:41:37 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:41:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:41:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:41:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:41:37 --> Final output sent to browser
DEBUG - 2024-12-01 15:41:37 --> Total execution time: 0.1037
INFO - 2024-12-01 15:42:35 --> Config Class Initialized
INFO - 2024-12-01 15:42:35 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:42:35 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:42:35 --> Utf8 Class Initialized
INFO - 2024-12-01 15:42:35 --> URI Class Initialized
INFO - 2024-12-01 15:42:35 --> Router Class Initialized
INFO - 2024-12-01 15:42:35 --> Output Class Initialized
INFO - 2024-12-01 15:42:35 --> Security Class Initialized
DEBUG - 2024-12-01 15:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:42:35 --> CSRF cookie sent
INFO - 2024-12-01 15:42:35 --> Input Class Initialized
INFO - 2024-12-01 15:42:35 --> Language Class Initialized
INFO - 2024-12-01 15:42:35 --> Loader Class Initialized
INFO - 2024-12-01 15:42:35 --> Helper loaded: url_helper
INFO - 2024-12-01 15:42:35 --> Helper loaded: form_helper
INFO - 2024-12-01 15:42:35 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:42:35 --> Form Validation Class Initialized
INFO - 2024-12-01 15:42:35 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:42:35 --> Controller Class Initialized
INFO - 2024-12-01 15:42:35 --> Model "User_model" initialized
INFO - 2024-12-01 15:42:35 --> Model "Category_model" initialized
INFO - 2024-12-01 15:42:35 --> Model "Review_model" initialized
INFO - 2024-12-01 15:42:35 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:42:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:42:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:42:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:42:35 --> Final output sent to browser
DEBUG - 2024-12-01 15:42:35 --> Total execution time: 0.3108
INFO - 2024-12-01 15:44:15 --> Config Class Initialized
INFO - 2024-12-01 15:44:15 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:44:15 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:44:15 --> Utf8 Class Initialized
INFO - 2024-12-01 15:44:15 --> URI Class Initialized
INFO - 2024-12-01 15:44:15 --> Router Class Initialized
INFO - 2024-12-01 15:44:15 --> Output Class Initialized
INFO - 2024-12-01 15:44:15 --> Security Class Initialized
DEBUG - 2024-12-01 15:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:44:15 --> CSRF cookie sent
INFO - 2024-12-01 15:44:15 --> Input Class Initialized
INFO - 2024-12-01 15:44:15 --> Language Class Initialized
INFO - 2024-12-01 15:44:15 --> Loader Class Initialized
INFO - 2024-12-01 15:44:15 --> Helper loaded: url_helper
INFO - 2024-12-01 15:44:15 --> Helper loaded: form_helper
INFO - 2024-12-01 15:44:15 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:44:15 --> Form Validation Class Initialized
INFO - 2024-12-01 15:44:15 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:44:15 --> Controller Class Initialized
INFO - 2024-12-01 15:44:15 --> Model "User_model" initialized
INFO - 2024-12-01 15:44:15 --> Model "Category_model" initialized
INFO - 2024-12-01 15:44:15 --> Model "Review_model" initialized
INFO - 2024-12-01 15:44:15 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:44:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:44:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:44:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:44:16 --> Final output sent to browser
DEBUG - 2024-12-01 15:44:16 --> Total execution time: 0.2188
INFO - 2024-12-01 15:44:20 --> Config Class Initialized
INFO - 2024-12-01 15:44:20 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:44:20 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:44:20 --> Utf8 Class Initialized
INFO - 2024-12-01 15:44:20 --> URI Class Initialized
INFO - 2024-12-01 15:44:20 --> Router Class Initialized
INFO - 2024-12-01 15:44:20 --> Output Class Initialized
INFO - 2024-12-01 15:44:20 --> Security Class Initialized
DEBUG - 2024-12-01 15:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:44:20 --> CSRF cookie sent
INFO - 2024-12-01 15:44:20 --> Input Class Initialized
INFO - 2024-12-01 15:44:20 --> Language Class Initialized
INFO - 2024-12-01 15:44:20 --> Loader Class Initialized
INFO - 2024-12-01 15:44:20 --> Helper loaded: url_helper
INFO - 2024-12-01 15:44:20 --> Helper loaded: form_helper
INFO - 2024-12-01 15:44:20 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:44:20 --> Form Validation Class Initialized
INFO - 2024-12-01 15:44:20 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:44:20 --> Controller Class Initialized
INFO - 2024-12-01 15:44:20 --> Model "User_model" initialized
INFO - 2024-12-01 15:44:20 --> Model "Category_model" initialized
INFO - 2024-12-01 15:44:20 --> Model "Review_model" initialized
INFO - 2024-12-01 15:44:20 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:44:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:44:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:44:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:44:20 --> Final output sent to browser
DEBUG - 2024-12-01 15:44:20 --> Total execution time: 0.1059
INFO - 2024-12-01 15:44:24 --> Config Class Initialized
INFO - 2024-12-01 15:44:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:44:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:44:24 --> Utf8 Class Initialized
INFO - 2024-12-01 15:44:24 --> URI Class Initialized
INFO - 2024-12-01 15:44:24 --> Router Class Initialized
INFO - 2024-12-01 15:44:24 --> Output Class Initialized
INFO - 2024-12-01 15:44:24 --> Security Class Initialized
DEBUG - 2024-12-01 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:44:24 --> CSRF cookie sent
INFO - 2024-12-01 15:44:24 --> Input Class Initialized
INFO - 2024-12-01 15:44:24 --> Language Class Initialized
INFO - 2024-12-01 15:44:24 --> Loader Class Initialized
INFO - 2024-12-01 15:44:24 --> Helper loaded: url_helper
INFO - 2024-12-01 15:44:24 --> Helper loaded: form_helper
INFO - 2024-12-01 15:44:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:44:24 --> Form Validation Class Initialized
INFO - 2024-12-01 15:44:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:44:24 --> Controller Class Initialized
INFO - 2024-12-01 15:44:24 --> Model "User_model" initialized
INFO - 2024-12-01 15:44:24 --> Model "Category_model" initialized
INFO - 2024-12-01 15:44:24 --> Model "Review_model" initialized
INFO - 2024-12-01 15:44:24 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:44:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-01 15:44:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:44:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:44:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:44:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-01 15:44:24 --> Final output sent to browser
DEBUG - 2024-12-01 15:44:24 --> Total execution time: 0.1047
INFO - 2024-12-01 15:44:27 --> Config Class Initialized
INFO - 2024-12-01 15:44:27 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:44:27 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:44:27 --> Utf8 Class Initialized
INFO - 2024-12-01 15:44:27 --> URI Class Initialized
INFO - 2024-12-01 15:44:27 --> Router Class Initialized
INFO - 2024-12-01 15:44:27 --> Output Class Initialized
INFO - 2024-12-01 15:44:27 --> Security Class Initialized
DEBUG - 2024-12-01 15:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:44:27 --> CSRF cookie sent
INFO - 2024-12-01 15:44:27 --> Input Class Initialized
INFO - 2024-12-01 15:44:27 --> Language Class Initialized
INFO - 2024-12-01 15:44:27 --> Loader Class Initialized
INFO - 2024-12-01 15:44:27 --> Helper loaded: url_helper
INFO - 2024-12-01 15:44:27 --> Helper loaded: form_helper
INFO - 2024-12-01 15:44:27 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:44:27 --> Form Validation Class Initialized
INFO - 2024-12-01 15:44:27 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:44:27 --> Controller Class Initialized
INFO - 2024-12-01 15:44:27 --> Model "User_model" initialized
INFO - 2024-12-01 15:44:27 --> Model "Category_model" initialized
INFO - 2024-12-01 15:44:27 --> Model "Review_model" initialized
INFO - 2024-12-01 15:44:27 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:44:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:44:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:44:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:44:27 --> Final output sent to browser
DEBUG - 2024-12-01 15:44:27 --> Total execution time: 0.0605
INFO - 2024-12-01 15:48:50 --> Config Class Initialized
INFO - 2024-12-01 15:48:50 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:48:50 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:48:50 --> Utf8 Class Initialized
INFO - 2024-12-01 15:48:50 --> URI Class Initialized
INFO - 2024-12-01 15:48:50 --> Router Class Initialized
INFO - 2024-12-01 15:48:50 --> Output Class Initialized
INFO - 2024-12-01 15:48:50 --> Security Class Initialized
DEBUG - 2024-12-01 15:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:48:50 --> CSRF cookie sent
INFO - 2024-12-01 15:48:50 --> Input Class Initialized
INFO - 2024-12-01 15:48:50 --> Language Class Initialized
INFO - 2024-12-01 15:48:50 --> Loader Class Initialized
INFO - 2024-12-01 15:48:50 --> Helper loaded: url_helper
INFO - 2024-12-01 15:48:50 --> Helper loaded: form_helper
INFO - 2024-12-01 15:48:50 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:48:50 --> Form Validation Class Initialized
INFO - 2024-12-01 15:48:50 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:48:50 --> Controller Class Initialized
INFO - 2024-12-01 15:48:50 --> Model "User_model" initialized
INFO - 2024-12-01 15:48:50 --> Model "Category_model" initialized
INFO - 2024-12-01 15:48:50 --> Model "Review_model" initialized
INFO - 2024-12-01 15:48:50 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:48:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:48:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:48:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:48:50 --> Final output sent to browser
DEBUG - 2024-12-01 15:48:50 --> Total execution time: 0.2799
INFO - 2024-12-01 15:48:56 --> Config Class Initialized
INFO - 2024-12-01 15:48:56 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:48:56 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:48:56 --> Utf8 Class Initialized
INFO - 2024-12-01 15:48:56 --> URI Class Initialized
INFO - 2024-12-01 15:48:56 --> Router Class Initialized
INFO - 2024-12-01 15:48:56 --> Output Class Initialized
INFO - 2024-12-01 15:48:56 --> Security Class Initialized
DEBUG - 2024-12-01 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:48:56 --> CSRF cookie sent
INFO - 2024-12-01 15:48:56 --> Input Class Initialized
INFO - 2024-12-01 15:48:56 --> Language Class Initialized
INFO - 2024-12-01 15:48:56 --> Loader Class Initialized
INFO - 2024-12-01 15:48:56 --> Helper loaded: url_helper
INFO - 2024-12-01 15:48:56 --> Helper loaded: form_helper
INFO - 2024-12-01 15:48:56 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:48:56 --> Form Validation Class Initialized
INFO - 2024-12-01 15:48:56 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:48:56 --> Controller Class Initialized
INFO - 2024-12-01 15:48:56 --> Model "User_model" initialized
INFO - 2024-12-01 15:48:56 --> Model "Category_model" initialized
INFO - 2024-12-01 15:48:56 --> Model "Review_model" initialized
INFO - 2024-12-01 15:48:56 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:48:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:48:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:48:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:48:56 --> Final output sent to browser
DEBUG - 2024-12-01 15:48:56 --> Total execution time: 0.1264
INFO - 2024-12-01 15:49:03 --> Config Class Initialized
INFO - 2024-12-01 15:49:03 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:49:03 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:49:03 --> Utf8 Class Initialized
INFO - 2024-12-01 15:49:03 --> URI Class Initialized
INFO - 2024-12-01 15:49:03 --> Router Class Initialized
INFO - 2024-12-01 15:49:03 --> Output Class Initialized
INFO - 2024-12-01 15:49:03 --> Security Class Initialized
DEBUG - 2024-12-01 15:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:49:03 --> CSRF cookie sent
INFO - 2024-12-01 15:49:03 --> Input Class Initialized
INFO - 2024-12-01 15:49:03 --> Language Class Initialized
INFO - 2024-12-01 15:49:03 --> Loader Class Initialized
INFO - 2024-12-01 15:49:03 --> Helper loaded: url_helper
INFO - 2024-12-01 15:49:03 --> Helper loaded: form_helper
INFO - 2024-12-01 15:49:03 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:49:03 --> Form Validation Class Initialized
INFO - 2024-12-01 15:49:03 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:49:03 --> Controller Class Initialized
INFO - 2024-12-01 15:49:03 --> Model "User_model" initialized
INFO - 2024-12-01 15:49:03 --> Model "Category_model" initialized
INFO - 2024-12-01 15:49:03 --> Model "Review_model" initialized
INFO - 2024-12-01 15:49:03 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:49:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:49:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:49:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:49:03 --> Final output sent to browser
DEBUG - 2024-12-01 15:49:03 --> Total execution time: 0.0864
INFO - 2024-12-01 15:53:54 --> Config Class Initialized
INFO - 2024-12-01 15:53:54 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:53:54 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:53:54 --> Utf8 Class Initialized
INFO - 2024-12-01 15:53:54 --> URI Class Initialized
INFO - 2024-12-01 15:53:54 --> Router Class Initialized
INFO - 2024-12-01 15:53:54 --> Output Class Initialized
INFO - 2024-12-01 15:53:54 --> Security Class Initialized
DEBUG - 2024-12-01 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:53:54 --> CSRF cookie sent
INFO - 2024-12-01 15:53:54 --> Input Class Initialized
INFO - 2024-12-01 15:53:54 --> Language Class Initialized
INFO - 2024-12-01 15:53:54 --> Loader Class Initialized
INFO - 2024-12-01 15:53:54 --> Helper loaded: url_helper
INFO - 2024-12-01 15:53:54 --> Helper loaded: form_helper
INFO - 2024-12-01 15:53:54 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:53:54 --> Form Validation Class Initialized
INFO - 2024-12-01 15:53:54 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:53:54 --> Controller Class Initialized
INFO - 2024-12-01 15:53:54 --> Model "User_model" initialized
INFO - 2024-12-01 15:53:54 --> Model "Category_model" initialized
INFO - 2024-12-01 15:53:54 --> Model "Review_model" initialized
INFO - 2024-12-01 15:53:54 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:53:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:53:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:53:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:53:54 --> Final output sent to browser
DEBUG - 2024-12-01 15:53:54 --> Total execution time: 0.4087
INFO - 2024-12-01 15:54:59 --> Config Class Initialized
INFO - 2024-12-01 15:54:59 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:54:59 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:54:59 --> Utf8 Class Initialized
INFO - 2024-12-01 15:54:59 --> URI Class Initialized
INFO - 2024-12-01 15:54:59 --> Router Class Initialized
INFO - 2024-12-01 15:54:59 --> Output Class Initialized
INFO - 2024-12-01 15:54:59 --> Security Class Initialized
DEBUG - 2024-12-01 15:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:54:59 --> CSRF cookie sent
INFO - 2024-12-01 15:54:59 --> Input Class Initialized
INFO - 2024-12-01 15:54:59 --> Language Class Initialized
INFO - 2024-12-01 15:54:59 --> Loader Class Initialized
INFO - 2024-12-01 15:54:59 --> Helper loaded: url_helper
INFO - 2024-12-01 15:54:59 --> Helper loaded: form_helper
INFO - 2024-12-01 15:54:59 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:55:00 --> Form Validation Class Initialized
INFO - 2024-12-01 15:55:00 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:55:00 --> Controller Class Initialized
INFO - 2024-12-01 15:55:00 --> Model "User_model" initialized
INFO - 2024-12-01 15:55:00 --> Model "Category_model" initialized
INFO - 2024-12-01 15:55:00 --> Model "Review_model" initialized
INFO - 2024-12-01 15:55:00 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:55:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:55:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:55:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:55:00 --> Final output sent to browser
DEBUG - 2024-12-01 15:55:00 --> Total execution time: 0.5208
INFO - 2024-12-01 15:55:04 --> Config Class Initialized
INFO - 2024-12-01 15:55:04 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:55:04 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:55:04 --> Utf8 Class Initialized
INFO - 2024-12-01 15:55:04 --> URI Class Initialized
INFO - 2024-12-01 15:55:04 --> Router Class Initialized
INFO - 2024-12-01 15:55:04 --> Output Class Initialized
INFO - 2024-12-01 15:55:04 --> Security Class Initialized
DEBUG - 2024-12-01 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:55:04 --> CSRF cookie sent
INFO - 2024-12-01 15:55:04 --> Input Class Initialized
INFO - 2024-12-01 15:55:04 --> Language Class Initialized
INFO - 2024-12-01 15:55:04 --> Loader Class Initialized
INFO - 2024-12-01 15:55:04 --> Helper loaded: url_helper
INFO - 2024-12-01 15:55:04 --> Helper loaded: form_helper
INFO - 2024-12-01 15:55:04 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:55:04 --> Form Validation Class Initialized
INFO - 2024-12-01 15:55:04 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:55:04 --> Controller Class Initialized
INFO - 2024-12-01 15:55:04 --> Model "User_model" initialized
INFO - 2024-12-01 15:55:04 --> Model "Category_model" initialized
INFO - 2024-12-01 15:55:04 --> Model "Review_model" initialized
INFO - 2024-12-01 15:55:04 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:55:04 --> Final output sent to browser
DEBUG - 2024-12-01 15:55:04 --> Total execution time: 0.2106
INFO - 2024-12-01 15:55:05 --> Config Class Initialized
INFO - 2024-12-01 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:55:05 --> Utf8 Class Initialized
INFO - 2024-12-01 15:55:05 --> URI Class Initialized
INFO - 2024-12-01 15:55:05 --> Router Class Initialized
INFO - 2024-12-01 15:55:05 --> Output Class Initialized
INFO - 2024-12-01 15:55:05 --> Security Class Initialized
DEBUG - 2024-12-01 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:55:05 --> CSRF cookie sent
INFO - 2024-12-01 15:55:05 --> Input Class Initialized
INFO - 2024-12-01 15:55:05 --> Language Class Initialized
INFO - 2024-12-01 15:55:05 --> Loader Class Initialized
INFO - 2024-12-01 15:55:05 --> Helper loaded: url_helper
INFO - 2024-12-01 15:55:05 --> Helper loaded: form_helper
INFO - 2024-12-01 15:55:05 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:55:05 --> Form Validation Class Initialized
INFO - 2024-12-01 15:55:05 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:55:05 --> Controller Class Initialized
INFO - 2024-12-01 15:55:05 --> Model "User_model" initialized
INFO - 2024-12-01 15:55:05 --> Model "Category_model" initialized
INFO - 2024-12-01 15:55:05 --> Model "Review_model" initialized
INFO - 2024-12-01 15:55:05 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:55:05 --> Final output sent to browser
DEBUG - 2024-12-01 15:55:05 --> Total execution time: 0.0962
INFO - 2024-12-01 15:55:05 --> Config Class Initialized
INFO - 2024-12-01 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:55:05 --> Utf8 Class Initialized
INFO - 2024-12-01 15:55:05 --> URI Class Initialized
INFO - 2024-12-01 15:55:05 --> Router Class Initialized
INFO - 2024-12-01 15:55:05 --> Output Class Initialized
INFO - 2024-12-01 15:55:05 --> Security Class Initialized
DEBUG - 2024-12-01 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:55:05 --> CSRF cookie sent
INFO - 2024-12-01 15:55:05 --> Input Class Initialized
INFO - 2024-12-01 15:55:05 --> Language Class Initialized
INFO - 2024-12-01 15:55:05 --> Loader Class Initialized
INFO - 2024-12-01 15:55:05 --> Helper loaded: url_helper
INFO - 2024-12-01 15:55:05 --> Helper loaded: form_helper
INFO - 2024-12-01 15:55:05 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:55:05 --> Form Validation Class Initialized
INFO - 2024-12-01 15:55:05 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:55:05 --> Controller Class Initialized
INFO - 2024-12-01 15:55:05 --> Model "User_model" initialized
INFO - 2024-12-01 15:55:05 --> Model "Category_model" initialized
INFO - 2024-12-01 15:55:05 --> Model "Review_model" initialized
INFO - 2024-12-01 15:55:05 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:55:05 --> Final output sent to browser
DEBUG - 2024-12-01 15:55:05 --> Total execution time: 0.0621
INFO - 2024-12-01 15:55:05 --> Config Class Initialized
INFO - 2024-12-01 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:55:05 --> Utf8 Class Initialized
INFO - 2024-12-01 15:55:05 --> URI Class Initialized
INFO - 2024-12-01 15:55:05 --> Router Class Initialized
INFO - 2024-12-01 15:55:06 --> Output Class Initialized
INFO - 2024-12-01 15:55:06 --> Security Class Initialized
DEBUG - 2024-12-01 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:55:06 --> CSRF cookie sent
INFO - 2024-12-01 15:55:06 --> Input Class Initialized
INFO - 2024-12-01 15:55:06 --> Language Class Initialized
INFO - 2024-12-01 15:55:06 --> Loader Class Initialized
INFO - 2024-12-01 15:55:06 --> Helper loaded: url_helper
INFO - 2024-12-01 15:55:06 --> Helper loaded: form_helper
INFO - 2024-12-01 15:55:06 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:55:06 --> Form Validation Class Initialized
INFO - 2024-12-01 15:55:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:55:06 --> Controller Class Initialized
INFO - 2024-12-01 15:55:06 --> Model "User_model" initialized
INFO - 2024-12-01 15:55:06 --> Model "Category_model" initialized
INFO - 2024-12-01 15:55:06 --> Model "Review_model" initialized
INFO - 2024-12-01 15:55:06 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:55:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:55:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:55:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:55:06 --> Final output sent to browser
DEBUG - 2024-12-01 15:55:06 --> Total execution time: 0.1058
INFO - 2024-12-01 15:55:13 --> Config Class Initialized
INFO - 2024-12-01 15:55:13 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:55:13 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:55:13 --> Utf8 Class Initialized
INFO - 2024-12-01 15:55:13 --> URI Class Initialized
INFO - 2024-12-01 15:55:13 --> Router Class Initialized
INFO - 2024-12-01 15:55:13 --> Output Class Initialized
INFO - 2024-12-01 15:55:13 --> Security Class Initialized
DEBUG - 2024-12-01 15:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:55:13 --> CSRF cookie sent
INFO - 2024-12-01 15:55:13 --> Input Class Initialized
INFO - 2024-12-01 15:55:13 --> Language Class Initialized
INFO - 2024-12-01 15:55:13 --> Loader Class Initialized
INFO - 2024-12-01 15:55:13 --> Helper loaded: url_helper
INFO - 2024-12-01 15:55:13 --> Helper loaded: form_helper
INFO - 2024-12-01 15:55:13 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:55:13 --> Form Validation Class Initialized
INFO - 2024-12-01 15:55:13 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:55:13 --> Controller Class Initialized
INFO - 2024-12-01 15:55:13 --> Model "User_model" initialized
INFO - 2024-12-01 15:55:13 --> Model "Category_model" initialized
INFO - 2024-12-01 15:55:13 --> Model "Review_model" initialized
INFO - 2024-12-01 15:55:13 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:55:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:55:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:55:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:55:13 --> Final output sent to browser
DEBUG - 2024-12-01 15:55:13 --> Total execution time: 0.1393
INFO - 2024-12-01 15:58:19 --> Config Class Initialized
INFO - 2024-12-01 15:58:19 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:58:19 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:58:19 --> Utf8 Class Initialized
INFO - 2024-12-01 15:58:19 --> URI Class Initialized
INFO - 2024-12-01 15:58:19 --> Router Class Initialized
INFO - 2024-12-01 15:58:19 --> Output Class Initialized
INFO - 2024-12-01 15:58:19 --> Security Class Initialized
DEBUG - 2024-12-01 15:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:58:19 --> CSRF cookie sent
INFO - 2024-12-01 15:58:19 --> Input Class Initialized
INFO - 2024-12-01 15:58:19 --> Language Class Initialized
INFO - 2024-12-01 15:58:19 --> Loader Class Initialized
INFO - 2024-12-01 15:58:19 --> Helper loaded: url_helper
INFO - 2024-12-01 15:58:19 --> Helper loaded: form_helper
INFO - 2024-12-01 15:58:19 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:58:19 --> Form Validation Class Initialized
INFO - 2024-12-01 15:58:19 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:58:19 --> Controller Class Initialized
INFO - 2024-12-01 15:58:19 --> Model "User_model" initialized
INFO - 2024-12-01 15:58:19 --> Model "Category_model" initialized
INFO - 2024-12-01 15:58:19 --> Model "Review_model" initialized
INFO - 2024-12-01 15:58:19 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:58:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:58:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:58:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:58:19 --> Final output sent to browser
DEBUG - 2024-12-01 15:58:19 --> Total execution time: 0.3294
INFO - 2024-12-01 15:59:11 --> Config Class Initialized
INFO - 2024-12-01 15:59:11 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:59:11 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:59:11 --> Utf8 Class Initialized
INFO - 2024-12-01 15:59:11 --> URI Class Initialized
INFO - 2024-12-01 15:59:11 --> Router Class Initialized
INFO - 2024-12-01 15:59:11 --> Output Class Initialized
INFO - 2024-12-01 15:59:11 --> Security Class Initialized
DEBUG - 2024-12-01 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:59:11 --> CSRF cookie sent
INFO - 2024-12-01 15:59:11 --> Input Class Initialized
INFO - 2024-12-01 15:59:11 --> Language Class Initialized
INFO - 2024-12-01 15:59:11 --> Loader Class Initialized
INFO - 2024-12-01 15:59:11 --> Helper loaded: url_helper
INFO - 2024-12-01 15:59:11 --> Helper loaded: form_helper
INFO - 2024-12-01 15:59:11 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:59:11 --> Form Validation Class Initialized
INFO - 2024-12-01 15:59:11 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:59:11 --> Controller Class Initialized
INFO - 2024-12-01 15:59:11 --> Model "User_model" initialized
INFO - 2024-12-01 15:59:11 --> Model "Category_model" initialized
INFO - 2024-12-01 15:59:11 --> Model "Review_model" initialized
INFO - 2024-12-01 15:59:11 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:59:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:59:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:59:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:59:11 --> Final output sent to browser
DEBUG - 2024-12-01 15:59:11 --> Total execution time: 0.2646
INFO - 2024-12-01 15:59:17 --> Config Class Initialized
INFO - 2024-12-01 15:59:17 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:59:17 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:59:17 --> Utf8 Class Initialized
INFO - 2024-12-01 15:59:17 --> URI Class Initialized
INFO - 2024-12-01 15:59:17 --> Router Class Initialized
INFO - 2024-12-01 15:59:17 --> Output Class Initialized
INFO - 2024-12-01 15:59:17 --> Security Class Initialized
DEBUG - 2024-12-01 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:59:17 --> CSRF cookie sent
INFO - 2024-12-01 15:59:17 --> Input Class Initialized
INFO - 2024-12-01 15:59:17 --> Language Class Initialized
INFO - 2024-12-01 15:59:17 --> Loader Class Initialized
INFO - 2024-12-01 15:59:17 --> Helper loaded: url_helper
INFO - 2024-12-01 15:59:17 --> Helper loaded: form_helper
INFO - 2024-12-01 15:59:17 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:59:18 --> Form Validation Class Initialized
INFO - 2024-12-01 15:59:18 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:59:18 --> Controller Class Initialized
INFO - 2024-12-01 15:59:18 --> Model "User_model" initialized
INFO - 2024-12-01 15:59:18 --> Model "Category_model" initialized
INFO - 2024-12-01 15:59:18 --> Model "Review_model" initialized
INFO - 2024-12-01 15:59:18 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:59:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:59:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:59:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:59:18 --> Final output sent to browser
DEBUG - 2024-12-01 15:59:18 --> Total execution time: 0.2455
INFO - 2024-12-01 15:59:19 --> Config Class Initialized
INFO - 2024-12-01 15:59:19 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:59:19 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:59:19 --> Utf8 Class Initialized
INFO - 2024-12-01 15:59:19 --> URI Class Initialized
INFO - 2024-12-01 15:59:19 --> Router Class Initialized
INFO - 2024-12-01 15:59:19 --> Output Class Initialized
INFO - 2024-12-01 15:59:19 --> Security Class Initialized
DEBUG - 2024-12-01 15:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:59:19 --> CSRF cookie sent
INFO - 2024-12-01 15:59:19 --> Input Class Initialized
INFO - 2024-12-01 15:59:19 --> Language Class Initialized
INFO - 2024-12-01 15:59:19 --> Loader Class Initialized
INFO - 2024-12-01 15:59:19 --> Helper loaded: url_helper
INFO - 2024-12-01 15:59:19 --> Helper loaded: form_helper
INFO - 2024-12-01 15:59:19 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:59:19 --> Form Validation Class Initialized
INFO - 2024-12-01 15:59:19 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:59:19 --> Controller Class Initialized
INFO - 2024-12-01 15:59:19 --> Model "User_model" initialized
INFO - 2024-12-01 15:59:19 --> Model "Category_model" initialized
INFO - 2024-12-01 15:59:19 --> Model "Review_model" initialized
INFO - 2024-12-01 15:59:19 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:59:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:59:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:59:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-01 15:59:19 --> Final output sent to browser
DEBUG - 2024-12-01 15:59:19 --> Total execution time: 0.1386
INFO - 2024-12-01 15:59:20 --> Config Class Initialized
INFO - 2024-12-01 15:59:20 --> Hooks Class Initialized
DEBUG - 2024-12-01 15:59:20 --> UTF-8 Support Enabled
INFO - 2024-12-01 15:59:20 --> Utf8 Class Initialized
INFO - 2024-12-01 15:59:20 --> URI Class Initialized
INFO - 2024-12-01 15:59:21 --> Router Class Initialized
INFO - 2024-12-01 15:59:21 --> Output Class Initialized
INFO - 2024-12-01 15:59:21 --> Security Class Initialized
DEBUG - 2024-12-01 15:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 15:59:21 --> CSRF cookie sent
INFO - 2024-12-01 15:59:21 --> Input Class Initialized
INFO - 2024-12-01 15:59:21 --> Language Class Initialized
INFO - 2024-12-01 15:59:21 --> Loader Class Initialized
INFO - 2024-12-01 15:59:21 --> Helper loaded: url_helper
INFO - 2024-12-01 15:59:21 --> Helper loaded: form_helper
INFO - 2024-12-01 15:59:21 --> Database Driver Class Initialized
DEBUG - 2024-12-01 15:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 15:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 15:59:21 --> Form Validation Class Initialized
INFO - 2024-12-01 15:59:21 --> Model "Culinary_model" initialized
INFO - 2024-12-01 15:59:21 --> Controller Class Initialized
INFO - 2024-12-01 15:59:21 --> Model "User_model" initialized
INFO - 2024-12-01 15:59:21 --> Model "Category_model" initialized
INFO - 2024-12-01 15:59:21 --> Model "Review_model" initialized
INFO - 2024-12-01 15:59:21 --> Model "News_model" initialized
DEBUG - 2024-12-01 15:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 15:59:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 15:59:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 15:59:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 15:59:21 --> Final output sent to browser
DEBUG - 2024-12-01 15:59:21 --> Total execution time: 0.0666
INFO - 2024-12-01 16:06:27 --> Config Class Initialized
INFO - 2024-12-01 16:06:27 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:06:27 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:06:27 --> Utf8 Class Initialized
INFO - 2024-12-01 16:06:27 --> URI Class Initialized
INFO - 2024-12-01 16:06:27 --> Router Class Initialized
INFO - 2024-12-01 16:06:27 --> Output Class Initialized
INFO - 2024-12-01 16:06:27 --> Security Class Initialized
DEBUG - 2024-12-01 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:06:27 --> CSRF cookie sent
INFO - 2024-12-01 16:06:27 --> Input Class Initialized
INFO - 2024-12-01 16:06:27 --> Language Class Initialized
INFO - 2024-12-01 16:06:27 --> Loader Class Initialized
INFO - 2024-12-01 16:06:27 --> Helper loaded: url_helper
INFO - 2024-12-01 16:06:27 --> Helper loaded: form_helper
INFO - 2024-12-01 16:06:27 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:06:27 --> Form Validation Class Initialized
INFO - 2024-12-01 16:06:27 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:06:27 --> Controller Class Initialized
INFO - 2024-12-01 16:06:27 --> Model "User_model" initialized
INFO - 2024-12-01 16:06:27 --> Model "Category_model" initialized
INFO - 2024-12-01 16:06:27 --> Model "Review_model" initialized
INFO - 2024-12-01 16:06:27 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:06:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:06:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:06:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:06:27 --> Final output sent to browser
DEBUG - 2024-12-01 16:06:27 --> Total execution time: 0.4728
INFO - 2024-12-01 16:07:27 --> Config Class Initialized
INFO - 2024-12-01 16:07:27 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:07:27 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:07:27 --> Utf8 Class Initialized
INFO - 2024-12-01 16:07:27 --> URI Class Initialized
INFO - 2024-12-01 16:07:27 --> Router Class Initialized
INFO - 2024-12-01 16:07:27 --> Output Class Initialized
INFO - 2024-12-01 16:07:27 --> Security Class Initialized
DEBUG - 2024-12-01 16:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:07:27 --> CSRF cookie sent
INFO - 2024-12-01 16:07:27 --> Input Class Initialized
INFO - 2024-12-01 16:07:27 --> Language Class Initialized
INFO - 2024-12-01 16:07:27 --> Loader Class Initialized
INFO - 2024-12-01 16:07:27 --> Helper loaded: url_helper
INFO - 2024-12-01 16:07:27 --> Helper loaded: form_helper
INFO - 2024-12-01 16:07:28 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:07:28 --> Form Validation Class Initialized
INFO - 2024-12-01 16:07:28 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:07:28 --> Controller Class Initialized
INFO - 2024-12-01 16:07:28 --> Model "User_model" initialized
INFO - 2024-12-01 16:07:28 --> Model "Category_model" initialized
INFO - 2024-12-01 16:07:28 --> Model "Review_model" initialized
INFO - 2024-12-01 16:07:28 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:07:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:07:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:07:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:07:28 --> Final output sent to browser
DEBUG - 2024-12-01 16:07:28 --> Total execution time: 0.1362
INFO - 2024-12-01 16:07:47 --> Config Class Initialized
INFO - 2024-12-01 16:07:47 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:07:47 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:07:47 --> Utf8 Class Initialized
INFO - 2024-12-01 16:07:47 --> URI Class Initialized
INFO - 2024-12-01 16:07:47 --> Router Class Initialized
INFO - 2024-12-01 16:07:47 --> Output Class Initialized
INFO - 2024-12-01 16:07:47 --> Security Class Initialized
DEBUG - 2024-12-01 16:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:07:47 --> CSRF cookie sent
INFO - 2024-12-01 16:07:47 --> Input Class Initialized
INFO - 2024-12-01 16:07:47 --> Language Class Initialized
INFO - 2024-12-01 16:07:47 --> Loader Class Initialized
INFO - 2024-12-01 16:07:47 --> Helper loaded: url_helper
INFO - 2024-12-01 16:07:47 --> Helper loaded: form_helper
INFO - 2024-12-01 16:07:47 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:07:47 --> Form Validation Class Initialized
INFO - 2024-12-01 16:07:47 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:07:47 --> Controller Class Initialized
INFO - 2024-12-01 16:07:47 --> Model "Category_model" initialized
INFO - 2024-12-01 16:07:47 --> Model "User_model" initialized
INFO - 2024-12-01 16:07:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 16:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:07:47 --> Config Class Initialized
INFO - 2024-12-01 16:07:47 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:07:47 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:07:47 --> Utf8 Class Initialized
INFO - 2024-12-01 16:07:47 --> URI Class Initialized
INFO - 2024-12-01 16:07:47 --> Router Class Initialized
INFO - 2024-12-01 16:07:47 --> Output Class Initialized
INFO - 2024-12-01 16:07:47 --> Security Class Initialized
DEBUG - 2024-12-01 16:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:07:47 --> CSRF cookie sent
INFO - 2024-12-01 16:07:47 --> Input Class Initialized
INFO - 2024-12-01 16:07:47 --> Language Class Initialized
INFO - 2024-12-01 16:07:47 --> Loader Class Initialized
INFO - 2024-12-01 16:07:47 --> Helper loaded: url_helper
INFO - 2024-12-01 16:07:47 --> Helper loaded: form_helper
INFO - 2024-12-01 16:07:47 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:07:47 --> Form Validation Class Initialized
INFO - 2024-12-01 16:07:47 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:07:47 --> Controller Class Initialized
INFO - 2024-12-01 16:07:47 --> Model "Category_model" initialized
INFO - 2024-12-01 16:07:47 --> Model "User_model" initialized
INFO - 2024-12-01 16:07:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 16:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:07:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:07:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:07:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-01 16:07:47 --> Final output sent to browser
DEBUG - 2024-12-01 16:07:47 --> Total execution time: 0.0651
INFO - 2024-12-01 16:12:18 --> Config Class Initialized
INFO - 2024-12-01 16:12:18 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:12:18 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:12:18 --> Utf8 Class Initialized
INFO - 2024-12-01 16:12:18 --> URI Class Initialized
INFO - 2024-12-01 16:12:18 --> Router Class Initialized
INFO - 2024-12-01 16:12:18 --> Output Class Initialized
INFO - 2024-12-01 16:12:18 --> Security Class Initialized
DEBUG - 2024-12-01 16:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:12:18 --> CSRF cookie sent
INFO - 2024-12-01 16:12:18 --> Input Class Initialized
INFO - 2024-12-01 16:12:18 --> Language Class Initialized
INFO - 2024-12-01 16:12:18 --> Loader Class Initialized
INFO - 2024-12-01 16:12:18 --> Helper loaded: url_helper
INFO - 2024-12-01 16:12:18 --> Helper loaded: form_helper
INFO - 2024-12-01 16:12:18 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:12:18 --> Form Validation Class Initialized
INFO - 2024-12-01 16:12:18 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:12:18 --> Controller Class Initialized
INFO - 2024-12-01 16:12:18 --> Model "User_model" initialized
INFO - 2024-12-01 16:12:18 --> Model "Category_model" initialized
INFO - 2024-12-01 16:12:18 --> Model "Review_model" initialized
INFO - 2024-12-01 16:12:18 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:12:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:12:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:12:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:12:18 --> Final output sent to browser
DEBUG - 2024-12-01 16:12:18 --> Total execution time: 0.2596
INFO - 2024-12-01 16:12:24 --> Config Class Initialized
INFO - 2024-12-01 16:12:24 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:12:24 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:12:24 --> Utf8 Class Initialized
INFO - 2024-12-01 16:12:24 --> URI Class Initialized
INFO - 2024-12-01 16:12:24 --> Router Class Initialized
INFO - 2024-12-01 16:12:24 --> Output Class Initialized
INFO - 2024-12-01 16:12:24 --> Security Class Initialized
DEBUG - 2024-12-01 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:12:24 --> CSRF cookie sent
INFO - 2024-12-01 16:12:24 --> Input Class Initialized
INFO - 2024-12-01 16:12:24 --> Language Class Initialized
INFO - 2024-12-01 16:12:24 --> Loader Class Initialized
INFO - 2024-12-01 16:12:24 --> Helper loaded: url_helper
INFO - 2024-12-01 16:12:24 --> Helper loaded: form_helper
INFO - 2024-12-01 16:12:24 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:12:24 --> Form Validation Class Initialized
INFO - 2024-12-01 16:12:24 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:12:24 --> Controller Class Initialized
INFO - 2024-12-01 16:12:24 --> Model "User_model" initialized
INFO - 2024-12-01 16:12:24 --> Model "Category_model" initialized
INFO - 2024-12-01 16:12:24 --> Model "Review_model" initialized
INFO - 2024-12-01 16:12:24 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:12:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:12:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:12:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:12:24 --> Final output sent to browser
DEBUG - 2024-12-01 16:12:24 --> Total execution time: 0.0509
INFO - 2024-12-01 16:18:28 --> Config Class Initialized
INFO - 2024-12-01 16:18:28 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:18:28 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:18:28 --> Utf8 Class Initialized
INFO - 2024-12-01 16:18:28 --> URI Class Initialized
INFO - 2024-12-01 16:18:28 --> Router Class Initialized
INFO - 2024-12-01 16:18:28 --> Output Class Initialized
INFO - 2024-12-01 16:18:28 --> Security Class Initialized
DEBUG - 2024-12-01 16:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:18:28 --> CSRF cookie sent
INFO - 2024-12-01 16:18:28 --> Input Class Initialized
INFO - 2024-12-01 16:18:28 --> Language Class Initialized
INFO - 2024-12-01 16:18:28 --> Loader Class Initialized
INFO - 2024-12-01 16:18:28 --> Helper loaded: url_helper
INFO - 2024-12-01 16:18:28 --> Helper loaded: form_helper
INFO - 2024-12-01 16:18:28 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:18:28 --> Form Validation Class Initialized
INFO - 2024-12-01 16:18:28 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:18:28 --> Controller Class Initialized
INFO - 2024-12-01 16:18:28 --> Model "User_model" initialized
INFO - 2024-12-01 16:18:28 --> Model "Category_model" initialized
INFO - 2024-12-01 16:18:28 --> Model "Review_model" initialized
INFO - 2024-12-01 16:18:28 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:18:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
ERROR - 2024-12-01 16:18:28 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 379
ERROR - 2024-12-01 16:18:28 --> Severity: Warning --> Undefined property: stdClass::$link_url C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 383
ERROR - 2024-12-01 16:18:28 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 383
INFO - 2024-12-01 16:18:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:18:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:18:28 --> Final output sent to browser
DEBUG - 2024-12-01 16:18:28 --> Total execution time: 0.2462
INFO - 2024-12-01 16:18:29 --> Config Class Initialized
INFO - 2024-12-01 16:18:29 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:18:29 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:18:29 --> Utf8 Class Initialized
INFO - 2024-12-01 16:23:15 --> Config Class Initialized
INFO - 2024-12-01 16:23:15 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:23:15 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:23:15 --> Utf8 Class Initialized
INFO - 2024-12-01 16:23:15 --> URI Class Initialized
INFO - 2024-12-01 16:23:15 --> Router Class Initialized
INFO - 2024-12-01 16:23:15 --> Output Class Initialized
INFO - 2024-12-01 16:23:15 --> Security Class Initialized
DEBUG - 2024-12-01 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:23:15 --> CSRF cookie sent
INFO - 2024-12-01 16:23:15 --> Input Class Initialized
INFO - 2024-12-01 16:23:15 --> Language Class Initialized
INFO - 2024-12-01 16:23:15 --> Loader Class Initialized
INFO - 2024-12-01 16:23:15 --> Helper loaded: url_helper
INFO - 2024-12-01 16:23:15 --> Helper loaded: form_helper
INFO - 2024-12-01 16:23:15 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:23:15 --> Form Validation Class Initialized
INFO - 2024-12-01 16:23:15 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:23:15 --> Controller Class Initialized
INFO - 2024-12-01 16:23:15 --> Model "User_model" initialized
INFO - 2024-12-01 16:23:15 --> Model "Category_model" initialized
INFO - 2024-12-01 16:23:15 --> Model "Review_model" initialized
INFO - 2024-12-01 16:23:15 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:23:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:23:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:23:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:23:15 --> Final output sent to browser
DEBUG - 2024-12-01 16:23:15 --> Total execution time: 0.2767
INFO - 2024-12-01 16:26:11 --> Config Class Initialized
INFO - 2024-12-01 16:26:11 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:26:11 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:26:11 --> Utf8 Class Initialized
INFO - 2024-12-01 16:26:11 --> URI Class Initialized
INFO - 2024-12-01 16:26:11 --> Router Class Initialized
INFO - 2024-12-01 16:26:11 --> Output Class Initialized
INFO - 2024-12-01 16:26:11 --> Security Class Initialized
DEBUG - 2024-12-01 16:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:26:11 --> CSRF cookie sent
INFO - 2024-12-01 16:26:11 --> Input Class Initialized
INFO - 2024-12-01 16:26:11 --> Language Class Initialized
INFO - 2024-12-01 16:26:11 --> Loader Class Initialized
INFO - 2024-12-01 16:26:11 --> Helper loaded: url_helper
INFO - 2024-12-01 16:26:11 --> Helper loaded: form_helper
INFO - 2024-12-01 16:26:11 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:26:11 --> Form Validation Class Initialized
INFO - 2024-12-01 16:26:11 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:26:11 --> Controller Class Initialized
INFO - 2024-12-01 16:26:11 --> Model "User_model" initialized
INFO - 2024-12-01 16:26:11 --> Model "Category_model" initialized
INFO - 2024-12-01 16:26:11 --> Model "Review_model" initialized
INFO - 2024-12-01 16:26:11 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:26:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:26:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:26:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:26:11 --> Final output sent to browser
DEBUG - 2024-12-01 16:26:11 --> Total execution time: 0.2958
INFO - 2024-12-01 16:27:04 --> Config Class Initialized
INFO - 2024-12-01 16:27:04 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:27:04 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:27:04 --> Utf8 Class Initialized
INFO - 2024-12-01 16:27:04 --> URI Class Initialized
INFO - 2024-12-01 16:27:04 --> Router Class Initialized
INFO - 2024-12-01 16:27:04 --> Output Class Initialized
INFO - 2024-12-01 16:27:04 --> Security Class Initialized
DEBUG - 2024-12-01 16:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:27:04 --> CSRF cookie sent
INFO - 2024-12-01 16:27:04 --> Input Class Initialized
INFO - 2024-12-01 16:27:04 --> Language Class Initialized
INFO - 2024-12-01 16:27:04 --> Loader Class Initialized
INFO - 2024-12-01 16:27:04 --> Helper loaded: url_helper
INFO - 2024-12-01 16:27:04 --> Helper loaded: form_helper
INFO - 2024-12-01 16:27:04 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:27:04 --> Form Validation Class Initialized
INFO - 2024-12-01 16:27:04 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:27:04 --> Controller Class Initialized
INFO - 2024-12-01 16:27:04 --> Model "User_model" initialized
INFO - 2024-12-01 16:27:04 --> Model "Category_model" initialized
INFO - 2024-12-01 16:27:04 --> Model "Review_model" initialized
INFO - 2024-12-01 16:27:04 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:27:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:27:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:27:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:27:04 --> Final output sent to browser
DEBUG - 2024-12-01 16:27:04 --> Total execution time: 0.5146
INFO - 2024-12-01 16:27:06 --> Config Class Initialized
INFO - 2024-12-01 16:27:06 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:27:06 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:27:06 --> Utf8 Class Initialized
INFO - 2024-12-01 16:27:06 --> URI Class Initialized
INFO - 2024-12-01 16:27:06 --> Router Class Initialized
INFO - 2024-12-01 16:27:06 --> Output Class Initialized
INFO - 2024-12-01 16:27:06 --> Security Class Initialized
DEBUG - 2024-12-01 16:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:27:06 --> CSRF cookie sent
INFO - 2024-12-01 16:27:06 --> Input Class Initialized
INFO - 2024-12-01 16:27:06 --> Language Class Initialized
INFO - 2024-12-01 16:27:06 --> Loader Class Initialized
INFO - 2024-12-01 16:27:06 --> Helper loaded: url_helper
INFO - 2024-12-01 16:27:06 --> Helper loaded: form_helper
INFO - 2024-12-01 16:27:06 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:27:06 --> Form Validation Class Initialized
INFO - 2024-12-01 16:27:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:27:06 --> Controller Class Initialized
INFO - 2024-12-01 16:27:06 --> Model "User_model" initialized
INFO - 2024-12-01 16:27:06 --> Model "Category_model" initialized
INFO - 2024-12-01 16:27:06 --> Model "Review_model" initialized
INFO - 2024-12-01 16:27:06 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:27:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:27:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:27:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:27:06 --> Final output sent to browser
DEBUG - 2024-12-01 16:27:06 --> Total execution time: 0.1432
INFO - 2024-12-01 16:32:42 --> Config Class Initialized
INFO - 2024-12-01 16:32:42 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:32:42 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:32:42 --> Utf8 Class Initialized
INFO - 2024-12-01 16:32:42 --> URI Class Initialized
INFO - 2024-12-01 16:32:42 --> Router Class Initialized
INFO - 2024-12-01 16:32:42 --> Output Class Initialized
INFO - 2024-12-01 16:32:42 --> Security Class Initialized
DEBUG - 2024-12-01 16:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:32:42 --> CSRF cookie sent
INFO - 2024-12-01 16:32:42 --> Input Class Initialized
INFO - 2024-12-01 16:32:42 --> Language Class Initialized
INFO - 2024-12-01 16:32:42 --> Loader Class Initialized
INFO - 2024-12-01 16:32:42 --> Helper loaded: url_helper
INFO - 2024-12-01 16:32:42 --> Helper loaded: form_helper
INFO - 2024-12-01 16:32:42 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:32:42 --> Form Validation Class Initialized
INFO - 2024-12-01 16:32:42 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:32:42 --> Controller Class Initialized
INFO - 2024-12-01 16:32:42 --> Model "User_model" initialized
INFO - 2024-12-01 16:32:42 --> Model "Category_model" initialized
INFO - 2024-12-01 16:32:42 --> Model "Review_model" initialized
INFO - 2024-12-01 16:32:42 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:32:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:32:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:32:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:32:42 --> Final output sent to browser
DEBUG - 2024-12-01 16:32:42 --> Total execution time: 0.6078
INFO - 2024-12-01 16:32:48 --> Config Class Initialized
INFO - 2024-12-01 16:32:48 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:32:48 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:32:48 --> Utf8 Class Initialized
INFO - 2024-12-01 16:32:48 --> URI Class Initialized
INFO - 2024-12-01 16:32:48 --> Router Class Initialized
INFO - 2024-12-01 16:32:48 --> Output Class Initialized
INFO - 2024-12-01 16:32:48 --> Security Class Initialized
DEBUG - 2024-12-01 16:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:32:48 --> CSRF cookie sent
INFO - 2024-12-01 16:32:48 --> Input Class Initialized
INFO - 2024-12-01 16:32:48 --> Language Class Initialized
INFO - 2024-12-01 16:32:48 --> Loader Class Initialized
INFO - 2024-12-01 16:32:48 --> Helper loaded: url_helper
INFO - 2024-12-01 16:32:48 --> Helper loaded: form_helper
INFO - 2024-12-01 16:32:48 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:32:48 --> Form Validation Class Initialized
INFO - 2024-12-01 16:32:48 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:32:48 --> Controller Class Initialized
INFO - 2024-12-01 16:32:48 --> Model "User_model" initialized
INFO - 2024-12-01 16:32:48 --> Model "Category_model" initialized
INFO - 2024-12-01 16:32:48 --> Model "Review_model" initialized
INFO - 2024-12-01 16:32:48 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:32:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:32:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:32:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:32:48 --> Final output sent to browser
DEBUG - 2024-12-01 16:32:48 --> Total execution time: 0.1243
INFO - 2024-12-01 16:35:04 --> Config Class Initialized
INFO - 2024-12-01 16:35:04 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:04 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:04 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:04 --> URI Class Initialized
INFO - 2024-12-01 16:35:04 --> Router Class Initialized
INFO - 2024-12-01 16:35:04 --> Output Class Initialized
INFO - 2024-12-01 16:35:04 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:04 --> CSRF cookie sent
INFO - 2024-12-01 16:35:04 --> Input Class Initialized
INFO - 2024-12-01 16:35:04 --> Language Class Initialized
INFO - 2024-12-01 16:35:04 --> Loader Class Initialized
INFO - 2024-12-01 16:35:04 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:04 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:04 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:04 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:04 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:04 --> Controller Class Initialized
INFO - 2024-12-01 16:35:04 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:04 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:04 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:04 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:35:04 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:04 --> Total execution time: 0.5892
INFO - 2024-12-01 16:35:17 --> Config Class Initialized
INFO - 2024-12-01 16:35:17 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:17 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:17 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:17 --> URI Class Initialized
INFO - 2024-12-01 16:35:17 --> Router Class Initialized
INFO - 2024-12-01 16:35:17 --> Output Class Initialized
INFO - 2024-12-01 16:35:17 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:17 --> CSRF cookie sent
INFO - 2024-12-01 16:35:17 --> Input Class Initialized
INFO - 2024-12-01 16:35:17 --> Language Class Initialized
INFO - 2024-12-01 16:35:17 --> Loader Class Initialized
INFO - 2024-12-01 16:35:17 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:17 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:17 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:17 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:17 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:17 --> Controller Class Initialized
INFO - 2024-12-01 16:35:17 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:17 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:17 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:17 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-01 16:35:17 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:17 --> Total execution time: 0.1405
INFO - 2024-12-01 16:35:29 --> Config Class Initialized
INFO - 2024-12-01 16:35:29 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:29 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:29 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:29 --> URI Class Initialized
INFO - 2024-12-01 16:35:29 --> Router Class Initialized
INFO - 2024-12-01 16:35:29 --> Output Class Initialized
INFO - 2024-12-01 16:35:29 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:29 --> CSRF cookie sent
INFO - 2024-12-01 16:35:29 --> CSRF token verified
INFO - 2024-12-01 16:35:29 --> Input Class Initialized
INFO - 2024-12-01 16:35:29 --> Language Class Initialized
INFO - 2024-12-01 16:35:29 --> Loader Class Initialized
INFO - 2024-12-01 16:35:29 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:29 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:29 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:29 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:29 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:29 --> Controller Class Initialized
INFO - 2024-12-01 16:35:29 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:29 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:29 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:29 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:29 --> Config Class Initialized
INFO - 2024-12-01 16:35:29 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:29 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:29 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:29 --> URI Class Initialized
INFO - 2024-12-01 16:35:29 --> Router Class Initialized
INFO - 2024-12-01 16:35:29 --> Output Class Initialized
INFO - 2024-12-01 16:35:29 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:29 --> CSRF cookie sent
INFO - 2024-12-01 16:35:29 --> Input Class Initialized
INFO - 2024-12-01 16:35:29 --> Language Class Initialized
INFO - 2024-12-01 16:35:29 --> Loader Class Initialized
INFO - 2024-12-01 16:35:29 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:29 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:29 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:29 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:29 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:29 --> Controller Class Initialized
INFO - 2024-12-01 16:35:29 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:29 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:29 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:29 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:35:29 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:29 --> Total execution time: 0.0437
INFO - 2024-12-01 16:35:35 --> Config Class Initialized
INFO - 2024-12-01 16:35:35 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:35 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:35 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:35 --> URI Class Initialized
INFO - 2024-12-01 16:35:35 --> Router Class Initialized
INFO - 2024-12-01 16:35:35 --> Output Class Initialized
INFO - 2024-12-01 16:35:35 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:35 --> CSRF cookie sent
INFO - 2024-12-01 16:35:35 --> Input Class Initialized
INFO - 2024-12-01 16:35:35 --> Language Class Initialized
INFO - 2024-12-01 16:35:35 --> Loader Class Initialized
INFO - 2024-12-01 16:35:35 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:35 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:35 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:35 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:35 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:35 --> Controller Class Initialized
INFO - 2024-12-01 16:35:35 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:35 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:35 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:35 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-01 16:35:35 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:35 --> Total execution time: 0.1199
INFO - 2024-12-01 16:35:40 --> Config Class Initialized
INFO - 2024-12-01 16:35:40 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:40 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:40 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:40 --> URI Class Initialized
INFO - 2024-12-01 16:35:40 --> Router Class Initialized
INFO - 2024-12-01 16:35:40 --> Output Class Initialized
INFO - 2024-12-01 16:35:40 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:40 --> CSRF cookie sent
INFO - 2024-12-01 16:35:40 --> Input Class Initialized
INFO - 2024-12-01 16:35:40 --> Language Class Initialized
INFO - 2024-12-01 16:35:40 --> Loader Class Initialized
INFO - 2024-12-01 16:35:40 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:40 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:40 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:40 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:40 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:40 --> Controller Class Initialized
INFO - 2024-12-01 16:35:40 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:40 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:40 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:40 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-01 16:35:40 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:40 --> Total execution time: 0.1571
INFO - 2024-12-01 16:35:48 --> Config Class Initialized
INFO - 2024-12-01 16:35:48 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:48 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:48 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:48 --> URI Class Initialized
INFO - 2024-12-01 16:35:48 --> Router Class Initialized
INFO - 2024-12-01 16:35:48 --> Output Class Initialized
INFO - 2024-12-01 16:35:48 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:48 --> CSRF cookie sent
INFO - 2024-12-01 16:35:51 --> Config Class Initialized
INFO - 2024-12-01 16:35:51 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:51 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:51 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:51 --> URI Class Initialized
INFO - 2024-12-01 16:35:51 --> Router Class Initialized
INFO - 2024-12-01 16:35:51 --> Output Class Initialized
INFO - 2024-12-01 16:35:51 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:51 --> CSRF cookie sent
INFO - 2024-12-01 16:35:51 --> Input Class Initialized
INFO - 2024-12-01 16:35:51 --> Language Class Initialized
INFO - 2024-12-01 16:35:51 --> Loader Class Initialized
INFO - 2024-12-01 16:35:51 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:51 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:51 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:51 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:51 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:51 --> Controller Class Initialized
INFO - 2024-12-01 16:35:51 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:51 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:51 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:51 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-01 16:35:51 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:51 --> Total execution time: 0.4144
INFO - 2024-12-01 16:35:52 --> Config Class Initialized
INFO - 2024-12-01 16:35:52 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:35:52 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:35:52 --> Utf8 Class Initialized
INFO - 2024-12-01 16:35:52 --> URI Class Initialized
INFO - 2024-12-01 16:35:52 --> Router Class Initialized
INFO - 2024-12-01 16:35:52 --> Output Class Initialized
INFO - 2024-12-01 16:35:52 --> Security Class Initialized
DEBUG - 2024-12-01 16:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:35:52 --> CSRF cookie sent
INFO - 2024-12-01 16:35:52 --> Input Class Initialized
INFO - 2024-12-01 16:35:52 --> Language Class Initialized
INFO - 2024-12-01 16:35:52 --> Loader Class Initialized
INFO - 2024-12-01 16:35:53 --> Helper loaded: url_helper
INFO - 2024-12-01 16:35:53 --> Helper loaded: form_helper
INFO - 2024-12-01 16:35:53 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:35:53 --> Form Validation Class Initialized
INFO - 2024-12-01 16:35:53 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:35:53 --> Controller Class Initialized
INFO - 2024-12-01 16:35:53 --> Model "User_model" initialized
INFO - 2024-12-01 16:35:53 --> Model "Category_model" initialized
INFO - 2024-12-01 16:35:53 --> Model "Review_model" initialized
INFO - 2024-12-01 16:35:53 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:35:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:35:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:35:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-01 16:35:53 --> Final output sent to browser
DEBUG - 2024-12-01 16:35:53 --> Total execution time: 0.2017
INFO - 2024-12-01 16:37:46 --> Config Class Initialized
INFO - 2024-12-01 16:37:46 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:37:46 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:37:46 --> Utf8 Class Initialized
INFO - 2024-12-01 16:37:46 --> URI Class Initialized
INFO - 2024-12-01 16:37:46 --> Router Class Initialized
INFO - 2024-12-01 16:37:46 --> Output Class Initialized
INFO - 2024-12-01 16:37:46 --> Security Class Initialized
DEBUG - 2024-12-01 16:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:37:46 --> CSRF cookie sent
INFO - 2024-12-01 16:37:46 --> Input Class Initialized
INFO - 2024-12-01 16:37:46 --> Language Class Initialized
INFO - 2024-12-01 16:37:46 --> Loader Class Initialized
INFO - 2024-12-01 16:37:46 --> Helper loaded: url_helper
INFO - 2024-12-01 16:37:46 --> Helper loaded: form_helper
INFO - 2024-12-01 16:37:46 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:37:46 --> Form Validation Class Initialized
INFO - 2024-12-01 16:37:46 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:37:46 --> Controller Class Initialized
INFO - 2024-12-01 16:37:46 --> Model "User_model" initialized
INFO - 2024-12-01 16:37:46 --> Model "Category_model" initialized
INFO - 2024-12-01 16:37:46 --> Model "Review_model" initialized
INFO - 2024-12-01 16:37:46 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:37:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:37:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:37:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:37:46 --> Final output sent to browser
DEBUG - 2024-12-01 16:37:46 --> Total execution time: 0.5761
INFO - 2024-12-01 16:57:36 --> Config Class Initialized
INFO - 2024-12-01 16:57:37 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:57:37 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:57:37 --> Utf8 Class Initialized
INFO - 2024-12-01 16:57:37 --> URI Class Initialized
INFO - 2024-12-01 16:57:37 --> Router Class Initialized
INFO - 2024-12-01 16:57:37 --> Output Class Initialized
INFO - 2024-12-01 16:57:37 --> Security Class Initialized
DEBUG - 2024-12-01 16:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:57:37 --> CSRF cookie sent
INFO - 2024-12-01 16:57:37 --> Input Class Initialized
INFO - 2024-12-01 16:57:37 --> Language Class Initialized
INFO - 2024-12-01 16:57:37 --> Loader Class Initialized
INFO - 2024-12-01 16:57:37 --> Helper loaded: url_helper
INFO - 2024-12-01 16:57:37 --> Helper loaded: form_helper
INFO - 2024-12-01 16:57:37 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:57:37 --> Form Validation Class Initialized
INFO - 2024-12-01 16:57:37 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:57:37 --> Controller Class Initialized
INFO - 2024-12-01 16:57:37 --> Model "User_model" initialized
INFO - 2024-12-01 16:57:37 --> Model "Category_model" initialized
INFO - 2024-12-01 16:57:37 --> Model "Review_model" initialized
INFO - 2024-12-01 16:57:37 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:57:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:57:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:57:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:57:37 --> Final output sent to browser
DEBUG - 2024-12-01 16:57:37 --> Total execution time: 0.4704
INFO - 2024-12-01 16:58:44 --> Config Class Initialized
INFO - 2024-12-01 16:58:44 --> Hooks Class Initialized
DEBUG - 2024-12-01 16:58:44 --> UTF-8 Support Enabled
INFO - 2024-12-01 16:58:44 --> Utf8 Class Initialized
INFO - 2024-12-01 16:58:44 --> URI Class Initialized
INFO - 2024-12-01 16:58:44 --> Router Class Initialized
INFO - 2024-12-01 16:58:44 --> Output Class Initialized
INFO - 2024-12-01 16:58:44 --> Security Class Initialized
DEBUG - 2024-12-01 16:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 16:58:44 --> CSRF cookie sent
INFO - 2024-12-01 16:58:44 --> Input Class Initialized
INFO - 2024-12-01 16:58:44 --> Language Class Initialized
INFO - 2024-12-01 16:58:44 --> Loader Class Initialized
INFO - 2024-12-01 16:58:44 --> Helper loaded: url_helper
INFO - 2024-12-01 16:58:44 --> Helper loaded: form_helper
INFO - 2024-12-01 16:58:44 --> Database Driver Class Initialized
DEBUG - 2024-12-01 16:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 16:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 16:58:45 --> Form Validation Class Initialized
INFO - 2024-12-01 16:58:45 --> Model "Culinary_model" initialized
INFO - 2024-12-01 16:58:45 --> Controller Class Initialized
INFO - 2024-12-01 16:58:45 --> Model "User_model" initialized
INFO - 2024-12-01 16:58:45 --> Model "Category_model" initialized
INFO - 2024-12-01 16:58:45 --> Model "Review_model" initialized
INFO - 2024-12-01 16:58:45 --> Model "News_model" initialized
DEBUG - 2024-12-01 16:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 16:58:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 16:58:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 16:58:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 16:58:45 --> Final output sent to browser
DEBUG - 2024-12-01 16:58:45 --> Total execution time: 0.3110
INFO - 2024-12-01 17:01:12 --> Config Class Initialized
INFO - 2024-12-01 17:01:12 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:01:12 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:01:12 --> Utf8 Class Initialized
INFO - 2024-12-01 17:01:12 --> URI Class Initialized
INFO - 2024-12-01 17:01:12 --> Router Class Initialized
INFO - 2024-12-01 17:01:12 --> Output Class Initialized
INFO - 2024-12-01 17:01:13 --> Security Class Initialized
DEBUG - 2024-12-01 17:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:01:13 --> CSRF cookie sent
INFO - 2024-12-01 17:01:13 --> Input Class Initialized
INFO - 2024-12-01 17:01:13 --> Language Class Initialized
INFO - 2024-12-01 17:01:13 --> Loader Class Initialized
INFO - 2024-12-01 17:01:13 --> Helper loaded: url_helper
INFO - 2024-12-01 17:01:13 --> Helper loaded: form_helper
INFO - 2024-12-01 17:01:13 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:01:13 --> Form Validation Class Initialized
INFO - 2024-12-01 17:01:13 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:01:13 --> Controller Class Initialized
INFO - 2024-12-01 17:01:13 --> Model "Category_model" initialized
INFO - 2024-12-01 17:01:13 --> Model "User_model" initialized
INFO - 2024-12-01 17:01:13 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 17:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:01:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:01:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:01:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-01 17:01:13 --> Final output sent to browser
DEBUG - 2024-12-01 17:01:13 --> Total execution time: 1.0980
INFO - 2024-12-01 17:03:39 --> Config Class Initialized
INFO - 2024-12-01 17:03:39 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:03:39 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:03:39 --> Utf8 Class Initialized
INFO - 2024-12-01 17:03:39 --> URI Class Initialized
INFO - 2024-12-01 17:03:39 --> Router Class Initialized
INFO - 2024-12-01 17:03:39 --> Output Class Initialized
INFO - 2024-12-01 17:03:39 --> Security Class Initialized
DEBUG - 2024-12-01 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:03:39 --> CSRF cookie sent
INFO - 2024-12-01 17:03:39 --> Input Class Initialized
INFO - 2024-12-01 17:03:39 --> Language Class Initialized
INFO - 2024-12-01 17:03:39 --> Loader Class Initialized
INFO - 2024-12-01 17:03:39 --> Helper loaded: url_helper
INFO - 2024-12-01 17:03:39 --> Helper loaded: form_helper
INFO - 2024-12-01 17:03:39 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:03:39 --> Form Validation Class Initialized
INFO - 2024-12-01 17:03:39 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:03:39 --> Controller Class Initialized
INFO - 2024-12-01 17:03:39 --> Model "User_model" initialized
INFO - 2024-12-01 17:03:39 --> Model "Category_model" initialized
INFO - 2024-12-01 17:03:39 --> Model "Review_model" initialized
INFO - 2024-12-01 17:03:39 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:03:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:03:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:03:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:03:39 --> Final output sent to browser
DEBUG - 2024-12-01 17:03:39 --> Total execution time: 0.2614
INFO - 2024-12-01 17:13:49 --> Config Class Initialized
INFO - 2024-12-01 17:13:49 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:13:49 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:13:49 --> Utf8 Class Initialized
INFO - 2024-12-01 17:13:49 --> URI Class Initialized
INFO - 2024-12-01 17:13:49 --> Router Class Initialized
INFO - 2024-12-01 17:13:49 --> Output Class Initialized
INFO - 2024-12-01 17:13:49 --> Security Class Initialized
DEBUG - 2024-12-01 17:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:13:49 --> CSRF cookie sent
INFO - 2024-12-01 17:13:49 --> Input Class Initialized
INFO - 2024-12-01 17:13:49 --> Language Class Initialized
INFO - 2024-12-01 17:13:49 --> Loader Class Initialized
INFO - 2024-12-01 17:13:49 --> Helper loaded: url_helper
INFO - 2024-12-01 17:13:49 --> Helper loaded: form_helper
INFO - 2024-12-01 17:13:49 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:13:49 --> Form Validation Class Initialized
INFO - 2024-12-01 17:13:49 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:13:49 --> Controller Class Initialized
INFO - 2024-12-01 17:13:49 --> Model "User_model" initialized
INFO - 2024-12-01 17:13:49 --> Model "Category_model" initialized
INFO - 2024-12-01 17:13:49 --> Model "Review_model" initialized
INFO - 2024-12-01 17:13:49 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:13:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:13:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:13:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:13:50 --> Final output sent to browser
DEBUG - 2024-12-01 17:13:50 --> Total execution time: 0.8189
INFO - 2024-12-01 17:14:45 --> Config Class Initialized
INFO - 2024-12-01 17:14:45 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:14:45 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:14:45 --> Utf8 Class Initialized
INFO - 2024-12-01 17:14:45 --> URI Class Initialized
INFO - 2024-12-01 17:14:45 --> Router Class Initialized
INFO - 2024-12-01 17:14:45 --> Output Class Initialized
INFO - 2024-12-01 17:14:45 --> Security Class Initialized
DEBUG - 2024-12-01 17:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:14:45 --> CSRF cookie sent
INFO - 2024-12-01 17:14:45 --> Input Class Initialized
INFO - 2024-12-01 17:14:45 --> Language Class Initialized
INFO - 2024-12-01 17:14:45 --> Loader Class Initialized
INFO - 2024-12-01 17:14:45 --> Helper loaded: url_helper
INFO - 2024-12-01 17:14:45 --> Helper loaded: form_helper
INFO - 2024-12-01 17:14:45 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:14:45 --> Form Validation Class Initialized
INFO - 2024-12-01 17:14:45 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:14:45 --> Controller Class Initialized
INFO - 2024-12-01 17:14:45 --> Model "User_model" initialized
INFO - 2024-12-01 17:14:45 --> Model "Category_model" initialized
INFO - 2024-12-01 17:14:45 --> Model "Review_model" initialized
INFO - 2024-12-01 17:14:45 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:14:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:14:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:14:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:14:45 --> Final output sent to browser
DEBUG - 2024-12-01 17:14:45 --> Total execution time: 0.1613
INFO - 2024-12-01 17:23:06 --> Config Class Initialized
INFO - 2024-12-01 17:23:06 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:23:06 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:23:06 --> Utf8 Class Initialized
INFO - 2024-12-01 17:23:06 --> URI Class Initialized
INFO - 2024-12-01 17:23:06 --> Router Class Initialized
INFO - 2024-12-01 17:23:06 --> Output Class Initialized
INFO - 2024-12-01 17:23:06 --> Security Class Initialized
DEBUG - 2024-12-01 17:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:23:06 --> CSRF cookie sent
INFO - 2024-12-01 17:23:06 --> Input Class Initialized
INFO - 2024-12-01 17:23:06 --> Language Class Initialized
INFO - 2024-12-01 17:23:06 --> Loader Class Initialized
INFO - 2024-12-01 17:23:06 --> Helper loaded: url_helper
INFO - 2024-12-01 17:23:06 --> Helper loaded: form_helper
INFO - 2024-12-01 17:23:06 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:23:06 --> Form Validation Class Initialized
INFO - 2024-12-01 17:23:06 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:23:06 --> Controller Class Initialized
INFO - 2024-12-01 17:23:06 --> Model "User_model" initialized
INFO - 2024-12-01 17:23:06 --> Model "Category_model" initialized
INFO - 2024-12-01 17:23:06 --> Model "Review_model" initialized
INFO - 2024-12-01 17:23:06 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:23:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:23:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:23:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:23:07 --> Final output sent to browser
DEBUG - 2024-12-01 17:23:07 --> Total execution time: 1.0267
INFO - 2024-12-01 17:23:17 --> Config Class Initialized
INFO - 2024-12-01 17:23:17 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:23:17 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:23:17 --> Utf8 Class Initialized
INFO - 2024-12-01 17:23:17 --> URI Class Initialized
INFO - 2024-12-01 17:23:17 --> Router Class Initialized
INFO - 2024-12-01 17:23:17 --> Output Class Initialized
INFO - 2024-12-01 17:23:17 --> Security Class Initialized
DEBUG - 2024-12-01 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:23:17 --> CSRF cookie sent
INFO - 2024-12-01 17:23:17 --> Input Class Initialized
INFO - 2024-12-01 17:23:17 --> Language Class Initialized
INFO - 2024-12-01 17:23:17 --> Loader Class Initialized
INFO - 2024-12-01 17:23:17 --> Helper loaded: url_helper
INFO - 2024-12-01 17:23:17 --> Helper loaded: form_helper
INFO - 2024-12-01 17:23:17 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:23:17 --> Form Validation Class Initialized
INFO - 2024-12-01 17:23:17 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:23:17 --> Controller Class Initialized
INFO - 2024-12-01 17:23:17 --> Model "User_model" initialized
INFO - 2024-12-01 17:23:17 --> Model "Category_model" initialized
INFO - 2024-12-01 17:23:17 --> Model "Review_model" initialized
INFO - 2024-12-01 17:23:17 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:23:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:23:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:23:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:23:17 --> Final output sent to browser
DEBUG - 2024-12-01 17:23:17 --> Total execution time: 0.2648
INFO - 2024-12-01 17:33:52 --> Config Class Initialized
INFO - 2024-12-01 17:33:52 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:33:52 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:33:52 --> Utf8 Class Initialized
INFO - 2024-12-01 17:33:52 --> URI Class Initialized
INFO - 2024-12-01 17:33:52 --> Router Class Initialized
INFO - 2024-12-01 17:33:52 --> Output Class Initialized
INFO - 2024-12-01 17:33:52 --> Security Class Initialized
DEBUG - 2024-12-01 17:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:33:52 --> CSRF cookie sent
INFO - 2024-12-01 17:33:52 --> Input Class Initialized
INFO - 2024-12-01 17:33:52 --> Language Class Initialized
INFO - 2024-12-01 17:33:52 --> Loader Class Initialized
INFO - 2024-12-01 17:33:52 --> Helper loaded: url_helper
INFO - 2024-12-01 17:33:52 --> Helper loaded: form_helper
INFO - 2024-12-01 17:33:52 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:33:52 --> Form Validation Class Initialized
INFO - 2024-12-01 17:33:52 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:33:52 --> Controller Class Initialized
INFO - 2024-12-01 17:33:52 --> Model "User_model" initialized
INFO - 2024-12-01 17:33:52 --> Model "Category_model" initialized
INFO - 2024-12-01 17:33:52 --> Model "Review_model" initialized
INFO - 2024-12-01 17:33:52 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:33:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:33:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:33:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:33:52 --> Final output sent to browser
DEBUG - 2024-12-01 17:33:52 --> Total execution time: 0.6093
INFO - 2024-12-01 17:38:53 --> Config Class Initialized
INFO - 2024-12-01 17:38:53 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:38:53 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:38:53 --> Utf8 Class Initialized
INFO - 2024-12-01 17:38:53 --> URI Class Initialized
INFO - 2024-12-01 17:38:53 --> Router Class Initialized
INFO - 2024-12-01 17:38:53 --> Output Class Initialized
INFO - 2024-12-01 17:38:53 --> Security Class Initialized
DEBUG - 2024-12-01 17:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:38:53 --> CSRF cookie sent
INFO - 2024-12-01 17:38:53 --> Input Class Initialized
INFO - 2024-12-01 17:38:53 --> Language Class Initialized
INFO - 2024-12-01 17:38:53 --> Loader Class Initialized
INFO - 2024-12-01 17:38:53 --> Helper loaded: url_helper
INFO - 2024-12-01 17:38:53 --> Helper loaded: form_helper
INFO - 2024-12-01 17:38:53 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:38:53 --> Form Validation Class Initialized
INFO - 2024-12-01 17:38:53 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:38:53 --> Controller Class Initialized
INFO - 2024-12-01 17:38:53 --> Model "Category_model" initialized
INFO - 2024-12-01 17:38:53 --> Model "User_model" initialized
INFO - 2024-12-01 17:38:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-01 17:38:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:38:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:38:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:38:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-01 17:38:53 --> Final output sent to browser
DEBUG - 2024-12-01 17:38:53 --> Total execution time: 0.4160
INFO - 2024-12-01 17:38:57 --> Config Class Initialized
INFO - 2024-12-01 17:38:57 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:38:57 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:38:57 --> Utf8 Class Initialized
INFO - 2024-12-01 17:38:57 --> URI Class Initialized
INFO - 2024-12-01 17:38:57 --> Router Class Initialized
INFO - 2024-12-01 17:38:57 --> Output Class Initialized
INFO - 2024-12-01 17:38:57 --> Security Class Initialized
DEBUG - 2024-12-01 17:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:38:57 --> CSRF cookie sent
INFO - 2024-12-01 17:38:57 --> Input Class Initialized
INFO - 2024-12-01 17:38:57 --> Language Class Initialized
INFO - 2024-12-01 17:38:57 --> Loader Class Initialized
INFO - 2024-12-01 17:38:57 --> Helper loaded: url_helper
INFO - 2024-12-01 17:38:57 --> Helper loaded: form_helper
INFO - 2024-12-01 17:38:57 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:38:57 --> Form Validation Class Initialized
INFO - 2024-12-01 17:38:57 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:38:57 --> Controller Class Initialized
INFO - 2024-12-01 17:38:57 --> Model "User_model" initialized
INFO - 2024-12-01 17:38:57 --> Model "Category_model" initialized
INFO - 2024-12-01 17:38:57 --> Model "Review_model" initialized
INFO - 2024-12-01 17:38:57 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:38:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:38:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:38:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:38:57 --> Final output sent to browser
DEBUG - 2024-12-01 17:38:57 --> Total execution time: 0.2979
INFO - 2024-12-01 17:39:15 --> Config Class Initialized
INFO - 2024-12-01 17:39:15 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:39:15 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:39:15 --> Utf8 Class Initialized
INFO - 2024-12-01 17:39:15 --> URI Class Initialized
INFO - 2024-12-01 17:39:15 --> Router Class Initialized
INFO - 2024-12-01 17:39:15 --> Output Class Initialized
INFO - 2024-12-01 17:39:15 --> Security Class Initialized
DEBUG - 2024-12-01 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:39:15 --> CSRF cookie sent
INFO - 2024-12-01 17:39:15 --> Input Class Initialized
INFO - 2024-12-01 17:39:15 --> Language Class Initialized
INFO - 2024-12-01 17:39:15 --> Loader Class Initialized
INFO - 2024-12-01 17:39:15 --> Helper loaded: url_helper
INFO - 2024-12-01 17:39:15 --> Helper loaded: form_helper
INFO - 2024-12-01 17:39:15 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:39:15 --> Form Validation Class Initialized
INFO - 2024-12-01 17:39:15 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:39:15 --> Controller Class Initialized
INFO - 2024-12-01 17:39:15 --> Model "User_model" initialized
INFO - 2024-12-01 17:39:15 --> Model "Category_model" initialized
INFO - 2024-12-01 17:39:15 --> Model "Review_model" initialized
INFO - 2024-12-01 17:39:15 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:39:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:39:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:39:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:39:15 --> Final output sent to browser
DEBUG - 2024-12-01 17:39:15 --> Total execution time: 0.1998
INFO - 2024-12-01 17:39:17 --> Config Class Initialized
INFO - 2024-12-01 17:39:17 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:39:17 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:39:17 --> Utf8 Class Initialized
INFO - 2024-12-01 17:39:17 --> URI Class Initialized
INFO - 2024-12-01 17:39:17 --> Router Class Initialized
INFO - 2024-12-01 17:39:17 --> Output Class Initialized
INFO - 2024-12-01 17:39:17 --> Security Class Initialized
DEBUG - 2024-12-01 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:39:17 --> CSRF cookie sent
INFO - 2024-12-01 17:39:17 --> Input Class Initialized
INFO - 2024-12-01 17:39:17 --> Language Class Initialized
INFO - 2024-12-01 17:39:17 --> Loader Class Initialized
INFO - 2024-12-01 17:39:17 --> Helper loaded: url_helper
INFO - 2024-12-01 17:39:17 --> Helper loaded: form_helper
INFO - 2024-12-01 17:39:17 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:39:17 --> Form Validation Class Initialized
INFO - 2024-12-01 17:39:17 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:39:17 --> Controller Class Initialized
INFO - 2024-12-01 17:39:17 --> Model "User_model" initialized
INFO - 2024-12-01 17:39:17 --> Model "Category_model" initialized
INFO - 2024-12-01 17:39:17 --> Model "Review_model" initialized
INFO - 2024-12-01 17:39:17 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:39:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:39:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:39:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:39:17 --> Final output sent to browser
DEBUG - 2024-12-01 17:39:17 --> Total execution time: 0.1251
INFO - 2024-12-01 17:39:22 --> Config Class Initialized
INFO - 2024-12-01 17:39:22 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:39:22 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:39:22 --> Utf8 Class Initialized
INFO - 2024-12-01 17:39:23 --> URI Class Initialized
INFO - 2024-12-01 17:39:23 --> Router Class Initialized
INFO - 2024-12-01 17:39:23 --> Output Class Initialized
INFO - 2024-12-01 17:39:23 --> Security Class Initialized
DEBUG - 2024-12-01 17:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:39:23 --> CSRF cookie sent
INFO - 2024-12-01 17:39:23 --> Input Class Initialized
INFO - 2024-12-01 17:39:23 --> Language Class Initialized
INFO - 2024-12-01 17:39:23 --> Loader Class Initialized
INFO - 2024-12-01 17:39:23 --> Helper loaded: url_helper
INFO - 2024-12-01 17:39:23 --> Helper loaded: form_helper
INFO - 2024-12-01 17:39:23 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:39:23 --> Form Validation Class Initialized
INFO - 2024-12-01 17:39:23 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:39:23 --> Controller Class Initialized
INFO - 2024-12-01 17:39:23 --> Model "User_model" initialized
INFO - 2024-12-01 17:39:23 --> Model "Category_model" initialized
INFO - 2024-12-01 17:39:23 --> Model "Review_model" initialized
INFO - 2024-12-01 17:39:23 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:39:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:39:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:39:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:39:23 --> Final output sent to browser
DEBUG - 2024-12-01 17:39:23 --> Total execution time: 0.0977
INFO - 2024-12-01 17:41:32 --> Config Class Initialized
INFO - 2024-12-01 17:41:32 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:41:32 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:41:32 --> Utf8 Class Initialized
INFO - 2024-12-01 17:41:32 --> URI Class Initialized
INFO - 2024-12-01 17:41:32 --> Router Class Initialized
INFO - 2024-12-01 17:41:32 --> Output Class Initialized
INFO - 2024-12-01 17:41:32 --> Security Class Initialized
DEBUG - 2024-12-01 17:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:41:32 --> CSRF cookie sent
INFO - 2024-12-01 17:41:32 --> Input Class Initialized
INFO - 2024-12-01 17:41:32 --> Language Class Initialized
INFO - 2024-12-01 17:41:32 --> Loader Class Initialized
INFO - 2024-12-01 17:41:32 --> Helper loaded: url_helper
INFO - 2024-12-01 17:41:32 --> Helper loaded: form_helper
INFO - 2024-12-01 17:41:32 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:41:32 --> Form Validation Class Initialized
INFO - 2024-12-01 17:41:32 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:41:32 --> Controller Class Initialized
INFO - 2024-12-01 17:41:32 --> Model "User_model" initialized
INFO - 2024-12-01 17:41:32 --> Model "Category_model" initialized
INFO - 2024-12-01 17:41:32 --> Model "Review_model" initialized
INFO - 2024-12-01 17:41:32 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:41:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:41:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:41:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:41:32 --> Final output sent to browser
DEBUG - 2024-12-01 17:41:32 --> Total execution time: 0.6868
INFO - 2024-12-01 17:42:15 --> Config Class Initialized
INFO - 2024-12-01 17:42:15 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:42:15 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:42:15 --> Utf8 Class Initialized
INFO - 2024-12-01 17:42:15 --> URI Class Initialized
INFO - 2024-12-01 17:42:15 --> Router Class Initialized
INFO - 2024-12-01 17:42:15 --> Output Class Initialized
INFO - 2024-12-01 17:42:15 --> Security Class Initialized
DEBUG - 2024-12-01 17:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:42:15 --> CSRF cookie sent
INFO - 2024-12-01 17:42:15 --> Input Class Initialized
INFO - 2024-12-01 17:42:15 --> Language Class Initialized
INFO - 2024-12-01 17:42:15 --> Loader Class Initialized
INFO - 2024-12-01 17:42:15 --> Helper loaded: url_helper
INFO - 2024-12-01 17:42:15 --> Helper loaded: form_helper
INFO - 2024-12-01 17:42:15 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:42:15 --> Form Validation Class Initialized
INFO - 2024-12-01 17:42:15 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:42:15 --> Controller Class Initialized
INFO - 2024-12-01 17:42:15 --> Model "User_model" initialized
INFO - 2024-12-01 17:42:15 --> Model "Category_model" initialized
INFO - 2024-12-01 17:42:15 --> Model "Review_model" initialized
INFO - 2024-12-01 17:42:15 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:42:15 --> Final output sent to browser
DEBUG - 2024-12-01 17:42:15 --> Total execution time: 0.2070
INFO - 2024-12-01 17:42:46 --> Config Class Initialized
INFO - 2024-12-01 17:42:46 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:42:46 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:42:46 --> Utf8 Class Initialized
INFO - 2024-12-01 17:42:46 --> URI Class Initialized
INFO - 2024-12-01 17:42:46 --> Router Class Initialized
INFO - 2024-12-01 17:42:46 --> Output Class Initialized
INFO - 2024-12-01 17:42:46 --> Security Class Initialized
DEBUG - 2024-12-01 17:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:42:46 --> CSRF cookie sent
INFO - 2024-12-01 17:42:46 --> Input Class Initialized
INFO - 2024-12-01 17:42:46 --> Language Class Initialized
INFO - 2024-12-01 17:42:46 --> Loader Class Initialized
INFO - 2024-12-01 17:42:46 --> Helper loaded: url_helper
INFO - 2024-12-01 17:42:46 --> Helper loaded: form_helper
INFO - 2024-12-01 17:42:46 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:42:46 --> Form Validation Class Initialized
INFO - 2024-12-01 17:42:46 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:42:46 --> Controller Class Initialized
INFO - 2024-12-01 17:42:46 --> Model "User_model" initialized
INFO - 2024-12-01 17:42:46 --> Model "Category_model" initialized
INFO - 2024-12-01 17:42:46 --> Model "Review_model" initialized
INFO - 2024-12-01 17:42:46 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:42:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:42:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:42:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:42:46 --> Final output sent to browser
DEBUG - 2024-12-01 17:42:46 --> Total execution time: 0.0833
INFO - 2024-12-01 17:43:16 --> Config Class Initialized
INFO - 2024-12-01 17:43:16 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:43:16 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:43:16 --> Utf8 Class Initialized
INFO - 2024-12-01 17:43:16 --> URI Class Initialized
INFO - 2024-12-01 17:43:16 --> Router Class Initialized
INFO - 2024-12-01 17:43:16 --> Output Class Initialized
INFO - 2024-12-01 17:43:16 --> Security Class Initialized
DEBUG - 2024-12-01 17:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:43:16 --> CSRF cookie sent
INFO - 2024-12-01 17:43:16 --> Input Class Initialized
INFO - 2024-12-01 17:43:16 --> Language Class Initialized
INFO - 2024-12-01 17:43:16 --> Loader Class Initialized
INFO - 2024-12-01 17:43:16 --> Helper loaded: url_helper
INFO - 2024-12-01 17:43:16 --> Helper loaded: form_helper
INFO - 2024-12-01 17:43:16 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:43:16 --> Form Validation Class Initialized
INFO - 2024-12-01 17:43:16 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:43:16 --> Controller Class Initialized
INFO - 2024-12-01 17:43:16 --> Model "User_model" initialized
INFO - 2024-12-01 17:43:16 --> Model "Category_model" initialized
INFO - 2024-12-01 17:43:16 --> Model "Review_model" initialized
INFO - 2024-12-01 17:43:16 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:43:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:43:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:43:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:43:16 --> Final output sent to browser
DEBUG - 2024-12-01 17:43:16 --> Total execution time: 0.3641
INFO - 2024-12-01 17:44:30 --> Config Class Initialized
INFO - 2024-12-01 17:44:30 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:44:30 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:44:30 --> Utf8 Class Initialized
INFO - 2024-12-01 17:44:31 --> URI Class Initialized
INFO - 2024-12-01 17:44:31 --> Router Class Initialized
INFO - 2024-12-01 17:44:31 --> Output Class Initialized
INFO - 2024-12-01 17:44:31 --> Security Class Initialized
DEBUG - 2024-12-01 17:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:44:31 --> CSRF cookie sent
INFO - 2024-12-01 17:44:31 --> Input Class Initialized
INFO - 2024-12-01 17:44:31 --> Language Class Initialized
INFO - 2024-12-01 17:44:31 --> Loader Class Initialized
INFO - 2024-12-01 17:44:31 --> Helper loaded: url_helper
INFO - 2024-12-01 17:44:31 --> Helper loaded: form_helper
INFO - 2024-12-01 17:44:31 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:44:31 --> Form Validation Class Initialized
INFO - 2024-12-01 17:44:31 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:44:31 --> Controller Class Initialized
INFO - 2024-12-01 17:44:31 --> Model "User_model" initialized
INFO - 2024-12-01 17:44:31 --> Model "Category_model" initialized
INFO - 2024-12-01 17:44:31 --> Model "Review_model" initialized
INFO - 2024-12-01 17:44:31 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:44:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:44:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:44:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:44:31 --> Final output sent to browser
DEBUG - 2024-12-01 17:44:31 --> Total execution time: 0.3737
INFO - 2024-12-01 17:45:35 --> Config Class Initialized
INFO - 2024-12-01 17:45:35 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:45:35 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:45:35 --> Utf8 Class Initialized
INFO - 2024-12-01 17:45:35 --> URI Class Initialized
INFO - 2024-12-01 17:45:35 --> Router Class Initialized
INFO - 2024-12-01 17:45:35 --> Output Class Initialized
INFO - 2024-12-01 17:45:35 --> Security Class Initialized
DEBUG - 2024-12-01 17:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:45:35 --> CSRF cookie sent
INFO - 2024-12-01 17:45:35 --> Input Class Initialized
INFO - 2024-12-01 17:45:35 --> Language Class Initialized
INFO - 2024-12-01 17:45:35 --> Loader Class Initialized
INFO - 2024-12-01 17:45:35 --> Helper loaded: url_helper
INFO - 2024-12-01 17:45:35 --> Helper loaded: form_helper
INFO - 2024-12-01 17:45:35 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:45:35 --> Form Validation Class Initialized
INFO - 2024-12-01 17:45:35 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:45:35 --> Controller Class Initialized
INFO - 2024-12-01 17:45:35 --> Model "User_model" initialized
INFO - 2024-12-01 17:45:35 --> Model "Category_model" initialized
INFO - 2024-12-01 17:45:35 --> Model "Review_model" initialized
INFO - 2024-12-01 17:45:35 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:45:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:45:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:45:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:45:35 --> Final output sent to browser
DEBUG - 2024-12-01 17:45:35 --> Total execution time: 0.2848
INFO - 2024-12-01 17:46:07 --> Config Class Initialized
INFO - 2024-12-01 17:46:07 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:46:07 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:46:07 --> Utf8 Class Initialized
INFO - 2024-12-01 17:46:07 --> URI Class Initialized
INFO - 2024-12-01 17:46:07 --> Router Class Initialized
INFO - 2024-12-01 17:46:07 --> Output Class Initialized
INFO - 2024-12-01 17:46:07 --> Security Class Initialized
DEBUG - 2024-12-01 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:46:07 --> CSRF cookie sent
INFO - 2024-12-01 17:46:07 --> Input Class Initialized
INFO - 2024-12-01 17:46:07 --> Language Class Initialized
INFO - 2024-12-01 17:46:07 --> Loader Class Initialized
INFO - 2024-12-01 17:46:07 --> Helper loaded: url_helper
INFO - 2024-12-01 17:46:07 --> Helper loaded: form_helper
INFO - 2024-12-01 17:46:07 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:46:07 --> Form Validation Class Initialized
INFO - 2024-12-01 17:46:07 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:46:07 --> Controller Class Initialized
INFO - 2024-12-01 17:46:07 --> Model "User_model" initialized
INFO - 2024-12-01 17:46:07 --> Model "Category_model" initialized
INFO - 2024-12-01 17:46:07 --> Model "Review_model" initialized
INFO - 2024-12-01 17:46:07 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:46:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:46:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:46:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-01 17:46:07 --> Final output sent to browser
DEBUG - 2024-12-01 17:46:07 --> Total execution time: 0.1598
INFO - 2024-12-01 17:46:13 --> Config Class Initialized
INFO - 2024-12-01 17:46:13 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:46:13 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:46:13 --> Utf8 Class Initialized
INFO - 2024-12-01 17:46:13 --> URI Class Initialized
INFO - 2024-12-01 17:46:13 --> Router Class Initialized
INFO - 2024-12-01 17:46:13 --> Output Class Initialized
INFO - 2024-12-01 17:46:13 --> Security Class Initialized
DEBUG - 2024-12-01 17:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:46:13 --> CSRF cookie sent
INFO - 2024-12-01 17:46:13 --> Input Class Initialized
INFO - 2024-12-01 17:46:13 --> Language Class Initialized
INFO - 2024-12-01 17:46:13 --> Loader Class Initialized
INFO - 2024-12-01 17:46:13 --> Helper loaded: url_helper
INFO - 2024-12-01 17:46:13 --> Helper loaded: form_helper
INFO - 2024-12-01 17:46:13 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:46:13 --> Form Validation Class Initialized
INFO - 2024-12-01 17:46:13 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:46:13 --> Controller Class Initialized
INFO - 2024-12-01 17:46:13 --> Model "User_model" initialized
INFO - 2024-12-01 17:46:13 --> Model "Category_model" initialized
INFO - 2024-12-01 17:46:13 --> Model "Review_model" initialized
INFO - 2024-12-01 17:46:13 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:46:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:46:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:46:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-01 17:46:14 --> Final output sent to browser
DEBUG - 2024-12-01 17:46:14 --> Total execution time: 0.0600
INFO - 2024-12-01 17:46:18 --> Config Class Initialized
INFO - 2024-12-01 17:46:18 --> Hooks Class Initialized
DEBUG - 2024-12-01 17:46:18 --> UTF-8 Support Enabled
INFO - 2024-12-01 17:46:18 --> Utf8 Class Initialized
INFO - 2024-12-01 17:46:18 --> URI Class Initialized
INFO - 2024-12-01 17:46:18 --> Router Class Initialized
INFO - 2024-12-01 17:46:18 --> Output Class Initialized
INFO - 2024-12-01 17:46:18 --> Security Class Initialized
DEBUG - 2024-12-01 17:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 17:46:18 --> CSRF cookie sent
INFO - 2024-12-01 17:46:19 --> Input Class Initialized
INFO - 2024-12-01 17:46:19 --> Language Class Initialized
INFO - 2024-12-01 17:46:19 --> Loader Class Initialized
INFO - 2024-12-01 17:46:19 --> Helper loaded: url_helper
INFO - 2024-12-01 17:46:19 --> Helper loaded: form_helper
INFO - 2024-12-01 17:46:19 --> Database Driver Class Initialized
DEBUG - 2024-12-01 17:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-01 17:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 17:46:19 --> Form Validation Class Initialized
INFO - 2024-12-01 17:46:19 --> Model "Culinary_model" initialized
INFO - 2024-12-01 17:46:19 --> Controller Class Initialized
INFO - 2024-12-01 17:46:19 --> Model "User_model" initialized
INFO - 2024-12-01 17:46:19 --> Model "Category_model" initialized
INFO - 2024-12-01 17:46:19 --> Model "Review_model" initialized
INFO - 2024-12-01 17:46:19 --> Model "News_model" initialized
DEBUG - 2024-12-01 17:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-01 17:46:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-01 17:46:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-01 17:46:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-01 17:46:19 --> Final output sent to browser
DEBUG - 2024-12-01 17:46:19 --> Total execution time: 0.0762
