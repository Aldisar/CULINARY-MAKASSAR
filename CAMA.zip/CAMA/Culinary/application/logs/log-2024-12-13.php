<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-13 01:48:20 --> Config Class Initialized
INFO - 2024-12-13 01:48:20 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:48:20 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:48:20 --> Utf8 Class Initialized
INFO - 2024-12-13 01:48:20 --> URI Class Initialized
INFO - 2024-12-13 01:48:20 --> Router Class Initialized
INFO - 2024-12-13 01:48:20 --> Output Class Initialized
INFO - 2024-12-13 01:48:20 --> Security Class Initialized
DEBUG - 2024-12-13 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:48:20 --> CSRF cookie sent
INFO - 2024-12-13 01:48:20 --> Input Class Initialized
INFO - 2024-12-13 01:48:20 --> Language Class Initialized
INFO - 2024-12-13 01:48:20 --> Loader Class Initialized
INFO - 2024-12-13 01:48:20 --> Helper loaded: url_helper
INFO - 2024-12-13 01:48:20 --> Helper loaded: form_helper
INFO - 2024-12-13 01:48:20 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:48:21 --> Form Validation Class Initialized
INFO - 2024-12-13 01:48:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:48:21 --> Controller Class Initialized
INFO - 2024-12-13 01:48:21 --> Model "User_model" initialized
INFO - 2024-12-13 01:48:21 --> Model "Category_model" initialized
INFO - 2024-12-13 01:48:21 --> Model "Review_model" initialized
INFO - 2024-12-13 01:48:21 --> Model "News_model" initialized
INFO - 2024-12-13 01:48:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 01:48:21 --> Query result: stdClass Object
(
    [view_count] => 155
)

INFO - 2024-12-13 01:48:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:48:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:48:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 01:48:21 --> Final output sent to browser
DEBUG - 2024-12-13 01:48:21 --> Total execution time: 1.1061
INFO - 2024-12-13 01:56:31 --> Config Class Initialized
INFO - 2024-12-13 01:56:31 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:56:31 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:56:31 --> Utf8 Class Initialized
INFO - 2024-12-13 01:56:32 --> URI Class Initialized
INFO - 2024-12-13 01:56:32 --> Router Class Initialized
INFO - 2024-12-13 01:56:32 --> Output Class Initialized
INFO - 2024-12-13 01:56:32 --> Security Class Initialized
DEBUG - 2024-12-13 01:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:56:32 --> CSRF cookie sent
INFO - 2024-12-13 01:56:32 --> Input Class Initialized
INFO - 2024-12-13 01:56:32 --> Language Class Initialized
INFO - 2024-12-13 01:56:32 --> Loader Class Initialized
INFO - 2024-12-13 01:56:32 --> Helper loaded: url_helper
INFO - 2024-12-13 01:56:32 --> Helper loaded: form_helper
INFO - 2024-12-13 01:56:32 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:56:32 --> Form Validation Class Initialized
INFO - 2024-12-13 01:56:32 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:56:32 --> Controller Class Initialized
INFO - 2024-12-13 01:56:32 --> Model "User_model" initialized
INFO - 2024-12-13 01:56:32 --> Model "Category_model" initialized
INFO - 2024-12-13 01:56:32 --> Model "Review_model" initialized
INFO - 2024-12-13 01:56:32 --> Model "News_model" initialized
INFO - 2024-12-13 01:56:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:56:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:56:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:56:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 01:56:32 --> Final output sent to browser
DEBUG - 2024-12-13 01:56:32 --> Total execution time: 0.6449
INFO - 2024-12-13 01:56:57 --> Config Class Initialized
INFO - 2024-12-13 01:56:57 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:56:57 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:56:57 --> Utf8 Class Initialized
INFO - 2024-12-13 01:56:57 --> URI Class Initialized
INFO - 2024-12-13 01:56:57 --> Router Class Initialized
INFO - 2024-12-13 01:56:57 --> Output Class Initialized
INFO - 2024-12-13 01:56:57 --> Security Class Initialized
DEBUG - 2024-12-13 01:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:56:57 --> CSRF cookie sent
INFO - 2024-12-13 01:56:57 --> Input Class Initialized
INFO - 2024-12-13 01:56:57 --> Language Class Initialized
INFO - 2024-12-13 01:56:57 --> Loader Class Initialized
INFO - 2024-12-13 01:56:57 --> Helper loaded: url_helper
INFO - 2024-12-13 01:56:57 --> Helper loaded: form_helper
INFO - 2024-12-13 01:56:57 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:56:57 --> Form Validation Class Initialized
INFO - 2024-12-13 01:56:57 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:56:57 --> Controller Class Initialized
INFO - 2024-12-13 01:56:57 --> Model "User_model" initialized
INFO - 2024-12-13 01:56:57 --> Model "Category_model" initialized
INFO - 2024-12-13 01:56:57 --> Model "Review_model" initialized
INFO - 2024-12-13 01:56:57 --> Model "News_model" initialized
INFO - 2024-12-13 01:56:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:56:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:56:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:56:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-13 01:56:58 --> Final output sent to browser
DEBUG - 2024-12-13 01:56:58 --> Total execution time: 0.1310
INFO - 2024-12-13 01:57:12 --> Config Class Initialized
INFO - 2024-12-13 01:57:12 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:12 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:12 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:12 --> URI Class Initialized
INFO - 2024-12-13 01:57:12 --> Router Class Initialized
INFO - 2024-12-13 01:57:12 --> Output Class Initialized
INFO - 2024-12-13 01:57:12 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:12 --> CSRF cookie sent
INFO - 2024-12-13 01:57:12 --> Input Class Initialized
INFO - 2024-12-13 01:57:12 --> Language Class Initialized
INFO - 2024-12-13 01:57:12 --> Loader Class Initialized
INFO - 2024-12-13 01:57:12 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:12 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:12 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:12 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:12 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:12 --> Controller Class Initialized
INFO - 2024-12-13 01:57:12 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:12 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:12 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:12 --> Model "News_model" initialized
INFO - 2024-12-13 01:57:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:57:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:57:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:57:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/minuman.php
INFO - 2024-12-13 01:57:12 --> Final output sent to browser
DEBUG - 2024-12-13 01:57:12 --> Total execution time: 0.1054
INFO - 2024-12-13 01:57:17 --> Config Class Initialized
INFO - 2024-12-13 01:57:17 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:17 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:17 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:17 --> URI Class Initialized
INFO - 2024-12-13 01:57:17 --> Router Class Initialized
INFO - 2024-12-13 01:57:17 --> Output Class Initialized
INFO - 2024-12-13 01:57:17 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:17 --> CSRF cookie sent
INFO - 2024-12-13 01:57:17 --> Input Class Initialized
INFO - 2024-12-13 01:57:17 --> Language Class Initialized
INFO - 2024-12-13 01:57:17 --> Loader Class Initialized
INFO - 2024-12-13 01:57:17 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:17 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:17 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:17 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:17 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:17 --> Controller Class Initialized
INFO - 2024-12-13 01:57:17 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:17 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:17 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:17 --> Model "News_model" initialized
INFO - 2024-12-13 01:57:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 01:57:17 --> Query result: stdClass Object
(
    [view_count] => 156
)

INFO - 2024-12-13 01:57:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:57:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:57:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 01:57:17 --> Final output sent to browser
DEBUG - 2024-12-13 01:57:17 --> Total execution time: 0.1099
INFO - 2024-12-13 01:57:17 --> Config Class Initialized
INFO - 2024-12-13 01:57:17 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:17 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:17 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:17 --> URI Class Initialized
INFO - 2024-12-13 01:57:17 --> Router Class Initialized
INFO - 2024-12-13 01:57:17 --> Output Class Initialized
INFO - 2024-12-13 01:57:17 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:17 --> CSRF cookie sent
INFO - 2024-12-13 01:57:17 --> Input Class Initialized
INFO - 2024-12-13 01:57:17 --> Language Class Initialized
ERROR - 2024-12-13 01:57:17 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 01:57:21 --> Config Class Initialized
INFO - 2024-12-13 01:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:21 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:21 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:21 --> URI Class Initialized
INFO - 2024-12-13 01:57:21 --> Router Class Initialized
INFO - 2024-12-13 01:57:21 --> Output Class Initialized
INFO - 2024-12-13 01:57:21 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:21 --> CSRF cookie sent
INFO - 2024-12-13 01:57:21 --> Input Class Initialized
INFO - 2024-12-13 01:57:21 --> Language Class Initialized
INFO - 2024-12-13 01:57:21 --> Loader Class Initialized
INFO - 2024-12-13 01:57:21 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:21 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:21 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:21 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:21 --> Controller Class Initialized
INFO - 2024-12-13 01:57:21 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:57:21 --> Config Class Initialized
INFO - 2024-12-13 01:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:21 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:21 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:21 --> URI Class Initialized
INFO - 2024-12-13 01:57:21 --> Router Class Initialized
INFO - 2024-12-13 01:57:21 --> Output Class Initialized
INFO - 2024-12-13 01:57:21 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:21 --> CSRF cookie sent
INFO - 2024-12-13 01:57:21 --> Input Class Initialized
INFO - 2024-12-13 01:57:21 --> Language Class Initialized
INFO - 2024-12-13 01:57:21 --> Loader Class Initialized
INFO - 2024-12-13 01:57:21 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:21 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:21 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:21 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:21 --> Controller Class Initialized
INFO - 2024-12-13 01:57:21 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 01:57:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:57:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:57:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:57:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-13 01:57:21 --> Final output sent to browser
DEBUG - 2024-12-13 01:57:21 --> Total execution time: 0.0667
INFO - 2024-12-13 01:57:24 --> Config Class Initialized
INFO - 2024-12-13 01:57:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:24 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:24 --> URI Class Initialized
INFO - 2024-12-13 01:57:24 --> Router Class Initialized
INFO - 2024-12-13 01:57:24 --> Output Class Initialized
INFO - 2024-12-13 01:57:24 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:24 --> CSRF cookie sent
INFO - 2024-12-13 01:57:24 --> CSRF token verified
INFO - 2024-12-13 01:57:24 --> Input Class Initialized
INFO - 2024-12-13 01:57:24 --> Language Class Initialized
INFO - 2024-12-13 01:57:24 --> Loader Class Initialized
INFO - 2024-12-13 01:57:24 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:24 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:24 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:24 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:24 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:24 --> Controller Class Initialized
INFO - 2024-12-13 01:57:24 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "News_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:57:24 --> Config Class Initialized
INFO - 2024-12-13 01:57:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:24 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:24 --> URI Class Initialized
INFO - 2024-12-13 01:57:24 --> Router Class Initialized
INFO - 2024-12-13 01:57:24 --> Output Class Initialized
INFO - 2024-12-13 01:57:24 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:24 --> CSRF cookie sent
INFO - 2024-12-13 01:57:24 --> Input Class Initialized
INFO - 2024-12-13 01:57:24 --> Language Class Initialized
INFO - 2024-12-13 01:57:24 --> Loader Class Initialized
INFO - 2024-12-13 01:57:24 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:24 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:24 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:24 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:24 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:24 --> Controller Class Initialized
INFO - 2024-12-13 01:57:24 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 01:57:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 01:57:24 --> Query result: stdClass Object
(
    [view_count] => 156
)

INFO - 2024-12-13 01:57:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 01:57:24 --> Final output sent to browser
DEBUG - 2024-12-13 01:57:24 --> Total execution time: 0.0816
INFO - 2024-12-13 01:57:28 --> Config Class Initialized
INFO - 2024-12-13 01:57:28 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:57:28 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:57:28 --> Utf8 Class Initialized
INFO - 2024-12-13 01:57:28 --> URI Class Initialized
INFO - 2024-12-13 01:57:28 --> Router Class Initialized
INFO - 2024-12-13 01:57:28 --> Output Class Initialized
INFO - 2024-12-13 01:57:28 --> Security Class Initialized
DEBUG - 2024-12-13 01:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:57:28 --> CSRF cookie sent
INFO - 2024-12-13 01:57:28 --> Input Class Initialized
INFO - 2024-12-13 01:57:28 --> Language Class Initialized
INFO - 2024-12-13 01:57:28 --> Loader Class Initialized
INFO - 2024-12-13 01:57:28 --> Helper loaded: url_helper
INFO - 2024-12-13 01:57:28 --> Helper loaded: form_helper
INFO - 2024-12-13 01:57:28 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:57:29 --> Form Validation Class Initialized
INFO - 2024-12-13 01:57:29 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:57:29 --> Controller Class Initialized
INFO - 2024-12-13 01:57:29 --> Model "Review_model" initialized
INFO - 2024-12-13 01:57:29 --> Model "Category_model" initialized
INFO - 2024-12-13 01:57:29 --> Model "User_model" initialized
INFO - 2024-12-13 01:57:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 01:57:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 01:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 01:57:29 --> Pagination Class Initialized
INFO - 2024-12-13 01:57:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 01:57:29 --> Final output sent to browser
DEBUG - 2024-12-13 01:57:29 --> Total execution time: 0.1158
INFO - 2024-12-13 01:59:42 --> Config Class Initialized
INFO - 2024-12-13 01:59:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:59:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:59:42 --> Utf8 Class Initialized
INFO - 2024-12-13 01:59:42 --> URI Class Initialized
INFO - 2024-12-13 01:59:42 --> Router Class Initialized
INFO - 2024-12-13 01:59:42 --> Output Class Initialized
INFO - 2024-12-13 01:59:42 --> Security Class Initialized
DEBUG - 2024-12-13 01:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:59:42 --> CSRF cookie sent
INFO - 2024-12-13 01:59:42 --> Input Class Initialized
INFO - 2024-12-13 01:59:42 --> Language Class Initialized
INFO - 2024-12-13 01:59:42 --> Loader Class Initialized
INFO - 2024-12-13 01:59:42 --> Helper loaded: url_helper
INFO - 2024-12-13 01:59:42 --> Helper loaded: form_helper
INFO - 2024-12-13 01:59:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 01:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 01:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 01:59:42 --> Form Validation Class Initialized
INFO - 2024-12-13 01:59:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 01:59:42 --> Controller Class Initialized
INFO - 2024-12-13 01:59:42 --> Model "User_model" initialized
INFO - 2024-12-13 01:59:42 --> Model "Category_model" initialized
INFO - 2024-12-13 01:59:42 --> Model "Review_model" initialized
INFO - 2024-12-13 01:59:42 --> Model "News_model" initialized
INFO - 2024-12-13 01:59:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 01:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 01:59:42 --> Query result: stdClass Object
(
    [view_count] => 157
)

INFO - 2024-12-13 01:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 01:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 01:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 01:59:42 --> Final output sent to browser
DEBUG - 2024-12-13 01:59:42 --> Total execution time: 0.2133
INFO - 2024-12-13 01:59:43 --> Config Class Initialized
INFO - 2024-12-13 01:59:43 --> Hooks Class Initialized
DEBUG - 2024-12-13 01:59:43 --> UTF-8 Support Enabled
INFO - 2024-12-13 01:59:43 --> Utf8 Class Initialized
INFO - 2024-12-13 01:59:43 --> URI Class Initialized
INFO - 2024-12-13 01:59:43 --> Router Class Initialized
INFO - 2024-12-13 01:59:43 --> Output Class Initialized
INFO - 2024-12-13 01:59:43 --> Security Class Initialized
DEBUG - 2024-12-13 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 01:59:43 --> CSRF cookie sent
INFO - 2024-12-13 01:59:43 --> Input Class Initialized
INFO - 2024-12-13 01:59:43 --> Language Class Initialized
ERROR - 2024-12-13 01:59:43 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 02:00:24 --> Config Class Initialized
INFO - 2024-12-13 02:00:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:24 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:25 --> URI Class Initialized
INFO - 2024-12-13 02:00:25 --> Router Class Initialized
INFO - 2024-12-13 02:00:25 --> Output Class Initialized
INFO - 2024-12-13 02:00:25 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:25 --> CSRF cookie sent
INFO - 2024-12-13 02:00:25 --> Input Class Initialized
INFO - 2024-12-13 02:00:25 --> Language Class Initialized
INFO - 2024-12-13 02:00:25 --> Loader Class Initialized
INFO - 2024-12-13 02:00:25 --> Helper loaded: url_helper
INFO - 2024-12-13 02:00:25 --> Helper loaded: form_helper
INFO - 2024-12-13 02:00:25 --> Database Driver Class Initialized
DEBUG - 2024-12-13 02:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 02:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:00:25 --> Form Validation Class Initialized
INFO - 2024-12-13 02:00:25 --> Model "Culinary_model" initialized
INFO - 2024-12-13 02:00:25 --> Controller Class Initialized
INFO - 2024-12-13 02:00:25 --> Model "User_model" initialized
INFO - 2024-12-13 02:00:25 --> Model "Category_model" initialized
INFO - 2024-12-13 02:00:25 --> Model "Review_model" initialized
INFO - 2024-12-13 02:00:25 --> Model "News_model" initialized
INFO - 2024-12-13 02:00:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 02:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 02:00:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 02:00:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 02:00:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 02:00:25 --> Final output sent to browser
DEBUG - 2024-12-13 02:00:25 --> Total execution time: 0.3851
INFO - 2024-12-13 02:00:34 --> Config Class Initialized
INFO - 2024-12-13 02:00:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:34 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:34 --> URI Class Initialized
INFO - 2024-12-13 02:00:34 --> Router Class Initialized
INFO - 2024-12-13 02:00:34 --> Output Class Initialized
INFO - 2024-12-13 02:00:34 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:34 --> CSRF cookie sent
INFO - 2024-12-13 02:00:34 --> Input Class Initialized
INFO - 2024-12-13 02:00:34 --> Language Class Initialized
INFO - 2024-12-13 02:00:34 --> Loader Class Initialized
INFO - 2024-12-13 02:00:34 --> Helper loaded: url_helper
INFO - 2024-12-13 02:00:34 --> Helper loaded: form_helper
INFO - 2024-12-13 02:00:34 --> Database Driver Class Initialized
DEBUG - 2024-12-13 02:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 02:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:00:34 --> Form Validation Class Initialized
INFO - 2024-12-13 02:00:34 --> Model "Culinary_model" initialized
INFO - 2024-12-13 02:00:34 --> Controller Class Initialized
INFO - 2024-12-13 02:00:34 --> Model "User_model" initialized
INFO - 2024-12-13 02:00:34 --> Model "Category_model" initialized
INFO - 2024-12-13 02:00:34 --> Model "Review_model" initialized
INFO - 2024-12-13 02:00:34 --> Model "News_model" initialized
INFO - 2024-12-13 02:00:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 02:00:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 02:00:34 --> Query result: stdClass Object
(
    [view_count] => 158
)

INFO - 2024-12-13 02:00:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 02:00:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 02:00:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 02:00:34 --> Final output sent to browser
DEBUG - 2024-12-13 02:00:34 --> Total execution time: 0.1531
INFO - 2024-12-13 02:00:34 --> Config Class Initialized
INFO - 2024-12-13 02:00:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:34 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:34 --> URI Class Initialized
INFO - 2024-12-13 02:00:34 --> Router Class Initialized
INFO - 2024-12-13 02:00:34 --> Output Class Initialized
INFO - 2024-12-13 02:00:34 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:34 --> CSRF cookie sent
INFO - 2024-12-13 02:00:34 --> Input Class Initialized
INFO - 2024-12-13 02:00:34 --> Language Class Initialized
ERROR - 2024-12-13 02:00:34 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 02:00:46 --> Config Class Initialized
INFO - 2024-12-13 02:00:46 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:46 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:46 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:46 --> URI Class Initialized
DEBUG - 2024-12-13 02:00:46 --> No URI present. Default controller set.
INFO - 2024-12-13 02:00:46 --> Router Class Initialized
INFO - 2024-12-13 02:00:46 --> Output Class Initialized
INFO - 2024-12-13 02:00:46 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:46 --> CSRF cookie sent
INFO - 2024-12-13 02:00:46 --> Input Class Initialized
INFO - 2024-12-13 02:00:46 --> Language Class Initialized
INFO - 2024-12-13 02:00:46 --> Loader Class Initialized
INFO - 2024-12-13 02:00:46 --> Helper loaded: url_helper
INFO - 2024-12-13 02:00:46 --> Helper loaded: form_helper
INFO - 2024-12-13 02:00:46 --> Database Driver Class Initialized
DEBUG - 2024-12-13 02:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 02:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:00:46 --> Form Validation Class Initialized
INFO - 2024-12-13 02:00:46 --> Model "Culinary_model" initialized
INFO - 2024-12-13 02:00:46 --> Controller Class Initialized
INFO - 2024-12-13 02:00:46 --> Model "User_model" initialized
INFO - 2024-12-13 02:00:46 --> Model "Category_model" initialized
INFO - 2024-12-13 02:00:46 --> Model "Review_model" initialized
INFO - 2024-12-13 02:00:46 --> Model "News_model" initialized
INFO - 2024-12-13 02:00:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 02:00:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 02:00:46 --> Query result: stdClass Object
(
    [view_count] => 159
)

INFO - 2024-12-13 02:00:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 02:00:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 02:00:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 02:00:46 --> Final output sent to browser
DEBUG - 2024-12-13 02:00:46 --> Total execution time: 0.1071
INFO - 2024-12-13 02:00:51 --> Config Class Initialized
INFO - 2024-12-13 02:00:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:51 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:51 --> URI Class Initialized
INFO - 2024-12-13 02:00:51 --> Router Class Initialized
INFO - 2024-12-13 02:00:51 --> Output Class Initialized
INFO - 2024-12-13 02:00:51 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:51 --> CSRF cookie sent
INFO - 2024-12-13 02:00:51 --> Input Class Initialized
INFO - 2024-12-13 02:00:51 --> Language Class Initialized
INFO - 2024-12-13 02:00:51 --> Loader Class Initialized
INFO - 2024-12-13 02:00:51 --> Helper loaded: url_helper
INFO - 2024-12-13 02:00:51 --> Helper loaded: form_helper
INFO - 2024-12-13 02:00:51 --> Database Driver Class Initialized
DEBUG - 2024-12-13 02:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 02:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:00:51 --> Form Validation Class Initialized
INFO - 2024-12-13 02:00:51 --> Model "Culinary_model" initialized
INFO - 2024-12-13 02:00:51 --> Controller Class Initialized
INFO - 2024-12-13 02:00:51 --> Model "User_model" initialized
INFO - 2024-12-13 02:00:51 --> Model "Category_model" initialized
INFO - 2024-12-13 02:00:51 --> Model "Review_model" initialized
INFO - 2024-12-13 02:00:51 --> Model "News_model" initialized
INFO - 2024-12-13 02:00:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 02:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 02:00:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 02:00:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 02:00:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 02:00:51 --> Final output sent to browser
DEBUG - 2024-12-13 02:00:51 --> Total execution time: 0.1448
INFO - 2024-12-13 02:00:56 --> Config Class Initialized
INFO - 2024-12-13 02:00:56 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:56 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:56 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:56 --> URI Class Initialized
INFO - 2024-12-13 02:00:56 --> Router Class Initialized
INFO - 2024-12-13 02:00:56 --> Output Class Initialized
INFO - 2024-12-13 02:00:56 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:56 --> CSRF cookie sent
INFO - 2024-12-13 02:00:56 --> CSRF token verified
INFO - 2024-12-13 02:00:56 --> Input Class Initialized
INFO - 2024-12-13 02:00:56 --> Language Class Initialized
INFO - 2024-12-13 02:00:56 --> Loader Class Initialized
INFO - 2024-12-13 02:00:56 --> Helper loaded: url_helper
INFO - 2024-12-13 02:00:56 --> Helper loaded: form_helper
INFO - 2024-12-13 02:00:56 --> Database Driver Class Initialized
DEBUG - 2024-12-13 02:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 02:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:00:56 --> Form Validation Class Initialized
INFO - 2024-12-13 02:00:56 --> Model "Culinary_model" initialized
INFO - 2024-12-13 02:00:56 --> Controller Class Initialized
INFO - 2024-12-13 02:00:56 --> Model "User_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "Category_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "Review_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "News_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 02:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 02:00:56 --> Config Class Initialized
INFO - 2024-12-13 02:00:56 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:56 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:56 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:56 --> URI Class Initialized
INFO - 2024-12-13 02:00:56 --> Router Class Initialized
INFO - 2024-12-13 02:00:56 --> Output Class Initialized
INFO - 2024-12-13 02:00:56 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:56 --> CSRF cookie sent
INFO - 2024-12-13 02:00:56 --> Input Class Initialized
INFO - 2024-12-13 02:00:56 --> Language Class Initialized
INFO - 2024-12-13 02:00:56 --> Loader Class Initialized
INFO - 2024-12-13 02:00:56 --> Helper loaded: url_helper
INFO - 2024-12-13 02:00:56 --> Helper loaded: form_helper
INFO - 2024-12-13 02:00:56 --> Database Driver Class Initialized
DEBUG - 2024-12-13 02:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 02:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:00:56 --> Form Validation Class Initialized
INFO - 2024-12-13 02:00:56 --> Model "Culinary_model" initialized
INFO - 2024-12-13 02:00:56 --> Controller Class Initialized
INFO - 2024-12-13 02:00:56 --> Model "User_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "Category_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "Review_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "News_model" initialized
INFO - 2024-12-13 02:00:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 02:00:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 02:00:56 --> Query result: stdClass Object
(
    [view_count] => 160
)

INFO - 2024-12-13 02:00:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 02:00:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 02:00:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 02:00:56 --> Final output sent to browser
DEBUG - 2024-12-13 02:00:56 --> Total execution time: 0.0593
INFO - 2024-12-13 02:00:56 --> Config Class Initialized
INFO - 2024-12-13 02:00:56 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:00:56 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:00:56 --> Utf8 Class Initialized
INFO - 2024-12-13 02:00:56 --> URI Class Initialized
INFO - 2024-12-13 02:00:56 --> Router Class Initialized
INFO - 2024-12-13 02:00:56 --> Output Class Initialized
INFO - 2024-12-13 02:00:56 --> Security Class Initialized
DEBUG - 2024-12-13 02:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:00:56 --> CSRF cookie sent
INFO - 2024-12-13 02:00:56 --> Input Class Initialized
INFO - 2024-12-13 02:00:56 --> Language Class Initialized
ERROR - 2024-12-13 02:00:56 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:12:55 --> Config Class Initialized
INFO - 2024-12-13 03:12:55 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:12:55 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:12:55 --> Utf8 Class Initialized
INFO - 2024-12-13 03:12:56 --> URI Class Initialized
INFO - 2024-12-13 03:12:56 --> Router Class Initialized
INFO - 2024-12-13 03:12:56 --> Output Class Initialized
INFO - 2024-12-13 03:12:56 --> Security Class Initialized
DEBUG - 2024-12-13 03:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:12:56 --> CSRF cookie sent
INFO - 2024-12-13 03:12:56 --> Input Class Initialized
INFO - 2024-12-13 03:12:56 --> Language Class Initialized
INFO - 2024-12-13 03:12:56 --> Loader Class Initialized
INFO - 2024-12-13 03:12:56 --> Helper loaded: url_helper
INFO - 2024-12-13 03:12:56 --> Helper loaded: form_helper
INFO - 2024-12-13 03:12:56 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:12:56 --> Form Validation Class Initialized
INFO - 2024-12-13 03:12:56 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:12:56 --> Controller Class Initialized
INFO - 2024-12-13 03:12:56 --> Model "User_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "Category_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "Review_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "News_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:12:56 --> Config Class Initialized
INFO - 2024-12-13 03:12:56 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:12:56 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:12:56 --> Utf8 Class Initialized
INFO - 2024-12-13 03:12:56 --> URI Class Initialized
INFO - 2024-12-13 03:12:56 --> Router Class Initialized
INFO - 2024-12-13 03:12:56 --> Output Class Initialized
INFO - 2024-12-13 03:12:56 --> Security Class Initialized
DEBUG - 2024-12-13 03:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:12:56 --> CSRF cookie sent
INFO - 2024-12-13 03:12:56 --> Input Class Initialized
INFO - 2024-12-13 03:12:56 --> Language Class Initialized
INFO - 2024-12-13 03:12:56 --> Loader Class Initialized
INFO - 2024-12-13 03:12:56 --> Helper loaded: url_helper
INFO - 2024-12-13 03:12:56 --> Helper loaded: form_helper
INFO - 2024-12-13 03:12:56 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:12:56 --> Form Validation Class Initialized
INFO - 2024-12-13 03:12:56 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:12:56 --> Controller Class Initialized
INFO - 2024-12-13 03:12:56 --> Model "User_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "Category_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "Review_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "News_model" initialized
INFO - 2024-12-13 03:12:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:12:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:12:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:12:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:12:56 --> Final output sent to browser
DEBUG - 2024-12-13 03:12:56 --> Total execution time: 0.0633
INFO - 2024-12-13 03:12:59 --> Config Class Initialized
INFO - 2024-12-13 03:12:59 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:12:59 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:12:59 --> Utf8 Class Initialized
INFO - 2024-12-13 03:12:59 --> URI Class Initialized
INFO - 2024-12-13 03:12:59 --> Router Class Initialized
INFO - 2024-12-13 03:12:59 --> Output Class Initialized
INFO - 2024-12-13 03:12:59 --> Security Class Initialized
DEBUG - 2024-12-13 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:12:59 --> CSRF cookie sent
INFO - 2024-12-13 03:12:59 --> Input Class Initialized
INFO - 2024-12-13 03:12:59 --> Language Class Initialized
INFO - 2024-12-13 03:12:59 --> Loader Class Initialized
INFO - 2024-12-13 03:12:59 --> Helper loaded: url_helper
INFO - 2024-12-13 03:12:59 --> Helper loaded: form_helper
INFO - 2024-12-13 03:12:59 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:12:59 --> Form Validation Class Initialized
INFO - 2024-12-13 03:12:59 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:12:59 --> Controller Class Initialized
INFO - 2024-12-13 03:12:59 --> Model "User_model" initialized
INFO - 2024-12-13 03:12:59 --> Model "Category_model" initialized
INFO - 2024-12-13 03:12:59 --> Model "Review_model" initialized
INFO - 2024-12-13 03:12:59 --> Model "News_model" initialized
INFO - 2024-12-13 03:12:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:12:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:13:00 --> Query result: stdClass Object
(
    [view_count] => 161
)

INFO - 2024-12-13 03:13:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:13:00 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:00 --> Total execution time: 0.6718
INFO - 2024-12-13 03:13:00 --> Config Class Initialized
INFO - 2024-12-13 03:13:00 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:00 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:00 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:00 --> URI Class Initialized
INFO - 2024-12-13 03:13:00 --> Router Class Initialized
INFO - 2024-12-13 03:13:00 --> Output Class Initialized
INFO - 2024-12-13 03:13:00 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:00 --> CSRF cookie sent
INFO - 2024-12-13 03:13:00 --> Input Class Initialized
INFO - 2024-12-13 03:13:00 --> Language Class Initialized
ERROR - 2024-12-13 03:13:00 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:13:13 --> Config Class Initialized
INFO - 2024-12-13 03:13:13 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:13 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:13 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:13 --> URI Class Initialized
INFO - 2024-12-13 03:13:13 --> Router Class Initialized
INFO - 2024-12-13 03:13:13 --> Output Class Initialized
INFO - 2024-12-13 03:13:13 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:13 --> CSRF cookie sent
INFO - 2024-12-13 03:13:13 --> Input Class Initialized
INFO - 2024-12-13 03:13:13 --> Language Class Initialized
INFO - 2024-12-13 03:13:13 --> Loader Class Initialized
INFO - 2024-12-13 03:13:13 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:13 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:13 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:13 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:13 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:13 --> Controller Class Initialized
INFO - 2024-12-13 03:13:13 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:13 --> Config Class Initialized
INFO - 2024-12-13 03:13:13 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:13 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:13 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:13 --> URI Class Initialized
INFO - 2024-12-13 03:13:13 --> Router Class Initialized
INFO - 2024-12-13 03:13:13 --> Output Class Initialized
INFO - 2024-12-13 03:13:13 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:13 --> CSRF cookie sent
INFO - 2024-12-13 03:13:13 --> Input Class Initialized
INFO - 2024-12-13 03:13:13 --> Language Class Initialized
INFO - 2024-12-13 03:13:13 --> Loader Class Initialized
INFO - 2024-12-13 03:13:13 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:13 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:13 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:13 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:13 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:13 --> Controller Class Initialized
INFO - 2024-12-13 03:13:13 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:13:13 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:13 --> Total execution time: 0.0679
INFO - 2024-12-13 03:13:21 --> Config Class Initialized
INFO - 2024-12-13 03:13:21 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:21 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:21 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:21 --> URI Class Initialized
INFO - 2024-12-13 03:13:21 --> Router Class Initialized
INFO - 2024-12-13 03:13:21 --> Output Class Initialized
INFO - 2024-12-13 03:13:21 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:21 --> CSRF cookie sent
INFO - 2024-12-13 03:13:21 --> Input Class Initialized
INFO - 2024-12-13 03:13:21 --> Language Class Initialized
INFO - 2024-12-13 03:13:21 --> Loader Class Initialized
INFO - 2024-12-13 03:13:21 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:21 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:21 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:21 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:21 --> Controller Class Initialized
INFO - 2024-12-13 03:13:21 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:21 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:21 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:21 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:13:21 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:21 --> Total execution time: 0.1610
INFO - 2024-12-13 03:13:28 --> Config Class Initialized
INFO - 2024-12-13 03:13:28 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:28 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:28 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:28 --> URI Class Initialized
INFO - 2024-12-13 03:13:28 --> Router Class Initialized
INFO - 2024-12-13 03:13:28 --> Output Class Initialized
INFO - 2024-12-13 03:13:28 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:28 --> CSRF cookie sent
INFO - 2024-12-13 03:13:28 --> Input Class Initialized
INFO - 2024-12-13 03:13:28 --> Language Class Initialized
INFO - 2024-12-13 03:13:28 --> Loader Class Initialized
INFO - 2024-12-13 03:13:28 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:28 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:28 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:28 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:28 --> Controller Class Initialized
INFO - 2024-12-13 03:13:28 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:28 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:28 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:28 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-13 03:13:29 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:29 --> Total execution time: 0.2011
INFO - 2024-12-13 03:13:34 --> Config Class Initialized
INFO - 2024-12-13 03:13:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:34 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:34 --> URI Class Initialized
INFO - 2024-12-13 03:13:34 --> Router Class Initialized
INFO - 2024-12-13 03:13:34 --> Output Class Initialized
INFO - 2024-12-13 03:13:34 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:34 --> CSRF cookie sent
INFO - 2024-12-13 03:13:34 --> Input Class Initialized
INFO - 2024-12-13 03:13:34 --> Language Class Initialized
INFO - 2024-12-13 03:13:34 --> Loader Class Initialized
INFO - 2024-12-13 03:13:34 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:34 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:34 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:34 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:34 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:34 --> Controller Class Initialized
INFO - 2024-12-13 03:13:34 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:34 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:34 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:34 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:13:34 --> Query result: stdClass Object
(
    [view_count] => 162
)

INFO - 2024-12-13 03:13:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:13:34 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:34 --> Total execution time: 0.1188
INFO - 2024-12-13 03:13:35 --> Config Class Initialized
INFO - 2024-12-13 03:13:35 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:35 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:35 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:35 --> URI Class Initialized
INFO - 2024-12-13 03:13:35 --> Router Class Initialized
INFO - 2024-12-13 03:13:35 --> Output Class Initialized
INFO - 2024-12-13 03:13:35 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:35 --> CSRF cookie sent
INFO - 2024-12-13 03:13:35 --> Input Class Initialized
INFO - 2024-12-13 03:13:35 --> Language Class Initialized
ERROR - 2024-12-13 03:13:35 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:13:39 --> Config Class Initialized
INFO - 2024-12-13 03:13:39 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:39 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:39 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:39 --> URI Class Initialized
INFO - 2024-12-13 03:13:39 --> Router Class Initialized
INFO - 2024-12-13 03:13:39 --> Output Class Initialized
INFO - 2024-12-13 03:13:39 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:39 --> CSRF cookie sent
INFO - 2024-12-13 03:13:39 --> Input Class Initialized
INFO - 2024-12-13 03:13:39 --> Language Class Initialized
INFO - 2024-12-13 03:13:39 --> Loader Class Initialized
INFO - 2024-12-13 03:13:39 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:39 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:39 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:39 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:39 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:39 --> Controller Class Initialized
INFO - 2024-12-13 03:13:39 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:39 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:39 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:39 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:13:39 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:39 --> Total execution time: 0.0439
INFO - 2024-12-13 03:13:42 --> Config Class Initialized
INFO - 2024-12-13 03:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:42 --> URI Class Initialized
INFO - 2024-12-13 03:13:42 --> Router Class Initialized
INFO - 2024-12-13 03:13:42 --> Output Class Initialized
INFO - 2024-12-13 03:13:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:42 --> CSRF cookie sent
INFO - 2024-12-13 03:13:42 --> CSRF token verified
INFO - 2024-12-13 03:13:42 --> Input Class Initialized
INFO - 2024-12-13 03:13:42 --> Language Class Initialized
INFO - 2024-12-13 03:13:42 --> Loader Class Initialized
INFO - 2024-12-13 03:13:42 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:42 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:42 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:42 --> Controller Class Initialized
INFO - 2024-12-13 03:13:42 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:42 --> Config Class Initialized
INFO - 2024-12-13 03:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:42 --> URI Class Initialized
INFO - 2024-12-13 03:13:42 --> Router Class Initialized
INFO - 2024-12-13 03:13:42 --> Output Class Initialized
INFO - 2024-12-13 03:13:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:42 --> CSRF cookie sent
INFO - 2024-12-13 03:13:42 --> Input Class Initialized
INFO - 2024-12-13 03:13:42 --> Language Class Initialized
INFO - 2024-12-13 03:13:42 --> Loader Class Initialized
INFO - 2024-12-13 03:13:42 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:42 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:42 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:42 --> Controller Class Initialized
INFO - 2024-12-13 03:13:42 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:13:42 --> Query result: stdClass Object
(
    [view_count] => 163
)

INFO - 2024-12-13 03:13:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:13:42 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:42 --> Total execution time: 0.0442
INFO - 2024-12-13 03:13:42 --> Config Class Initialized
INFO - 2024-12-13 03:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:42 --> URI Class Initialized
INFO - 2024-12-13 03:13:42 --> Router Class Initialized
INFO - 2024-12-13 03:13:42 --> Output Class Initialized
INFO - 2024-12-13 03:13:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:42 --> CSRF cookie sent
INFO - 2024-12-13 03:13:42 --> Input Class Initialized
INFO - 2024-12-13 03:13:42 --> Language Class Initialized
ERROR - 2024-12-13 03:13:42 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:13:43 --> Config Class Initialized
INFO - 2024-12-13 03:13:43 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:43 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:43 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:43 --> URI Class Initialized
INFO - 2024-12-13 03:13:43 --> Router Class Initialized
INFO - 2024-12-13 03:13:43 --> Output Class Initialized
INFO - 2024-12-13 03:13:43 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:43 --> CSRF cookie sent
INFO - 2024-12-13 03:13:43 --> Input Class Initialized
INFO - 2024-12-13 03:13:43 --> Language Class Initialized
INFO - 2024-12-13 03:13:43 --> Loader Class Initialized
INFO - 2024-12-13 03:13:43 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:43 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:43 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:43 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:43 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:43 --> Controller Class Initialized
INFO - 2024-12-13 03:13:43 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:43 --> Config Class Initialized
INFO - 2024-12-13 03:13:43 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:43 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:43 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:43 --> URI Class Initialized
INFO - 2024-12-13 03:13:43 --> Router Class Initialized
INFO - 2024-12-13 03:13:43 --> Output Class Initialized
INFO - 2024-12-13 03:13:43 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:43 --> CSRF cookie sent
INFO - 2024-12-13 03:13:43 --> Input Class Initialized
INFO - 2024-12-13 03:13:43 --> Language Class Initialized
INFO - 2024-12-13 03:13:43 --> Loader Class Initialized
INFO - 2024-12-13 03:13:43 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:43 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:43 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:43 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:43 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:43 --> Controller Class Initialized
INFO - 2024-12-13 03:13:43 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:13:43 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:43 --> Total execution time: 0.0500
INFO - 2024-12-13 03:13:48 --> Config Class Initialized
INFO - 2024-12-13 03:13:48 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:13:48 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:13:48 --> Utf8 Class Initialized
INFO - 2024-12-13 03:13:48 --> URI Class Initialized
INFO - 2024-12-13 03:13:48 --> Router Class Initialized
INFO - 2024-12-13 03:13:48 --> Output Class Initialized
INFO - 2024-12-13 03:13:48 --> Security Class Initialized
DEBUG - 2024-12-13 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:13:48 --> CSRF cookie sent
INFO - 2024-12-13 03:13:48 --> Input Class Initialized
INFO - 2024-12-13 03:13:48 --> Language Class Initialized
INFO - 2024-12-13 03:13:48 --> Loader Class Initialized
INFO - 2024-12-13 03:13:48 --> Helper loaded: url_helper
INFO - 2024-12-13 03:13:48 --> Helper loaded: form_helper
INFO - 2024-12-13 03:13:48 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:13:48 --> Form Validation Class Initialized
INFO - 2024-12-13 03:13:48 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:13:48 --> Controller Class Initialized
INFO - 2024-12-13 03:13:48 --> Model "User_model" initialized
INFO - 2024-12-13 03:13:48 --> Model "Category_model" initialized
INFO - 2024-12-13 03:13:48 --> Model "Review_model" initialized
INFO - 2024-12-13 03:13:48 --> Model "News_model" initialized
INFO - 2024-12-13 03:13:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:13:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:13:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:13:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-13 03:13:48 --> Final output sent to browser
DEBUG - 2024-12-13 03:13:48 --> Total execution time: 0.0558
INFO - 2024-12-13 03:14:00 --> Config Class Initialized
INFO - 2024-12-13 03:14:00 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:00 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:00 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:00 --> URI Class Initialized
INFO - 2024-12-13 03:14:00 --> Router Class Initialized
INFO - 2024-12-13 03:14:00 --> Output Class Initialized
INFO - 2024-12-13 03:14:00 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:00 --> CSRF cookie sent
INFO - 2024-12-13 03:14:00 --> CSRF token verified
INFO - 2024-12-13 03:14:00 --> Input Class Initialized
INFO - 2024-12-13 03:14:00 --> Language Class Initialized
INFO - 2024-12-13 03:14:00 --> Loader Class Initialized
INFO - 2024-12-13 03:14:00 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:00 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:00 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:00 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:00 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:00 --> Controller Class Initialized
INFO - 2024-12-13 03:14:00 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:00 --> Config Class Initialized
INFO - 2024-12-13 03:14:00 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:00 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:00 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:00 --> URI Class Initialized
INFO - 2024-12-13 03:14:00 --> Router Class Initialized
INFO - 2024-12-13 03:14:00 --> Output Class Initialized
INFO - 2024-12-13 03:14:00 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:00 --> CSRF cookie sent
INFO - 2024-12-13 03:14:00 --> Input Class Initialized
INFO - 2024-12-13 03:14:00 --> Language Class Initialized
INFO - 2024-12-13 03:14:00 --> Loader Class Initialized
INFO - 2024-12-13 03:14:00 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:00 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:00 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:00 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:00 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:00 --> Controller Class Initialized
INFO - 2024-12-13 03:14:00 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:14:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:14:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-13 03:14:00 --> Final output sent to browser
DEBUG - 2024-12-13 03:14:00 --> Total execution time: 0.0571
INFO - 2024-12-13 03:14:08 --> Config Class Initialized
INFO - 2024-12-13 03:14:08 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:08 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:08 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:08 --> URI Class Initialized
INFO - 2024-12-13 03:14:08 --> Router Class Initialized
INFO - 2024-12-13 03:14:08 --> Output Class Initialized
INFO - 2024-12-13 03:14:08 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:08 --> CSRF cookie sent
INFO - 2024-12-13 03:14:08 --> Input Class Initialized
INFO - 2024-12-13 03:14:08 --> Language Class Initialized
INFO - 2024-12-13 03:14:08 --> Loader Class Initialized
INFO - 2024-12-13 03:14:08 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:08 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:08 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:08 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:08 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:08 --> Controller Class Initialized
INFO - 2024-12-13 03:14:08 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:08 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:08 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:08 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:14:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:14:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:14:08 --> Final output sent to browser
DEBUG - 2024-12-13 03:14:08 --> Total execution time: 0.0558
INFO - 2024-12-13 03:14:09 --> Config Class Initialized
INFO - 2024-12-13 03:14:09 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:09 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:09 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:09 --> URI Class Initialized
INFO - 2024-12-13 03:14:09 --> Router Class Initialized
INFO - 2024-12-13 03:14:09 --> Output Class Initialized
INFO - 2024-12-13 03:14:09 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:09 --> CSRF cookie sent
INFO - 2024-12-13 03:14:09 --> CSRF token verified
INFO - 2024-12-13 03:14:09 --> Input Class Initialized
INFO - 2024-12-13 03:14:09 --> Language Class Initialized
INFO - 2024-12-13 03:14:09 --> Loader Class Initialized
INFO - 2024-12-13 03:14:09 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:09 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:09 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:09 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:09 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:09 --> Controller Class Initialized
INFO - 2024-12-13 03:14:09 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:09 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:09 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:09 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:10 --> Config Class Initialized
INFO - 2024-12-13 03:14:10 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:10 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:10 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:10 --> URI Class Initialized
INFO - 2024-12-13 03:14:10 --> Router Class Initialized
INFO - 2024-12-13 03:14:10 --> Output Class Initialized
INFO - 2024-12-13 03:14:10 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:10 --> CSRF cookie sent
INFO - 2024-12-13 03:14:10 --> Input Class Initialized
INFO - 2024-12-13 03:14:10 --> Language Class Initialized
INFO - 2024-12-13 03:14:10 --> Loader Class Initialized
INFO - 2024-12-13 03:14:10 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:10 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:10 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:10 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:10 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:10 --> Controller Class Initialized
INFO - 2024-12-13 03:14:10 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:10 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:10 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:10 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:14:10 --> Query result: stdClass Object
(
    [view_count] => 164
)

INFO - 2024-12-13 03:14:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:14:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:14:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:14:10 --> Final output sent to browser
DEBUG - 2024-12-13 03:14:10 --> Total execution time: 0.0498
INFO - 2024-12-13 03:14:10 --> Config Class Initialized
INFO - 2024-12-13 03:14:10 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:10 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:10 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:10 --> URI Class Initialized
INFO - 2024-12-13 03:14:10 --> Router Class Initialized
INFO - 2024-12-13 03:14:10 --> Output Class Initialized
INFO - 2024-12-13 03:14:10 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:10 --> CSRF cookie sent
INFO - 2024-12-13 03:14:10 --> Input Class Initialized
INFO - 2024-12-13 03:14:10 --> Language Class Initialized
ERROR - 2024-12-13 03:14:10 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:14:22 --> Config Class Initialized
INFO - 2024-12-13 03:14:22 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:22 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:22 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:22 --> URI Class Initialized
INFO - 2024-12-13 03:14:22 --> Router Class Initialized
INFO - 2024-12-13 03:14:22 --> Output Class Initialized
INFO - 2024-12-13 03:14:22 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:22 --> CSRF cookie sent
INFO - 2024-12-13 03:14:22 --> Input Class Initialized
INFO - 2024-12-13 03:14:22 --> Language Class Initialized
INFO - 2024-12-13 03:14:22 --> Loader Class Initialized
INFO - 2024-12-13 03:14:22 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:22 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:22 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:22 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:22 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:22 --> Controller Class Initialized
INFO - 2024-12-13 03:14:22 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:22 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:22 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:22 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:14:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:14:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-13 03:14:22 --> Final output sent to browser
DEBUG - 2024-12-13 03:14:22 --> Total execution time: 0.0476
INFO - 2024-12-13 03:14:56 --> Config Class Initialized
INFO - 2024-12-13 03:14:56 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:56 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:56 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:56 --> URI Class Initialized
INFO - 2024-12-13 03:14:56 --> Router Class Initialized
INFO - 2024-12-13 03:14:56 --> Output Class Initialized
INFO - 2024-12-13 03:14:56 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:56 --> CSRF cookie sent
INFO - 2024-12-13 03:14:56 --> CSRF token verified
INFO - 2024-12-13 03:14:56 --> Input Class Initialized
INFO - 2024-12-13 03:14:56 --> Language Class Initialized
INFO - 2024-12-13 03:14:56 --> Loader Class Initialized
INFO - 2024-12-13 03:14:56 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:56 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:56 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:56 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:56 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:56 --> Controller Class Initialized
INFO - 2024-12-13 03:14:56 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:56 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:56 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:56 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:56 --> Upload Class Initialized
INFO - 2024-12-13 03:14:57 --> Config Class Initialized
INFO - 2024-12-13 03:14:57 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:57 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:57 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:57 --> URI Class Initialized
INFO - 2024-12-13 03:14:57 --> Router Class Initialized
INFO - 2024-12-13 03:14:57 --> Output Class Initialized
INFO - 2024-12-13 03:14:57 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:57 --> CSRF cookie sent
INFO - 2024-12-13 03:14:57 --> Input Class Initialized
INFO - 2024-12-13 03:14:57 --> Language Class Initialized
INFO - 2024-12-13 03:14:57 --> Loader Class Initialized
INFO - 2024-12-13 03:14:57 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:57 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:57 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:57 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:57 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:57 --> Controller Class Initialized
INFO - 2024-12-13 03:14:57 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:57 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:57 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:57 --> Model "News_model" initialized
INFO - 2024-12-13 03:14:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:14:57 --> Query result: stdClass Object
(
    [view_count] => 165
)

INFO - 2024-12-13 03:14:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:14:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:14:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:14:57 --> Final output sent to browser
DEBUG - 2024-12-13 03:14:57 --> Total execution time: 0.0490
INFO - 2024-12-13 03:14:57 --> Config Class Initialized
INFO - 2024-12-13 03:14:57 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:57 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:57 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:57 --> URI Class Initialized
INFO - 2024-12-13 03:14:57 --> Router Class Initialized
INFO - 2024-12-13 03:14:57 --> Output Class Initialized
INFO - 2024-12-13 03:14:57 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:57 --> CSRF cookie sent
INFO - 2024-12-13 03:14:57 --> Input Class Initialized
INFO - 2024-12-13 03:14:57 --> Language Class Initialized
ERROR - 2024-12-13 03:14:57 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-13 03:14:59 --> Config Class Initialized
INFO - 2024-12-13 03:14:59 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:14:59 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:14:59 --> Utf8 Class Initialized
INFO - 2024-12-13 03:14:59 --> URI Class Initialized
INFO - 2024-12-13 03:14:59 --> Router Class Initialized
INFO - 2024-12-13 03:14:59 --> Output Class Initialized
INFO - 2024-12-13 03:14:59 --> Security Class Initialized
DEBUG - 2024-12-13 03:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:14:59 --> CSRF cookie sent
INFO - 2024-12-13 03:14:59 --> Input Class Initialized
INFO - 2024-12-13 03:14:59 --> Language Class Initialized
INFO - 2024-12-13 03:14:59 --> Loader Class Initialized
INFO - 2024-12-13 03:14:59 --> Helper loaded: url_helper
INFO - 2024-12-13 03:14:59 --> Helper loaded: form_helper
INFO - 2024-12-13 03:14:59 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:14:59 --> Form Validation Class Initialized
INFO - 2024-12-13 03:14:59 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:14:59 --> Controller Class Initialized
INFO - 2024-12-13 03:14:59 --> Model "Review_model" initialized
INFO - 2024-12-13 03:14:59 --> Model "Category_model" initialized
INFO - 2024-12-13 03:14:59 --> Model "User_model" initialized
INFO - 2024-12-13 03:14:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:14:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 03:14:59 --> Pagination Class Initialized
INFO - 2024-12-13 03:14:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 03:14:59 --> Final output sent to browser
DEBUG - 2024-12-13 03:14:59 --> Total execution time: 0.1565
INFO - 2024-12-13 03:15:01 --> Config Class Initialized
INFO - 2024-12-13 03:15:01 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:01 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:01 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:01 --> URI Class Initialized
INFO - 2024-12-13 03:15:01 --> Router Class Initialized
INFO - 2024-12-13 03:15:01 --> Output Class Initialized
INFO - 2024-12-13 03:15:01 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:01 --> CSRF cookie sent
INFO - 2024-12-13 03:15:01 --> Input Class Initialized
INFO - 2024-12-13 03:15:01 --> Language Class Initialized
INFO - 2024-12-13 03:15:01 --> Loader Class Initialized
INFO - 2024-12-13 03:15:01 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:01 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:01 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:01 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:01 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:01 --> Controller Class Initialized
INFO - 2024-12-13 03:15:01 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:01 --> Config Class Initialized
INFO - 2024-12-13 03:15:01 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:01 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:01 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:01 --> URI Class Initialized
INFO - 2024-12-13 03:15:01 --> Router Class Initialized
INFO - 2024-12-13 03:15:01 --> Output Class Initialized
INFO - 2024-12-13 03:15:01 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:01 --> CSRF cookie sent
INFO - 2024-12-13 03:15:01 --> Input Class Initialized
INFO - 2024-12-13 03:15:01 --> Language Class Initialized
INFO - 2024-12-13 03:15:01 --> Loader Class Initialized
INFO - 2024-12-13 03:15:01 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:01 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:01 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:01 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:01 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:01 --> Controller Class Initialized
INFO - 2024-12-13 03:15:01 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:15:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:15:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-13 03:15:01 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:01 --> Total execution time: 0.0430
INFO - 2024-12-13 03:15:06 --> Config Class Initialized
INFO - 2024-12-13 03:15:06 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:06 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:06 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:06 --> URI Class Initialized
INFO - 2024-12-13 03:15:06 --> Router Class Initialized
INFO - 2024-12-13 03:15:06 --> Output Class Initialized
INFO - 2024-12-13 03:15:06 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:06 --> CSRF cookie sent
INFO - 2024-12-13 03:15:06 --> CSRF token verified
INFO - 2024-12-13 03:15:06 --> Input Class Initialized
INFO - 2024-12-13 03:15:06 --> Language Class Initialized
INFO - 2024-12-13 03:15:06 --> Loader Class Initialized
INFO - 2024-12-13 03:15:06 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:06 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:06 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:06 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:06 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:06 --> Controller Class Initialized
INFO - 2024-12-13 03:15:06 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "News_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:06 --> Config Class Initialized
INFO - 2024-12-13 03:15:06 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:06 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:06 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:06 --> URI Class Initialized
INFO - 2024-12-13 03:15:06 --> Router Class Initialized
INFO - 2024-12-13 03:15:06 --> Output Class Initialized
INFO - 2024-12-13 03:15:06 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:06 --> CSRF cookie sent
INFO - 2024-12-13 03:15:06 --> Input Class Initialized
INFO - 2024-12-13 03:15:06 --> Language Class Initialized
INFO - 2024-12-13 03:15:06 --> Loader Class Initialized
INFO - 2024-12-13 03:15:06 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:06 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:06 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:06 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:06 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:06 --> Controller Class Initialized
INFO - 2024-12-13 03:15:06 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:15:06 --> Query result: stdClass Object
(
    [view_count] => 165
)

INFO - 2024-12-13 03:15:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 03:15:06 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:06 --> Total execution time: 0.0830
INFO - 2024-12-13 03:15:11 --> Config Class Initialized
INFO - 2024-12-13 03:15:11 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:11 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:11 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:11 --> URI Class Initialized
INFO - 2024-12-13 03:15:11 --> Router Class Initialized
INFO - 2024-12-13 03:15:11 --> Output Class Initialized
INFO - 2024-12-13 03:15:11 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:11 --> CSRF cookie sent
INFO - 2024-12-13 03:15:11 --> Input Class Initialized
INFO - 2024-12-13 03:15:11 --> Language Class Initialized
INFO - 2024-12-13 03:15:11 --> Loader Class Initialized
INFO - 2024-12-13 03:15:11 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:11 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:11 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:11 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:11 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:11 --> Controller Class Initialized
INFO - 2024-12-13 03:15:11 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:11 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:11 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:15:11 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:11 --> Total execution time: 0.0648
INFO - 2024-12-13 03:15:14 --> Config Class Initialized
INFO - 2024-12-13 03:15:14 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:14 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:14 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:14 --> URI Class Initialized
INFO - 2024-12-13 03:15:14 --> Router Class Initialized
INFO - 2024-12-13 03:15:14 --> Output Class Initialized
INFO - 2024-12-13 03:15:14 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:14 --> CSRF cookie sent
INFO - 2024-12-13 03:15:14 --> Input Class Initialized
INFO - 2024-12-13 03:15:14 --> Language Class Initialized
INFO - 2024-12-13 03:15:14 --> Loader Class Initialized
INFO - 2024-12-13 03:15:14 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:14 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:14 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:14 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:14 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:14 --> Controller Class Initialized
INFO - 2024-12-13 03:15:14 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:14 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:14 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:15:14 --> Query result: stdClass Object
(
    [view_count] => 165
)

INFO - 2024-12-13 03:15:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 03:15:14 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:14 --> Total execution time: 0.0426
INFO - 2024-12-13 03:15:27 --> Config Class Initialized
INFO - 2024-12-13 03:15:27 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:27 --> URI Class Initialized
INFO - 2024-12-13 03:15:27 --> Router Class Initialized
INFO - 2024-12-13 03:15:27 --> Output Class Initialized
INFO - 2024-12-13 03:15:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:27 --> CSRF cookie sent
INFO - 2024-12-13 03:15:27 --> Input Class Initialized
INFO - 2024-12-13 03:15:27 --> Language Class Initialized
INFO - 2024-12-13 03:15:27 --> Loader Class Initialized
INFO - 2024-12-13 03:15:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:27 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:27 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:27 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:27 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:27 --> Controller Class Initialized
INFO - 2024-12-13 03:15:27 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:27 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:27 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 03:15:27 --> Pagination Class Initialized
INFO - 2024-12-13 03:15:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 03:15:27 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:27 --> Total execution time: 0.0742
INFO - 2024-12-13 03:15:33 --> Config Class Initialized
INFO - 2024-12-13 03:15:33 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:33 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:33 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:33 --> URI Class Initialized
INFO - 2024-12-13 03:15:33 --> Router Class Initialized
INFO - 2024-12-13 03:15:33 --> Output Class Initialized
INFO - 2024-12-13 03:15:33 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:33 --> CSRF cookie sent
INFO - 2024-12-13 03:15:33 --> Input Class Initialized
INFO - 2024-12-13 03:15:33 --> Language Class Initialized
INFO - 2024-12-13 03:15:33 --> Loader Class Initialized
INFO - 2024-12-13 03:15:33 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:33 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:33 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:33 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:33 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:33 --> Controller Class Initialized
INFO - 2024-12-13 03:15:33 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:33 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:33 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:15:33 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:33 --> Total execution time: 0.0423
INFO - 2024-12-13 03:15:35 --> Config Class Initialized
INFO - 2024-12-13 03:15:35 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:35 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:35 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:35 --> URI Class Initialized
INFO - 2024-12-13 03:15:35 --> Router Class Initialized
INFO - 2024-12-13 03:15:35 --> Output Class Initialized
INFO - 2024-12-13 03:15:35 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:35 --> CSRF cookie sent
INFO - 2024-12-13 03:15:35 --> Input Class Initialized
INFO - 2024-12-13 03:15:35 --> Language Class Initialized
INFO - 2024-12-13 03:15:35 --> Loader Class Initialized
INFO - 2024-12-13 03:15:35 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:35 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:35 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:35 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:35 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:35 --> Controller Class Initialized
INFO - 2024-12-13 03:15:35 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:35 --> Config Class Initialized
INFO - 2024-12-13 03:15:35 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:35 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:35 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:35 --> URI Class Initialized
INFO - 2024-12-13 03:15:35 --> Router Class Initialized
INFO - 2024-12-13 03:15:35 --> Output Class Initialized
INFO - 2024-12-13 03:15:35 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:35 --> CSRF cookie sent
INFO - 2024-12-13 03:15:35 --> Input Class Initialized
INFO - 2024-12-13 03:15:35 --> Language Class Initialized
INFO - 2024-12-13 03:15:35 --> Loader Class Initialized
INFO - 2024-12-13 03:15:35 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:35 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:35 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:35 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:35 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:35 --> Controller Class Initialized
INFO - 2024-12-13 03:15:35 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:15:35 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:35 --> Total execution time: 0.0389
INFO - 2024-12-13 03:15:37 --> Config Class Initialized
INFO - 2024-12-13 03:15:37 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:37 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:37 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:37 --> URI Class Initialized
INFO - 2024-12-13 03:15:37 --> Router Class Initialized
INFO - 2024-12-13 03:15:37 --> Output Class Initialized
INFO - 2024-12-13 03:15:37 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:37 --> CSRF cookie sent
INFO - 2024-12-13 03:15:37 --> Input Class Initialized
INFO - 2024-12-13 03:15:37 --> Language Class Initialized
INFO - 2024-12-13 03:15:37 --> Loader Class Initialized
INFO - 2024-12-13 03:15:37 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:37 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:37 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:37 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:37 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:37 --> Controller Class Initialized
INFO - 2024-12-13 03:15:37 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:37 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:37 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:15:37 --> Query result: stdClass Object
(
    [view_count] => 165
)

INFO - 2024-12-13 03:15:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 03:15:37 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:37 --> Total execution time: 0.0450
INFO - 2024-12-13 03:15:38 --> Config Class Initialized
INFO - 2024-12-13 03:15:38 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:38 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:38 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:38 --> URI Class Initialized
INFO - 2024-12-13 03:15:38 --> Router Class Initialized
INFO - 2024-12-13 03:15:38 --> Output Class Initialized
INFO - 2024-12-13 03:15:38 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:38 --> CSRF cookie sent
INFO - 2024-12-13 03:15:38 --> Input Class Initialized
INFO - 2024-12-13 03:15:38 --> Language Class Initialized
INFO - 2024-12-13 03:15:38 --> Loader Class Initialized
INFO - 2024-12-13 03:15:38 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:38 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:38 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:38 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:38 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:38 --> Controller Class Initialized
INFO - 2024-12-13 03:15:38 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:38 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:38 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:38 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:15:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 03:15:38 --> Pagination Class Initialized
INFO - 2024-12-13 03:15:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 03:15:38 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:38 --> Total execution time: 0.0615
INFO - 2024-12-13 03:15:47 --> Config Class Initialized
INFO - 2024-12-13 03:15:47 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:47 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:47 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:47 --> URI Class Initialized
INFO - 2024-12-13 03:15:47 --> Router Class Initialized
INFO - 2024-12-13 03:15:47 --> Output Class Initialized
INFO - 2024-12-13 03:15:47 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:47 --> CSRF cookie sent
INFO - 2024-12-13 03:15:47 --> Input Class Initialized
INFO - 2024-12-13 03:15:47 --> Language Class Initialized
INFO - 2024-12-13 03:15:47 --> Loader Class Initialized
INFO - 2024-12-13 03:15:47 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:47 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:47 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:47 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:47 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:47 --> Controller Class Initialized
INFO - 2024-12-13 03:15:47 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:47 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:47 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:47 --> Model "News_model" initialized
INFO - 2024-12-13 03:15:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:15:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:15:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:15:47 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:47 --> Total execution time: 0.0500
INFO - 2024-12-13 03:15:54 --> Config Class Initialized
INFO - 2024-12-13 03:15:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:15:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:15:54 --> Utf8 Class Initialized
INFO - 2024-12-13 03:15:54 --> URI Class Initialized
INFO - 2024-12-13 03:15:54 --> Router Class Initialized
INFO - 2024-12-13 03:15:54 --> Output Class Initialized
INFO - 2024-12-13 03:15:54 --> Security Class Initialized
DEBUG - 2024-12-13 03:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:15:54 --> CSRF cookie sent
INFO - 2024-12-13 03:15:54 --> Input Class Initialized
INFO - 2024-12-13 03:15:54 --> Language Class Initialized
INFO - 2024-12-13 03:15:54 --> Loader Class Initialized
INFO - 2024-12-13 03:15:54 --> Helper loaded: url_helper
INFO - 2024-12-13 03:15:54 --> Helper loaded: form_helper
INFO - 2024-12-13 03:15:54 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:15:54 --> Form Validation Class Initialized
INFO - 2024-12-13 03:15:54 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:15:54 --> Controller Class Initialized
INFO - 2024-12-13 03:15:54 --> Model "User_model" initialized
INFO - 2024-12-13 03:15:54 --> Model "Category_model" initialized
INFO - 2024-12-13 03:15:54 --> Model "Review_model" initialized
INFO - 2024-12-13 03:15:54 --> Model "News_model" initialized
INFO - 2024-12-13 03:15:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:15:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:15:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:15:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:15:54 --> Final output sent to browser
DEBUG - 2024-12-13 03:15:54 --> Total execution time: 0.0472
INFO - 2024-12-13 03:16:00 --> Config Class Initialized
INFO - 2024-12-13 03:16:00 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:00 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:00 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:00 --> URI Class Initialized
INFO - 2024-12-13 03:16:00 --> Router Class Initialized
INFO - 2024-12-13 03:16:00 --> Output Class Initialized
INFO - 2024-12-13 03:16:00 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:00 --> CSRF cookie sent
INFO - 2024-12-13 03:16:00 --> Input Class Initialized
INFO - 2024-12-13 03:16:00 --> Language Class Initialized
INFO - 2024-12-13 03:16:00 --> Loader Class Initialized
INFO - 2024-12-13 03:16:00 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:00 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:00 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:00 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:00 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:00 --> Controller Class Initialized
INFO - 2024-12-13 03:16:00 --> Model "User_model" initialized
INFO - 2024-12-13 03:16:00 --> Model "Category_model" initialized
INFO - 2024-12-13 03:16:00 --> Model "Review_model" initialized
INFO - 2024-12-13 03:16:00 --> Model "News_model" initialized
INFO - 2024-12-13 03:16:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-13 03:16:00 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:00 --> Total execution time: 0.1048
INFO - 2024-12-13 03:16:20 --> Config Class Initialized
INFO - 2024-12-13 03:16:20 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:20 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:20 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:20 --> URI Class Initialized
INFO - 2024-12-13 03:16:20 --> Router Class Initialized
INFO - 2024-12-13 03:16:20 --> Output Class Initialized
INFO - 2024-12-13 03:16:20 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:20 --> CSRF cookie sent
INFO - 2024-12-13 03:16:20 --> Input Class Initialized
INFO - 2024-12-13 03:16:20 --> Language Class Initialized
INFO - 2024-12-13 03:16:20 --> Loader Class Initialized
INFO - 2024-12-13 03:16:20 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:20 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:20 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:21 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:21 --> Controller Class Initialized
INFO - 2024-12-13 03:16:21 --> Model "User_model" initialized
INFO - 2024-12-13 03:16:21 --> Model "Category_model" initialized
INFO - 2024-12-13 03:16:21 --> Model "Review_model" initialized
INFO - 2024-12-13 03:16:21 --> Model "News_model" initialized
INFO - 2024-12-13 03:16:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/lihat_semua.php
INFO - 2024-12-13 03:16:21 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:21 --> Total execution time: 0.6538
INFO - 2024-12-13 03:16:25 --> Config Class Initialized
INFO - 2024-12-13 03:16:25 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:25 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:25 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:25 --> URI Class Initialized
INFO - 2024-12-13 03:16:25 --> Router Class Initialized
INFO - 2024-12-13 03:16:25 --> Output Class Initialized
INFO - 2024-12-13 03:16:25 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:25 --> CSRF cookie sent
INFO - 2024-12-13 03:16:25 --> Input Class Initialized
INFO - 2024-12-13 03:16:25 --> Language Class Initialized
INFO - 2024-12-13 03:16:25 --> Loader Class Initialized
INFO - 2024-12-13 03:16:25 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:25 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:25 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:25 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:25 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:25 --> Controller Class Initialized
INFO - 2024-12-13 03:16:25 --> Model "User_model" initialized
INFO - 2024-12-13 03:16:25 --> Model "Category_model" initialized
INFO - 2024-12-13 03:16:25 --> Model "Review_model" initialized
INFO - 2024-12-13 03:16:25 --> Model "News_model" initialized
INFO - 2024-12-13 03:16:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-13 03:16:25 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:25 --> Total execution time: 0.0542
INFO - 2024-12-13 03:16:31 --> Config Class Initialized
INFO - 2024-12-13 03:16:31 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:31 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:31 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:31 --> URI Class Initialized
INFO - 2024-12-13 03:16:31 --> Router Class Initialized
INFO - 2024-12-13 03:16:31 --> Output Class Initialized
INFO - 2024-12-13 03:16:31 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:31 --> CSRF cookie sent
INFO - 2024-12-13 03:16:31 --> Input Class Initialized
INFO - 2024-12-13 03:16:31 --> Language Class Initialized
INFO - 2024-12-13 03:16:31 --> Loader Class Initialized
INFO - 2024-12-13 03:16:31 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:31 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:31 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:31 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:31 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:31 --> Controller Class Initialized
INFO - 2024-12-13 03:16:31 --> Model "Review_model" initialized
INFO - 2024-12-13 03:16:31 --> Model "Category_model" initialized
INFO - 2024-12-13 03:16:31 --> Model "User_model" initialized
INFO - 2024-12-13 03:16:31 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:16:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:31 --> Model "Contact_model" initialized
INFO - 2024-12-13 03:16:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-13 03:16:31 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:31 --> Total execution time: 0.1416
INFO - 2024-12-13 03:16:43 --> Config Class Initialized
INFO - 2024-12-13 03:16:43 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:43 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:43 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:43 --> URI Class Initialized
INFO - 2024-12-13 03:16:43 --> Router Class Initialized
INFO - 2024-12-13 03:16:43 --> Output Class Initialized
INFO - 2024-12-13 03:16:43 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:43 --> CSRF cookie sent
INFO - 2024-12-13 03:16:43 --> Input Class Initialized
INFO - 2024-12-13 03:16:43 --> Language Class Initialized
INFO - 2024-12-13 03:16:43 --> Loader Class Initialized
INFO - 2024-12-13 03:16:43 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:43 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:43 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:43 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:43 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:43 --> Controller Class Initialized
INFO - 2024-12-13 03:16:43 --> Model "User_model" initialized
INFO - 2024-12-13 03:16:43 --> Model "Category_model" initialized
INFO - 2024-12-13 03:16:43 --> Model "Review_model" initialized
INFO - 2024-12-13 03:16:43 --> Model "News_model" initialized
INFO - 2024-12-13 03:16:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-13 03:16:43 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:43 --> Total execution time: 0.2434
INFO - 2024-12-13 03:16:47 --> Config Class Initialized
INFO - 2024-12-13 03:16:47 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:47 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:47 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:47 --> URI Class Initialized
INFO - 2024-12-13 03:16:47 --> Router Class Initialized
INFO - 2024-12-13 03:16:47 --> Output Class Initialized
INFO - 2024-12-13 03:16:47 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:47 --> CSRF cookie sent
INFO - 2024-12-13 03:16:47 --> Input Class Initialized
INFO - 2024-12-13 03:16:47 --> Language Class Initialized
INFO - 2024-12-13 03:16:47 --> Loader Class Initialized
INFO - 2024-12-13 03:16:47 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:47 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:47 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:47 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:47 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:47 --> Controller Class Initialized
INFO - 2024-12-13 03:16:47 --> Model "User_model" initialized
INFO - 2024-12-13 03:16:47 --> Model "Category_model" initialized
INFO - 2024-12-13 03:16:47 --> Model "Review_model" initialized
INFO - 2024-12-13 03:16:47 --> Model "News_model" initialized
INFO - 2024-12-13 03:16:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-13 03:16:47 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:47 --> Total execution time: 0.0551
INFO - 2024-12-13 03:16:51 --> Config Class Initialized
INFO - 2024-12-13 03:16:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:51 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:51 --> URI Class Initialized
INFO - 2024-12-13 03:16:51 --> Router Class Initialized
INFO - 2024-12-13 03:16:51 --> Output Class Initialized
INFO - 2024-12-13 03:16:51 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:51 --> CSRF cookie sent
INFO - 2024-12-13 03:16:51 --> Input Class Initialized
INFO - 2024-12-13 03:16:51 --> Language Class Initialized
INFO - 2024-12-13 03:16:51 --> Loader Class Initialized
INFO - 2024-12-13 03:16:51 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:51 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:51 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:51 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:51 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:51 --> Controller Class Initialized
INFO - 2024-12-13 03:16:51 --> Model "User_model" initialized
DEBUG - 2024-12-13 03:16:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:16:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-13 03:16:51 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:51 --> Total execution time: 0.0496
INFO - 2024-12-13 03:16:55 --> Config Class Initialized
INFO - 2024-12-13 03:16:55 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:16:55 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:16:55 --> Utf8 Class Initialized
INFO - 2024-12-13 03:16:55 --> URI Class Initialized
INFO - 2024-12-13 03:16:55 --> Router Class Initialized
INFO - 2024-12-13 03:16:55 --> Output Class Initialized
INFO - 2024-12-13 03:16:55 --> Security Class Initialized
DEBUG - 2024-12-13 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:16:55 --> CSRF cookie sent
INFO - 2024-12-13 03:16:55 --> Input Class Initialized
INFO - 2024-12-13 03:16:55 --> Language Class Initialized
INFO - 2024-12-13 03:16:55 --> Loader Class Initialized
INFO - 2024-12-13 03:16:55 --> Helper loaded: url_helper
INFO - 2024-12-13 03:16:55 --> Helper loaded: form_helper
INFO - 2024-12-13 03:16:55 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:16:55 --> Form Validation Class Initialized
INFO - 2024-12-13 03:16:55 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:16:55 --> Controller Class Initialized
INFO - 2024-12-13 03:16:55 --> Model "User_model" initialized
DEBUG - 2024-12-13 03:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:16:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:16:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:16:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:16:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-13 03:16:55 --> Final output sent to browser
DEBUG - 2024-12-13 03:16:55 --> Total execution time: 0.0623
INFO - 2024-12-13 03:17:08 --> Config Class Initialized
INFO - 2024-12-13 03:17:08 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:08 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:08 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:08 --> URI Class Initialized
INFO - 2024-12-13 03:17:08 --> Router Class Initialized
INFO - 2024-12-13 03:17:08 --> Output Class Initialized
INFO - 2024-12-13 03:17:08 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:08 --> CSRF cookie sent
INFO - 2024-12-13 03:17:08 --> CSRF token verified
INFO - 2024-12-13 03:17:08 --> Input Class Initialized
INFO - 2024-12-13 03:17:08 --> Language Class Initialized
INFO - 2024-12-13 03:17:08 --> Loader Class Initialized
INFO - 2024-12-13 03:17:08 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:08 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:08 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:08 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:08 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:08 --> Controller Class Initialized
INFO - 2024-12-13 03:17:08 --> Model "User_model" initialized
DEBUG - 2024-12-13 03:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:17:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:08 --> User data with ID 2 successfully updated.
INFO - 2024-12-13 03:17:08 --> Config Class Initialized
INFO - 2024-12-13 03:17:08 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:08 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:08 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:08 --> URI Class Initialized
INFO - 2024-12-13 03:17:08 --> Router Class Initialized
INFO - 2024-12-13 03:17:08 --> Output Class Initialized
INFO - 2024-12-13 03:17:08 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:08 --> CSRF cookie sent
INFO - 2024-12-13 03:17:08 --> Input Class Initialized
INFO - 2024-12-13 03:17:08 --> Language Class Initialized
INFO - 2024-12-13 03:17:08 --> Loader Class Initialized
INFO - 2024-12-13 03:17:08 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:08 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:08 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:08 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:08 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:08 --> Controller Class Initialized
INFO - 2024-12-13 03:17:08 --> Model "User_model" initialized
DEBUG - 2024-12-13 03:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:17:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:17:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:17:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-13 03:17:08 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:08 --> Total execution time: 0.0606
INFO - 2024-12-13 03:17:11 --> Config Class Initialized
INFO - 2024-12-13 03:17:11 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:11 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:11 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:11 --> URI Class Initialized
INFO - 2024-12-13 03:17:11 --> Router Class Initialized
INFO - 2024-12-13 03:17:11 --> Output Class Initialized
INFO - 2024-12-13 03:17:11 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:11 --> CSRF cookie sent
INFO - 2024-12-13 03:17:11 --> Input Class Initialized
INFO - 2024-12-13 03:17:11 --> Language Class Initialized
INFO - 2024-12-13 03:17:11 --> Loader Class Initialized
INFO - 2024-12-13 03:17:11 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:11 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:11 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:11 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:11 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:11 --> Controller Class Initialized
INFO - 2024-12-13 03:17:11 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:11 --> Config Class Initialized
INFO - 2024-12-13 03:17:11 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:11 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:11 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:11 --> URI Class Initialized
INFO - 2024-12-13 03:17:11 --> Router Class Initialized
INFO - 2024-12-13 03:17:11 --> Output Class Initialized
INFO - 2024-12-13 03:17:11 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:11 --> CSRF cookie sent
INFO - 2024-12-13 03:17:11 --> Input Class Initialized
INFO - 2024-12-13 03:17:11 --> Language Class Initialized
INFO - 2024-12-13 03:17:11 --> Loader Class Initialized
INFO - 2024-12-13 03:17:11 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:11 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:11 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:11 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:11 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:11 --> Controller Class Initialized
INFO - 2024-12-13 03:17:11 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:17:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:17:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:17:11 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:11 --> Total execution time: 0.0545
INFO - 2024-12-13 03:17:20 --> Config Class Initialized
INFO - 2024-12-13 03:17:20 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:20 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:20 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:20 --> URI Class Initialized
INFO - 2024-12-13 03:17:20 --> Router Class Initialized
INFO - 2024-12-13 03:17:20 --> Output Class Initialized
INFO - 2024-12-13 03:17:20 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:20 --> CSRF cookie sent
INFO - 2024-12-13 03:17:20 --> CSRF token verified
INFO - 2024-12-13 03:17:20 --> Input Class Initialized
INFO - 2024-12-13 03:17:20 --> Language Class Initialized
INFO - 2024-12-13 03:17:20 --> Loader Class Initialized
INFO - 2024-12-13 03:17:20 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:20 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:20 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:20 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:20 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:20 --> Controller Class Initialized
INFO - 2024-12-13 03:17:20 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:20 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:20 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:20 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:17:20 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:20 --> Total execution time: 0.1306
INFO - 2024-12-13 03:17:29 --> Config Class Initialized
INFO - 2024-12-13 03:17:29 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:29 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:29 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:29 --> URI Class Initialized
INFO - 2024-12-13 03:17:29 --> Router Class Initialized
INFO - 2024-12-13 03:17:29 --> Output Class Initialized
INFO - 2024-12-13 03:17:29 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:29 --> CSRF cookie sent
INFO - 2024-12-13 03:17:29 --> CSRF token verified
INFO - 2024-12-13 03:17:29 --> Input Class Initialized
INFO - 2024-12-13 03:17:29 --> Language Class Initialized
INFO - 2024-12-13 03:17:29 --> Loader Class Initialized
INFO - 2024-12-13 03:17:29 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:29 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:29 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:29 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:29 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:29 --> Controller Class Initialized
INFO - 2024-12-13 03:17:29 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:29 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:29 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:29 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:17:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:17:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:17:29 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:29 --> Total execution time: 0.1167
INFO - 2024-12-13 03:17:40 --> Config Class Initialized
INFO - 2024-12-13 03:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:40 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:40 --> URI Class Initialized
INFO - 2024-12-13 03:17:40 --> Router Class Initialized
INFO - 2024-12-13 03:17:40 --> Output Class Initialized
INFO - 2024-12-13 03:17:40 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:40 --> CSRF cookie sent
INFO - 2024-12-13 03:17:40 --> CSRF token verified
INFO - 2024-12-13 03:17:40 --> Input Class Initialized
INFO - 2024-12-13 03:17:40 --> Language Class Initialized
INFO - 2024-12-13 03:17:40 --> Loader Class Initialized
INFO - 2024-12-13 03:17:40 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:40 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:40 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:40 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:40 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:40 --> Controller Class Initialized
INFO - 2024-12-13 03:17:40 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:40 --> Config Class Initialized
INFO - 2024-12-13 03:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:40 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:40 --> URI Class Initialized
INFO - 2024-12-13 03:17:40 --> Router Class Initialized
INFO - 2024-12-13 03:17:40 --> Output Class Initialized
INFO - 2024-12-13 03:17:40 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:40 --> CSRF cookie sent
INFO - 2024-12-13 03:17:40 --> Input Class Initialized
INFO - 2024-12-13 03:17:40 --> Language Class Initialized
INFO - 2024-12-13 03:17:40 --> Loader Class Initialized
INFO - 2024-12-13 03:17:40 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:40 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:40 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:40 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:40 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:40 --> Controller Class Initialized
INFO - 2024-12-13 03:17:40 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:17:40 --> Query result: stdClass Object
(
    [view_count] => 166
)

INFO - 2024-12-13 03:17:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:17:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:17:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:17:40 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:40 --> Total execution time: 0.2895
INFO - 2024-12-13 03:17:41 --> Config Class Initialized
INFO - 2024-12-13 03:17:41 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:41 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:41 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:41 --> URI Class Initialized
INFO - 2024-12-13 03:17:41 --> Router Class Initialized
INFO - 2024-12-13 03:17:41 --> Output Class Initialized
INFO - 2024-12-13 03:17:41 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:41 --> CSRF cookie sent
INFO - 2024-12-13 03:17:41 --> Input Class Initialized
INFO - 2024-12-13 03:17:41 --> Language Class Initialized
ERROR - 2024-12-13 03:17:41 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:17:51 --> Config Class Initialized
INFO - 2024-12-13 03:17:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:51 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:51 --> URI Class Initialized
INFO - 2024-12-13 03:17:51 --> Router Class Initialized
INFO - 2024-12-13 03:17:51 --> Output Class Initialized
INFO - 2024-12-13 03:17:51 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:51 --> CSRF cookie sent
INFO - 2024-12-13 03:17:51 --> Input Class Initialized
INFO - 2024-12-13 03:17:51 --> Language Class Initialized
INFO - 2024-12-13 03:17:51 --> Loader Class Initialized
INFO - 2024-12-13 03:17:51 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:51 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:51 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:51 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:51 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:51 --> Controller Class Initialized
INFO - 2024-12-13 03:17:51 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:51 --> Config Class Initialized
INFO - 2024-12-13 03:17:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:51 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:51 --> URI Class Initialized
INFO - 2024-12-13 03:17:51 --> Router Class Initialized
INFO - 2024-12-13 03:17:51 --> Output Class Initialized
INFO - 2024-12-13 03:17:51 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:51 --> CSRF cookie sent
INFO - 2024-12-13 03:17:51 --> Input Class Initialized
INFO - 2024-12-13 03:17:51 --> Language Class Initialized
INFO - 2024-12-13 03:17:51 --> Loader Class Initialized
INFO - 2024-12-13 03:17:51 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:51 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:51 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:51 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:51 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:51 --> Controller Class Initialized
INFO - 2024-12-13 03:17:51 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:17:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:17:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:17:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-13 03:17:51 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:51 --> Total execution time: 0.0583
INFO - 2024-12-13 03:17:55 --> Config Class Initialized
INFO - 2024-12-13 03:17:55 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:55 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:55 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:55 --> URI Class Initialized
INFO - 2024-12-13 03:17:55 --> Router Class Initialized
INFO - 2024-12-13 03:17:55 --> Output Class Initialized
INFO - 2024-12-13 03:17:55 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:55 --> CSRF cookie sent
INFO - 2024-12-13 03:17:55 --> CSRF token verified
INFO - 2024-12-13 03:17:55 --> Input Class Initialized
INFO - 2024-12-13 03:17:55 --> Language Class Initialized
INFO - 2024-12-13 03:17:55 --> Loader Class Initialized
INFO - 2024-12-13 03:17:55 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:55 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:55 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:55 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:55 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:55 --> Controller Class Initialized
INFO - 2024-12-13 03:17:55 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "News_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:17:55 --> Config Class Initialized
INFO - 2024-12-13 03:17:55 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:17:55 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:17:55 --> Utf8 Class Initialized
INFO - 2024-12-13 03:17:55 --> URI Class Initialized
INFO - 2024-12-13 03:17:55 --> Router Class Initialized
INFO - 2024-12-13 03:17:55 --> Output Class Initialized
INFO - 2024-12-13 03:17:55 --> Security Class Initialized
DEBUG - 2024-12-13 03:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:17:55 --> CSRF cookie sent
INFO - 2024-12-13 03:17:55 --> Input Class Initialized
INFO - 2024-12-13 03:17:55 --> Language Class Initialized
INFO - 2024-12-13 03:17:55 --> Loader Class Initialized
INFO - 2024-12-13 03:17:55 --> Helper loaded: url_helper
INFO - 2024-12-13 03:17:55 --> Helper loaded: form_helper
INFO - 2024-12-13 03:17:55 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:17:55 --> Form Validation Class Initialized
INFO - 2024-12-13 03:17:55 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:17:55 --> Controller Class Initialized
INFO - 2024-12-13 03:17:55 --> Model "Review_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "Category_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "User_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:17:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:17:55 --> Query result: stdClass Object
(
    [view_count] => 166
)

INFO - 2024-12-13 03:17:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 03:17:55 --> Final output sent to browser
DEBUG - 2024-12-13 03:17:55 --> Total execution time: 0.0516
INFO - 2024-12-13 03:18:14 --> Config Class Initialized
INFO - 2024-12-13 03:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:14 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:14 --> URI Class Initialized
INFO - 2024-12-13 03:18:14 --> Router Class Initialized
INFO - 2024-12-13 03:18:14 --> Output Class Initialized
INFO - 2024-12-13 03:18:14 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:14 --> CSRF cookie sent
INFO - 2024-12-13 03:18:14 --> Input Class Initialized
INFO - 2024-12-13 03:18:14 --> Language Class Initialized
INFO - 2024-12-13 03:18:14 --> Loader Class Initialized
INFO - 2024-12-13 03:18:14 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:14 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:14 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:14 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:14 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:14 --> Controller Class Initialized
INFO - 2024-12-13 03:18:14 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:14 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:14 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:18:14 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:14 --> Total execution time: 0.0451
INFO - 2024-12-13 03:18:17 --> Config Class Initialized
INFO - 2024-12-13 03:18:17 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:17 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:17 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:17 --> URI Class Initialized
INFO - 2024-12-13 03:18:17 --> Router Class Initialized
INFO - 2024-12-13 03:18:17 --> Output Class Initialized
INFO - 2024-12-13 03:18:17 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:17 --> CSRF cookie sent
INFO - 2024-12-13 03:18:17 --> Input Class Initialized
INFO - 2024-12-13 03:18:17 --> Language Class Initialized
INFO - 2024-12-13 03:18:17 --> Loader Class Initialized
INFO - 2024-12-13 03:18:17 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:17 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:17 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:17 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:17 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:17 --> Controller Class Initialized
INFO - 2024-12-13 03:18:17 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:17 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:17 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kategori.php
INFO - 2024-12-13 03:18:17 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:17 --> Total execution time: 0.0470
INFO - 2024-12-13 03:18:21 --> Config Class Initialized
INFO - 2024-12-13 03:18:21 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:21 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:21 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:21 --> URI Class Initialized
INFO - 2024-12-13 03:18:21 --> Router Class Initialized
INFO - 2024-12-13 03:18:21 --> Output Class Initialized
INFO - 2024-12-13 03:18:21 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:21 --> CSRF cookie sent
INFO - 2024-12-13 03:18:21 --> Input Class Initialized
INFO - 2024-12-13 03:18:21 --> Language Class Initialized
INFO - 2024-12-13 03:18:21 --> Loader Class Initialized
INFO - 2024-12-13 03:18:21 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:21 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:21 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:21 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:21 --> Controller Class Initialized
INFO - 2024-12-13 03:18:21 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:21 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:21 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:18:21 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:21 --> Total execution time: 0.0404
INFO - 2024-12-13 03:18:23 --> Config Class Initialized
INFO - 2024-12-13 03:18:23 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:23 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:23 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:23 --> URI Class Initialized
INFO - 2024-12-13 03:18:23 --> Router Class Initialized
INFO - 2024-12-13 03:18:23 --> Output Class Initialized
INFO - 2024-12-13 03:18:23 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:23 --> CSRF cookie sent
INFO - 2024-12-13 03:18:23 --> Input Class Initialized
INFO - 2024-12-13 03:18:23 --> Language Class Initialized
INFO - 2024-12-13 03:18:23 --> Loader Class Initialized
INFO - 2024-12-13 03:18:23 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:23 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:23 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:23 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:23 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:23 --> Controller Class Initialized
INFO - 2024-12-13 03:18:23 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:23 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:23 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:23 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-13 03:18:23 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:23 --> Total execution time: 0.0364
INFO - 2024-12-13 03:18:28 --> Config Class Initialized
INFO - 2024-12-13 03:18:28 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:28 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:28 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:28 --> URI Class Initialized
INFO - 2024-12-13 03:18:28 --> Router Class Initialized
INFO - 2024-12-13 03:18:28 --> Output Class Initialized
INFO - 2024-12-13 03:18:28 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:28 --> CSRF cookie sent
INFO - 2024-12-13 03:18:28 --> CSRF token verified
INFO - 2024-12-13 03:18:28 --> Input Class Initialized
INFO - 2024-12-13 03:18:28 --> Language Class Initialized
INFO - 2024-12-13 03:18:28 --> Loader Class Initialized
INFO - 2024-12-13 03:18:28 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:28 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:28 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:28 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:28 --> Controller Class Initialized
INFO - 2024-12-13 03:18:28 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:28 --> Config Class Initialized
INFO - 2024-12-13 03:18:28 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:28 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:28 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:28 --> URI Class Initialized
INFO - 2024-12-13 03:18:28 --> Router Class Initialized
INFO - 2024-12-13 03:18:28 --> Output Class Initialized
INFO - 2024-12-13 03:18:28 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:28 --> CSRF cookie sent
INFO - 2024-12-13 03:18:28 --> Input Class Initialized
INFO - 2024-12-13 03:18:28 --> Language Class Initialized
INFO - 2024-12-13 03:18:28 --> Loader Class Initialized
INFO - 2024-12-13 03:18:28 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:28 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:28 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:28 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:28 --> Controller Class Initialized
INFO - 2024-12-13 03:18:28 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:18:28 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:28 --> Total execution time: 0.0417
INFO - 2024-12-13 03:18:30 --> Config Class Initialized
INFO - 2024-12-13 03:18:30 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:30 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:30 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:30 --> URI Class Initialized
INFO - 2024-12-13 03:18:30 --> Router Class Initialized
INFO - 2024-12-13 03:18:30 --> Output Class Initialized
INFO - 2024-12-13 03:18:30 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:30 --> CSRF cookie sent
INFO - 2024-12-13 03:18:30 --> Input Class Initialized
INFO - 2024-12-13 03:18:30 --> Language Class Initialized
INFO - 2024-12-13 03:18:30 --> Loader Class Initialized
INFO - 2024-12-13 03:18:30 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:30 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:30 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:30 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:30 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:30 --> Controller Class Initialized
INFO - 2024-12-13 03:18:30 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:30 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:30 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:30 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kategori.php
INFO - 2024-12-13 03:18:30 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:30 --> Total execution time: 0.0516
INFO - 2024-12-13 03:18:34 --> Config Class Initialized
INFO - 2024-12-13 03:18:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:34 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:34 --> URI Class Initialized
INFO - 2024-12-13 03:18:34 --> Router Class Initialized
INFO - 2024-12-13 03:18:34 --> Output Class Initialized
INFO - 2024-12-13 03:18:34 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:34 --> CSRF cookie sent
INFO - 2024-12-13 03:18:34 --> CSRF token verified
INFO - 2024-12-13 03:18:34 --> Input Class Initialized
INFO - 2024-12-13 03:18:34 --> Language Class Initialized
INFO - 2024-12-13 03:18:34 --> Loader Class Initialized
INFO - 2024-12-13 03:18:34 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:34 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:34 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:34 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:34 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:34 --> Controller Class Initialized
INFO - 2024-12-13 03:18:34 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:34 --> Config Class Initialized
INFO - 2024-12-13 03:18:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:34 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:34 --> URI Class Initialized
INFO - 2024-12-13 03:18:34 --> Router Class Initialized
INFO - 2024-12-13 03:18:34 --> Output Class Initialized
INFO - 2024-12-13 03:18:34 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:34 --> CSRF cookie sent
INFO - 2024-12-13 03:18:34 --> Input Class Initialized
INFO - 2024-12-13 03:18:34 --> Language Class Initialized
INFO - 2024-12-13 03:18:34 --> Loader Class Initialized
INFO - 2024-12-13 03:18:34 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:34 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:34 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:34 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:34 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:34 --> Controller Class Initialized
INFO - 2024-12-13 03:18:34 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:18:34 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:34 --> Total execution time: 0.0367
INFO - 2024-12-13 03:18:36 --> Config Class Initialized
INFO - 2024-12-13 03:18:36 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:36 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:36 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:36 --> URI Class Initialized
INFO - 2024-12-13 03:18:36 --> Router Class Initialized
INFO - 2024-12-13 03:18:36 --> Output Class Initialized
INFO - 2024-12-13 03:18:36 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:36 --> CSRF cookie sent
INFO - 2024-12-13 03:18:36 --> Input Class Initialized
INFO - 2024-12-13 03:18:36 --> Language Class Initialized
INFO - 2024-12-13 03:18:36 --> Loader Class Initialized
INFO - 2024-12-13 03:18:36 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:36 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:36 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:36 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:36 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:36 --> Controller Class Initialized
INFO - 2024-12-13 03:18:36 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:36 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:36 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:36 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-13 03:18:36 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:36 --> Total execution time: 0.0437
INFO - 2024-12-13 03:18:42 --> Config Class Initialized
INFO - 2024-12-13 03:18:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:42 --> URI Class Initialized
INFO - 2024-12-13 03:18:42 --> Router Class Initialized
INFO - 2024-12-13 03:18:42 --> Output Class Initialized
INFO - 2024-12-13 03:18:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:42 --> CSRF cookie sent
INFO - 2024-12-13 03:18:42 --> Input Class Initialized
INFO - 2024-12-13 03:18:42 --> Language Class Initialized
INFO - 2024-12-13 03:18:42 --> Loader Class Initialized
INFO - 2024-12-13 03:18:42 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:42 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:42 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:42 --> Controller Class Initialized
INFO - 2024-12-13 03:18:42 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:42 --> User data with ID 16 successfully deleted.
INFO - 2024-12-13 03:18:42 --> Config Class Initialized
INFO - 2024-12-13 03:18:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:42 --> URI Class Initialized
INFO - 2024-12-13 03:18:42 --> Router Class Initialized
INFO - 2024-12-13 03:18:42 --> Output Class Initialized
INFO - 2024-12-13 03:18:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:42 --> CSRF cookie sent
INFO - 2024-12-13 03:18:42 --> Input Class Initialized
INFO - 2024-12-13 03:18:42 --> Language Class Initialized
INFO - 2024-12-13 03:18:42 --> Loader Class Initialized
INFO - 2024-12-13 03:18:42 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:42 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:42 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:42 --> Controller Class Initialized
INFO - 2024-12-13 03:18:42 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-13 03:18:42 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:42 --> Total execution time: 0.0365
INFO - 2024-12-13 03:18:45 --> Config Class Initialized
INFO - 2024-12-13 03:18:45 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:45 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:45 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:45 --> URI Class Initialized
INFO - 2024-12-13 03:18:45 --> Router Class Initialized
INFO - 2024-12-13 03:18:45 --> Output Class Initialized
INFO - 2024-12-13 03:18:45 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:45 --> CSRF cookie sent
INFO - 2024-12-13 03:18:45 --> Input Class Initialized
INFO - 2024-12-13 03:18:45 --> Language Class Initialized
INFO - 2024-12-13 03:18:45 --> Loader Class Initialized
INFO - 2024-12-13 03:18:45 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:45 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:45 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:45 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:45 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:45 --> Controller Class Initialized
INFO - 2024-12-13 03:18:45 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:45 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:45 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:45 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-13 03:18:45 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:45 --> Total execution time: 0.0523
INFO - 2024-12-13 03:18:46 --> Config Class Initialized
INFO - 2024-12-13 03:18:46 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:46 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:46 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:46 --> URI Class Initialized
INFO - 2024-12-13 03:18:46 --> Router Class Initialized
INFO - 2024-12-13 03:18:46 --> Output Class Initialized
INFO - 2024-12-13 03:18:46 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:46 --> CSRF cookie sent
INFO - 2024-12-13 03:18:46 --> Input Class Initialized
INFO - 2024-12-13 03:18:46 --> Language Class Initialized
INFO - 2024-12-13 03:18:46 --> Loader Class Initialized
INFO - 2024-12-13 03:18:46 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:46 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:46 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:46 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:46 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:46 --> Controller Class Initialized
INFO - 2024-12-13 03:18:46 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:46 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:46 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:46 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-13 03:18:46 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:46 --> Total execution time: 0.0424
INFO - 2024-12-13 03:18:48 --> Config Class Initialized
INFO - 2024-12-13 03:18:48 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:48 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:48 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:48 --> URI Class Initialized
INFO - 2024-12-13 03:18:48 --> Router Class Initialized
INFO - 2024-12-13 03:18:48 --> Output Class Initialized
INFO - 2024-12-13 03:18:48 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:48 --> CSRF cookie sent
INFO - 2024-12-13 03:18:48 --> Input Class Initialized
INFO - 2024-12-13 03:18:48 --> Language Class Initialized
INFO - 2024-12-13 03:18:48 --> Loader Class Initialized
INFO - 2024-12-13 03:18:48 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:48 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:48 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:48 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:48 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:48 --> Controller Class Initialized
INFO - 2024-12-13 03:18:48 --> Model "Review_model" initialized
INFO - 2024-12-13 03:18:48 --> Model "Category_model" initialized
INFO - 2024-12-13 03:18:48 --> Model "User_model" initialized
INFO - 2024-12-13 03:18:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:18:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:18:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:18:49 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:49 --> Total execution time: 0.0514
INFO - 2024-12-13 03:18:51 --> Config Class Initialized
INFO - 2024-12-13 03:18:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:18:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:18:51 --> Utf8 Class Initialized
INFO - 2024-12-13 03:18:51 --> URI Class Initialized
INFO - 2024-12-13 03:18:51 --> Router Class Initialized
INFO - 2024-12-13 03:18:51 --> Output Class Initialized
INFO - 2024-12-13 03:18:51 --> Security Class Initialized
DEBUG - 2024-12-13 03:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:18:51 --> CSRF cookie sent
INFO - 2024-12-13 03:18:51 --> Input Class Initialized
INFO - 2024-12-13 03:18:51 --> Language Class Initialized
INFO - 2024-12-13 03:18:51 --> Loader Class Initialized
INFO - 2024-12-13 03:18:51 --> Helper loaded: url_helper
INFO - 2024-12-13 03:18:51 --> Helper loaded: form_helper
INFO - 2024-12-13 03:18:51 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:18:51 --> Form Validation Class Initialized
INFO - 2024-12-13 03:18:51 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:18:51 --> Controller Class Initialized
INFO - 2024-12-13 03:18:51 --> Model "News_model" initialized
INFO - 2024-12-13 03:18:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-13 03:18:51 --> Final output sent to browser
DEBUG - 2024-12-13 03:18:51 --> Total execution time: 0.0377
INFO - 2024-12-13 03:19:05 --> Config Class Initialized
INFO - 2024-12-13 03:19:05 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:19:05 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:19:05 --> Utf8 Class Initialized
INFO - 2024-12-13 03:19:05 --> URI Class Initialized
INFO - 2024-12-13 03:19:05 --> Router Class Initialized
INFO - 2024-12-13 03:19:05 --> Output Class Initialized
INFO - 2024-12-13 03:19:05 --> Security Class Initialized
DEBUG - 2024-12-13 03:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:19:05 --> CSRF cookie sent
INFO - 2024-12-13 03:19:05 --> Input Class Initialized
INFO - 2024-12-13 03:19:05 --> Language Class Initialized
INFO - 2024-12-13 03:19:05 --> Loader Class Initialized
INFO - 2024-12-13 03:19:05 --> Helper loaded: url_helper
INFO - 2024-12-13 03:19:05 --> Helper loaded: form_helper
INFO - 2024-12-13 03:19:05 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:19:05 --> Form Validation Class Initialized
INFO - 2024-12-13 03:19:05 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:19:05 --> Controller Class Initialized
INFO - 2024-12-13 03:19:05 --> Model "News_model" initialized
INFO - 2024-12-13 03:19:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-13 03:19:05 --> Final output sent to browser
DEBUG - 2024-12-13 03:19:05 --> Total execution time: 0.0787
INFO - 2024-12-13 03:19:11 --> Config Class Initialized
INFO - 2024-12-13 03:19:11 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:19:11 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:19:11 --> Utf8 Class Initialized
INFO - 2024-12-13 03:19:11 --> URI Class Initialized
INFO - 2024-12-13 03:19:11 --> Router Class Initialized
INFO - 2024-12-13 03:19:11 --> Output Class Initialized
INFO - 2024-12-13 03:19:11 --> Security Class Initialized
DEBUG - 2024-12-13 03:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:19:11 --> CSRF cookie sent
INFO - 2024-12-13 03:19:11 --> Input Class Initialized
INFO - 2024-12-13 03:19:11 --> Language Class Initialized
INFO - 2024-12-13 03:19:11 --> Loader Class Initialized
INFO - 2024-12-13 03:19:11 --> Helper loaded: url_helper
INFO - 2024-12-13 03:19:11 --> Helper loaded: form_helper
INFO - 2024-12-13 03:19:11 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:19:11 --> Form Validation Class Initialized
INFO - 2024-12-13 03:19:11 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:19:11 --> Controller Class Initialized
INFO - 2024-12-13 03:19:11 --> Model "Review_model" initialized
INFO - 2024-12-13 03:19:11 --> Model "Category_model" initialized
INFO - 2024-12-13 03:19:11 --> Model "User_model" initialized
INFO - 2024-12-13 03:19:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:19:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:19:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-13 03:19:11 --> Final output sent to browser
DEBUG - 2024-12-13 03:19:11 --> Total execution time: 0.0485
INFO - 2024-12-13 03:19:40 --> Config Class Initialized
INFO - 2024-12-13 03:19:40 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:19:40 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:19:40 --> Utf8 Class Initialized
INFO - 2024-12-13 03:19:40 --> URI Class Initialized
INFO - 2024-12-13 03:19:40 --> Router Class Initialized
INFO - 2024-12-13 03:19:40 --> Output Class Initialized
INFO - 2024-12-13 03:19:40 --> Security Class Initialized
DEBUG - 2024-12-13 03:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:19:40 --> CSRF cookie sent
INFO - 2024-12-13 03:19:40 --> Input Class Initialized
INFO - 2024-12-13 03:19:40 --> Language Class Initialized
INFO - 2024-12-13 03:19:40 --> Loader Class Initialized
INFO - 2024-12-13 03:19:40 --> Helper loaded: url_helper
INFO - 2024-12-13 03:19:40 --> Helper loaded: form_helper
INFO - 2024-12-13 03:19:40 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:19:40 --> Form Validation Class Initialized
INFO - 2024-12-13 03:19:40 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:19:40 --> Controller Class Initialized
INFO - 2024-12-13 03:19:40 --> Model "Review_model" initialized
INFO - 2024-12-13 03:19:40 --> Model "Category_model" initialized
INFO - 2024-12-13 03:19:40 --> Model "User_model" initialized
INFO - 2024-12-13 03:19:40 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:19:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:19:40 --> Model "Contact_model" initialized
INFO - 2024-12-13 03:19:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-13 03:19:40 --> Final output sent to browser
DEBUG - 2024-12-13 03:19:40 --> Total execution time: 0.0464
INFO - 2024-12-13 03:19:42 --> Config Class Initialized
INFO - 2024-12-13 03:19:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:19:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:19:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:19:42 --> URI Class Initialized
INFO - 2024-12-13 03:19:42 --> Router Class Initialized
INFO - 2024-12-13 03:19:42 --> Output Class Initialized
INFO - 2024-12-13 03:19:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:19:42 --> CSRF cookie sent
INFO - 2024-12-13 03:19:42 --> Input Class Initialized
INFO - 2024-12-13 03:19:42 --> Language Class Initialized
INFO - 2024-12-13 03:19:42 --> Loader Class Initialized
INFO - 2024-12-13 03:19:42 --> Helper loaded: url_helper
INFO - 2024-12-13 03:19:42 --> Helper loaded: form_helper
INFO - 2024-12-13 03:19:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:19:42 --> Form Validation Class Initialized
INFO - 2024-12-13 03:19:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:19:42 --> Controller Class Initialized
INFO - 2024-12-13 03:19:42 --> Model "User_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "Category_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "Review_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "News_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:19:42 --> Config Class Initialized
INFO - 2024-12-13 03:19:42 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:19:42 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:19:42 --> Utf8 Class Initialized
INFO - 2024-12-13 03:19:42 --> URI Class Initialized
INFO - 2024-12-13 03:19:42 --> Router Class Initialized
INFO - 2024-12-13 03:19:42 --> Output Class Initialized
INFO - 2024-12-13 03:19:42 --> Security Class Initialized
DEBUG - 2024-12-13 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:19:42 --> CSRF cookie sent
INFO - 2024-12-13 03:19:42 --> Input Class Initialized
INFO - 2024-12-13 03:19:42 --> Language Class Initialized
INFO - 2024-12-13 03:19:42 --> Loader Class Initialized
INFO - 2024-12-13 03:19:42 --> Helper loaded: url_helper
INFO - 2024-12-13 03:19:42 --> Helper loaded: form_helper
INFO - 2024-12-13 03:19:42 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:19:42 --> Form Validation Class Initialized
INFO - 2024-12-13 03:19:42 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:19:42 --> Controller Class Initialized
INFO - 2024-12-13 03:19:42 --> Model "User_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "Category_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "Review_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "News_model" initialized
INFO - 2024-12-13 03:19:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:19:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:19:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:19:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:19:42 --> Final output sent to browser
DEBUG - 2024-12-13 03:19:42 --> Total execution time: 0.0396
INFO - 2024-12-13 03:39:18 --> Config Class Initialized
INFO - 2024-12-13 03:39:18 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:18 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:18 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:18 --> URI Class Initialized
INFO - 2024-12-13 03:39:18 --> Router Class Initialized
INFO - 2024-12-13 03:39:18 --> Output Class Initialized
INFO - 2024-12-13 03:39:18 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:18 --> CSRF cookie sent
INFO - 2024-12-13 03:39:18 --> Input Class Initialized
INFO - 2024-12-13 03:39:18 --> Language Class Initialized
INFO - 2024-12-13 03:39:18 --> Loader Class Initialized
INFO - 2024-12-13 03:39:18 --> Helper loaded: url_helper
INFO - 2024-12-13 03:39:18 --> Helper loaded: form_helper
INFO - 2024-12-13 03:39:18 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:39:19 --> Form Validation Class Initialized
INFO - 2024-12-13 03:39:19 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:39:19 --> Controller Class Initialized
INFO - 2024-12-13 03:39:19 --> Model "User_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "Category_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "Review_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "News_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:39:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:39:19 --> Query result: stdClass Object
(
    [view_count] => 167
)

INFO - 2024-12-13 03:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:39:19 --> Final output sent to browser
DEBUG - 2024-12-13 03:39:19 --> Total execution time: 1.0908
INFO - 2024-12-13 03:39:19 --> Config Class Initialized
INFO - 2024-12-13 03:39:19 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:19 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:19 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:19 --> URI Class Initialized
INFO - 2024-12-13 03:39:19 --> Router Class Initialized
INFO - 2024-12-13 03:39:19 --> Output Class Initialized
INFO - 2024-12-13 03:39:19 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:19 --> CSRF cookie sent
INFO - 2024-12-13 03:39:19 --> Input Class Initialized
INFO - 2024-12-13 03:39:19 --> Language Class Initialized
INFO - 2024-12-13 03:39:19 --> Loader Class Initialized
INFO - 2024-12-13 03:39:19 --> Helper loaded: url_helper
INFO - 2024-12-13 03:39:19 --> Helper loaded: form_helper
INFO - 2024-12-13 03:39:19 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:39:19 --> Form Validation Class Initialized
INFO - 2024-12-13 03:39:19 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:39:19 --> Controller Class Initialized
INFO - 2024-12-13 03:39:19 --> Model "User_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "Category_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "Review_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "News_model" initialized
INFO - 2024-12-13 03:39:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:39:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:39:19 --> Query result: stdClass Object
(
    [view_count] => 168
)

INFO - 2024-12-13 03:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:39:19 --> Final output sent to browser
DEBUG - 2024-12-13 03:39:19 --> Total execution time: 0.0738
INFO - 2024-12-13 03:39:19 --> Config Class Initialized
INFO - 2024-12-13 03:39:19 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:19 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:19 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:19 --> URI Class Initialized
INFO - 2024-12-13 03:39:19 --> Router Class Initialized
INFO - 2024-12-13 03:39:19 --> Output Class Initialized
INFO - 2024-12-13 03:39:19 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:19 --> CSRF cookie sent
INFO - 2024-12-13 03:39:19 --> Input Class Initialized
INFO - 2024-12-13 03:39:19 --> Language Class Initialized
ERROR - 2024-12-13 03:39:20 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:39:46 --> Config Class Initialized
INFO - 2024-12-13 03:39:46 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:46 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:46 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:46 --> URI Class Initialized
INFO - 2024-12-13 03:39:46 --> Router Class Initialized
INFO - 2024-12-13 03:39:46 --> Output Class Initialized
INFO - 2024-12-13 03:39:46 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:46 --> CSRF cookie sent
INFO - 2024-12-13 03:39:46 --> Input Class Initialized
INFO - 2024-12-13 03:39:46 --> Language Class Initialized
INFO - 2024-12-13 03:39:46 --> Loader Class Initialized
INFO - 2024-12-13 03:39:46 --> Helper loaded: url_helper
INFO - 2024-12-13 03:39:46 --> Helper loaded: form_helper
INFO - 2024-12-13 03:39:46 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:39:46 --> Form Validation Class Initialized
INFO - 2024-12-13 03:39:46 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:39:46 --> Controller Class Initialized
INFO - 2024-12-13 03:39:46 --> Model "User_model" initialized
INFO - 2024-12-13 03:39:46 --> Model "Category_model" initialized
INFO - 2024-12-13 03:39:46 --> Model "Review_model" initialized
INFO - 2024-12-13 03:39:46 --> Model "News_model" initialized
INFO - 2024-12-13 03:39:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:39:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:39:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:39:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-13 03:39:46 --> Final output sent to browser
DEBUG - 2024-12-13 03:39:46 --> Total execution time: 0.1033
INFO - 2024-12-13 03:39:49 --> Config Class Initialized
INFO - 2024-12-13 03:39:49 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:49 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:49 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:49 --> URI Class Initialized
INFO - 2024-12-13 03:39:49 --> Router Class Initialized
INFO - 2024-12-13 03:39:49 --> Output Class Initialized
INFO - 2024-12-13 03:39:49 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:49 --> CSRF cookie sent
INFO - 2024-12-13 03:39:49 --> Input Class Initialized
INFO - 2024-12-13 03:39:49 --> Language Class Initialized
INFO - 2024-12-13 03:39:49 --> Loader Class Initialized
INFO - 2024-12-13 03:39:49 --> Helper loaded: url_helper
INFO - 2024-12-13 03:39:49 --> Helper loaded: form_helper
INFO - 2024-12-13 03:39:49 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:39:49 --> Form Validation Class Initialized
INFO - 2024-12-13 03:39:49 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:39:49 --> Controller Class Initialized
INFO - 2024-12-13 03:39:49 --> Model "User_model" initialized
INFO - 2024-12-13 03:39:49 --> Model "Category_model" initialized
INFO - 2024-12-13 03:39:49 --> Model "Review_model" initialized
INFO - 2024-12-13 03:39:49 --> Model "News_model" initialized
INFO - 2024-12-13 03:39:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:39:49 --> Query result: stdClass Object
(
    [view_count] => 169
)

INFO - 2024-12-13 03:39:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:39:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:39:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:39:49 --> Final output sent to browser
DEBUG - 2024-12-13 03:39:49 --> Total execution time: 0.0836
INFO - 2024-12-13 03:39:49 --> Config Class Initialized
INFO - 2024-12-13 03:39:49 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:49 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:49 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:49 --> URI Class Initialized
INFO - 2024-12-13 03:39:49 --> Router Class Initialized
INFO - 2024-12-13 03:39:49 --> Output Class Initialized
INFO - 2024-12-13 03:39:49 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:49 --> CSRF cookie sent
INFO - 2024-12-13 03:39:49 --> Input Class Initialized
INFO - 2024-12-13 03:39:49 --> Language Class Initialized
ERROR - 2024-12-13 03:39:49 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:39:54 --> Config Class Initialized
INFO - 2024-12-13 03:39:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:54 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:54 --> URI Class Initialized
INFO - 2024-12-13 03:39:54 --> Router Class Initialized
INFO - 2024-12-13 03:39:54 --> Output Class Initialized
INFO - 2024-12-13 03:39:54 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:54 --> CSRF cookie sent
INFO - 2024-12-13 03:39:54 --> Input Class Initialized
INFO - 2024-12-13 03:39:54 --> Language Class Initialized
INFO - 2024-12-13 03:39:54 --> Loader Class Initialized
INFO - 2024-12-13 03:39:54 --> Helper loaded: url_helper
INFO - 2024-12-13 03:39:54 --> Helper loaded: form_helper
INFO - 2024-12-13 03:39:54 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:39:54 --> Form Validation Class Initialized
INFO - 2024-12-13 03:39:54 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:39:54 --> Controller Class Initialized
INFO - 2024-12-13 03:39:54 --> Model "User_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "Category_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "Review_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "News_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:39:54 --> Config Class Initialized
INFO - 2024-12-13 03:39:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:39:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:39:54 --> Utf8 Class Initialized
INFO - 2024-12-13 03:39:54 --> URI Class Initialized
INFO - 2024-12-13 03:39:54 --> Router Class Initialized
INFO - 2024-12-13 03:39:54 --> Output Class Initialized
INFO - 2024-12-13 03:39:54 --> Security Class Initialized
DEBUG - 2024-12-13 03:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:39:54 --> CSRF cookie sent
INFO - 2024-12-13 03:39:54 --> Input Class Initialized
INFO - 2024-12-13 03:39:54 --> Language Class Initialized
INFO - 2024-12-13 03:39:54 --> Loader Class Initialized
INFO - 2024-12-13 03:39:54 --> Helper loaded: url_helper
INFO - 2024-12-13 03:39:54 --> Helper loaded: form_helper
INFO - 2024-12-13 03:39:54 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:39:54 --> Form Validation Class Initialized
INFO - 2024-12-13 03:39:54 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:39:54 --> Controller Class Initialized
INFO - 2024-12-13 03:39:54 --> Model "User_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "Category_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "Review_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "News_model" initialized
INFO - 2024-12-13 03:39:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:39:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:39:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:39:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:39:54 --> Final output sent to browser
DEBUG - 2024-12-13 03:39:54 --> Total execution time: 0.0562
INFO - 2024-12-13 03:40:00 --> Config Class Initialized
INFO - 2024-12-13 03:40:00 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:00 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:00 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:00 --> URI Class Initialized
INFO - 2024-12-13 03:40:00 --> Router Class Initialized
INFO - 2024-12-13 03:40:00 --> Output Class Initialized
INFO - 2024-12-13 03:40:00 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:00 --> CSRF cookie sent
INFO - 2024-12-13 03:40:00 --> Input Class Initialized
INFO - 2024-12-13 03:40:00 --> Language Class Initialized
INFO - 2024-12-13 03:40:00 --> Loader Class Initialized
INFO - 2024-12-13 03:40:00 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:00 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:00 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:00 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:00 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:00 --> Controller Class Initialized
INFO - 2024-12-13 03:40:00 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:00 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:00 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:00 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:40:00 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:00 --> Total execution time: 0.0893
INFO - 2024-12-13 03:40:02 --> Config Class Initialized
INFO - 2024-12-13 03:40:02 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:02 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:02 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:02 --> URI Class Initialized
INFO - 2024-12-13 03:40:02 --> Router Class Initialized
INFO - 2024-12-13 03:40:02 --> Output Class Initialized
INFO - 2024-12-13 03:40:02 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:02 --> CSRF cookie sent
INFO - 2024-12-13 03:40:02 --> Input Class Initialized
INFO - 2024-12-13 03:40:02 --> Language Class Initialized
INFO - 2024-12-13 03:40:02 --> Loader Class Initialized
INFO - 2024-12-13 03:40:02 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:02 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:02 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:02 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:02 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:02 --> Controller Class Initialized
INFO - 2024-12-13 03:40:02 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:02 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:02 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:02 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-13 03:40:02 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:02 --> Total execution time: 0.0734
INFO - 2024-12-13 03:40:13 --> Config Class Initialized
INFO - 2024-12-13 03:40:13 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:13 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:13 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:13 --> URI Class Initialized
INFO - 2024-12-13 03:40:13 --> Router Class Initialized
INFO - 2024-12-13 03:40:13 --> Output Class Initialized
INFO - 2024-12-13 03:40:13 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:13 --> CSRF cookie sent
INFO - 2024-12-13 03:40:13 --> Input Class Initialized
INFO - 2024-12-13 03:40:13 --> Language Class Initialized
INFO - 2024-12-13 03:40:13 --> Loader Class Initialized
INFO - 2024-12-13 03:40:13 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:13 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:13 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:13 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:13 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:13 --> Controller Class Initialized
INFO - 2024-12-13 03:40:13 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:13 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:13 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:13 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:40:13 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:13 --> Total execution time: 0.1733
INFO - 2024-12-13 03:40:21 --> Config Class Initialized
INFO - 2024-12-13 03:40:21 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:21 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:21 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:21 --> URI Class Initialized
INFO - 2024-12-13 03:40:21 --> Router Class Initialized
INFO - 2024-12-13 03:40:21 --> Output Class Initialized
INFO - 2024-12-13 03:40:21 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:21 --> CSRF cookie sent
INFO - 2024-12-13 03:40:21 --> Input Class Initialized
INFO - 2024-12-13 03:40:21 --> Language Class Initialized
INFO - 2024-12-13 03:40:21 --> Loader Class Initialized
INFO - 2024-12-13 03:40:21 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:21 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:21 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:21 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:21 --> Controller Class Initialized
INFO - 2024-12-13 03:40:21 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:21 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:21 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:21 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:40:21 --> Query result: stdClass Object
(
    [view_count] => 170
)

INFO - 2024-12-13 03:40:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:40:21 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:21 --> Total execution time: 0.3680
INFO - 2024-12-13 03:40:26 --> Config Class Initialized
INFO - 2024-12-13 03:40:26 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:26 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:26 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:26 --> URI Class Initialized
INFO - 2024-12-13 03:40:26 --> Router Class Initialized
INFO - 2024-12-13 03:40:26 --> Output Class Initialized
INFO - 2024-12-13 03:40:26 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:26 --> CSRF cookie sent
INFO - 2024-12-13 03:40:26 --> Input Class Initialized
INFO - 2024-12-13 03:40:26 --> Language Class Initialized
INFO - 2024-12-13 03:40:26 --> Loader Class Initialized
INFO - 2024-12-13 03:40:26 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:26 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:26 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:26 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:26 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:26 --> Controller Class Initialized
INFO - 2024-12-13 03:40:26 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:26 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:26 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:26 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:40:26 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:26 --> Total execution time: 0.0735
INFO - 2024-12-13 03:40:39 --> Config Class Initialized
INFO - 2024-12-13 03:40:39 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:39 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:39 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:39 --> URI Class Initialized
INFO - 2024-12-13 03:40:39 --> Router Class Initialized
INFO - 2024-12-13 03:40:39 --> Output Class Initialized
INFO - 2024-12-13 03:40:39 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:39 --> CSRF cookie sent
INFO - 2024-12-13 03:40:39 --> Input Class Initialized
INFO - 2024-12-13 03:40:39 --> Language Class Initialized
INFO - 2024-12-13 03:40:39 --> Loader Class Initialized
INFO - 2024-12-13 03:40:39 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:39 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:39 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:39 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:39 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:39 --> Controller Class Initialized
INFO - 2024-12-13 03:40:39 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:39 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:39 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:39 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/reset_password.php
INFO - 2024-12-13 03:40:39 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:39 --> Total execution time: 0.0753
INFO - 2024-12-13 03:40:43 --> Config Class Initialized
INFO - 2024-12-13 03:40:43 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:43 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:43 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:43 --> URI Class Initialized
INFO - 2024-12-13 03:40:43 --> Router Class Initialized
INFO - 2024-12-13 03:40:43 --> Output Class Initialized
INFO - 2024-12-13 03:40:43 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:43 --> CSRF cookie sent
INFO - 2024-12-13 03:40:43 --> Input Class Initialized
INFO - 2024-12-13 03:40:43 --> Language Class Initialized
INFO - 2024-12-13 03:40:43 --> Loader Class Initialized
INFO - 2024-12-13 03:40:43 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:43 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:43 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:43 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:43 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:43 --> Controller Class Initialized
INFO - 2024-12-13 03:40:43 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:43 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:43 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:43 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:40:43 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:43 --> Total execution time: 0.1182
INFO - 2024-12-13 03:40:48 --> Config Class Initialized
INFO - 2024-12-13 03:40:48 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:48 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:48 --> URI Class Initialized
INFO - 2024-12-13 03:40:48 --> Router Class Initialized
INFO - 2024-12-13 03:40:48 --> Output Class Initialized
INFO - 2024-12-13 03:40:48 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:48 --> CSRF cookie sent
INFO - 2024-12-13 03:40:48 --> CSRF token verified
INFO - 2024-12-13 03:40:48 --> Input Class Initialized
INFO - 2024-12-13 03:40:48 --> Language Class Initialized
INFO - 2024-12-13 03:40:48 --> Loader Class Initialized
INFO - 2024-12-13 03:40:48 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:48 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:48 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:48 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:48 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:48 --> Controller Class Initialized
INFO - 2024-12-13 03:40:48 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:40:48 --> Config Class Initialized
INFO - 2024-12-13 03:40:48 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:48 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:48 --> URI Class Initialized
INFO - 2024-12-13 03:40:48 --> Router Class Initialized
INFO - 2024-12-13 03:40:48 --> Output Class Initialized
INFO - 2024-12-13 03:40:48 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:48 --> CSRF cookie sent
INFO - 2024-12-13 03:40:48 --> Input Class Initialized
INFO - 2024-12-13 03:40:48 --> Language Class Initialized
INFO - 2024-12-13 03:40:48 --> Loader Class Initialized
INFO - 2024-12-13 03:40:48 --> Helper loaded: url_helper
INFO - 2024-12-13 03:40:48 --> Helper loaded: form_helper
INFO - 2024-12-13 03:40:48 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:40:48 --> Form Validation Class Initialized
INFO - 2024-12-13 03:40:48 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:40:48 --> Controller Class Initialized
INFO - 2024-12-13 03:40:48 --> Model "User_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "Category_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "Review_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "News_model" initialized
INFO - 2024-12-13 03:40:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:40:48 --> Query result: stdClass Object
(
    [view_count] => 171
)

INFO - 2024-12-13 03:40:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:40:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:40:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:40:48 --> Final output sent to browser
DEBUG - 2024-12-13 03:40:48 --> Total execution time: 0.0584
INFO - 2024-12-13 03:40:48 --> Config Class Initialized
INFO - 2024-12-13 03:40:48 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:40:49 --> Utf8 Class Initialized
INFO - 2024-12-13 03:40:49 --> URI Class Initialized
INFO - 2024-12-13 03:40:49 --> Router Class Initialized
INFO - 2024-12-13 03:40:49 --> Output Class Initialized
INFO - 2024-12-13 03:40:49 --> Security Class Initialized
DEBUG - 2024-12-13 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:40:49 --> CSRF cookie sent
INFO - 2024-12-13 03:40:49 --> Input Class Initialized
INFO - 2024-12-13 03:40:49 --> Language Class Initialized
ERROR - 2024-12-13 03:40:49 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:41:02 --> Config Class Initialized
INFO - 2024-12-13 03:41:02 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:41:02 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:41:02 --> Utf8 Class Initialized
INFO - 2024-12-13 03:41:02 --> URI Class Initialized
INFO - 2024-12-13 03:41:02 --> Router Class Initialized
INFO - 2024-12-13 03:41:02 --> Output Class Initialized
INFO - 2024-12-13 03:41:02 --> Security Class Initialized
DEBUG - 2024-12-13 03:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:41:02 --> CSRF cookie sent
INFO - 2024-12-13 03:41:02 --> Input Class Initialized
INFO - 2024-12-13 03:41:02 --> Language Class Initialized
INFO - 2024-12-13 03:41:02 --> Loader Class Initialized
INFO - 2024-12-13 03:41:02 --> Helper loaded: url_helper
INFO - 2024-12-13 03:41:02 --> Helper loaded: form_helper
INFO - 2024-12-13 03:41:02 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:41:02 --> Form Validation Class Initialized
INFO - 2024-12-13 03:41:02 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:41:02 --> Controller Class Initialized
INFO - 2024-12-13 03:41:02 --> Model "User_model" initialized
INFO - 2024-12-13 03:41:02 --> Model "Category_model" initialized
INFO - 2024-12-13 03:41:02 --> Model "Review_model" initialized
INFO - 2024-12-13 03:41:02 --> Model "News_model" initialized
INFO - 2024-12-13 03:41:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:41:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:41:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:41:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-13 03:41:02 --> Final output sent to browser
DEBUG - 2024-12-13 03:41:02 --> Total execution time: 0.1014
INFO - 2024-12-13 03:42:06 --> Config Class Initialized
INFO - 2024-12-13 03:42:06 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:06 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:06 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:06 --> URI Class Initialized
INFO - 2024-12-13 03:42:06 --> Router Class Initialized
INFO - 2024-12-13 03:42:06 --> Output Class Initialized
INFO - 2024-12-13 03:42:06 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:06 --> CSRF cookie sent
INFO - 2024-12-13 03:42:06 --> CSRF token verified
INFO - 2024-12-13 03:42:06 --> Input Class Initialized
INFO - 2024-12-13 03:42:06 --> Language Class Initialized
INFO - 2024-12-13 03:42:06 --> Loader Class Initialized
INFO - 2024-12-13 03:42:06 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:06 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:06 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:06 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:06 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:06 --> Controller Class Initialized
INFO - 2024-12-13 03:42:06 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:06 --> Upload Class Initialized
INFO - 2024-12-13 03:42:06 --> Config Class Initialized
INFO - 2024-12-13 03:42:06 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:06 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:06 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:06 --> URI Class Initialized
INFO - 2024-12-13 03:42:06 --> Router Class Initialized
INFO - 2024-12-13 03:42:06 --> Output Class Initialized
INFO - 2024-12-13 03:42:06 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:06 --> CSRF cookie sent
INFO - 2024-12-13 03:42:06 --> Input Class Initialized
INFO - 2024-12-13 03:42:06 --> Language Class Initialized
INFO - 2024-12-13 03:42:06 --> Loader Class Initialized
INFO - 2024-12-13 03:42:06 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:06 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:06 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:06 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:06 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:06 --> Controller Class Initialized
INFO - 2024-12-13 03:42:06 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:42:06 --> Query result: stdClass Object
(
    [view_count] => 172
)

INFO - 2024-12-13 03:42:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:42:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:42:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:42:06 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:06 --> Total execution time: 0.2266
INFO - 2024-12-13 03:42:07 --> Config Class Initialized
INFO - 2024-12-13 03:42:07 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:07 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:07 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:07 --> URI Class Initialized
INFO - 2024-12-13 03:42:07 --> Router Class Initialized
INFO - 2024-12-13 03:42:07 --> Output Class Initialized
INFO - 2024-12-13 03:42:07 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:07 --> CSRF cookie sent
INFO - 2024-12-13 03:42:07 --> Input Class Initialized
INFO - 2024-12-13 03:42:07 --> Language Class Initialized
ERROR - 2024-12-13 03:42:07 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-13 03:42:12 --> Config Class Initialized
INFO - 2024-12-13 03:42:12 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:12 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:12 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:12 --> URI Class Initialized
INFO - 2024-12-13 03:42:12 --> Router Class Initialized
INFO - 2024-12-13 03:42:12 --> Output Class Initialized
INFO - 2024-12-13 03:42:12 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:12 --> CSRF cookie sent
INFO - 2024-12-13 03:42:16 --> Config Class Initialized
INFO - 2024-12-13 03:42:16 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:16 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:16 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:16 --> URI Class Initialized
INFO - 2024-12-13 03:42:16 --> Router Class Initialized
INFO - 2024-12-13 03:42:16 --> Output Class Initialized
INFO - 2024-12-13 03:42:16 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:16 --> CSRF cookie sent
INFO - 2024-12-13 03:42:16 --> Input Class Initialized
INFO - 2024-12-13 03:42:16 --> Language Class Initialized
INFO - 2024-12-13 03:42:16 --> Loader Class Initialized
INFO - 2024-12-13 03:42:16 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:16 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:16 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:16 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:16 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:16 --> Controller Class Initialized
INFO - 2024-12-13 03:42:16 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:16 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:16 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:16 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:42:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:42:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:42:16 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:16 --> Total execution time: 0.1025
INFO - 2024-12-13 03:42:17 --> Config Class Initialized
INFO - 2024-12-13 03:42:17 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:17 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:17 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:17 --> URI Class Initialized
INFO - 2024-12-13 03:42:17 --> Router Class Initialized
INFO - 2024-12-13 03:42:17 --> Output Class Initialized
INFO - 2024-12-13 03:42:17 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:17 --> CSRF cookie sent
INFO - 2024-12-13 03:42:17 --> Input Class Initialized
INFO - 2024-12-13 03:42:17 --> Language Class Initialized
INFO - 2024-12-13 03:42:17 --> Loader Class Initialized
INFO - 2024-12-13 03:42:17 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:17 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:17 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:17 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:17 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:17 --> Controller Class Initialized
INFO - 2024-12-13 03:42:17 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:17 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:17 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:17 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:42:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:42:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-13 03:42:17 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:17 --> Total execution time: 0.1233
INFO - 2024-12-13 03:42:20 --> Config Class Initialized
INFO - 2024-12-13 03:42:20 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:20 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:20 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:20 --> URI Class Initialized
INFO - 2024-12-13 03:42:20 --> Router Class Initialized
INFO - 2024-12-13 03:42:20 --> Output Class Initialized
INFO - 2024-12-13 03:42:20 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:20 --> CSRF cookie sent
INFO - 2024-12-13 03:42:20 --> Input Class Initialized
INFO - 2024-12-13 03:42:20 --> Language Class Initialized
INFO - 2024-12-13 03:42:20 --> Loader Class Initialized
INFO - 2024-12-13 03:42:20 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:20 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:20 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:20 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:20 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:20 --> Controller Class Initialized
INFO - 2024-12-13 03:42:20 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:20 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:20 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:20 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:42:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:42:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:42:20 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:20 --> Total execution time: 0.1292
INFO - 2024-12-13 03:42:22 --> Config Class Initialized
INFO - 2024-12-13 03:42:22 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:22 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:22 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:22 --> URI Class Initialized
INFO - 2024-12-13 03:42:22 --> Router Class Initialized
INFO - 2024-12-13 03:42:22 --> Output Class Initialized
INFO - 2024-12-13 03:42:22 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:22 --> CSRF cookie sent
INFO - 2024-12-13 03:42:22 --> Input Class Initialized
INFO - 2024-12-13 03:42:22 --> Language Class Initialized
INFO - 2024-12-13 03:42:22 --> Loader Class Initialized
INFO - 2024-12-13 03:42:22 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:22 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:22 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:22 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:22 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:22 --> Controller Class Initialized
INFO - 2024-12-13 03:42:22 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:23 --> Config Class Initialized
INFO - 2024-12-13 03:42:23 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:23 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:23 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:23 --> URI Class Initialized
INFO - 2024-12-13 03:42:23 --> Router Class Initialized
INFO - 2024-12-13 03:42:23 --> Output Class Initialized
INFO - 2024-12-13 03:42:23 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:23 --> CSRF cookie sent
INFO - 2024-12-13 03:42:23 --> Input Class Initialized
INFO - 2024-12-13 03:42:23 --> Language Class Initialized
INFO - 2024-12-13 03:42:23 --> Loader Class Initialized
INFO - 2024-12-13 03:42:23 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:23 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:23 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:23 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:23 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:23 --> Controller Class Initialized
INFO - 2024-12-13 03:42:23 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:42:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:42:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:42:23 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:23 --> Total execution time: 0.0799
INFO - 2024-12-13 03:42:27 --> Config Class Initialized
INFO - 2024-12-13 03:42:27 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:27 --> URI Class Initialized
INFO - 2024-12-13 03:42:27 --> Router Class Initialized
INFO - 2024-12-13 03:42:27 --> Output Class Initialized
INFO - 2024-12-13 03:42:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:27 --> CSRF cookie sent
INFO - 2024-12-13 03:42:27 --> CSRF token verified
INFO - 2024-12-13 03:42:27 --> Input Class Initialized
INFO - 2024-12-13 03:42:27 --> Language Class Initialized
INFO - 2024-12-13 03:42:27 --> Loader Class Initialized
INFO - 2024-12-13 03:42:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:27 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:27 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:28 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:28 --> Controller Class Initialized
INFO - 2024-12-13 03:42:28 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "News_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:28 --> Config Class Initialized
INFO - 2024-12-13 03:42:28 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:28 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:28 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:28 --> URI Class Initialized
INFO - 2024-12-13 03:42:28 --> Router Class Initialized
INFO - 2024-12-13 03:42:28 --> Output Class Initialized
INFO - 2024-12-13 03:42:28 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:28 --> CSRF cookie sent
INFO - 2024-12-13 03:42:28 --> Input Class Initialized
INFO - 2024-12-13 03:42:28 --> Language Class Initialized
INFO - 2024-12-13 03:42:28 --> Loader Class Initialized
INFO - 2024-12-13 03:42:28 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:28 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:28 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:28 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:28 --> Controller Class Initialized
INFO - 2024-12-13 03:42:28 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:42:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:42:28 --> Query result: stdClass Object
(
    [view_count] => 172
)

INFO - 2024-12-13 03:42:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 03:42:28 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:28 --> Total execution time: 0.1317
INFO - 2024-12-13 03:42:34 --> Config Class Initialized
INFO - 2024-12-13 03:42:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:34 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:34 --> URI Class Initialized
INFO - 2024-12-13 03:42:34 --> Router Class Initialized
INFO - 2024-12-13 03:42:34 --> Output Class Initialized
INFO - 2024-12-13 03:42:34 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:34 --> CSRF cookie sent
INFO - 2024-12-13 03:42:34 --> Input Class Initialized
INFO - 2024-12-13 03:42:34 --> Language Class Initialized
INFO - 2024-12-13 03:42:34 --> Loader Class Initialized
INFO - 2024-12-13 03:42:34 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:34 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:34 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:34 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:34 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:34 --> Controller Class Initialized
INFO - 2024-12-13 03:42:34 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:34 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:34 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:42:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:42:34 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:34 --> Total execution time: 0.0832
INFO - 2024-12-13 03:42:45 --> Config Class Initialized
INFO - 2024-12-13 03:42:45 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:45 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:45 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:45 --> URI Class Initialized
INFO - 2024-12-13 03:42:45 --> Router Class Initialized
INFO - 2024-12-13 03:42:45 --> Output Class Initialized
INFO - 2024-12-13 03:42:45 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:45 --> CSRF cookie sent
INFO - 2024-12-13 03:42:45 --> Input Class Initialized
INFO - 2024-12-13 03:42:45 --> Language Class Initialized
INFO - 2024-12-13 03:42:45 --> Loader Class Initialized
INFO - 2024-12-13 03:42:45 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:45 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:45 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:45 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:45 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:45 --> Controller Class Initialized
INFO - 2024-12-13 03:42:45 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:45 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:45 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:45 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:42:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 03:42:45 --> Pagination Class Initialized
INFO - 2024-12-13 03:42:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 03:42:45 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:45 --> Total execution time: 0.1463
INFO - 2024-12-13 03:42:53 --> Config Class Initialized
INFO - 2024-12-13 03:42:53 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:53 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:53 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:53 --> URI Class Initialized
INFO - 2024-12-13 03:42:53 --> Router Class Initialized
INFO - 2024-12-13 03:42:53 --> Output Class Initialized
INFO - 2024-12-13 03:42:53 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:53 --> CSRF cookie sent
INFO - 2024-12-13 03:42:53 --> Input Class Initialized
INFO - 2024-12-13 03:42:53 --> Language Class Initialized
INFO - 2024-12-13 03:42:53 --> Loader Class Initialized
INFO - 2024-12-13 03:42:53 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:53 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:53 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:53 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:53 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:53 --> Controller Class Initialized
INFO - 2024-12-13 03:42:53 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:53 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:53 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:53 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:42:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:42:53 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:53 --> Total execution time: 0.1232
INFO - 2024-12-13 03:42:58 --> Config Class Initialized
INFO - 2024-12-13 03:42:58 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:58 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:58 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:58 --> URI Class Initialized
INFO - 2024-12-13 03:42:58 --> Router Class Initialized
INFO - 2024-12-13 03:42:58 --> Output Class Initialized
INFO - 2024-12-13 03:42:58 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:58 --> CSRF cookie sent
INFO - 2024-12-13 03:42:58 --> Input Class Initialized
INFO - 2024-12-13 03:42:58 --> Language Class Initialized
INFO - 2024-12-13 03:42:58 --> Loader Class Initialized
INFO - 2024-12-13 03:42:58 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:58 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:58 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:58 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:58 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:58 --> Controller Class Initialized
INFO - 2024-12-13 03:42:58 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:58 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:58 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:42:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:59 --> Config Class Initialized
INFO - 2024-12-13 03:42:59 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:42:59 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:42:59 --> Utf8 Class Initialized
INFO - 2024-12-13 03:42:59 --> URI Class Initialized
INFO - 2024-12-13 03:42:59 --> Router Class Initialized
INFO - 2024-12-13 03:42:59 --> Output Class Initialized
INFO - 2024-12-13 03:42:59 --> Security Class Initialized
DEBUG - 2024-12-13 03:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:42:59 --> CSRF cookie sent
INFO - 2024-12-13 03:42:59 --> Input Class Initialized
INFO - 2024-12-13 03:42:59 --> Language Class Initialized
INFO - 2024-12-13 03:42:59 --> Loader Class Initialized
INFO - 2024-12-13 03:42:59 --> Helper loaded: url_helper
INFO - 2024-12-13 03:42:59 --> Helper loaded: form_helper
INFO - 2024-12-13 03:42:59 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:42:59 --> Form Validation Class Initialized
INFO - 2024-12-13 03:42:59 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:42:59 --> Controller Class Initialized
INFO - 2024-12-13 03:42:59 --> Model "Review_model" initialized
INFO - 2024-12-13 03:42:59 --> Model "Category_model" initialized
INFO - 2024-12-13 03:42:59 --> Model "User_model" initialized
INFO - 2024-12-13 03:42:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:42:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:42:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:42:59 --> Final output sent to browser
DEBUG - 2024-12-13 03:42:59 --> Total execution time: 0.0583
INFO - 2024-12-13 03:43:01 --> Config Class Initialized
INFO - 2024-12-13 03:43:01 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:02 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:02 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:02 --> URI Class Initialized
INFO - 2024-12-13 03:43:02 --> Router Class Initialized
INFO - 2024-12-13 03:43:02 --> Output Class Initialized
INFO - 2024-12-13 03:43:02 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:02 --> CSRF cookie sent
INFO - 2024-12-13 03:43:02 --> Input Class Initialized
INFO - 2024-12-13 03:43:02 --> Language Class Initialized
INFO - 2024-12-13 03:43:02 --> Loader Class Initialized
INFO - 2024-12-13 03:43:02 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:02 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:02 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:02 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:02 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:02 --> Controller Class Initialized
INFO - 2024-12-13 03:43:02 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:02 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:02 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:43:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 03:43:02 --> Pagination Class Initialized
INFO - 2024-12-13 03:43:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 03:43:02 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:02 --> Total execution time: 0.0725
INFO - 2024-12-13 03:43:12 --> Config Class Initialized
INFO - 2024-12-13 03:43:12 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:12 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:12 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:12 --> URI Class Initialized
INFO - 2024-12-13 03:43:12 --> Router Class Initialized
INFO - 2024-12-13 03:43:12 --> Output Class Initialized
INFO - 2024-12-13 03:43:12 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:12 --> CSRF cookie sent
INFO - 2024-12-13 03:43:12 --> Input Class Initialized
INFO - 2024-12-13 03:43:12 --> Language Class Initialized
INFO - 2024-12-13 03:43:12 --> Loader Class Initialized
INFO - 2024-12-13 03:43:12 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:12 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:12 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:12 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:12 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:12 --> Controller Class Initialized
INFO - 2024-12-13 03:43:12 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:12 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:12 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:12 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:43:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:43:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:43:13 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:13 --> Total execution time: 0.0824
INFO - 2024-12-13 03:43:21 --> Config Class Initialized
INFO - 2024-12-13 03:43:21 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:21 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:21 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:21 --> URI Class Initialized
INFO - 2024-12-13 03:43:21 --> Router Class Initialized
INFO - 2024-12-13 03:43:21 --> Output Class Initialized
INFO - 2024-12-13 03:43:21 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:21 --> CSRF cookie sent
INFO - 2024-12-13 03:43:21 --> Input Class Initialized
INFO - 2024-12-13 03:43:21 --> Language Class Initialized
INFO - 2024-12-13 03:43:21 --> Loader Class Initialized
INFO - 2024-12-13 03:43:21 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:21 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:21 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:21 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:21 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:21 --> Controller Class Initialized
INFO - 2024-12-13 03:43:21 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:21 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:21 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:21 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:43:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:43:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-13 03:43:22 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:22 --> Total execution time: 0.2412
INFO - 2024-12-13 03:43:31 --> Config Class Initialized
INFO - 2024-12-13 03:43:31 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:31 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:31 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:31 --> URI Class Initialized
INFO - 2024-12-13 03:43:31 --> Router Class Initialized
INFO - 2024-12-13 03:43:31 --> Output Class Initialized
INFO - 2024-12-13 03:43:31 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:31 --> CSRF cookie sent
INFO - 2024-12-13 03:43:31 --> Input Class Initialized
INFO - 2024-12-13 03:43:31 --> Language Class Initialized
INFO - 2024-12-13 03:43:31 --> Loader Class Initialized
INFO - 2024-12-13 03:43:31 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:31 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:31 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:31 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:31 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:31 --> Controller Class Initialized
INFO - 2024-12-13 03:43:31 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:31 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:31 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:31 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:43:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:43:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:43:31 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:31 --> Total execution time: 0.1617
INFO - 2024-12-13 03:43:37 --> Config Class Initialized
INFO - 2024-12-13 03:43:37 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:37 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:37 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:37 --> URI Class Initialized
INFO - 2024-12-13 03:43:37 --> Router Class Initialized
INFO - 2024-12-13 03:43:37 --> Output Class Initialized
INFO - 2024-12-13 03:43:37 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:37 --> CSRF cookie sent
INFO - 2024-12-13 03:43:37 --> CSRF token verified
INFO - 2024-12-13 03:43:37 --> Input Class Initialized
INFO - 2024-12-13 03:43:38 --> Language Class Initialized
INFO - 2024-12-13 03:43:38 --> Loader Class Initialized
INFO - 2024-12-13 03:43:38 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:38 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:38 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:38 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:38 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:38 --> Controller Class Initialized
INFO - 2024-12-13 03:43:38 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:38 --> Config Class Initialized
INFO - 2024-12-13 03:43:38 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:38 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:38 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:38 --> URI Class Initialized
INFO - 2024-12-13 03:43:38 --> Router Class Initialized
INFO - 2024-12-13 03:43:38 --> Output Class Initialized
INFO - 2024-12-13 03:43:38 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:38 --> CSRF cookie sent
INFO - 2024-12-13 03:43:38 --> Input Class Initialized
INFO - 2024-12-13 03:43:38 --> Language Class Initialized
INFO - 2024-12-13 03:43:38 --> Loader Class Initialized
INFO - 2024-12-13 03:43:38 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:38 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:38 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:38 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:38 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:38 --> Controller Class Initialized
INFO - 2024-12-13 03:43:38 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:43:38 --> Query result: stdClass Object
(
    [view_count] => 173
)

INFO - 2024-12-13 03:43:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:43:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:43:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:43:39 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:39 --> Total execution time: 0.4168
INFO - 2024-12-13 03:43:39 --> Config Class Initialized
INFO - 2024-12-13 03:43:39 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:39 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:39 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:39 --> URI Class Initialized
INFO - 2024-12-13 03:43:39 --> Router Class Initialized
INFO - 2024-12-13 03:43:39 --> Output Class Initialized
INFO - 2024-12-13 03:43:39 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:39 --> CSRF cookie sent
INFO - 2024-12-13 03:43:39 --> Input Class Initialized
INFO - 2024-12-13 03:43:39 --> Language Class Initialized
ERROR - 2024-12-13 03:43:39 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:43:44 --> Config Class Initialized
INFO - 2024-12-13 03:43:44 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:44 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:44 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:44 --> URI Class Initialized
INFO - 2024-12-13 03:43:44 --> Router Class Initialized
INFO - 2024-12-13 03:43:44 --> Output Class Initialized
INFO - 2024-12-13 03:43:44 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:44 --> CSRF cookie sent
INFO - 2024-12-13 03:43:44 --> Input Class Initialized
INFO - 2024-12-13 03:43:44 --> Language Class Initialized
INFO - 2024-12-13 03:43:44 --> Loader Class Initialized
INFO - 2024-12-13 03:43:44 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:44 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:44 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:44 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:44 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:44 --> Controller Class Initialized
INFO - 2024-12-13 03:43:44 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:44 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:44 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:44 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:43:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:43:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/makanan_berat.php
INFO - 2024-12-13 03:43:44 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:45 --> Total execution time: 0.5878
INFO - 2024-12-13 03:43:51 --> Config Class Initialized
INFO - 2024-12-13 03:43:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:43:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:43:51 --> Utf8 Class Initialized
INFO - 2024-12-13 03:43:51 --> URI Class Initialized
INFO - 2024-12-13 03:43:51 --> Router Class Initialized
INFO - 2024-12-13 03:43:51 --> Output Class Initialized
INFO - 2024-12-13 03:43:51 --> Security Class Initialized
DEBUG - 2024-12-13 03:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:43:51 --> CSRF cookie sent
INFO - 2024-12-13 03:43:51 --> Input Class Initialized
INFO - 2024-12-13 03:43:51 --> Language Class Initialized
INFO - 2024-12-13 03:43:51 --> Loader Class Initialized
INFO - 2024-12-13 03:43:51 --> Helper loaded: url_helper
INFO - 2024-12-13 03:43:51 --> Helper loaded: form_helper
INFO - 2024-12-13 03:43:51 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:43:51 --> Form Validation Class Initialized
INFO - 2024-12-13 03:43:51 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:43:51 --> Controller Class Initialized
INFO - 2024-12-13 03:43:51 --> Model "User_model" initialized
INFO - 2024-12-13 03:43:51 --> Model "Category_model" initialized
INFO - 2024-12-13 03:43:51 --> Model "Review_model" initialized
INFO - 2024-12-13 03:43:51 --> Model "News_model" initialized
INFO - 2024-12-13 03:43:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:43:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:43:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:43:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-13 03:43:51 --> Final output sent to browser
DEBUG - 2024-12-13 03:43:51 --> Total execution time: 0.0919
INFO - 2024-12-13 03:44:26 --> Config Class Initialized
INFO - 2024-12-13 03:44:26 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:44:26 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:44:26 --> Utf8 Class Initialized
INFO - 2024-12-13 03:44:26 --> URI Class Initialized
INFO - 2024-12-13 03:44:26 --> Router Class Initialized
INFO - 2024-12-13 03:44:26 --> Output Class Initialized
INFO - 2024-12-13 03:44:26 --> Security Class Initialized
DEBUG - 2024-12-13 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:44:26 --> CSRF cookie sent
INFO - 2024-12-13 03:44:26 --> Input Class Initialized
INFO - 2024-12-13 03:44:26 --> Language Class Initialized
INFO - 2024-12-13 03:44:26 --> Loader Class Initialized
INFO - 2024-12-13 03:44:26 --> Helper loaded: url_helper
INFO - 2024-12-13 03:44:26 --> Helper loaded: form_helper
INFO - 2024-12-13 03:44:26 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:44:26 --> Form Validation Class Initialized
INFO - 2024-12-13 03:44:26 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:44:26 --> Controller Class Initialized
INFO - 2024-12-13 03:44:26 --> Model "Review_model" initialized
INFO - 2024-12-13 03:44:26 --> Model "Category_model" initialized
INFO - 2024-12-13 03:44:26 --> Model "User_model" initialized
INFO - 2024-12-13 03:44:26 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:44:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:44:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-13 03:44:26 --> Final output sent to browser
DEBUG - 2024-12-13 03:44:26 --> Total execution time: 0.1395
INFO - 2024-12-13 03:44:40 --> Config Class Initialized
INFO - 2024-12-13 03:44:40 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:44:40 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:44:40 --> Utf8 Class Initialized
INFO - 2024-12-13 03:44:40 --> URI Class Initialized
INFO - 2024-12-13 03:44:40 --> Router Class Initialized
INFO - 2024-12-13 03:44:40 --> Output Class Initialized
INFO - 2024-12-13 03:44:40 --> Security Class Initialized
DEBUG - 2024-12-13 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:44:40 --> CSRF cookie sent
INFO - 2024-12-13 03:44:40 --> Input Class Initialized
INFO - 2024-12-13 03:44:40 --> Language Class Initialized
INFO - 2024-12-13 03:44:40 --> Loader Class Initialized
INFO - 2024-12-13 03:44:40 --> Helper loaded: url_helper
INFO - 2024-12-13 03:44:40 --> Helper loaded: form_helper
INFO - 2024-12-13 03:44:40 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:44:40 --> Form Validation Class Initialized
INFO - 2024-12-13 03:44:40 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:44:40 --> Controller Class Initialized
INFO - 2024-12-13 03:44:40 --> Model "User_model" initialized
INFO - 2024-12-13 03:44:40 --> Model "Category_model" initialized
INFO - 2024-12-13 03:44:40 --> Model "Review_model" initialized
INFO - 2024-12-13 03:44:40 --> Model "News_model" initialized
INFO - 2024-12-13 03:44:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:44:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:44:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:44:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-13 03:44:40 --> Final output sent to browser
DEBUG - 2024-12-13 03:44:40 --> Total execution time: 0.1054
INFO - 2024-12-13 03:45:09 --> Config Class Initialized
INFO - 2024-12-13 03:45:09 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:09 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:09 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:09 --> URI Class Initialized
INFO - 2024-12-13 03:45:09 --> Router Class Initialized
INFO - 2024-12-13 03:45:09 --> Output Class Initialized
INFO - 2024-12-13 03:45:09 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:09 --> CSRF cookie sent
INFO - 2024-12-13 03:45:09 --> CSRF token verified
INFO - 2024-12-13 03:45:09 --> Input Class Initialized
INFO - 2024-12-13 03:45:09 --> Language Class Initialized
INFO - 2024-12-13 03:45:09 --> Loader Class Initialized
INFO - 2024-12-13 03:45:09 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:09 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:09 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:10 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:10 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:10 --> Controller Class Initialized
INFO - 2024-12-13 03:45:10 --> Model "Contact_model" initialized
DEBUG - 2024-12-13 03:45:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-13 03:45:10 --> Config Class Initialized
INFO - 2024-12-13 03:45:10 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:10 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:10 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:10 --> URI Class Initialized
INFO - 2024-12-13 03:45:10 --> Router Class Initialized
INFO - 2024-12-13 03:45:10 --> Output Class Initialized
INFO - 2024-12-13 03:45:10 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:10 --> CSRF cookie sent
INFO - 2024-12-13 03:45:10 --> Input Class Initialized
INFO - 2024-12-13 03:45:10 --> Language Class Initialized
INFO - 2024-12-13 03:45:10 --> Loader Class Initialized
INFO - 2024-12-13 03:45:10 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:10 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:10 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:10 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:10 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:10 --> Controller Class Initialized
INFO - 2024-12-13 03:45:10 --> Model "Contact_model" initialized
DEBUG - 2024-12-13 03:45:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:45:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:45:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-13 03:45:10 --> Final output sent to browser
DEBUG - 2024-12-13 03:45:10 --> Total execution time: 0.0649
INFO - 2024-12-13 03:45:14 --> Config Class Initialized
INFO - 2024-12-13 03:45:14 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:14 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:14 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:14 --> URI Class Initialized
INFO - 2024-12-13 03:45:14 --> Router Class Initialized
INFO - 2024-12-13 03:45:14 --> Output Class Initialized
INFO - 2024-12-13 03:45:14 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:14 --> CSRF cookie sent
INFO - 2024-12-13 03:45:14 --> Input Class Initialized
INFO - 2024-12-13 03:45:14 --> Language Class Initialized
INFO - 2024-12-13 03:45:14 --> Loader Class Initialized
INFO - 2024-12-13 03:45:14 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:14 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:14 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:14 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:14 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:14 --> Controller Class Initialized
INFO - 2024-12-13 03:45:14 --> Model "Review_model" initialized
INFO - 2024-12-13 03:45:14 --> Model "Category_model" initialized
INFO - 2024-12-13 03:45:14 --> Model "User_model" initialized
INFO - 2024-12-13 03:45:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:45:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:14 --> Model "Contact_model" initialized
INFO - 2024-12-13 03:45:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-13 03:45:14 --> Final output sent to browser
DEBUG - 2024-12-13 03:45:14 --> Total execution time: 0.0649
INFO - 2024-12-13 03:45:36 --> Config Class Initialized
INFO - 2024-12-13 03:45:36 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:36 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:36 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:36 --> URI Class Initialized
INFO - 2024-12-13 03:45:36 --> Router Class Initialized
INFO - 2024-12-13 03:45:36 --> Output Class Initialized
INFO - 2024-12-13 03:45:36 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:36 --> CSRF cookie sent
INFO - 2024-12-13 03:45:36 --> Input Class Initialized
INFO - 2024-12-13 03:45:36 --> Language Class Initialized
INFO - 2024-12-13 03:45:36 --> Loader Class Initialized
INFO - 2024-12-13 03:45:36 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:36 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:36 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:36 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:36 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:36 --> Controller Class Initialized
INFO - 2024-12-13 03:45:36 --> Model "Review_model" initialized
INFO - 2024-12-13 03:45:36 --> Model "Category_model" initialized
INFO - 2024-12-13 03:45:36 --> Model "User_model" initialized
INFO - 2024-12-13 03:45:36 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:45:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:45:36 --> Final output sent to browser
DEBUG - 2024-12-13 03:45:36 --> Total execution time: 0.2668
INFO - 2024-12-13 03:45:47 --> Config Class Initialized
INFO - 2024-12-13 03:45:47 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:47 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:47 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:47 --> URI Class Initialized
INFO - 2024-12-13 03:45:47 --> Router Class Initialized
INFO - 2024-12-13 03:45:47 --> Output Class Initialized
INFO - 2024-12-13 03:45:47 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:47 --> CSRF cookie sent
INFO - 2024-12-13 03:45:47 --> Input Class Initialized
INFO - 2024-12-13 03:45:48 --> Language Class Initialized
INFO - 2024-12-13 03:45:48 --> Loader Class Initialized
INFO - 2024-12-13 03:45:48 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:48 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:48 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:48 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:48 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:48 --> Controller Class Initialized
INFO - 2024-12-13 03:45:48 --> Model "User_model" initialized
INFO - 2024-12-13 03:45:48 --> Model "Category_model" initialized
INFO - 2024-12-13 03:45:48 --> Model "Review_model" initialized
INFO - 2024-12-13 03:45:48 --> Model "News_model" initialized
INFO - 2024-12-13 03:45:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:45:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:45:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-13 03:45:49 --> Final output sent to browser
DEBUG - 2024-12-13 03:45:49 --> Total execution time: 1.8230
INFO - 2024-12-13 03:45:54 --> Config Class Initialized
INFO - 2024-12-13 03:45:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:54 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:54 --> URI Class Initialized
INFO - 2024-12-13 03:45:54 --> Router Class Initialized
INFO - 2024-12-13 03:45:54 --> Output Class Initialized
INFO - 2024-12-13 03:45:54 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:54 --> CSRF cookie sent
INFO - 2024-12-13 03:45:54 --> Input Class Initialized
INFO - 2024-12-13 03:45:54 --> Language Class Initialized
INFO - 2024-12-13 03:45:54 --> Loader Class Initialized
INFO - 2024-12-13 03:45:54 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:54 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:54 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:54 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:54 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:54 --> Controller Class Initialized
INFO - 2024-12-13 03:45:54 --> Model "User_model" initialized
INFO - 2024-12-13 03:45:54 --> Model "Category_model" initialized
INFO - 2024-12-13 03:45:54 --> Model "Review_model" initialized
INFO - 2024-12-13 03:45:54 --> Model "News_model" initialized
INFO - 2024-12-13 03:45:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:45:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:45:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-13 03:45:54 --> Final output sent to browser
DEBUG - 2024-12-13 03:45:54 --> Total execution time: 0.1035
INFO - 2024-12-13 03:45:58 --> Config Class Initialized
INFO - 2024-12-13 03:45:58 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:45:58 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:45:58 --> Utf8 Class Initialized
INFO - 2024-12-13 03:45:58 --> URI Class Initialized
INFO - 2024-12-13 03:45:58 --> Router Class Initialized
INFO - 2024-12-13 03:45:58 --> Output Class Initialized
INFO - 2024-12-13 03:45:58 --> Security Class Initialized
DEBUG - 2024-12-13 03:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:45:58 --> CSRF cookie sent
INFO - 2024-12-13 03:45:58 --> Input Class Initialized
INFO - 2024-12-13 03:45:58 --> Language Class Initialized
INFO - 2024-12-13 03:45:58 --> Loader Class Initialized
INFO - 2024-12-13 03:45:58 --> Helper loaded: url_helper
INFO - 2024-12-13 03:45:58 --> Helper loaded: form_helper
INFO - 2024-12-13 03:45:58 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:45:58 --> Form Validation Class Initialized
INFO - 2024-12-13 03:45:58 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:45:58 --> Controller Class Initialized
INFO - 2024-12-13 03:45:58 --> Model "User_model" initialized
DEBUG - 2024-12-13 03:45:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:45:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:45:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:45:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:45:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-13 03:45:58 --> Final output sent to browser
DEBUG - 2024-12-13 03:45:58 --> Total execution time: 0.2054
INFO - 2024-12-13 03:46:03 --> Config Class Initialized
INFO - 2024-12-13 03:46:03 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:03 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:03 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:03 --> URI Class Initialized
INFO - 2024-12-13 03:46:03 --> Router Class Initialized
INFO - 2024-12-13 03:46:03 --> Output Class Initialized
INFO - 2024-12-13 03:46:03 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:03 --> CSRF cookie sent
INFO - 2024-12-13 03:46:03 --> Input Class Initialized
INFO - 2024-12-13 03:46:03 --> Language Class Initialized
INFO - 2024-12-13 03:46:03 --> Loader Class Initialized
INFO - 2024-12-13 03:46:03 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:03 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:03 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:03 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:03 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:03 --> Controller Class Initialized
INFO - 2024-12-13 03:46:03 --> Model "User_model" initialized
DEBUG - 2024-12-13 03:46:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:46:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:46:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:46:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-13 03:46:03 --> Final output sent to browser
DEBUG - 2024-12-13 03:46:03 --> Total execution time: 0.3494
INFO - 2024-12-13 03:46:23 --> Config Class Initialized
INFO - 2024-12-13 03:46:23 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:23 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:23 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:23 --> URI Class Initialized
INFO - 2024-12-13 03:46:23 --> Router Class Initialized
INFO - 2024-12-13 03:46:23 --> Output Class Initialized
INFO - 2024-12-13 03:46:23 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:23 --> CSRF cookie sent
INFO - 2024-12-13 03:46:23 --> Input Class Initialized
INFO - 2024-12-13 03:46:23 --> Language Class Initialized
INFO - 2024-12-13 03:46:23 --> Loader Class Initialized
INFO - 2024-12-13 03:46:23 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:23 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:23 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:23 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:23 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:23 --> Controller Class Initialized
INFO - 2024-12-13 03:46:23 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "News_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:23 --> Config Class Initialized
INFO - 2024-12-13 03:46:23 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:23 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:23 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:23 --> URI Class Initialized
INFO - 2024-12-13 03:46:23 --> Router Class Initialized
INFO - 2024-12-13 03:46:23 --> Output Class Initialized
INFO - 2024-12-13 03:46:23 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:23 --> CSRF cookie sent
INFO - 2024-12-13 03:46:23 --> Input Class Initialized
INFO - 2024-12-13 03:46:23 --> Language Class Initialized
INFO - 2024-12-13 03:46:23 --> Loader Class Initialized
INFO - 2024-12-13 03:46:23 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:23 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:23 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:23 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:23 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:23 --> Controller Class Initialized
INFO - 2024-12-13 03:46:23 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "News_model" initialized
INFO - 2024-12-13 03:46:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:46:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:46:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 03:46:23 --> Final output sent to browser
DEBUG - 2024-12-13 03:46:23 --> Total execution time: 0.3034
INFO - 2024-12-13 03:46:27 --> Config Class Initialized
INFO - 2024-12-13 03:46:27 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:27 --> URI Class Initialized
INFO - 2024-12-13 03:46:27 --> Router Class Initialized
INFO - 2024-12-13 03:46:27 --> Output Class Initialized
INFO - 2024-12-13 03:46:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:27 --> CSRF cookie sent
INFO - 2024-12-13 03:46:27 --> Input Class Initialized
INFO - 2024-12-13 03:46:27 --> Language Class Initialized
INFO - 2024-12-13 03:46:27 --> Loader Class Initialized
INFO - 2024-12-13 03:46:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:27 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:27 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:27 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:27 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:27 --> Controller Class Initialized
INFO - 2024-12-13 03:46:27 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:27 --> Config Class Initialized
INFO - 2024-12-13 03:46:27 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:27 --> URI Class Initialized
INFO - 2024-12-13 03:46:27 --> Router Class Initialized
INFO - 2024-12-13 03:46:27 --> Output Class Initialized
INFO - 2024-12-13 03:46:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:27 --> CSRF cookie sent
INFO - 2024-12-13 03:46:27 --> Input Class Initialized
INFO - 2024-12-13 03:46:27 --> Language Class Initialized
INFO - 2024-12-13 03:46:27 --> Loader Class Initialized
INFO - 2024-12-13 03:46:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:27 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:27 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:27 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:27 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:27 --> Controller Class Initialized
INFO - 2024-12-13 03:46:27 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:46:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:46:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:46:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-13 03:46:27 --> Final output sent to browser
DEBUG - 2024-12-13 03:46:27 --> Total execution time: 0.0812
INFO - 2024-12-13 03:46:33 --> Config Class Initialized
INFO - 2024-12-13 03:46:33 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:33 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:33 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:33 --> URI Class Initialized
INFO - 2024-12-13 03:46:33 --> Router Class Initialized
INFO - 2024-12-13 03:46:33 --> Output Class Initialized
INFO - 2024-12-13 03:46:33 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:33 --> CSRF cookie sent
INFO - 2024-12-13 03:46:33 --> CSRF token verified
INFO - 2024-12-13 03:46:33 --> Input Class Initialized
INFO - 2024-12-13 03:46:33 --> Language Class Initialized
INFO - 2024-12-13 03:46:33 --> Loader Class Initialized
INFO - 2024-12-13 03:46:33 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:33 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:33 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:33 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:33 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:33 --> Controller Class Initialized
INFO - 2024-12-13 03:46:33 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:33 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:33 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:33 --> Model "News_model" initialized
INFO - 2024-12-13 03:46:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:34 --> Config Class Initialized
INFO - 2024-12-13 03:46:34 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:34 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:34 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:34 --> URI Class Initialized
INFO - 2024-12-13 03:46:34 --> Router Class Initialized
INFO - 2024-12-13 03:46:34 --> Output Class Initialized
INFO - 2024-12-13 03:46:34 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:34 --> CSRF cookie sent
INFO - 2024-12-13 03:46:34 --> Input Class Initialized
INFO - 2024-12-13 03:46:34 --> Language Class Initialized
INFO - 2024-12-13 03:46:34 --> Loader Class Initialized
INFO - 2024-12-13 03:46:34 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:34 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:34 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:34 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:34 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:34 --> Controller Class Initialized
INFO - 2024-12-13 03:46:34 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:34 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:34 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:46:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:46:34 --> Query result: stdClass Object
(
    [view_count] => 173
)

INFO - 2024-12-13 03:46:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-13 03:46:34 --> Final output sent to browser
DEBUG - 2024-12-13 03:46:34 --> Total execution time: 0.1042
INFO - 2024-12-13 03:46:58 --> Config Class Initialized
INFO - 2024-12-13 03:46:58 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:46:58 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:46:58 --> Utf8 Class Initialized
INFO - 2024-12-13 03:46:58 --> URI Class Initialized
INFO - 2024-12-13 03:46:58 --> Router Class Initialized
INFO - 2024-12-13 03:46:58 --> Output Class Initialized
INFO - 2024-12-13 03:46:59 --> Security Class Initialized
DEBUG - 2024-12-13 03:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:46:59 --> CSRF cookie sent
INFO - 2024-12-13 03:46:59 --> Input Class Initialized
INFO - 2024-12-13 03:46:59 --> Language Class Initialized
INFO - 2024-12-13 03:46:59 --> Loader Class Initialized
INFO - 2024-12-13 03:46:59 --> Helper loaded: url_helper
INFO - 2024-12-13 03:46:59 --> Helper loaded: form_helper
INFO - 2024-12-13 03:46:59 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:46:59 --> Form Validation Class Initialized
INFO - 2024-12-13 03:46:59 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:46:59 --> Controller Class Initialized
INFO - 2024-12-13 03:46:59 --> Model "Review_model" initialized
INFO - 2024-12-13 03:46:59 --> Model "Category_model" initialized
INFO - 2024-12-13 03:46:59 --> Model "User_model" initialized
INFO - 2024-12-13 03:46:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:46:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:46:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:46:59 --> Final output sent to browser
DEBUG - 2024-12-13 03:46:59 --> Total execution time: 0.1182
INFO - 2024-12-13 03:47:03 --> Config Class Initialized
INFO - 2024-12-13 03:47:03 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:03 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:03 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:03 --> URI Class Initialized
INFO - 2024-12-13 03:47:03 --> Router Class Initialized
INFO - 2024-12-13 03:47:03 --> Output Class Initialized
INFO - 2024-12-13 03:47:03 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:03 --> CSRF cookie sent
INFO - 2024-12-13 03:47:03 --> Input Class Initialized
INFO - 2024-12-13 03:47:03 --> Language Class Initialized
INFO - 2024-12-13 03:47:03 --> Loader Class Initialized
INFO - 2024-12-13 03:47:03 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:03 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:03 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:03 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:03 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:03 --> Controller Class Initialized
INFO - 2024-12-13 03:47:03 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:03 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:03 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:03 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kategori.php
INFO - 2024-12-13 03:47:03 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:03 --> Total execution time: 0.1348
INFO - 2024-12-13 03:47:12 --> Config Class Initialized
INFO - 2024-12-13 03:47:12 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:12 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:12 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:12 --> URI Class Initialized
INFO - 2024-12-13 03:47:12 --> Router Class Initialized
INFO - 2024-12-13 03:47:12 --> Output Class Initialized
INFO - 2024-12-13 03:47:12 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:12 --> CSRF cookie sent
INFO - 2024-12-13 03:47:12 --> CSRF token verified
INFO - 2024-12-13 03:47:12 --> Input Class Initialized
INFO - 2024-12-13 03:47:12 --> Language Class Initialized
INFO - 2024-12-13 03:47:12 --> Loader Class Initialized
INFO - 2024-12-13 03:47:12 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:12 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:12 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:12 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:12 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:12 --> Controller Class Initialized
INFO - 2024-12-13 03:47:12 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:12 --> Config Class Initialized
INFO - 2024-12-13 03:47:12 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:12 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:12 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:12 --> URI Class Initialized
INFO - 2024-12-13 03:47:12 --> Router Class Initialized
INFO - 2024-12-13 03:47:12 --> Output Class Initialized
INFO - 2024-12-13 03:47:12 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:12 --> CSRF cookie sent
INFO - 2024-12-13 03:47:12 --> Input Class Initialized
INFO - 2024-12-13 03:47:12 --> Language Class Initialized
INFO - 2024-12-13 03:47:12 --> Loader Class Initialized
INFO - 2024-12-13 03:47:12 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:12 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:12 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:12 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:12 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:12 --> Controller Class Initialized
INFO - 2024-12-13 03:47:12 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:47:12 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:12 --> Total execution time: 0.0609
INFO - 2024-12-13 03:47:16 --> Config Class Initialized
INFO - 2024-12-13 03:47:16 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:16 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:16 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:16 --> URI Class Initialized
INFO - 2024-12-13 03:47:16 --> Router Class Initialized
INFO - 2024-12-13 03:47:16 --> Output Class Initialized
INFO - 2024-12-13 03:47:16 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:16 --> CSRF cookie sent
INFO - 2024-12-13 03:47:16 --> Input Class Initialized
INFO - 2024-12-13 03:47:16 --> Language Class Initialized
INFO - 2024-12-13 03:47:16 --> Loader Class Initialized
INFO - 2024-12-13 03:47:16 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:16 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:16 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:16 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:16 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:16 --> Controller Class Initialized
INFO - 2024-12-13 03:47:16 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:16 --> Config Class Initialized
INFO - 2024-12-13 03:47:16 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:16 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:16 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:16 --> URI Class Initialized
INFO - 2024-12-13 03:47:16 --> Router Class Initialized
INFO - 2024-12-13 03:47:16 --> Output Class Initialized
INFO - 2024-12-13 03:47:16 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:16 --> CSRF cookie sent
INFO - 2024-12-13 03:47:16 --> Input Class Initialized
INFO - 2024-12-13 03:47:16 --> Language Class Initialized
INFO - 2024-12-13 03:47:16 --> Loader Class Initialized
INFO - 2024-12-13 03:47:16 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:16 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:16 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:16 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:16 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:16 --> Controller Class Initialized
INFO - 2024-12-13 03:47:16 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-13 03:47:16 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:16 --> Total execution time: 0.0833
INFO - 2024-12-13 03:47:19 --> Config Class Initialized
INFO - 2024-12-13 03:47:19 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:19 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:19 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:19 --> URI Class Initialized
INFO - 2024-12-13 03:47:19 --> Router Class Initialized
INFO - 2024-12-13 03:47:19 --> Output Class Initialized
INFO - 2024-12-13 03:47:19 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:19 --> CSRF cookie sent
INFO - 2024-12-13 03:47:19 --> Input Class Initialized
INFO - 2024-12-13 03:47:19 --> Language Class Initialized
INFO - 2024-12-13 03:47:19 --> Loader Class Initialized
INFO - 2024-12-13 03:47:19 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:19 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:19 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:19 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:19 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:19 --> Controller Class Initialized
INFO - 2024-12-13 03:47:19 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:19 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:19 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:19 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-13 03:47:19 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:19 --> Total execution time: 0.0751
INFO - 2024-12-13 03:47:24 --> Config Class Initialized
INFO - 2024-12-13 03:47:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:24 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:24 --> URI Class Initialized
INFO - 2024-12-13 03:47:24 --> Router Class Initialized
INFO - 2024-12-13 03:47:24 --> Output Class Initialized
INFO - 2024-12-13 03:47:24 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:24 --> CSRF cookie sent
INFO - 2024-12-13 03:47:24 --> Input Class Initialized
INFO - 2024-12-13 03:47:24 --> Language Class Initialized
INFO - 2024-12-13 03:47:24 --> Loader Class Initialized
INFO - 2024-12-13 03:47:24 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:24 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:24 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:24 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:24 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:24 --> Controller Class Initialized
INFO - 2024-12-13 03:47:24 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:24 --> User data with ID 15 successfully deleted.
INFO - 2024-12-13 03:47:24 --> Config Class Initialized
INFO - 2024-12-13 03:47:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:24 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:24 --> URI Class Initialized
INFO - 2024-12-13 03:47:24 --> Router Class Initialized
INFO - 2024-12-13 03:47:24 --> Output Class Initialized
INFO - 2024-12-13 03:47:24 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:24 --> CSRF cookie sent
INFO - 2024-12-13 03:47:24 --> Input Class Initialized
INFO - 2024-12-13 03:47:24 --> Language Class Initialized
INFO - 2024-12-13 03:47:24 --> Loader Class Initialized
INFO - 2024-12-13 03:47:24 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:24 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:24 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:24 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:24 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:24 --> Controller Class Initialized
INFO - 2024-12-13 03:47:24 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-13 03:47:24 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:24 --> Total execution time: 0.0729
INFO - 2024-12-13 03:47:27 --> Config Class Initialized
INFO - 2024-12-13 03:47:27 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:27 --> URI Class Initialized
INFO - 2024-12-13 03:47:27 --> Router Class Initialized
INFO - 2024-12-13 03:47:27 --> Output Class Initialized
INFO - 2024-12-13 03:47:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:27 --> CSRF cookie sent
INFO - 2024-12-13 03:47:27 --> Input Class Initialized
INFO - 2024-12-13 03:47:27 --> Language Class Initialized
INFO - 2024-12-13 03:47:27 --> Loader Class Initialized
INFO - 2024-12-13 03:47:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:27 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:27 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:27 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:27 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:27 --> Controller Class Initialized
INFO - 2024-12-13 03:47:27 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:27 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:27 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:47:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:47:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-13 03:47:27 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:27 --> Total execution time: 0.0917
INFO - 2024-12-13 03:47:29 --> Config Class Initialized
INFO - 2024-12-13 03:47:29 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:29 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:29 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:29 --> URI Class Initialized
INFO - 2024-12-13 03:47:29 --> Router Class Initialized
INFO - 2024-12-13 03:47:29 --> Output Class Initialized
INFO - 2024-12-13 03:47:29 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:29 --> CSRF cookie sent
INFO - 2024-12-13 03:47:29 --> Input Class Initialized
INFO - 2024-12-13 03:47:29 --> Language Class Initialized
INFO - 2024-12-13 03:47:29 --> Loader Class Initialized
INFO - 2024-12-13 03:47:29 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:29 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:29 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:29 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:29 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:29 --> Controller Class Initialized
INFO - 2024-12-13 03:47:29 --> Model "News_model" initialized
INFO - 2024-12-13 03:47:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-13 03:47:29 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:29 --> Total execution time: 0.1452
INFO - 2024-12-13 03:47:35 --> Config Class Initialized
INFO - 2024-12-13 03:47:35 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:35 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:35 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:35 --> URI Class Initialized
INFO - 2024-12-13 03:47:35 --> Router Class Initialized
INFO - 2024-12-13 03:47:35 --> Output Class Initialized
INFO - 2024-12-13 03:47:35 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:35 --> CSRF cookie sent
INFO - 2024-12-13 03:47:35 --> Input Class Initialized
INFO - 2024-12-13 03:47:35 --> Language Class Initialized
INFO - 2024-12-13 03:47:35 --> Loader Class Initialized
INFO - 2024-12-13 03:47:35 --> Helper loaded: url_helper
INFO - 2024-12-13 03:47:35 --> Helper loaded: form_helper
INFO - 2024-12-13 03:47:35 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:47:35 --> Form Validation Class Initialized
INFO - 2024-12-13 03:47:35 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:47:35 --> Controller Class Initialized
INFO - 2024-12-13 03:47:35 --> Model "User_model" initialized
INFO - 2024-12-13 03:47:35 --> Model "Category_model" initialized
INFO - 2024-12-13 03:47:35 --> Model "Review_model" initialized
INFO - 2024-12-13 03:47:35 --> Model "News_model" initialized
INFO - 2024-12-13 03:47:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:47:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 03:47:35 --> Query result: stdClass Object
(
    [view_count] => 174
)

INFO - 2024-12-13 03:47:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 03:47:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 03:47:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 03:47:35 --> Final output sent to browser
DEBUG - 2024-12-13 03:47:35 --> Total execution time: 0.1723
INFO - 2024-12-13 03:47:37 --> Config Class Initialized
INFO - 2024-12-13 03:47:37 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:47:37 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:47:37 --> Utf8 Class Initialized
INFO - 2024-12-13 03:47:37 --> URI Class Initialized
INFO - 2024-12-13 03:47:37 --> Router Class Initialized
INFO - 2024-12-13 03:47:37 --> Output Class Initialized
INFO - 2024-12-13 03:47:37 --> Security Class Initialized
DEBUG - 2024-12-13 03:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:47:37 --> CSRF cookie sent
INFO - 2024-12-13 03:47:37 --> Input Class Initialized
INFO - 2024-12-13 03:47:37 --> Language Class Initialized
ERROR - 2024-12-13 03:47:37 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-13 03:48:02 --> Config Class Initialized
INFO - 2024-12-13 03:48:02 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:48:02 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:48:02 --> Utf8 Class Initialized
INFO - 2024-12-13 03:48:02 --> URI Class Initialized
INFO - 2024-12-13 03:48:02 --> Router Class Initialized
INFO - 2024-12-13 03:48:02 --> Output Class Initialized
INFO - 2024-12-13 03:48:02 --> Security Class Initialized
DEBUG - 2024-12-13 03:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:48:02 --> CSRF cookie sent
INFO - 2024-12-13 03:48:02 --> Input Class Initialized
INFO - 2024-12-13 03:48:02 --> Language Class Initialized
INFO - 2024-12-13 03:48:02 --> Loader Class Initialized
INFO - 2024-12-13 03:48:02 --> Helper loaded: url_helper
INFO - 2024-12-13 03:48:02 --> Helper loaded: form_helper
INFO - 2024-12-13 03:48:02 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:48:03 --> Form Validation Class Initialized
INFO - 2024-12-13 03:48:03 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:48:03 --> Controller Class Initialized
INFO - 2024-12-13 03:48:03 --> Model "News_model" initialized
INFO - 2024-12-13 03:48:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-13 03:48:03 --> Final output sent to browser
DEBUG - 2024-12-13 03:48:03 --> Total execution time: 1.4965
INFO - 2024-12-13 03:48:12 --> Config Class Initialized
INFO - 2024-12-13 03:48:12 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:48:12 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:48:12 --> Utf8 Class Initialized
INFO - 2024-12-13 03:48:12 --> URI Class Initialized
INFO - 2024-12-13 03:48:13 --> Router Class Initialized
INFO - 2024-12-13 03:48:13 --> Output Class Initialized
INFO - 2024-12-13 03:48:13 --> Security Class Initialized
DEBUG - 2024-12-13 03:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:48:13 --> CSRF cookie sent
INFO - 2024-12-13 03:48:13 --> Input Class Initialized
INFO - 2024-12-13 03:48:13 --> Language Class Initialized
INFO - 2024-12-13 03:48:13 --> Loader Class Initialized
INFO - 2024-12-13 03:48:13 --> Helper loaded: url_helper
INFO - 2024-12-13 03:48:13 --> Helper loaded: form_helper
INFO - 2024-12-13 03:48:13 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:48:13 --> Form Validation Class Initialized
INFO - 2024-12-13 03:48:13 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:48:13 --> Controller Class Initialized
INFO - 2024-12-13 03:48:13 --> Model "Review_model" initialized
INFO - 2024-12-13 03:48:13 --> Model "Category_model" initialized
INFO - 2024-12-13 03:48:13 --> Model "User_model" initialized
INFO - 2024-12-13 03:48:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:48:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:48:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-13 03:48:14 --> Final output sent to browser
DEBUG - 2024-12-13 03:48:14 --> Total execution time: 1.7028
INFO - 2024-12-13 03:48:26 --> Config Class Initialized
INFO - 2024-12-13 03:48:26 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:48:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:48:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:48:27 --> URI Class Initialized
INFO - 2024-12-13 03:48:27 --> Router Class Initialized
INFO - 2024-12-13 03:48:27 --> Output Class Initialized
INFO - 2024-12-13 03:48:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:48:27 --> CSRF cookie sent
INFO - 2024-12-13 03:48:27 --> Input Class Initialized
INFO - 2024-12-13 03:48:27 --> Language Class Initialized
INFO - 2024-12-13 03:48:27 --> Loader Class Initialized
INFO - 2024-12-13 03:48:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:48:27 --> Helper loaded: form_helper
INFO - 2024-12-13 03:48:28 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:48:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:48:28 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:48:28 --> Controller Class Initialized
INFO - 2024-12-13 03:48:28 --> Model "Review_model" initialized
INFO - 2024-12-13 03:48:28 --> Model "Category_model" initialized
INFO - 2024-12-13 03:48:28 --> Model "User_model" initialized
INFO - 2024-12-13 03:48:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:48:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:48:29 --> Config Class Initialized
INFO - 2024-12-13 03:48:29 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:48:29 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:48:29 --> Utf8 Class Initialized
INFO - 2024-12-13 03:48:29 --> URI Class Initialized
INFO - 2024-12-13 03:48:29 --> Router Class Initialized
INFO - 2024-12-13 03:48:29 --> Output Class Initialized
INFO - 2024-12-13 03:48:29 --> Security Class Initialized
DEBUG - 2024-12-13 03:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:48:29 --> CSRF cookie sent
INFO - 2024-12-13 03:48:29 --> Input Class Initialized
INFO - 2024-12-13 03:48:29 --> Language Class Initialized
INFO - 2024-12-13 03:48:29 --> Loader Class Initialized
INFO - 2024-12-13 03:48:29 --> Helper loaded: url_helper
INFO - 2024-12-13 03:48:29 --> Helper loaded: form_helper
INFO - 2024-12-13 03:48:29 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:48:29 --> Form Validation Class Initialized
INFO - 2024-12-13 03:48:29 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:48:29 --> Controller Class Initialized
INFO - 2024-12-13 03:48:29 --> Model "Review_model" initialized
INFO - 2024-12-13 03:48:29 --> Model "Category_model" initialized
INFO - 2024-12-13 03:48:29 --> Model "User_model" initialized
INFO - 2024-12-13 03:48:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:48:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:48:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-13 03:48:29 --> Final output sent to browser
DEBUG - 2024-12-13 03:48:29 --> Total execution time: 0.2434
INFO - 2024-12-13 03:48:36 --> Config Class Initialized
INFO - 2024-12-13 03:48:36 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:48:36 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:48:36 --> Utf8 Class Initialized
INFO - 2024-12-13 03:48:36 --> URI Class Initialized
INFO - 2024-12-13 03:48:36 --> Router Class Initialized
INFO - 2024-12-13 03:48:36 --> Output Class Initialized
INFO - 2024-12-13 03:48:36 --> Security Class Initialized
DEBUG - 2024-12-13 03:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:48:36 --> CSRF cookie sent
INFO - 2024-12-13 03:48:36 --> Input Class Initialized
INFO - 2024-12-13 03:48:37 --> Language Class Initialized
INFO - 2024-12-13 03:48:37 --> Loader Class Initialized
INFO - 2024-12-13 03:48:37 --> Helper loaded: url_helper
INFO - 2024-12-13 03:48:37 --> Helper loaded: form_helper
INFO - 2024-12-13 03:48:37 --> Database Driver Class Initialized
DEBUG - 2024-12-13 03:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:48:37 --> Form Validation Class Initialized
INFO - 2024-12-13 03:48:37 --> Model "Culinary_model" initialized
INFO - 2024-12-13 03:48:37 --> Controller Class Initialized
INFO - 2024-12-13 03:48:37 --> Model "Review_model" initialized
INFO - 2024-12-13 03:48:37 --> Model "Category_model" initialized
INFO - 2024-12-13 03:48:37 --> Model "User_model" initialized
INFO - 2024-12-13 03:48:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 03:48:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 03:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:48:37 --> Model "Contact_model" initialized
INFO - 2024-12-13 03:48:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-13 03:48:37 --> Final output sent to browser
DEBUG - 2024-12-13 03:48:37 --> Total execution time: 1.4414
INFO - 2024-12-13 05:04:08 --> Config Class Initialized
INFO - 2024-12-13 05:04:08 --> Hooks Class Initialized
DEBUG - 2024-12-13 05:04:09 --> UTF-8 Support Enabled
INFO - 2024-12-13 05:04:09 --> Utf8 Class Initialized
INFO - 2024-12-13 05:04:09 --> URI Class Initialized
INFO - 2024-12-13 05:04:09 --> Router Class Initialized
INFO - 2024-12-13 05:04:09 --> Output Class Initialized
INFO - 2024-12-13 05:04:09 --> Security Class Initialized
DEBUG - 2024-12-13 05:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 05:04:09 --> CSRF cookie sent
INFO - 2024-12-13 05:04:09 --> Input Class Initialized
INFO - 2024-12-13 05:04:09 --> Language Class Initialized
INFO - 2024-12-13 05:04:09 --> Loader Class Initialized
INFO - 2024-12-13 05:04:09 --> Helper loaded: url_helper
INFO - 2024-12-13 05:04:09 --> Helper loaded: form_helper
INFO - 2024-12-13 05:04:09 --> Database Driver Class Initialized
DEBUG - 2024-12-13 05:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 05:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 05:04:09 --> Form Validation Class Initialized
INFO - 2024-12-13 05:04:09 --> Model "Culinary_model" initialized
INFO - 2024-12-13 05:04:09 --> Controller Class Initialized
INFO - 2024-12-13 05:04:09 --> Model "Review_model" initialized
INFO - 2024-12-13 05:04:09 --> Model "Category_model" initialized
INFO - 2024-12-13 05:04:09 --> Model "User_model" initialized
INFO - 2024-12-13 05:04:09 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 05:04:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 05:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 05:04:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-13 05:04:09 --> Final output sent to browser
DEBUG - 2024-12-13 05:04:09 --> Total execution time: 1.0683
INFO - 2024-12-13 05:04:13 --> Config Class Initialized
INFO - 2024-12-13 05:04:13 --> Hooks Class Initialized
DEBUG - 2024-12-13 05:04:13 --> UTF-8 Support Enabled
INFO - 2024-12-13 05:04:13 --> Utf8 Class Initialized
INFO - 2024-12-13 05:04:13 --> URI Class Initialized
INFO - 2024-12-13 05:04:13 --> Router Class Initialized
INFO - 2024-12-13 05:04:13 --> Output Class Initialized
INFO - 2024-12-13 05:04:13 --> Security Class Initialized
DEBUG - 2024-12-13 05:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 05:04:13 --> CSRF cookie sent
INFO - 2024-12-13 05:04:13 --> Input Class Initialized
INFO - 2024-12-13 05:04:13 --> Language Class Initialized
INFO - 2024-12-13 05:04:13 --> Loader Class Initialized
INFO - 2024-12-13 05:04:13 --> Helper loaded: url_helper
INFO - 2024-12-13 05:04:13 --> Helper loaded: form_helper
INFO - 2024-12-13 05:04:13 --> Database Driver Class Initialized
DEBUG - 2024-12-13 05:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 05:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 05:04:13 --> Form Validation Class Initialized
INFO - 2024-12-13 05:04:13 --> Model "Culinary_model" initialized
INFO - 2024-12-13 05:04:13 --> Controller Class Initialized
INFO - 2024-12-13 05:04:13 --> Model "Review_model" initialized
INFO - 2024-12-13 05:04:13 --> Model "Category_model" initialized
INFO - 2024-12-13 05:04:13 --> Model "User_model" initialized
INFO - 2024-12-13 05:04:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 05:04:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 05:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 05:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-12-13 05:04:13 --> Pagination Class Initialized
INFO - 2024-12-13 05:04:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-13 05:04:13 --> Final output sent to browser
DEBUG - 2024-12-13 05:04:13 --> Total execution time: 0.2052
INFO - 2024-12-13 05:04:16 --> Config Class Initialized
INFO - 2024-12-13 05:04:16 --> Hooks Class Initialized
DEBUG - 2024-12-13 05:04:16 --> UTF-8 Support Enabled
INFO - 2024-12-13 05:04:16 --> Utf8 Class Initialized
INFO - 2024-12-13 05:04:16 --> URI Class Initialized
INFO - 2024-12-13 05:04:16 --> Router Class Initialized
INFO - 2024-12-13 05:04:16 --> Output Class Initialized
INFO - 2024-12-13 05:04:16 --> Security Class Initialized
DEBUG - 2024-12-13 05:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 05:04:16 --> CSRF cookie sent
INFO - 2024-12-13 05:04:16 --> Input Class Initialized
INFO - 2024-12-13 05:04:16 --> Language Class Initialized
INFO - 2024-12-13 05:04:16 --> Loader Class Initialized
INFO - 2024-12-13 05:04:16 --> Helper loaded: url_helper
INFO - 2024-12-13 05:04:16 --> Helper loaded: form_helper
INFO - 2024-12-13 05:04:16 --> Database Driver Class Initialized
DEBUG - 2024-12-13 05:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 05:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 05:04:16 --> Form Validation Class Initialized
INFO - 2024-12-13 05:04:16 --> Model "Culinary_model" initialized
INFO - 2024-12-13 05:04:16 --> Controller Class Initialized
INFO - 2024-12-13 05:04:16 --> Model "Review_model" initialized
INFO - 2024-12-13 05:04:16 --> Model "Category_model" initialized
INFO - 2024-12-13 05:04:16 --> Model "User_model" initialized
INFO - 2024-12-13 05:04:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-13 05:04:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 05:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 05:04:16 --> Model "Contact_model" initialized
INFO - 2024-12-13 05:04:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-13 05:04:16 --> Final output sent to browser
DEBUG - 2024-12-13 05:04:16 --> Total execution time: 0.1568
INFO - 2024-12-13 06:16:25 --> Config Class Initialized
INFO - 2024-12-13 06:16:25 --> Hooks Class Initialized
DEBUG - 2024-12-13 06:16:25 --> UTF-8 Support Enabled
INFO - 2024-12-13 06:16:25 --> Utf8 Class Initialized
INFO - 2024-12-13 06:16:25 --> URI Class Initialized
DEBUG - 2024-12-13 06:16:25 --> No URI present. Default controller set.
INFO - 2024-12-13 06:16:25 --> Router Class Initialized
INFO - 2024-12-13 06:16:25 --> Output Class Initialized
INFO - 2024-12-13 06:16:25 --> Security Class Initialized
DEBUG - 2024-12-13 06:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 06:16:25 --> CSRF cookie sent
INFO - 2024-12-13 06:16:25 --> Input Class Initialized
INFO - 2024-12-13 06:16:25 --> Language Class Initialized
INFO - 2024-12-13 06:16:25 --> Loader Class Initialized
INFO - 2024-12-13 06:16:25 --> Helper loaded: url_helper
INFO - 2024-12-13 06:16:25 --> Helper loaded: form_helper
INFO - 2024-12-13 06:16:25 --> Database Driver Class Initialized
DEBUG - 2024-12-13 06:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 06:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 06:16:26 --> Form Validation Class Initialized
INFO - 2024-12-13 06:16:26 --> Model "Culinary_model" initialized
INFO - 2024-12-13 06:16:26 --> Controller Class Initialized
INFO - 2024-12-13 06:16:26 --> Model "User_model" initialized
INFO - 2024-12-13 06:16:26 --> Model "Category_model" initialized
INFO - 2024-12-13 06:16:26 --> Model "Review_model" initialized
INFO - 2024-12-13 06:16:26 --> Model "News_model" initialized
INFO - 2024-12-13 06:16:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 06:16:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 06:16:26 --> Query result: stdClass Object
(
    [view_count] => 175
)

INFO - 2024-12-13 06:16:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 06:16:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 06:16:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 06:16:26 --> Final output sent to browser
DEBUG - 2024-12-13 06:16:26 --> Total execution time: 1.2404
INFO - 2024-12-13 06:16:31 --> Config Class Initialized
INFO - 2024-12-13 06:16:31 --> Hooks Class Initialized
DEBUG - 2024-12-13 06:16:31 --> UTF-8 Support Enabled
INFO - 2024-12-13 06:16:31 --> Utf8 Class Initialized
INFO - 2024-12-13 06:16:31 --> URI Class Initialized
DEBUG - 2024-12-13 06:16:31 --> No URI present. Default controller set.
INFO - 2024-12-13 06:16:31 --> Router Class Initialized
INFO - 2024-12-13 06:16:31 --> Output Class Initialized
INFO - 2024-12-13 06:16:31 --> Security Class Initialized
DEBUG - 2024-12-13 06:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 06:16:31 --> CSRF cookie sent
INFO - 2024-12-13 06:16:31 --> Input Class Initialized
INFO - 2024-12-13 06:16:31 --> Language Class Initialized
INFO - 2024-12-13 06:16:31 --> Loader Class Initialized
INFO - 2024-12-13 06:16:31 --> Helper loaded: url_helper
INFO - 2024-12-13 06:16:31 --> Helper loaded: form_helper
INFO - 2024-12-13 06:16:31 --> Database Driver Class Initialized
DEBUG - 2024-12-13 06:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 06:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 06:16:31 --> Form Validation Class Initialized
INFO - 2024-12-13 06:16:31 --> Model "Culinary_model" initialized
INFO - 2024-12-13 06:16:31 --> Controller Class Initialized
INFO - 2024-12-13 06:16:31 --> Model "User_model" initialized
INFO - 2024-12-13 06:16:31 --> Model "Category_model" initialized
INFO - 2024-12-13 06:16:31 --> Model "Review_model" initialized
INFO - 2024-12-13 06:16:31 --> Model "News_model" initialized
INFO - 2024-12-13 06:16:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 06:16:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 06:16:31 --> Query result: stdClass Object
(
    [view_count] => 176
)

INFO - 2024-12-13 06:16:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 06:16:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 06:16:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 06:16:31 --> Final output sent to browser
DEBUG - 2024-12-13 06:16:31 --> Total execution time: 0.2683
INFO - 2024-12-13 06:17:20 --> Config Class Initialized
INFO - 2024-12-13 06:17:20 --> Hooks Class Initialized
DEBUG - 2024-12-13 06:17:20 --> UTF-8 Support Enabled
INFO - 2024-12-13 06:17:20 --> Utf8 Class Initialized
INFO - 2024-12-13 06:17:20 --> URI Class Initialized
INFO - 2024-12-13 06:17:20 --> Router Class Initialized
INFO - 2024-12-13 06:17:20 --> Output Class Initialized
INFO - 2024-12-13 06:17:20 --> Security Class Initialized
DEBUG - 2024-12-13 06:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 06:17:20 --> CSRF cookie sent
INFO - 2024-12-13 06:17:20 --> Input Class Initialized
INFO - 2024-12-13 06:17:20 --> Language Class Initialized
INFO - 2024-12-13 06:17:20 --> Loader Class Initialized
INFO - 2024-12-13 06:17:20 --> Helper loaded: url_helper
INFO - 2024-12-13 06:17:20 --> Helper loaded: form_helper
INFO - 2024-12-13 06:17:20 --> Database Driver Class Initialized
DEBUG - 2024-12-13 06:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 06:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 06:17:20 --> Form Validation Class Initialized
INFO - 2024-12-13 06:17:20 --> Model "Culinary_model" initialized
INFO - 2024-12-13 06:17:20 --> Controller Class Initialized
INFO - 2024-12-13 06:17:20 --> Model "User_model" initialized
INFO - 2024-12-13 06:17:20 --> Model "Category_model" initialized
INFO - 2024-12-13 06:17:20 --> Model "Review_model" initialized
INFO - 2024-12-13 06:17:20 --> Model "News_model" initialized
INFO - 2024-12-13 06:17:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 06:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-13 06:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 06:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 06:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-13 06:17:20 --> Final output sent to browser
DEBUG - 2024-12-13 06:17:20 --> Total execution time: 0.4942
INFO - 2024-12-13 07:58:30 --> Config Class Initialized
INFO - 2024-12-13 07:58:30 --> Hooks Class Initialized
DEBUG - 2024-12-13 07:58:30 --> UTF-8 Support Enabled
INFO - 2024-12-13 07:58:30 --> Utf8 Class Initialized
INFO - 2024-12-13 07:58:30 --> URI Class Initialized
DEBUG - 2024-12-13 07:58:30 --> No URI present. Default controller set.
INFO - 2024-12-13 07:58:30 --> Router Class Initialized
INFO - 2024-12-13 07:58:30 --> Output Class Initialized
INFO - 2024-12-13 07:58:30 --> Security Class Initialized
DEBUG - 2024-12-13 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 07:58:31 --> CSRF cookie sent
INFO - 2024-12-13 07:58:31 --> Input Class Initialized
INFO - 2024-12-13 07:58:31 --> Language Class Initialized
INFO - 2024-12-13 07:58:31 --> Loader Class Initialized
INFO - 2024-12-13 07:58:31 --> Helper loaded: url_helper
INFO - 2024-12-13 07:58:31 --> Helper loaded: form_helper
INFO - 2024-12-13 07:58:31 --> Database Driver Class Initialized
DEBUG - 2024-12-13 07:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 07:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 07:58:31 --> Form Validation Class Initialized
INFO - 2024-12-13 07:58:31 --> Model "Culinary_model" initialized
INFO - 2024-12-13 07:58:31 --> Controller Class Initialized
INFO - 2024-12-13 07:58:31 --> Model "User_model" initialized
INFO - 2024-12-13 07:58:31 --> Model "Category_model" initialized
INFO - 2024-12-13 07:58:31 --> Model "Review_model" initialized
INFO - 2024-12-13 07:58:31 --> Model "News_model" initialized
INFO - 2024-12-13 07:58:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 07:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 07:58:31 --> Query result: stdClass Object
(
    [view_count] => 177
)

INFO - 2024-12-13 07:58:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 07:58:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 07:58:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 07:58:31 --> Final output sent to browser
DEBUG - 2024-12-13 07:58:31 --> Total execution time: 1.2408
INFO - 2024-12-13 10:32:13 --> Config Class Initialized
INFO - 2024-12-13 10:32:13 --> Hooks Class Initialized
DEBUG - 2024-12-13 10:32:13 --> UTF-8 Support Enabled
INFO - 2024-12-13 10:32:13 --> Utf8 Class Initialized
INFO - 2024-12-13 10:32:13 --> URI Class Initialized
DEBUG - 2024-12-13 10:32:13 --> No URI present. Default controller set.
INFO - 2024-12-13 10:32:13 --> Router Class Initialized
INFO - 2024-12-13 10:32:13 --> Output Class Initialized
INFO - 2024-12-13 10:32:13 --> Security Class Initialized
DEBUG - 2024-12-13 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 10:32:13 --> CSRF cookie sent
INFO - 2024-12-13 10:32:13 --> Input Class Initialized
INFO - 2024-12-13 10:32:13 --> Language Class Initialized
INFO - 2024-12-13 10:32:13 --> Loader Class Initialized
INFO - 2024-12-13 10:32:13 --> Helper loaded: url_helper
INFO - 2024-12-13 10:32:13 --> Helper loaded: form_helper
INFO - 2024-12-13 10:32:13 --> Database Driver Class Initialized
DEBUG - 2024-12-13 10:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 10:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 10:32:14 --> Form Validation Class Initialized
INFO - 2024-12-13 10:32:14 --> Model "Culinary_model" initialized
INFO - 2024-12-13 10:32:14 --> Controller Class Initialized
INFO - 2024-12-13 10:32:14 --> Model "User_model" initialized
INFO - 2024-12-13 10:32:14 --> Model "Category_model" initialized
INFO - 2024-12-13 10:32:14 --> Model "Review_model" initialized
INFO - 2024-12-13 10:32:14 --> Model "News_model" initialized
INFO - 2024-12-13 10:32:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 10:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 10:32:14 --> Query result: stdClass Object
(
    [view_count] => 178
)

INFO - 2024-12-13 10:32:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 10:32:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 10:32:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 10:32:14 --> Final output sent to browser
DEBUG - 2024-12-13 10:32:14 --> Total execution time: 1.1417
INFO - 2024-12-13 10:32:45 --> Config Class Initialized
INFO - 2024-12-13 10:32:45 --> Hooks Class Initialized
DEBUG - 2024-12-13 10:32:45 --> UTF-8 Support Enabled
INFO - 2024-12-13 10:32:45 --> Utf8 Class Initialized
INFO - 2024-12-13 10:32:45 --> URI Class Initialized
DEBUG - 2024-12-13 10:32:45 --> No URI present. Default controller set.
INFO - 2024-12-13 10:32:45 --> Router Class Initialized
INFO - 2024-12-13 10:32:45 --> Output Class Initialized
INFO - 2024-12-13 10:32:45 --> Security Class Initialized
DEBUG - 2024-12-13 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 10:32:45 --> CSRF cookie sent
INFO - 2024-12-13 10:32:45 --> Input Class Initialized
INFO - 2024-12-13 10:32:45 --> Language Class Initialized
INFO - 2024-12-13 10:32:45 --> Loader Class Initialized
INFO - 2024-12-13 10:32:45 --> Helper loaded: url_helper
INFO - 2024-12-13 10:32:45 --> Helper loaded: form_helper
INFO - 2024-12-13 10:32:45 --> Database Driver Class Initialized
DEBUG - 2024-12-13 10:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 10:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 10:32:46 --> Form Validation Class Initialized
INFO - 2024-12-13 10:32:46 --> Model "Culinary_model" initialized
INFO - 2024-12-13 10:32:46 --> Controller Class Initialized
INFO - 2024-12-13 10:32:46 --> Model "User_model" initialized
INFO - 2024-12-13 10:32:46 --> Model "Category_model" initialized
INFO - 2024-12-13 10:32:46 --> Model "Review_model" initialized
INFO - 2024-12-13 10:32:46 --> Model "News_model" initialized
INFO - 2024-12-13 10:32:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-13 10:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-13 10:32:46 --> Query result: stdClass Object
(
    [view_count] => 179
)

INFO - 2024-12-13 10:32:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-13 10:32:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-13 10:32:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-13 10:32:46 --> Final output sent to browser
DEBUG - 2024-12-13 10:32:46 --> Total execution time: 0.3380
