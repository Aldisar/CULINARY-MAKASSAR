<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-07 15:30:37 --> Config Class Initialized
INFO - 2024-12-07 15:30:37 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:37 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:37 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:37 --> URI Class Initialized
INFO - 2024-12-07 15:30:37 --> Router Class Initialized
INFO - 2024-12-07 15:30:37 --> Output Class Initialized
INFO - 2024-12-07 15:30:37 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:37 --> CSRF cookie sent
INFO - 2024-12-07 15:30:37 --> Input Class Initialized
INFO - 2024-12-07 15:30:37 --> Language Class Initialized
INFO - 2024-12-07 15:30:37 --> Loader Class Initialized
INFO - 2024-12-07 15:30:37 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:37 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:37 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:37 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:37 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:37 --> Controller Class Initialized
INFO - 2024-12-07 15:30:37 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:37 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:37 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:37 --> Model "News_model" initialized
INFO - 2024-12-07 15:30:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:30:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-07 15:30:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-07 15:30:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-07 15:30:37 --> Final output sent to browser
DEBUG - 2024-12-07 15:30:37 --> Total execution time: 0.4191
INFO - 2024-12-07 15:30:42 --> Config Class Initialized
INFO - 2024-12-07 15:30:42 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:42 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:42 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:42 --> URI Class Initialized
INFO - 2024-12-07 15:30:42 --> Router Class Initialized
INFO - 2024-12-07 15:30:42 --> Output Class Initialized
INFO - 2024-12-07 15:30:42 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:42 --> CSRF cookie sent
INFO - 2024-12-07 15:30:42 --> CSRF token verified
INFO - 2024-12-07 15:30:42 --> Input Class Initialized
INFO - 2024-12-07 15:30:42 --> Language Class Initialized
INFO - 2024-12-07 15:30:42 --> Loader Class Initialized
INFO - 2024-12-07 15:30:42 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:42 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:42 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:42 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:42 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:42 --> Controller Class Initialized
INFO - 2024-12-07 15:30:42 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "News_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:30:42 --> Config Class Initialized
INFO - 2024-12-07 15:30:42 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:42 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:42 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:42 --> URI Class Initialized
INFO - 2024-12-07 15:30:42 --> Router Class Initialized
INFO - 2024-12-07 15:30:42 --> Output Class Initialized
INFO - 2024-12-07 15:30:42 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:42 --> CSRF cookie sent
INFO - 2024-12-07 15:30:42 --> Input Class Initialized
INFO - 2024-12-07 15:30:42 --> Language Class Initialized
INFO - 2024-12-07 15:30:42 --> Loader Class Initialized
INFO - 2024-12-07 15:30:42 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:42 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:42 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:42 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:42 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:42 --> Controller Class Initialized
INFO - 2024-12-07 15:30:42 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:30:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-07 15:30:42 --> Query result: stdClass Object
(
    [view_count] => 96
)

INFO - 2024-12-07 15:30:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-07 15:30:42 --> Final output sent to browser
DEBUG - 2024-12-07 15:30:42 --> Total execution time: 0.0889
INFO - 2024-12-07 15:30:48 --> Config Class Initialized
INFO - 2024-12-07 15:30:48 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:48 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:48 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:48 --> URI Class Initialized
INFO - 2024-12-07 15:30:48 --> Router Class Initialized
INFO - 2024-12-07 15:30:48 --> Output Class Initialized
INFO - 2024-12-07 15:30:48 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:48 --> CSRF cookie sent
INFO - 2024-12-07 15:30:48 --> Input Class Initialized
INFO - 2024-12-07 15:30:48 --> Language Class Initialized
INFO - 2024-12-07 15:30:48 --> Loader Class Initialized
INFO - 2024-12-07 15:30:48 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:48 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:48 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:48 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:48 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:48 --> Controller Class Initialized
INFO - 2024-12-07 15:30:48 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:48 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:48 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:30:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:30:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-07 15:30:48 --> Final output sent to browser
DEBUG - 2024-12-07 15:30:48 --> Total execution time: 0.0847
INFO - 2024-12-07 15:30:54 --> Config Class Initialized
INFO - 2024-12-07 15:30:54 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:54 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:54 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:54 --> URI Class Initialized
INFO - 2024-12-07 15:30:54 --> Router Class Initialized
INFO - 2024-12-07 15:30:54 --> Output Class Initialized
INFO - 2024-12-07 15:30:54 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:54 --> CSRF cookie sent
INFO - 2024-12-07 15:30:54 --> Input Class Initialized
INFO - 2024-12-07 15:30:54 --> Language Class Initialized
INFO - 2024-12-07 15:30:54 --> Loader Class Initialized
INFO - 2024-12-07 15:30:54 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:54 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:54 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:54 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:54 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:54 --> Controller Class Initialized
INFO - 2024-12-07 15:30:54 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:54 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:54 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:30:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:30:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-07 15:30:54 --> Final output sent to browser
DEBUG - 2024-12-07 15:30:54 --> Total execution time: 0.0501
INFO - 2024-12-07 15:30:58 --> Config Class Initialized
INFO - 2024-12-07 15:30:58 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:58 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:58 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:58 --> URI Class Initialized
INFO - 2024-12-07 15:30:58 --> Router Class Initialized
INFO - 2024-12-07 15:30:58 --> Output Class Initialized
INFO - 2024-12-07 15:30:58 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:58 --> CSRF cookie sent
INFO - 2024-12-07 15:30:58 --> CSRF token verified
INFO - 2024-12-07 15:30:58 --> Input Class Initialized
INFO - 2024-12-07 15:30:58 --> Language Class Initialized
INFO - 2024-12-07 15:30:58 --> Loader Class Initialized
INFO - 2024-12-07 15:30:58 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:58 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:58 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:58 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:58 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:58 --> Controller Class Initialized
INFO - 2024-12-07 15:30:58 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:58 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:58 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:30:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:30:59 --> Config Class Initialized
INFO - 2024-12-07 15:30:59 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:59 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:59 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:59 --> URI Class Initialized
INFO - 2024-12-07 15:30:59 --> Router Class Initialized
INFO - 2024-12-07 15:30:59 --> Output Class Initialized
INFO - 2024-12-07 15:30:59 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:59 --> CSRF cookie sent
INFO - 2024-12-07 15:30:59 --> Input Class Initialized
INFO - 2024-12-07 15:30:59 --> Language Class Initialized
INFO - 2024-12-07 15:30:59 --> Loader Class Initialized
INFO - 2024-12-07 15:30:59 --> Helper loaded: url_helper
INFO - 2024-12-07 15:30:59 --> Helper loaded: form_helper
INFO - 2024-12-07 15:30:59 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:30:59 --> Form Validation Class Initialized
INFO - 2024-12-07 15:30:59 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:30:59 --> Controller Class Initialized
INFO - 2024-12-07 15:30:59 --> Model "Review_model" initialized
INFO - 2024-12-07 15:30:59 --> Model "Category_model" initialized
INFO - 2024-12-07 15:30:59 --> Model "User_model" initialized
INFO - 2024-12-07 15:30:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:30:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:30:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-07 15:30:59 --> Final output sent to browser
DEBUG - 2024-12-07 15:30:59 --> Total execution time: 0.0699
INFO - 2024-12-07 15:31:02 --> Config Class Initialized
INFO - 2024-12-07 15:31:02 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:02 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:02 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:02 --> URI Class Initialized
INFO - 2024-12-07 15:31:02 --> Router Class Initialized
INFO - 2024-12-07 15:31:02 --> Output Class Initialized
INFO - 2024-12-07 15:31:02 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:02 --> CSRF cookie sent
INFO - 2024-12-07 15:31:02 --> Input Class Initialized
INFO - 2024-12-07 15:31:02 --> Language Class Initialized
INFO - 2024-12-07 15:31:02 --> Loader Class Initialized
INFO - 2024-12-07 15:31:02 --> Helper loaded: url_helper
INFO - 2024-12-07 15:31:02 --> Helper loaded: form_helper
INFO - 2024-12-07 15:31:02 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:31:02 --> Form Validation Class Initialized
INFO - 2024-12-07 15:31:02 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:31:02 --> Controller Class Initialized
INFO - 2024-12-07 15:31:02 --> Model "Review_model" initialized
INFO - 2024-12-07 15:31:02 --> Model "Category_model" initialized
INFO - 2024-12-07 15:31:02 --> Model "User_model" initialized
INFO - 2024-12-07 15:31:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:31:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:31:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-07 15:31:02 --> Final output sent to browser
DEBUG - 2024-12-07 15:31:02 --> Total execution time: 0.0558
INFO - 2024-12-07 15:31:04 --> Config Class Initialized
INFO - 2024-12-07 15:31:04 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:04 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:04 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:04 --> URI Class Initialized
INFO - 2024-12-07 15:31:04 --> Router Class Initialized
INFO - 2024-12-07 15:31:04 --> Output Class Initialized
INFO - 2024-12-07 15:31:04 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:04 --> CSRF cookie sent
INFO - 2024-12-07 15:31:04 --> Input Class Initialized
INFO - 2024-12-07 15:31:04 --> Language Class Initialized
INFO - 2024-12-07 15:31:04 --> Loader Class Initialized
INFO - 2024-12-07 15:31:04 --> Helper loaded: url_helper
INFO - 2024-12-07 15:31:04 --> Helper loaded: form_helper
INFO - 2024-12-07 15:31:04 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:31:04 --> Form Validation Class Initialized
INFO - 2024-12-07 15:31:04 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:31:04 --> Controller Class Initialized
INFO - 2024-12-07 15:31:04 --> Model "News_model" initialized
INFO - 2024-12-07 15:31:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-07 15:31:04 --> Final output sent to browser
DEBUG - 2024-12-07 15:31:04 --> Total execution time: 0.0626
INFO - 2024-12-07 15:31:06 --> Config Class Initialized
INFO - 2024-12-07 15:31:06 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:06 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:06 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:06 --> URI Class Initialized
INFO - 2024-12-07 15:31:06 --> Router Class Initialized
INFO - 2024-12-07 15:31:06 --> Output Class Initialized
INFO - 2024-12-07 15:31:06 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:06 --> CSRF cookie sent
INFO - 2024-12-07 15:31:06 --> Input Class Initialized
INFO - 2024-12-07 15:31:06 --> Language Class Initialized
INFO - 2024-12-07 15:31:06 --> Loader Class Initialized
INFO - 2024-12-07 15:31:06 --> Helper loaded: url_helper
INFO - 2024-12-07 15:31:06 --> Helper loaded: form_helper
INFO - 2024-12-07 15:31:06 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:31:06 --> Form Validation Class Initialized
INFO - 2024-12-07 15:31:06 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:31:06 --> Controller Class Initialized
INFO - 2024-12-07 15:31:06 --> Model "Review_model" initialized
INFO - 2024-12-07 15:31:06 --> Model "Category_model" initialized
INFO - 2024-12-07 15:31:06 --> Model "User_model" initialized
INFO - 2024-12-07 15:31:06 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-07 15:31:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:31:06 --> Model "Contact_model" initialized
INFO - 2024-12-07 15:31:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-07 15:31:06 --> Final output sent to browser
DEBUG - 2024-12-07 15:31:06 --> Total execution time: 0.0498
INFO - 2024-12-07 15:31:08 --> Config Class Initialized
INFO - 2024-12-07 15:31:08 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:08 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:08 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:08 --> URI Class Initialized
INFO - 2024-12-07 15:31:08 --> Router Class Initialized
INFO - 2024-12-07 15:31:08 --> Output Class Initialized
INFO - 2024-12-07 15:31:08 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:08 --> CSRF cookie sent
INFO - 2024-12-07 15:31:08 --> Input Class Initialized
INFO - 2024-12-07 15:31:08 --> Language Class Initialized
INFO - 2024-12-07 15:31:08 --> Loader Class Initialized
INFO - 2024-12-07 15:31:08 --> Helper loaded: url_helper
INFO - 2024-12-07 15:31:08 --> Helper loaded: form_helper
INFO - 2024-12-07 15:31:08 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:31:08 --> Form Validation Class Initialized
INFO - 2024-12-07 15:31:08 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:31:08 --> Controller Class Initialized
INFO - 2024-12-07 15:31:08 --> Model "User_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "Category_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "Review_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "News_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:31:08 --> Config Class Initialized
INFO - 2024-12-07 15:31:08 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:08 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:08 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:08 --> URI Class Initialized
INFO - 2024-12-07 15:31:08 --> Router Class Initialized
INFO - 2024-12-07 15:31:08 --> Output Class Initialized
INFO - 2024-12-07 15:31:08 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:08 --> CSRF cookie sent
INFO - 2024-12-07 15:31:08 --> Input Class Initialized
INFO - 2024-12-07 15:31:08 --> Language Class Initialized
INFO - 2024-12-07 15:31:08 --> Loader Class Initialized
INFO - 2024-12-07 15:31:08 --> Helper loaded: url_helper
INFO - 2024-12-07 15:31:08 --> Helper loaded: form_helper
INFO - 2024-12-07 15:31:08 --> Database Driver Class Initialized
DEBUG - 2024-12-07 15:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:31:08 --> Form Validation Class Initialized
INFO - 2024-12-07 15:31:08 --> Model "Culinary_model" initialized
INFO - 2024-12-07 15:31:08 --> Controller Class Initialized
INFO - 2024-12-07 15:31:08 --> Model "User_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "Category_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "Review_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "News_model" initialized
INFO - 2024-12-07 15:31:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-07 15:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:31:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-07 15:31:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-07 15:31:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-07 15:31:08 --> Final output sent to browser
DEBUG - 2024-12-07 15:31:08 --> Total execution time: 0.0669
