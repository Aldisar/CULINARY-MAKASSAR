<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-03 05:54:25 --> Config Class Initialized
INFO - 2024-12-03 05:54:25 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:25 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:25 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:25 --> URI Class Initialized
INFO - 2024-12-03 05:54:25 --> Router Class Initialized
INFO - 2024-12-03 05:54:25 --> Output Class Initialized
INFO - 2024-12-03 05:54:25 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:25 --> CSRF cookie sent
INFO - 2024-12-03 05:54:25 --> Input Class Initialized
INFO - 2024-12-03 05:54:25 --> Language Class Initialized
INFO - 2024-12-03 05:54:25 --> Loader Class Initialized
INFO - 2024-12-03 05:54:26 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:26 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:26 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:26 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:26 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:26 --> Controller Class Initialized
INFO - 2024-12-03 05:54:26 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:26 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:26 --> Config Class Initialized
INFO - 2024-12-03 05:54:26 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:26 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:26 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:26 --> URI Class Initialized
INFO - 2024-12-03 05:54:26 --> Router Class Initialized
INFO - 2024-12-03 05:54:26 --> Output Class Initialized
INFO - 2024-12-03 05:54:26 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:26 --> CSRF cookie sent
INFO - 2024-12-03 05:54:26 --> Input Class Initialized
INFO - 2024-12-03 05:54:26 --> Language Class Initialized
INFO - 2024-12-03 05:54:26 --> Loader Class Initialized
INFO - 2024-12-03 05:54:26 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:26 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:26 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:26 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:26 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:26 --> Controller Class Initialized
INFO - 2024-12-03 05:54:26 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:26 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 05:54:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 05:54:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-03 05:54:26 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:26 --> Total execution time: 0.1189
INFO - 2024-12-03 05:54:29 --> Config Class Initialized
INFO - 2024-12-03 05:54:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:29 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:29 --> URI Class Initialized
INFO - 2024-12-03 05:54:29 --> Router Class Initialized
INFO - 2024-12-03 05:54:29 --> Output Class Initialized
INFO - 2024-12-03 05:54:29 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:29 --> CSRF cookie sent
INFO - 2024-12-03 05:54:29 --> CSRF token verified
INFO - 2024-12-03 05:54:29 --> Input Class Initialized
INFO - 2024-12-03 05:54:29 --> Language Class Initialized
INFO - 2024-12-03 05:54:29 --> Loader Class Initialized
INFO - 2024-12-03 05:54:29 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:29 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:29 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:29 --> Controller Class Initialized
INFO - 2024-12-03 05:54:29 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:29 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:29 --> Model "Review_model" initialized
INFO - 2024-12-03 05:54:29 --> Model "News_model" initialized
INFO - 2024-12-03 05:54:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 05:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:29 --> Config Class Initialized
INFO - 2024-12-03 05:54:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:29 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:29 --> URI Class Initialized
INFO - 2024-12-03 05:54:29 --> Router Class Initialized
INFO - 2024-12-03 05:54:29 --> Output Class Initialized
INFO - 2024-12-03 05:54:29 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:29 --> CSRF cookie sent
INFO - 2024-12-03 05:54:29 --> Input Class Initialized
INFO - 2024-12-03 05:54:29 --> Language Class Initialized
INFO - 2024-12-03 05:54:29 --> Loader Class Initialized
INFO - 2024-12-03 05:54:29 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:29 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:29 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:29 --> Controller Class Initialized
INFO - 2024-12-03 05:54:29 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:29 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:29 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 05:54:29 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:29 --> Total execution time: 0.0782
INFO - 2024-12-03 05:54:34 --> Config Class Initialized
INFO - 2024-12-03 05:54:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:34 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:34 --> URI Class Initialized
INFO - 2024-12-03 05:54:34 --> Router Class Initialized
INFO - 2024-12-03 05:54:34 --> Output Class Initialized
INFO - 2024-12-03 05:54:34 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:34 --> CSRF cookie sent
INFO - 2024-12-03 05:54:34 --> Input Class Initialized
INFO - 2024-12-03 05:54:34 --> Language Class Initialized
INFO - 2024-12-03 05:54:34 --> Loader Class Initialized
INFO - 2024-12-03 05:54:34 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:34 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:34 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:34 --> Controller Class Initialized
INFO - 2024-12-03 05:54:34 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:34 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:34 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 05:54:34 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:34 --> Total execution time: 0.0809
INFO - 2024-12-03 05:54:36 --> Config Class Initialized
INFO - 2024-12-03 05:54:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:36 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:36 --> URI Class Initialized
INFO - 2024-12-03 05:54:36 --> Router Class Initialized
INFO - 2024-12-03 05:54:36 --> Output Class Initialized
INFO - 2024-12-03 05:54:36 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:36 --> CSRF cookie sent
INFO - 2024-12-03 05:54:36 --> Input Class Initialized
INFO - 2024-12-03 05:54:36 --> Language Class Initialized
INFO - 2024-12-03 05:54:36 --> Loader Class Initialized
INFO - 2024-12-03 05:54:36 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:36 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:36 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:36 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:36 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:36 --> Controller Class Initialized
INFO - 2024-12-03 05:54:36 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:36 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-03 05:54:36 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:36 --> Total execution time: 0.0933
INFO - 2024-12-03 05:54:38 --> Config Class Initialized
INFO - 2024-12-03 05:54:38 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:38 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:38 --> URI Class Initialized
INFO - 2024-12-03 05:54:38 --> Router Class Initialized
INFO - 2024-12-03 05:54:38 --> Output Class Initialized
INFO - 2024-12-03 05:54:38 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:38 --> CSRF cookie sent
INFO - 2024-12-03 05:54:38 --> Input Class Initialized
INFO - 2024-12-03 05:54:38 --> Language Class Initialized
INFO - 2024-12-03 05:54:38 --> Loader Class Initialized
INFO - 2024-12-03 05:54:38 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:38 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:38 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:38 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:38 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:38 --> Controller Class Initialized
INFO - 2024-12-03 05:54:38 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:38 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:38 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 05:54:38 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:38 --> Total execution time: 0.0461
INFO - 2024-12-03 05:54:39 --> Config Class Initialized
INFO - 2024-12-03 05:54:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:39 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:39 --> URI Class Initialized
INFO - 2024-12-03 05:54:39 --> Router Class Initialized
INFO - 2024-12-03 05:54:39 --> Output Class Initialized
INFO - 2024-12-03 05:54:39 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:39 --> CSRF cookie sent
INFO - 2024-12-03 05:54:39 --> Input Class Initialized
INFO - 2024-12-03 05:54:39 --> Language Class Initialized
INFO - 2024-12-03 05:54:39 --> Loader Class Initialized
INFO - 2024-12-03 05:54:39 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:39 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:39 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:39 --> Controller Class Initialized
INFO - 2024-12-03 05:54:39 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:39 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:39 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 05:54:39 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:39 --> Total execution time: 0.0585
INFO - 2024-12-03 05:54:40 --> Config Class Initialized
INFO - 2024-12-03 05:54:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:40 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:40 --> URI Class Initialized
INFO - 2024-12-03 05:54:40 --> Router Class Initialized
INFO - 2024-12-03 05:54:40 --> Output Class Initialized
INFO - 2024-12-03 05:54:40 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:40 --> CSRF cookie sent
INFO - 2024-12-03 05:54:40 --> Input Class Initialized
INFO - 2024-12-03 05:54:40 --> Language Class Initialized
INFO - 2024-12-03 05:54:40 --> Loader Class Initialized
INFO - 2024-12-03 05:54:40 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:40 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:40 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:40 --> Controller Class Initialized
INFO - 2024-12-03 05:54:40 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:40 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:40 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 05:54:40 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:40 --> Total execution time: 0.0574
INFO - 2024-12-03 05:54:42 --> Config Class Initialized
INFO - 2024-12-03 05:54:42 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:42 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:42 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:42 --> URI Class Initialized
INFO - 2024-12-03 05:54:42 --> Router Class Initialized
INFO - 2024-12-03 05:54:42 --> Output Class Initialized
INFO - 2024-12-03 05:54:42 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:42 --> CSRF cookie sent
INFO - 2024-12-03 05:54:42 --> Input Class Initialized
INFO - 2024-12-03 05:54:42 --> Language Class Initialized
INFO - 2024-12-03 05:54:42 --> Loader Class Initialized
INFO - 2024-12-03 05:54:42 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:42 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:42 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:42 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:42 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:42 --> Controller Class Initialized
INFO - 2024-12-03 05:54:42 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:42 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:42 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 05:54:42 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:42 --> Total execution time: 0.0459
INFO - 2024-12-03 05:54:43 --> Config Class Initialized
INFO - 2024-12-03 05:54:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:43 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:43 --> URI Class Initialized
INFO - 2024-12-03 05:54:43 --> Router Class Initialized
INFO - 2024-12-03 05:54:43 --> Output Class Initialized
INFO - 2024-12-03 05:54:43 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:43 --> CSRF cookie sent
INFO - 2024-12-03 05:54:43 --> Input Class Initialized
INFO - 2024-12-03 05:54:43 --> Language Class Initialized
INFO - 2024-12-03 05:54:43 --> Loader Class Initialized
INFO - 2024-12-03 05:54:43 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:43 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:43 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:43 --> Controller Class Initialized
INFO - 2024-12-03 05:54:43 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:43 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-03 05:54:43 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:43 --> Total execution time: 0.0410
INFO - 2024-12-03 05:54:44 --> Config Class Initialized
INFO - 2024-12-03 05:54:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:44 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:44 --> URI Class Initialized
INFO - 2024-12-03 05:54:44 --> Router Class Initialized
INFO - 2024-12-03 05:54:44 --> Output Class Initialized
INFO - 2024-12-03 05:54:44 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:44 --> CSRF cookie sent
INFO - 2024-12-03 05:54:44 --> Input Class Initialized
INFO - 2024-12-03 05:54:44 --> Language Class Initialized
INFO - 2024-12-03 05:54:44 --> Loader Class Initialized
INFO - 2024-12-03 05:54:44 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:44 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:44 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:44 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:44 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:44 --> Controller Class Initialized
INFO - 2024-12-03 05:54:44 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:44 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:44 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 05:54:44 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:44 --> Total execution time: 0.0806
INFO - 2024-12-03 05:54:46 --> Config Class Initialized
INFO - 2024-12-03 05:54:46 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:46 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:46 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:46 --> URI Class Initialized
INFO - 2024-12-03 05:54:46 --> Router Class Initialized
INFO - 2024-12-03 05:54:46 --> Output Class Initialized
INFO - 2024-12-03 05:54:46 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:46 --> CSRF cookie sent
INFO - 2024-12-03 05:54:46 --> Input Class Initialized
INFO - 2024-12-03 05:54:46 --> Language Class Initialized
INFO - 2024-12-03 05:54:46 --> Loader Class Initialized
INFO - 2024-12-03 05:54:46 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:46 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:46 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:46 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:46 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:46 --> Controller Class Initialized
INFO - 2024-12-03 05:54:46 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:46 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:46 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:46 --> Model "Contact_model" initialized
INFO - 2024-12-03 05:54:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-03 05:54:46 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:46 --> Total execution time: 0.0827
INFO - 2024-12-03 05:54:48 --> Config Class Initialized
INFO - 2024-12-03 05:54:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:48 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:48 --> URI Class Initialized
INFO - 2024-12-03 05:54:48 --> Router Class Initialized
INFO - 2024-12-03 05:54:48 --> Output Class Initialized
INFO - 2024-12-03 05:54:48 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:48 --> CSRF cookie sent
INFO - 2024-12-03 05:54:48 --> Input Class Initialized
INFO - 2024-12-03 05:54:48 --> Language Class Initialized
INFO - 2024-12-03 05:54:48 --> Loader Class Initialized
INFO - 2024-12-03 05:54:48 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:48 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:48 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:48 --> Controller Class Initialized
INFO - 2024-12-03 05:54:48 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:48 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:48 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 05:54:48 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:48 --> Total execution time: 0.0581
INFO - 2024-12-03 05:54:50 --> Config Class Initialized
INFO - 2024-12-03 05:54:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:50 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:50 --> URI Class Initialized
INFO - 2024-12-03 05:54:50 --> Router Class Initialized
INFO - 2024-12-03 05:54:50 --> Output Class Initialized
INFO - 2024-12-03 05:54:50 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:50 --> CSRF cookie sent
INFO - 2024-12-03 05:54:50 --> Input Class Initialized
INFO - 2024-12-03 05:54:50 --> Language Class Initialized
INFO - 2024-12-03 05:54:50 --> Loader Class Initialized
INFO - 2024-12-03 05:54:50 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:50 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:50 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:50 --> Controller Class Initialized
INFO - 2024-12-03 05:54:50 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:50 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:50 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 05:54:50 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:50 --> Total execution time: 0.0446
INFO - 2024-12-03 05:54:53 --> Config Class Initialized
INFO - 2024-12-03 05:54:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 05:54:53 --> UTF-8 Support Enabled
INFO - 2024-12-03 05:54:53 --> Utf8 Class Initialized
INFO - 2024-12-03 05:54:53 --> URI Class Initialized
INFO - 2024-12-03 05:54:53 --> Router Class Initialized
INFO - 2024-12-03 05:54:53 --> Output Class Initialized
INFO - 2024-12-03 05:54:53 --> Security Class Initialized
DEBUG - 2024-12-03 05:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 05:54:53 --> CSRF cookie sent
INFO - 2024-12-03 05:54:53 --> Input Class Initialized
INFO - 2024-12-03 05:54:53 --> Language Class Initialized
INFO - 2024-12-03 05:54:53 --> Loader Class Initialized
INFO - 2024-12-03 05:54:53 --> Helper loaded: url_helper
INFO - 2024-12-03 05:54:53 --> Helper loaded: form_helper
INFO - 2024-12-03 05:54:53 --> Database Driver Class Initialized
DEBUG - 2024-12-03 05:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 05:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 05:54:53 --> Form Validation Class Initialized
INFO - 2024-12-03 05:54:53 --> Model "Culinary_model" initialized
INFO - 2024-12-03 05:54:53 --> Controller Class Initialized
INFO - 2024-12-03 05:54:53 --> Model "Category_model" initialized
INFO - 2024-12-03 05:54:53 --> Model "User_model" initialized
INFO - 2024-12-03 05:54:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 05:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 05:54:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 05:54:53 --> Final output sent to browser
DEBUG - 2024-12-03 05:54:53 --> Total execution time: 0.0383
INFO - 2024-12-03 08:21:54 --> Config Class Initialized
INFO - 2024-12-03 08:21:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:21:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:21:54 --> Utf8 Class Initialized
INFO - 2024-12-03 08:21:54 --> URI Class Initialized
INFO - 2024-12-03 08:21:54 --> Router Class Initialized
INFO - 2024-12-03 08:21:54 --> Output Class Initialized
INFO - 2024-12-03 08:21:54 --> Security Class Initialized
DEBUG - 2024-12-03 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:21:54 --> CSRF cookie sent
INFO - 2024-12-03 08:21:54 --> Input Class Initialized
INFO - 2024-12-03 08:21:54 --> Language Class Initialized
INFO - 2024-12-03 08:21:54 --> Loader Class Initialized
INFO - 2024-12-03 08:21:54 --> Helper loaded: url_helper
INFO - 2024-12-03 08:21:54 --> Helper loaded: form_helper
INFO - 2024-12-03 08:21:54 --> Database Driver Class Initialized
DEBUG - 2024-12-03 08:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 08:21:54 --> Form Validation Class Initialized
INFO - 2024-12-03 08:21:54 --> Model "Culinary_model" initialized
INFO - 2024-12-03 08:21:54 --> Controller Class Initialized
INFO - 2024-12-03 08:21:54 --> Model "Category_model" initialized
INFO - 2024-12-03 08:21:54 --> Model "User_model" initialized
INFO - 2024-12-03 08:21:54 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 08:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 08:21:54 --> Config Class Initialized
INFO - 2024-12-03 08:21:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:21:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:21:54 --> Utf8 Class Initialized
INFO - 2024-12-03 08:21:54 --> URI Class Initialized
INFO - 2024-12-03 08:21:54 --> Router Class Initialized
INFO - 2024-12-03 08:21:54 --> Output Class Initialized
INFO - 2024-12-03 08:21:54 --> Security Class Initialized
DEBUG - 2024-12-03 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:21:54 --> CSRF cookie sent
INFO - 2024-12-03 08:21:54 --> Input Class Initialized
INFO - 2024-12-03 08:21:54 --> Language Class Initialized
INFO - 2024-12-03 08:21:54 --> Loader Class Initialized
INFO - 2024-12-03 08:21:54 --> Helper loaded: url_helper
INFO - 2024-12-03 08:21:54 --> Helper loaded: form_helper
INFO - 2024-12-03 08:21:54 --> Database Driver Class Initialized
DEBUG - 2024-12-03 08:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 08:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 08:21:55 --> Form Validation Class Initialized
INFO - 2024-12-03 08:21:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 08:21:55 --> Controller Class Initialized
INFO - 2024-12-03 08:21:55 --> Model "Category_model" initialized
INFO - 2024-12-03 08:21:55 --> Model "User_model" initialized
INFO - 2024-12-03 08:21:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 08:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 08:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 08:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 08:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-03 08:21:55 --> Final output sent to browser
DEBUG - 2024-12-03 08:21:55 --> Total execution time: 0.1117
INFO - 2024-12-03 08:22:39 --> Config Class Initialized
INFO - 2024-12-03 08:22:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:22:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:22:39 --> Utf8 Class Initialized
INFO - 2024-12-03 08:22:39 --> URI Class Initialized
INFO - 2024-12-03 08:22:40 --> Router Class Initialized
INFO - 2024-12-03 08:22:40 --> Output Class Initialized
INFO - 2024-12-03 08:22:40 --> Security Class Initialized
DEBUG - 2024-12-03 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:22:40 --> CSRF cookie sent
INFO - 2024-12-03 08:22:40 --> CSRF token verified
INFO - 2024-12-03 08:22:40 --> Input Class Initialized
INFO - 2024-12-03 08:22:40 --> Language Class Initialized
INFO - 2024-12-03 08:22:40 --> Loader Class Initialized
INFO - 2024-12-03 08:22:40 --> Helper loaded: url_helper
INFO - 2024-12-03 08:22:40 --> Helper loaded: form_helper
INFO - 2024-12-03 08:22:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 08:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 08:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 08:22:40 --> Form Validation Class Initialized
INFO - 2024-12-03 08:22:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 08:22:40 --> Controller Class Initialized
INFO - 2024-12-03 08:22:40 --> Model "User_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "Category_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "Review_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "News_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 08:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 08:22:40 --> Config Class Initialized
INFO - 2024-12-03 08:22:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:22:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:22:40 --> Utf8 Class Initialized
INFO - 2024-12-03 08:22:40 --> URI Class Initialized
INFO - 2024-12-03 08:22:40 --> Router Class Initialized
INFO - 2024-12-03 08:22:40 --> Output Class Initialized
INFO - 2024-12-03 08:22:40 --> Security Class Initialized
DEBUG - 2024-12-03 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:22:40 --> CSRF cookie sent
INFO - 2024-12-03 08:22:40 --> Input Class Initialized
INFO - 2024-12-03 08:22:40 --> Language Class Initialized
INFO - 2024-12-03 08:22:40 --> Loader Class Initialized
INFO - 2024-12-03 08:22:40 --> Helper loaded: url_helper
INFO - 2024-12-03 08:22:40 --> Helper loaded: form_helper
INFO - 2024-12-03 08:22:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 08:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 08:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 08:22:40 --> Form Validation Class Initialized
INFO - 2024-12-03 08:22:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 08:22:40 --> Controller Class Initialized
INFO - 2024-12-03 08:22:40 --> Model "User_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "Category_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "Review_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "News_model" initialized
INFO - 2024-12-03 08:22:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 08:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 08:22:40 --> Query result: stdClass Object
(
    [view_count] => 46
)

INFO - 2024-12-03 08:22:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 08:22:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 08:22:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 08:22:40 --> Final output sent to browser
DEBUG - 2024-12-03 08:22:40 --> Total execution time: 0.1818
INFO - 2024-12-03 08:22:43 --> Config Class Initialized
INFO - 2024-12-03 08:22:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:22:43 --> Utf8 Class Initialized
INFO - 2024-12-03 08:22:43 --> URI Class Initialized
INFO - 2024-12-03 08:22:43 --> Router Class Initialized
INFO - 2024-12-03 08:22:43 --> Output Class Initialized
INFO - 2024-12-03 08:22:43 --> Security Class Initialized
DEBUG - 2024-12-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:22:43 --> CSRF cookie sent
INFO - 2024-12-03 08:22:43 --> Input Class Initialized
INFO - 2024-12-03 08:22:43 --> Language Class Initialized
ERROR - 2024-12-03 08:22:43 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 08:23:04 --> Config Class Initialized
INFO - 2024-12-03 08:23:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:23:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:23:04 --> Utf8 Class Initialized
INFO - 2024-12-03 08:23:04 --> URI Class Initialized
INFO - 2024-12-03 08:23:04 --> Router Class Initialized
INFO - 2024-12-03 08:23:04 --> Output Class Initialized
INFO - 2024-12-03 08:23:04 --> Security Class Initialized
DEBUG - 2024-12-03 08:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:23:04 --> CSRF cookie sent
INFO - 2024-12-03 08:23:04 --> Input Class Initialized
INFO - 2024-12-03 08:23:04 --> Language Class Initialized
INFO - 2024-12-03 08:23:04 --> Loader Class Initialized
INFO - 2024-12-03 08:23:04 --> Helper loaded: url_helper
INFO - 2024-12-03 08:23:04 --> Helper loaded: form_helper
INFO - 2024-12-03 08:23:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 08:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 08:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 08:23:04 --> Form Validation Class Initialized
INFO - 2024-12-03 08:23:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 08:23:04 --> Controller Class Initialized
INFO - 2024-12-03 08:23:04 --> Model "User_model" initialized
INFO - 2024-12-03 08:23:04 --> Model "Category_model" initialized
INFO - 2024-12-03 08:23:04 --> Model "Review_model" initialized
INFO - 2024-12-03 08:23:04 --> Model "News_model" initialized
INFO - 2024-12-03 08:23:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 08:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 08:23:04 --> Query result: stdClass Object
(
    [view_count] => 47
)

INFO - 2024-12-03 08:23:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 08:23:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 08:23:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 08:23:04 --> Final output sent to browser
DEBUG - 2024-12-03 08:23:04 --> Total execution time: 0.0696
INFO - 2024-12-03 08:23:06 --> Config Class Initialized
INFO - 2024-12-03 08:23:06 --> Hooks Class Initialized
DEBUG - 2024-12-03 08:23:06 --> UTF-8 Support Enabled
INFO - 2024-12-03 08:23:06 --> Utf8 Class Initialized
INFO - 2024-12-03 08:23:06 --> URI Class Initialized
INFO - 2024-12-03 08:23:06 --> Router Class Initialized
INFO - 2024-12-03 08:23:06 --> Output Class Initialized
INFO - 2024-12-03 08:23:06 --> Security Class Initialized
DEBUG - 2024-12-03 08:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 08:23:06 --> CSRF cookie sent
INFO - 2024-12-03 08:23:06 --> Input Class Initialized
INFO - 2024-12-03 08:23:06 --> Language Class Initialized
ERROR - 2024-12-03 08:23:06 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:34:43 --> Config Class Initialized
INFO - 2024-12-03 09:34:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:34:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:34:43 --> Utf8 Class Initialized
INFO - 2024-12-03 09:34:43 --> URI Class Initialized
INFO - 2024-12-03 09:34:43 --> Router Class Initialized
INFO - 2024-12-03 09:34:43 --> Output Class Initialized
INFO - 2024-12-03 09:34:43 --> Security Class Initialized
DEBUG - 2024-12-03 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:34:43 --> CSRF cookie sent
INFO - 2024-12-03 09:34:43 --> Input Class Initialized
INFO - 2024-12-03 09:34:43 --> Language Class Initialized
INFO - 2024-12-03 09:34:43 --> Loader Class Initialized
INFO - 2024-12-03 09:34:43 --> Helper loaded: url_helper
INFO - 2024-12-03 09:34:43 --> Helper loaded: form_helper
INFO - 2024-12-03 09:34:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:34:43 --> Form Validation Class Initialized
INFO - 2024-12-03 09:34:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:34:43 --> Controller Class Initialized
INFO - 2024-12-03 09:34:43 --> Model "User_model" initialized
INFO - 2024-12-03 09:34:43 --> Model "Category_model" initialized
INFO - 2024-12-03 09:34:43 --> Model "Review_model" initialized
INFO - 2024-12-03 09:34:43 --> Model "News_model" initialized
INFO - 2024-12-03 09:34:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:34:44 --> Query result: stdClass Object
(
    [view_count] => 1
)

INFO - 2024-12-03 09:34:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:34:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:34:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:34:44 --> Final output sent to browser
DEBUG - 2024-12-03 09:34:44 --> Total execution time: 0.7817
INFO - 2024-12-03 09:34:48 --> Config Class Initialized
INFO - 2024-12-03 09:34:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:34:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:34:48 --> Utf8 Class Initialized
INFO - 2024-12-03 09:34:48 --> URI Class Initialized
INFO - 2024-12-03 09:34:48 --> Router Class Initialized
INFO - 2024-12-03 09:34:48 --> Output Class Initialized
INFO - 2024-12-03 09:34:48 --> Security Class Initialized
DEBUG - 2024-12-03 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:34:48 --> CSRF cookie sent
INFO - 2024-12-03 09:34:48 --> Input Class Initialized
INFO - 2024-12-03 09:34:48 --> Language Class Initialized
INFO - 2024-12-03 09:34:48 --> Loader Class Initialized
INFO - 2024-12-03 09:34:48 --> Helper loaded: url_helper
INFO - 2024-12-03 09:34:48 --> Helper loaded: form_helper
INFO - 2024-12-03 09:34:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:34:49 --> Form Validation Class Initialized
INFO - 2024-12-03 09:34:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:34:49 --> Controller Class Initialized
INFO - 2024-12-03 09:34:49 --> Model "User_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "Category_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "Review_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "News_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:34:49 --> Config Class Initialized
INFO - 2024-12-03 09:34:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:34:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:34:49 --> Utf8 Class Initialized
INFO - 2024-12-03 09:34:49 --> URI Class Initialized
INFO - 2024-12-03 09:34:49 --> Router Class Initialized
INFO - 2024-12-03 09:34:49 --> Output Class Initialized
INFO - 2024-12-03 09:34:49 --> Security Class Initialized
DEBUG - 2024-12-03 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:34:49 --> CSRF cookie sent
INFO - 2024-12-03 09:34:49 --> Input Class Initialized
INFO - 2024-12-03 09:34:49 --> Language Class Initialized
INFO - 2024-12-03 09:34:49 --> Loader Class Initialized
INFO - 2024-12-03 09:34:49 --> Helper loaded: url_helper
INFO - 2024-12-03 09:34:49 --> Helper loaded: form_helper
INFO - 2024-12-03 09:34:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:34:49 --> Form Validation Class Initialized
INFO - 2024-12-03 09:34:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:34:49 --> Controller Class Initialized
INFO - 2024-12-03 09:34:49 --> Model "User_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "Category_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "Review_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "News_model" initialized
INFO - 2024-12-03 09:34:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:34:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:34:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:34:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:34:49 --> Final output sent to browser
DEBUG - 2024-12-03 09:34:49 --> Total execution time: 0.1560
INFO - 2024-12-03 09:35:09 --> Config Class Initialized
INFO - 2024-12-03 09:35:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:35:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:35:09 --> Utf8 Class Initialized
INFO - 2024-12-03 09:35:09 --> URI Class Initialized
INFO - 2024-12-03 09:35:09 --> Router Class Initialized
INFO - 2024-12-03 09:35:09 --> Output Class Initialized
INFO - 2024-12-03 09:35:09 --> Security Class Initialized
DEBUG - 2024-12-03 09:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:35:09 --> CSRF cookie sent
INFO - 2024-12-03 09:35:09 --> CSRF token verified
INFO - 2024-12-03 09:35:09 --> Input Class Initialized
INFO - 2024-12-03 09:35:09 --> Language Class Initialized
INFO - 2024-12-03 09:35:09 --> Loader Class Initialized
INFO - 2024-12-03 09:35:09 --> Helper loaded: url_helper
INFO - 2024-12-03 09:35:09 --> Helper loaded: form_helper
INFO - 2024-12-03 09:35:09 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:35:10 --> Form Validation Class Initialized
INFO - 2024-12-03 09:35:10 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:35:10 --> Controller Class Initialized
INFO - 2024-12-03 09:35:10 --> Model "User_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "Category_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "Review_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "News_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:35:10 --> Config Class Initialized
INFO - 2024-12-03 09:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:35:10 --> Utf8 Class Initialized
INFO - 2024-12-03 09:35:10 --> URI Class Initialized
INFO - 2024-12-03 09:35:10 --> Router Class Initialized
INFO - 2024-12-03 09:35:10 --> Output Class Initialized
INFO - 2024-12-03 09:35:10 --> Security Class Initialized
DEBUG - 2024-12-03 09:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:35:10 --> CSRF cookie sent
INFO - 2024-12-03 09:35:10 --> Input Class Initialized
INFO - 2024-12-03 09:35:10 --> Language Class Initialized
INFO - 2024-12-03 09:35:10 --> Loader Class Initialized
INFO - 2024-12-03 09:35:10 --> Helper loaded: url_helper
INFO - 2024-12-03 09:35:10 --> Helper loaded: form_helper
INFO - 2024-12-03 09:35:10 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:35:10 --> Form Validation Class Initialized
INFO - 2024-12-03 09:35:10 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:35:10 --> Controller Class Initialized
INFO - 2024-12-03 09:35:10 --> Model "User_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "Category_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "Review_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "News_model" initialized
INFO - 2024-12-03 09:35:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:35:10 --> Query result: stdClass Object
(
    [view_count] => 2
)

INFO - 2024-12-03 09:35:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:35:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:35:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:35:10 --> Final output sent to browser
DEBUG - 2024-12-03 09:35:10 --> Total execution time: 0.0753
INFO - 2024-12-03 09:35:14 --> Config Class Initialized
INFO - 2024-12-03 09:35:14 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:35:14 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:35:14 --> Utf8 Class Initialized
INFO - 2024-12-03 09:35:14 --> URI Class Initialized
INFO - 2024-12-03 09:35:14 --> Router Class Initialized
INFO - 2024-12-03 09:35:14 --> Output Class Initialized
INFO - 2024-12-03 09:35:14 --> Security Class Initialized
DEBUG - 2024-12-03 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:35:14 --> CSRF cookie sent
INFO - 2024-12-03 09:35:14 --> Input Class Initialized
INFO - 2024-12-03 09:35:14 --> Language Class Initialized
ERROR - 2024-12-03 09:35:14 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:39:31 --> Config Class Initialized
INFO - 2024-12-03 09:39:31 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:39:31 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:39:31 --> Utf8 Class Initialized
INFO - 2024-12-03 09:39:31 --> URI Class Initialized
INFO - 2024-12-03 09:39:31 --> Router Class Initialized
INFO - 2024-12-03 09:39:31 --> Output Class Initialized
INFO - 2024-12-03 09:39:31 --> Security Class Initialized
DEBUG - 2024-12-03 09:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:39:31 --> CSRF cookie sent
INFO - 2024-12-03 09:39:31 --> Input Class Initialized
INFO - 2024-12-03 09:39:31 --> Language Class Initialized
INFO - 2024-12-03 09:39:32 --> Loader Class Initialized
INFO - 2024-12-03 09:39:32 --> Helper loaded: url_helper
INFO - 2024-12-03 09:39:32 --> Helper loaded: form_helper
INFO - 2024-12-03 09:39:32 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:39:32 --> Form Validation Class Initialized
INFO - 2024-12-03 09:39:32 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:39:32 --> Controller Class Initialized
INFO - 2024-12-03 09:39:32 --> Model "User_model" initialized
INFO - 2024-12-03 09:39:32 --> Model "Category_model" initialized
INFO - 2024-12-03 09:39:32 --> Model "Review_model" initialized
INFO - 2024-12-03 09:39:32 --> Model "News_model" initialized
INFO - 2024-12-03 09:39:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:39:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:39:32 --> Query result: stdClass Object
(
    [view_count] => 3
)

INFO - 2024-12-03 09:39:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:39:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:39:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:39:32 --> Final output sent to browser
DEBUG - 2024-12-03 09:39:32 --> Total execution time: 0.9502
INFO - 2024-12-03 09:39:35 --> Config Class Initialized
INFO - 2024-12-03 09:39:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:39:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:39:35 --> Utf8 Class Initialized
INFO - 2024-12-03 09:39:35 --> URI Class Initialized
INFO - 2024-12-03 09:39:35 --> Router Class Initialized
INFO - 2024-12-03 09:39:35 --> Output Class Initialized
INFO - 2024-12-03 09:39:35 --> Security Class Initialized
DEBUG - 2024-12-03 09:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:39:35 --> CSRF cookie sent
INFO - 2024-12-03 09:39:35 --> Input Class Initialized
INFO - 2024-12-03 09:39:35 --> Language Class Initialized
ERROR - 2024-12-03 09:39:35 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:39:39 --> Config Class Initialized
INFO - 2024-12-03 09:39:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:39:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:39:39 --> Utf8 Class Initialized
INFO - 2024-12-03 09:39:39 --> URI Class Initialized
INFO - 2024-12-03 09:39:39 --> Router Class Initialized
INFO - 2024-12-03 09:39:39 --> Output Class Initialized
INFO - 2024-12-03 09:39:39 --> Security Class Initialized
DEBUG - 2024-12-03 09:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:39:39 --> CSRF cookie sent
INFO - 2024-12-03 09:39:39 --> Input Class Initialized
INFO - 2024-12-03 09:39:39 --> Language Class Initialized
INFO - 2024-12-03 09:39:39 --> Loader Class Initialized
INFO - 2024-12-03 09:39:39 --> Helper loaded: url_helper
INFO - 2024-12-03 09:39:39 --> Helper loaded: form_helper
INFO - 2024-12-03 09:39:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:39:39 --> Form Validation Class Initialized
INFO - 2024-12-03 09:39:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:39:39 --> Controller Class Initialized
INFO - 2024-12-03 09:39:39 --> Model "User_model" initialized
INFO - 2024-12-03 09:39:39 --> Model "Category_model" initialized
INFO - 2024-12-03 09:39:39 --> Model "Review_model" initialized
INFO - 2024-12-03 09:39:39 --> Model "News_model" initialized
INFO - 2024-12-03 09:39:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:39:39 --> Config Class Initialized
INFO - 2024-12-03 09:39:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:39:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:39:39 --> Utf8 Class Initialized
INFO - 2024-12-03 09:39:39 --> URI Class Initialized
INFO - 2024-12-03 09:39:39 --> Router Class Initialized
INFO - 2024-12-03 09:39:39 --> Output Class Initialized
INFO - 2024-12-03 09:39:39 --> Security Class Initialized
DEBUG - 2024-12-03 09:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:39:39 --> CSRF cookie sent
INFO - 2024-12-03 09:39:39 --> Input Class Initialized
INFO - 2024-12-03 09:39:39 --> Language Class Initialized
INFO - 2024-12-03 09:39:39 --> Loader Class Initialized
INFO - 2024-12-03 09:39:39 --> Helper loaded: url_helper
INFO - 2024-12-03 09:39:39 --> Helper loaded: form_helper
INFO - 2024-12-03 09:39:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:39:40 --> Form Validation Class Initialized
INFO - 2024-12-03 09:39:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:39:40 --> Controller Class Initialized
INFO - 2024-12-03 09:39:40 --> Model "User_model" initialized
INFO - 2024-12-03 09:39:40 --> Model "Category_model" initialized
INFO - 2024-12-03 09:39:40 --> Model "Review_model" initialized
INFO - 2024-12-03 09:39:40 --> Model "News_model" initialized
INFO - 2024-12-03 09:39:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:39:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:39:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:39:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:39:40 --> Final output sent to browser
DEBUG - 2024-12-03 09:39:40 --> Total execution time: 0.0774
INFO - 2024-12-03 09:39:42 --> Config Class Initialized
INFO - 2024-12-03 09:39:42 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:39:42 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:39:42 --> Utf8 Class Initialized
INFO - 2024-12-03 09:39:42 --> URI Class Initialized
INFO - 2024-12-03 09:39:42 --> Router Class Initialized
INFO - 2024-12-03 09:39:42 --> Output Class Initialized
INFO - 2024-12-03 09:39:42 --> Security Class Initialized
DEBUG - 2024-12-03 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:39:42 --> CSRF cookie sent
INFO - 2024-12-03 09:39:42 --> Input Class Initialized
INFO - 2024-12-03 09:39:42 --> Language Class Initialized
INFO - 2024-12-03 09:39:42 --> Loader Class Initialized
INFO - 2024-12-03 09:39:42 --> Helper loaded: url_helper
INFO - 2024-12-03 09:39:42 --> Helper loaded: form_helper
INFO - 2024-12-03 09:39:42 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:39:42 --> Form Validation Class Initialized
INFO - 2024-12-03 09:39:42 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:39:42 --> Controller Class Initialized
INFO - 2024-12-03 09:39:42 --> Model "User_model" initialized
INFO - 2024-12-03 09:39:42 --> Model "Category_model" initialized
INFO - 2024-12-03 09:39:42 --> Model "Review_model" initialized
INFO - 2024-12-03 09:39:42 --> Model "News_model" initialized
INFO - 2024-12-03 09:39:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:39:42 --> Query result: stdClass Object
(
    [view_count] => 4
)

INFO - 2024-12-03 09:39:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:39:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:39:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:39:42 --> Final output sent to browser
DEBUG - 2024-12-03 09:39:42 --> Total execution time: 0.0806
INFO - 2024-12-03 09:39:42 --> Config Class Initialized
INFO - 2024-12-03 09:39:42 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:39:42 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:39:42 --> Utf8 Class Initialized
INFO - 2024-12-03 09:39:42 --> URI Class Initialized
INFO - 2024-12-03 09:39:42 --> Router Class Initialized
INFO - 2024-12-03 09:39:42 --> Output Class Initialized
INFO - 2024-12-03 09:39:42 --> Security Class Initialized
DEBUG - 2024-12-03 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:39:42 --> CSRF cookie sent
INFO - 2024-12-03 09:39:42 --> Input Class Initialized
INFO - 2024-12-03 09:39:42 --> Language Class Initialized
ERROR - 2024-12-03 09:39:42 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:40:33 --> Config Class Initialized
INFO - 2024-12-03 09:40:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:34 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:34 --> URI Class Initialized
INFO - 2024-12-03 09:40:34 --> Router Class Initialized
INFO - 2024-12-03 09:40:34 --> Output Class Initialized
INFO - 2024-12-03 09:40:34 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:34 --> CSRF cookie sent
INFO - 2024-12-03 09:40:34 --> Input Class Initialized
INFO - 2024-12-03 09:40:34 --> Language Class Initialized
INFO - 2024-12-03 09:40:34 --> Loader Class Initialized
INFO - 2024-12-03 09:40:34 --> Helper loaded: url_helper
INFO - 2024-12-03 09:40:34 --> Helper loaded: form_helper
INFO - 2024-12-03 09:40:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:40:34 --> Form Validation Class Initialized
INFO - 2024-12-03 09:40:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:40:34 --> Controller Class Initialized
INFO - 2024-12-03 09:40:34 --> Model "User_model" initialized
INFO - 2024-12-03 09:40:34 --> Model "Category_model" initialized
INFO - 2024-12-03 09:40:34 --> Model "Review_model" initialized
INFO - 2024-12-03 09:40:34 --> Model "News_model" initialized
INFO - 2024-12-03 09:40:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:40:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:40:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:40:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-03 09:40:34 --> Final output sent to browser
DEBUG - 2024-12-03 09:40:34 --> Total execution time: 0.6319
INFO - 2024-12-03 09:40:43 --> Config Class Initialized
INFO - 2024-12-03 09:40:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:43 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:43 --> URI Class Initialized
INFO - 2024-12-03 09:40:43 --> Router Class Initialized
INFO - 2024-12-03 09:40:43 --> Output Class Initialized
INFO - 2024-12-03 09:40:43 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:43 --> CSRF cookie sent
INFO - 2024-12-03 09:40:43 --> Input Class Initialized
INFO - 2024-12-03 09:40:43 --> Language Class Initialized
INFO - 2024-12-03 09:40:43 --> Loader Class Initialized
INFO - 2024-12-03 09:40:43 --> Helper loaded: url_helper
INFO - 2024-12-03 09:40:43 --> Helper loaded: form_helper
INFO - 2024-12-03 09:40:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:40:43 --> Form Validation Class Initialized
INFO - 2024-12-03 09:40:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:40:43 --> Controller Class Initialized
INFO - 2024-12-03 09:40:43 --> Model "User_model" initialized
INFO - 2024-12-03 09:40:43 --> Model "Category_model" initialized
INFO - 2024-12-03 09:40:43 --> Model "Review_model" initialized
INFO - 2024-12-03 09:40:43 --> Model "News_model" initialized
INFO - 2024-12-03 09:40:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:40:43 --> Query result: stdClass Object
(
    [view_count] => 5
)

INFO - 2024-12-03 09:40:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:40:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:40:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:40:43 --> Final output sent to browser
DEBUG - 2024-12-03 09:40:43 --> Total execution time: 0.1318
INFO - 2024-12-03 09:40:43 --> Config Class Initialized
INFO - 2024-12-03 09:40:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:43 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:43 --> URI Class Initialized
INFO - 2024-12-03 09:40:43 --> Router Class Initialized
INFO - 2024-12-03 09:40:43 --> Output Class Initialized
INFO - 2024-12-03 09:40:44 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:44 --> CSRF cookie sent
INFO - 2024-12-03 09:40:44 --> Input Class Initialized
INFO - 2024-12-03 09:40:44 --> Language Class Initialized
ERROR - 2024-12-03 09:40:44 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:40:48 --> Config Class Initialized
INFO - 2024-12-03 09:40:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:48 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:48 --> URI Class Initialized
INFO - 2024-12-03 09:40:48 --> Router Class Initialized
INFO - 2024-12-03 09:40:48 --> Output Class Initialized
INFO - 2024-12-03 09:40:48 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:48 --> CSRF cookie sent
INFO - 2024-12-03 09:40:48 --> Input Class Initialized
INFO - 2024-12-03 09:40:48 --> Language Class Initialized
INFO - 2024-12-03 09:40:48 --> Loader Class Initialized
INFO - 2024-12-03 09:40:48 --> Helper loaded: url_helper
INFO - 2024-12-03 09:40:48 --> Helper loaded: form_helper
INFO - 2024-12-03 09:40:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:40:48 --> Form Validation Class Initialized
INFO - 2024-12-03 09:40:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:40:48 --> Controller Class Initialized
INFO - 2024-12-03 09:40:48 --> Model "User_model" initialized
INFO - 2024-12-03 09:40:48 --> Model "Category_model" initialized
INFO - 2024-12-03 09:40:48 --> Model "Review_model" initialized
INFO - 2024-12-03 09:40:48 --> Model "News_model" initialized
INFO - 2024-12-03 09:40:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:40:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:40:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:40:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:40:48 --> Final output sent to browser
DEBUG - 2024-12-03 09:40:48 --> Total execution time: 0.0591
INFO - 2024-12-03 09:40:55 --> Config Class Initialized
INFO - 2024-12-03 09:40:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:55 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:55 --> URI Class Initialized
INFO - 2024-12-03 09:40:55 --> Router Class Initialized
INFO - 2024-12-03 09:40:55 --> Output Class Initialized
INFO - 2024-12-03 09:40:55 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:55 --> CSRF cookie sent
INFO - 2024-12-03 09:40:55 --> CSRF token verified
INFO - 2024-12-03 09:40:55 --> Input Class Initialized
INFO - 2024-12-03 09:40:55 --> Language Class Initialized
INFO - 2024-12-03 09:40:55 --> Loader Class Initialized
INFO - 2024-12-03 09:40:55 --> Helper loaded: url_helper
INFO - 2024-12-03 09:40:55 --> Helper loaded: form_helper
INFO - 2024-12-03 09:40:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:40:55 --> Form Validation Class Initialized
INFO - 2024-12-03 09:40:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:40:55 --> Controller Class Initialized
INFO - 2024-12-03 09:40:55 --> Model "User_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "Category_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "Review_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "News_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:40:55 --> Config Class Initialized
INFO - 2024-12-03 09:40:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:55 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:55 --> URI Class Initialized
INFO - 2024-12-03 09:40:55 --> Router Class Initialized
INFO - 2024-12-03 09:40:55 --> Output Class Initialized
INFO - 2024-12-03 09:40:55 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:55 --> CSRF cookie sent
INFO - 2024-12-03 09:40:55 --> Input Class Initialized
INFO - 2024-12-03 09:40:55 --> Language Class Initialized
INFO - 2024-12-03 09:40:55 --> Loader Class Initialized
INFO - 2024-12-03 09:40:55 --> Helper loaded: url_helper
INFO - 2024-12-03 09:40:55 --> Helper loaded: form_helper
INFO - 2024-12-03 09:40:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:40:55 --> Form Validation Class Initialized
INFO - 2024-12-03 09:40:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:40:55 --> Controller Class Initialized
INFO - 2024-12-03 09:40:55 --> Model "User_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "Category_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "Review_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "News_model" initialized
INFO - 2024-12-03 09:40:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:40:55 --> Query result: stdClass Object
(
    [view_count] => 6
)

INFO - 2024-12-03 09:40:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:40:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:40:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:40:55 --> Final output sent to browser
DEBUG - 2024-12-03 09:40:55 --> Total execution time: 0.2085
INFO - 2024-12-03 09:40:55 --> Config Class Initialized
INFO - 2024-12-03 09:40:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:40:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:40:55 --> Utf8 Class Initialized
INFO - 2024-12-03 09:40:55 --> URI Class Initialized
INFO - 2024-12-03 09:40:55 --> Router Class Initialized
INFO - 2024-12-03 09:40:55 --> Output Class Initialized
INFO - 2024-12-03 09:40:55 --> Security Class Initialized
DEBUG - 2024-12-03 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:40:55 --> CSRF cookie sent
INFO - 2024-12-03 09:40:55 --> Input Class Initialized
INFO - 2024-12-03 09:40:55 --> Language Class Initialized
ERROR - 2024-12-03 09:40:56 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:41:02 --> Config Class Initialized
INFO - 2024-12-03 09:41:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:41:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:41:02 --> Utf8 Class Initialized
INFO - 2024-12-03 09:41:02 --> URI Class Initialized
INFO - 2024-12-03 09:41:02 --> Router Class Initialized
INFO - 2024-12-03 09:41:02 --> Output Class Initialized
INFO - 2024-12-03 09:41:02 --> Security Class Initialized
DEBUG - 2024-12-03 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:41:02 --> CSRF cookie sent
INFO - 2024-12-03 09:41:02 --> Input Class Initialized
INFO - 2024-12-03 09:41:02 --> Language Class Initialized
INFO - 2024-12-03 09:41:02 --> Loader Class Initialized
INFO - 2024-12-03 09:41:02 --> Helper loaded: url_helper
INFO - 2024-12-03 09:41:03 --> Helper loaded: form_helper
INFO - 2024-12-03 09:41:03 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:41:03 --> Form Validation Class Initialized
INFO - 2024-12-03 09:41:03 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:41:03 --> Controller Class Initialized
INFO - 2024-12-03 09:41:03 --> Model "User_model" initialized
INFO - 2024-12-03 09:41:03 --> Model "Category_model" initialized
INFO - 2024-12-03 09:41:03 --> Model "Review_model" initialized
INFO - 2024-12-03 09:41:03 --> Model "News_model" initialized
INFO - 2024-12-03 09:41:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:41:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:41:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-03 09:41:03 --> Final output sent to browser
DEBUG - 2024-12-03 09:41:03 --> Total execution time: 0.0745
INFO - 2024-12-03 09:41:08 --> Config Class Initialized
INFO - 2024-12-03 09:41:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:41:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:41:08 --> Utf8 Class Initialized
INFO - 2024-12-03 09:41:08 --> URI Class Initialized
INFO - 2024-12-03 09:41:08 --> Router Class Initialized
INFO - 2024-12-03 09:41:08 --> Output Class Initialized
INFO - 2024-12-03 09:41:08 --> Security Class Initialized
DEBUG - 2024-12-03 09:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:41:08 --> CSRF cookie sent
INFO - 2024-12-03 09:41:08 --> Input Class Initialized
INFO - 2024-12-03 09:41:08 --> Language Class Initialized
INFO - 2024-12-03 09:41:08 --> Loader Class Initialized
INFO - 2024-12-03 09:41:08 --> Helper loaded: url_helper
INFO - 2024-12-03 09:41:08 --> Helper loaded: form_helper
INFO - 2024-12-03 09:41:08 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:41:08 --> Form Validation Class Initialized
INFO - 2024-12-03 09:41:08 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:41:08 --> Controller Class Initialized
INFO - 2024-12-03 09:41:08 --> Model "User_model" initialized
INFO - 2024-12-03 09:41:08 --> Model "Category_model" initialized
INFO - 2024-12-03 09:41:08 --> Model "Review_model" initialized
INFO - 2024-12-03 09:41:08 --> Model "News_model" initialized
INFO - 2024-12-03 09:41:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:41:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:41:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:41:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:41:08 --> Final output sent to browser
DEBUG - 2024-12-03 09:41:08 --> Total execution time: 0.0550
INFO - 2024-12-03 09:45:21 --> Config Class Initialized
INFO - 2024-12-03 09:45:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:45:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:45:21 --> Utf8 Class Initialized
INFO - 2024-12-03 09:45:21 --> URI Class Initialized
INFO - 2024-12-03 09:45:21 --> Router Class Initialized
INFO - 2024-12-03 09:45:21 --> Output Class Initialized
INFO - 2024-12-03 09:45:21 --> Security Class Initialized
DEBUG - 2024-12-03 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:45:21 --> CSRF cookie sent
INFO - 2024-12-03 09:45:21 --> Input Class Initialized
INFO - 2024-12-03 09:45:21 --> Language Class Initialized
INFO - 2024-12-03 09:45:21 --> Loader Class Initialized
INFO - 2024-12-03 09:45:21 --> Helper loaded: url_helper
INFO - 2024-12-03 09:45:21 --> Helper loaded: form_helper
INFO - 2024-12-03 09:45:21 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:45:21 --> Form Validation Class Initialized
INFO - 2024-12-03 09:45:21 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:45:21 --> Controller Class Initialized
INFO - 2024-12-03 09:45:21 --> Model "User_model" initialized
INFO - 2024-12-03 09:45:21 --> Model "Category_model" initialized
INFO - 2024-12-03 09:45:21 --> Model "Review_model" initialized
INFO - 2024-12-03 09:45:21 --> Model "News_model" initialized
INFO - 2024-12-03 09:45:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:45:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:45:21 --> Query result: stdClass Object
(
    [view_count] => 7
)

INFO - 2024-12-03 09:45:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:45:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:45:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:45:21 --> Final output sent to browser
DEBUG - 2024-12-03 09:45:21 --> Total execution time: 0.6812
INFO - 2024-12-03 09:45:36 --> Config Class Initialized
INFO - 2024-12-03 09:45:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:45:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:45:36 --> Utf8 Class Initialized
INFO - 2024-12-03 09:45:36 --> URI Class Initialized
INFO - 2024-12-03 09:45:36 --> Router Class Initialized
INFO - 2024-12-03 09:45:36 --> Output Class Initialized
INFO - 2024-12-03 09:45:36 --> Security Class Initialized
DEBUG - 2024-12-03 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:45:36 --> CSRF cookie sent
INFO - 2024-12-03 09:45:36 --> Input Class Initialized
INFO - 2024-12-03 09:45:36 --> Language Class Initialized
ERROR - 2024-12-03 09:45:36 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:45:52 --> Config Class Initialized
INFO - 2024-12-03 09:45:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:45:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:45:52 --> Utf8 Class Initialized
INFO - 2024-12-03 09:45:52 --> URI Class Initialized
INFO - 2024-12-03 09:45:52 --> Router Class Initialized
INFO - 2024-12-03 09:45:52 --> Output Class Initialized
INFO - 2024-12-03 09:45:52 --> Security Class Initialized
DEBUG - 2024-12-03 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:45:52 --> CSRF cookie sent
INFO - 2024-12-03 09:45:52 --> Input Class Initialized
INFO - 2024-12-03 09:45:52 --> Language Class Initialized
INFO - 2024-12-03 09:45:52 --> Loader Class Initialized
INFO - 2024-12-03 09:45:52 --> Helper loaded: url_helper
INFO - 2024-12-03 09:45:52 --> Helper loaded: form_helper
INFO - 2024-12-03 09:45:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:45:52 --> Form Validation Class Initialized
INFO - 2024-12-03 09:45:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:45:52 --> Controller Class Initialized
INFO - 2024-12-03 09:45:52 --> Model "User_model" initialized
INFO - 2024-12-03 09:45:52 --> Model "Category_model" initialized
INFO - 2024-12-03 09:45:52 --> Model "Review_model" initialized
INFO - 2024-12-03 09:45:52 --> Model "News_model" initialized
INFO - 2024-12-03 09:45:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:45:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:45:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:45:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-03 09:45:53 --> Final output sent to browser
DEBUG - 2024-12-03 09:45:53 --> Total execution time: 0.1207
INFO - 2024-12-03 09:46:02 --> Config Class Initialized
INFO - 2024-12-03 09:46:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:46:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:46:02 --> Utf8 Class Initialized
INFO - 2024-12-03 09:46:02 --> URI Class Initialized
INFO - 2024-12-03 09:46:02 --> Router Class Initialized
INFO - 2024-12-03 09:46:02 --> Output Class Initialized
INFO - 2024-12-03 09:46:02 --> Security Class Initialized
DEBUG - 2024-12-03 09:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:46:02 --> CSRF cookie sent
INFO - 2024-12-03 09:46:02 --> Input Class Initialized
INFO - 2024-12-03 09:46:02 --> Language Class Initialized
INFO - 2024-12-03 09:46:02 --> Loader Class Initialized
INFO - 2024-12-03 09:46:02 --> Helper loaded: url_helper
INFO - 2024-12-03 09:46:02 --> Helper loaded: form_helper
INFO - 2024-12-03 09:46:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:46:02 --> Form Validation Class Initialized
INFO - 2024-12-03 09:46:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:46:02 --> Controller Class Initialized
INFO - 2024-12-03 09:46:02 --> Model "User_model" initialized
DEBUG - 2024-12-03 09:46:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:46:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:46:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:46:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-03 09:46:02 --> Final output sent to browser
DEBUG - 2024-12-03 09:46:02 --> Total execution time: 0.0823
INFO - 2024-12-03 09:47:25 --> Config Class Initialized
INFO - 2024-12-03 09:47:25 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:47:25 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:47:25 --> Utf8 Class Initialized
INFO - 2024-12-03 09:47:25 --> URI Class Initialized
INFO - 2024-12-03 09:47:25 --> Router Class Initialized
INFO - 2024-12-03 09:47:25 --> Output Class Initialized
INFO - 2024-12-03 09:47:25 --> Security Class Initialized
DEBUG - 2024-12-03 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:47:25 --> CSRF cookie sent
INFO - 2024-12-03 09:47:25 --> Input Class Initialized
INFO - 2024-12-03 09:47:25 --> Language Class Initialized
INFO - 2024-12-03 09:47:25 --> Loader Class Initialized
INFO - 2024-12-03 09:47:25 --> Helper loaded: url_helper
INFO - 2024-12-03 09:47:25 --> Helper loaded: form_helper
INFO - 2024-12-03 09:47:25 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:47:25 --> Form Validation Class Initialized
INFO - 2024-12-03 09:47:25 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:47:25 --> Controller Class Initialized
INFO - 2024-12-03 09:47:25 --> Model "User_model" initialized
INFO - 2024-12-03 09:47:25 --> Model "Category_model" initialized
INFO - 2024-12-03 09:47:25 --> Model "Review_model" initialized
INFO - 2024-12-03 09:47:25 --> Model "News_model" initialized
INFO - 2024-12-03 09:47:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:47:25 --> Query result: stdClass Object
(
    [view_count] => 8
)

INFO - 2024-12-03 09:47:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:47:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:47:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:47:25 --> Final output sent to browser
DEBUG - 2024-12-03 09:47:25 --> Total execution time: 0.1761
INFO - 2024-12-03 09:47:27 --> Config Class Initialized
INFO - 2024-12-03 09:47:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:47:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:47:27 --> Utf8 Class Initialized
INFO - 2024-12-03 09:47:27 --> URI Class Initialized
INFO - 2024-12-03 09:47:27 --> Router Class Initialized
INFO - 2024-12-03 09:47:27 --> Output Class Initialized
INFO - 2024-12-03 09:47:27 --> Security Class Initialized
DEBUG - 2024-12-03 09:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:47:27 --> CSRF cookie sent
INFO - 2024-12-03 09:47:27 --> Input Class Initialized
INFO - 2024-12-03 09:47:27 --> Language Class Initialized
INFO - 2024-12-03 09:47:27 --> Loader Class Initialized
INFO - 2024-12-03 09:47:27 --> Helper loaded: url_helper
INFO - 2024-12-03 09:47:27 --> Helper loaded: form_helper
INFO - 2024-12-03 09:47:27 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:47:27 --> Form Validation Class Initialized
INFO - 2024-12-03 09:47:27 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:47:27 --> Controller Class Initialized
INFO - 2024-12-03 09:47:27 --> Model "User_model" initialized
INFO - 2024-12-03 09:47:27 --> Model "Category_model" initialized
INFO - 2024-12-03 09:47:27 --> Model "Review_model" initialized
INFO - 2024-12-03 09:47:27 --> Model "News_model" initialized
INFO - 2024-12-03 09:47:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:47:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:47:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:47:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 09:47:27 --> Final output sent to browser
DEBUG - 2024-12-03 09:47:27 --> Total execution time: 0.0767
INFO - 2024-12-03 09:51:42 --> Config Class Initialized
INFO - 2024-12-03 09:51:42 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:51:42 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:51:42 --> Utf8 Class Initialized
INFO - 2024-12-03 09:51:42 --> URI Class Initialized
INFO - 2024-12-03 09:51:42 --> Router Class Initialized
INFO - 2024-12-03 09:51:42 --> Output Class Initialized
INFO - 2024-12-03 09:51:42 --> Security Class Initialized
DEBUG - 2024-12-03 09:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:51:42 --> CSRF cookie sent
INFO - 2024-12-03 09:51:42 --> CSRF token verified
INFO - 2024-12-03 09:51:42 --> Input Class Initialized
INFO - 2024-12-03 09:51:42 --> Language Class Initialized
INFO - 2024-12-03 09:51:42 --> Loader Class Initialized
INFO - 2024-12-03 09:51:42 --> Helper loaded: url_helper
INFO - 2024-12-03 09:51:42 --> Helper loaded: form_helper
INFO - 2024-12-03 09:51:42 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:51:43 --> Form Validation Class Initialized
INFO - 2024-12-03 09:51:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:51:43 --> Controller Class Initialized
INFO - 2024-12-03 09:51:43 --> Model "User_model" initialized
INFO - 2024-12-03 09:51:43 --> Model "Category_model" initialized
INFO - 2024-12-03 09:51:43 --> Model "Review_model" initialized
INFO - 2024-12-03 09:51:43 --> Model "News_model" initialized
INFO - 2024-12-03 09:51:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:51:43 --> Upload Class Initialized
INFO - 2024-12-03 09:51:43 --> Language file loaded: language/english/upload_lang.php
INFO - 2024-12-03 09:51:43 --> The file you are attempting to upload is larger than the permitted size.
INFO - 2024-12-03 09:51:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:51:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:51:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 09:51:43 --> Final output sent to browser
DEBUG - 2024-12-03 09:51:43 --> Total execution time: 1.3096
INFO - 2024-12-03 09:51:50 --> Config Class Initialized
INFO - 2024-12-03 09:51:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:51:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:51:50 --> Utf8 Class Initialized
INFO - 2024-12-03 09:51:50 --> URI Class Initialized
INFO - 2024-12-03 09:51:50 --> Router Class Initialized
INFO - 2024-12-03 09:51:50 --> Output Class Initialized
INFO - 2024-12-03 09:51:50 --> Security Class Initialized
DEBUG - 2024-12-03 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:51:50 --> CSRF cookie sent
INFO - 2024-12-03 09:51:50 --> Input Class Initialized
INFO - 2024-12-03 09:51:50 --> Language Class Initialized
INFO - 2024-12-03 09:51:50 --> Loader Class Initialized
INFO - 2024-12-03 09:51:50 --> Helper loaded: url_helper
INFO - 2024-12-03 09:51:50 --> Helper loaded: form_helper
INFO - 2024-12-03 09:51:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:51:50 --> Form Validation Class Initialized
INFO - 2024-12-03 09:51:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:51:50 --> Controller Class Initialized
INFO - 2024-12-03 09:51:50 --> Model "User_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "Category_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "Review_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "News_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:51:50 --> Config Class Initialized
INFO - 2024-12-03 09:51:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:51:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:51:50 --> Utf8 Class Initialized
INFO - 2024-12-03 09:51:50 --> URI Class Initialized
INFO - 2024-12-03 09:51:50 --> Router Class Initialized
INFO - 2024-12-03 09:51:50 --> Output Class Initialized
INFO - 2024-12-03 09:51:50 --> Security Class Initialized
DEBUG - 2024-12-03 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:51:50 --> CSRF cookie sent
INFO - 2024-12-03 09:51:50 --> Input Class Initialized
INFO - 2024-12-03 09:51:50 --> Language Class Initialized
INFO - 2024-12-03 09:51:50 --> Loader Class Initialized
INFO - 2024-12-03 09:51:50 --> Helper loaded: url_helper
INFO - 2024-12-03 09:51:50 --> Helper loaded: form_helper
INFO - 2024-12-03 09:51:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:51:50 --> Form Validation Class Initialized
INFO - 2024-12-03 09:51:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:51:50 --> Controller Class Initialized
INFO - 2024-12-03 09:51:50 --> Model "User_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "Category_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "Review_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "News_model" initialized
INFO - 2024-12-03 09:51:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:51:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:51:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:51:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:51:50 --> Final output sent to browser
DEBUG - 2024-12-03 09:51:50 --> Total execution time: 0.0423
INFO - 2024-12-03 09:51:55 --> Config Class Initialized
INFO - 2024-12-03 09:51:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:51:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:51:55 --> Utf8 Class Initialized
INFO - 2024-12-03 09:51:55 --> URI Class Initialized
INFO - 2024-12-03 09:51:55 --> Router Class Initialized
INFO - 2024-12-03 09:51:55 --> Output Class Initialized
INFO - 2024-12-03 09:51:55 --> Security Class Initialized
DEBUG - 2024-12-03 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:51:55 --> CSRF cookie sent
INFO - 2024-12-03 09:51:55 --> CSRF token verified
INFO - 2024-12-03 09:51:55 --> Input Class Initialized
INFO - 2024-12-03 09:51:55 --> Language Class Initialized
INFO - 2024-12-03 09:51:55 --> Loader Class Initialized
INFO - 2024-12-03 09:51:55 --> Helper loaded: url_helper
INFO - 2024-12-03 09:51:55 --> Helper loaded: form_helper
INFO - 2024-12-03 09:51:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:51:56 --> Form Validation Class Initialized
INFO - 2024-12-03 09:51:56 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:51:56 --> Controller Class Initialized
INFO - 2024-12-03 09:51:56 --> Model "User_model" initialized
INFO - 2024-12-03 09:51:56 --> Model "Category_model" initialized
INFO - 2024-12-03 09:51:56 --> Model "Review_model" initialized
INFO - 2024-12-03 09:51:56 --> Model "News_model" initialized
INFO - 2024-12-03 09:51:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:51:56 --> Config Class Initialized
INFO - 2024-12-03 09:51:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:51:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:51:56 --> Utf8 Class Initialized
INFO - 2024-12-03 09:51:56 --> URI Class Initialized
INFO - 2024-12-03 09:51:56 --> Router Class Initialized
INFO - 2024-12-03 09:51:56 --> Output Class Initialized
INFO - 2024-12-03 09:51:56 --> Security Class Initialized
DEBUG - 2024-12-03 09:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:51:56 --> CSRF cookie sent
INFO - 2024-12-03 09:51:56 --> Input Class Initialized
INFO - 2024-12-03 09:51:56 --> Language Class Initialized
INFO - 2024-12-03 09:51:56 --> Loader Class Initialized
INFO - 2024-12-03 09:51:56 --> Helper loaded: url_helper
INFO - 2024-12-03 09:51:56 --> Helper loaded: form_helper
INFO - 2024-12-03 09:51:56 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:51:56 --> Form Validation Class Initialized
INFO - 2024-12-03 09:51:56 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:51:56 --> Controller Class Initialized
INFO - 2024-12-03 09:51:56 --> Model "Category_model" initialized
INFO - 2024-12-03 09:51:56 --> Model "User_model" initialized
INFO - 2024-12-03 09:51:56 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:51:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:51:56 --> Final output sent to browser
DEBUG - 2024-12-03 09:51:56 --> Total execution time: 0.1365
INFO - 2024-12-03 09:52:01 --> Config Class Initialized
INFO - 2024-12-03 09:52:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:01 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:01 --> URI Class Initialized
INFO - 2024-12-03 09:52:01 --> Router Class Initialized
INFO - 2024-12-03 09:52:01 --> Output Class Initialized
INFO - 2024-12-03 09:52:01 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:01 --> CSRF cookie sent
INFO - 2024-12-03 09:52:01 --> Input Class Initialized
INFO - 2024-12-03 09:52:01 --> Language Class Initialized
INFO - 2024-12-03 09:52:01 --> Loader Class Initialized
INFO - 2024-12-03 09:52:01 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:01 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:01 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:01 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:01 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:01 --> Controller Class Initialized
INFO - 2024-12-03 09:52:01 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:01 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:01 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:01 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:01 --> Total execution time: 0.0425
INFO - 2024-12-03 09:52:02 --> Config Class Initialized
INFO - 2024-12-03 09:52:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:02 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:02 --> URI Class Initialized
INFO - 2024-12-03 09:52:02 --> Router Class Initialized
INFO - 2024-12-03 09:52:02 --> Output Class Initialized
INFO - 2024-12-03 09:52:02 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:02 --> CSRF cookie sent
INFO - 2024-12-03 09:52:02 --> Input Class Initialized
INFO - 2024-12-03 09:52:02 --> Language Class Initialized
INFO - 2024-12-03 09:52:02 --> Loader Class Initialized
INFO - 2024-12-03 09:52:02 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:02 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:02 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:02 --> Controller Class Initialized
INFO - 2024-12-03 09:52:02 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:02 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:02 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:02 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:02 --> Total execution time: 0.0480
INFO - 2024-12-03 09:52:03 --> Config Class Initialized
INFO - 2024-12-03 09:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:03 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:03 --> URI Class Initialized
INFO - 2024-12-03 09:52:03 --> Router Class Initialized
INFO - 2024-12-03 09:52:03 --> Output Class Initialized
INFO - 2024-12-03 09:52:03 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:03 --> CSRF cookie sent
INFO - 2024-12-03 09:52:03 --> Input Class Initialized
INFO - 2024-12-03 09:52:03 --> Language Class Initialized
INFO - 2024-12-03 09:52:03 --> Loader Class Initialized
INFO - 2024-12-03 09:52:03 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:03 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:03 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:03 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:03 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:03 --> Controller Class Initialized
INFO - 2024-12-03 09:52:03 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:03 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:03 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:03 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:03 --> Total execution time: 0.0457
INFO - 2024-12-03 09:52:03 --> Config Class Initialized
INFO - 2024-12-03 09:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:03 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:03 --> URI Class Initialized
INFO - 2024-12-03 09:52:03 --> Router Class Initialized
INFO - 2024-12-03 09:52:03 --> Output Class Initialized
INFO - 2024-12-03 09:52:03 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:03 --> CSRF cookie sent
INFO - 2024-12-03 09:52:03 --> Input Class Initialized
INFO - 2024-12-03 09:52:03 --> Language Class Initialized
INFO - 2024-12-03 09:52:03 --> Loader Class Initialized
INFO - 2024-12-03 09:52:03 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:03 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:03 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:03 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:03 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:03 --> Controller Class Initialized
INFO - 2024-12-03 09:52:03 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:03 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:03 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:03 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:03 --> Total execution time: 0.0520
INFO - 2024-12-03 09:52:03 --> Config Class Initialized
INFO - 2024-12-03 09:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:04 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:04 --> URI Class Initialized
INFO - 2024-12-03 09:52:04 --> Router Class Initialized
INFO - 2024-12-03 09:52:04 --> Output Class Initialized
INFO - 2024-12-03 09:52:04 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:04 --> CSRF cookie sent
INFO - 2024-12-03 09:52:04 --> Input Class Initialized
INFO - 2024-12-03 09:52:04 --> Language Class Initialized
INFO - 2024-12-03 09:52:04 --> Loader Class Initialized
INFO - 2024-12-03 09:52:04 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:04 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:04 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:04 --> Controller Class Initialized
INFO - 2024-12-03 09:52:04 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:04 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:04 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:04 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:04 --> Total execution time: 0.0436
INFO - 2024-12-03 09:52:04 --> Config Class Initialized
INFO - 2024-12-03 09:52:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:04 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:04 --> URI Class Initialized
INFO - 2024-12-03 09:52:04 --> Router Class Initialized
INFO - 2024-12-03 09:52:04 --> Output Class Initialized
INFO - 2024-12-03 09:52:04 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:04 --> CSRF cookie sent
INFO - 2024-12-03 09:52:04 --> Input Class Initialized
INFO - 2024-12-03 09:52:04 --> Language Class Initialized
INFO - 2024-12-03 09:52:04 --> Loader Class Initialized
INFO - 2024-12-03 09:52:04 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:04 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:04 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:04 --> Controller Class Initialized
INFO - 2024-12-03 09:52:04 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:04 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:04 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:04 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:04 --> Total execution time: 0.0521
INFO - 2024-12-03 09:52:04 --> Config Class Initialized
INFO - 2024-12-03 09:52:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:04 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:04 --> URI Class Initialized
INFO - 2024-12-03 09:52:04 --> Router Class Initialized
INFO - 2024-12-03 09:52:04 --> Output Class Initialized
INFO - 2024-12-03 09:52:04 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:04 --> CSRF cookie sent
INFO - 2024-12-03 09:52:04 --> Input Class Initialized
INFO - 2024-12-03 09:52:04 --> Language Class Initialized
INFO - 2024-12-03 09:52:04 --> Loader Class Initialized
INFO - 2024-12-03 09:52:04 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:04 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:04 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:04 --> Controller Class Initialized
INFO - 2024-12-03 09:52:04 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:04 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:04 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:04 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:04 --> Total execution time: 0.0364
INFO - 2024-12-03 09:52:05 --> Config Class Initialized
INFO - 2024-12-03 09:52:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:05 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:05 --> URI Class Initialized
INFO - 2024-12-03 09:52:05 --> Router Class Initialized
INFO - 2024-12-03 09:52:05 --> Output Class Initialized
INFO - 2024-12-03 09:52:05 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:05 --> CSRF cookie sent
INFO - 2024-12-03 09:52:05 --> Input Class Initialized
INFO - 2024-12-03 09:52:05 --> Language Class Initialized
INFO - 2024-12-03 09:52:05 --> Loader Class Initialized
INFO - 2024-12-03 09:52:05 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:05 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:05 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:05 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:05 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:05 --> Controller Class Initialized
INFO - 2024-12-03 09:52:05 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:05 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:05 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:05 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:05 --> Total execution time: 0.0379
INFO - 2024-12-03 09:52:05 --> Config Class Initialized
INFO - 2024-12-03 09:52:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:05 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:05 --> URI Class Initialized
INFO - 2024-12-03 09:52:05 --> Router Class Initialized
INFO - 2024-12-03 09:52:05 --> Output Class Initialized
INFO - 2024-12-03 09:52:05 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:05 --> CSRF cookie sent
INFO - 2024-12-03 09:52:05 --> Input Class Initialized
INFO - 2024-12-03 09:52:05 --> Language Class Initialized
INFO - 2024-12-03 09:52:05 --> Loader Class Initialized
INFO - 2024-12-03 09:52:05 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:05 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:05 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:05 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:05 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:05 --> Controller Class Initialized
INFO - 2024-12-03 09:52:05 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:05 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:05 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:05 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:05 --> Total execution time: 0.0386
INFO - 2024-12-03 09:52:08 --> Config Class Initialized
INFO - 2024-12-03 09:52:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:08 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:08 --> URI Class Initialized
INFO - 2024-12-03 09:52:08 --> Router Class Initialized
INFO - 2024-12-03 09:52:08 --> Output Class Initialized
INFO - 2024-12-03 09:52:08 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:08 --> CSRF cookie sent
INFO - 2024-12-03 09:52:08 --> Input Class Initialized
INFO - 2024-12-03 09:52:08 --> Language Class Initialized
INFO - 2024-12-03 09:52:08 --> Loader Class Initialized
INFO - 2024-12-03 09:52:08 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:08 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:08 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:08 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:08 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:08 --> Controller Class Initialized
INFO - 2024-12-03 09:52:08 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:08 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:08 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:08 --> Total execution time: 0.0620
INFO - 2024-12-03 09:52:09 --> Config Class Initialized
INFO - 2024-12-03 09:52:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:09 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:09 --> URI Class Initialized
INFO - 2024-12-03 09:52:09 --> Router Class Initialized
INFO - 2024-12-03 09:52:09 --> Output Class Initialized
INFO - 2024-12-03 09:52:09 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:09 --> CSRF cookie sent
INFO - 2024-12-03 09:52:09 --> Input Class Initialized
INFO - 2024-12-03 09:52:09 --> Language Class Initialized
INFO - 2024-12-03 09:52:09 --> Loader Class Initialized
INFO - 2024-12-03 09:52:09 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:09 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:10 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:10 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:10 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:10 --> Controller Class Initialized
INFO - 2024-12-03 09:52:10 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:10 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:10 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:52:10 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:10 --> Total execution time: 0.0482
INFO - 2024-12-03 09:52:10 --> Config Class Initialized
INFO - 2024-12-03 09:52:10 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:10 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:10 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:10 --> URI Class Initialized
INFO - 2024-12-03 09:52:10 --> Router Class Initialized
INFO - 2024-12-03 09:52:10 --> Output Class Initialized
INFO - 2024-12-03 09:52:10 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:11 --> CSRF cookie sent
INFO - 2024-12-03 09:52:11 --> Input Class Initialized
INFO - 2024-12-03 09:52:11 --> Language Class Initialized
INFO - 2024-12-03 09:52:11 --> Loader Class Initialized
INFO - 2024-12-03 09:52:11 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:11 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:11 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:11 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:11 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:11 --> Controller Class Initialized
INFO - 2024-12-03 09:52:11 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:11 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:11 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:52:11 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:11 --> Total execution time: 0.0428
INFO - 2024-12-03 09:52:12 --> Config Class Initialized
INFO - 2024-12-03 09:52:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:12 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:12 --> URI Class Initialized
INFO - 2024-12-03 09:52:12 --> Router Class Initialized
INFO - 2024-12-03 09:52:12 --> Output Class Initialized
INFO - 2024-12-03 09:52:12 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:12 --> CSRF cookie sent
INFO - 2024-12-03 09:52:12 --> Input Class Initialized
INFO - 2024-12-03 09:52:12 --> Language Class Initialized
INFO - 2024-12-03 09:52:12 --> Loader Class Initialized
INFO - 2024-12-03 09:52:12 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:12 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:12 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:12 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:12 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:12 --> Controller Class Initialized
INFO - 2024-12-03 09:52:12 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:12 --> Config Class Initialized
INFO - 2024-12-03 09:52:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:12 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:12 --> URI Class Initialized
INFO - 2024-12-03 09:52:12 --> Router Class Initialized
INFO - 2024-12-03 09:52:12 --> Output Class Initialized
INFO - 2024-12-03 09:52:12 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:12 --> CSRF cookie sent
INFO - 2024-12-03 09:52:12 --> Input Class Initialized
INFO - 2024-12-03 09:52:12 --> Language Class Initialized
INFO - 2024-12-03 09:52:12 --> Loader Class Initialized
INFO - 2024-12-03 09:52:12 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:12 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:12 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:12 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:12 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:12 --> Controller Class Initialized
INFO - 2024-12-03 09:52:12 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:52:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:52:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:52:12 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:12 --> Total execution time: 0.0484
INFO - 2024-12-03 09:52:14 --> Config Class Initialized
INFO - 2024-12-03 09:52:14 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:14 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:14 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:14 --> URI Class Initialized
INFO - 2024-12-03 09:52:14 --> Router Class Initialized
INFO - 2024-12-03 09:52:14 --> Output Class Initialized
INFO - 2024-12-03 09:52:14 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:14 --> CSRF cookie sent
INFO - 2024-12-03 09:52:14 --> CSRF token verified
INFO - 2024-12-03 09:52:14 --> Input Class Initialized
INFO - 2024-12-03 09:52:14 --> Language Class Initialized
INFO - 2024-12-03 09:52:14 --> Loader Class Initialized
INFO - 2024-12-03 09:52:14 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:14 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:14 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:14 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:14 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:14 --> Controller Class Initialized
INFO - 2024-12-03 09:52:14 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:14 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:14 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:14 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:14 --> Config Class Initialized
INFO - 2024-12-03 09:52:14 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:14 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:14 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:14 --> URI Class Initialized
INFO - 2024-12-03 09:52:14 --> Router Class Initialized
INFO - 2024-12-03 09:52:14 --> Output Class Initialized
INFO - 2024-12-03 09:52:14 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:14 --> CSRF cookie sent
INFO - 2024-12-03 09:52:14 --> Input Class Initialized
INFO - 2024-12-03 09:52:14 --> Language Class Initialized
INFO - 2024-12-03 09:52:14 --> Loader Class Initialized
INFO - 2024-12-03 09:52:14 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:14 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:14 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:14 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:14 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:14 --> Controller Class Initialized
INFO - 2024-12-03 09:52:14 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:14 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:14 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:52:14 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:14 --> Total execution time: 0.0624
INFO - 2024-12-03 09:52:16 --> Config Class Initialized
INFO - 2024-12-03 09:52:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:16 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:16 --> URI Class Initialized
INFO - 2024-12-03 09:52:16 --> Router Class Initialized
INFO - 2024-12-03 09:52:16 --> Output Class Initialized
INFO - 2024-12-03 09:52:16 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:16 --> CSRF cookie sent
INFO - 2024-12-03 09:52:16 --> Input Class Initialized
INFO - 2024-12-03 09:52:16 --> Language Class Initialized
INFO - 2024-12-03 09:52:16 --> Loader Class Initialized
INFO - 2024-12-03 09:52:16 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:16 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:16 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:16 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:16 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:16 --> Controller Class Initialized
INFO - 2024-12-03 09:52:16 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:16 --> Config Class Initialized
INFO - 2024-12-03 09:52:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:16 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:16 --> URI Class Initialized
INFO - 2024-12-03 09:52:16 --> Router Class Initialized
INFO - 2024-12-03 09:52:16 --> Output Class Initialized
INFO - 2024-12-03 09:52:16 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:16 --> CSRF cookie sent
INFO - 2024-12-03 09:52:16 --> Input Class Initialized
INFO - 2024-12-03 09:52:16 --> Language Class Initialized
INFO - 2024-12-03 09:52:16 --> Loader Class Initialized
INFO - 2024-12-03 09:52:16 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:16 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:16 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:16 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:16 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:16 --> Controller Class Initialized
INFO - 2024-12-03 09:52:16 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:52:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:52:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:52:16 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:16 --> Total execution time: 0.0407
INFO - 2024-12-03 09:52:20 --> Config Class Initialized
INFO - 2024-12-03 09:52:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:20 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:20 --> URI Class Initialized
INFO - 2024-12-03 09:52:20 --> Router Class Initialized
INFO - 2024-12-03 09:52:20 --> Output Class Initialized
INFO - 2024-12-03 09:52:20 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:20 --> CSRF cookie sent
INFO - 2024-12-03 09:52:20 --> CSRF token verified
INFO - 2024-12-03 09:52:20 --> Input Class Initialized
INFO - 2024-12-03 09:52:20 --> Language Class Initialized
INFO - 2024-12-03 09:52:20 --> Loader Class Initialized
INFO - 2024-12-03 09:52:20 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:20 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:20 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:20 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:20 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:20 --> Controller Class Initialized
INFO - 2024-12-03 09:52:20 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:52:20 --> Config Class Initialized
INFO - 2024-12-03 09:52:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:20 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:20 --> URI Class Initialized
INFO - 2024-12-03 09:52:20 --> Router Class Initialized
INFO - 2024-12-03 09:52:20 --> Output Class Initialized
INFO - 2024-12-03 09:52:20 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:20 --> CSRF cookie sent
INFO - 2024-12-03 09:52:20 --> Input Class Initialized
INFO - 2024-12-03 09:52:20 --> Language Class Initialized
INFO - 2024-12-03 09:52:20 --> Loader Class Initialized
INFO - 2024-12-03 09:52:20 --> Helper loaded: url_helper
INFO - 2024-12-03 09:52:20 --> Helper loaded: form_helper
INFO - 2024-12-03 09:52:20 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:52:20 --> Form Validation Class Initialized
INFO - 2024-12-03 09:52:20 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:52:20 --> Controller Class Initialized
INFO - 2024-12-03 09:52:20 --> Model "User_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "Category_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "Review_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "News_model" initialized
INFO - 2024-12-03 09:52:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:52:20 --> Query result: stdClass Object
(
    [view_count] => 9
)

INFO - 2024-12-03 09:52:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:52:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:52:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:52:20 --> Final output sent to browser
DEBUG - 2024-12-03 09:52:20 --> Total execution time: 0.1575
INFO - 2024-12-03 09:52:23 --> Config Class Initialized
INFO - 2024-12-03 09:52:23 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:52:23 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:52:23 --> Utf8 Class Initialized
INFO - 2024-12-03 09:52:23 --> URI Class Initialized
INFO - 2024-12-03 09:52:23 --> Router Class Initialized
INFO - 2024-12-03 09:52:23 --> Output Class Initialized
INFO - 2024-12-03 09:52:23 --> Security Class Initialized
DEBUG - 2024-12-03 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:52:23 --> CSRF cookie sent
INFO - 2024-12-03 09:52:23 --> Input Class Initialized
INFO - 2024-12-03 09:52:23 --> Language Class Initialized
ERROR - 2024-12-03 09:52:23 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:53:13 --> Config Class Initialized
INFO - 2024-12-03 09:53:13 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:53:13 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:53:13 --> Utf8 Class Initialized
INFO - 2024-12-03 09:53:13 --> URI Class Initialized
INFO - 2024-12-03 09:53:13 --> Router Class Initialized
INFO - 2024-12-03 09:53:13 --> Output Class Initialized
INFO - 2024-12-03 09:53:13 --> Security Class Initialized
DEBUG - 2024-12-03 09:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:53:13 --> CSRF cookie sent
INFO - 2024-12-03 09:53:13 --> Input Class Initialized
INFO - 2024-12-03 09:53:13 --> Language Class Initialized
INFO - 2024-12-03 09:53:13 --> Loader Class Initialized
INFO - 2024-12-03 09:53:13 --> Helper loaded: url_helper
INFO - 2024-12-03 09:53:13 --> Helper loaded: form_helper
INFO - 2024-12-03 09:53:13 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:53:13 --> Form Validation Class Initialized
INFO - 2024-12-03 09:53:13 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:53:13 --> Controller Class Initialized
INFO - 2024-12-03 09:53:13 --> Model "User_model" initialized
INFO - 2024-12-03 09:53:13 --> Model "Category_model" initialized
INFO - 2024-12-03 09:53:13 --> Model "Review_model" initialized
INFO - 2024-12-03 09:53:13 --> Model "News_model" initialized
INFO - 2024-12-03 09:53:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:53:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:53:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:53:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 09:53:13 --> Final output sent to browser
DEBUG - 2024-12-03 09:53:13 --> Total execution time: 0.1619
INFO - 2024-12-03 09:56:03 --> Config Class Initialized
INFO - 2024-12-03 09:56:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:56:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:56:03 --> Utf8 Class Initialized
INFO - 2024-12-03 09:56:04 --> URI Class Initialized
INFO - 2024-12-03 09:56:04 --> Router Class Initialized
INFO - 2024-12-03 09:56:04 --> Output Class Initialized
INFO - 2024-12-03 09:56:04 --> Security Class Initialized
DEBUG - 2024-12-03 09:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:56:04 --> CSRF cookie sent
INFO - 2024-12-03 09:56:04 --> Input Class Initialized
INFO - 2024-12-03 09:56:04 --> Language Class Initialized
INFO - 2024-12-03 09:56:04 --> Loader Class Initialized
INFO - 2024-12-03 09:56:04 --> Helper loaded: url_helper
INFO - 2024-12-03 09:56:04 --> Helper loaded: form_helper
INFO - 2024-12-03 09:56:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:56:04 --> Form Validation Class Initialized
INFO - 2024-12-03 09:56:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:56:04 --> Controller Class Initialized
INFO - 2024-12-03 09:56:04 --> Model "User_model" initialized
INFO - 2024-12-03 09:56:04 --> Model "Category_model" initialized
INFO - 2024-12-03 09:56:04 --> Model "Review_model" initialized
INFO - 2024-12-03 09:56:04 --> Model "News_model" initialized
INFO - 2024-12-03 09:56:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:56:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:56:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:56:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 09:56:04 --> Final output sent to browser
DEBUG - 2024-12-03 09:56:04 --> Total execution time: 0.3874
INFO - 2024-12-03 09:57:27 --> Config Class Initialized
INFO - 2024-12-03 09:57:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:27 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:27 --> URI Class Initialized
INFO - 2024-12-03 09:57:27 --> Router Class Initialized
INFO - 2024-12-03 09:57:27 --> Output Class Initialized
INFO - 2024-12-03 09:57:27 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:27 --> CSRF cookie sent
INFO - 2024-12-03 09:57:28 --> CSRF token verified
INFO - 2024-12-03 09:57:28 --> Input Class Initialized
INFO - 2024-12-03 09:57:28 --> Language Class Initialized
INFO - 2024-12-03 09:57:28 --> Loader Class Initialized
INFO - 2024-12-03 09:57:28 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:28 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:28 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:28 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:28 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:28 --> Controller Class Initialized
INFO - 2024-12-03 09:57:28 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:28 --> Upload Class Initialized
INFO - 2024-12-03 09:57:28 --> Config Class Initialized
INFO - 2024-12-03 09:57:28 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:28 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:28 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:28 --> URI Class Initialized
INFO - 2024-12-03 09:57:28 --> Router Class Initialized
INFO - 2024-12-03 09:57:28 --> Output Class Initialized
INFO - 2024-12-03 09:57:28 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:28 --> CSRF cookie sent
INFO - 2024-12-03 09:57:28 --> Input Class Initialized
INFO - 2024-12-03 09:57:28 --> Language Class Initialized
INFO - 2024-12-03 09:57:28 --> Loader Class Initialized
INFO - 2024-12-03 09:57:28 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:28 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:28 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:28 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:28 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:28 --> Controller Class Initialized
INFO - 2024-12-03 09:57:28 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:57:28 --> Query result: stdClass Object
(
    [view_count] => 10
)

INFO - 2024-12-03 09:57:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:57:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:57:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:57:28 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:28 --> Total execution time: 0.0821
INFO - 2024-12-03 09:57:29 --> Config Class Initialized
INFO - 2024-12-03 09:57:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:29 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:29 --> URI Class Initialized
INFO - 2024-12-03 09:57:29 --> Router Class Initialized
INFO - 2024-12-03 09:57:29 --> Output Class Initialized
INFO - 2024-12-03 09:57:29 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:29 --> CSRF cookie sent
INFO - 2024-12-03 09:57:29 --> Input Class Initialized
INFO - 2024-12-03 09:57:29 --> Language Class Initialized
ERROR - 2024-12-03 09:57:29 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-03 09:57:34 --> Config Class Initialized
INFO - 2024-12-03 09:57:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:34 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:34 --> URI Class Initialized
INFO - 2024-12-03 09:57:34 --> Router Class Initialized
INFO - 2024-12-03 09:57:34 --> Output Class Initialized
INFO - 2024-12-03 09:57:34 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:34 --> CSRF cookie sent
INFO - 2024-12-03 09:57:34 --> Input Class Initialized
INFO - 2024-12-03 09:57:34 --> Language Class Initialized
INFO - 2024-12-03 09:57:34 --> Loader Class Initialized
INFO - 2024-12-03 09:57:34 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:34 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:34 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:34 --> Controller Class Initialized
INFO - 2024-12-03 09:57:34 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:34 --> Config Class Initialized
INFO - 2024-12-03 09:57:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:34 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:34 --> URI Class Initialized
INFO - 2024-12-03 09:57:34 --> Router Class Initialized
INFO - 2024-12-03 09:57:34 --> Output Class Initialized
INFO - 2024-12-03 09:57:34 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:34 --> CSRF cookie sent
INFO - 2024-12-03 09:57:34 --> Input Class Initialized
INFO - 2024-12-03 09:57:34 --> Language Class Initialized
INFO - 2024-12-03 09:57:34 --> Loader Class Initialized
INFO - 2024-12-03 09:57:34 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:34 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:34 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:34 --> Controller Class Initialized
INFO - 2024-12-03 09:57:34 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:57:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:57:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:57:34 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:34 --> Total execution time: 0.0582
INFO - 2024-12-03 09:57:38 --> Config Class Initialized
INFO - 2024-12-03 09:57:38 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:38 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:38 --> URI Class Initialized
INFO - 2024-12-03 09:57:38 --> Router Class Initialized
INFO - 2024-12-03 09:57:38 --> Output Class Initialized
INFO - 2024-12-03 09:57:38 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:38 --> CSRF cookie sent
INFO - 2024-12-03 09:57:38 --> CSRF token verified
INFO - 2024-12-03 09:57:38 --> Input Class Initialized
INFO - 2024-12-03 09:57:38 --> Language Class Initialized
INFO - 2024-12-03 09:57:38 --> Loader Class Initialized
INFO - 2024-12-03 09:57:38 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:38 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:38 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:38 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:38 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:38 --> Controller Class Initialized
INFO - 2024-12-03 09:57:38 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:38 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:38 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:38 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:39 --> Config Class Initialized
INFO - 2024-12-03 09:57:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:39 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:39 --> URI Class Initialized
INFO - 2024-12-03 09:57:39 --> Router Class Initialized
INFO - 2024-12-03 09:57:39 --> Output Class Initialized
INFO - 2024-12-03 09:57:39 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:39 --> CSRF cookie sent
INFO - 2024-12-03 09:57:39 --> Input Class Initialized
INFO - 2024-12-03 09:57:39 --> Language Class Initialized
INFO - 2024-12-03 09:57:39 --> Loader Class Initialized
INFO - 2024-12-03 09:57:39 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:39 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:39 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:39 --> Controller Class Initialized
INFO - 2024-12-03 09:57:39 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:39 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:39 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:39 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 09:57:39 --> Query result: stdClass Object
(
    [view_count] => 11
)

INFO - 2024-12-03 09:57:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:57:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:57:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 09:57:39 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:39 --> Total execution time: 0.0715
INFO - 2024-12-03 09:57:39 --> Config Class Initialized
INFO - 2024-12-03 09:57:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:39 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:39 --> URI Class Initialized
INFO - 2024-12-03 09:57:39 --> Router Class Initialized
INFO - 2024-12-03 09:57:39 --> Output Class Initialized
INFO - 2024-12-03 09:57:39 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:39 --> CSRF cookie sent
INFO - 2024-12-03 09:57:39 --> Input Class Initialized
INFO - 2024-12-03 09:57:39 --> Language Class Initialized
ERROR - 2024-12-03 09:57:39 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 09:57:40 --> Config Class Initialized
INFO - 2024-12-03 09:57:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:40 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:40 --> URI Class Initialized
INFO - 2024-12-03 09:57:40 --> Router Class Initialized
INFO - 2024-12-03 09:57:40 --> Output Class Initialized
INFO - 2024-12-03 09:57:40 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:40 --> CSRF cookie sent
INFO - 2024-12-03 09:57:40 --> Input Class Initialized
INFO - 2024-12-03 09:57:40 --> Language Class Initialized
INFO - 2024-12-03 09:57:40 --> Loader Class Initialized
INFO - 2024-12-03 09:57:40 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:40 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:40 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:40 --> Controller Class Initialized
INFO - 2024-12-03 09:57:40 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:40 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:40 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:40 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:40 --> Config Class Initialized
INFO - 2024-12-03 09:57:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:40 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:40 --> URI Class Initialized
INFO - 2024-12-03 09:57:40 --> Router Class Initialized
INFO - 2024-12-03 09:57:40 --> Output Class Initialized
INFO - 2024-12-03 09:57:40 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:41 --> CSRF cookie sent
INFO - 2024-12-03 09:57:41 --> Input Class Initialized
INFO - 2024-12-03 09:57:41 --> Language Class Initialized
INFO - 2024-12-03 09:57:41 --> Loader Class Initialized
INFO - 2024-12-03 09:57:41 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:41 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:41 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:41 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:41 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:41 --> Controller Class Initialized
INFO - 2024-12-03 09:57:41 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:41 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:41 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:41 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 09:57:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 09:57:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 09:57:41 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:41 --> Total execution time: 0.0707
INFO - 2024-12-03 09:57:48 --> Config Class Initialized
INFO - 2024-12-03 09:57:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:48 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:48 --> URI Class Initialized
INFO - 2024-12-03 09:57:48 --> Router Class Initialized
INFO - 2024-12-03 09:57:48 --> Output Class Initialized
INFO - 2024-12-03 09:57:48 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:48 --> CSRF cookie sent
INFO - 2024-12-03 09:57:48 --> CSRF token verified
INFO - 2024-12-03 09:57:48 --> Input Class Initialized
INFO - 2024-12-03 09:57:48 --> Language Class Initialized
INFO - 2024-12-03 09:57:48 --> Loader Class Initialized
INFO - 2024-12-03 09:57:48 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:48 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:48 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:48 --> Controller Class Initialized
INFO - 2024-12-03 09:57:48 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:48 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:48 --> Model "Review_model" initialized
INFO - 2024-12-03 09:57:48 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 09:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:48 --> Config Class Initialized
INFO - 2024-12-03 09:57:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:48 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:48 --> URI Class Initialized
INFO - 2024-12-03 09:57:48 --> Router Class Initialized
INFO - 2024-12-03 09:57:48 --> Output Class Initialized
INFO - 2024-12-03 09:57:48 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:48 --> CSRF cookie sent
INFO - 2024-12-03 09:57:48 --> Input Class Initialized
INFO - 2024-12-03 09:57:48 --> Language Class Initialized
INFO - 2024-12-03 09:57:48 --> Loader Class Initialized
INFO - 2024-12-03 09:57:48 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:48 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:49 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:49 --> Controller Class Initialized
INFO - 2024-12-03 09:57:49 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:49 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:49 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:57:49 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:49 --> Total execution time: 0.1430
INFO - 2024-12-03 09:57:52 --> Config Class Initialized
INFO - 2024-12-03 09:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:52 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:52 --> URI Class Initialized
INFO - 2024-12-03 09:57:52 --> Router Class Initialized
INFO - 2024-12-03 09:57:52 --> Output Class Initialized
INFO - 2024-12-03 09:57:52 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:52 --> CSRF cookie sent
INFO - 2024-12-03 09:57:52 --> Input Class Initialized
INFO - 2024-12-03 09:57:52 --> Language Class Initialized
INFO - 2024-12-03 09:57:52 --> Loader Class Initialized
INFO - 2024-12-03 09:57:52 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:52 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:52 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:52 --> Controller Class Initialized
INFO - 2024-12-03 09:57:52 --> Model "News_model" initialized
INFO - 2024-12-03 09:57:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-03 09:57:52 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:52 --> Total execution time: 0.0552
INFO - 2024-12-03 09:57:53 --> Config Class Initialized
INFO - 2024-12-03 09:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:53 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:53 --> URI Class Initialized
INFO - 2024-12-03 09:57:53 --> Router Class Initialized
INFO - 2024-12-03 09:57:53 --> Output Class Initialized
INFO - 2024-12-03 09:57:53 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:53 --> CSRF cookie sent
INFO - 2024-12-03 09:57:53 --> Input Class Initialized
INFO - 2024-12-03 09:57:53 --> Language Class Initialized
INFO - 2024-12-03 09:57:53 --> Loader Class Initialized
INFO - 2024-12-03 09:57:53 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:53 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:53 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:53 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:53 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:53 --> Controller Class Initialized
INFO - 2024-12-03 09:57:53 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:53 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:57:53 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:53 --> Total execution time: 0.0542
INFO - 2024-12-03 09:57:55 --> Config Class Initialized
INFO - 2024-12-03 09:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:55 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:55 --> URI Class Initialized
INFO - 2024-12-03 09:57:55 --> Router Class Initialized
INFO - 2024-12-03 09:57:55 --> Output Class Initialized
INFO - 2024-12-03 09:57:55 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:55 --> CSRF cookie sent
INFO - 2024-12-03 09:57:55 --> Input Class Initialized
INFO - 2024-12-03 09:57:55 --> Language Class Initialized
INFO - 2024-12-03 09:57:55 --> Loader Class Initialized
INFO - 2024-12-03 09:57:55 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:55 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:55 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:55 --> Controller Class Initialized
INFO - 2024-12-03 09:57:55 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:55 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:57:55 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:55 --> Total execution time: 0.0515
INFO - 2024-12-03 09:57:56 --> Config Class Initialized
INFO - 2024-12-03 09:57:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:57:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:57:56 --> Utf8 Class Initialized
INFO - 2024-12-03 09:57:56 --> URI Class Initialized
INFO - 2024-12-03 09:57:56 --> Router Class Initialized
INFO - 2024-12-03 09:57:56 --> Output Class Initialized
INFO - 2024-12-03 09:57:56 --> Security Class Initialized
DEBUG - 2024-12-03 09:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:57:56 --> CSRF cookie sent
INFO - 2024-12-03 09:57:56 --> Input Class Initialized
INFO - 2024-12-03 09:57:56 --> Language Class Initialized
INFO - 2024-12-03 09:57:56 --> Loader Class Initialized
INFO - 2024-12-03 09:57:56 --> Helper loaded: url_helper
INFO - 2024-12-03 09:57:56 --> Helper loaded: form_helper
INFO - 2024-12-03 09:57:56 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:57:56 --> Form Validation Class Initialized
INFO - 2024-12-03 09:57:56 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:57:56 --> Controller Class Initialized
INFO - 2024-12-03 09:57:56 --> Model "Category_model" initialized
INFO - 2024-12-03 09:57:56 --> Model "User_model" initialized
INFO - 2024-12-03 09:57:56 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:57:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 09:57:56 --> Final output sent to browser
DEBUG - 2024-12-03 09:57:56 --> Total execution time: 0.0454
INFO - 2024-12-03 09:58:04 --> Config Class Initialized
INFO - 2024-12-03 09:58:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:04 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:04 --> URI Class Initialized
INFO - 2024-12-03 09:58:04 --> Router Class Initialized
INFO - 2024-12-03 09:58:04 --> Output Class Initialized
INFO - 2024-12-03 09:58:04 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:04 --> CSRF cookie sent
INFO - 2024-12-03 09:58:04 --> Input Class Initialized
INFO - 2024-12-03 09:58:04 --> Language Class Initialized
INFO - 2024-12-03 09:58:04 --> Loader Class Initialized
INFO - 2024-12-03 09:58:04 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:04 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:04 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:04 --> Controller Class Initialized
INFO - 2024-12-03 09:58:04 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:04 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:04 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:58:04 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:04 --> Total execution time: 0.0637
INFO - 2024-12-03 09:58:08 --> Config Class Initialized
INFO - 2024-12-03 09:58:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:08 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:08 --> URI Class Initialized
INFO - 2024-12-03 09:58:08 --> Router Class Initialized
INFO - 2024-12-03 09:58:08 --> Output Class Initialized
INFO - 2024-12-03 09:58:08 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:08 --> CSRF cookie sent
INFO - 2024-12-03 09:58:08 --> Input Class Initialized
INFO - 2024-12-03 09:58:08 --> Language Class Initialized
INFO - 2024-12-03 09:58:08 --> Loader Class Initialized
INFO - 2024-12-03 09:58:08 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:08 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:08 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:08 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:08 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:08 --> Controller Class Initialized
INFO - 2024-12-03 09:58:08 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:08 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:58:08 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:08 --> Total execution time: 0.0484
INFO - 2024-12-03 09:58:12 --> Config Class Initialized
INFO - 2024-12-03 09:58:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:12 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:12 --> URI Class Initialized
INFO - 2024-12-03 09:58:12 --> Router Class Initialized
INFO - 2024-12-03 09:58:12 --> Output Class Initialized
INFO - 2024-12-03 09:58:12 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:12 --> CSRF cookie sent
INFO - 2024-12-03 09:58:12 --> Input Class Initialized
INFO - 2024-12-03 09:58:12 --> Language Class Initialized
INFO - 2024-12-03 09:58:12 --> Loader Class Initialized
INFO - 2024-12-03 09:58:12 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:12 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:12 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:12 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:12 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:12 --> Controller Class Initialized
INFO - 2024-12-03 09:58:12 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:12 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:58:12 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:12 --> Total execution time: 0.0423
INFO - 2024-12-03 09:58:15 --> Config Class Initialized
INFO - 2024-12-03 09:58:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:15 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:15 --> URI Class Initialized
INFO - 2024-12-03 09:58:15 --> Router Class Initialized
INFO - 2024-12-03 09:58:15 --> Output Class Initialized
INFO - 2024-12-03 09:58:15 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:15 --> CSRF cookie sent
INFO - 2024-12-03 09:58:15 --> Input Class Initialized
INFO - 2024-12-03 09:58:15 --> Language Class Initialized
INFO - 2024-12-03 09:58:15 --> Loader Class Initialized
INFO - 2024-12-03 09:58:15 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:15 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:15 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:15 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:15 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:15 --> Controller Class Initialized
INFO - 2024-12-03 09:58:15 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:15 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:15 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:58:15 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:15 --> Total execution time: 0.0704
INFO - 2024-12-03 09:58:18 --> Config Class Initialized
INFO - 2024-12-03 09:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:18 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:18 --> URI Class Initialized
INFO - 2024-12-03 09:58:18 --> Router Class Initialized
INFO - 2024-12-03 09:58:18 --> Output Class Initialized
INFO - 2024-12-03 09:58:18 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:18 --> CSRF cookie sent
INFO - 2024-12-03 09:58:18 --> Input Class Initialized
INFO - 2024-12-03 09:58:18 --> Language Class Initialized
INFO - 2024-12-03 09:58:18 --> Loader Class Initialized
INFO - 2024-12-03 09:58:18 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:18 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:18 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:18 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:18 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:18 --> Controller Class Initialized
INFO - 2024-12-03 09:58:18 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:18 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:18 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-03 09:58:18 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:18 --> Total execution time: 0.0421
INFO - 2024-12-03 09:58:20 --> Config Class Initialized
INFO - 2024-12-03 09:58:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:20 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:20 --> URI Class Initialized
INFO - 2024-12-03 09:58:20 --> Router Class Initialized
INFO - 2024-12-03 09:58:20 --> Output Class Initialized
INFO - 2024-12-03 09:58:20 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:20 --> CSRF cookie sent
INFO - 2024-12-03 09:58:20 --> Input Class Initialized
INFO - 2024-12-03 09:58:20 --> Language Class Initialized
INFO - 2024-12-03 09:58:20 --> Loader Class Initialized
INFO - 2024-12-03 09:58:20 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:20 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:20 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:20 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:20 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:20 --> Controller Class Initialized
INFO - 2024-12-03 09:58:20 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:20 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:20 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:58:20 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:20 --> Total execution time: 0.0405
INFO - 2024-12-03 09:58:21 --> Config Class Initialized
INFO - 2024-12-03 09:58:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:58:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:58:21 --> Utf8 Class Initialized
INFO - 2024-12-03 09:58:21 --> URI Class Initialized
INFO - 2024-12-03 09:58:21 --> Router Class Initialized
INFO - 2024-12-03 09:58:21 --> Output Class Initialized
INFO - 2024-12-03 09:58:21 --> Security Class Initialized
DEBUG - 2024-12-03 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:58:21 --> CSRF cookie sent
INFO - 2024-12-03 09:58:21 --> Input Class Initialized
INFO - 2024-12-03 09:58:21 --> Language Class Initialized
INFO - 2024-12-03 09:58:21 --> Loader Class Initialized
INFO - 2024-12-03 09:58:21 --> Helper loaded: url_helper
INFO - 2024-12-03 09:58:21 --> Helper loaded: form_helper
INFO - 2024-12-03 09:58:21 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:58:21 --> Form Validation Class Initialized
INFO - 2024-12-03 09:58:21 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:58:21 --> Controller Class Initialized
INFO - 2024-12-03 09:58:21 --> Model "Category_model" initialized
INFO - 2024-12-03 09:58:21 --> Model "User_model" initialized
INFO - 2024-12-03 09:58:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:58:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 09:58:21 --> Final output sent to browser
DEBUG - 2024-12-03 09:58:21 --> Total execution time: 0.0406
INFO - 2024-12-03 09:59:31 --> Config Class Initialized
INFO - 2024-12-03 09:59:31 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:31 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:31 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:31 --> URI Class Initialized
INFO - 2024-12-03 09:59:31 --> Router Class Initialized
INFO - 2024-12-03 09:59:31 --> Output Class Initialized
INFO - 2024-12-03 09:59:31 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:31 --> CSRF cookie sent
INFO - 2024-12-03 09:59:31 --> Input Class Initialized
INFO - 2024-12-03 09:59:31 --> Language Class Initialized
INFO - 2024-12-03 09:59:31 --> Loader Class Initialized
INFO - 2024-12-03 09:59:31 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:31 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:31 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:31 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:31 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:31 --> Controller Class Initialized
INFO - 2024-12-03 09:59:31 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:31 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:59:31 --> Final output sent to browser
DEBUG - 2024-12-03 09:59:31 --> Total execution time: 0.4166
INFO - 2024-12-03 09:59:35 --> Config Class Initialized
INFO - 2024-12-03 09:59:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:35 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:35 --> URI Class Initialized
INFO - 2024-12-03 09:59:35 --> Router Class Initialized
INFO - 2024-12-03 09:59:35 --> Output Class Initialized
INFO - 2024-12-03 09:59:35 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:35 --> CSRF cookie sent
INFO - 2024-12-03 09:59:35 --> Input Class Initialized
INFO - 2024-12-03 09:59:35 --> Language Class Initialized
INFO - 2024-12-03 09:59:35 --> Loader Class Initialized
INFO - 2024-12-03 09:59:35 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:35 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:35 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:35 --> Controller Class Initialized
INFO - 2024-12-03 09:59:35 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:35 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:35 --> Config Class Initialized
INFO - 2024-12-03 09:59:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:35 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:35 --> URI Class Initialized
INFO - 2024-12-03 09:59:35 --> Router Class Initialized
INFO - 2024-12-03 09:59:35 --> Output Class Initialized
INFO - 2024-12-03 09:59:35 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:35 --> CSRF cookie sent
INFO - 2024-12-03 09:59:35 --> Input Class Initialized
INFO - 2024-12-03 09:59:35 --> Language Class Initialized
INFO - 2024-12-03 09:59:35 --> Loader Class Initialized
INFO - 2024-12-03 09:59:35 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:35 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:35 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:35 --> Controller Class Initialized
INFO - 2024-12-03 09:59:35 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:35 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 09:59:35 --> Final output sent to browser
DEBUG - 2024-12-03 09:59:35 --> Total execution time: 0.0706
INFO - 2024-12-03 09:59:37 --> Config Class Initialized
INFO - 2024-12-03 09:59:37 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:37 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:37 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:37 --> URI Class Initialized
INFO - 2024-12-03 09:59:37 --> Router Class Initialized
INFO - 2024-12-03 09:59:37 --> Output Class Initialized
INFO - 2024-12-03 09:59:37 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:37 --> CSRF cookie sent
INFO - 2024-12-03 09:59:37 --> Input Class Initialized
INFO - 2024-12-03 09:59:37 --> Language Class Initialized
INFO - 2024-12-03 09:59:37 --> Loader Class Initialized
INFO - 2024-12-03 09:59:37 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:37 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:37 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:37 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:37 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:37 --> Controller Class Initialized
INFO - 2024-12-03 09:59:37 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:37 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:37 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 09:59:37 --> Final output sent to browser
DEBUG - 2024-12-03 09:59:37 --> Total execution time: 0.0461
INFO - 2024-12-03 09:59:41 --> Config Class Initialized
INFO - 2024-12-03 09:59:41 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:41 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:41 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:41 --> URI Class Initialized
INFO - 2024-12-03 09:59:41 --> Router Class Initialized
INFO - 2024-12-03 09:59:42 --> Output Class Initialized
INFO - 2024-12-03 09:59:42 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:42 --> CSRF cookie sent
INFO - 2024-12-03 09:59:42 --> Input Class Initialized
INFO - 2024-12-03 09:59:42 --> Language Class Initialized
INFO - 2024-12-03 09:59:42 --> Loader Class Initialized
INFO - 2024-12-03 09:59:42 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:42 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:42 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:42 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:42 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:42 --> Controller Class Initialized
INFO - 2024-12-03 09:59:42 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:42 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:42 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 09:59:42 --> Final output sent to browser
DEBUG - 2024-12-03 09:59:42 --> Total execution time: 0.0566
INFO - 2024-12-03 09:59:43 --> Config Class Initialized
INFO - 2024-12-03 09:59:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:43 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:43 --> URI Class Initialized
INFO - 2024-12-03 09:59:43 --> Router Class Initialized
INFO - 2024-12-03 09:59:43 --> Output Class Initialized
INFO - 2024-12-03 09:59:43 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:43 --> CSRF cookie sent
INFO - 2024-12-03 09:59:43 --> Input Class Initialized
INFO - 2024-12-03 09:59:43 --> Language Class Initialized
INFO - 2024-12-03 09:59:43 --> Loader Class Initialized
INFO - 2024-12-03 09:59:43 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:43 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:43 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:43 --> Controller Class Initialized
INFO - 2024-12-03 09:59:43 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:43 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 09:59:43 --> Final output sent to browser
DEBUG - 2024-12-03 09:59:43 --> Total execution time: 0.0385
INFO - 2024-12-03 09:59:47 --> Config Class Initialized
INFO - 2024-12-03 09:59:47 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:47 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:47 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:47 --> URI Class Initialized
INFO - 2024-12-03 09:59:47 --> Router Class Initialized
INFO - 2024-12-03 09:59:47 --> Output Class Initialized
INFO - 2024-12-03 09:59:47 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:47 --> CSRF cookie sent
INFO - 2024-12-03 09:59:47 --> Input Class Initialized
INFO - 2024-12-03 09:59:47 --> Language Class Initialized
INFO - 2024-12-03 09:59:47 --> Loader Class Initialized
INFO - 2024-12-03 09:59:47 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:47 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:47 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:47 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:47 --> Controller Class Initialized
INFO - 2024-12-03 09:59:47 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:47 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:47 --> Config Class Initialized
INFO - 2024-12-03 09:59:47 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:59:47 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:59:47 --> Utf8 Class Initialized
INFO - 2024-12-03 09:59:47 --> URI Class Initialized
INFO - 2024-12-03 09:59:47 --> Router Class Initialized
INFO - 2024-12-03 09:59:47 --> Output Class Initialized
INFO - 2024-12-03 09:59:47 --> Security Class Initialized
DEBUG - 2024-12-03 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:59:47 --> CSRF cookie sent
INFO - 2024-12-03 09:59:47 --> Input Class Initialized
INFO - 2024-12-03 09:59:47 --> Language Class Initialized
INFO - 2024-12-03 09:59:47 --> Loader Class Initialized
INFO - 2024-12-03 09:59:47 --> Helper loaded: url_helper
INFO - 2024-12-03 09:59:47 --> Helper loaded: form_helper
INFO - 2024-12-03 09:59:47 --> Database Driver Class Initialized
DEBUG - 2024-12-03 09:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:59:47 --> Form Validation Class Initialized
INFO - 2024-12-03 09:59:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 09:59:47 --> Controller Class Initialized
INFO - 2024-12-03 09:59:47 --> Model "Category_model" initialized
INFO - 2024-12-03 09:59:47 --> Model "User_model" initialized
INFO - 2024-12-03 09:59:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 09:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:59:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 09:59:47 --> Final output sent to browser
DEBUG - 2024-12-03 09:59:47 --> Total execution time: 0.0991
INFO - 2024-12-03 10:04:58 --> Config Class Initialized
INFO - 2024-12-03 10:04:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:04:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:04:58 --> Utf8 Class Initialized
INFO - 2024-12-03 10:04:58 --> URI Class Initialized
INFO - 2024-12-03 10:04:58 --> Router Class Initialized
INFO - 2024-12-03 10:04:58 --> Output Class Initialized
INFO - 2024-12-03 10:04:58 --> Security Class Initialized
DEBUG - 2024-12-03 10:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:04:58 --> CSRF cookie sent
INFO - 2024-12-03 10:04:58 --> Input Class Initialized
INFO - 2024-12-03 10:04:58 --> Language Class Initialized
INFO - 2024-12-03 10:04:58 --> Loader Class Initialized
INFO - 2024-12-03 10:04:58 --> Helper loaded: url_helper
INFO - 2024-12-03 10:04:58 --> Helper loaded: form_helper
INFO - 2024-12-03 10:04:58 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:04:58 --> Form Validation Class Initialized
INFO - 2024-12-03 10:04:58 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:04:58 --> Controller Class Initialized
INFO - 2024-12-03 10:04:58 --> Model "Category_model" initialized
INFO - 2024-12-03 10:04:58 --> Model "User_model" initialized
INFO - 2024-12-03 10:04:58 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:04:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:04:58 --> Final output sent to browser
DEBUG - 2024-12-03 10:04:58 --> Total execution time: 0.2549
INFO - 2024-12-03 10:05:02 --> Config Class Initialized
INFO - 2024-12-03 10:05:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:05:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:05:02 --> Utf8 Class Initialized
INFO - 2024-12-03 10:05:02 --> URI Class Initialized
INFO - 2024-12-03 10:05:02 --> Router Class Initialized
INFO - 2024-12-03 10:05:02 --> Output Class Initialized
INFO - 2024-12-03 10:05:02 --> Security Class Initialized
DEBUG - 2024-12-03 10:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:05:02 --> CSRF cookie sent
INFO - 2024-12-03 10:05:02 --> Input Class Initialized
INFO - 2024-12-03 10:05:02 --> Language Class Initialized
INFO - 2024-12-03 10:05:02 --> Loader Class Initialized
INFO - 2024-12-03 10:05:02 --> Helper loaded: url_helper
INFO - 2024-12-03 10:05:02 --> Helper loaded: form_helper
INFO - 2024-12-03 10:05:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:05:02 --> Form Validation Class Initialized
INFO - 2024-12-03 10:05:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:05:02 --> Controller Class Initialized
INFO - 2024-12-03 10:05:02 --> Model "Category_model" initialized
INFO - 2024-12-03 10:05:02 --> Model "User_model" initialized
INFO - 2024-12-03 10:05:02 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:05:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:05:02 --> Final output sent to browser
DEBUG - 2024-12-03 10:05:02 --> Total execution time: 0.0605
INFO - 2024-12-03 10:06:52 --> Config Class Initialized
INFO - 2024-12-03 10:06:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:06:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:06:52 --> Utf8 Class Initialized
INFO - 2024-12-03 10:06:52 --> URI Class Initialized
INFO - 2024-12-03 10:06:52 --> Router Class Initialized
INFO - 2024-12-03 10:06:52 --> Output Class Initialized
INFO - 2024-12-03 10:06:52 --> Security Class Initialized
DEBUG - 2024-12-03 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:06:52 --> CSRF cookie sent
INFO - 2024-12-03 10:06:52 --> Input Class Initialized
INFO - 2024-12-03 10:06:52 --> Language Class Initialized
INFO - 2024-12-03 10:06:52 --> Loader Class Initialized
INFO - 2024-12-03 10:06:52 --> Helper loaded: url_helper
INFO - 2024-12-03 10:06:52 --> Helper loaded: form_helper
INFO - 2024-12-03 10:06:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:06:52 --> Form Validation Class Initialized
INFO - 2024-12-03 10:06:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:06:52 --> Controller Class Initialized
INFO - 2024-12-03 10:06:52 --> Model "User_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "Category_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "Review_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "News_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:06:52 --> Config Class Initialized
INFO - 2024-12-03 10:06:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:06:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:06:52 --> Utf8 Class Initialized
INFO - 2024-12-03 10:06:52 --> URI Class Initialized
INFO - 2024-12-03 10:06:52 --> Router Class Initialized
INFO - 2024-12-03 10:06:52 --> Output Class Initialized
INFO - 2024-12-03 10:06:52 --> Security Class Initialized
DEBUG - 2024-12-03 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:06:52 --> CSRF cookie sent
INFO - 2024-12-03 10:06:52 --> Input Class Initialized
INFO - 2024-12-03 10:06:52 --> Language Class Initialized
INFO - 2024-12-03 10:06:52 --> Loader Class Initialized
INFO - 2024-12-03 10:06:52 --> Helper loaded: url_helper
INFO - 2024-12-03 10:06:52 --> Helper loaded: form_helper
INFO - 2024-12-03 10:06:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:06:52 --> Form Validation Class Initialized
INFO - 2024-12-03 10:06:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:06:52 --> Controller Class Initialized
INFO - 2024-12-03 10:06:52 --> Model "User_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "Category_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "Review_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "News_model" initialized
INFO - 2024-12-03 10:06:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:06:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:06:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:06:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:06:52 --> Final output sent to browser
DEBUG - 2024-12-03 10:06:52 --> Total execution time: 0.0555
INFO - 2024-12-03 10:06:55 --> Config Class Initialized
INFO - 2024-12-03 10:06:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:06:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:06:55 --> Utf8 Class Initialized
INFO - 2024-12-03 10:06:55 --> URI Class Initialized
INFO - 2024-12-03 10:06:55 --> Router Class Initialized
INFO - 2024-12-03 10:06:55 --> Output Class Initialized
INFO - 2024-12-03 10:06:55 --> Security Class Initialized
DEBUG - 2024-12-03 10:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:06:55 --> CSRF cookie sent
INFO - 2024-12-03 10:06:55 --> CSRF token verified
INFO - 2024-12-03 10:06:55 --> Input Class Initialized
INFO - 2024-12-03 10:06:55 --> Language Class Initialized
INFO - 2024-12-03 10:06:55 --> Loader Class Initialized
INFO - 2024-12-03 10:06:55 --> Helper loaded: url_helper
INFO - 2024-12-03 10:06:55 --> Helper loaded: form_helper
INFO - 2024-12-03 10:06:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:06:55 --> Form Validation Class Initialized
INFO - 2024-12-03 10:06:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:06:55 --> Controller Class Initialized
INFO - 2024-12-03 10:06:55 --> Model "User_model" initialized
INFO - 2024-12-03 10:06:55 --> Model "Category_model" initialized
INFO - 2024-12-03 10:06:55 --> Model "Review_model" initialized
INFO - 2024-12-03 10:06:55 --> Model "News_model" initialized
INFO - 2024-12-03 10:06:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:06:55 --> Config Class Initialized
INFO - 2024-12-03 10:06:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:06:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:06:55 --> Utf8 Class Initialized
INFO - 2024-12-03 10:06:55 --> URI Class Initialized
INFO - 2024-12-03 10:06:55 --> Router Class Initialized
INFO - 2024-12-03 10:06:55 --> Output Class Initialized
INFO - 2024-12-03 10:06:55 --> Security Class Initialized
DEBUG - 2024-12-03 10:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:06:55 --> CSRF cookie sent
INFO - 2024-12-03 10:06:55 --> Input Class Initialized
INFO - 2024-12-03 10:06:55 --> Language Class Initialized
INFO - 2024-12-03 10:06:55 --> Loader Class Initialized
INFO - 2024-12-03 10:06:55 --> Helper loaded: url_helper
INFO - 2024-12-03 10:06:55 --> Helper loaded: form_helper
INFO - 2024-12-03 10:06:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:06:55 --> Form Validation Class Initialized
INFO - 2024-12-03 10:06:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:06:55 --> Controller Class Initialized
INFO - 2024-12-03 10:06:55 --> Model "Category_model" initialized
INFO - 2024-12-03 10:06:55 --> Model "User_model" initialized
INFO - 2024-12-03 10:06:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:06:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:06:56 --> Final output sent to browser
DEBUG - 2024-12-03 10:06:56 --> Total execution time: 0.0748
INFO - 2024-12-03 10:06:57 --> Config Class Initialized
INFO - 2024-12-03 10:06:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:06:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:06:57 --> Utf8 Class Initialized
INFO - 2024-12-03 10:06:57 --> URI Class Initialized
INFO - 2024-12-03 10:06:57 --> Router Class Initialized
INFO - 2024-12-03 10:06:57 --> Output Class Initialized
INFO - 2024-12-03 10:06:57 --> Security Class Initialized
DEBUG - 2024-12-03 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:06:57 --> CSRF cookie sent
INFO - 2024-12-03 10:06:57 --> Input Class Initialized
INFO - 2024-12-03 10:06:57 --> Language Class Initialized
INFO - 2024-12-03 10:06:57 --> Loader Class Initialized
INFO - 2024-12-03 10:06:57 --> Helper loaded: url_helper
INFO - 2024-12-03 10:06:57 --> Helper loaded: form_helper
INFO - 2024-12-03 10:06:57 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:06:57 --> Form Validation Class Initialized
INFO - 2024-12-03 10:06:57 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:06:57 --> Controller Class Initialized
INFO - 2024-12-03 10:06:57 --> Model "User_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "Category_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "Review_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "News_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:06:57 --> Config Class Initialized
INFO - 2024-12-03 10:06:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:06:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:06:57 --> Utf8 Class Initialized
INFO - 2024-12-03 10:06:57 --> URI Class Initialized
INFO - 2024-12-03 10:06:57 --> Router Class Initialized
INFO - 2024-12-03 10:06:57 --> Output Class Initialized
INFO - 2024-12-03 10:06:57 --> Security Class Initialized
DEBUG - 2024-12-03 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:06:57 --> CSRF cookie sent
INFO - 2024-12-03 10:06:57 --> Input Class Initialized
INFO - 2024-12-03 10:06:57 --> Language Class Initialized
INFO - 2024-12-03 10:06:57 --> Loader Class Initialized
INFO - 2024-12-03 10:06:57 --> Helper loaded: url_helper
INFO - 2024-12-03 10:06:57 --> Helper loaded: form_helper
INFO - 2024-12-03 10:06:57 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:06:57 --> Form Validation Class Initialized
INFO - 2024-12-03 10:06:57 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:06:57 --> Controller Class Initialized
INFO - 2024-12-03 10:06:57 --> Model "User_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "Category_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "Review_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "News_model" initialized
INFO - 2024-12-03 10:06:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:06:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:06:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:06:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:06:57 --> Final output sent to browser
DEBUG - 2024-12-03 10:06:57 --> Total execution time: 0.0569
INFO - 2024-12-03 10:07:03 --> Config Class Initialized
INFO - 2024-12-03 10:07:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:03 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:03 --> URI Class Initialized
INFO - 2024-12-03 10:07:03 --> Router Class Initialized
INFO - 2024-12-03 10:07:03 --> Output Class Initialized
INFO - 2024-12-03 10:07:04 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:04 --> CSRF cookie sent
INFO - 2024-12-03 10:07:04 --> CSRF token verified
INFO - 2024-12-03 10:07:04 --> Input Class Initialized
INFO - 2024-12-03 10:07:04 --> Language Class Initialized
INFO - 2024-12-03 10:07:04 --> Loader Class Initialized
INFO - 2024-12-03 10:07:04 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:04 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:04 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:04 --> Controller Class Initialized
INFO - 2024-12-03 10:07:04 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:04 --> Config Class Initialized
INFO - 2024-12-03 10:07:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:04 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:04 --> URI Class Initialized
INFO - 2024-12-03 10:07:04 --> Router Class Initialized
INFO - 2024-12-03 10:07:04 --> Output Class Initialized
INFO - 2024-12-03 10:07:04 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:04 --> CSRF cookie sent
INFO - 2024-12-03 10:07:04 --> Input Class Initialized
INFO - 2024-12-03 10:07:04 --> Language Class Initialized
INFO - 2024-12-03 10:07:04 --> Loader Class Initialized
INFO - 2024-12-03 10:07:04 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:04 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:04 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:04 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:04 --> Controller Class Initialized
INFO - 2024-12-03 10:07:04 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:07:04 --> Query result: stdClass Object
(
    [view_count] => 12
)

INFO - 2024-12-03 10:07:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:07:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:07:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:07:04 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:04 --> Total execution time: 0.1023
INFO - 2024-12-03 10:07:07 --> Config Class Initialized
INFO - 2024-12-03 10:07:07 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:07 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:07 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:07 --> URI Class Initialized
INFO - 2024-12-03 10:07:07 --> Router Class Initialized
INFO - 2024-12-03 10:07:07 --> Output Class Initialized
INFO - 2024-12-03 10:07:07 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:07 --> CSRF cookie sent
INFO - 2024-12-03 10:07:07 --> Input Class Initialized
INFO - 2024-12-03 10:07:07 --> Language Class Initialized
ERROR - 2024-12-03 10:07:07 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 10:07:11 --> Config Class Initialized
INFO - 2024-12-03 10:07:11 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:11 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:11 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:11 --> URI Class Initialized
INFO - 2024-12-03 10:07:11 --> Router Class Initialized
INFO - 2024-12-03 10:07:11 --> Output Class Initialized
INFO - 2024-12-03 10:07:11 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:11 --> CSRF cookie sent
INFO - 2024-12-03 10:07:11 --> Input Class Initialized
INFO - 2024-12-03 10:07:11 --> Language Class Initialized
INFO - 2024-12-03 10:07:11 --> Loader Class Initialized
INFO - 2024-12-03 10:07:11 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:11 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:11 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:11 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:11 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:11 --> Controller Class Initialized
INFO - 2024-12-03 10:07:11 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:11 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:11 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:11 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:07:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:07:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 10:07:11 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:11 --> Total execution time: 0.0504
INFO - 2024-12-03 10:07:34 --> Config Class Initialized
INFO - 2024-12-03 10:07:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:34 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:34 --> URI Class Initialized
INFO - 2024-12-03 10:07:34 --> Router Class Initialized
INFO - 2024-12-03 10:07:34 --> Output Class Initialized
INFO - 2024-12-03 10:07:34 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:34 --> CSRF cookie sent
INFO - 2024-12-03 10:07:34 --> CSRF token verified
INFO - 2024-12-03 10:07:34 --> Input Class Initialized
INFO - 2024-12-03 10:07:34 --> Language Class Initialized
INFO - 2024-12-03 10:07:34 --> Loader Class Initialized
INFO - 2024-12-03 10:07:34 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:34 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:34 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:34 --> Controller Class Initialized
INFO - 2024-12-03 10:07:34 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:34 --> Upload Class Initialized
INFO - 2024-12-03 10:07:34 --> Config Class Initialized
INFO - 2024-12-03 10:07:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:34 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:34 --> URI Class Initialized
INFO - 2024-12-03 10:07:34 --> Router Class Initialized
INFO - 2024-12-03 10:07:34 --> Output Class Initialized
INFO - 2024-12-03 10:07:34 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:34 --> CSRF cookie sent
INFO - 2024-12-03 10:07:34 --> Input Class Initialized
INFO - 2024-12-03 10:07:34 --> Language Class Initialized
INFO - 2024-12-03 10:07:34 --> Loader Class Initialized
INFO - 2024-12-03 10:07:34 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:34 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:34 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:34 --> Controller Class Initialized
INFO - 2024-12-03 10:07:34 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:07:34 --> Query result: stdClass Object
(
    [view_count] => 13
)

INFO - 2024-12-03 10:07:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:07:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:07:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:07:34 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:34 --> Total execution time: 0.0446
INFO - 2024-12-03 10:07:35 --> Config Class Initialized
INFO - 2024-12-03 10:07:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:35 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:35 --> URI Class Initialized
INFO - 2024-12-03 10:07:35 --> Router Class Initialized
INFO - 2024-12-03 10:07:35 --> Output Class Initialized
INFO - 2024-12-03 10:07:35 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:35 --> CSRF cookie sent
INFO - 2024-12-03 10:07:35 --> Input Class Initialized
INFO - 2024-12-03 10:07:35 --> Language Class Initialized
ERROR - 2024-12-03 10:07:35 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-03 10:07:39 --> Config Class Initialized
INFO - 2024-12-03 10:07:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:39 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:39 --> URI Class Initialized
INFO - 2024-12-03 10:07:39 --> Router Class Initialized
INFO - 2024-12-03 10:07:39 --> Output Class Initialized
INFO - 2024-12-03 10:07:39 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:39 --> CSRF cookie sent
INFO - 2024-12-03 10:07:39 --> Input Class Initialized
INFO - 2024-12-03 10:07:39 --> Language Class Initialized
INFO - 2024-12-03 10:07:39 --> Loader Class Initialized
INFO - 2024-12-03 10:07:39 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:39 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:39 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:39 --> Controller Class Initialized
INFO - 2024-12-03 10:07:39 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:39 --> Config Class Initialized
INFO - 2024-12-03 10:07:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:39 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:39 --> URI Class Initialized
INFO - 2024-12-03 10:07:39 --> Router Class Initialized
INFO - 2024-12-03 10:07:39 --> Output Class Initialized
INFO - 2024-12-03 10:07:39 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:39 --> CSRF cookie sent
INFO - 2024-12-03 10:07:39 --> Input Class Initialized
INFO - 2024-12-03 10:07:39 --> Language Class Initialized
INFO - 2024-12-03 10:07:39 --> Loader Class Initialized
INFO - 2024-12-03 10:07:39 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:39 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:39 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:39 --> Controller Class Initialized
INFO - 2024-12-03 10:07:39 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:07:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:07:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:07:39 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:39 --> Total execution time: 0.0833
INFO - 2024-12-03 10:07:43 --> Config Class Initialized
INFO - 2024-12-03 10:07:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:43 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:43 --> URI Class Initialized
INFO - 2024-12-03 10:07:43 --> Router Class Initialized
INFO - 2024-12-03 10:07:43 --> Output Class Initialized
INFO - 2024-12-03 10:07:43 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:43 --> CSRF cookie sent
INFO - 2024-12-03 10:07:43 --> CSRF token verified
INFO - 2024-12-03 10:07:43 --> Input Class Initialized
INFO - 2024-12-03 10:07:43 --> Language Class Initialized
INFO - 2024-12-03 10:07:43 --> Loader Class Initialized
INFO - 2024-12-03 10:07:43 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:43 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:43 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:43 --> Controller Class Initialized
INFO - 2024-12-03 10:07:43 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:43 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:43 --> Model "Review_model" initialized
INFO - 2024-12-03 10:07:43 --> Model "News_model" initialized
INFO - 2024-12-03 10:07:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:43 --> Config Class Initialized
INFO - 2024-12-03 10:07:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:43 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:43 --> URI Class Initialized
INFO - 2024-12-03 10:07:43 --> Router Class Initialized
INFO - 2024-12-03 10:07:43 --> Output Class Initialized
INFO - 2024-12-03 10:07:43 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:43 --> CSRF cookie sent
INFO - 2024-12-03 10:07:43 --> Input Class Initialized
INFO - 2024-12-03 10:07:43 --> Language Class Initialized
INFO - 2024-12-03 10:07:43 --> Loader Class Initialized
INFO - 2024-12-03 10:07:43 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:43 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:43 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:43 --> Controller Class Initialized
INFO - 2024-12-03 10:07:43 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:43 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:07:43 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:43 --> Total execution time: 0.0545
INFO - 2024-12-03 10:07:47 --> Config Class Initialized
INFO - 2024-12-03 10:07:47 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:47 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:47 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:47 --> URI Class Initialized
INFO - 2024-12-03 10:07:47 --> Router Class Initialized
INFO - 2024-12-03 10:07:47 --> Output Class Initialized
INFO - 2024-12-03 10:07:47 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:47 --> CSRF cookie sent
INFO - 2024-12-03 10:07:47 --> Input Class Initialized
INFO - 2024-12-03 10:07:47 --> Language Class Initialized
INFO - 2024-12-03 10:07:47 --> Loader Class Initialized
INFO - 2024-12-03 10:07:47 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:47 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:47 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:47 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:47 --> Controller Class Initialized
INFO - 2024-12-03 10:07:47 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:47 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:07:47 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:47 --> Total execution time: 0.0507
INFO - 2024-12-03 10:07:49 --> Config Class Initialized
INFO - 2024-12-03 10:07:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:49 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:49 --> URI Class Initialized
INFO - 2024-12-03 10:07:49 --> Router Class Initialized
INFO - 2024-12-03 10:07:49 --> Output Class Initialized
INFO - 2024-12-03 10:07:49 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:49 --> CSRF cookie sent
INFO - 2024-12-03 10:07:49 --> Input Class Initialized
INFO - 2024-12-03 10:07:49 --> Language Class Initialized
INFO - 2024-12-03 10:07:49 --> Loader Class Initialized
INFO - 2024-12-03 10:07:49 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:49 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:49 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:49 --> Controller Class Initialized
INFO - 2024-12-03 10:07:49 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:49 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:49 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:49 --> Config Class Initialized
INFO - 2024-12-03 10:07:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:49 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:49 --> URI Class Initialized
INFO - 2024-12-03 10:07:49 --> Router Class Initialized
INFO - 2024-12-03 10:07:49 --> Output Class Initialized
INFO - 2024-12-03 10:07:49 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:49 --> CSRF cookie sent
INFO - 2024-12-03 10:07:49 --> Input Class Initialized
INFO - 2024-12-03 10:07:49 --> Language Class Initialized
INFO - 2024-12-03 10:07:49 --> Loader Class Initialized
INFO - 2024-12-03 10:07:49 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:49 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:49 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:49 --> Controller Class Initialized
INFO - 2024-12-03 10:07:49 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:49 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:49 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:07:49 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:49 --> Total execution time: 0.0623
INFO - 2024-12-03 10:07:52 --> Config Class Initialized
INFO - 2024-12-03 10:07:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:52 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:52 --> URI Class Initialized
INFO - 2024-12-03 10:07:52 --> Router Class Initialized
INFO - 2024-12-03 10:07:52 --> Output Class Initialized
INFO - 2024-12-03 10:07:52 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:52 --> CSRF cookie sent
INFO - 2024-12-03 10:07:52 --> Input Class Initialized
INFO - 2024-12-03 10:07:52 --> Language Class Initialized
INFO - 2024-12-03 10:07:52 --> Loader Class Initialized
INFO - 2024-12-03 10:07:52 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:52 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:52 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:52 --> Controller Class Initialized
INFO - 2024-12-03 10:07:52 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:52 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:52 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:07:52 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:52 --> Total execution time: 0.0582
INFO - 2024-12-03 10:07:56 --> Config Class Initialized
INFO - 2024-12-03 10:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:07:56 --> Utf8 Class Initialized
INFO - 2024-12-03 10:07:56 --> URI Class Initialized
INFO - 2024-12-03 10:07:56 --> Router Class Initialized
INFO - 2024-12-03 10:07:56 --> Output Class Initialized
INFO - 2024-12-03 10:07:56 --> Security Class Initialized
DEBUG - 2024-12-03 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:07:56 --> CSRF cookie sent
INFO - 2024-12-03 10:07:56 --> Input Class Initialized
INFO - 2024-12-03 10:07:56 --> Language Class Initialized
INFO - 2024-12-03 10:07:56 --> Loader Class Initialized
INFO - 2024-12-03 10:07:56 --> Helper loaded: url_helper
INFO - 2024-12-03 10:07:56 --> Helper loaded: form_helper
INFO - 2024-12-03 10:07:56 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:07:56 --> Form Validation Class Initialized
INFO - 2024-12-03 10:07:56 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:07:56 --> Controller Class Initialized
INFO - 2024-12-03 10:07:56 --> Model "Category_model" initialized
INFO - 2024-12-03 10:07:56 --> Model "User_model" initialized
INFO - 2024-12-03 10:07:56 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:07:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:07:56 --> Final output sent to browser
DEBUG - 2024-12-03 10:07:56 --> Total execution time: 0.0452
INFO - 2024-12-03 10:12:35 --> Config Class Initialized
INFO - 2024-12-03 10:12:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:35 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:35 --> URI Class Initialized
INFO - 2024-12-03 10:12:35 --> Router Class Initialized
INFO - 2024-12-03 10:12:35 --> Output Class Initialized
INFO - 2024-12-03 10:12:35 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:35 --> CSRF cookie sent
INFO - 2024-12-03 10:12:35 --> Input Class Initialized
INFO - 2024-12-03 10:12:35 --> Language Class Initialized
INFO - 2024-12-03 10:12:35 --> Loader Class Initialized
INFO - 2024-12-03 10:12:35 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:35 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:35 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:35 --> Controller Class Initialized
INFO - 2024-12-03 10:12:35 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:35 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:35 --> Model "Review_model" initialized
INFO - 2024-12-03 10:12:35 --> Model "News_model" initialized
INFO - 2024-12-03 10:12:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:12:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:12:35 --> Query result: stdClass Object
(
    [view_count] => 14
)

INFO - 2024-12-03 10:12:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:12:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:12:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:12:35 --> Final output sent to browser
DEBUG - 2024-12-03 10:12:35 --> Total execution time: 0.2957
INFO - 2024-12-03 10:12:39 --> Config Class Initialized
INFO - 2024-12-03 10:12:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:39 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:39 --> URI Class Initialized
INFO - 2024-12-03 10:12:39 --> Router Class Initialized
INFO - 2024-12-03 10:12:39 --> Output Class Initialized
INFO - 2024-12-03 10:12:39 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:39 --> CSRF cookie sent
INFO - 2024-12-03 10:12:39 --> Input Class Initialized
INFO - 2024-12-03 10:12:39 --> Language Class Initialized
INFO - 2024-12-03 10:12:39 --> Loader Class Initialized
INFO - 2024-12-03 10:12:39 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:39 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:39 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:39 --> Controller Class Initialized
INFO - 2024-12-03 10:12:39 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:39 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:39 --> Model "Review_model" initialized
INFO - 2024-12-03 10:12:39 --> Model "News_model" initialized
INFO - 2024-12-03 10:12:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:12:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:12:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:12:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:12:39 --> Final output sent to browser
DEBUG - 2024-12-03 10:12:39 --> Total execution time: 0.0683
INFO - 2024-12-03 10:12:47 --> Config Class Initialized
INFO - 2024-12-03 10:12:47 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:47 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:47 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:47 --> URI Class Initialized
INFO - 2024-12-03 10:12:47 --> Router Class Initialized
INFO - 2024-12-03 10:12:47 --> Output Class Initialized
INFO - 2024-12-03 10:12:47 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:47 --> CSRF cookie sent
INFO - 2024-12-03 10:12:47 --> CSRF token verified
INFO - 2024-12-03 10:12:47 --> Input Class Initialized
INFO - 2024-12-03 10:12:47 --> Language Class Initialized
INFO - 2024-12-03 10:12:47 --> Loader Class Initialized
INFO - 2024-12-03 10:12:47 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:47 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:47 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:47 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:47 --> Controller Class Initialized
INFO - 2024-12-03 10:12:47 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:47 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:47 --> Model "Review_model" initialized
INFO - 2024-12-03 10:12:47 --> Model "News_model" initialized
INFO - 2024-12-03 10:12:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:12:47 --> Config Class Initialized
INFO - 2024-12-03 10:12:47 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:47 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:47 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:47 --> URI Class Initialized
INFO - 2024-12-03 10:12:47 --> Router Class Initialized
INFO - 2024-12-03 10:12:47 --> Output Class Initialized
INFO - 2024-12-03 10:12:47 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:47 --> CSRF cookie sent
INFO - 2024-12-03 10:12:47 --> Input Class Initialized
INFO - 2024-12-03 10:12:47 --> Language Class Initialized
INFO - 2024-12-03 10:12:47 --> Loader Class Initialized
INFO - 2024-12-03 10:12:47 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:47 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:47 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:47 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:47 --> Controller Class Initialized
INFO - 2024-12-03 10:12:47 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:47 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:12:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:12:47 --> Final output sent to browser
DEBUG - 2024-12-03 10:12:47 --> Total execution time: 0.0591
INFO - 2024-12-03 10:12:49 --> Config Class Initialized
INFO - 2024-12-03 10:12:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:49 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:49 --> URI Class Initialized
INFO - 2024-12-03 10:12:49 --> Router Class Initialized
INFO - 2024-12-03 10:12:49 --> Output Class Initialized
INFO - 2024-12-03 10:12:49 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:49 --> CSRF cookie sent
INFO - 2024-12-03 10:12:49 --> Input Class Initialized
INFO - 2024-12-03 10:12:49 --> Language Class Initialized
INFO - 2024-12-03 10:12:49 --> Loader Class Initialized
INFO - 2024-12-03 10:12:49 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:49 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:49 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:49 --> Controller Class Initialized
INFO - 2024-12-03 10:12:49 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:49 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:49 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:12:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:12:49 --> Final output sent to browser
DEBUG - 2024-12-03 10:12:49 --> Total execution time: 0.0611
INFO - 2024-12-03 10:12:52 --> Config Class Initialized
INFO - 2024-12-03 10:12:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:52 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:52 --> URI Class Initialized
INFO - 2024-12-03 10:12:52 --> Router Class Initialized
INFO - 2024-12-03 10:12:52 --> Output Class Initialized
INFO - 2024-12-03 10:12:52 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:52 --> CSRF cookie sent
INFO - 2024-12-03 10:12:52 --> Input Class Initialized
INFO - 2024-12-03 10:12:52 --> Language Class Initialized
INFO - 2024-12-03 10:12:52 --> Loader Class Initialized
INFO - 2024-12-03 10:12:52 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:52 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:52 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:52 --> Controller Class Initialized
INFO - 2024-12-03 10:12:52 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:52 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:52 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:12:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:12:52 --> Final output sent to browser
DEBUG - 2024-12-03 10:12:52 --> Total execution time: 0.0436
INFO - 2024-12-03 10:12:59 --> Config Class Initialized
INFO - 2024-12-03 10:12:59 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:12:59 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:12:59 --> Utf8 Class Initialized
INFO - 2024-12-03 10:12:59 --> URI Class Initialized
INFO - 2024-12-03 10:12:59 --> Router Class Initialized
INFO - 2024-12-03 10:12:59 --> Output Class Initialized
INFO - 2024-12-03 10:12:59 --> Security Class Initialized
DEBUG - 2024-12-03 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:12:59 --> CSRF cookie sent
INFO - 2024-12-03 10:12:59 --> Input Class Initialized
INFO - 2024-12-03 10:12:59 --> Language Class Initialized
INFO - 2024-12-03 10:12:59 --> Loader Class Initialized
INFO - 2024-12-03 10:12:59 --> Helper loaded: url_helper
INFO - 2024-12-03 10:12:59 --> Helper loaded: form_helper
INFO - 2024-12-03 10:12:59 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:12:59 --> Form Validation Class Initialized
INFO - 2024-12-03 10:12:59 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:12:59 --> Controller Class Initialized
INFO - 2024-12-03 10:12:59 --> Model "Category_model" initialized
INFO - 2024-12-03 10:12:59 --> Model "User_model" initialized
INFO - 2024-12-03 10:12:59 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:12:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:12:59 --> Final output sent to browser
DEBUG - 2024-12-03 10:12:59 --> Total execution time: 0.0484
INFO - 2024-12-03 10:15:33 --> Config Class Initialized
INFO - 2024-12-03 10:15:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:33 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:33 --> URI Class Initialized
INFO - 2024-12-03 10:15:33 --> Router Class Initialized
INFO - 2024-12-03 10:15:33 --> Output Class Initialized
INFO - 2024-12-03 10:15:33 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:33 --> CSRF cookie sent
INFO - 2024-12-03 10:15:33 --> Input Class Initialized
INFO - 2024-12-03 10:15:33 --> Language Class Initialized
INFO - 2024-12-03 10:15:33 --> Loader Class Initialized
INFO - 2024-12-03 10:15:33 --> Helper loaded: url_helper
INFO - 2024-12-03 10:15:33 --> Helper loaded: form_helper
INFO - 2024-12-03 10:15:33 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:15:33 --> Form Validation Class Initialized
INFO - 2024-12-03 10:15:33 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:15:33 --> Controller Class Initialized
INFO - 2024-12-03 10:15:33 --> Model "Category_model" initialized
INFO - 2024-12-03 10:15:33 --> Model "User_model" initialized
INFO - 2024-12-03 10:15:33 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:15:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:15:33 --> Final output sent to browser
DEBUG - 2024-12-03 10:15:33 --> Total execution time: 0.5528
INFO - 2024-12-03 10:15:36 --> Config Class Initialized
INFO - 2024-12-03 10:15:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:36 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:36 --> URI Class Initialized
INFO - 2024-12-03 10:15:36 --> Router Class Initialized
INFO - 2024-12-03 10:15:36 --> Output Class Initialized
INFO - 2024-12-03 10:15:36 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:36 --> CSRF cookie sent
INFO - 2024-12-03 10:15:36 --> Input Class Initialized
INFO - 2024-12-03 10:15:36 --> Language Class Initialized
INFO - 2024-12-03 10:15:36 --> Loader Class Initialized
INFO - 2024-12-03 10:15:36 --> Helper loaded: url_helper
INFO - 2024-12-03 10:15:36 --> Helper loaded: form_helper
INFO - 2024-12-03 10:15:36 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:15:36 --> Form Validation Class Initialized
INFO - 2024-12-03 10:15:36 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:15:36 --> Controller Class Initialized
INFO - 2024-12-03 10:15:36 --> Model "User_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "Category_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "Review_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "News_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:15:36 --> Config Class Initialized
INFO - 2024-12-03 10:15:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:36 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:36 --> URI Class Initialized
INFO - 2024-12-03 10:15:36 --> Router Class Initialized
INFO - 2024-12-03 10:15:36 --> Output Class Initialized
INFO - 2024-12-03 10:15:36 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:36 --> CSRF cookie sent
INFO - 2024-12-03 10:15:36 --> Input Class Initialized
INFO - 2024-12-03 10:15:36 --> Language Class Initialized
INFO - 2024-12-03 10:15:36 --> Loader Class Initialized
INFO - 2024-12-03 10:15:36 --> Helper loaded: url_helper
INFO - 2024-12-03 10:15:36 --> Helper loaded: form_helper
INFO - 2024-12-03 10:15:36 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:15:36 --> Form Validation Class Initialized
INFO - 2024-12-03 10:15:36 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:15:36 --> Controller Class Initialized
INFO - 2024-12-03 10:15:36 --> Model "User_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "Category_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "Review_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "News_model" initialized
INFO - 2024-12-03 10:15:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:15:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:15:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:15:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:15:36 --> Final output sent to browser
DEBUG - 2024-12-03 10:15:36 --> Total execution time: 0.0838
INFO - 2024-12-03 10:15:41 --> Config Class Initialized
INFO - 2024-12-03 10:15:41 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:41 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:41 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:41 --> URI Class Initialized
INFO - 2024-12-03 10:15:41 --> Router Class Initialized
INFO - 2024-12-03 10:15:41 --> Output Class Initialized
INFO - 2024-12-03 10:15:41 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:41 --> CSRF cookie sent
INFO - 2024-12-03 10:15:41 --> CSRF token verified
INFO - 2024-12-03 10:15:41 --> Input Class Initialized
INFO - 2024-12-03 10:15:41 --> Language Class Initialized
INFO - 2024-12-03 10:15:41 --> Loader Class Initialized
INFO - 2024-12-03 10:15:41 --> Helper loaded: url_helper
INFO - 2024-12-03 10:15:41 --> Helper loaded: form_helper
INFO - 2024-12-03 10:15:41 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:15:41 --> Form Validation Class Initialized
INFO - 2024-12-03 10:15:41 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:15:41 --> Controller Class Initialized
INFO - 2024-12-03 10:15:41 --> Model "User_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "Category_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "Review_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "News_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:15:41 --> Config Class Initialized
INFO - 2024-12-03 10:15:41 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:41 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:41 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:41 --> URI Class Initialized
INFO - 2024-12-03 10:15:41 --> Router Class Initialized
INFO - 2024-12-03 10:15:41 --> Output Class Initialized
INFO - 2024-12-03 10:15:41 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:41 --> CSRF cookie sent
INFO - 2024-12-03 10:15:41 --> Input Class Initialized
INFO - 2024-12-03 10:15:41 --> Language Class Initialized
INFO - 2024-12-03 10:15:41 --> Loader Class Initialized
INFO - 2024-12-03 10:15:41 --> Helper loaded: url_helper
INFO - 2024-12-03 10:15:41 --> Helper loaded: form_helper
INFO - 2024-12-03 10:15:41 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:15:41 --> Form Validation Class Initialized
INFO - 2024-12-03 10:15:41 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:15:41 --> Controller Class Initialized
INFO - 2024-12-03 10:15:41 --> Model "User_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "Category_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "Review_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "News_model" initialized
INFO - 2024-12-03 10:15:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:15:42 --> Query result: stdClass Object
(
    [view_count] => 15
)

INFO - 2024-12-03 10:15:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:15:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:15:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:15:42 --> Final output sent to browser
DEBUG - 2024-12-03 10:15:42 --> Total execution time: 0.1315
INFO - 2024-12-03 10:15:42 --> Config Class Initialized
INFO - 2024-12-03 10:15:42 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:42 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:42 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:42 --> URI Class Initialized
INFO - 2024-12-03 10:15:42 --> Router Class Initialized
INFO - 2024-12-03 10:15:42 --> Output Class Initialized
INFO - 2024-12-03 10:15:42 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:42 --> CSRF cookie sent
INFO - 2024-12-03 10:15:42 --> Input Class Initialized
INFO - 2024-12-03 10:15:42 --> Language Class Initialized
ERROR - 2024-12-03 10:15:42 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 10:15:48 --> Config Class Initialized
INFO - 2024-12-03 10:15:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:15:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:15:48 --> Utf8 Class Initialized
INFO - 2024-12-03 10:15:48 --> URI Class Initialized
INFO - 2024-12-03 10:15:48 --> Router Class Initialized
INFO - 2024-12-03 10:15:48 --> Output Class Initialized
INFO - 2024-12-03 10:15:48 --> Security Class Initialized
DEBUG - 2024-12-03 10:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:15:48 --> CSRF cookie sent
INFO - 2024-12-03 10:15:48 --> Input Class Initialized
INFO - 2024-12-03 10:15:48 --> Language Class Initialized
INFO - 2024-12-03 10:15:48 --> Loader Class Initialized
INFO - 2024-12-03 10:15:48 --> Helper loaded: url_helper
INFO - 2024-12-03 10:15:48 --> Helper loaded: form_helper
INFO - 2024-12-03 10:15:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:15:48 --> Form Validation Class Initialized
INFO - 2024-12-03 10:15:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:15:48 --> Controller Class Initialized
INFO - 2024-12-03 10:15:48 --> Model "User_model" initialized
INFO - 2024-12-03 10:15:48 --> Model "Category_model" initialized
INFO - 2024-12-03 10:15:48 --> Model "Review_model" initialized
INFO - 2024-12-03 10:15:48 --> Model "News_model" initialized
INFO - 2024-12-03 10:15:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:15:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:15:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:15:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 10:15:48 --> Final output sent to browser
DEBUG - 2024-12-03 10:15:48 --> Total execution time: 0.0560
INFO - 2024-12-03 10:16:44 --> Config Class Initialized
INFO - 2024-12-03 10:16:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:16:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:16:44 --> Utf8 Class Initialized
INFO - 2024-12-03 10:16:44 --> URI Class Initialized
INFO - 2024-12-03 10:16:44 --> Router Class Initialized
INFO - 2024-12-03 10:16:44 --> Output Class Initialized
INFO - 2024-12-03 10:16:44 --> Security Class Initialized
DEBUG - 2024-12-03 10:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:16:44 --> CSRF cookie sent
INFO - 2024-12-03 10:16:44 --> CSRF token verified
INFO - 2024-12-03 10:16:44 --> Input Class Initialized
INFO - 2024-12-03 10:16:44 --> Language Class Initialized
INFO - 2024-12-03 10:16:44 --> Loader Class Initialized
INFO - 2024-12-03 10:16:44 --> Helper loaded: url_helper
INFO - 2024-12-03 10:16:44 --> Helper loaded: form_helper
INFO - 2024-12-03 10:16:44 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:16:44 --> Form Validation Class Initialized
INFO - 2024-12-03 10:16:44 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:16:44 --> Controller Class Initialized
INFO - 2024-12-03 10:16:44 --> Model "User_model" initialized
INFO - 2024-12-03 10:16:44 --> Model "Category_model" initialized
INFO - 2024-12-03 10:16:44 --> Model "Review_model" initialized
INFO - 2024-12-03 10:16:44 --> Model "News_model" initialized
INFO - 2024-12-03 10:16:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:16:45 --> Upload Class Initialized
INFO - 2024-12-03 10:16:45 --> Config Class Initialized
INFO - 2024-12-03 10:16:45 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:16:45 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:16:45 --> Utf8 Class Initialized
INFO - 2024-12-03 10:16:45 --> URI Class Initialized
INFO - 2024-12-03 10:16:45 --> Router Class Initialized
INFO - 2024-12-03 10:16:45 --> Output Class Initialized
INFO - 2024-12-03 10:16:45 --> Security Class Initialized
DEBUG - 2024-12-03 10:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:16:45 --> CSRF cookie sent
INFO - 2024-12-03 10:16:45 --> Input Class Initialized
INFO - 2024-12-03 10:16:45 --> Language Class Initialized
INFO - 2024-12-03 10:16:45 --> Loader Class Initialized
INFO - 2024-12-03 10:16:45 --> Helper loaded: url_helper
INFO - 2024-12-03 10:16:45 --> Helper loaded: form_helper
INFO - 2024-12-03 10:16:45 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:16:45 --> Form Validation Class Initialized
INFO - 2024-12-03 10:16:45 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:16:45 --> Controller Class Initialized
INFO - 2024-12-03 10:16:45 --> Model "User_model" initialized
INFO - 2024-12-03 10:16:45 --> Model "Category_model" initialized
INFO - 2024-12-03 10:16:45 --> Model "Review_model" initialized
INFO - 2024-12-03 10:16:45 --> Model "News_model" initialized
INFO - 2024-12-03 10:16:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:16:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:16:47 --> Query result: stdClass Object
(
    [view_count] => 16
)

INFO - 2024-12-03 10:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:16:47 --> Final output sent to browser
DEBUG - 2024-12-03 10:16:47 --> Total execution time: 2.5735
INFO - 2024-12-03 10:16:48 --> Config Class Initialized
INFO - 2024-12-03 10:16:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:16:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:16:48 --> Utf8 Class Initialized
INFO - 2024-12-03 10:16:48 --> URI Class Initialized
INFO - 2024-12-03 10:16:48 --> Router Class Initialized
INFO - 2024-12-03 10:16:48 --> Output Class Initialized
INFO - 2024-12-03 10:16:48 --> Security Class Initialized
DEBUG - 2024-12-03 10:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:16:48 --> CSRF cookie sent
INFO - 2024-12-03 10:16:48 --> Input Class Initialized
INFO - 2024-12-03 10:16:48 --> Language Class Initialized
ERROR - 2024-12-03 10:16:48 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-03 10:16:55 --> Config Class Initialized
INFO - 2024-12-03 10:16:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:16:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:16:55 --> Utf8 Class Initialized
INFO - 2024-12-03 10:16:55 --> URI Class Initialized
INFO - 2024-12-03 10:16:55 --> Router Class Initialized
INFO - 2024-12-03 10:16:55 --> Output Class Initialized
INFO - 2024-12-03 10:16:55 --> Security Class Initialized
DEBUG - 2024-12-03 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:16:55 --> CSRF cookie sent
INFO - 2024-12-03 10:16:55 --> Input Class Initialized
INFO - 2024-12-03 10:16:55 --> Language Class Initialized
INFO - 2024-12-03 10:16:55 --> Loader Class Initialized
INFO - 2024-12-03 10:16:55 --> Helper loaded: url_helper
INFO - 2024-12-03 10:16:55 --> Helper loaded: form_helper
INFO - 2024-12-03 10:16:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:16:55 --> Form Validation Class Initialized
INFO - 2024-12-03 10:16:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:16:55 --> Controller Class Initialized
INFO - 2024-12-03 10:16:55 --> Model "Category_model" initialized
INFO - 2024-12-03 10:16:55 --> Model "User_model" initialized
INFO - 2024-12-03 10:16:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:16:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:16:55 --> Final output sent to browser
DEBUG - 2024-12-03 10:16:55 --> Total execution time: 0.0859
INFO - 2024-12-03 10:16:57 --> Config Class Initialized
INFO - 2024-12-03 10:16:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:16:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:16:57 --> Utf8 Class Initialized
INFO - 2024-12-03 10:16:57 --> URI Class Initialized
INFO - 2024-12-03 10:16:57 --> Router Class Initialized
INFO - 2024-12-03 10:16:57 --> Output Class Initialized
INFO - 2024-12-03 10:16:57 --> Security Class Initialized
DEBUG - 2024-12-03 10:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:16:57 --> CSRF cookie sent
INFO - 2024-12-03 10:16:57 --> Input Class Initialized
INFO - 2024-12-03 10:16:57 --> Language Class Initialized
INFO - 2024-12-03 10:16:57 --> Loader Class Initialized
INFO - 2024-12-03 10:16:57 --> Helper loaded: url_helper
INFO - 2024-12-03 10:16:57 --> Helper loaded: form_helper
INFO - 2024-12-03 10:16:57 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:16:57 --> Form Validation Class Initialized
INFO - 2024-12-03 10:16:57 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:16:57 --> Controller Class Initialized
INFO - 2024-12-03 10:16:57 --> Model "Category_model" initialized
INFO - 2024-12-03 10:16:57 --> Model "User_model" initialized
INFO - 2024-12-03 10:16:57 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:16:57 --> Config Class Initialized
INFO - 2024-12-03 10:16:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:16:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:16:57 --> Utf8 Class Initialized
INFO - 2024-12-03 10:16:57 --> URI Class Initialized
INFO - 2024-12-03 10:16:57 --> Router Class Initialized
INFO - 2024-12-03 10:16:57 --> Output Class Initialized
INFO - 2024-12-03 10:16:57 --> Security Class Initialized
DEBUG - 2024-12-03 10:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:16:57 --> CSRF cookie sent
INFO - 2024-12-03 10:16:57 --> Input Class Initialized
INFO - 2024-12-03 10:16:57 --> Language Class Initialized
ERROR - 2024-12-03 10:16:57 --> 404 Page Not Found: Admin/verifikasi_kuliner
INFO - 2024-12-03 10:17:01 --> Config Class Initialized
INFO - 2024-12-03 10:17:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:01 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:01 --> URI Class Initialized
INFO - 2024-12-03 10:17:01 --> Router Class Initialized
INFO - 2024-12-03 10:17:01 --> Output Class Initialized
INFO - 2024-12-03 10:17:01 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:01 --> CSRF cookie sent
INFO - 2024-12-03 10:17:01 --> Input Class Initialized
INFO - 2024-12-03 10:17:01 --> Language Class Initialized
INFO - 2024-12-03 10:17:01 --> Loader Class Initialized
INFO - 2024-12-03 10:17:01 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:01 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:01 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:01 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:01 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:01 --> Controller Class Initialized
INFO - 2024-12-03 10:17:01 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:01 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:01 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:17:01 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:01 --> Total execution time: 0.0466
INFO - 2024-12-03 10:17:03 --> Config Class Initialized
INFO - 2024-12-03 10:17:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:03 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:03 --> URI Class Initialized
INFO - 2024-12-03 10:17:03 --> Router Class Initialized
INFO - 2024-12-03 10:17:03 --> Output Class Initialized
INFO - 2024-12-03 10:17:03 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:03 --> CSRF cookie sent
INFO - 2024-12-03 10:17:03 --> Input Class Initialized
INFO - 2024-12-03 10:17:03 --> Language Class Initialized
INFO - 2024-12-03 10:17:03 --> Loader Class Initialized
INFO - 2024-12-03 10:17:03 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:03 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:03 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:03 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:03 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:03 --> Controller Class Initialized
INFO - 2024-12-03 10:17:03 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:03 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:03 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:17:03 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:03 --> Total execution time: 0.0592
INFO - 2024-12-03 10:17:04 --> Config Class Initialized
INFO - 2024-12-03 10:17:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:04 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:04 --> URI Class Initialized
INFO - 2024-12-03 10:17:04 --> Router Class Initialized
INFO - 2024-12-03 10:17:04 --> Output Class Initialized
INFO - 2024-12-03 10:17:04 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:04 --> CSRF cookie sent
INFO - 2024-12-03 10:17:04 --> Input Class Initialized
INFO - 2024-12-03 10:17:04 --> Language Class Initialized
INFO - 2024-12-03 10:17:04 --> Loader Class Initialized
INFO - 2024-12-03 10:17:04 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:04 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:04 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:05 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:05 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:05 --> Controller Class Initialized
INFO - 2024-12-03 10:17:05 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:05 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:05 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:17:05 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:05 --> Total execution time: 0.0568
INFO - 2024-12-03 10:17:08 --> Config Class Initialized
INFO - 2024-12-03 10:17:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:08 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:08 --> URI Class Initialized
INFO - 2024-12-03 10:17:08 --> Router Class Initialized
INFO - 2024-12-03 10:17:08 --> Output Class Initialized
INFO - 2024-12-03 10:17:08 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:08 --> CSRF cookie sent
INFO - 2024-12-03 10:17:08 --> Input Class Initialized
INFO - 2024-12-03 10:17:08 --> Language Class Initialized
INFO - 2024-12-03 10:17:08 --> Loader Class Initialized
INFO - 2024-12-03 10:17:08 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:08 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:08 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:09 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:09 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:09 --> Controller Class Initialized
INFO - 2024-12-03 10:17:09 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:09 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:09 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:09 --> Config Class Initialized
INFO - 2024-12-03 10:17:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:09 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:09 --> URI Class Initialized
INFO - 2024-12-03 10:17:09 --> Router Class Initialized
INFO - 2024-12-03 10:17:09 --> Output Class Initialized
INFO - 2024-12-03 10:17:09 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:09 --> CSRF cookie sent
INFO - 2024-12-03 10:17:09 --> Input Class Initialized
INFO - 2024-12-03 10:17:09 --> Language Class Initialized
INFO - 2024-12-03 10:17:09 --> Loader Class Initialized
INFO - 2024-12-03 10:17:09 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:09 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:09 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:09 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:09 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:09 --> Controller Class Initialized
INFO - 2024-12-03 10:17:09 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:09 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:09 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:17:09 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:09 --> Total execution time: 0.0711
INFO - 2024-12-03 10:17:15 --> Config Class Initialized
INFO - 2024-12-03 10:17:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:15 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:15 --> URI Class Initialized
INFO - 2024-12-03 10:17:15 --> Router Class Initialized
INFO - 2024-12-03 10:17:15 --> Output Class Initialized
INFO - 2024-12-03 10:17:15 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:15 --> CSRF cookie sent
INFO - 2024-12-03 10:17:15 --> Input Class Initialized
INFO - 2024-12-03 10:17:15 --> Language Class Initialized
INFO - 2024-12-03 10:17:15 --> Loader Class Initialized
INFO - 2024-12-03 10:17:15 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:15 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:15 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:15 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:15 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:15 --> Controller Class Initialized
INFO - 2024-12-03 10:17:15 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:15 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:15 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:15 --> Config Class Initialized
INFO - 2024-12-03 10:17:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:15 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:15 --> URI Class Initialized
INFO - 2024-12-03 10:17:15 --> Router Class Initialized
INFO - 2024-12-03 10:17:15 --> Output Class Initialized
INFO - 2024-12-03 10:17:15 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:15 --> CSRF cookie sent
INFO - 2024-12-03 10:17:15 --> Input Class Initialized
INFO - 2024-12-03 10:17:15 --> Language Class Initialized
INFO - 2024-12-03 10:17:15 --> Loader Class Initialized
INFO - 2024-12-03 10:17:15 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:15 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:15 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:15 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:15 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:15 --> Controller Class Initialized
INFO - 2024-12-03 10:17:15 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:15 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:15 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:17:15 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:15 --> Total execution time: 0.0395
INFO - 2024-12-03 10:17:17 --> Config Class Initialized
INFO - 2024-12-03 10:17:17 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:17 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:17 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:17 --> URI Class Initialized
INFO - 2024-12-03 10:17:17 --> Router Class Initialized
INFO - 2024-12-03 10:17:17 --> Output Class Initialized
INFO - 2024-12-03 10:17:17 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:17 --> CSRF cookie sent
INFO - 2024-12-03 10:17:17 --> Input Class Initialized
INFO - 2024-12-03 10:17:17 --> Language Class Initialized
INFO - 2024-12-03 10:17:17 --> Loader Class Initialized
INFO - 2024-12-03 10:17:17 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:17 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:17 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:17 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:17 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:17 --> Controller Class Initialized
INFO - 2024-12-03 10:17:17 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:17 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:17:17 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:17 --> Total execution time: 0.0550
INFO - 2024-12-03 10:17:20 --> Config Class Initialized
INFO - 2024-12-03 10:17:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:17:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:17:20 --> Utf8 Class Initialized
INFO - 2024-12-03 10:17:20 --> URI Class Initialized
INFO - 2024-12-03 10:17:20 --> Router Class Initialized
INFO - 2024-12-03 10:17:20 --> Output Class Initialized
INFO - 2024-12-03 10:17:20 --> Security Class Initialized
DEBUG - 2024-12-03 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:17:20 --> CSRF cookie sent
INFO - 2024-12-03 10:17:20 --> Input Class Initialized
INFO - 2024-12-03 10:17:20 --> Language Class Initialized
INFO - 2024-12-03 10:17:20 --> Loader Class Initialized
INFO - 2024-12-03 10:17:20 --> Helper loaded: url_helper
INFO - 2024-12-03 10:17:20 --> Helper loaded: form_helper
INFO - 2024-12-03 10:17:20 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:17:20 --> Form Validation Class Initialized
INFO - 2024-12-03 10:17:20 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:17:20 --> Controller Class Initialized
INFO - 2024-12-03 10:17:20 --> Model "Category_model" initialized
INFO - 2024-12-03 10:17:20 --> Model "User_model" initialized
INFO - 2024-12-03 10:17:20 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:17:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:17:20 --> Final output sent to browser
DEBUG - 2024-12-03 10:17:20 --> Total execution time: 0.0888
INFO - 2024-12-03 10:56:58 --> Config Class Initialized
INFO - 2024-12-03 10:56:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:56:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:56:58 --> Utf8 Class Initialized
INFO - 2024-12-03 10:56:58 --> URI Class Initialized
INFO - 2024-12-03 10:56:58 --> Router Class Initialized
INFO - 2024-12-03 10:56:58 --> Output Class Initialized
INFO - 2024-12-03 10:56:58 --> Security Class Initialized
DEBUG - 2024-12-03 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:56:58 --> CSRF cookie sent
INFO - 2024-12-03 10:56:58 --> Input Class Initialized
INFO - 2024-12-03 10:56:58 --> Language Class Initialized
INFO - 2024-12-03 10:56:58 --> Loader Class Initialized
INFO - 2024-12-03 10:56:58 --> Helper loaded: url_helper
INFO - 2024-12-03 10:56:59 --> Helper loaded: form_helper
INFO - 2024-12-03 10:56:59 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:56:59 --> Form Validation Class Initialized
INFO - 2024-12-03 10:56:59 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:56:59 --> Controller Class Initialized
INFO - 2024-12-03 10:56:59 --> Model "User_model" initialized
INFO - 2024-12-03 10:56:59 --> Model "Category_model" initialized
INFO - 2024-12-03 10:56:59 --> Model "Review_model" initialized
INFO - 2024-12-03 10:56:59 --> Model "News_model" initialized
INFO - 2024-12-03 10:56:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:56:59 --> Query result: stdClass Object
(
    [view_count] => 17
)

INFO - 2024-12-03 10:56:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:56:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:56:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:56:59 --> Final output sent to browser
DEBUG - 2024-12-03 10:56:59 --> Total execution time: 0.3754
INFO - 2024-12-03 10:57:40 --> Config Class Initialized
INFO - 2024-12-03 10:57:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:40 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:40 --> URI Class Initialized
INFO - 2024-12-03 10:57:40 --> Router Class Initialized
INFO - 2024-12-03 10:57:40 --> Output Class Initialized
INFO - 2024-12-03 10:57:40 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:40 --> CSRF cookie sent
INFO - 2024-12-03 10:57:40 --> Input Class Initialized
INFO - 2024-12-03 10:57:40 --> Language Class Initialized
INFO - 2024-12-03 10:57:40 --> Loader Class Initialized
INFO - 2024-12-03 10:57:40 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:40 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:40 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:40 --> Controller Class Initialized
INFO - 2024-12-03 10:57:40 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:40 --> Config Class Initialized
INFO - 2024-12-03 10:57:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:40 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:40 --> URI Class Initialized
INFO - 2024-12-03 10:57:40 --> Router Class Initialized
INFO - 2024-12-03 10:57:40 --> Output Class Initialized
INFO - 2024-12-03 10:57:40 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:40 --> CSRF cookie sent
INFO - 2024-12-03 10:57:40 --> Input Class Initialized
INFO - 2024-12-03 10:57:40 --> Language Class Initialized
INFO - 2024-12-03 10:57:40 --> Loader Class Initialized
INFO - 2024-12-03 10:57:40 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:40 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:40 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:40 --> Controller Class Initialized
INFO - 2024-12-03 10:57:40 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:57:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:57:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:57:40 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:40 --> Total execution time: 0.0671
INFO - 2024-12-03 10:57:44 --> Config Class Initialized
INFO - 2024-12-03 10:57:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:44 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:44 --> URI Class Initialized
INFO - 2024-12-03 10:57:44 --> Router Class Initialized
INFO - 2024-12-03 10:57:44 --> Output Class Initialized
INFO - 2024-12-03 10:57:44 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:44 --> CSRF cookie sent
INFO - 2024-12-03 10:57:44 --> CSRF token verified
INFO - 2024-12-03 10:57:44 --> Input Class Initialized
INFO - 2024-12-03 10:57:44 --> Language Class Initialized
INFO - 2024-12-03 10:57:44 --> Loader Class Initialized
INFO - 2024-12-03 10:57:44 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:44 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:44 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:44 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:44 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:44 --> Controller Class Initialized
INFO - 2024-12-03 10:57:44 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:44 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:44 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:44 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:44 --> Config Class Initialized
INFO - 2024-12-03 10:57:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:44 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:44 --> URI Class Initialized
INFO - 2024-12-03 10:57:44 --> Router Class Initialized
INFO - 2024-12-03 10:57:44 --> Output Class Initialized
INFO - 2024-12-03 10:57:44 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:44 --> CSRF cookie sent
INFO - 2024-12-03 10:57:44 --> Input Class Initialized
INFO - 2024-12-03 10:57:44 --> Language Class Initialized
INFO - 2024-12-03 10:57:44 --> Loader Class Initialized
INFO - 2024-12-03 10:57:44 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:44 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:44 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:44 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:44 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:44 --> Controller Class Initialized
INFO - 2024-12-03 10:57:44 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:44 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:44 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:57:44 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:44 --> Total execution time: 0.0460
INFO - 2024-12-03 10:57:46 --> Config Class Initialized
INFO - 2024-12-03 10:57:46 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:46 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:46 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:46 --> URI Class Initialized
INFO - 2024-12-03 10:57:46 --> Router Class Initialized
INFO - 2024-12-03 10:57:46 --> Output Class Initialized
INFO - 2024-12-03 10:57:46 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:46 --> CSRF cookie sent
INFO - 2024-12-03 10:57:46 --> Input Class Initialized
INFO - 2024-12-03 10:57:46 --> Language Class Initialized
INFO - 2024-12-03 10:57:46 --> Loader Class Initialized
INFO - 2024-12-03 10:57:46 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:46 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:46 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:46 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:46 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:46 --> Controller Class Initialized
INFO - 2024-12-03 10:57:46 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:46 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:46 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:57:46 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:46 --> Total execution time: 0.0569
INFO - 2024-12-03 10:57:48 --> Config Class Initialized
INFO - 2024-12-03 10:57:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:48 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:48 --> URI Class Initialized
INFO - 2024-12-03 10:57:48 --> Router Class Initialized
INFO - 2024-12-03 10:57:48 --> Output Class Initialized
INFO - 2024-12-03 10:57:48 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:48 --> CSRF cookie sent
INFO - 2024-12-03 10:57:48 --> Input Class Initialized
INFO - 2024-12-03 10:57:48 --> Language Class Initialized
INFO - 2024-12-03 10:57:48 --> Loader Class Initialized
INFO - 2024-12-03 10:57:48 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:48 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:48 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:48 --> Controller Class Initialized
INFO - 2024-12-03 10:57:48 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:48 --> Config Class Initialized
INFO - 2024-12-03 10:57:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:48 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:48 --> URI Class Initialized
INFO - 2024-12-03 10:57:48 --> Router Class Initialized
INFO - 2024-12-03 10:57:48 --> Output Class Initialized
INFO - 2024-12-03 10:57:48 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:48 --> CSRF cookie sent
INFO - 2024-12-03 10:57:48 --> Input Class Initialized
INFO - 2024-12-03 10:57:48 --> Language Class Initialized
INFO - 2024-12-03 10:57:48 --> Loader Class Initialized
INFO - 2024-12-03 10:57:48 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:48 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:48 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:48 --> Controller Class Initialized
INFO - 2024-12-03 10:57:48 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:57:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:57:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:57:48 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:48 --> Total execution time: 0.0388
INFO - 2024-12-03 10:57:50 --> Config Class Initialized
INFO - 2024-12-03 10:57:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:50 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:50 --> URI Class Initialized
INFO - 2024-12-03 10:57:50 --> Router Class Initialized
INFO - 2024-12-03 10:57:50 --> Output Class Initialized
INFO - 2024-12-03 10:57:50 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:50 --> CSRF cookie sent
INFO - 2024-12-03 10:57:50 --> Input Class Initialized
INFO - 2024-12-03 10:57:50 --> Language Class Initialized
INFO - 2024-12-03 10:57:50 --> Loader Class Initialized
INFO - 2024-12-03 10:57:50 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:50 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:50 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:50 --> Controller Class Initialized
INFO - 2024-12-03 10:57:50 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:50 --> Config Class Initialized
INFO - 2024-12-03 10:57:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:50 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:50 --> URI Class Initialized
INFO - 2024-12-03 10:57:50 --> Router Class Initialized
INFO - 2024-12-03 10:57:50 --> Output Class Initialized
INFO - 2024-12-03 10:57:50 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:50 --> CSRF cookie sent
INFO - 2024-12-03 10:57:50 --> Input Class Initialized
INFO - 2024-12-03 10:57:50 --> Language Class Initialized
INFO - 2024-12-03 10:57:50 --> Loader Class Initialized
INFO - 2024-12-03 10:57:50 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:50 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:50 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:50 --> Controller Class Initialized
INFO - 2024-12-03 10:57:50 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:57:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:57:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:57:50 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:50 --> Total execution time: 0.0504
INFO - 2024-12-03 10:57:54 --> Config Class Initialized
INFO - 2024-12-03 10:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:54 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:54 --> URI Class Initialized
INFO - 2024-12-03 10:57:54 --> Router Class Initialized
INFO - 2024-12-03 10:57:54 --> Output Class Initialized
INFO - 2024-12-03 10:57:54 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:54 --> CSRF cookie sent
INFO - 2024-12-03 10:57:54 --> CSRF token verified
INFO - 2024-12-03 10:57:54 --> Input Class Initialized
INFO - 2024-12-03 10:57:54 --> Language Class Initialized
INFO - 2024-12-03 10:57:54 --> Loader Class Initialized
INFO - 2024-12-03 10:57:54 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:54 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:54 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:54 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:54 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:54 --> Controller Class Initialized
INFO - 2024-12-03 10:57:54 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:54 --> Config Class Initialized
INFO - 2024-12-03 10:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:54 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:54 --> URI Class Initialized
INFO - 2024-12-03 10:57:54 --> Router Class Initialized
INFO - 2024-12-03 10:57:54 --> Output Class Initialized
INFO - 2024-12-03 10:57:54 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:54 --> CSRF cookie sent
INFO - 2024-12-03 10:57:54 --> Input Class Initialized
INFO - 2024-12-03 10:57:54 --> Language Class Initialized
INFO - 2024-12-03 10:57:54 --> Loader Class Initialized
INFO - 2024-12-03 10:57:54 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:54 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:54 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:54 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:54 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:54 --> Controller Class Initialized
INFO - 2024-12-03 10:57:54 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:57:54 --> Query result: stdClass Object
(
    [view_count] => 18
)

INFO - 2024-12-03 10:57:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:57:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:57:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:57:54 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:54 --> Total execution time: 0.0840
INFO - 2024-12-03 10:57:54 --> Config Class Initialized
INFO - 2024-12-03 10:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:54 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:54 --> URI Class Initialized
INFO - 2024-12-03 10:57:54 --> Router Class Initialized
INFO - 2024-12-03 10:57:54 --> Output Class Initialized
INFO - 2024-12-03 10:57:54 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:54 --> CSRF cookie sent
INFO - 2024-12-03 10:57:54 --> Input Class Initialized
INFO - 2024-12-03 10:57:54 --> Language Class Initialized
ERROR - 2024-12-03 10:57:54 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 10:57:55 --> Config Class Initialized
INFO - 2024-12-03 10:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:57:55 --> Utf8 Class Initialized
INFO - 2024-12-03 10:57:55 --> URI Class Initialized
INFO - 2024-12-03 10:57:55 --> Router Class Initialized
INFO - 2024-12-03 10:57:55 --> Output Class Initialized
INFO - 2024-12-03 10:57:55 --> Security Class Initialized
DEBUG - 2024-12-03 10:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:57:55 --> CSRF cookie sent
INFO - 2024-12-03 10:57:55 --> Input Class Initialized
INFO - 2024-12-03 10:57:55 --> Language Class Initialized
INFO - 2024-12-03 10:57:55 --> Loader Class Initialized
INFO - 2024-12-03 10:57:55 --> Helper loaded: url_helper
INFO - 2024-12-03 10:57:55 --> Helper loaded: form_helper
INFO - 2024-12-03 10:57:55 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:57:55 --> Form Validation Class Initialized
INFO - 2024-12-03 10:57:55 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:57:55 --> Controller Class Initialized
INFO - 2024-12-03 10:57:55 --> Model "User_model" initialized
INFO - 2024-12-03 10:57:55 --> Model "Category_model" initialized
INFO - 2024-12-03 10:57:55 --> Model "Review_model" initialized
INFO - 2024-12-03 10:57:55 --> Model "News_model" initialized
INFO - 2024-12-03 10:57:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:57:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:57:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:57:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 10:57:55 --> Final output sent to browser
DEBUG - 2024-12-03 10:57:55 --> Total execution time: 0.0771
INFO - 2024-12-03 10:58:31 --> Config Class Initialized
INFO - 2024-12-03 10:58:31 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:32 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:32 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:32 --> URI Class Initialized
INFO - 2024-12-03 10:58:32 --> Router Class Initialized
INFO - 2024-12-03 10:58:32 --> Output Class Initialized
INFO - 2024-12-03 10:58:32 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:32 --> CSRF cookie sent
INFO - 2024-12-03 10:58:32 --> CSRF token verified
INFO - 2024-12-03 10:58:32 --> Input Class Initialized
INFO - 2024-12-03 10:58:32 --> Language Class Initialized
INFO - 2024-12-03 10:58:32 --> Loader Class Initialized
INFO - 2024-12-03 10:58:32 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:32 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:32 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:32 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:32 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:32 --> Controller Class Initialized
INFO - 2024-12-03 10:58:32 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "Review_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "News_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:32 --> Upload Class Initialized
INFO - 2024-12-03 10:58:32 --> Config Class Initialized
INFO - 2024-12-03 10:58:32 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:32 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:32 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:32 --> URI Class Initialized
INFO - 2024-12-03 10:58:32 --> Router Class Initialized
INFO - 2024-12-03 10:58:32 --> Output Class Initialized
INFO - 2024-12-03 10:58:32 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:32 --> CSRF cookie sent
INFO - 2024-12-03 10:58:32 --> Input Class Initialized
INFO - 2024-12-03 10:58:32 --> Language Class Initialized
INFO - 2024-12-03 10:58:32 --> Loader Class Initialized
INFO - 2024-12-03 10:58:32 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:32 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:32 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:32 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:32 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:32 --> Controller Class Initialized
INFO - 2024-12-03 10:58:32 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "Review_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "News_model" initialized
INFO - 2024-12-03 10:58:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 10:58:32 --> Query result: stdClass Object
(
    [view_count] => 19
)

INFO - 2024-12-03 10:58:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:58:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:58:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 10:58:32 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:32 --> Total execution time: 0.0655
INFO - 2024-12-03 10:58:32 --> Config Class Initialized
INFO - 2024-12-03 10:58:32 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:32 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:32 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:32 --> URI Class Initialized
INFO - 2024-12-03 10:58:32 --> Router Class Initialized
INFO - 2024-12-03 10:58:32 --> Output Class Initialized
INFO - 2024-12-03 10:58:32 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:32 --> CSRF cookie sent
INFO - 2024-12-03 10:58:32 --> Input Class Initialized
INFO - 2024-12-03 10:58:32 --> Language Class Initialized
ERROR - 2024-12-03 10:58:32 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-03 10:58:35 --> Config Class Initialized
INFO - 2024-12-03 10:58:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:35 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:35 --> URI Class Initialized
INFO - 2024-12-03 10:58:35 --> Router Class Initialized
INFO - 2024-12-03 10:58:35 --> Output Class Initialized
INFO - 2024-12-03 10:58:35 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:35 --> CSRF cookie sent
INFO - 2024-12-03 10:58:35 --> Input Class Initialized
INFO - 2024-12-03 10:58:35 --> Language Class Initialized
INFO - 2024-12-03 10:58:35 --> Loader Class Initialized
INFO - 2024-12-03 10:58:35 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:35 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:35 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:35 --> Controller Class Initialized
INFO - 2024-12-03 10:58:35 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "Review_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "News_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:35 --> Config Class Initialized
INFO - 2024-12-03 10:58:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:35 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:35 --> URI Class Initialized
INFO - 2024-12-03 10:58:35 --> Router Class Initialized
INFO - 2024-12-03 10:58:35 --> Output Class Initialized
INFO - 2024-12-03 10:58:35 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:35 --> CSRF cookie sent
INFO - 2024-12-03 10:58:35 --> Input Class Initialized
INFO - 2024-12-03 10:58:35 --> Language Class Initialized
INFO - 2024-12-03 10:58:35 --> Loader Class Initialized
INFO - 2024-12-03 10:58:35 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:35 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:35 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:35 --> Controller Class Initialized
INFO - 2024-12-03 10:58:35 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "Review_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "News_model" initialized
INFO - 2024-12-03 10:58:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 10:58:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 10:58:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 10:58:35 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:35 --> Total execution time: 0.0434
INFO - 2024-12-03 10:58:40 --> Config Class Initialized
INFO - 2024-12-03 10:58:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:40 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:40 --> URI Class Initialized
INFO - 2024-12-03 10:58:40 --> Router Class Initialized
INFO - 2024-12-03 10:58:40 --> Output Class Initialized
INFO - 2024-12-03 10:58:40 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:40 --> CSRF cookie sent
INFO - 2024-12-03 10:58:40 --> CSRF token verified
INFO - 2024-12-03 10:58:40 --> Input Class Initialized
INFO - 2024-12-03 10:58:40 --> Language Class Initialized
INFO - 2024-12-03 10:58:40 --> Loader Class Initialized
INFO - 2024-12-03 10:58:40 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:40 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:40 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:40 --> Controller Class Initialized
INFO - 2024-12-03 10:58:40 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:40 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:40 --> Model "Review_model" initialized
INFO - 2024-12-03 10:58:40 --> Model "News_model" initialized
INFO - 2024-12-03 10:58:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 10:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:40 --> Config Class Initialized
INFO - 2024-12-03 10:58:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:40 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:40 --> URI Class Initialized
INFO - 2024-12-03 10:58:40 --> Router Class Initialized
INFO - 2024-12-03 10:58:40 --> Output Class Initialized
INFO - 2024-12-03 10:58:40 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:40 --> CSRF cookie sent
INFO - 2024-12-03 10:58:40 --> Input Class Initialized
INFO - 2024-12-03 10:58:40 --> Language Class Initialized
INFO - 2024-12-03 10:58:40 --> Loader Class Initialized
INFO - 2024-12-03 10:58:40 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:40 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:40 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:40 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:40 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:40 --> Controller Class Initialized
INFO - 2024-12-03 10:58:40 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:40 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:40 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:58:40 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:40 --> Total execution time: 0.0594
INFO - 2024-12-03 10:58:43 --> Config Class Initialized
INFO - 2024-12-03 10:58:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:43 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:43 --> URI Class Initialized
INFO - 2024-12-03 10:58:43 --> Router Class Initialized
INFO - 2024-12-03 10:58:43 --> Output Class Initialized
INFO - 2024-12-03 10:58:43 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:43 --> CSRF cookie sent
INFO - 2024-12-03 10:58:43 --> Input Class Initialized
INFO - 2024-12-03 10:58:43 --> Language Class Initialized
INFO - 2024-12-03 10:58:43 --> Loader Class Initialized
INFO - 2024-12-03 10:58:43 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:43 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:43 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:43 --> Controller Class Initialized
INFO - 2024-12-03 10:58:43 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:43 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:58:43 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:43 --> Total execution time: 0.0426
INFO - 2024-12-03 10:58:45 --> Config Class Initialized
INFO - 2024-12-03 10:58:45 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:45 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:45 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:45 --> URI Class Initialized
INFO - 2024-12-03 10:58:45 --> Router Class Initialized
INFO - 2024-12-03 10:58:45 --> Output Class Initialized
INFO - 2024-12-03 10:58:45 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:45 --> CSRF cookie sent
INFO - 2024-12-03 10:58:45 --> Input Class Initialized
INFO - 2024-12-03 10:58:45 --> Language Class Initialized
INFO - 2024-12-03 10:58:45 --> Loader Class Initialized
INFO - 2024-12-03 10:58:45 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:45 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:45 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:45 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:45 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:45 --> Controller Class Initialized
INFO - 2024-12-03 10:58:45 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:45 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:45 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 10:58:45 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:45 --> Total execution time: 0.0417
INFO - 2024-12-03 10:58:48 --> Config Class Initialized
INFO - 2024-12-03 10:58:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:48 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:48 --> URI Class Initialized
INFO - 2024-12-03 10:58:48 --> Router Class Initialized
INFO - 2024-12-03 10:58:48 --> Output Class Initialized
INFO - 2024-12-03 10:58:48 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:48 --> CSRF cookie sent
INFO - 2024-12-03 10:58:48 --> Input Class Initialized
INFO - 2024-12-03 10:58:48 --> Language Class Initialized
INFO - 2024-12-03 10:58:48 --> Loader Class Initialized
INFO - 2024-12-03 10:58:48 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:48 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:48 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:48 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:48 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:48 --> Controller Class Initialized
INFO - 2024-12-03 10:58:48 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:48 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:48 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:58:48 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:48 --> Total execution time: 0.0435
INFO - 2024-12-03 10:58:50 --> Config Class Initialized
INFO - 2024-12-03 10:58:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:50 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:50 --> URI Class Initialized
INFO - 2024-12-03 10:58:50 --> Router Class Initialized
INFO - 2024-12-03 10:58:50 --> Output Class Initialized
INFO - 2024-12-03 10:58:50 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:50 --> CSRF cookie sent
INFO - 2024-12-03 10:58:50 --> Input Class Initialized
INFO - 2024-12-03 10:58:50 --> Language Class Initialized
INFO - 2024-12-03 10:58:50 --> Loader Class Initialized
INFO - 2024-12-03 10:58:50 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:50 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:50 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:50 --> Controller Class Initialized
INFO - 2024-12-03 10:58:50 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:50 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:50 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:50 --> Config Class Initialized
INFO - 2024-12-03 10:58:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:50 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:50 --> URI Class Initialized
INFO - 2024-12-03 10:58:50 --> Router Class Initialized
INFO - 2024-12-03 10:58:50 --> Output Class Initialized
INFO - 2024-12-03 10:58:50 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:50 --> CSRF cookie sent
INFO - 2024-12-03 10:58:50 --> Input Class Initialized
INFO - 2024-12-03 10:58:50 --> Language Class Initialized
ERROR - 2024-12-03 10:58:50 --> 404 Page Not Found: Admin/verifikasi_kuliner
INFO - 2024-12-03 10:58:53 --> Config Class Initialized
INFO - 2024-12-03 10:58:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:53 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:53 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:53 --> URI Class Initialized
INFO - 2024-12-03 10:58:53 --> Router Class Initialized
INFO - 2024-12-03 10:58:53 --> Output Class Initialized
INFO - 2024-12-03 10:58:53 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:53 --> CSRF cookie sent
INFO - 2024-12-03 10:58:53 --> Input Class Initialized
INFO - 2024-12-03 10:58:53 --> Language Class Initialized
INFO - 2024-12-03 10:58:53 --> Loader Class Initialized
INFO - 2024-12-03 10:58:53 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:53 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:53 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:53 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:53 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:53 --> Controller Class Initialized
INFO - 2024-12-03 10:58:53 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:53 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 10:58:53 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:53 --> Total execution time: 0.0382
INFO - 2024-12-03 10:58:56 --> Config Class Initialized
INFO - 2024-12-03 10:58:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:58:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:58:56 --> Utf8 Class Initialized
INFO - 2024-12-03 10:58:56 --> URI Class Initialized
INFO - 2024-12-03 10:58:56 --> Router Class Initialized
INFO - 2024-12-03 10:58:56 --> Output Class Initialized
INFO - 2024-12-03 10:58:56 --> Security Class Initialized
DEBUG - 2024-12-03 10:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:58:56 --> CSRF cookie sent
INFO - 2024-12-03 10:58:56 --> Input Class Initialized
INFO - 2024-12-03 10:58:56 --> Language Class Initialized
INFO - 2024-12-03 10:58:56 --> Loader Class Initialized
INFO - 2024-12-03 10:58:56 --> Helper loaded: url_helper
INFO - 2024-12-03 10:58:56 --> Helper loaded: form_helper
INFO - 2024-12-03 10:58:56 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:58:56 --> Form Validation Class Initialized
INFO - 2024-12-03 10:58:56 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:58:56 --> Controller Class Initialized
INFO - 2024-12-03 10:58:56 --> Model "Category_model" initialized
INFO - 2024-12-03 10:58:56 --> Model "User_model" initialized
INFO - 2024-12-03 10:58:56 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:58:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:58:56 --> Final output sent to browser
DEBUG - 2024-12-03 10:58:56 --> Total execution time: 0.0370
INFO - 2024-12-03 10:59:02 --> Config Class Initialized
INFO - 2024-12-03 10:59:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:02 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:02 --> URI Class Initialized
INFO - 2024-12-03 10:59:02 --> Router Class Initialized
INFO - 2024-12-03 10:59:02 --> Output Class Initialized
INFO - 2024-12-03 10:59:02 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:02 --> CSRF cookie sent
INFO - 2024-12-03 10:59:02 --> Input Class Initialized
INFO - 2024-12-03 10:59:02 --> Language Class Initialized
INFO - 2024-12-03 10:59:02 --> Loader Class Initialized
INFO - 2024-12-03 10:59:02 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:02 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:02 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:02 --> Controller Class Initialized
INFO - 2024-12-03 10:59:02 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:02 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:02 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-03 10:59:02 --> Final output sent to browser
DEBUG - 2024-12-03 10:59:02 --> Total execution time: 0.0563
INFO - 2024-12-03 10:59:17 --> Config Class Initialized
INFO - 2024-12-03 10:59:17 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:17 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:17 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:17 --> URI Class Initialized
INFO - 2024-12-03 10:59:17 --> Router Class Initialized
INFO - 2024-12-03 10:59:17 --> Output Class Initialized
INFO - 2024-12-03 10:59:17 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:17 --> CSRF cookie sent
INFO - 2024-12-03 10:59:17 --> CSRF token verified
INFO - 2024-12-03 10:59:17 --> Input Class Initialized
INFO - 2024-12-03 10:59:17 --> Language Class Initialized
INFO - 2024-12-03 10:59:17 --> Loader Class Initialized
INFO - 2024-12-03 10:59:17 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:17 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:17 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:17 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:17 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:17 --> Controller Class Initialized
INFO - 2024-12-03 10:59:17 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:17 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:17 --> Upload Class Initialized
INFO - 2024-12-03 10:59:17 --> Config Class Initialized
INFO - 2024-12-03 10:59:17 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:17 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:17 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:17 --> URI Class Initialized
INFO - 2024-12-03 10:59:17 --> Router Class Initialized
INFO - 2024-12-03 10:59:17 --> Output Class Initialized
INFO - 2024-12-03 10:59:17 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:17 --> CSRF cookie sent
INFO - 2024-12-03 10:59:17 --> Input Class Initialized
INFO - 2024-12-03 10:59:17 --> Language Class Initialized
INFO - 2024-12-03 10:59:17 --> Loader Class Initialized
INFO - 2024-12-03 10:59:17 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:17 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:17 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:17 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:17 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:17 --> Controller Class Initialized
INFO - 2024-12-03 10:59:17 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:17 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:59:17 --> Final output sent to browser
DEBUG - 2024-12-03 10:59:17 --> Total execution time: 0.0428
INFO - 2024-12-03 10:59:23 --> Config Class Initialized
INFO - 2024-12-03 10:59:23 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:23 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:23 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:23 --> URI Class Initialized
INFO - 2024-12-03 10:59:23 --> Router Class Initialized
INFO - 2024-12-03 10:59:23 --> Output Class Initialized
INFO - 2024-12-03 10:59:23 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:23 --> CSRF cookie sent
INFO - 2024-12-03 10:59:23 --> Input Class Initialized
INFO - 2024-12-03 10:59:23 --> Language Class Initialized
INFO - 2024-12-03 10:59:23 --> Loader Class Initialized
INFO - 2024-12-03 10:59:23 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:23 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:23 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:23 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:23 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:23 --> Controller Class Initialized
INFO - 2024-12-03 10:59:23 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:23 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:23 --> Config Class Initialized
INFO - 2024-12-03 10:59:23 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:23 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:23 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:23 --> URI Class Initialized
INFO - 2024-12-03 10:59:23 --> Router Class Initialized
INFO - 2024-12-03 10:59:23 --> Output Class Initialized
INFO - 2024-12-03 10:59:23 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:23 --> CSRF cookie sent
INFO - 2024-12-03 10:59:23 --> Input Class Initialized
INFO - 2024-12-03 10:59:23 --> Language Class Initialized
INFO - 2024-12-03 10:59:23 --> Loader Class Initialized
INFO - 2024-12-03 10:59:23 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:23 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:23 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:23 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:23 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:23 --> Controller Class Initialized
INFO - 2024-12-03 10:59:23 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:23 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:59:23 --> Final output sent to browser
DEBUG - 2024-12-03 10:59:23 --> Total execution time: 0.0650
INFO - 2024-12-03 10:59:29 --> Config Class Initialized
INFO - 2024-12-03 10:59:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:29 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:29 --> URI Class Initialized
INFO - 2024-12-03 10:59:29 --> Router Class Initialized
INFO - 2024-12-03 10:59:29 --> Output Class Initialized
INFO - 2024-12-03 10:59:29 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:29 --> CSRF cookie sent
INFO - 2024-12-03 10:59:29 --> Input Class Initialized
INFO - 2024-12-03 10:59:29 --> Language Class Initialized
INFO - 2024-12-03 10:59:29 --> Loader Class Initialized
INFO - 2024-12-03 10:59:29 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:29 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:29 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:29 --> Controller Class Initialized
INFO - 2024-12-03 10:59:29 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:29 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:29 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:29 --> Config Class Initialized
INFO - 2024-12-03 10:59:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:59:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:59:29 --> Utf8 Class Initialized
INFO - 2024-12-03 10:59:29 --> URI Class Initialized
INFO - 2024-12-03 10:59:29 --> Router Class Initialized
INFO - 2024-12-03 10:59:29 --> Output Class Initialized
INFO - 2024-12-03 10:59:29 --> Security Class Initialized
DEBUG - 2024-12-03 10:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:59:29 --> CSRF cookie sent
INFO - 2024-12-03 10:59:29 --> Input Class Initialized
INFO - 2024-12-03 10:59:29 --> Language Class Initialized
INFO - 2024-12-03 10:59:29 --> Loader Class Initialized
INFO - 2024-12-03 10:59:29 --> Helper loaded: url_helper
INFO - 2024-12-03 10:59:29 --> Helper loaded: form_helper
INFO - 2024-12-03 10:59:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 10:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:59:29 --> Form Validation Class Initialized
INFO - 2024-12-03 10:59:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 10:59:29 --> Controller Class Initialized
INFO - 2024-12-03 10:59:29 --> Model "Category_model" initialized
INFO - 2024-12-03 10:59:29 --> Model "User_model" initialized
INFO - 2024-12-03 10:59:29 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 10:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:59:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 10:59:29 --> Final output sent to browser
DEBUG - 2024-12-03 10:59:29 --> Total execution time: 0.0409
INFO - 2024-12-03 11:05:01 --> Config Class Initialized
INFO - 2024-12-03 11:05:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:05:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:05:01 --> Utf8 Class Initialized
INFO - 2024-12-03 11:05:01 --> URI Class Initialized
INFO - 2024-12-03 11:05:01 --> Router Class Initialized
INFO - 2024-12-03 11:05:01 --> Output Class Initialized
INFO - 2024-12-03 11:05:01 --> Security Class Initialized
DEBUG - 2024-12-03 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:05:01 --> CSRF cookie sent
INFO - 2024-12-03 11:05:01 --> Input Class Initialized
INFO - 2024-12-03 11:05:01 --> Language Class Initialized
INFO - 2024-12-03 11:05:01 --> Loader Class Initialized
INFO - 2024-12-03 11:05:01 --> Helper loaded: url_helper
INFO - 2024-12-03 11:05:01 --> Helper loaded: form_helper
INFO - 2024-12-03 11:05:01 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:05:01 --> Form Validation Class Initialized
INFO - 2024-12-03 11:05:01 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:05:01 --> Controller Class Initialized
INFO - 2024-12-03 11:05:01 --> Model "User_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "Category_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "Review_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "News_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:05:01 --> Config Class Initialized
INFO - 2024-12-03 11:05:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:05:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:05:01 --> Utf8 Class Initialized
INFO - 2024-12-03 11:05:01 --> URI Class Initialized
INFO - 2024-12-03 11:05:01 --> Router Class Initialized
INFO - 2024-12-03 11:05:01 --> Output Class Initialized
INFO - 2024-12-03 11:05:01 --> Security Class Initialized
DEBUG - 2024-12-03 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:05:01 --> CSRF cookie sent
INFO - 2024-12-03 11:05:01 --> Input Class Initialized
INFO - 2024-12-03 11:05:01 --> Language Class Initialized
INFO - 2024-12-03 11:05:01 --> Loader Class Initialized
INFO - 2024-12-03 11:05:01 --> Helper loaded: url_helper
INFO - 2024-12-03 11:05:01 --> Helper loaded: form_helper
INFO - 2024-12-03 11:05:01 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:05:01 --> Form Validation Class Initialized
INFO - 2024-12-03 11:05:01 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:05:01 --> Controller Class Initialized
INFO - 2024-12-03 11:05:01 --> Model "User_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "Category_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "Review_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "News_model" initialized
INFO - 2024-12-03 11:05:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:05:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:05:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:05:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 11:05:01 --> Final output sent to browser
DEBUG - 2024-12-03 11:05:01 --> Total execution time: 0.2299
INFO - 2024-12-03 11:05:06 --> Config Class Initialized
INFO - 2024-12-03 11:05:06 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:05:06 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:05:06 --> Utf8 Class Initialized
INFO - 2024-12-03 11:05:06 --> URI Class Initialized
INFO - 2024-12-03 11:05:06 --> Router Class Initialized
INFO - 2024-12-03 11:05:06 --> Output Class Initialized
INFO - 2024-12-03 11:05:06 --> Security Class Initialized
DEBUG - 2024-12-03 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:05:06 --> CSRF cookie sent
INFO - 2024-12-03 11:05:06 --> CSRF token verified
INFO - 2024-12-03 11:05:06 --> Input Class Initialized
INFO - 2024-12-03 11:05:06 --> Language Class Initialized
INFO - 2024-12-03 11:05:06 --> Loader Class Initialized
INFO - 2024-12-03 11:05:06 --> Helper loaded: url_helper
INFO - 2024-12-03 11:05:06 --> Helper loaded: form_helper
INFO - 2024-12-03 11:05:06 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:05:06 --> Form Validation Class Initialized
INFO - 2024-12-03 11:05:06 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:05:06 --> Controller Class Initialized
INFO - 2024-12-03 11:05:06 --> Model "User_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "Category_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "Review_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "News_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:05:06 --> Config Class Initialized
INFO - 2024-12-03 11:05:06 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:05:06 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:05:06 --> Utf8 Class Initialized
INFO - 2024-12-03 11:05:06 --> URI Class Initialized
INFO - 2024-12-03 11:05:06 --> Router Class Initialized
INFO - 2024-12-03 11:05:06 --> Output Class Initialized
INFO - 2024-12-03 11:05:06 --> Security Class Initialized
DEBUG - 2024-12-03 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:05:06 --> CSRF cookie sent
INFO - 2024-12-03 11:05:06 --> Input Class Initialized
INFO - 2024-12-03 11:05:06 --> Language Class Initialized
INFO - 2024-12-03 11:05:06 --> Loader Class Initialized
INFO - 2024-12-03 11:05:06 --> Helper loaded: url_helper
INFO - 2024-12-03 11:05:06 --> Helper loaded: form_helper
INFO - 2024-12-03 11:05:06 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:05:06 --> Form Validation Class Initialized
INFO - 2024-12-03 11:05:06 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:05:06 --> Controller Class Initialized
INFO - 2024-12-03 11:05:06 --> Model "User_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "Category_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "Review_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "News_model" initialized
INFO - 2024-12-03 11:05:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 11:05:06 --> Query result: stdClass Object
(
    [view_count] => 20
)

INFO - 2024-12-03 11:05:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:05:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:05:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 11:05:06 --> Final output sent to browser
DEBUG - 2024-12-03 11:05:06 --> Total execution time: 0.0997
INFO - 2024-12-03 11:05:06 --> Config Class Initialized
INFO - 2024-12-03 11:05:06 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:05:06 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:05:06 --> Utf8 Class Initialized
INFO - 2024-12-03 11:05:06 --> URI Class Initialized
INFO - 2024-12-03 11:05:06 --> Router Class Initialized
INFO - 2024-12-03 11:05:06 --> Output Class Initialized
INFO - 2024-12-03 11:05:06 --> Security Class Initialized
DEBUG - 2024-12-03 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:05:06 --> CSRF cookie sent
INFO - 2024-12-03 11:05:06 --> Input Class Initialized
INFO - 2024-12-03 11:05:06 --> Language Class Initialized
ERROR - 2024-12-03 11:05:06 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 11:05:17 --> Config Class Initialized
INFO - 2024-12-03 11:05:17 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:05:17 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:05:17 --> Utf8 Class Initialized
INFO - 2024-12-03 11:05:17 --> URI Class Initialized
INFO - 2024-12-03 11:05:17 --> Router Class Initialized
INFO - 2024-12-03 11:05:17 --> Output Class Initialized
INFO - 2024-12-03 11:05:17 --> Security Class Initialized
DEBUG - 2024-12-03 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:05:17 --> CSRF cookie sent
INFO - 2024-12-03 11:05:17 --> Input Class Initialized
INFO - 2024-12-03 11:05:17 --> Language Class Initialized
INFO - 2024-12-03 11:05:17 --> Loader Class Initialized
INFO - 2024-12-03 11:05:17 --> Helper loaded: url_helper
INFO - 2024-12-03 11:05:17 --> Helper loaded: form_helper
INFO - 2024-12-03 11:05:17 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:05:17 --> Form Validation Class Initialized
INFO - 2024-12-03 11:05:17 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:05:17 --> Controller Class Initialized
INFO - 2024-12-03 11:05:17 --> Model "User_model" initialized
INFO - 2024-12-03 11:05:17 --> Model "Category_model" initialized
INFO - 2024-12-03 11:05:17 --> Model "Review_model" initialized
INFO - 2024-12-03 11:05:17 --> Model "News_model" initialized
INFO - 2024-12-03 11:05:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:05:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:05:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:05:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 11:05:17 --> Final output sent to browser
DEBUG - 2024-12-03 11:05:17 --> Total execution time: 0.0794
INFO - 2024-12-03 11:06:02 --> Config Class Initialized
INFO - 2024-12-03 11:06:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:02 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:02 --> URI Class Initialized
INFO - 2024-12-03 11:06:02 --> Router Class Initialized
INFO - 2024-12-03 11:06:02 --> Output Class Initialized
INFO - 2024-12-03 11:06:02 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:02 --> CSRF cookie sent
INFO - 2024-12-03 11:06:02 --> CSRF token verified
INFO - 2024-12-03 11:06:02 --> Input Class Initialized
INFO - 2024-12-03 11:06:02 --> Language Class Initialized
INFO - 2024-12-03 11:06:02 --> Loader Class Initialized
INFO - 2024-12-03 11:06:02 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:02 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:02 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:02 --> Controller Class Initialized
INFO - 2024-12-03 11:06:02 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:02 --> Upload Class Initialized
INFO - 2024-12-03 11:06:02 --> Config Class Initialized
INFO - 2024-12-03 11:06:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:02 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:02 --> URI Class Initialized
INFO - 2024-12-03 11:06:02 --> Router Class Initialized
INFO - 2024-12-03 11:06:02 --> Output Class Initialized
INFO - 2024-12-03 11:06:02 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:02 --> CSRF cookie sent
INFO - 2024-12-03 11:06:02 --> Input Class Initialized
INFO - 2024-12-03 11:06:02 --> Language Class Initialized
INFO - 2024-12-03 11:06:02 --> Loader Class Initialized
INFO - 2024-12-03 11:06:02 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:02 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:02 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:02 --> Controller Class Initialized
INFO - 2024-12-03 11:06:02 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 11:06:02 --> Query result: stdClass Object
(
    [view_count] => 21
)

INFO - 2024-12-03 11:06:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 11:06:02 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:02 --> Total execution time: 0.1104
INFO - 2024-12-03 11:06:02 --> Config Class Initialized
INFO - 2024-12-03 11:06:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:02 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:02 --> URI Class Initialized
INFO - 2024-12-03 11:06:02 --> Router Class Initialized
INFO - 2024-12-03 11:06:02 --> Output Class Initialized
INFO - 2024-12-03 11:06:02 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:02 --> CSRF cookie sent
INFO - 2024-12-03 11:06:02 --> Input Class Initialized
INFO - 2024-12-03 11:06:02 --> Language Class Initialized
ERROR - 2024-12-03 11:06:02 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-03 11:06:05 --> Config Class Initialized
INFO - 2024-12-03 11:06:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:05 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:05 --> URI Class Initialized
INFO - 2024-12-03 11:06:05 --> Router Class Initialized
INFO - 2024-12-03 11:06:05 --> Output Class Initialized
INFO - 2024-12-03 11:06:05 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:05 --> CSRF cookie sent
INFO - 2024-12-03 11:06:05 --> Input Class Initialized
INFO - 2024-12-03 11:06:05 --> Language Class Initialized
INFO - 2024-12-03 11:06:05 --> Loader Class Initialized
INFO - 2024-12-03 11:06:05 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:05 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:05 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:05 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:05 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:05 --> Controller Class Initialized
INFO - 2024-12-03 11:06:05 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:05 --> Config Class Initialized
INFO - 2024-12-03 11:06:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:05 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:05 --> URI Class Initialized
INFO - 2024-12-03 11:06:05 --> Router Class Initialized
INFO - 2024-12-03 11:06:05 --> Output Class Initialized
INFO - 2024-12-03 11:06:05 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:05 --> CSRF cookie sent
INFO - 2024-12-03 11:06:05 --> Input Class Initialized
INFO - 2024-12-03 11:06:05 --> Language Class Initialized
INFO - 2024-12-03 11:06:05 --> Loader Class Initialized
INFO - 2024-12-03 11:06:05 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:05 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:05 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:05 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:05 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:05 --> Controller Class Initialized
INFO - 2024-12-03 11:06:05 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 11:06:05 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:05 --> Total execution time: 0.0574
INFO - 2024-12-03 11:06:08 --> Config Class Initialized
INFO - 2024-12-03 11:06:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:08 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:08 --> URI Class Initialized
INFO - 2024-12-03 11:06:08 --> Router Class Initialized
INFO - 2024-12-03 11:06:08 --> Output Class Initialized
INFO - 2024-12-03 11:06:08 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:08 --> CSRF cookie sent
INFO - 2024-12-03 11:06:08 --> CSRF token verified
INFO - 2024-12-03 11:06:08 --> Input Class Initialized
INFO - 2024-12-03 11:06:08 --> Language Class Initialized
INFO - 2024-12-03 11:06:08 --> Loader Class Initialized
INFO - 2024-12-03 11:06:08 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:08 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:08 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:08 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:08 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:08 --> Controller Class Initialized
INFO - 2024-12-03 11:06:08 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:08 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:08 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:08 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:08 --> Config Class Initialized
INFO - 2024-12-03 11:06:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:08 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:08 --> URI Class Initialized
INFO - 2024-12-03 11:06:08 --> Router Class Initialized
INFO - 2024-12-03 11:06:08 --> Output Class Initialized
INFO - 2024-12-03 11:06:08 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:08 --> CSRF cookie sent
INFO - 2024-12-03 11:06:08 --> Input Class Initialized
INFO - 2024-12-03 11:06:08 --> Language Class Initialized
INFO - 2024-12-03 11:06:08 --> Loader Class Initialized
INFO - 2024-12-03 11:06:08 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:08 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:08 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:08 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:08 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:08 --> Controller Class Initialized
INFO - 2024-12-03 11:06:08 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:08 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 11:06:08 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:08 --> Total execution time: 0.0827
INFO - 2024-12-03 11:06:13 --> Config Class Initialized
INFO - 2024-12-03 11:06:13 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:13 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:13 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:13 --> URI Class Initialized
INFO - 2024-12-03 11:06:13 --> Router Class Initialized
INFO - 2024-12-03 11:06:13 --> Output Class Initialized
INFO - 2024-12-03 11:06:13 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:13 --> CSRF cookie sent
INFO - 2024-12-03 11:06:13 --> Input Class Initialized
INFO - 2024-12-03 11:06:13 --> Language Class Initialized
INFO - 2024-12-03 11:06:13 --> Loader Class Initialized
INFO - 2024-12-03 11:06:13 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:13 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:13 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:13 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:13 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:13 --> Controller Class Initialized
INFO - 2024-12-03 11:06:13 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:13 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:13 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 11:06:13 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:13 --> Total execution time: 0.0431
INFO - 2024-12-03 11:06:29 --> Config Class Initialized
INFO - 2024-12-03 11:06:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:29 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:29 --> URI Class Initialized
INFO - 2024-12-03 11:06:29 --> Router Class Initialized
INFO - 2024-12-03 11:06:29 --> Output Class Initialized
INFO - 2024-12-03 11:06:29 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:29 --> CSRF cookie sent
INFO - 2024-12-03 11:06:29 --> Input Class Initialized
INFO - 2024-12-03 11:06:29 --> Language Class Initialized
INFO - 2024-12-03 11:06:29 --> Loader Class Initialized
INFO - 2024-12-03 11:06:29 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:29 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:29 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:29 --> Controller Class Initialized
INFO - 2024-12-03 11:06:29 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:29 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:29 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:29 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:30 --> Config Class Initialized
INFO - 2024-12-03 11:06:30 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:30 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:30 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:30 --> URI Class Initialized
INFO - 2024-12-03 11:06:30 --> Router Class Initialized
INFO - 2024-12-03 11:06:30 --> Output Class Initialized
INFO - 2024-12-03 11:06:30 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:30 --> CSRF cookie sent
INFO - 2024-12-03 11:06:30 --> Input Class Initialized
INFO - 2024-12-03 11:06:30 --> Language Class Initialized
INFO - 2024-12-03 11:06:30 --> Loader Class Initialized
INFO - 2024-12-03 11:06:30 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:30 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:30 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:30 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:30 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:30 --> Controller Class Initialized
INFO - 2024-12-03 11:06:30 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:30 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:30 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:30 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 11:06:30 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:30 --> Total execution time: 0.0424
INFO - 2024-12-03 11:06:33 --> Config Class Initialized
INFO - 2024-12-03 11:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:33 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:33 --> URI Class Initialized
INFO - 2024-12-03 11:06:33 --> Router Class Initialized
INFO - 2024-12-03 11:06:33 --> Output Class Initialized
INFO - 2024-12-03 11:06:33 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:33 --> CSRF cookie sent
INFO - 2024-12-03 11:06:33 --> CSRF token verified
INFO - 2024-12-03 11:06:33 --> Input Class Initialized
INFO - 2024-12-03 11:06:33 --> Language Class Initialized
INFO - 2024-12-03 11:06:33 --> Loader Class Initialized
INFO - 2024-12-03 11:06:33 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:33 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:33 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:33 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:33 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:33 --> Controller Class Initialized
INFO - 2024-12-03 11:06:33 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:33 --> Config Class Initialized
INFO - 2024-12-03 11:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:33 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:33 --> URI Class Initialized
INFO - 2024-12-03 11:06:33 --> Router Class Initialized
INFO - 2024-12-03 11:06:33 --> Output Class Initialized
INFO - 2024-12-03 11:06:33 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:33 --> CSRF cookie sent
INFO - 2024-12-03 11:06:33 --> Input Class Initialized
INFO - 2024-12-03 11:06:33 --> Language Class Initialized
INFO - 2024-12-03 11:06:33 --> Loader Class Initialized
INFO - 2024-12-03 11:06:33 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:33 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:33 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:33 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:33 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:33 --> Controller Class Initialized
INFO - 2024-12-03 11:06:33 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 11:06:33 --> Query result: stdClass Object
(
    [view_count] => 22
)

INFO - 2024-12-03 11:06:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 11:06:33 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:33 --> Total execution time: 0.0735
INFO - 2024-12-03 11:06:36 --> Config Class Initialized
INFO - 2024-12-03 11:06:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:36 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:36 --> URI Class Initialized
INFO - 2024-12-03 11:06:36 --> Router Class Initialized
INFO - 2024-12-03 11:06:36 --> Output Class Initialized
INFO - 2024-12-03 11:06:36 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:36 --> CSRF cookie sent
INFO - 2024-12-03 11:06:36 --> Input Class Initialized
INFO - 2024-12-03 11:06:36 --> Language Class Initialized
ERROR - 2024-12-03 11:06:36 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 11:06:44 --> Config Class Initialized
INFO - 2024-12-03 11:06:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:44 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:44 --> URI Class Initialized
INFO - 2024-12-03 11:06:44 --> Router Class Initialized
INFO - 2024-12-03 11:06:44 --> Output Class Initialized
INFO - 2024-12-03 11:06:44 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:44 --> CSRF cookie sent
INFO - 2024-12-03 11:06:44 --> Input Class Initialized
INFO - 2024-12-03 11:06:44 --> Language Class Initialized
INFO - 2024-12-03 11:06:44 --> Loader Class Initialized
INFO - 2024-12-03 11:06:44 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:44 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:44 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:44 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:44 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:44 --> Controller Class Initialized
INFO - 2024-12-03 11:06:44 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:44 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:44 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:44 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-03 11:06:44 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:44 --> Total execution time: 0.0890
INFO - 2024-12-03 11:06:51 --> Config Class Initialized
INFO - 2024-12-03 11:06:51 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:51 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:51 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:51 --> URI Class Initialized
INFO - 2024-12-03 11:06:51 --> Router Class Initialized
INFO - 2024-12-03 11:06:51 --> Output Class Initialized
INFO - 2024-12-03 11:06:51 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:51 --> CSRF cookie sent
INFO - 2024-12-03 11:06:51 --> Input Class Initialized
INFO - 2024-12-03 11:06:51 --> Language Class Initialized
INFO - 2024-12-03 11:06:51 --> Loader Class Initialized
INFO - 2024-12-03 11:06:51 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:51 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:51 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:51 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:51 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:51 --> Controller Class Initialized
INFO - 2024-12-03 11:06:51 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:51 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:51 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:51 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 11:06:51 --> Query result: stdClass Object
(
    [view_count] => 23
)

INFO - 2024-12-03 11:06:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 11:06:51 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:51 --> Total execution time: 0.0613
INFO - 2024-12-03 11:06:51 --> Config Class Initialized
INFO - 2024-12-03 11:06:51 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:51 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:51 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:51 --> URI Class Initialized
INFO - 2024-12-03 11:06:51 --> Router Class Initialized
INFO - 2024-12-03 11:06:51 --> Output Class Initialized
INFO - 2024-12-03 11:06:51 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:51 --> CSRF cookie sent
INFO - 2024-12-03 11:06:51 --> Input Class Initialized
INFO - 2024-12-03 11:06:51 --> Language Class Initialized
ERROR - 2024-12-03 11:06:51 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 11:06:58 --> Config Class Initialized
INFO - 2024-12-03 11:06:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:06:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:06:58 --> Utf8 Class Initialized
INFO - 2024-12-03 11:06:58 --> URI Class Initialized
INFO - 2024-12-03 11:06:58 --> Router Class Initialized
INFO - 2024-12-03 11:06:58 --> Output Class Initialized
INFO - 2024-12-03 11:06:58 --> Security Class Initialized
DEBUG - 2024-12-03 11:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:06:58 --> CSRF cookie sent
INFO - 2024-12-03 11:06:58 --> Input Class Initialized
INFO - 2024-12-03 11:06:58 --> Language Class Initialized
INFO - 2024-12-03 11:06:58 --> Loader Class Initialized
INFO - 2024-12-03 11:06:58 --> Helper loaded: url_helper
INFO - 2024-12-03 11:06:58 --> Helper loaded: form_helper
INFO - 2024-12-03 11:06:58 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:06:58 --> Form Validation Class Initialized
INFO - 2024-12-03 11:06:58 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:06:58 --> Controller Class Initialized
INFO - 2024-12-03 11:06:58 --> Model "User_model" initialized
INFO - 2024-12-03 11:06:58 --> Model "Category_model" initialized
INFO - 2024-12-03 11:06:58 --> Model "Review_model" initialized
INFO - 2024-12-03 11:06:58 --> Model "News_model" initialized
INFO - 2024-12-03 11:06:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:06:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:06:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:06:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-03 11:06:58 --> Final output sent to browser
DEBUG - 2024-12-03 11:06:58 --> Total execution time: 0.0686
INFO - 2024-12-03 11:07:21 --> Config Class Initialized
INFO - 2024-12-03 11:07:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:07:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:07:21 --> Utf8 Class Initialized
INFO - 2024-12-03 11:07:21 --> URI Class Initialized
INFO - 2024-12-03 11:07:21 --> Router Class Initialized
INFO - 2024-12-03 11:07:21 --> Output Class Initialized
INFO - 2024-12-03 11:07:21 --> Security Class Initialized
DEBUG - 2024-12-03 11:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:07:21 --> CSRF cookie sent
INFO - 2024-12-03 11:07:21 --> Input Class Initialized
INFO - 2024-12-03 11:07:21 --> Language Class Initialized
INFO - 2024-12-03 11:07:21 --> Loader Class Initialized
INFO - 2024-12-03 11:07:21 --> Helper loaded: url_helper
INFO - 2024-12-03 11:07:21 --> Helper loaded: form_helper
INFO - 2024-12-03 11:07:21 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:07:21 --> Form Validation Class Initialized
INFO - 2024-12-03 11:07:21 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:07:21 --> Controller Class Initialized
INFO - 2024-12-03 11:07:21 --> Model "Category_model" initialized
INFO - 2024-12-03 11:07:21 --> Model "User_model" initialized
INFO - 2024-12-03 11:07:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:07:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 11:07:21 --> Final output sent to browser
DEBUG - 2024-12-03 11:07:21 --> Total execution time: 0.0819
INFO - 2024-12-03 11:07:24 --> Config Class Initialized
INFO - 2024-12-03 11:07:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:07:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:07:24 --> Utf8 Class Initialized
INFO - 2024-12-03 11:07:24 --> URI Class Initialized
INFO - 2024-12-03 11:07:24 --> Router Class Initialized
INFO - 2024-12-03 11:07:24 --> Output Class Initialized
INFO - 2024-12-03 11:07:24 --> Security Class Initialized
DEBUG - 2024-12-03 11:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:07:24 --> CSRF cookie sent
INFO - 2024-12-03 11:07:24 --> Input Class Initialized
INFO - 2024-12-03 11:07:24 --> Language Class Initialized
INFO - 2024-12-03 11:07:24 --> Loader Class Initialized
INFO - 2024-12-03 11:07:24 --> Helper loaded: url_helper
INFO - 2024-12-03 11:07:24 --> Helper loaded: form_helper
INFO - 2024-12-03 11:07:24 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:07:24 --> Form Validation Class Initialized
INFO - 2024-12-03 11:07:24 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:07:24 --> Controller Class Initialized
INFO - 2024-12-03 11:07:24 --> Model "Category_model" initialized
INFO - 2024-12-03 11:07:24 --> Model "User_model" initialized
INFO - 2024-12-03 11:07:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:07:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 11:07:24 --> Final output sent to browser
DEBUG - 2024-12-03 11:07:24 --> Total execution time: 0.0712
INFO - 2024-12-03 11:09:15 --> Config Class Initialized
INFO - 2024-12-03 11:09:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:09:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:09:15 --> Utf8 Class Initialized
INFO - 2024-12-03 11:09:15 --> URI Class Initialized
INFO - 2024-12-03 11:09:15 --> Router Class Initialized
INFO - 2024-12-03 11:09:15 --> Output Class Initialized
INFO - 2024-12-03 11:09:15 --> Security Class Initialized
DEBUG - 2024-12-03 11:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:09:15 --> CSRF cookie sent
INFO - 2024-12-03 11:09:15 --> Input Class Initialized
INFO - 2024-12-03 11:09:15 --> Language Class Initialized
INFO - 2024-12-03 11:09:15 --> Loader Class Initialized
INFO - 2024-12-03 11:09:15 --> Helper loaded: url_helper
INFO - 2024-12-03 11:09:15 --> Helper loaded: form_helper
INFO - 2024-12-03 11:09:15 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:09:15 --> Form Validation Class Initialized
INFO - 2024-12-03 11:09:15 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:09:15 --> Controller Class Initialized
INFO - 2024-12-03 11:09:15 --> Model "Category_model" initialized
INFO - 2024-12-03 11:09:15 --> Model "User_model" initialized
INFO - 2024-12-03 11:09:15 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:09:16 --> Config Class Initialized
INFO - 2024-12-03 11:09:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:09:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:09:16 --> Utf8 Class Initialized
INFO - 2024-12-03 11:09:16 --> URI Class Initialized
INFO - 2024-12-03 11:09:16 --> Router Class Initialized
INFO - 2024-12-03 11:09:16 --> Output Class Initialized
INFO - 2024-12-03 11:09:16 --> Security Class Initialized
DEBUG - 2024-12-03 11:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:09:16 --> CSRF cookie sent
INFO - 2024-12-03 11:09:16 --> Input Class Initialized
INFO - 2024-12-03 11:09:16 --> Language Class Initialized
ERROR - 2024-12-03 11:09:16 --> 404 Page Not Found: Admin/verifikasi_kuliner
INFO - 2024-12-03 11:15:05 --> Config Class Initialized
INFO - 2024-12-03 11:15:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:15:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:15:05 --> Utf8 Class Initialized
INFO - 2024-12-03 11:15:05 --> URI Class Initialized
INFO - 2024-12-03 11:15:05 --> Router Class Initialized
INFO - 2024-12-03 11:15:05 --> Output Class Initialized
INFO - 2024-12-03 11:15:05 --> Security Class Initialized
DEBUG - 2024-12-03 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:15:05 --> CSRF cookie sent
INFO - 2024-12-03 11:15:05 --> Input Class Initialized
INFO - 2024-12-03 11:15:05 --> Language Class Initialized
INFO - 2024-12-03 11:15:05 --> Loader Class Initialized
INFO - 2024-12-03 11:15:05 --> Helper loaded: url_helper
INFO - 2024-12-03 11:15:05 --> Helper loaded: form_helper
INFO - 2024-12-03 11:15:05 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:15:05 --> Form Validation Class Initialized
INFO - 2024-12-03 11:15:05 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:15:05 --> Controller Class Initialized
INFO - 2024-12-03 11:15:05 --> Model "Category_model" initialized
INFO - 2024-12-03 11:15:05 --> Model "User_model" initialized
INFO - 2024-12-03 11:15:05 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:15:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 11:15:05 --> Final output sent to browser
DEBUG - 2024-12-03 11:15:05 --> Total execution time: 0.3215
INFO - 2024-12-03 11:15:09 --> Config Class Initialized
INFO - 2024-12-03 11:15:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:15:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:15:09 --> Utf8 Class Initialized
INFO - 2024-12-03 11:15:09 --> URI Class Initialized
INFO - 2024-12-03 11:15:09 --> Router Class Initialized
INFO - 2024-12-03 11:15:09 --> Output Class Initialized
INFO - 2024-12-03 11:15:09 --> Security Class Initialized
DEBUG - 2024-12-03 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:15:09 --> CSRF cookie sent
INFO - 2024-12-03 11:15:09 --> Input Class Initialized
INFO - 2024-12-03 11:15:09 --> Language Class Initialized
INFO - 2024-12-03 11:15:09 --> Loader Class Initialized
INFO - 2024-12-03 11:15:09 --> Helper loaded: url_helper
INFO - 2024-12-03 11:15:09 --> Helper loaded: form_helper
INFO - 2024-12-03 11:15:09 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:15:09 --> Form Validation Class Initialized
INFO - 2024-12-03 11:15:09 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:15:09 --> Controller Class Initialized
INFO - 2024-12-03 11:15:09 --> Model "Category_model" initialized
INFO - 2024-12-03 11:15:09 --> Model "User_model" initialized
INFO - 2024-12-03 11:15:10 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:15:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 11:15:10 --> Final output sent to browser
DEBUG - 2024-12-03 11:15:10 --> Total execution time: 0.0706
INFO - 2024-12-03 11:15:26 --> Config Class Initialized
INFO - 2024-12-03 11:15:26 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:15:26 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:15:26 --> Utf8 Class Initialized
INFO - 2024-12-03 11:15:26 --> URI Class Initialized
INFO - 2024-12-03 11:15:26 --> Router Class Initialized
INFO - 2024-12-03 11:15:26 --> Output Class Initialized
INFO - 2024-12-03 11:15:27 --> Security Class Initialized
DEBUG - 2024-12-03 11:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:15:27 --> CSRF cookie sent
INFO - 2024-12-03 11:15:27 --> Input Class Initialized
INFO - 2024-12-03 11:15:27 --> Language Class Initialized
INFO - 2024-12-03 11:15:27 --> Loader Class Initialized
INFO - 2024-12-03 11:15:27 --> Helper loaded: url_helper
INFO - 2024-12-03 11:15:27 --> Helper loaded: form_helper
INFO - 2024-12-03 11:15:27 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:15:27 --> Form Validation Class Initialized
INFO - 2024-12-03 11:15:27 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:15:27 --> Controller Class Initialized
INFO - 2024-12-03 11:15:27 --> Model "Category_model" initialized
INFO - 2024-12-03 11:15:27 --> Model "User_model" initialized
INFO - 2024-12-03 11:15:27 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:15:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 11:15:27 --> Final output sent to browser
DEBUG - 2024-12-03 11:15:27 --> Total execution time: 0.1498
INFO - 2024-12-03 11:22:43 --> Config Class Initialized
INFO - 2024-12-03 11:22:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:22:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:22:43 --> Utf8 Class Initialized
INFO - 2024-12-03 11:22:43 --> URI Class Initialized
INFO - 2024-12-03 11:22:43 --> Router Class Initialized
INFO - 2024-12-03 11:22:43 --> Output Class Initialized
INFO - 2024-12-03 11:22:43 --> Security Class Initialized
DEBUG - 2024-12-03 11:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:22:43 --> CSRF cookie sent
INFO - 2024-12-03 11:22:43 --> Input Class Initialized
INFO - 2024-12-03 11:22:43 --> Language Class Initialized
INFO - 2024-12-03 11:22:43 --> Loader Class Initialized
INFO - 2024-12-03 11:22:43 --> Helper loaded: url_helper
INFO - 2024-12-03 11:22:43 --> Helper loaded: form_helper
INFO - 2024-12-03 11:22:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:22:43 --> Form Validation Class Initialized
INFO - 2024-12-03 11:22:43 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:22:43 --> Controller Class Initialized
INFO - 2024-12-03 11:22:43 --> Model "User_model" initialized
INFO - 2024-12-03 11:22:43 --> Model "Category_model" initialized
INFO - 2024-12-03 11:22:43 --> Model "Review_model" initialized
INFO - 2024-12-03 11:22:43 --> Model "News_model" initialized
INFO - 2024-12-03 11:22:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:22:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:22:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:22:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-03 11:22:43 --> Final output sent to browser
DEBUG - 2024-12-03 11:22:43 --> Total execution time: 0.4774
INFO - 2024-12-03 11:22:47 --> Config Class Initialized
INFO - 2024-12-03 11:22:47 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:22:47 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:22:47 --> Utf8 Class Initialized
INFO - 2024-12-03 11:22:47 --> URI Class Initialized
INFO - 2024-12-03 11:22:47 --> Router Class Initialized
INFO - 2024-12-03 11:22:47 --> Output Class Initialized
INFO - 2024-12-03 11:22:47 --> Security Class Initialized
DEBUG - 2024-12-03 11:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:22:47 --> CSRF cookie sent
INFO - 2024-12-03 11:22:47 --> Input Class Initialized
INFO - 2024-12-03 11:22:47 --> Language Class Initialized
INFO - 2024-12-03 11:22:47 --> Loader Class Initialized
INFO - 2024-12-03 11:22:47 --> Helper loaded: url_helper
INFO - 2024-12-03 11:22:47 --> Helper loaded: form_helper
INFO - 2024-12-03 11:22:47 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:22:47 --> Form Validation Class Initialized
INFO - 2024-12-03 11:22:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:22:47 --> Controller Class Initialized
INFO - 2024-12-03 11:22:47 --> Model "User_model" initialized
INFO - 2024-12-03 11:22:47 --> Model "Category_model" initialized
INFO - 2024-12-03 11:22:47 --> Model "Review_model" initialized
INFO - 2024-12-03 11:22:47 --> Model "News_model" initialized
INFO - 2024-12-03 11:22:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:22:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:22:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:22:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 11:22:47 --> Final output sent to browser
DEBUG - 2024-12-03 11:22:47 --> Total execution time: 0.0736
INFO - 2024-12-03 11:23:12 --> Config Class Initialized
INFO - 2024-12-03 11:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:12 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:12 --> URI Class Initialized
INFO - 2024-12-03 11:23:12 --> Router Class Initialized
INFO - 2024-12-03 11:23:12 --> Output Class Initialized
INFO - 2024-12-03 11:23:12 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:12 --> CSRF cookie sent
INFO - 2024-12-03 11:23:12 --> CSRF token verified
INFO - 2024-12-03 11:23:12 --> Input Class Initialized
INFO - 2024-12-03 11:23:12 --> Language Class Initialized
INFO - 2024-12-03 11:23:12 --> Loader Class Initialized
INFO - 2024-12-03 11:23:12 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:12 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:12 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:12 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:12 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:12 --> Controller Class Initialized
INFO - 2024-12-03 11:23:12 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "Review_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "News_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:12 --> Upload Class Initialized
INFO - 2024-12-03 11:23:12 --> Config Class Initialized
INFO - 2024-12-03 11:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:12 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:12 --> URI Class Initialized
INFO - 2024-12-03 11:23:12 --> Router Class Initialized
INFO - 2024-12-03 11:23:12 --> Output Class Initialized
INFO - 2024-12-03 11:23:12 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:12 --> CSRF cookie sent
INFO - 2024-12-03 11:23:12 --> Input Class Initialized
INFO - 2024-12-03 11:23:12 --> Language Class Initialized
INFO - 2024-12-03 11:23:12 --> Loader Class Initialized
INFO - 2024-12-03 11:23:12 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:12 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:12 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:12 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:12 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:12 --> Controller Class Initialized
INFO - 2024-12-03 11:23:12 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "Review_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "News_model" initialized
INFO - 2024-12-03 11:23:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:23:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 11:23:12 --> Query result: stdClass Object
(
    [view_count] => 24
)

INFO - 2024-12-03 11:23:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:23:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:23:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 11:23:12 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:12 --> Total execution time: 0.1257
INFO - 2024-12-03 11:23:18 --> Config Class Initialized
INFO - 2024-12-03 11:23:18 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:18 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:18 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:18 --> URI Class Initialized
INFO - 2024-12-03 11:23:18 --> Router Class Initialized
INFO - 2024-12-03 11:23:18 --> Output Class Initialized
INFO - 2024-12-03 11:23:18 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:18 --> CSRF cookie sent
INFO - 2024-12-03 11:23:18 --> Input Class Initialized
INFO - 2024-12-03 11:23:18 --> Language Class Initialized
INFO - 2024-12-03 11:23:18 --> Loader Class Initialized
INFO - 2024-12-03 11:23:18 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:18 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:18 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:18 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:18 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:18 --> Controller Class Initialized
INFO - 2024-12-03 11:23:18 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:18 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:18 --> Model "Review_model" initialized
INFO - 2024-12-03 11:23:18 --> Model "News_model" initialized
INFO - 2024-12-03 11:23:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:23:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:23:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-03 11:23:18 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:18 --> Total execution time: 0.0738
INFO - 2024-12-03 11:23:20 --> Config Class Initialized
INFO - 2024-12-03 11:23:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:20 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:20 --> URI Class Initialized
INFO - 2024-12-03 11:23:20 --> Router Class Initialized
INFO - 2024-12-03 11:23:20 --> Output Class Initialized
INFO - 2024-12-03 11:23:20 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:20 --> CSRF cookie sent
INFO - 2024-12-03 11:23:20 --> Input Class Initialized
INFO - 2024-12-03 11:23:20 --> Language Class Initialized
ERROR - 2024-12-03 11:23:20 --> 404 Page Not Found: Culinary/path-to-your-image.jpg
INFO - 2024-12-03 11:23:20 --> Config Class Initialized
INFO - 2024-12-03 11:23:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:20 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:20 --> URI Class Initialized
INFO - 2024-12-03 11:23:20 --> Router Class Initialized
INFO - 2024-12-03 11:23:20 --> Output Class Initialized
INFO - 2024-12-03 11:23:20 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:20 --> CSRF cookie sent
INFO - 2024-12-03 11:23:20 --> Input Class Initialized
INFO - 2024-12-03 11:23:20 --> Language Class Initialized
INFO - 2024-12-03 11:23:20 --> Loader Class Initialized
INFO - 2024-12-03 11:23:20 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:20 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:20 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:20 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:20 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:20 --> Controller Class Initialized
INFO - 2024-12-03 11:23:20 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "Review_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "News_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:20 --> Config Class Initialized
INFO - 2024-12-03 11:23:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:20 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:20 --> URI Class Initialized
INFO - 2024-12-03 11:23:20 --> Router Class Initialized
INFO - 2024-12-03 11:23:20 --> Output Class Initialized
INFO - 2024-12-03 11:23:20 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:20 --> CSRF cookie sent
INFO - 2024-12-03 11:23:20 --> Input Class Initialized
INFO - 2024-12-03 11:23:20 --> Language Class Initialized
INFO - 2024-12-03 11:23:20 --> Loader Class Initialized
INFO - 2024-12-03 11:23:20 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:20 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:20 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:20 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:20 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:20 --> Controller Class Initialized
INFO - 2024-12-03 11:23:20 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "Review_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "News_model" initialized
INFO - 2024-12-03 11:23:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 11:23:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 11:23:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 11:23:20 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:20 --> Total execution time: 0.0477
INFO - 2024-12-03 11:23:24 --> Config Class Initialized
INFO - 2024-12-03 11:23:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:24 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:24 --> URI Class Initialized
INFO - 2024-12-03 11:23:24 --> Router Class Initialized
INFO - 2024-12-03 11:23:24 --> Output Class Initialized
INFO - 2024-12-03 11:23:24 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:24 --> CSRF cookie sent
INFO - 2024-12-03 11:23:24 --> CSRF token verified
INFO - 2024-12-03 11:23:24 --> Input Class Initialized
INFO - 2024-12-03 11:23:24 --> Language Class Initialized
INFO - 2024-12-03 11:23:24 --> Loader Class Initialized
INFO - 2024-12-03 11:23:24 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:24 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:24 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:24 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:24 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:24 --> Controller Class Initialized
INFO - 2024-12-03 11:23:24 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:24 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:24 --> Model "Review_model" initialized
INFO - 2024-12-03 11:23:24 --> Model "News_model" initialized
INFO - 2024-12-03 11:23:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 11:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:24 --> Config Class Initialized
INFO - 2024-12-03 11:23:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:24 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:24 --> URI Class Initialized
INFO - 2024-12-03 11:23:24 --> Router Class Initialized
INFO - 2024-12-03 11:23:24 --> Output Class Initialized
INFO - 2024-12-03 11:23:24 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:24 --> CSRF cookie sent
INFO - 2024-12-03 11:23:24 --> Input Class Initialized
INFO - 2024-12-03 11:23:24 --> Language Class Initialized
INFO - 2024-12-03 11:23:24 --> Loader Class Initialized
INFO - 2024-12-03 11:23:24 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:24 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:24 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:24 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:24 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:24 --> Controller Class Initialized
INFO - 2024-12-03 11:23:24 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:24 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 11:23:24 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:24 --> Total execution time: 0.0561
INFO - 2024-12-03 11:23:28 --> Config Class Initialized
INFO - 2024-12-03 11:23:28 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:28 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:28 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:28 --> URI Class Initialized
INFO - 2024-12-03 11:23:28 --> Router Class Initialized
INFO - 2024-12-03 11:23:28 --> Output Class Initialized
INFO - 2024-12-03 11:23:28 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:28 --> CSRF cookie sent
INFO - 2024-12-03 11:23:28 --> Input Class Initialized
INFO - 2024-12-03 11:23:28 --> Language Class Initialized
INFO - 2024-12-03 11:23:28 --> Loader Class Initialized
INFO - 2024-12-03 11:23:28 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:28 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:28 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:28 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:28 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:28 --> Controller Class Initialized
INFO - 2024-12-03 11:23:28 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:28 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 11:23:29 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:29 --> Total execution time: 0.0576
INFO - 2024-12-03 11:23:34 --> Config Class Initialized
INFO - 2024-12-03 11:23:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:34 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:34 --> URI Class Initialized
INFO - 2024-12-03 11:23:34 --> Router Class Initialized
INFO - 2024-12-03 11:23:34 --> Output Class Initialized
INFO - 2024-12-03 11:23:34 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:34 --> CSRF cookie sent
INFO - 2024-12-03 11:23:34 --> Input Class Initialized
INFO - 2024-12-03 11:23:34 --> Language Class Initialized
INFO - 2024-12-03 11:23:34 --> Loader Class Initialized
INFO - 2024-12-03 11:23:34 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:34 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:34 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:34 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:34 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:34 --> Controller Class Initialized
INFO - 2024-12-03 11:23:34 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:34 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:34 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 11:23:34 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:34 --> Total execution time: 0.0654
INFO - 2024-12-03 11:23:37 --> Config Class Initialized
INFO - 2024-12-03 11:23:37 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:37 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:37 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:37 --> URI Class Initialized
INFO - 2024-12-03 11:23:37 --> Router Class Initialized
INFO - 2024-12-03 11:23:37 --> Output Class Initialized
INFO - 2024-12-03 11:23:37 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:37 --> CSRF cookie sent
INFO - 2024-12-03 11:23:37 --> Input Class Initialized
INFO - 2024-12-03 11:23:37 --> Language Class Initialized
INFO - 2024-12-03 11:23:37 --> Loader Class Initialized
INFO - 2024-12-03 11:23:37 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:37 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:37 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:37 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:37 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:37 --> Controller Class Initialized
INFO - 2024-12-03 11:23:37 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:37 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:37 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:37 --> Config Class Initialized
INFO - 2024-12-03 11:23:37 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:37 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:37 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:37 --> URI Class Initialized
INFO - 2024-12-03 11:23:37 --> Router Class Initialized
INFO - 2024-12-03 11:23:37 --> Output Class Initialized
INFO - 2024-12-03 11:23:37 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:37 --> CSRF cookie sent
INFO - 2024-12-03 11:23:37 --> Input Class Initialized
INFO - 2024-12-03 11:23:37 --> Language Class Initialized
INFO - 2024-12-03 11:23:37 --> Loader Class Initialized
INFO - 2024-12-03 11:23:37 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:37 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:37 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:37 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:37 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:37 --> Controller Class Initialized
INFO - 2024-12-03 11:23:37 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:37 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:37 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 11:23:37 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:37 --> Total execution time: 0.0537
INFO - 2024-12-03 11:23:39 --> Config Class Initialized
INFO - 2024-12-03 11:23:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:23:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:23:39 --> Utf8 Class Initialized
INFO - 2024-12-03 11:23:39 --> URI Class Initialized
INFO - 2024-12-03 11:23:39 --> Router Class Initialized
INFO - 2024-12-03 11:23:39 --> Output Class Initialized
INFO - 2024-12-03 11:23:39 --> Security Class Initialized
DEBUG - 2024-12-03 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:23:39 --> CSRF cookie sent
INFO - 2024-12-03 11:23:39 --> Input Class Initialized
INFO - 2024-12-03 11:23:39 --> Language Class Initialized
INFO - 2024-12-03 11:23:39 --> Loader Class Initialized
INFO - 2024-12-03 11:23:39 --> Helper loaded: url_helper
INFO - 2024-12-03 11:23:39 --> Helper loaded: form_helper
INFO - 2024-12-03 11:23:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 11:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 11:23:39 --> Form Validation Class Initialized
INFO - 2024-12-03 11:23:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 11:23:39 --> Controller Class Initialized
INFO - 2024-12-03 11:23:39 --> Model "Category_model" initialized
INFO - 2024-12-03 11:23:39 --> Model "User_model" initialized
INFO - 2024-12-03 11:23:39 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 11:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 11:23:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 11:23:39 --> Final output sent to browser
DEBUG - 2024-12-03 11:23:39 --> Total execution time: 0.0449
INFO - 2024-12-03 13:06:05 --> Config Class Initialized
INFO - 2024-12-03 13:06:06 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:06:06 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:06:06 --> Utf8 Class Initialized
INFO - 2024-12-03 13:06:06 --> URI Class Initialized
INFO - 2024-12-03 13:06:06 --> Router Class Initialized
INFO - 2024-12-03 13:06:06 --> Output Class Initialized
INFO - 2024-12-03 13:06:06 --> Security Class Initialized
DEBUG - 2024-12-03 13:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:06:06 --> CSRF cookie sent
INFO - 2024-12-03 13:06:06 --> Input Class Initialized
INFO - 2024-12-03 13:06:06 --> Language Class Initialized
INFO - 2024-12-03 13:06:06 --> Loader Class Initialized
INFO - 2024-12-03 13:06:06 --> Helper loaded: url_helper
INFO - 2024-12-03 13:06:06 --> Helper loaded: form_helper
INFO - 2024-12-03 13:06:06 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:06:07 --> Form Validation Class Initialized
INFO - 2024-12-03 13:06:07 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:06:07 --> Controller Class Initialized
INFO - 2024-12-03 13:06:07 --> Model "Category_model" initialized
INFO - 2024-12-03 13:06:07 --> Model "User_model" initialized
INFO - 2024-12-03 13:06:07 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:06:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:06:07 --> Final output sent to browser
DEBUG - 2024-12-03 13:06:07 --> Total execution time: 1.9991
INFO - 2024-12-03 13:06:16 --> Config Class Initialized
INFO - 2024-12-03 13:06:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:06:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:06:16 --> Utf8 Class Initialized
INFO - 2024-12-03 13:06:16 --> URI Class Initialized
INFO - 2024-12-03 13:06:16 --> Router Class Initialized
INFO - 2024-12-03 13:06:16 --> Output Class Initialized
INFO - 2024-12-03 13:06:16 --> Security Class Initialized
DEBUG - 2024-12-03 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:06:16 --> CSRF cookie sent
INFO - 2024-12-03 13:06:16 --> Input Class Initialized
INFO - 2024-12-03 13:06:16 --> Language Class Initialized
INFO - 2024-12-03 13:06:16 --> Loader Class Initialized
INFO - 2024-12-03 13:06:16 --> Helper loaded: url_helper
INFO - 2024-12-03 13:06:16 --> Helper loaded: form_helper
INFO - 2024-12-03 13:06:16 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:06:16 --> Form Validation Class Initialized
INFO - 2024-12-03 13:06:16 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:06:16 --> Controller Class Initialized
INFO - 2024-12-03 13:06:16 --> Model "Category_model" initialized
INFO - 2024-12-03 13:06:16 --> Model "User_model" initialized
INFO - 2024-12-03 13:06:16 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:06:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 13:06:16 --> Final output sent to browser
DEBUG - 2024-12-03 13:06:16 --> Total execution time: 0.1684
INFO - 2024-12-03 13:06:24 --> Config Class Initialized
INFO - 2024-12-03 13:06:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:06:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:06:24 --> Utf8 Class Initialized
INFO - 2024-12-03 13:06:24 --> URI Class Initialized
INFO - 2024-12-03 13:06:24 --> Router Class Initialized
INFO - 2024-12-03 13:06:24 --> Output Class Initialized
INFO - 2024-12-03 13:06:24 --> Security Class Initialized
DEBUG - 2024-12-03 13:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:06:24 --> CSRF cookie sent
INFO - 2024-12-03 13:06:24 --> Input Class Initialized
INFO - 2024-12-03 13:06:24 --> Language Class Initialized
INFO - 2024-12-03 13:06:24 --> Loader Class Initialized
INFO - 2024-12-03 13:06:24 --> Helper loaded: url_helper
INFO - 2024-12-03 13:06:24 --> Helper loaded: form_helper
INFO - 2024-12-03 13:06:24 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:06:24 --> Form Validation Class Initialized
INFO - 2024-12-03 13:06:24 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:06:24 --> Controller Class Initialized
INFO - 2024-12-03 13:06:24 --> Model "Category_model" initialized
INFO - 2024-12-03 13:06:24 --> Model "User_model" initialized
INFO - 2024-12-03 13:06:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:06:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:06:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-03 13:06:24 --> Final output sent to browser
DEBUG - 2024-12-03 13:06:24 --> Total execution time: 0.3001
INFO - 2024-12-03 13:06:27 --> Config Class Initialized
INFO - 2024-12-03 13:06:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:06:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:06:27 --> Utf8 Class Initialized
INFO - 2024-12-03 13:06:27 --> URI Class Initialized
INFO - 2024-12-03 13:06:27 --> Router Class Initialized
INFO - 2024-12-03 13:06:27 --> Output Class Initialized
INFO - 2024-12-03 13:06:27 --> Security Class Initialized
DEBUG - 2024-12-03 13:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:06:27 --> CSRF cookie sent
INFO - 2024-12-03 13:06:27 --> Input Class Initialized
INFO - 2024-12-03 13:06:27 --> Language Class Initialized
INFO - 2024-12-03 13:06:27 --> Loader Class Initialized
INFO - 2024-12-03 13:06:27 --> Helper loaded: url_helper
INFO - 2024-12-03 13:06:27 --> Helper loaded: form_helper
INFO - 2024-12-03 13:06:27 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:06:27 --> Form Validation Class Initialized
INFO - 2024-12-03 13:06:27 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:06:27 --> Controller Class Initialized
INFO - 2024-12-03 13:06:27 --> Model "Category_model" initialized
INFO - 2024-12-03 13:06:27 --> Model "User_model" initialized
INFO - 2024-12-03 13:06:27 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:06:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 13:06:27 --> Final output sent to browser
DEBUG - 2024-12-03 13:06:27 --> Total execution time: 0.0788
INFO - 2024-12-03 13:06:33 --> Config Class Initialized
INFO - 2024-12-03 13:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:06:33 --> Utf8 Class Initialized
INFO - 2024-12-03 13:06:33 --> URI Class Initialized
INFO - 2024-12-03 13:06:33 --> Router Class Initialized
INFO - 2024-12-03 13:06:33 --> Output Class Initialized
INFO - 2024-12-03 13:06:33 --> Security Class Initialized
DEBUG - 2024-12-03 13:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:06:33 --> CSRF cookie sent
INFO - 2024-12-03 13:06:33 --> Input Class Initialized
INFO - 2024-12-03 13:06:33 --> Language Class Initialized
INFO - 2024-12-03 13:06:33 --> Loader Class Initialized
INFO - 2024-12-03 13:06:33 --> Helper loaded: url_helper
INFO - 2024-12-03 13:06:33 --> Helper loaded: form_helper
INFO - 2024-12-03 13:06:33 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:06:33 --> Form Validation Class Initialized
INFO - 2024-12-03 13:06:33 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:06:33 --> Controller Class Initialized
INFO - 2024-12-03 13:06:33 --> Model "Category_model" initialized
INFO - 2024-12-03 13:06:33 --> Model "User_model" initialized
INFO - 2024-12-03 13:06:33 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:06:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:06:33 --> Final output sent to browser
DEBUG - 2024-12-03 13:06:33 --> Total execution time: 0.1624
INFO - 2024-12-03 13:16:01 --> Config Class Initialized
INFO - 2024-12-03 13:16:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:16:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:16:02 --> Utf8 Class Initialized
INFO - 2024-12-03 13:16:02 --> URI Class Initialized
INFO - 2024-12-03 13:16:02 --> Router Class Initialized
INFO - 2024-12-03 13:16:02 --> Output Class Initialized
INFO - 2024-12-03 13:16:02 --> Security Class Initialized
DEBUG - 2024-12-03 13:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:16:02 --> CSRF cookie sent
INFO - 2024-12-03 13:16:02 --> Input Class Initialized
INFO - 2024-12-03 13:16:02 --> Language Class Initialized
INFO - 2024-12-03 13:16:02 --> Loader Class Initialized
INFO - 2024-12-03 13:16:02 --> Helper loaded: url_helper
INFO - 2024-12-03 13:16:02 --> Helper loaded: form_helper
INFO - 2024-12-03 13:16:02 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:16:02 --> Form Validation Class Initialized
INFO - 2024-12-03 13:16:02 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:16:02 --> Controller Class Initialized
INFO - 2024-12-03 13:16:02 --> Model "User_model" initialized
INFO - 2024-12-03 13:16:02 --> Model "Category_model" initialized
INFO - 2024-12-03 13:16:02 --> Model "Review_model" initialized
INFO - 2024-12-03 13:16:02 --> Model "News_model" initialized
INFO - 2024-12-03 13:16:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:16:02 --> Query result: stdClass Object
(
    [view_count] => 25
)

INFO - 2024-12-03 13:16:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 13:16:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 13:16:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 13:16:02 --> Final output sent to browser
DEBUG - 2024-12-03 13:16:02 --> Total execution time: 0.9677
INFO - 2024-12-03 13:20:12 --> Config Class Initialized
INFO - 2024-12-03 13:20:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:20:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:20:12 --> Utf8 Class Initialized
INFO - 2024-12-03 13:20:12 --> URI Class Initialized
INFO - 2024-12-03 13:20:12 --> Router Class Initialized
INFO - 2024-12-03 13:20:12 --> Output Class Initialized
INFO - 2024-12-03 13:20:12 --> Security Class Initialized
DEBUG - 2024-12-03 13:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:20:12 --> CSRF cookie sent
INFO - 2024-12-03 13:20:12 --> Input Class Initialized
INFO - 2024-12-03 13:20:12 --> Language Class Initialized
INFO - 2024-12-03 13:20:12 --> Loader Class Initialized
INFO - 2024-12-03 13:20:12 --> Helper loaded: url_helper
INFO - 2024-12-03 13:20:12 --> Helper loaded: form_helper
INFO - 2024-12-03 13:20:12 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:20:12 --> Form Validation Class Initialized
INFO - 2024-12-03 13:20:12 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:20:12 --> Controller Class Initialized
INFO - 2024-12-03 13:20:12 --> Model "Category_model" initialized
INFO - 2024-12-03 13:20:12 --> Model "User_model" initialized
INFO - 2024-12-03 13:20:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:20:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:20:12 --> Final output sent to browser
DEBUG - 2024-12-03 13:20:12 --> Total execution time: 0.8246
INFO - 2024-12-03 13:20:15 --> Config Class Initialized
INFO - 2024-12-03 13:20:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:20:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:20:15 --> Utf8 Class Initialized
INFO - 2024-12-03 13:20:15 --> URI Class Initialized
INFO - 2024-12-03 13:20:15 --> Router Class Initialized
INFO - 2024-12-03 13:20:15 --> Output Class Initialized
INFO - 2024-12-03 13:20:15 --> Security Class Initialized
DEBUG - 2024-12-03 13:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:20:15 --> CSRF cookie sent
INFO - 2024-12-03 13:20:15 --> Input Class Initialized
INFO - 2024-12-03 13:20:15 --> Language Class Initialized
INFO - 2024-12-03 13:20:15 --> Loader Class Initialized
INFO - 2024-12-03 13:20:15 --> Helper loaded: url_helper
INFO - 2024-12-03 13:20:15 --> Helper loaded: form_helper
INFO - 2024-12-03 13:20:15 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:20:15 --> Form Validation Class Initialized
INFO - 2024-12-03 13:20:15 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:20:15 --> Controller Class Initialized
INFO - 2024-12-03 13:20:15 --> Model "Category_model" initialized
INFO - 2024-12-03 13:20:15 --> Model "User_model" initialized
INFO - 2024-12-03 13:20:15 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:20:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 13:20:15 --> Final output sent to browser
DEBUG - 2024-12-03 13:20:15 --> Total execution time: 0.0588
INFO - 2024-12-03 13:20:36 --> Config Class Initialized
INFO - 2024-12-03 13:20:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:20:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:20:36 --> Utf8 Class Initialized
INFO - 2024-12-03 13:20:36 --> URI Class Initialized
INFO - 2024-12-03 13:20:36 --> Router Class Initialized
INFO - 2024-12-03 13:20:36 --> Output Class Initialized
INFO - 2024-12-03 13:20:36 --> Security Class Initialized
DEBUG - 2024-12-03 13:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:20:36 --> CSRF cookie sent
INFO - 2024-12-03 13:20:36 --> Input Class Initialized
INFO - 2024-12-03 13:20:36 --> Language Class Initialized
INFO - 2024-12-03 13:20:36 --> Loader Class Initialized
INFO - 2024-12-03 13:20:36 --> Helper loaded: url_helper
INFO - 2024-12-03 13:20:36 --> Helper loaded: form_helper
INFO - 2024-12-03 13:20:36 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:20:36 --> Form Validation Class Initialized
INFO - 2024-12-03 13:20:36 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:20:36 --> Controller Class Initialized
INFO - 2024-12-03 13:20:36 --> Model "Category_model" initialized
INFO - 2024-12-03 13:20:36 --> Model "User_model" initialized
INFO - 2024-12-03 13:20:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:20:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-03 13:20:36 --> Final output sent to browser
DEBUG - 2024-12-03 13:20:36 --> Total execution time: 0.1208
INFO - 2024-12-03 13:20:52 --> Config Class Initialized
INFO - 2024-12-03 13:20:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:20:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:20:52 --> Utf8 Class Initialized
INFO - 2024-12-03 13:20:52 --> URI Class Initialized
INFO - 2024-12-03 13:20:52 --> Router Class Initialized
INFO - 2024-12-03 13:20:52 --> Output Class Initialized
INFO - 2024-12-03 13:20:52 --> Security Class Initialized
DEBUG - 2024-12-03 13:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:20:52 --> CSRF cookie sent
INFO - 2024-12-03 13:20:52 --> CSRF token verified
INFO - 2024-12-03 13:20:52 --> Input Class Initialized
INFO - 2024-12-03 13:20:52 --> Language Class Initialized
INFO - 2024-12-03 13:20:52 --> Loader Class Initialized
INFO - 2024-12-03 13:20:52 --> Helper loaded: url_helper
INFO - 2024-12-03 13:20:52 --> Helper loaded: form_helper
INFO - 2024-12-03 13:20:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:20:52 --> Form Validation Class Initialized
INFO - 2024-12-03 13:20:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:20:52 --> Controller Class Initialized
INFO - 2024-12-03 13:20:52 --> Model "Category_model" initialized
INFO - 2024-12-03 13:20:52 --> Model "User_model" initialized
INFO - 2024-12-03 13:20:52 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:20:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-03 13:20:52 --> Config Class Initialized
INFO - 2024-12-03 13:20:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:20:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:20:52 --> Utf8 Class Initialized
INFO - 2024-12-03 13:20:52 --> URI Class Initialized
INFO - 2024-12-03 13:20:52 --> Router Class Initialized
INFO - 2024-12-03 13:20:52 --> Output Class Initialized
INFO - 2024-12-03 13:20:52 --> Security Class Initialized
DEBUG - 2024-12-03 13:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:20:52 --> CSRF cookie sent
INFO - 2024-12-03 13:20:52 --> Input Class Initialized
INFO - 2024-12-03 13:20:52 --> Language Class Initialized
INFO - 2024-12-03 13:20:52 --> Loader Class Initialized
INFO - 2024-12-03 13:20:52 --> Helper loaded: url_helper
INFO - 2024-12-03 13:20:52 --> Helper loaded: form_helper
INFO - 2024-12-03 13:20:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:20:52 --> Form Validation Class Initialized
INFO - 2024-12-03 13:20:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:20:52 --> Controller Class Initialized
INFO - 2024-12-03 13:20:52 --> Model "Category_model" initialized
INFO - 2024-12-03 13:20:52 --> Model "User_model" initialized
INFO - 2024-12-03 13:20:52 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:20:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 13:20:52 --> Final output sent to browser
DEBUG - 2024-12-03 13:20:52 --> Total execution time: 0.0540
INFO - 2024-12-03 13:20:58 --> Config Class Initialized
INFO - 2024-12-03 13:20:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:20:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:20:58 --> Utf8 Class Initialized
INFO - 2024-12-03 13:20:58 --> URI Class Initialized
INFO - 2024-12-03 13:20:58 --> Router Class Initialized
INFO - 2024-12-03 13:20:58 --> Output Class Initialized
INFO - 2024-12-03 13:20:58 --> Security Class Initialized
DEBUG - 2024-12-03 13:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:20:58 --> CSRF cookie sent
INFO - 2024-12-03 13:20:58 --> Input Class Initialized
INFO - 2024-12-03 13:20:58 --> Language Class Initialized
INFO - 2024-12-03 13:20:58 --> Loader Class Initialized
INFO - 2024-12-03 13:20:58 --> Helper loaded: url_helper
INFO - 2024-12-03 13:20:58 --> Helper loaded: form_helper
INFO - 2024-12-03 13:20:58 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:20:58 --> Form Validation Class Initialized
INFO - 2024-12-03 13:20:58 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:20:58 --> Controller Class Initialized
INFO - 2024-12-03 13:20:58 --> Model "Category_model" initialized
INFO - 2024-12-03 13:20:58 --> Model "User_model" initialized
INFO - 2024-12-03 13:20:58 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:20:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-03 13:20:58 --> Final output sent to browser
DEBUG - 2024-12-03 13:20:58 --> Total execution time: 0.1031
INFO - 2024-12-03 13:21:00 --> Config Class Initialized
INFO - 2024-12-03 13:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:21:00 --> Utf8 Class Initialized
INFO - 2024-12-03 13:21:00 --> URI Class Initialized
INFO - 2024-12-03 13:21:00 --> Router Class Initialized
INFO - 2024-12-03 13:21:00 --> Output Class Initialized
INFO - 2024-12-03 13:21:00 --> Security Class Initialized
DEBUG - 2024-12-03 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:21:00 --> CSRF cookie sent
INFO - 2024-12-03 13:21:00 --> Input Class Initialized
INFO - 2024-12-03 13:21:00 --> Language Class Initialized
INFO - 2024-12-03 13:21:00 --> Loader Class Initialized
INFO - 2024-12-03 13:21:00 --> Helper loaded: url_helper
INFO - 2024-12-03 13:21:00 --> Helper loaded: form_helper
INFO - 2024-12-03 13:21:00 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:21:00 --> Form Validation Class Initialized
INFO - 2024-12-03 13:21:00 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:21:00 --> Controller Class Initialized
INFO - 2024-12-03 13:21:00 --> Model "Category_model" initialized
INFO - 2024-12-03 13:21:00 --> Model "User_model" initialized
INFO - 2024-12-03 13:21:00 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:21:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 13:21:00 --> Final output sent to browser
DEBUG - 2024-12-03 13:21:00 --> Total execution time: 0.0499
INFO - 2024-12-03 13:21:03 --> Config Class Initialized
INFO - 2024-12-03 13:21:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:21:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:21:03 --> Utf8 Class Initialized
INFO - 2024-12-03 13:21:03 --> URI Class Initialized
INFO - 2024-12-03 13:21:03 --> Router Class Initialized
INFO - 2024-12-03 13:21:03 --> Output Class Initialized
INFO - 2024-12-03 13:21:03 --> Security Class Initialized
DEBUG - 2024-12-03 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:21:03 --> CSRF cookie sent
INFO - 2024-12-03 13:21:03 --> Input Class Initialized
INFO - 2024-12-03 13:21:03 --> Language Class Initialized
INFO - 2024-12-03 13:21:03 --> Loader Class Initialized
INFO - 2024-12-03 13:21:03 --> Helper loaded: url_helper
INFO - 2024-12-03 13:21:03 --> Helper loaded: form_helper
INFO - 2024-12-03 13:21:03 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:21:03 --> Form Validation Class Initialized
INFO - 2024-12-03 13:21:03 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:21:03 --> Controller Class Initialized
INFO - 2024-12-03 13:21:03 --> Model "Category_model" initialized
INFO - 2024-12-03 13:21:03 --> Model "User_model" initialized
INFO - 2024-12-03 13:21:03 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:21:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:21:03 --> Final output sent to browser
DEBUG - 2024-12-03 13:21:03 --> Total execution time: 0.0724
INFO - 2024-12-03 13:21:36 --> Config Class Initialized
INFO - 2024-12-03 13:21:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:21:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:21:36 --> Utf8 Class Initialized
INFO - 2024-12-03 13:21:36 --> URI Class Initialized
INFO - 2024-12-03 13:21:36 --> Router Class Initialized
INFO - 2024-12-03 13:21:36 --> Output Class Initialized
INFO - 2024-12-03 13:21:36 --> Security Class Initialized
DEBUG - 2024-12-03 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:21:36 --> CSRF cookie sent
INFO - 2024-12-03 13:21:36 --> Input Class Initialized
INFO - 2024-12-03 13:21:36 --> Language Class Initialized
INFO - 2024-12-03 13:21:36 --> Loader Class Initialized
INFO - 2024-12-03 13:21:36 --> Helper loaded: url_helper
INFO - 2024-12-03 13:21:36 --> Helper loaded: form_helper
INFO - 2024-12-03 13:21:36 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:21:36 --> Form Validation Class Initialized
INFO - 2024-12-03 13:21:36 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:21:36 --> Controller Class Initialized
INFO - 2024-12-03 13:21:36 --> Model "Category_model" initialized
INFO - 2024-12-03 13:21:36 --> Model "User_model" initialized
INFO - 2024-12-03 13:21:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:21:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 13:21:36 --> Final output sent to browser
DEBUG - 2024-12-03 13:21:36 --> Total execution time: 0.4939
INFO - 2024-12-03 13:21:39 --> Config Class Initialized
INFO - 2024-12-03 13:21:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:21:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:21:39 --> Utf8 Class Initialized
INFO - 2024-12-03 13:21:39 --> URI Class Initialized
INFO - 2024-12-03 13:21:39 --> Router Class Initialized
INFO - 2024-12-03 13:21:39 --> Output Class Initialized
INFO - 2024-12-03 13:21:39 --> Security Class Initialized
DEBUG - 2024-12-03 13:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:21:39 --> CSRF cookie sent
INFO - 2024-12-03 13:21:39 --> Input Class Initialized
INFO - 2024-12-03 13:21:39 --> Language Class Initialized
INFO - 2024-12-03 13:21:39 --> Loader Class Initialized
INFO - 2024-12-03 13:21:39 --> Helper loaded: url_helper
INFO - 2024-12-03 13:21:39 --> Helper loaded: form_helper
INFO - 2024-12-03 13:21:39 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:21:39 --> Form Validation Class Initialized
INFO - 2024-12-03 13:21:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:21:39 --> Controller Class Initialized
INFO - 2024-12-03 13:21:39 --> Model "Category_model" initialized
INFO - 2024-12-03 13:21:39 --> Model "User_model" initialized
INFO - 2024-12-03 13:21:39 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-03 13:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:21:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:21:39 --> Final output sent to browser
DEBUG - 2024-12-03 13:21:39 --> Total execution time: 0.0936
INFO - 2024-12-03 13:33:29 --> Config Class Initialized
INFO - 2024-12-03 13:33:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:33:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:33:29 --> Utf8 Class Initialized
INFO - 2024-12-03 13:33:29 --> URI Class Initialized
INFO - 2024-12-03 13:33:29 --> Router Class Initialized
INFO - 2024-12-03 13:33:29 --> Output Class Initialized
INFO - 2024-12-03 13:33:29 --> Security Class Initialized
DEBUG - 2024-12-03 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:33:29 --> CSRF cookie sent
INFO - 2024-12-03 13:33:29 --> Input Class Initialized
INFO - 2024-12-03 13:33:29 --> Language Class Initialized
INFO - 2024-12-03 13:33:29 --> Loader Class Initialized
INFO - 2024-12-03 13:33:29 --> Helper loaded: url_helper
INFO - 2024-12-03 13:33:29 --> Helper loaded: form_helper
INFO - 2024-12-03 13:33:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:33:29 --> Form Validation Class Initialized
INFO - 2024-12-03 13:33:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:33:29 --> Controller Class Initialized
INFO - 2024-12-03 13:33:29 --> Model "User_model" initialized
INFO - 2024-12-03 13:33:29 --> Model "Category_model" initialized
INFO - 2024-12-03 13:33:29 --> Model "Review_model" initialized
INFO - 2024-12-03 13:33:29 --> Model "News_model" initialized
INFO - 2024-12-03 13:33:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:33:29 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:33:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 13:33:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 13:33:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 13:33:29 --> Final output sent to browser
DEBUG - 2024-12-03 13:33:29 --> Total execution time: 0.7743
INFO - 2024-12-03 13:33:32 --> Config Class Initialized
INFO - 2024-12-03 13:33:32 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:33:32 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:33:32 --> Utf8 Class Initialized
INFO - 2024-12-03 13:33:32 --> URI Class Initialized
INFO - 2024-12-03 13:33:32 --> Router Class Initialized
INFO - 2024-12-03 13:33:32 --> Output Class Initialized
INFO - 2024-12-03 13:33:32 --> Security Class Initialized
DEBUG - 2024-12-03 13:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:33:32 --> CSRF cookie sent
INFO - 2024-12-03 13:33:32 --> Input Class Initialized
INFO - 2024-12-03 13:33:32 --> Language Class Initialized
INFO - 2024-12-03 13:33:32 --> Loader Class Initialized
INFO - 2024-12-03 13:33:32 --> Helper loaded: url_helper
INFO - 2024-12-03 13:33:32 --> Helper loaded: form_helper
INFO - 2024-12-03 13:33:32 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:33:32 --> Form Validation Class Initialized
INFO - 2024-12-03 13:33:32 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:33:32 --> Controller Class Initialized
INFO - 2024-12-03 13:33:32 --> Model "User_model" initialized
INFO - 2024-12-03 13:33:32 --> Model "Category_model" initialized
INFO - 2024-12-03 13:33:32 --> Model "Review_model" initialized
INFO - 2024-12-03 13:33:32 --> Model "News_model" initialized
INFO - 2024-12-03 13:33:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:33:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 13:33:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 13:33:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 13:33:32 --> Final output sent to browser
DEBUG - 2024-12-03 13:33:32 --> Total execution time: 0.0780
INFO - 2024-12-03 13:33:35 --> Config Class Initialized
INFO - 2024-12-03 13:33:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:33:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:33:35 --> Utf8 Class Initialized
INFO - 2024-12-03 13:33:35 --> URI Class Initialized
INFO - 2024-12-03 13:33:35 --> Router Class Initialized
INFO - 2024-12-03 13:33:35 --> Output Class Initialized
INFO - 2024-12-03 13:33:35 --> Security Class Initialized
DEBUG - 2024-12-03 13:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:33:35 --> CSRF cookie sent
INFO - 2024-12-03 13:33:35 --> CSRF token verified
INFO - 2024-12-03 13:33:35 --> Input Class Initialized
INFO - 2024-12-03 13:33:35 --> Language Class Initialized
INFO - 2024-12-03 13:33:35 --> Loader Class Initialized
INFO - 2024-12-03 13:33:35 --> Helper loaded: url_helper
INFO - 2024-12-03 13:33:35 --> Helper loaded: form_helper
INFO - 2024-12-03 13:33:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:33:35 --> Form Validation Class Initialized
INFO - 2024-12-03 13:33:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:33:35 --> Controller Class Initialized
INFO - 2024-12-03 13:33:35 --> Model "User_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "Category_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "Review_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "News_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:33:35 --> Config Class Initialized
INFO - 2024-12-03 13:33:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:33:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:33:35 --> Utf8 Class Initialized
INFO - 2024-12-03 13:33:35 --> URI Class Initialized
INFO - 2024-12-03 13:33:35 --> Router Class Initialized
INFO - 2024-12-03 13:33:35 --> Output Class Initialized
INFO - 2024-12-03 13:33:35 --> Security Class Initialized
DEBUG - 2024-12-03 13:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:33:35 --> CSRF cookie sent
INFO - 2024-12-03 13:33:35 --> Input Class Initialized
INFO - 2024-12-03 13:33:35 --> Language Class Initialized
INFO - 2024-12-03 13:33:35 --> Loader Class Initialized
INFO - 2024-12-03 13:33:35 --> Helper loaded: url_helper
INFO - 2024-12-03 13:33:35 --> Helper loaded: form_helper
INFO - 2024-12-03 13:33:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:33:35 --> Form Validation Class Initialized
INFO - 2024-12-03 13:33:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:33:35 --> Controller Class Initialized
INFO - 2024-12-03 13:33:35 --> Model "Category_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "User_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:33:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:33:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:33:35 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:33:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:33:35 --> Final output sent to browser
DEBUG - 2024-12-03 13:33:35 --> Total execution time: 0.0639
INFO - 2024-12-03 13:36:24 --> Config Class Initialized
INFO - 2024-12-03 13:36:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:36:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:36:24 --> Utf8 Class Initialized
INFO - 2024-12-03 13:36:24 --> URI Class Initialized
INFO - 2024-12-03 13:36:24 --> Router Class Initialized
INFO - 2024-12-03 13:36:24 --> Output Class Initialized
INFO - 2024-12-03 13:36:24 --> Security Class Initialized
DEBUG - 2024-12-03 13:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:36:24 --> CSRF cookie sent
INFO - 2024-12-03 13:36:24 --> Input Class Initialized
INFO - 2024-12-03 13:36:24 --> Language Class Initialized
INFO - 2024-12-03 13:36:24 --> Loader Class Initialized
INFO - 2024-12-03 13:36:24 --> Helper loaded: url_helper
INFO - 2024-12-03 13:36:24 --> Helper loaded: form_helper
INFO - 2024-12-03 13:36:24 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:36:24 --> Form Validation Class Initialized
INFO - 2024-12-03 13:36:24 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:36:24 --> Controller Class Initialized
INFO - 2024-12-03 13:36:24 --> Model "Category_model" initialized
INFO - 2024-12-03 13:36:24 --> Model "User_model" initialized
INFO - 2024-12-03 13:36:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:36:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:36:24 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:36:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:36:24 --> Final output sent to browser
DEBUG - 2024-12-03 13:36:24 --> Total execution time: 0.2780
INFO - 2024-12-03 13:37:11 --> Config Class Initialized
INFO - 2024-12-03 13:37:11 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:37:11 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:37:11 --> Utf8 Class Initialized
INFO - 2024-12-03 13:37:11 --> URI Class Initialized
INFO - 2024-12-03 13:37:11 --> Router Class Initialized
INFO - 2024-12-03 13:37:11 --> Output Class Initialized
INFO - 2024-12-03 13:37:11 --> Security Class Initialized
DEBUG - 2024-12-03 13:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:37:11 --> CSRF cookie sent
INFO - 2024-12-03 13:37:11 --> Input Class Initialized
INFO - 2024-12-03 13:37:11 --> Language Class Initialized
INFO - 2024-12-03 13:37:11 --> Loader Class Initialized
INFO - 2024-12-03 13:37:11 --> Helper loaded: url_helper
INFO - 2024-12-03 13:37:11 --> Helper loaded: form_helper
INFO - 2024-12-03 13:37:11 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:37:11 --> Form Validation Class Initialized
INFO - 2024-12-03 13:37:11 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:37:11 --> Controller Class Initialized
INFO - 2024-12-03 13:37:11 --> Model "Category_model" initialized
INFO - 2024-12-03 13:37:11 --> Model "User_model" initialized
INFO - 2024-12-03 13:37:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:37:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:37:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 13:37:11 --> Final output sent to browser
DEBUG - 2024-12-03 13:37:11 --> Total execution time: 0.3964
INFO - 2024-12-03 13:37:13 --> Config Class Initialized
INFO - 2024-12-03 13:37:13 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:37:13 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:37:13 --> Utf8 Class Initialized
INFO - 2024-12-03 13:37:13 --> URI Class Initialized
INFO - 2024-12-03 13:37:13 --> Router Class Initialized
INFO - 2024-12-03 13:37:13 --> Output Class Initialized
INFO - 2024-12-03 13:37:13 --> Security Class Initialized
DEBUG - 2024-12-03 13:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:37:13 --> CSRF cookie sent
INFO - 2024-12-03 13:37:13 --> Input Class Initialized
INFO - 2024-12-03 13:37:13 --> Language Class Initialized
INFO - 2024-12-03 13:37:13 --> Loader Class Initialized
INFO - 2024-12-03 13:37:13 --> Helper loaded: url_helper
INFO - 2024-12-03 13:37:13 --> Helper loaded: form_helper
INFO - 2024-12-03 13:37:13 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:37:13 --> Form Validation Class Initialized
INFO - 2024-12-03 13:37:13 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:37:13 --> Controller Class Initialized
INFO - 2024-12-03 13:37:13 --> Model "Category_model" initialized
INFO - 2024-12-03 13:37:13 --> Model "User_model" initialized
INFO - 2024-12-03 13:37:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:37:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:37:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:37:13 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:37:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:37:13 --> Final output sent to browser
DEBUG - 2024-12-03 13:37:13 --> Total execution time: 0.0670
INFO - 2024-12-03 13:37:15 --> Config Class Initialized
INFO - 2024-12-03 13:37:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:37:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:37:15 --> Utf8 Class Initialized
INFO - 2024-12-03 13:37:15 --> URI Class Initialized
INFO - 2024-12-03 13:37:15 --> Router Class Initialized
INFO - 2024-12-03 13:37:15 --> Output Class Initialized
INFO - 2024-12-03 13:37:15 --> Security Class Initialized
DEBUG - 2024-12-03 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:37:15 --> CSRF cookie sent
INFO - 2024-12-03 13:37:15 --> Input Class Initialized
INFO - 2024-12-03 13:37:15 --> Language Class Initialized
INFO - 2024-12-03 13:37:15 --> Loader Class Initialized
INFO - 2024-12-03 13:37:15 --> Helper loaded: url_helper
INFO - 2024-12-03 13:37:15 --> Helper loaded: form_helper
INFO - 2024-12-03 13:37:15 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:37:15 --> Form Validation Class Initialized
INFO - 2024-12-03 13:37:15 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:37:15 --> Controller Class Initialized
INFO - 2024-12-03 13:37:15 --> Model "Category_model" initialized
INFO - 2024-12-03 13:37:15 --> Model "User_model" initialized
INFO - 2024-12-03 13:37:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:37:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:37:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 13:37:15 --> Final output sent to browser
DEBUG - 2024-12-03 13:37:15 --> Total execution time: 0.0612
INFO - 2024-12-03 13:37:16 --> Config Class Initialized
INFO - 2024-12-03 13:37:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:37:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:37:16 --> Utf8 Class Initialized
INFO - 2024-12-03 13:37:16 --> URI Class Initialized
INFO - 2024-12-03 13:37:16 --> Router Class Initialized
INFO - 2024-12-03 13:37:16 --> Output Class Initialized
INFO - 2024-12-03 13:37:16 --> Security Class Initialized
DEBUG - 2024-12-03 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:37:16 --> CSRF cookie sent
INFO - 2024-12-03 13:37:16 --> Input Class Initialized
INFO - 2024-12-03 13:37:16 --> Language Class Initialized
INFO - 2024-12-03 13:37:16 --> Loader Class Initialized
INFO - 2024-12-03 13:37:16 --> Helper loaded: url_helper
INFO - 2024-12-03 13:37:16 --> Helper loaded: form_helper
INFO - 2024-12-03 13:37:16 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:37:17 --> Form Validation Class Initialized
INFO - 2024-12-03 13:37:17 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:37:17 --> Controller Class Initialized
INFO - 2024-12-03 13:37:17 --> Model "Category_model" initialized
INFO - 2024-12-03 13:37:17 --> Model "User_model" initialized
INFO - 2024-12-03 13:37:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:37:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:37:17 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:37:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:37:17 --> Final output sent to browser
DEBUG - 2024-12-03 13:37:17 --> Total execution time: 0.0837
INFO - 2024-12-03 13:37:21 --> Config Class Initialized
INFO - 2024-12-03 13:37:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:37:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:37:21 --> Utf8 Class Initialized
INFO - 2024-12-03 13:37:21 --> URI Class Initialized
INFO - 2024-12-03 13:37:21 --> Router Class Initialized
INFO - 2024-12-03 13:37:21 --> Output Class Initialized
INFO - 2024-12-03 13:37:21 --> Security Class Initialized
DEBUG - 2024-12-03 13:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:37:21 --> CSRF cookie sent
INFO - 2024-12-03 13:37:21 --> Input Class Initialized
INFO - 2024-12-03 13:37:21 --> Language Class Initialized
INFO - 2024-12-03 13:37:21 --> Loader Class Initialized
INFO - 2024-12-03 13:37:21 --> Helper loaded: url_helper
INFO - 2024-12-03 13:37:21 --> Helper loaded: form_helper
INFO - 2024-12-03 13:37:21 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:37:21 --> Form Validation Class Initialized
INFO - 2024-12-03 13:37:21 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:37:21 --> Controller Class Initialized
INFO - 2024-12-03 13:37:21 --> Model "Category_model" initialized
INFO - 2024-12-03 13:37:21 --> Model "User_model" initialized
INFO - 2024-12-03 13:37:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:37:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:37:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 13:37:21 --> Final output sent to browser
DEBUG - 2024-12-03 13:37:21 --> Total execution time: 0.0985
INFO - 2024-12-03 13:40:25 --> Config Class Initialized
INFO - 2024-12-03 13:40:25 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:40:25 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:40:25 --> Utf8 Class Initialized
INFO - 2024-12-03 13:40:25 --> URI Class Initialized
INFO - 2024-12-03 13:40:25 --> Router Class Initialized
INFO - 2024-12-03 13:40:25 --> Output Class Initialized
INFO - 2024-12-03 13:40:25 --> Security Class Initialized
DEBUG - 2024-12-03 13:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:40:25 --> CSRF cookie sent
INFO - 2024-12-03 13:40:25 --> Input Class Initialized
INFO - 2024-12-03 13:40:25 --> Language Class Initialized
INFO - 2024-12-03 13:40:25 --> Loader Class Initialized
INFO - 2024-12-03 13:40:25 --> Helper loaded: url_helper
INFO - 2024-12-03 13:40:25 --> Helper loaded: form_helper
INFO - 2024-12-03 13:40:25 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:40:25 --> Form Validation Class Initialized
INFO - 2024-12-03 13:40:25 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:40:25 --> Controller Class Initialized
INFO - 2024-12-03 13:40:25 --> Model "Category_model" initialized
INFO - 2024-12-03 13:40:25 --> Model "User_model" initialized
INFO - 2024-12-03 13:40:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:40:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:40:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 13:40:25 --> Final output sent to browser
DEBUG - 2024-12-03 13:40:25 --> Total execution time: 0.1848
INFO - 2024-12-03 13:40:29 --> Config Class Initialized
INFO - 2024-12-03 13:40:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:40:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:40:29 --> Utf8 Class Initialized
INFO - 2024-12-03 13:40:29 --> URI Class Initialized
INFO - 2024-12-03 13:40:29 --> Router Class Initialized
INFO - 2024-12-03 13:40:29 --> Output Class Initialized
INFO - 2024-12-03 13:40:29 --> Security Class Initialized
DEBUG - 2024-12-03 13:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:40:29 --> CSRF cookie sent
INFO - 2024-12-03 13:40:29 --> Input Class Initialized
INFO - 2024-12-03 13:40:29 --> Language Class Initialized
INFO - 2024-12-03 13:40:29 --> Loader Class Initialized
INFO - 2024-12-03 13:40:29 --> Helper loaded: url_helper
INFO - 2024-12-03 13:40:29 --> Helper loaded: form_helper
INFO - 2024-12-03 13:40:29 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:40:29 --> Form Validation Class Initialized
INFO - 2024-12-03 13:40:29 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:40:29 --> Controller Class Initialized
INFO - 2024-12-03 13:40:29 --> Model "Category_model" initialized
INFO - 2024-12-03 13:40:29 --> Model "User_model" initialized
INFO - 2024-12-03 13:40:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:40:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:40:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:40:29 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:40:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:40:29 --> Final output sent to browser
DEBUG - 2024-12-03 13:40:29 --> Total execution time: 0.1023
INFO - 2024-12-03 13:40:31 --> Config Class Initialized
INFO - 2024-12-03 13:40:31 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:40:31 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:40:31 --> Utf8 Class Initialized
INFO - 2024-12-03 13:40:31 --> URI Class Initialized
INFO - 2024-12-03 13:40:31 --> Router Class Initialized
INFO - 2024-12-03 13:40:31 --> Output Class Initialized
INFO - 2024-12-03 13:40:31 --> Security Class Initialized
DEBUG - 2024-12-03 13:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:40:31 --> CSRF cookie sent
INFO - 2024-12-03 13:40:31 --> Input Class Initialized
INFO - 2024-12-03 13:40:31 --> Language Class Initialized
INFO - 2024-12-03 13:40:31 --> Loader Class Initialized
INFO - 2024-12-03 13:40:31 --> Helper loaded: url_helper
INFO - 2024-12-03 13:40:31 --> Helper loaded: form_helper
INFO - 2024-12-03 13:40:31 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:40:31 --> Form Validation Class Initialized
INFO - 2024-12-03 13:40:31 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:40:31 --> Controller Class Initialized
INFO - 2024-12-03 13:40:31 --> Model "Category_model" initialized
INFO - 2024-12-03 13:40:31 --> Model "User_model" initialized
INFO - 2024-12-03 13:40:31 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:40:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:40:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-03 13:40:31 --> Final output sent to browser
DEBUG - 2024-12-03 13:40:31 --> Total execution time: 0.1086
INFO - 2024-12-03 13:40:35 --> Config Class Initialized
INFO - 2024-12-03 13:40:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:40:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:40:35 --> Utf8 Class Initialized
INFO - 2024-12-03 13:40:35 --> URI Class Initialized
INFO - 2024-12-03 13:40:35 --> Router Class Initialized
INFO - 2024-12-03 13:40:35 --> Output Class Initialized
INFO - 2024-12-03 13:40:35 --> Security Class Initialized
DEBUG - 2024-12-03 13:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:40:35 --> CSRF cookie sent
INFO - 2024-12-03 13:40:35 --> Input Class Initialized
INFO - 2024-12-03 13:40:35 --> Language Class Initialized
INFO - 2024-12-03 13:40:35 --> Loader Class Initialized
INFO - 2024-12-03 13:40:35 --> Helper loaded: url_helper
INFO - 2024-12-03 13:40:35 --> Helper loaded: form_helper
INFO - 2024-12-03 13:40:35 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:40:35 --> Form Validation Class Initialized
INFO - 2024-12-03 13:40:35 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:40:35 --> Controller Class Initialized
INFO - 2024-12-03 13:40:35 --> Model "Category_model" initialized
INFO - 2024-12-03 13:40:35 --> Model "User_model" initialized
INFO - 2024-12-03 13:40:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:40:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:40:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-03 13:40:35 --> Final output sent to browser
DEBUG - 2024-12-03 13:40:35 --> Total execution time: 0.0762
INFO - 2024-12-03 13:40:36 --> Config Class Initialized
INFO - 2024-12-03 13:40:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:40:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:40:36 --> Utf8 Class Initialized
INFO - 2024-12-03 13:40:36 --> URI Class Initialized
INFO - 2024-12-03 13:40:36 --> Router Class Initialized
INFO - 2024-12-03 13:40:36 --> Output Class Initialized
INFO - 2024-12-03 13:40:36 --> Security Class Initialized
DEBUG - 2024-12-03 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:40:36 --> CSRF cookie sent
INFO - 2024-12-03 13:40:36 --> Input Class Initialized
INFO - 2024-12-03 13:40:36 --> Language Class Initialized
INFO - 2024-12-03 13:40:36 --> Loader Class Initialized
INFO - 2024-12-03 13:40:36 --> Helper loaded: url_helper
INFO - 2024-12-03 13:40:36 --> Helper loaded: form_helper
INFO - 2024-12-03 13:40:36 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:40:36 --> Form Validation Class Initialized
INFO - 2024-12-03 13:40:36 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:40:36 --> Controller Class Initialized
INFO - 2024-12-03 13:40:36 --> Model "Category_model" initialized
INFO - 2024-12-03 13:40:36 --> Model "User_model" initialized
INFO - 2024-12-03 13:40:36 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:40:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:40:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-03 13:40:36 --> Final output sent to browser
DEBUG - 2024-12-03 13:40:36 --> Total execution time: 0.0951
INFO - 2024-12-03 13:40:38 --> Config Class Initialized
INFO - 2024-12-03 13:40:38 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:40:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:40:38 --> Utf8 Class Initialized
INFO - 2024-12-03 13:40:38 --> URI Class Initialized
INFO - 2024-12-03 13:40:38 --> Router Class Initialized
INFO - 2024-12-03 13:40:38 --> Output Class Initialized
INFO - 2024-12-03 13:40:38 --> Security Class Initialized
DEBUG - 2024-12-03 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:40:38 --> CSRF cookie sent
INFO - 2024-12-03 13:40:38 --> Input Class Initialized
INFO - 2024-12-03 13:40:38 --> Language Class Initialized
INFO - 2024-12-03 13:40:38 --> Loader Class Initialized
INFO - 2024-12-03 13:40:38 --> Helper loaded: url_helper
INFO - 2024-12-03 13:40:38 --> Helper loaded: form_helper
INFO - 2024-12-03 13:40:38 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:40:39 --> Form Validation Class Initialized
INFO - 2024-12-03 13:40:39 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:40:39 --> Controller Class Initialized
INFO - 2024-12-03 13:40:39 --> Model "Category_model" initialized
INFO - 2024-12-03 13:40:39 --> Model "User_model" initialized
INFO - 2024-12-03 13:40:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:40:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:40:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 13:40:39 --> Final output sent to browser
DEBUG - 2024-12-03 13:40:39 --> Total execution time: 0.4855
INFO - 2024-12-03 13:42:50 --> Config Class Initialized
INFO - 2024-12-03 13:42:50 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:42:50 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:42:50 --> Utf8 Class Initialized
INFO - 2024-12-03 13:42:50 --> URI Class Initialized
INFO - 2024-12-03 13:42:50 --> Router Class Initialized
INFO - 2024-12-03 13:42:50 --> Output Class Initialized
INFO - 2024-12-03 13:42:50 --> Security Class Initialized
DEBUG - 2024-12-03 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:42:50 --> CSRF cookie sent
INFO - 2024-12-03 13:42:50 --> Input Class Initialized
INFO - 2024-12-03 13:42:50 --> Language Class Initialized
INFO - 2024-12-03 13:42:50 --> Loader Class Initialized
INFO - 2024-12-03 13:42:50 --> Helper loaded: url_helper
INFO - 2024-12-03 13:42:50 --> Helper loaded: form_helper
INFO - 2024-12-03 13:42:50 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:42:50 --> Form Validation Class Initialized
INFO - 2024-12-03 13:42:50 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:42:50 --> Controller Class Initialized
INFO - 2024-12-03 13:42:50 --> Model "Category_model" initialized
INFO - 2024-12-03 13:42:50 --> Model "User_model" initialized
INFO - 2024-12-03 13:42:50 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:42:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:42:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-03 13:42:50 --> Final output sent to browser
DEBUG - 2024-12-03 13:42:50 --> Total execution time: 0.3264
INFO - 2024-12-03 13:42:52 --> Config Class Initialized
INFO - 2024-12-03 13:42:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:42:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:42:52 --> Utf8 Class Initialized
INFO - 2024-12-03 13:42:52 --> URI Class Initialized
INFO - 2024-12-03 13:42:52 --> Router Class Initialized
INFO - 2024-12-03 13:42:52 --> Output Class Initialized
INFO - 2024-12-03 13:42:52 --> Security Class Initialized
DEBUG - 2024-12-03 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:42:52 --> CSRF cookie sent
INFO - 2024-12-03 13:42:52 --> Input Class Initialized
INFO - 2024-12-03 13:42:52 --> Language Class Initialized
INFO - 2024-12-03 13:42:52 --> Loader Class Initialized
INFO - 2024-12-03 13:42:52 --> Helper loaded: url_helper
INFO - 2024-12-03 13:42:52 --> Helper loaded: form_helper
INFO - 2024-12-03 13:42:52 --> Database Driver Class Initialized
DEBUG - 2024-12-03 13:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:42:52 --> Form Validation Class Initialized
INFO - 2024-12-03 13:42:52 --> Model "Culinary_model" initialized
INFO - 2024-12-03 13:42:52 --> Controller Class Initialized
INFO - 2024-12-03 13:42:52 --> Model "Category_model" initialized
INFO - 2024-12-03 13:42:52 --> Model "User_model" initialized
INFO - 2024-12-03 13:42:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 13:42:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 13:42:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 13:42:52 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 13:42:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 13:42:52 --> Final output sent to browser
DEBUG - 2024-12-03 13:42:52 --> Total execution time: 0.0737
INFO - 2024-12-03 14:40:46 --> Config Class Initialized
INFO - 2024-12-03 14:40:46 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:40:46 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:40:46 --> Utf8 Class Initialized
INFO - 2024-12-03 14:40:46 --> URI Class Initialized
INFO - 2024-12-03 14:40:46 --> Router Class Initialized
INFO - 2024-12-03 14:40:46 --> Output Class Initialized
INFO - 2024-12-03 14:40:46 --> Security Class Initialized
DEBUG - 2024-12-03 14:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:40:46 --> CSRF cookie sent
INFO - 2024-12-03 14:40:46 --> Input Class Initialized
INFO - 2024-12-03 14:40:46 --> Language Class Initialized
INFO - 2024-12-03 14:40:46 --> Loader Class Initialized
INFO - 2024-12-03 14:40:46 --> Helper loaded: url_helper
INFO - 2024-12-03 14:40:46 --> Helper loaded: form_helper
INFO - 2024-12-03 14:40:46 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:40:47 --> Form Validation Class Initialized
INFO - 2024-12-03 14:40:47 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:40:47 --> Controller Class Initialized
INFO - 2024-12-03 14:40:47 --> Model "Category_model" initialized
INFO - 2024-12-03 14:40:47 --> Model "User_model" initialized
INFO - 2024-12-03 14:40:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 14:40:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 14:40:47 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-03 14:40:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 14:40:47 --> Final output sent to browser
DEBUG - 2024-12-03 14:40:47 --> Total execution time: 0.6455
INFO - 2024-12-03 14:40:49 --> Config Class Initialized
INFO - 2024-12-03 14:40:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:40:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:40:49 --> Utf8 Class Initialized
INFO - 2024-12-03 14:40:49 --> URI Class Initialized
INFO - 2024-12-03 14:40:49 --> Router Class Initialized
INFO - 2024-12-03 14:40:49 --> Output Class Initialized
INFO - 2024-12-03 14:40:49 --> Security Class Initialized
DEBUG - 2024-12-03 14:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:40:49 --> CSRF cookie sent
INFO - 2024-12-03 14:40:49 --> Input Class Initialized
INFO - 2024-12-03 14:40:49 --> Language Class Initialized
INFO - 2024-12-03 14:40:49 --> Loader Class Initialized
INFO - 2024-12-03 14:40:49 --> Helper loaded: url_helper
INFO - 2024-12-03 14:40:49 --> Helper loaded: form_helper
INFO - 2024-12-03 14:40:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:40:49 --> Form Validation Class Initialized
INFO - 2024-12-03 14:40:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:40:49 --> Controller Class Initialized
INFO - 2024-12-03 14:40:49 --> Model "User_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "Category_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "Review_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "News_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:40:49 --> Config Class Initialized
INFO - 2024-12-03 14:40:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:40:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:40:49 --> Utf8 Class Initialized
INFO - 2024-12-03 14:40:49 --> URI Class Initialized
INFO - 2024-12-03 14:40:49 --> Router Class Initialized
INFO - 2024-12-03 14:40:49 --> Output Class Initialized
INFO - 2024-12-03 14:40:49 --> Security Class Initialized
DEBUG - 2024-12-03 14:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:40:49 --> CSRF cookie sent
INFO - 2024-12-03 14:40:49 --> Input Class Initialized
INFO - 2024-12-03 14:40:49 --> Language Class Initialized
INFO - 2024-12-03 14:40:49 --> Loader Class Initialized
INFO - 2024-12-03 14:40:49 --> Helper loaded: url_helper
INFO - 2024-12-03 14:40:49 --> Helper loaded: form_helper
INFO - 2024-12-03 14:40:49 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:40:49 --> Form Validation Class Initialized
INFO - 2024-12-03 14:40:49 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:40:49 --> Controller Class Initialized
INFO - 2024-12-03 14:40:49 --> Model "User_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "Category_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "Review_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "News_model" initialized
INFO - 2024-12-03 14:40:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:40:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 14:40:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 14:40:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-03 14:40:49 --> Final output sent to browser
DEBUG - 2024-12-03 14:40:49 --> Total execution time: 0.0690
INFO - 2024-12-03 14:40:54 --> Config Class Initialized
INFO - 2024-12-03 14:40:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:40:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:40:54 --> Utf8 Class Initialized
INFO - 2024-12-03 14:40:54 --> URI Class Initialized
INFO - 2024-12-03 14:40:54 --> Router Class Initialized
INFO - 2024-12-03 14:40:54 --> Output Class Initialized
INFO - 2024-12-03 14:40:54 --> Security Class Initialized
DEBUG - 2024-12-03 14:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:40:54 --> CSRF cookie sent
INFO - 2024-12-03 14:40:54 --> CSRF token verified
INFO - 2024-12-03 14:40:54 --> Input Class Initialized
INFO - 2024-12-03 14:40:54 --> Language Class Initialized
INFO - 2024-12-03 14:40:54 --> Loader Class Initialized
INFO - 2024-12-03 14:40:54 --> Helper loaded: url_helper
INFO - 2024-12-03 14:40:54 --> Helper loaded: form_helper
INFO - 2024-12-03 14:40:54 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:40:54 --> Form Validation Class Initialized
INFO - 2024-12-03 14:40:54 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:40:54 --> Controller Class Initialized
INFO - 2024-12-03 14:40:54 --> Model "User_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "Category_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "Review_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "News_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:40:54 --> Config Class Initialized
INFO - 2024-12-03 14:40:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:40:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:40:54 --> Utf8 Class Initialized
INFO - 2024-12-03 14:40:54 --> URI Class Initialized
INFO - 2024-12-03 14:40:54 --> Router Class Initialized
INFO - 2024-12-03 14:40:54 --> Output Class Initialized
INFO - 2024-12-03 14:40:54 --> Security Class Initialized
DEBUG - 2024-12-03 14:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:40:54 --> CSRF cookie sent
INFO - 2024-12-03 14:40:54 --> Input Class Initialized
INFO - 2024-12-03 14:40:54 --> Language Class Initialized
INFO - 2024-12-03 14:40:54 --> Loader Class Initialized
INFO - 2024-12-03 14:40:54 --> Helper loaded: url_helper
INFO - 2024-12-03 14:40:54 --> Helper loaded: form_helper
INFO - 2024-12-03 14:40:54 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:40:54 --> Form Validation Class Initialized
INFO - 2024-12-03 14:40:54 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:40:54 --> Controller Class Initialized
INFO - 2024-12-03 14:40:54 --> Model "User_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "Category_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "Review_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "News_model" initialized
INFO - 2024-12-03 14:40:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:40:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 14:40:54 --> Query result: stdClass Object
(
    [view_count] => 27
)

INFO - 2024-12-03 14:40:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 14:40:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 14:40:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-03 14:40:54 --> Final output sent to browser
DEBUG - 2024-12-03 14:40:54 --> Total execution time: 0.1969
INFO - 2024-12-03 14:40:55 --> Config Class Initialized
INFO - 2024-12-03 14:40:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:40:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:40:55 --> Utf8 Class Initialized
INFO - 2024-12-03 14:40:55 --> URI Class Initialized
INFO - 2024-12-03 14:40:55 --> Router Class Initialized
INFO - 2024-12-03 14:40:55 --> Output Class Initialized
INFO - 2024-12-03 14:40:55 --> Security Class Initialized
DEBUG - 2024-12-03 14:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:40:55 --> CSRF cookie sent
INFO - 2024-12-03 14:40:55 --> Input Class Initialized
INFO - 2024-12-03 14:40:55 --> Language Class Initialized
ERROR - 2024-12-03 14:40:55 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-03 14:42:24 --> Config Class Initialized
INFO - 2024-12-03 14:42:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:42:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:42:24 --> Utf8 Class Initialized
INFO - 2024-12-03 14:42:24 --> URI Class Initialized
INFO - 2024-12-03 14:42:24 --> Router Class Initialized
INFO - 2024-12-03 14:42:24 --> Output Class Initialized
INFO - 2024-12-03 14:42:24 --> Security Class Initialized
DEBUG - 2024-12-03 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:42:24 --> CSRF cookie sent
INFO - 2024-12-03 14:42:24 --> Input Class Initialized
INFO - 2024-12-03 14:42:24 --> Language Class Initialized
INFO - 2024-12-03 14:42:24 --> Loader Class Initialized
INFO - 2024-12-03 14:42:24 --> Helper loaded: url_helper
INFO - 2024-12-03 14:42:24 --> Helper loaded: form_helper
INFO - 2024-12-03 14:42:24 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:42:25 --> Form Validation Class Initialized
INFO - 2024-12-03 14:42:25 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:42:25 --> Controller Class Initialized
INFO - 2024-12-03 14:42:25 --> Model "Category_model" initialized
INFO - 2024-12-03 14:42:25 --> Model "User_model" initialized
INFO - 2024-12-03 14:42:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 14:42:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:42:25 --> Config Class Initialized
INFO - 2024-12-03 14:42:25 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:42:25 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:42:25 --> Utf8 Class Initialized
INFO - 2024-12-03 14:42:25 --> URI Class Initialized
INFO - 2024-12-03 14:42:25 --> Router Class Initialized
INFO - 2024-12-03 14:42:25 --> Output Class Initialized
INFO - 2024-12-03 14:42:25 --> Security Class Initialized
DEBUG - 2024-12-03 14:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:42:25 --> CSRF cookie sent
INFO - 2024-12-03 14:42:25 --> Input Class Initialized
INFO - 2024-12-03 14:42:25 --> Language Class Initialized
INFO - 2024-12-03 14:42:25 --> Loader Class Initialized
INFO - 2024-12-03 14:42:25 --> Helper loaded: url_helper
INFO - 2024-12-03 14:42:25 --> Helper loaded: form_helper
INFO - 2024-12-03 14:42:25 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:42:25 --> Form Validation Class Initialized
INFO - 2024-12-03 14:42:25 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:42:25 --> Controller Class Initialized
INFO - 2024-12-03 14:42:25 --> Model "Category_model" initialized
INFO - 2024-12-03 14:42:25 --> Model "User_model" initialized
INFO - 2024-12-03 14:42:25 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 14:42:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:42:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 14:42:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 14:42:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-03 14:42:25 --> Final output sent to browser
DEBUG - 2024-12-03 14:42:25 --> Total execution time: 0.0675
INFO - 2024-12-03 14:42:33 --> Config Class Initialized
INFO - 2024-12-03 14:42:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:42:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:42:33 --> Utf8 Class Initialized
INFO - 2024-12-03 14:42:33 --> URI Class Initialized
INFO - 2024-12-03 14:42:33 --> Router Class Initialized
INFO - 2024-12-03 14:42:33 --> Output Class Initialized
INFO - 2024-12-03 14:42:33 --> Security Class Initialized
DEBUG - 2024-12-03 14:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:42:33 --> CSRF cookie sent
INFO - 2024-12-03 14:42:33 --> Input Class Initialized
INFO - 2024-12-03 14:42:33 --> Language Class Initialized
INFO - 2024-12-03 14:42:33 --> Loader Class Initialized
INFO - 2024-12-03 14:42:33 --> Helper loaded: url_helper
INFO - 2024-12-03 14:42:33 --> Helper loaded: form_helper
INFO - 2024-12-03 14:42:33 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:42:33 --> Form Validation Class Initialized
INFO - 2024-12-03 14:42:33 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:42:33 --> Controller Class Initialized
INFO - 2024-12-03 14:42:33 --> Model "Category_model" initialized
INFO - 2024-12-03 14:42:33 --> Model "User_model" initialized
INFO - 2024-12-03 14:42:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 14:42:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:42:33 --> Config Class Initialized
INFO - 2024-12-03 14:42:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:42:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:42:33 --> Utf8 Class Initialized
INFO - 2024-12-03 14:42:33 --> URI Class Initialized
INFO - 2024-12-03 14:42:33 --> Router Class Initialized
INFO - 2024-12-03 14:42:33 --> Output Class Initialized
INFO - 2024-12-03 14:42:33 --> Security Class Initialized
DEBUG - 2024-12-03 14:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:42:33 --> CSRF cookie sent
INFO - 2024-12-03 14:42:33 --> Input Class Initialized
INFO - 2024-12-03 14:42:33 --> Language Class Initialized
INFO - 2024-12-03 14:42:33 --> Loader Class Initialized
INFO - 2024-12-03 14:42:33 --> Helper loaded: url_helper
INFO - 2024-12-03 14:42:33 --> Helper loaded: form_helper
INFO - 2024-12-03 14:42:33 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:42:33 --> Form Validation Class Initialized
INFO - 2024-12-03 14:42:33 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:42:33 --> Controller Class Initialized
INFO - 2024-12-03 14:42:33 --> Model "Category_model" initialized
INFO - 2024-12-03 14:42:33 --> Model "User_model" initialized
INFO - 2024-12-03 14:42:33 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 14:42:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:42:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-03 14:42:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-03 14:42:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-03 14:42:33 --> Final output sent to browser
DEBUG - 2024-12-03 14:42:33 --> Total execution time: 0.0934
INFO - 2024-12-03 14:42:42 --> Config Class Initialized
INFO - 2024-12-03 14:42:42 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:42:42 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:42:42 --> Utf8 Class Initialized
INFO - 2024-12-03 14:42:42 --> URI Class Initialized
INFO - 2024-12-03 14:42:42 --> Router Class Initialized
INFO - 2024-12-03 14:42:42 --> Output Class Initialized
INFO - 2024-12-03 14:42:43 --> Security Class Initialized
DEBUG - 2024-12-03 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:42:43 --> CSRF cookie sent
INFO - 2024-12-03 14:42:43 --> CSRF token verified
INFO - 2024-12-03 14:42:43 --> Input Class Initialized
INFO - 2024-12-03 14:42:43 --> Language Class Initialized
INFO - 2024-12-03 14:42:43 --> Loader Class Initialized
INFO - 2024-12-03 14:42:43 --> Helper loaded: url_helper
INFO - 2024-12-03 14:42:43 --> Helper loaded: form_helper
INFO - 2024-12-03 14:42:43 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:42:44 --> Form Validation Class Initialized
INFO - 2024-12-03 14:42:44 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:42:44 --> Controller Class Initialized
INFO - 2024-12-03 14:42:44 --> Model "User_model" initialized
INFO - 2024-12-03 14:42:44 --> Model "Category_model" initialized
INFO - 2024-12-03 14:42:44 --> Model "Review_model" initialized
INFO - 2024-12-03 14:42:44 --> Model "News_model" initialized
INFO - 2024-12-03 14:42:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:42:44 --> Config Class Initialized
INFO - 2024-12-03 14:42:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:42:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:42:44 --> Utf8 Class Initialized
INFO - 2024-12-03 14:42:44 --> URI Class Initialized
INFO - 2024-12-03 14:42:44 --> Router Class Initialized
INFO - 2024-12-03 14:42:44 --> Output Class Initialized
INFO - 2024-12-03 14:42:44 --> Security Class Initialized
DEBUG - 2024-12-03 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:42:44 --> CSRF cookie sent
INFO - 2024-12-03 14:42:44 --> Input Class Initialized
INFO - 2024-12-03 14:42:44 --> Language Class Initialized
INFO - 2024-12-03 14:42:44 --> Loader Class Initialized
INFO - 2024-12-03 14:42:44 --> Helper loaded: url_helper
INFO - 2024-12-03 14:42:44 --> Helper loaded: form_helper
INFO - 2024-12-03 14:42:44 --> Database Driver Class Initialized
DEBUG - 2024-12-03 14:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:42:45 --> Form Validation Class Initialized
INFO - 2024-12-03 14:42:45 --> Model "Culinary_model" initialized
INFO - 2024-12-03 14:42:45 --> Controller Class Initialized
INFO - 2024-12-03 14:42:45 --> Model "Category_model" initialized
INFO - 2024-12-03 14:42:45 --> Model "User_model" initialized
INFO - 2024-12-03 14:42:45 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-03 14:42:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-03 14:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-03 14:42:45 --> Query result: stdClass Object
(
    [view_count] => 27
)

INFO - 2024-12-03 14:42:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-03 14:42:45 --> Final output sent to browser
DEBUG - 2024-12-03 14:42:45 --> Total execution time: 0.6919
