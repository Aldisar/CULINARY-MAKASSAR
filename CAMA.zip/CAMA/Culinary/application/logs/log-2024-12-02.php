<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-02 02:05:09 --> Config Class Initialized
INFO - 2024-12-02 02:05:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:05:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:05:09 --> Utf8 Class Initialized
INFO - 2024-12-02 02:05:09 --> URI Class Initialized
INFO - 2024-12-02 02:05:09 --> Router Class Initialized
INFO - 2024-12-02 02:05:09 --> Output Class Initialized
INFO - 2024-12-02 02:05:09 --> Security Class Initialized
DEBUG - 2024-12-02 02:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:05:09 --> CSRF cookie sent
INFO - 2024-12-02 02:05:09 --> Input Class Initialized
INFO - 2024-12-02 02:05:09 --> Language Class Initialized
INFO - 2024-12-02 02:05:09 --> Loader Class Initialized
INFO - 2024-12-02 02:05:09 --> Helper loaded: url_helper
INFO - 2024-12-02 02:05:09 --> Helper loaded: form_helper
INFO - 2024-12-02 02:05:09 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:05:09 --> Form Validation Class Initialized
INFO - 2024-12-02 02:05:09 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:05:09 --> Controller Class Initialized
INFO - 2024-12-02 02:05:09 --> Model "User_model" initialized
INFO - 2024-12-02 02:05:09 --> Model "Category_model" initialized
INFO - 2024-12-02 02:05:09 --> Model "Review_model" initialized
INFO - 2024-12-02 02:05:09 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:05:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:05:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:05:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:05:10 --> Final output sent to browser
DEBUG - 2024-12-02 02:05:10 --> Total execution time: 0.9929
INFO - 2024-12-02 02:06:51 --> Config Class Initialized
INFO - 2024-12-02 02:06:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:06:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:06:51 --> Utf8 Class Initialized
INFO - 2024-12-02 02:06:51 --> URI Class Initialized
INFO - 2024-12-02 02:06:51 --> Router Class Initialized
INFO - 2024-12-02 02:06:51 --> Output Class Initialized
INFO - 2024-12-02 02:06:51 --> Security Class Initialized
DEBUG - 2024-12-02 02:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:06:51 --> CSRF cookie sent
INFO - 2024-12-02 02:06:51 --> Input Class Initialized
INFO - 2024-12-02 02:06:51 --> Language Class Initialized
INFO - 2024-12-02 02:06:51 --> Loader Class Initialized
INFO - 2024-12-02 02:06:51 --> Helper loaded: url_helper
INFO - 2024-12-02 02:06:51 --> Helper loaded: form_helper
INFO - 2024-12-02 02:06:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:06:51 --> Form Validation Class Initialized
INFO - 2024-12-02 02:06:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:06:51 --> Controller Class Initialized
INFO - 2024-12-02 02:06:51 --> Model "User_model" initialized
INFO - 2024-12-02 02:06:51 --> Model "Category_model" initialized
INFO - 2024-12-02 02:06:51 --> Model "Review_model" initialized
INFO - 2024-12-02 02:06:51 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:06:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:06:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:06:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:06:51 --> Final output sent to browser
DEBUG - 2024-12-02 02:06:51 --> Total execution time: 0.8213
INFO - 2024-12-02 02:13:20 --> Config Class Initialized
INFO - 2024-12-02 02:13:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:13:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:13:20 --> Utf8 Class Initialized
INFO - 2024-12-02 02:13:20 --> URI Class Initialized
INFO - 2024-12-02 02:13:20 --> Router Class Initialized
INFO - 2024-12-02 02:13:20 --> Output Class Initialized
INFO - 2024-12-02 02:13:20 --> Security Class Initialized
DEBUG - 2024-12-02 02:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:13:20 --> CSRF cookie sent
INFO - 2024-12-02 02:13:20 --> Input Class Initialized
INFO - 2024-12-02 02:13:20 --> Language Class Initialized
INFO - 2024-12-02 02:13:20 --> Loader Class Initialized
INFO - 2024-12-02 02:13:20 --> Helper loaded: url_helper
INFO - 2024-12-02 02:13:20 --> Helper loaded: form_helper
INFO - 2024-12-02 02:13:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:13:20 --> Form Validation Class Initialized
INFO - 2024-12-02 02:13:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:13:20 --> Controller Class Initialized
INFO - 2024-12-02 02:13:21 --> Model "User_model" initialized
INFO - 2024-12-02 02:13:21 --> Model "Category_model" initialized
INFO - 2024-12-02 02:13:21 --> Model "Review_model" initialized
INFO - 2024-12-02 02:13:21 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:13:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:13:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:13:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:13:21 --> Final output sent to browser
DEBUG - 2024-12-02 02:13:21 --> Total execution time: 0.4797
INFO - 2024-12-02 02:18:31 --> Config Class Initialized
INFO - 2024-12-02 02:18:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:18:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:18:31 --> Utf8 Class Initialized
INFO - 2024-12-02 02:18:31 --> URI Class Initialized
INFO - 2024-12-02 02:18:31 --> Router Class Initialized
INFO - 2024-12-02 02:18:31 --> Output Class Initialized
INFO - 2024-12-02 02:18:31 --> Security Class Initialized
DEBUG - 2024-12-02 02:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:18:31 --> CSRF cookie sent
INFO - 2024-12-02 02:18:31 --> Input Class Initialized
INFO - 2024-12-02 02:18:31 --> Language Class Initialized
INFO - 2024-12-02 02:18:31 --> Loader Class Initialized
INFO - 2024-12-02 02:18:31 --> Helper loaded: url_helper
INFO - 2024-12-02 02:18:31 --> Helper loaded: form_helper
INFO - 2024-12-02 02:18:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:18:31 --> Form Validation Class Initialized
INFO - 2024-12-02 02:18:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:18:31 --> Controller Class Initialized
INFO - 2024-12-02 02:18:31 --> Model "User_model" initialized
INFO - 2024-12-02 02:18:31 --> Model "Category_model" initialized
INFO - 2024-12-02 02:18:31 --> Model "Review_model" initialized
INFO - 2024-12-02 02:18:31 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:18:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:18:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:18:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:18:32 --> Final output sent to browser
DEBUG - 2024-12-02 02:18:32 --> Total execution time: 0.6566
INFO - 2024-12-02 02:20:00 --> Config Class Initialized
INFO - 2024-12-02 02:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:20:00 --> Utf8 Class Initialized
INFO - 2024-12-02 02:20:00 --> URI Class Initialized
INFO - 2024-12-02 02:20:00 --> Router Class Initialized
INFO - 2024-12-02 02:20:00 --> Output Class Initialized
INFO - 2024-12-02 02:20:00 --> Security Class Initialized
DEBUG - 2024-12-02 02:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:20:00 --> CSRF cookie sent
INFO - 2024-12-02 02:20:00 --> Input Class Initialized
INFO - 2024-12-02 02:20:00 --> Language Class Initialized
INFO - 2024-12-02 02:20:00 --> Loader Class Initialized
INFO - 2024-12-02 02:20:00 --> Helper loaded: url_helper
INFO - 2024-12-02 02:20:00 --> Helper loaded: form_helper
INFO - 2024-12-02 02:20:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:20:00 --> Form Validation Class Initialized
INFO - 2024-12-02 02:20:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:20:00 --> Controller Class Initialized
INFO - 2024-12-02 02:20:00 --> Model "User_model" initialized
INFO - 2024-12-02 02:20:00 --> Model "Category_model" initialized
INFO - 2024-12-02 02:20:00 --> Model "Review_model" initialized
INFO - 2024-12-02 02:20:00 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:20:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:20:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:20:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:20:00 --> Final output sent to browser
DEBUG - 2024-12-02 02:20:00 --> Total execution time: 0.3555
INFO - 2024-12-02 02:20:44 --> Config Class Initialized
INFO - 2024-12-02 02:20:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:20:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:20:44 --> Utf8 Class Initialized
INFO - 2024-12-02 02:20:44 --> URI Class Initialized
INFO - 2024-12-02 02:20:44 --> Router Class Initialized
INFO - 2024-12-02 02:20:44 --> Output Class Initialized
INFO - 2024-12-02 02:20:44 --> Security Class Initialized
DEBUG - 2024-12-02 02:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:20:44 --> CSRF cookie sent
INFO - 2024-12-02 02:20:44 --> Input Class Initialized
INFO - 2024-12-02 02:20:44 --> Language Class Initialized
INFO - 2024-12-02 02:20:44 --> Loader Class Initialized
INFO - 2024-12-02 02:20:44 --> Helper loaded: url_helper
INFO - 2024-12-02 02:20:44 --> Helper loaded: form_helper
INFO - 2024-12-02 02:20:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:20:44 --> Form Validation Class Initialized
INFO - 2024-12-02 02:20:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:20:44 --> Controller Class Initialized
INFO - 2024-12-02 02:20:44 --> Model "User_model" initialized
INFO - 2024-12-02 02:20:44 --> Model "Category_model" initialized
INFO - 2024-12-02 02:20:44 --> Model "Review_model" initialized
INFO - 2024-12-02 02:20:44 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:20:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:20:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:20:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:20:44 --> Final output sent to browser
DEBUG - 2024-12-02 02:20:44 --> Total execution time: 0.0827
INFO - 2024-12-02 02:21:15 --> Config Class Initialized
INFO - 2024-12-02 02:21:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:21:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:21:15 --> Utf8 Class Initialized
INFO - 2024-12-02 02:21:15 --> URI Class Initialized
INFO - 2024-12-02 02:21:15 --> Router Class Initialized
INFO - 2024-12-02 02:21:15 --> Output Class Initialized
INFO - 2024-12-02 02:21:15 --> Security Class Initialized
DEBUG - 2024-12-02 02:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:21:15 --> CSRF cookie sent
INFO - 2024-12-02 02:21:15 --> Input Class Initialized
INFO - 2024-12-02 02:21:15 --> Language Class Initialized
INFO - 2024-12-02 02:21:15 --> Loader Class Initialized
INFO - 2024-12-02 02:21:15 --> Helper loaded: url_helper
INFO - 2024-12-02 02:21:15 --> Helper loaded: form_helper
INFO - 2024-12-02 02:21:15 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:21:15 --> Form Validation Class Initialized
INFO - 2024-12-02 02:21:15 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:21:15 --> Controller Class Initialized
INFO - 2024-12-02 02:21:15 --> Model "User_model" initialized
INFO - 2024-12-02 02:21:15 --> Model "Category_model" initialized
INFO - 2024-12-02 02:21:15 --> Model "Review_model" initialized
INFO - 2024-12-02 02:21:15 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:21:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:21:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:21:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:21:15 --> Final output sent to browser
DEBUG - 2024-12-02 02:21:15 --> Total execution time: 0.1188
INFO - 2024-12-02 02:24:19 --> Config Class Initialized
INFO - 2024-12-02 02:24:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:24:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:24:20 --> Utf8 Class Initialized
INFO - 2024-12-02 02:24:20 --> URI Class Initialized
INFO - 2024-12-02 02:24:20 --> Router Class Initialized
INFO - 2024-12-02 02:24:20 --> Output Class Initialized
INFO - 2024-12-02 02:24:20 --> Security Class Initialized
DEBUG - 2024-12-02 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:24:20 --> CSRF cookie sent
INFO - 2024-12-02 02:24:20 --> Input Class Initialized
INFO - 2024-12-02 02:24:20 --> Language Class Initialized
INFO - 2024-12-02 02:24:20 --> Loader Class Initialized
INFO - 2024-12-02 02:24:20 --> Helper loaded: url_helper
INFO - 2024-12-02 02:24:20 --> Helper loaded: form_helper
INFO - 2024-12-02 02:24:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:24:20 --> Form Validation Class Initialized
INFO - 2024-12-02 02:24:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:24:20 --> Controller Class Initialized
INFO - 2024-12-02 02:24:20 --> Model "User_model" initialized
INFO - 2024-12-02 02:24:20 --> Model "Category_model" initialized
INFO - 2024-12-02 02:24:20 --> Model "Review_model" initialized
INFO - 2024-12-02 02:24:20 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:24:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:24:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:24:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:24:20 --> Final output sent to browser
DEBUG - 2024-12-02 02:24:20 --> Total execution time: 0.4812
INFO - 2024-12-02 02:24:21 --> Config Class Initialized
INFO - 2024-12-02 02:24:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:24:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:24:21 --> Utf8 Class Initialized
INFO - 2024-12-02 02:24:21 --> URI Class Initialized
INFO - 2024-12-02 02:24:21 --> Router Class Initialized
INFO - 2024-12-02 02:24:21 --> Output Class Initialized
INFO - 2024-12-02 02:24:21 --> Security Class Initialized
DEBUG - 2024-12-02 02:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:24:21 --> CSRF cookie sent
INFO - 2024-12-02 02:24:21 --> Input Class Initialized
INFO - 2024-12-02 02:24:21 --> Language Class Initialized
ERROR - 2024-12-02 02:24:21 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:25:03 --> Config Class Initialized
INFO - 2024-12-02 02:25:03 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:25:03 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:25:03 --> Utf8 Class Initialized
INFO - 2024-12-02 02:25:03 --> URI Class Initialized
INFO - 2024-12-02 02:25:03 --> Router Class Initialized
INFO - 2024-12-02 02:25:03 --> Output Class Initialized
INFO - 2024-12-02 02:25:03 --> Security Class Initialized
DEBUG - 2024-12-02 02:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:25:03 --> CSRF cookie sent
INFO - 2024-12-02 02:25:03 --> Input Class Initialized
INFO - 2024-12-02 02:25:03 --> Language Class Initialized
INFO - 2024-12-02 02:25:03 --> Loader Class Initialized
INFO - 2024-12-02 02:25:03 --> Helper loaded: url_helper
INFO - 2024-12-02 02:25:03 --> Helper loaded: form_helper
INFO - 2024-12-02 02:25:03 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:25:03 --> Form Validation Class Initialized
INFO - 2024-12-02 02:25:03 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:25:03 --> Controller Class Initialized
INFO - 2024-12-02 02:25:03 --> Model "User_model" initialized
INFO - 2024-12-02 02:25:03 --> Model "Category_model" initialized
INFO - 2024-12-02 02:25:03 --> Model "Review_model" initialized
INFO - 2024-12-02 02:25:03 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:25:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:25:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:25:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:25:03 --> Final output sent to browser
DEBUG - 2024-12-02 02:25:03 --> Total execution time: 0.3444
INFO - 2024-12-02 02:25:04 --> Config Class Initialized
INFO - 2024-12-02 02:25:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:25:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:25:04 --> Utf8 Class Initialized
INFO - 2024-12-02 02:25:04 --> URI Class Initialized
INFO - 2024-12-02 02:25:04 --> Router Class Initialized
INFO - 2024-12-02 02:25:04 --> Output Class Initialized
INFO - 2024-12-02 02:25:04 --> Security Class Initialized
DEBUG - 2024-12-02 02:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:25:04 --> CSRF cookie sent
INFO - 2024-12-02 02:25:04 --> Input Class Initialized
INFO - 2024-12-02 02:25:04 --> Language Class Initialized
ERROR - 2024-12-02 02:25:04 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:28:46 --> Config Class Initialized
INFO - 2024-12-02 02:28:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:28:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:28:46 --> Utf8 Class Initialized
INFO - 2024-12-02 02:28:46 --> URI Class Initialized
INFO - 2024-12-02 02:28:46 --> Router Class Initialized
INFO - 2024-12-02 02:28:46 --> Output Class Initialized
INFO - 2024-12-02 02:28:46 --> Security Class Initialized
DEBUG - 2024-12-02 02:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:28:46 --> CSRF cookie sent
INFO - 2024-12-02 02:28:46 --> Input Class Initialized
INFO - 2024-12-02 02:28:46 --> Language Class Initialized
INFO - 2024-12-02 02:28:46 --> Loader Class Initialized
INFO - 2024-12-02 02:28:46 --> Helper loaded: url_helper
INFO - 2024-12-02 02:28:46 --> Helper loaded: form_helper
INFO - 2024-12-02 02:28:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:28:47 --> Form Validation Class Initialized
INFO - 2024-12-02 02:28:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:28:47 --> Controller Class Initialized
INFO - 2024-12-02 02:28:47 --> Model "User_model" initialized
INFO - 2024-12-02 02:28:47 --> Model "Category_model" initialized
INFO - 2024-12-02 02:28:47 --> Model "Review_model" initialized
INFO - 2024-12-02 02:28:47 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:28:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:28:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:28:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:28:47 --> Final output sent to browser
DEBUG - 2024-12-02 02:28:47 --> Total execution time: 0.6788
INFO - 2024-12-02 02:28:48 --> Config Class Initialized
INFO - 2024-12-02 02:28:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:28:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:28:48 --> Utf8 Class Initialized
INFO - 2024-12-02 02:28:48 --> URI Class Initialized
INFO - 2024-12-02 02:28:48 --> Router Class Initialized
INFO - 2024-12-02 02:28:48 --> Output Class Initialized
INFO - 2024-12-02 02:28:48 --> Security Class Initialized
DEBUG - 2024-12-02 02:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:28:48 --> CSRF cookie sent
INFO - 2024-12-02 02:28:48 --> Input Class Initialized
INFO - 2024-12-02 02:28:48 --> Language Class Initialized
ERROR - 2024-12-02 02:28:48 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:31:26 --> Config Class Initialized
INFO - 2024-12-02 02:31:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:31:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:31:26 --> Utf8 Class Initialized
INFO - 2024-12-02 02:31:26 --> URI Class Initialized
INFO - 2024-12-02 02:31:26 --> Router Class Initialized
INFO - 2024-12-02 02:31:26 --> Output Class Initialized
INFO - 2024-12-02 02:31:26 --> Security Class Initialized
DEBUG - 2024-12-02 02:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:31:26 --> CSRF cookie sent
INFO - 2024-12-02 02:31:26 --> Input Class Initialized
INFO - 2024-12-02 02:31:26 --> Language Class Initialized
INFO - 2024-12-02 02:31:26 --> Loader Class Initialized
INFO - 2024-12-02 02:31:26 --> Helper loaded: url_helper
INFO - 2024-12-02 02:31:26 --> Helper loaded: form_helper
INFO - 2024-12-02 02:31:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:31:26 --> Form Validation Class Initialized
INFO - 2024-12-02 02:31:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:31:26 --> Controller Class Initialized
INFO - 2024-12-02 02:31:26 --> Model "User_model" initialized
INFO - 2024-12-02 02:31:26 --> Model "Category_model" initialized
INFO - 2024-12-02 02:31:26 --> Model "Review_model" initialized
INFO - 2024-12-02 02:31:26 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:31:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:31:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:31:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:31:26 --> Final output sent to browser
DEBUG - 2024-12-02 02:31:26 --> Total execution time: 0.4371
INFO - 2024-12-02 02:31:27 --> Config Class Initialized
INFO - 2024-12-02 02:31:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:31:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:31:27 --> Utf8 Class Initialized
INFO - 2024-12-02 02:31:27 --> URI Class Initialized
INFO - 2024-12-02 02:31:27 --> Router Class Initialized
INFO - 2024-12-02 02:31:28 --> Output Class Initialized
INFO - 2024-12-02 02:31:28 --> Security Class Initialized
DEBUG - 2024-12-02 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:31:28 --> CSRF cookie sent
INFO - 2024-12-02 02:31:28 --> Input Class Initialized
INFO - 2024-12-02 02:31:28 --> Language Class Initialized
ERROR - 2024-12-02 02:31:28 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:34:42 --> Config Class Initialized
INFO - 2024-12-02 02:34:42 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:34:42 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:34:42 --> Utf8 Class Initialized
INFO - 2024-12-02 02:34:42 --> URI Class Initialized
INFO - 2024-12-02 02:34:42 --> Router Class Initialized
INFO - 2024-12-02 02:34:42 --> Output Class Initialized
INFO - 2024-12-02 02:34:42 --> Security Class Initialized
DEBUG - 2024-12-02 02:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:34:42 --> CSRF cookie sent
INFO - 2024-12-02 02:34:42 --> Input Class Initialized
INFO - 2024-12-02 02:34:42 --> Language Class Initialized
INFO - 2024-12-02 02:34:42 --> Loader Class Initialized
INFO - 2024-12-02 02:34:42 --> Helper loaded: url_helper
INFO - 2024-12-02 02:34:42 --> Helper loaded: form_helper
INFO - 2024-12-02 02:34:42 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:34:42 --> Form Validation Class Initialized
INFO - 2024-12-02 02:34:42 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:34:42 --> Controller Class Initialized
INFO - 2024-12-02 02:34:42 --> Model "User_model" initialized
INFO - 2024-12-02 02:34:42 --> Model "Category_model" initialized
INFO - 2024-12-02 02:34:42 --> Model "Review_model" initialized
INFO - 2024-12-02 02:34:42 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:34:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:34:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:34:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:34:43 --> Final output sent to browser
DEBUG - 2024-12-02 02:34:43 --> Total execution time: 0.7236
INFO - 2024-12-02 02:34:43 --> Config Class Initialized
INFO - 2024-12-02 02:34:43 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:34:43 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:34:43 --> Utf8 Class Initialized
INFO - 2024-12-02 02:34:43 --> URI Class Initialized
INFO - 2024-12-02 02:34:43 --> Router Class Initialized
INFO - 2024-12-02 02:34:43 --> Output Class Initialized
INFO - 2024-12-02 02:34:43 --> Security Class Initialized
DEBUG - 2024-12-02 02:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:34:43 --> CSRF cookie sent
INFO - 2024-12-02 02:34:43 --> Input Class Initialized
INFO - 2024-12-02 02:34:43 --> Language Class Initialized
ERROR - 2024-12-02 02:34:43 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:38:20 --> Config Class Initialized
INFO - 2024-12-02 02:38:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:20 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:20 --> URI Class Initialized
INFO - 2024-12-02 02:38:20 --> Router Class Initialized
INFO - 2024-12-02 02:38:20 --> Output Class Initialized
INFO - 2024-12-02 02:38:20 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:20 --> CSRF cookie sent
INFO - 2024-12-02 02:38:20 --> Input Class Initialized
INFO - 2024-12-02 02:38:20 --> Language Class Initialized
INFO - 2024-12-02 02:38:20 --> Loader Class Initialized
INFO - 2024-12-02 02:38:20 --> Helper loaded: url_helper
INFO - 2024-12-02 02:38:20 --> Helper loaded: form_helper
INFO - 2024-12-02 02:38:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:38:20 --> Form Validation Class Initialized
INFO - 2024-12-02 02:38:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:38:20 --> Controller Class Initialized
INFO - 2024-12-02 02:38:20 --> Model "User_model" initialized
INFO - 2024-12-02 02:38:20 --> Model "Category_model" initialized
INFO - 2024-12-02 02:38:20 --> Model "Review_model" initialized
INFO - 2024-12-02 02:38:20 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:38:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:38:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:38:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:38:20 --> Final output sent to browser
DEBUG - 2024-12-02 02:38:20 --> Total execution time: 0.3282
INFO - 2024-12-02 02:38:25 --> Config Class Initialized
INFO - 2024-12-02 02:38:25 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:25 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:25 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:25 --> URI Class Initialized
INFO - 2024-12-02 02:38:25 --> Router Class Initialized
INFO - 2024-12-02 02:38:25 --> Output Class Initialized
INFO - 2024-12-02 02:38:25 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:25 --> CSRF cookie sent
INFO - 2024-12-02 02:38:25 --> Input Class Initialized
INFO - 2024-12-02 02:38:25 --> Language Class Initialized
INFO - 2024-12-02 02:38:25 --> Loader Class Initialized
INFO - 2024-12-02 02:38:25 --> Helper loaded: url_helper
INFO - 2024-12-02 02:38:25 --> Helper loaded: form_helper
INFO - 2024-12-02 02:38:25 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:38:25 --> Form Validation Class Initialized
INFO - 2024-12-02 02:38:25 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:38:25 --> Controller Class Initialized
INFO - 2024-12-02 02:38:25 --> Model "User_model" initialized
INFO - 2024-12-02 02:38:25 --> Model "Category_model" initialized
INFO - 2024-12-02 02:38:25 --> Model "Review_model" initialized
INFO - 2024-12-02 02:38:25 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:38:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:38:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:38:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 02:38:25 --> Final output sent to browser
DEBUG - 2024-12-02 02:38:25 --> Total execution time: 0.0623
INFO - 2024-12-02 02:38:30 --> Config Class Initialized
INFO - 2024-12-02 02:38:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:30 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:30 --> URI Class Initialized
INFO - 2024-12-02 02:38:30 --> Router Class Initialized
INFO - 2024-12-02 02:38:30 --> Output Class Initialized
INFO - 2024-12-02 02:38:30 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:30 --> CSRF cookie sent
INFO - 2024-12-02 02:38:30 --> CSRF token verified
INFO - 2024-12-02 02:38:30 --> Input Class Initialized
INFO - 2024-12-02 02:38:30 --> Language Class Initialized
INFO - 2024-12-02 02:38:30 --> Loader Class Initialized
INFO - 2024-12-02 02:38:30 --> Helper loaded: url_helper
INFO - 2024-12-02 02:38:30 --> Helper loaded: form_helper
INFO - 2024-12-02 02:38:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:38:30 --> Form Validation Class Initialized
INFO - 2024-12-02 02:38:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:38:30 --> Controller Class Initialized
INFO - 2024-12-02 02:38:30 --> Model "User_model" initialized
INFO - 2024-12-02 02:38:30 --> Model "Category_model" initialized
INFO - 2024-12-02 02:38:30 --> Model "Review_model" initialized
INFO - 2024-12-02 02:38:30 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:38:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:38:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:38:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 02:38:30 --> Final output sent to browser
DEBUG - 2024-12-02 02:38:30 --> Total execution time: 0.1313
INFO - 2024-12-02 02:38:36 --> Config Class Initialized
INFO - 2024-12-02 02:38:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:36 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:36 --> URI Class Initialized
INFO - 2024-12-02 02:38:36 --> Router Class Initialized
INFO - 2024-12-02 02:38:36 --> Output Class Initialized
INFO - 2024-12-02 02:38:36 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:36 --> CSRF cookie sent
INFO - 2024-12-02 02:38:36 --> CSRF token verified
INFO - 2024-12-02 02:38:36 --> Input Class Initialized
INFO - 2024-12-02 02:38:36 --> Language Class Initialized
INFO - 2024-12-02 02:38:36 --> Loader Class Initialized
INFO - 2024-12-02 02:38:36 --> Helper loaded: url_helper
INFO - 2024-12-02 02:38:36 --> Helper loaded: form_helper
INFO - 2024-12-02 02:38:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:38:36 --> Form Validation Class Initialized
INFO - 2024-12-02 02:38:36 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:38:36 --> Controller Class Initialized
INFO - 2024-12-02 02:38:36 --> Model "User_model" initialized
INFO - 2024-12-02 02:38:36 --> Model "Category_model" initialized
INFO - 2024-12-02 02:38:36 --> Model "Review_model" initialized
INFO - 2024-12-02 02:38:36 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:38:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:38:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:38:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 02:38:36 --> Final output sent to browser
DEBUG - 2024-12-02 02:38:36 --> Total execution time: 0.0953
INFO - 2024-12-02 02:38:47 --> Config Class Initialized
INFO - 2024-12-02 02:38:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:47 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:47 --> URI Class Initialized
INFO - 2024-12-02 02:38:47 --> Router Class Initialized
INFO - 2024-12-02 02:38:47 --> Output Class Initialized
INFO - 2024-12-02 02:38:47 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:47 --> CSRF cookie sent
INFO - 2024-12-02 02:38:47 --> CSRF token verified
INFO - 2024-12-02 02:38:47 --> Input Class Initialized
INFO - 2024-12-02 02:38:47 --> Language Class Initialized
INFO - 2024-12-02 02:38:47 --> Loader Class Initialized
INFO - 2024-12-02 02:38:47 --> Helper loaded: url_helper
INFO - 2024-12-02 02:38:47 --> Helper loaded: form_helper
INFO - 2024-12-02 02:38:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:38:47 --> Form Validation Class Initialized
INFO - 2024-12-02 02:38:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:38:47 --> Controller Class Initialized
INFO - 2024-12-02 02:38:47 --> Model "User_model" initialized
INFO - 2024-12-02 02:38:47 --> Model "Category_model" initialized
INFO - 2024-12-02 02:38:47 --> Model "Review_model" initialized
INFO - 2024-12-02 02:38:47 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:38:47 --> Config Class Initialized
INFO - 2024-12-02 02:38:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:47 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:47 --> URI Class Initialized
INFO - 2024-12-02 02:38:47 --> Router Class Initialized
INFO - 2024-12-02 02:38:47 --> Output Class Initialized
INFO - 2024-12-02 02:38:47 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:47 --> CSRF cookie sent
INFO - 2024-12-02 02:38:47 --> Input Class Initialized
INFO - 2024-12-02 02:38:47 --> Language Class Initialized
INFO - 2024-12-02 02:38:47 --> Loader Class Initialized
INFO - 2024-12-02 02:38:47 --> Helper loaded: url_helper
INFO - 2024-12-02 02:38:47 --> Helper loaded: form_helper
INFO - 2024-12-02 02:38:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:38:47 --> Form Validation Class Initialized
INFO - 2024-12-02 02:38:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:38:47 --> Controller Class Initialized
INFO - 2024-12-02 02:38:47 --> Model "User_model" initialized
INFO - 2024-12-02 02:38:47 --> Model "Category_model" initialized
INFO - 2024-12-02 02:38:47 --> Model "Review_model" initialized
INFO - 2024-12-02 02:38:47 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:38:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:38:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:38:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:38:47 --> Final output sent to browser
DEBUG - 2024-12-02 02:38:47 --> Total execution time: 0.0528
INFO - 2024-12-02 02:38:47 --> Config Class Initialized
INFO - 2024-12-02 02:38:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:38:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:38:47 --> Utf8 Class Initialized
INFO - 2024-12-02 02:38:47 --> URI Class Initialized
INFO - 2024-12-02 02:38:47 --> Router Class Initialized
INFO - 2024-12-02 02:38:47 --> Output Class Initialized
INFO - 2024-12-02 02:38:47 --> Security Class Initialized
DEBUG - 2024-12-02 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:38:47 --> CSRF cookie sent
INFO - 2024-12-02 02:38:47 --> Input Class Initialized
INFO - 2024-12-02 02:38:47 --> Language Class Initialized
ERROR - 2024-12-02 02:38:47 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:39:01 --> Config Class Initialized
INFO - 2024-12-02 02:39:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:39:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:39:01 --> Utf8 Class Initialized
INFO - 2024-12-02 02:39:01 --> URI Class Initialized
INFO - 2024-12-02 02:39:01 --> Router Class Initialized
INFO - 2024-12-02 02:39:01 --> Output Class Initialized
INFO - 2024-12-02 02:39:01 --> Security Class Initialized
DEBUG - 2024-12-02 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:39:01 --> CSRF cookie sent
INFO - 2024-12-02 02:39:01 --> Input Class Initialized
INFO - 2024-12-02 02:39:01 --> Language Class Initialized
INFO - 2024-12-02 02:39:01 --> Loader Class Initialized
INFO - 2024-12-02 02:39:01 --> Helper loaded: url_helper
INFO - 2024-12-02 02:39:01 --> Helper loaded: form_helper
INFO - 2024-12-02 02:39:01 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:39:01 --> Form Validation Class Initialized
INFO - 2024-12-02 02:39:01 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:39:01 --> Controller Class Initialized
INFO - 2024-12-02 02:39:01 --> Model "User_model" initialized
INFO - 2024-12-02 02:39:01 --> Model "Category_model" initialized
INFO - 2024-12-02 02:39:01 --> Model "Review_model" initialized
INFO - 2024-12-02 02:39:01 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:39:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:39:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:39:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:39:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:39:01 --> Final output sent to browser
DEBUG - 2024-12-02 02:39:01 --> Total execution time: 0.0724
INFO - 2024-12-02 02:39:15 --> Config Class Initialized
INFO - 2024-12-02 02:39:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:39:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:39:15 --> Utf8 Class Initialized
INFO - 2024-12-02 02:39:15 --> URI Class Initialized
INFO - 2024-12-02 02:39:15 --> Router Class Initialized
INFO - 2024-12-02 02:39:15 --> Output Class Initialized
INFO - 2024-12-02 02:39:15 --> Security Class Initialized
DEBUG - 2024-12-02 02:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:39:15 --> CSRF cookie sent
INFO - 2024-12-02 02:39:40 --> Config Class Initialized
INFO - 2024-12-02 02:39:40 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:39:40 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:39:40 --> Utf8 Class Initialized
INFO - 2024-12-02 02:39:40 --> URI Class Initialized
INFO - 2024-12-02 02:39:40 --> Router Class Initialized
INFO - 2024-12-02 02:39:40 --> Output Class Initialized
INFO - 2024-12-02 02:39:40 --> Security Class Initialized
DEBUG - 2024-12-02 02:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:39:40 --> CSRF cookie sent
INFO - 2024-12-02 02:39:40 --> Input Class Initialized
INFO - 2024-12-02 02:39:40 --> Language Class Initialized
INFO - 2024-12-02 02:39:40 --> Loader Class Initialized
INFO - 2024-12-02 02:39:40 --> Helper loaded: url_helper
INFO - 2024-12-02 02:39:40 --> Helper loaded: form_helper
INFO - 2024-12-02 02:39:40 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:39:40 --> Form Validation Class Initialized
INFO - 2024-12-02 02:39:40 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:39:40 --> Controller Class Initialized
INFO - 2024-12-02 02:39:40 --> Model "User_model" initialized
INFO - 2024-12-02 02:39:40 --> Model "Category_model" initialized
INFO - 2024-12-02 02:39:40 --> Model "Review_model" initialized
INFO - 2024-12-02 02:39:40 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:39:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:39:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:39:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:39:41 --> Final output sent to browser
DEBUG - 2024-12-02 02:39:41 --> Total execution time: 0.2880
INFO - 2024-12-02 02:41:32 --> Config Class Initialized
INFO - 2024-12-02 02:41:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:41:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:41:32 --> Utf8 Class Initialized
INFO - 2024-12-02 02:41:32 --> URI Class Initialized
INFO - 2024-12-02 02:41:32 --> Router Class Initialized
INFO - 2024-12-02 02:41:32 --> Output Class Initialized
INFO - 2024-12-02 02:41:32 --> Security Class Initialized
DEBUG - 2024-12-02 02:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:41:32 --> CSRF cookie sent
INFO - 2024-12-02 02:48:28 --> Config Class Initialized
INFO - 2024-12-02 02:48:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:48:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:48:28 --> Utf8 Class Initialized
INFO - 2024-12-02 02:48:28 --> URI Class Initialized
INFO - 2024-12-02 02:48:28 --> Router Class Initialized
INFO - 2024-12-02 02:48:28 --> Output Class Initialized
INFO - 2024-12-02 02:48:28 --> Security Class Initialized
DEBUG - 2024-12-02 02:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:48:28 --> CSRF cookie sent
INFO - 2024-12-02 02:48:28 --> Input Class Initialized
INFO - 2024-12-02 02:48:28 --> Language Class Initialized
INFO - 2024-12-02 02:48:28 --> Loader Class Initialized
INFO - 2024-12-02 02:48:28 --> Helper loaded: url_helper
INFO - 2024-12-02 02:48:28 --> Helper loaded: form_helper
INFO - 2024-12-02 02:48:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:48:28 --> Form Validation Class Initialized
INFO - 2024-12-02 02:48:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:48:28 --> Controller Class Initialized
INFO - 2024-12-02 02:48:28 --> Model "User_model" initialized
INFO - 2024-12-02 02:48:28 --> Model "Category_model" initialized
INFO - 2024-12-02 02:48:28 --> Model "Review_model" initialized
INFO - 2024-12-02 02:48:28 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:48:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:48:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:48:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:48:29 --> Final output sent to browser
DEBUG - 2024-12-02 02:48:29 --> Total execution time: 0.2476
INFO - 2024-12-02 02:48:34 --> Config Class Initialized
INFO - 2024-12-02 02:48:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:48:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:48:34 --> Utf8 Class Initialized
INFO - 2024-12-02 02:48:34 --> URI Class Initialized
INFO - 2024-12-02 02:48:34 --> Router Class Initialized
INFO - 2024-12-02 02:48:34 --> Output Class Initialized
INFO - 2024-12-02 02:48:34 --> Security Class Initialized
DEBUG - 2024-12-02 02:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:48:34 --> CSRF cookie sent
INFO - 2024-12-02 02:50:12 --> Config Class Initialized
INFO - 2024-12-02 02:50:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:50:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:50:12 --> Utf8 Class Initialized
INFO - 2024-12-02 02:50:12 --> URI Class Initialized
INFO - 2024-12-02 02:50:12 --> Router Class Initialized
INFO - 2024-12-02 02:50:12 --> Output Class Initialized
INFO - 2024-12-02 02:50:12 --> Security Class Initialized
DEBUG - 2024-12-02 02:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:50:12 --> CSRF cookie sent
INFO - 2024-12-02 02:50:12 --> Input Class Initialized
INFO - 2024-12-02 02:50:12 --> Language Class Initialized
INFO - 2024-12-02 02:50:12 --> Loader Class Initialized
INFO - 2024-12-02 02:50:12 --> Helper loaded: url_helper
INFO - 2024-12-02 02:50:12 --> Helper loaded: form_helper
INFO - 2024-12-02 02:50:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:50:13 --> Form Validation Class Initialized
INFO - 2024-12-02 02:50:13 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:50:13 --> Controller Class Initialized
INFO - 2024-12-02 02:50:13 --> Model "User_model" initialized
INFO - 2024-12-02 02:50:13 --> Model "Category_model" initialized
INFO - 2024-12-02 02:50:13 --> Model "Review_model" initialized
INFO - 2024-12-02 02:50:13 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:50:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:50:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:50:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:50:13 --> Final output sent to browser
DEBUG - 2024-12-02 02:50:13 --> Total execution time: 0.5177
INFO - 2024-12-02 02:50:17 --> Config Class Initialized
INFO - 2024-12-02 02:50:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:50:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:50:17 --> Utf8 Class Initialized
INFO - 2024-12-02 02:50:17 --> URI Class Initialized
INFO - 2024-12-02 02:50:17 --> Router Class Initialized
INFO - 2024-12-02 02:50:17 --> Output Class Initialized
INFO - 2024-12-02 02:50:17 --> Security Class Initialized
DEBUG - 2024-12-02 02:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:50:17 --> CSRF cookie sent
INFO - 2024-12-02 02:50:17 --> Input Class Initialized
INFO - 2024-12-02 02:50:17 --> Language Class Initialized
INFO - 2024-12-02 02:50:17 --> Loader Class Initialized
INFO - 2024-12-02 02:50:17 --> Helper loaded: url_helper
INFO - 2024-12-02 02:50:17 --> Helper loaded: form_helper
INFO - 2024-12-02 02:50:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:50:17 --> Form Validation Class Initialized
INFO - 2024-12-02 02:50:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:50:17 --> Controller Class Initialized
INFO - 2024-12-02 02:50:17 --> Model "User_model" initialized
INFO - 2024-12-02 02:50:17 --> Model "Category_model" initialized
INFO - 2024-12-02 02:50:17 --> Model "Review_model" initialized
INFO - 2024-12-02 02:50:17 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:50:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:50:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:50:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:50:17 --> Final output sent to browser
DEBUG - 2024-12-02 02:50:17 --> Total execution time: 0.1179
INFO - 2024-12-02 02:50:27 --> Config Class Initialized
INFO - 2024-12-02 02:50:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:50:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:50:27 --> Utf8 Class Initialized
INFO - 2024-12-02 02:50:27 --> URI Class Initialized
INFO - 2024-12-02 02:50:27 --> Router Class Initialized
INFO - 2024-12-02 02:50:27 --> Output Class Initialized
INFO - 2024-12-02 02:50:27 --> Security Class Initialized
DEBUG - 2024-12-02 02:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:50:27 --> CSRF cookie sent
INFO - 2024-12-02 02:50:27 --> CSRF token verified
INFO - 2024-12-02 02:50:27 --> Input Class Initialized
INFO - 2024-12-02 02:50:27 --> Language Class Initialized
INFO - 2024-12-02 02:50:27 --> Loader Class Initialized
INFO - 2024-12-02 02:50:27 --> Helper loaded: url_helper
INFO - 2024-12-02 02:50:27 --> Helper loaded: form_helper
INFO - 2024-12-02 02:50:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:50:27 --> Form Validation Class Initialized
INFO - 2024-12-02 02:50:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:50:27 --> Controller Class Initialized
INFO - 2024-12-02 02:50:27 --> Model "User_model" initialized
INFO - 2024-12-02 02:50:27 --> Model "Category_model" initialized
INFO - 2024-12-02 02:50:27 --> Model "Review_model" initialized
INFO - 2024-12-02 02:50:27 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:50:27 --> Config Class Initialized
INFO - 2024-12-02 02:50:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:50:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:50:27 --> Utf8 Class Initialized
INFO - 2024-12-02 02:50:27 --> URI Class Initialized
INFO - 2024-12-02 02:50:27 --> Router Class Initialized
INFO - 2024-12-02 02:50:27 --> Output Class Initialized
INFO - 2024-12-02 02:50:27 --> Security Class Initialized
DEBUG - 2024-12-02 02:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:50:27 --> CSRF cookie sent
INFO - 2024-12-02 02:50:27 --> Input Class Initialized
INFO - 2024-12-02 02:50:27 --> Language Class Initialized
INFO - 2024-12-02 02:50:27 --> Loader Class Initialized
INFO - 2024-12-02 02:50:27 --> Helper loaded: url_helper
INFO - 2024-12-02 02:50:27 --> Helper loaded: form_helper
INFO - 2024-12-02 02:50:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:50:27 --> Form Validation Class Initialized
INFO - 2024-12-02 02:50:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:50:27 --> Controller Class Initialized
INFO - 2024-12-02 02:50:27 --> Model "User_model" initialized
INFO - 2024-12-02 02:50:27 --> Model "Category_model" initialized
INFO - 2024-12-02 02:50:27 --> Model "Review_model" initialized
INFO - 2024-12-02 02:50:27 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:50:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:50:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:50:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:50:27 --> Final output sent to browser
DEBUG - 2024-12-02 02:50:27 --> Total execution time: 0.0557
INFO - 2024-12-02 02:50:44 --> Config Class Initialized
INFO - 2024-12-02 02:50:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:50:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:50:44 --> Utf8 Class Initialized
INFO - 2024-12-02 02:50:44 --> URI Class Initialized
INFO - 2024-12-02 02:50:44 --> Router Class Initialized
INFO - 2024-12-02 02:50:44 --> Output Class Initialized
INFO - 2024-12-02 02:50:44 --> Security Class Initialized
DEBUG - 2024-12-02 02:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:50:44 --> CSRF cookie sent
INFO - 2024-12-02 02:50:44 --> Input Class Initialized
INFO - 2024-12-02 02:50:44 --> Language Class Initialized
INFO - 2024-12-02 02:50:44 --> Loader Class Initialized
INFO - 2024-12-02 02:50:44 --> Helper loaded: url_helper
INFO - 2024-12-02 02:50:44 --> Helper loaded: form_helper
INFO - 2024-12-02 02:50:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:50:44 --> Form Validation Class Initialized
INFO - 2024-12-02 02:50:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:50:44 --> Controller Class Initialized
INFO - 2024-12-02 02:50:44 --> Model "User_model" initialized
INFO - 2024-12-02 02:50:44 --> Model "Category_model" initialized
INFO - 2024-12-02 02:50:44 --> Model "Review_model" initialized
INFO - 2024-12-02 02:50:44 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:50:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:50:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:50:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:50:44 --> Final output sent to browser
DEBUG - 2024-12-02 02:50:44 --> Total execution time: 0.0803
INFO - 2024-12-02 02:50:44 --> Config Class Initialized
INFO - 2024-12-02 02:50:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:50:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:50:44 --> Utf8 Class Initialized
INFO - 2024-12-02 02:50:44 --> URI Class Initialized
INFO - 2024-12-02 02:50:44 --> Router Class Initialized
INFO - 2024-12-02 02:50:44 --> Output Class Initialized
INFO - 2024-12-02 02:50:44 --> Security Class Initialized
DEBUG - 2024-12-02 02:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:50:44 --> CSRF cookie sent
INFO - 2024-12-02 02:50:44 --> Input Class Initialized
INFO - 2024-12-02 02:50:44 --> Language Class Initialized
ERROR - 2024-12-02 02:50:44 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:56:32 --> Config Class Initialized
INFO - 2024-12-02 02:56:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:56:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:56:32 --> Utf8 Class Initialized
INFO - 2024-12-02 02:56:32 --> URI Class Initialized
INFO - 2024-12-02 02:56:32 --> Router Class Initialized
INFO - 2024-12-02 02:56:32 --> Output Class Initialized
INFO - 2024-12-02 02:56:32 --> Security Class Initialized
DEBUG - 2024-12-02 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:56:32 --> CSRF cookie sent
INFO - 2024-12-02 02:56:32 --> Input Class Initialized
INFO - 2024-12-02 02:56:32 --> Language Class Initialized
INFO - 2024-12-02 02:56:32 --> Loader Class Initialized
INFO - 2024-12-02 02:56:32 --> Helper loaded: url_helper
INFO - 2024-12-02 02:56:32 --> Helper loaded: form_helper
INFO - 2024-12-02 02:56:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:56:32 --> Form Validation Class Initialized
INFO - 2024-12-02 02:56:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:56:32 --> Controller Class Initialized
INFO - 2024-12-02 02:56:32 --> Model "User_model" initialized
INFO - 2024-12-02 02:56:32 --> Model "Category_model" initialized
INFO - 2024-12-02 02:56:32 --> Model "Review_model" initialized
INFO - 2024-12-02 02:56:32 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:56:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:56:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:56:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 02:56:33 --> Final output sent to browser
DEBUG - 2024-12-02 02:56:33 --> Total execution time: 0.4778
INFO - 2024-12-02 02:56:41 --> Config Class Initialized
INFO - 2024-12-02 02:56:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:56:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:56:41 --> Utf8 Class Initialized
INFO - 2024-12-02 02:56:41 --> URI Class Initialized
INFO - 2024-12-02 02:56:41 --> Router Class Initialized
INFO - 2024-12-02 02:56:41 --> Output Class Initialized
INFO - 2024-12-02 02:56:41 --> Security Class Initialized
DEBUG - 2024-12-02 02:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:56:41 --> CSRF cookie sent
INFO - 2024-12-02 02:56:41 --> Input Class Initialized
INFO - 2024-12-02 02:56:41 --> Language Class Initialized
INFO - 2024-12-02 02:56:41 --> Loader Class Initialized
INFO - 2024-12-02 02:56:41 --> Helper loaded: url_helper
INFO - 2024-12-02 02:56:41 --> Helper loaded: form_helper
INFO - 2024-12-02 02:56:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:56:41 --> Form Validation Class Initialized
INFO - 2024-12-02 02:56:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:56:41 --> Controller Class Initialized
INFO - 2024-12-02 02:56:41 --> Model "User_model" initialized
INFO - 2024-12-02 02:56:41 --> Model "Category_model" initialized
INFO - 2024-12-02 02:56:41 --> Model "Review_model" initialized
INFO - 2024-12-02 02:56:41 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:56:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:56:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:56:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 02:56:41 --> Final output sent to browser
DEBUG - 2024-12-02 02:56:41 --> Total execution time: 0.1043
INFO - 2024-12-02 02:56:42 --> Config Class Initialized
INFO - 2024-12-02 02:56:42 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:56:42 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:56:42 --> Utf8 Class Initialized
INFO - 2024-12-02 02:56:42 --> URI Class Initialized
INFO - 2024-12-02 02:56:42 --> Router Class Initialized
INFO - 2024-12-02 02:56:42 --> Output Class Initialized
INFO - 2024-12-02 02:56:42 --> Security Class Initialized
DEBUG - 2024-12-02 02:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:56:42 --> CSRF cookie sent
INFO - 2024-12-02 02:56:42 --> Input Class Initialized
INFO - 2024-12-02 02:56:42 --> Language Class Initialized
ERROR - 2024-12-02 02:56:42 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 02:56:48 --> Config Class Initialized
INFO - 2024-12-02 02:56:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:56:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:56:48 --> Utf8 Class Initialized
INFO - 2024-12-02 02:56:48 --> URI Class Initialized
INFO - 2024-12-02 02:56:48 --> Router Class Initialized
INFO - 2024-12-02 02:56:48 --> Output Class Initialized
INFO - 2024-12-02 02:56:48 --> Security Class Initialized
DEBUG - 2024-12-02 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:56:48 --> CSRF cookie sent
INFO - 2024-12-02 02:56:48 --> Input Class Initialized
INFO - 2024-12-02 02:56:48 --> Language Class Initialized
INFO - 2024-12-02 02:56:48 --> Loader Class Initialized
INFO - 2024-12-02 02:56:48 --> Helper loaded: url_helper
INFO - 2024-12-02 02:56:48 --> Helper loaded: form_helper
INFO - 2024-12-02 02:56:48 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:56:48 --> Form Validation Class Initialized
INFO - 2024-12-02 02:56:48 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:56:48 --> Controller Class Initialized
INFO - 2024-12-02 02:56:48 --> Model "User_model" initialized
INFO - 2024-12-02 02:56:48 --> Model "Category_model" initialized
INFO - 2024-12-02 02:56:48 --> Model "Review_model" initialized
INFO - 2024-12-02 02:56:48 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:56:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:56:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:56:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-02 02:56:48 --> Final output sent to browser
DEBUG - 2024-12-02 02:56:48 --> Total execution time: 0.0647
INFO - 2024-12-02 02:57:41 --> Config Class Initialized
INFO - 2024-12-02 02:57:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:41 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:41 --> URI Class Initialized
INFO - 2024-12-02 02:57:41 --> Router Class Initialized
INFO - 2024-12-02 02:57:41 --> Output Class Initialized
INFO - 2024-12-02 02:57:41 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:41 --> CSRF cookie sent
INFO - 2024-12-02 02:57:41 --> CSRF token verified
INFO - 2024-12-02 02:57:41 --> Input Class Initialized
INFO - 2024-12-02 02:57:41 --> Language Class Initialized
INFO - 2024-12-02 02:57:41 --> Loader Class Initialized
INFO - 2024-12-02 02:57:41 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:41 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:41 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:41 --> Controller Class Initialized
INFO - 2024-12-02 02:57:41 --> Model "Contact_model" initialized
DEBUG - 2024-12-02 02:57:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-02 02:57:41 --> Config Class Initialized
INFO - 2024-12-02 02:57:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:41 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:41 --> URI Class Initialized
INFO - 2024-12-02 02:57:41 --> Router Class Initialized
INFO - 2024-12-02 02:57:41 --> Output Class Initialized
INFO - 2024-12-02 02:57:41 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:41 --> CSRF cookie sent
INFO - 2024-12-02 02:57:41 --> Input Class Initialized
INFO - 2024-12-02 02:57:41 --> Language Class Initialized
INFO - 2024-12-02 02:57:41 --> Loader Class Initialized
INFO - 2024-12-02 02:57:41 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:41 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:41 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:41 --> Controller Class Initialized
INFO - 2024-12-02 02:57:41 --> Model "Contact_model" initialized
DEBUG - 2024-12-02 02:57:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:57:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:57:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-02 02:57:41 --> Final output sent to browser
DEBUG - 2024-12-02 02:57:41 --> Total execution time: 0.0382
INFO - 2024-12-02 02:57:47 --> Config Class Initialized
INFO - 2024-12-02 02:57:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:47 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:47 --> URI Class Initialized
INFO - 2024-12-02 02:57:47 --> Router Class Initialized
INFO - 2024-12-02 02:57:47 --> Output Class Initialized
INFO - 2024-12-02 02:57:47 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:47 --> CSRF cookie sent
INFO - 2024-12-02 02:57:47 --> Input Class Initialized
INFO - 2024-12-02 02:57:47 --> Language Class Initialized
INFO - 2024-12-02 02:57:47 --> Loader Class Initialized
INFO - 2024-12-02 02:57:47 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:47 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:47 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:47 --> Controller Class Initialized
INFO - 2024-12-02 02:57:47 --> Model "User_model" initialized
INFO - 2024-12-02 02:57:47 --> Model "Category_model" initialized
INFO - 2024-12-02 02:57:47 --> Model "Review_model" initialized
INFO - 2024-12-02 02:57:47 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:47 --> Config Class Initialized
INFO - 2024-12-02 02:57:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:47 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:47 --> URI Class Initialized
INFO - 2024-12-02 02:57:47 --> Router Class Initialized
INFO - 2024-12-02 02:57:47 --> Output Class Initialized
INFO - 2024-12-02 02:57:47 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:47 --> CSRF cookie sent
INFO - 2024-12-02 02:57:47 --> Input Class Initialized
INFO - 2024-12-02 02:57:47 --> Language Class Initialized
INFO - 2024-12-02 02:57:47 --> Loader Class Initialized
INFO - 2024-12-02 02:57:47 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:47 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:47 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:47 --> Controller Class Initialized
INFO - 2024-12-02 02:57:47 --> Model "User_model" initialized
INFO - 2024-12-02 02:57:47 --> Model "Category_model" initialized
INFO - 2024-12-02 02:57:47 --> Model "Review_model" initialized
INFO - 2024-12-02 02:57:47 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 02:57:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 02:57:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 02:57:47 --> Final output sent to browser
DEBUG - 2024-12-02 02:57:47 --> Total execution time: 0.0775
INFO - 2024-12-02 02:57:52 --> Config Class Initialized
INFO - 2024-12-02 02:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:52 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:52 --> URI Class Initialized
INFO - 2024-12-02 02:57:52 --> Router Class Initialized
INFO - 2024-12-02 02:57:52 --> Output Class Initialized
INFO - 2024-12-02 02:57:52 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:52 --> CSRF cookie sent
INFO - 2024-12-02 02:57:52 --> CSRF token verified
INFO - 2024-12-02 02:57:52 --> Input Class Initialized
INFO - 2024-12-02 02:57:52 --> Language Class Initialized
INFO - 2024-12-02 02:57:52 --> Loader Class Initialized
INFO - 2024-12-02 02:57:52 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:52 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:52 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:52 --> Controller Class Initialized
INFO - 2024-12-02 02:57:52 --> Model "User_model" initialized
INFO - 2024-12-02 02:57:52 --> Model "Category_model" initialized
INFO - 2024-12-02 02:57:52 --> Model "Review_model" initialized
INFO - 2024-12-02 02:57:52 --> Model "News_model" initialized
DEBUG - 2024-12-02 02:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:52 --> Config Class Initialized
INFO - 2024-12-02 02:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:52 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:52 --> URI Class Initialized
INFO - 2024-12-02 02:57:52 --> Router Class Initialized
INFO - 2024-12-02 02:57:52 --> Output Class Initialized
INFO - 2024-12-02 02:57:52 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:52 --> CSRF cookie sent
INFO - 2024-12-02 02:57:52 --> Input Class Initialized
INFO - 2024-12-02 02:57:52 --> Language Class Initialized
INFO - 2024-12-02 02:57:52 --> Loader Class Initialized
INFO - 2024-12-02 02:57:52 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:52 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:52 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:52 --> Controller Class Initialized
INFO - 2024-12-02 02:57:52 --> Model "Category_model" initialized
INFO - 2024-12-02 02:57:52 --> Model "User_model" initialized
INFO - 2024-12-02 02:57:52 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 02:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 02:57:52 --> Final output sent to browser
DEBUG - 2024-12-02 02:57:52 --> Total execution time: 0.0573
INFO - 2024-12-02 02:57:56 --> Config Class Initialized
INFO - 2024-12-02 02:57:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:57:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:57:56 --> Utf8 Class Initialized
INFO - 2024-12-02 02:57:56 --> URI Class Initialized
INFO - 2024-12-02 02:57:56 --> Router Class Initialized
INFO - 2024-12-02 02:57:56 --> Output Class Initialized
INFO - 2024-12-02 02:57:56 --> Security Class Initialized
DEBUG - 2024-12-02 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:57:56 --> CSRF cookie sent
INFO - 2024-12-02 02:57:56 --> Input Class Initialized
INFO - 2024-12-02 02:57:56 --> Language Class Initialized
INFO - 2024-12-02 02:57:56 --> Loader Class Initialized
INFO - 2024-12-02 02:57:56 --> Helper loaded: url_helper
INFO - 2024-12-02 02:57:56 --> Helper loaded: form_helper
INFO - 2024-12-02 02:57:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:57:56 --> Form Validation Class Initialized
INFO - 2024-12-02 02:57:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:57:56 --> Controller Class Initialized
INFO - 2024-12-02 02:57:56 --> Model "Category_model" initialized
INFO - 2024-12-02 02:57:56 --> Model "User_model" initialized
INFO - 2024-12-02 02:57:56 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 02:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:57:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 02:57:56 --> Final output sent to browser
DEBUG - 2024-12-02 02:57:56 --> Total execution time: 0.0620
INFO - 2024-12-02 02:58:00 --> Config Class Initialized
INFO - 2024-12-02 02:58:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:58:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:58:00 --> Utf8 Class Initialized
INFO - 2024-12-02 02:58:00 --> URI Class Initialized
INFO - 2024-12-02 02:58:00 --> Router Class Initialized
INFO - 2024-12-02 02:58:00 --> Output Class Initialized
INFO - 2024-12-02 02:58:00 --> Security Class Initialized
DEBUG - 2024-12-02 02:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:58:00 --> CSRF cookie sent
INFO - 2024-12-02 02:58:00 --> Input Class Initialized
INFO - 2024-12-02 02:58:00 --> Language Class Initialized
INFO - 2024-12-02 02:58:00 --> Loader Class Initialized
INFO - 2024-12-02 02:58:00 --> Helper loaded: url_helper
INFO - 2024-12-02 02:58:00 --> Helper loaded: form_helper
INFO - 2024-12-02 02:58:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:58:00 --> Form Validation Class Initialized
INFO - 2024-12-02 02:58:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:58:00 --> Controller Class Initialized
INFO - 2024-12-02 02:58:00 --> Model "Category_model" initialized
INFO - 2024-12-02 02:58:00 --> Model "User_model" initialized
INFO - 2024-12-02 02:58:00 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 02:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:58:00 --> Model "Contact_model" initialized
INFO - 2024-12-02 02:58:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-02 02:58:00 --> Final output sent to browser
DEBUG - 2024-12-02 02:58:00 --> Total execution time: 0.0560
INFO - 2024-12-02 02:58:08 --> Config Class Initialized
INFO - 2024-12-02 02:58:08 --> Hooks Class Initialized
DEBUG - 2024-12-02 02:58:08 --> UTF-8 Support Enabled
INFO - 2024-12-02 02:58:08 --> Utf8 Class Initialized
INFO - 2024-12-02 02:58:08 --> URI Class Initialized
INFO - 2024-12-02 02:58:08 --> Router Class Initialized
INFO - 2024-12-02 02:58:08 --> Output Class Initialized
INFO - 2024-12-02 02:58:08 --> Security Class Initialized
DEBUG - 2024-12-02 02:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 02:58:08 --> CSRF cookie sent
INFO - 2024-12-02 02:58:08 --> Input Class Initialized
INFO - 2024-12-02 02:58:08 --> Language Class Initialized
INFO - 2024-12-02 02:58:08 --> Loader Class Initialized
INFO - 2024-12-02 02:58:08 --> Helper loaded: url_helper
INFO - 2024-12-02 02:58:08 --> Helper loaded: form_helper
INFO - 2024-12-02 02:58:08 --> Database Driver Class Initialized
DEBUG - 2024-12-02 02:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 02:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 02:58:08 --> Form Validation Class Initialized
INFO - 2024-12-02 02:58:08 --> Model "Culinary_model" initialized
INFO - 2024-12-02 02:58:08 --> Controller Class Initialized
INFO - 2024-12-02 02:58:08 --> Model "Category_model" initialized
INFO - 2024-12-02 02:58:08 --> Model "User_model" initialized
INFO - 2024-12-02 02:58:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 02:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 02:58:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 02:58:08 --> Final output sent to browser
DEBUG - 2024-12-02 02:58:08 --> Total execution time: 0.0870
INFO - 2024-12-02 03:01:45 --> Config Class Initialized
INFO - 2024-12-02 03:01:45 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:01:45 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:01:45 --> Utf8 Class Initialized
INFO - 2024-12-02 03:01:45 --> URI Class Initialized
INFO - 2024-12-02 03:01:45 --> Router Class Initialized
INFO - 2024-12-02 03:01:45 --> Output Class Initialized
INFO - 2024-12-02 03:01:45 --> Security Class Initialized
DEBUG - 2024-12-02 03:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:01:45 --> CSRF cookie sent
INFO - 2024-12-02 03:01:45 --> Input Class Initialized
INFO - 2024-12-02 03:01:45 --> Language Class Initialized
INFO - 2024-12-02 03:01:45 --> Loader Class Initialized
INFO - 2024-12-02 03:01:45 --> Helper loaded: url_helper
INFO - 2024-12-02 03:01:45 --> Helper loaded: form_helper
INFO - 2024-12-02 03:01:45 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:01:45 --> Form Validation Class Initialized
INFO - 2024-12-02 03:01:45 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:01:45 --> Controller Class Initialized
INFO - 2024-12-02 03:01:45 --> Model "Category_model" initialized
INFO - 2024-12-02 03:01:45 --> Model "User_model" initialized
INFO - 2024-12-02 03:01:45 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 03:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:01:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 03:01:45 --> Final output sent to browser
DEBUG - 2024-12-02 03:01:45 --> Total execution time: 0.2816
INFO - 2024-12-02 03:01:47 --> Config Class Initialized
INFO - 2024-12-02 03:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:01:47 --> Utf8 Class Initialized
INFO - 2024-12-02 03:01:47 --> URI Class Initialized
INFO - 2024-12-02 03:01:47 --> Router Class Initialized
INFO - 2024-12-02 03:01:47 --> Output Class Initialized
INFO - 2024-12-02 03:01:47 --> Security Class Initialized
DEBUG - 2024-12-02 03:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:01:47 --> CSRF cookie sent
INFO - 2024-12-02 03:01:47 --> Input Class Initialized
INFO - 2024-12-02 03:01:47 --> Language Class Initialized
INFO - 2024-12-02 03:01:47 --> Loader Class Initialized
INFO - 2024-12-02 03:01:47 --> Helper loaded: url_helper
INFO - 2024-12-02 03:01:47 --> Helper loaded: form_helper
INFO - 2024-12-02 03:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:01:47 --> Form Validation Class Initialized
INFO - 2024-12-02 03:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:01:47 --> Controller Class Initialized
INFO - 2024-12-02 03:01:47 --> Model "Category_model" initialized
INFO - 2024-12-02 03:01:47 --> Model "User_model" initialized
INFO - 2024-12-02 03:01:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 03:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 03:01:47 --> Final output sent to browser
DEBUG - 2024-12-02 03:01:47 --> Total execution time: 0.0491
INFO - 2024-12-02 03:01:50 --> Config Class Initialized
INFO - 2024-12-02 03:01:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:01:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:01:50 --> Utf8 Class Initialized
INFO - 2024-12-02 03:01:50 --> URI Class Initialized
INFO - 2024-12-02 03:01:50 --> Router Class Initialized
INFO - 2024-12-02 03:01:50 --> Output Class Initialized
INFO - 2024-12-02 03:01:50 --> Security Class Initialized
DEBUG - 2024-12-02 03:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:01:50 --> CSRF cookie sent
INFO - 2024-12-02 03:01:50 --> Input Class Initialized
INFO - 2024-12-02 03:01:50 --> Language Class Initialized
INFO - 2024-12-02 03:01:50 --> Loader Class Initialized
INFO - 2024-12-02 03:01:50 --> Helper loaded: url_helper
INFO - 2024-12-02 03:01:50 --> Helper loaded: form_helper
INFO - 2024-12-02 03:01:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:01:50 --> Form Validation Class Initialized
INFO - 2024-12-02 03:01:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:01:50 --> Controller Class Initialized
INFO - 2024-12-02 03:01:50 --> Model "Category_model" initialized
INFO - 2024-12-02 03:01:50 --> Model "User_model" initialized
INFO - 2024-12-02 03:01:50 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 03:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:01:50 --> Model "Contact_model" initialized
INFO - 2024-12-02 03:01:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-02 03:01:50 --> Final output sent to browser
DEBUG - 2024-12-02 03:01:50 --> Total execution time: 0.0513
INFO - 2024-12-02 03:01:54 --> Config Class Initialized
INFO - 2024-12-02 03:01:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:01:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:01:54 --> Utf8 Class Initialized
INFO - 2024-12-02 03:01:54 --> URI Class Initialized
INFO - 2024-12-02 03:01:54 --> Router Class Initialized
INFO - 2024-12-02 03:01:54 --> Output Class Initialized
INFO - 2024-12-02 03:01:54 --> Security Class Initialized
DEBUG - 2024-12-02 03:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:01:54 --> CSRF cookie sent
INFO - 2024-12-02 03:01:54 --> Input Class Initialized
INFO - 2024-12-02 03:01:54 --> Language Class Initialized
INFO - 2024-12-02 03:01:54 --> Loader Class Initialized
INFO - 2024-12-02 03:01:54 --> Helper loaded: url_helper
INFO - 2024-12-02 03:01:54 --> Helper loaded: form_helper
INFO - 2024-12-02 03:01:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:01:54 --> Form Validation Class Initialized
INFO - 2024-12-02 03:01:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:01:54 --> Controller Class Initialized
INFO - 2024-12-02 03:01:54 --> Model "Category_model" initialized
INFO - 2024-12-02 03:01:54 --> Model "User_model" initialized
INFO - 2024-12-02 03:01:54 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 03:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:01:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 03:01:54 --> Final output sent to browser
DEBUG - 2024-12-02 03:01:54 --> Total execution time: 0.0729
INFO - 2024-12-02 03:16:46 --> Config Class Initialized
INFO - 2024-12-02 03:16:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:16:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:16:46 --> Utf8 Class Initialized
INFO - 2024-12-02 03:16:46 --> URI Class Initialized
INFO - 2024-12-02 03:16:46 --> Router Class Initialized
INFO - 2024-12-02 03:16:46 --> Output Class Initialized
INFO - 2024-12-02 03:16:46 --> Security Class Initialized
DEBUG - 2024-12-02 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:16:46 --> CSRF cookie sent
INFO - 2024-12-02 03:16:46 --> Input Class Initialized
INFO - 2024-12-02 03:16:46 --> Language Class Initialized
INFO - 2024-12-02 03:16:46 --> Loader Class Initialized
INFO - 2024-12-02 03:16:46 --> Helper loaded: url_helper
INFO - 2024-12-02 03:16:46 --> Helper loaded: form_helper
INFO - 2024-12-02 03:16:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:16:46 --> Form Validation Class Initialized
INFO - 2024-12-02 03:16:46 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:16:46 --> Controller Class Initialized
INFO - 2024-12-02 03:16:46 --> Model "User_model" initialized
INFO - 2024-12-02 03:16:46 --> Model "Category_model" initialized
INFO - 2024-12-02 03:16:46 --> Model "Review_model" initialized
INFO - 2024-12-02 03:16:46 --> Model "News_model" initialized
DEBUG - 2024-12-02 03:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:16:46 --> Config Class Initialized
INFO - 2024-12-02 03:16:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:16:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:16:46 --> Utf8 Class Initialized
INFO - 2024-12-02 03:16:46 --> URI Class Initialized
INFO - 2024-12-02 03:16:46 --> Router Class Initialized
INFO - 2024-12-02 03:16:46 --> Output Class Initialized
INFO - 2024-12-02 03:16:46 --> Security Class Initialized
DEBUG - 2024-12-02 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:16:46 --> CSRF cookie sent
INFO - 2024-12-02 03:16:46 --> Input Class Initialized
INFO - 2024-12-02 03:16:46 --> Language Class Initialized
INFO - 2024-12-02 03:16:46 --> Loader Class Initialized
INFO - 2024-12-02 03:16:46 --> Helper loaded: url_helper
INFO - 2024-12-02 03:16:46 --> Helper loaded: form_helper
INFO - 2024-12-02 03:16:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:16:46 --> Form Validation Class Initialized
INFO - 2024-12-02 03:16:46 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:16:46 --> Controller Class Initialized
INFO - 2024-12-02 03:16:46 --> Model "User_model" initialized
INFO - 2024-12-02 03:16:46 --> Model "Category_model" initialized
INFO - 2024-12-02 03:16:46 --> Model "Review_model" initialized
INFO - 2024-12-02 03:16:46 --> Model "News_model" initialized
DEBUG - 2024-12-02 03:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 03:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 03:16:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 03:16:47 --> Final output sent to browser
DEBUG - 2024-12-02 03:16:47 --> Total execution time: 0.0583
INFO - 2024-12-02 03:16:53 --> Config Class Initialized
INFO - 2024-12-02 03:16:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:16:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:16:53 --> Utf8 Class Initialized
INFO - 2024-12-02 03:16:53 --> URI Class Initialized
INFO - 2024-12-02 03:16:53 --> Router Class Initialized
INFO - 2024-12-02 03:16:53 --> Output Class Initialized
INFO - 2024-12-02 03:16:53 --> Security Class Initialized
DEBUG - 2024-12-02 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:16:53 --> CSRF cookie sent
INFO - 2024-12-02 03:16:53 --> CSRF token verified
INFO - 2024-12-02 03:16:53 --> Input Class Initialized
INFO - 2024-12-02 03:16:53 --> Language Class Initialized
INFO - 2024-12-02 03:16:53 --> Loader Class Initialized
INFO - 2024-12-02 03:16:53 --> Helper loaded: url_helper
INFO - 2024-12-02 03:16:53 --> Helper loaded: form_helper
INFO - 2024-12-02 03:16:53 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:16:53 --> Form Validation Class Initialized
INFO - 2024-12-02 03:16:53 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:16:53 --> Controller Class Initialized
INFO - 2024-12-02 03:16:53 --> Model "User_model" initialized
INFO - 2024-12-02 03:16:53 --> Model "Category_model" initialized
INFO - 2024-12-02 03:16:53 --> Model "Review_model" initialized
INFO - 2024-12-02 03:16:53 --> Model "News_model" initialized
DEBUG - 2024-12-02 03:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:16:54 --> Config Class Initialized
INFO - 2024-12-02 03:16:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:16:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:16:54 --> Utf8 Class Initialized
INFO - 2024-12-02 03:16:54 --> URI Class Initialized
INFO - 2024-12-02 03:16:54 --> Router Class Initialized
INFO - 2024-12-02 03:16:54 --> Output Class Initialized
INFO - 2024-12-02 03:16:54 --> Security Class Initialized
DEBUG - 2024-12-02 03:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:16:54 --> CSRF cookie sent
INFO - 2024-12-02 03:16:54 --> Input Class Initialized
INFO - 2024-12-02 03:16:54 --> Language Class Initialized
INFO - 2024-12-02 03:16:54 --> Loader Class Initialized
INFO - 2024-12-02 03:16:54 --> Helper loaded: url_helper
INFO - 2024-12-02 03:16:54 --> Helper loaded: form_helper
INFO - 2024-12-02 03:16:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 03:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 03:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 03:16:54 --> Form Validation Class Initialized
INFO - 2024-12-02 03:16:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 03:16:54 --> Controller Class Initialized
INFO - 2024-12-02 03:16:54 --> Model "User_model" initialized
INFO - 2024-12-02 03:16:54 --> Model "Category_model" initialized
INFO - 2024-12-02 03:16:54 --> Model "Review_model" initialized
INFO - 2024-12-02 03:16:54 --> Model "News_model" initialized
DEBUG - 2024-12-02 03:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 03:16:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 03:16:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 03:16:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 03:16:54 --> Final output sent to browser
DEBUG - 2024-12-02 03:16:54 --> Total execution time: 0.3152
INFO - 2024-12-02 03:16:55 --> Config Class Initialized
INFO - 2024-12-02 03:16:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:16:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:16:55 --> Utf8 Class Initialized
INFO - 2024-12-02 03:16:55 --> URI Class Initialized
INFO - 2024-12-02 03:16:55 --> Router Class Initialized
INFO - 2024-12-02 03:16:55 --> Output Class Initialized
INFO - 2024-12-02 03:16:55 --> Security Class Initialized
DEBUG - 2024-12-02 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:16:55 --> CSRF cookie sent
INFO - 2024-12-02 03:16:55 --> Input Class Initialized
INFO - 2024-12-02 03:16:55 --> Language Class Initialized
ERROR - 2024-12-02 03:16:55 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 04:59:28 --> Config Class Initialized
INFO - 2024-12-02 04:59:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:28 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:28 --> URI Class Initialized
INFO - 2024-12-02 04:59:28 --> Router Class Initialized
INFO - 2024-12-02 04:59:28 --> Output Class Initialized
INFO - 2024-12-02 04:59:28 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:28 --> CSRF cookie sent
INFO - 2024-12-02 04:59:28 --> Input Class Initialized
INFO - 2024-12-02 04:59:28 --> Language Class Initialized
INFO - 2024-12-02 04:59:28 --> Loader Class Initialized
INFO - 2024-12-02 04:59:28 --> Helper loaded: url_helper
INFO - 2024-12-02 04:59:28 --> Helper loaded: form_helper
INFO - 2024-12-02 04:59:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 04:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 04:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 04:59:28 --> Form Validation Class Initialized
INFO - 2024-12-02 04:59:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 04:59:28 --> Controller Class Initialized
INFO - 2024-12-02 04:59:28 --> Model "User_model" initialized
INFO - 2024-12-02 04:59:28 --> Model "Category_model" initialized
INFO - 2024-12-02 04:59:28 --> Model "Review_model" initialized
INFO - 2024-12-02 04:59:28 --> Model "News_model" initialized
DEBUG - 2024-12-02 04:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 04:59:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 04:59:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 04:59:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 04:59:28 --> Final output sent to browser
DEBUG - 2024-12-02 04:59:28 --> Total execution time: 0.6553
INFO - 2024-12-02 04:59:44 --> Config Class Initialized
INFO - 2024-12-02 04:59:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:44 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:44 --> URI Class Initialized
INFO - 2024-12-02 04:59:44 --> Router Class Initialized
INFO - 2024-12-02 04:59:44 --> Output Class Initialized
INFO - 2024-12-02 04:59:44 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:44 --> CSRF cookie sent
INFO - 2024-12-02 04:59:44 --> Input Class Initialized
INFO - 2024-12-02 04:59:44 --> Language Class Initialized
INFO - 2024-12-02 04:59:44 --> Loader Class Initialized
INFO - 2024-12-02 04:59:44 --> Helper loaded: url_helper
INFO - 2024-12-02 04:59:44 --> Helper loaded: form_helper
INFO - 2024-12-02 04:59:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 04:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 04:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 04:59:44 --> Form Validation Class Initialized
INFO - 2024-12-02 04:59:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 04:59:44 --> Controller Class Initialized
INFO - 2024-12-02 04:59:44 --> Model "User_model" initialized
INFO - 2024-12-02 04:59:44 --> Model "Category_model" initialized
INFO - 2024-12-02 04:59:44 --> Model "Review_model" initialized
INFO - 2024-12-02 04:59:44 --> Model "News_model" initialized
DEBUG - 2024-12-02 04:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 04:59:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 04:59:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 04:59:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 04:59:44 --> Final output sent to browser
DEBUG - 2024-12-02 04:59:44 --> Total execution time: 0.0919
INFO - 2024-12-02 04:59:44 --> Config Class Initialized
INFO - 2024-12-02 04:59:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:44 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:44 --> URI Class Initialized
INFO - 2024-12-02 04:59:44 --> Router Class Initialized
INFO - 2024-12-02 04:59:44 --> Output Class Initialized
INFO - 2024-12-02 04:59:44 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:44 --> CSRF cookie sent
INFO - 2024-12-02 04:59:44 --> Input Class Initialized
INFO - 2024-12-02 04:59:44 --> Language Class Initialized
ERROR - 2024-12-02 04:59:44 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 04:59:47 --> Config Class Initialized
INFO - 2024-12-02 04:59:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:47 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:47 --> URI Class Initialized
INFO - 2024-12-02 04:59:47 --> Router Class Initialized
INFO - 2024-12-02 04:59:47 --> Output Class Initialized
INFO - 2024-12-02 04:59:47 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:47 --> CSRF cookie sent
INFO - 2024-12-02 04:59:47 --> Input Class Initialized
INFO - 2024-12-02 04:59:47 --> Language Class Initialized
INFO - 2024-12-02 04:59:47 --> Loader Class Initialized
INFO - 2024-12-02 04:59:47 --> Helper loaded: url_helper
INFO - 2024-12-02 04:59:47 --> Helper loaded: form_helper
INFO - 2024-12-02 04:59:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 04:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 04:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 04:59:47 --> Form Validation Class Initialized
INFO - 2024-12-02 04:59:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 04:59:47 --> Controller Class Initialized
INFO - 2024-12-02 04:59:47 --> Model "User_model" initialized
INFO - 2024-12-02 04:59:47 --> Model "Category_model" initialized
INFO - 2024-12-02 04:59:47 --> Model "Review_model" initialized
INFO - 2024-12-02 04:59:47 --> Model "News_model" initialized
DEBUG - 2024-12-02 04:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 04:59:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 04:59:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 04:59:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-02 04:59:47 --> Final output sent to browser
DEBUG - 2024-12-02 04:59:47 --> Total execution time: 0.0625
INFO - 2024-12-02 04:59:50 --> Config Class Initialized
INFO - 2024-12-02 04:59:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:50 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:50 --> URI Class Initialized
INFO - 2024-12-02 04:59:50 --> Router Class Initialized
INFO - 2024-12-02 04:59:50 --> Output Class Initialized
INFO - 2024-12-02 04:59:50 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:50 --> CSRF cookie sent
INFO - 2024-12-02 04:59:50 --> Input Class Initialized
INFO - 2024-12-02 04:59:50 --> Language Class Initialized
INFO - 2024-12-02 04:59:50 --> Loader Class Initialized
INFO - 2024-12-02 04:59:50 --> Helper loaded: url_helper
INFO - 2024-12-02 04:59:50 --> Helper loaded: form_helper
INFO - 2024-12-02 04:59:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 04:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 04:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 04:59:50 --> Form Validation Class Initialized
INFO - 2024-12-02 04:59:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 04:59:50 --> Controller Class Initialized
INFO - 2024-12-02 04:59:50 --> Model "User_model" initialized
INFO - 2024-12-02 04:59:50 --> Model "Category_model" initialized
INFO - 2024-12-02 04:59:50 --> Model "Review_model" initialized
INFO - 2024-12-02 04:59:50 --> Model "News_model" initialized
DEBUG - 2024-12-02 04:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 04:59:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 04:59:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 04:59:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 04:59:50 --> Final output sent to browser
DEBUG - 2024-12-02 04:59:50 --> Total execution time: 0.1261
INFO - 2024-12-02 04:59:55 --> Config Class Initialized
INFO - 2024-12-02 04:59:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:55 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:55 --> URI Class Initialized
INFO - 2024-12-02 04:59:55 --> Router Class Initialized
INFO - 2024-12-02 04:59:55 --> Output Class Initialized
INFO - 2024-12-02 04:59:55 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:55 --> CSRF cookie sent
INFO - 2024-12-02 04:59:55 --> Input Class Initialized
INFO - 2024-12-02 04:59:55 --> Language Class Initialized
INFO - 2024-12-02 04:59:55 --> Loader Class Initialized
INFO - 2024-12-02 04:59:55 --> Helper loaded: url_helper
INFO - 2024-12-02 04:59:55 --> Helper loaded: form_helper
INFO - 2024-12-02 04:59:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 04:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 04:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 04:59:55 --> Form Validation Class Initialized
INFO - 2024-12-02 04:59:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 04:59:55 --> Controller Class Initialized
INFO - 2024-12-02 04:59:55 --> Model "User_model" initialized
INFO - 2024-12-02 04:59:55 --> Model "Category_model" initialized
INFO - 2024-12-02 04:59:55 --> Model "Review_model" initialized
INFO - 2024-12-02 04:59:55 --> Model "News_model" initialized
DEBUG - 2024-12-02 04:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 04:59:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 04:59:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 04:59:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-02 04:59:55 --> Final output sent to browser
DEBUG - 2024-12-02 04:59:55 --> Total execution time: 0.0780
INFO - 2024-12-02 04:59:59 --> Config Class Initialized
INFO - 2024-12-02 04:59:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 04:59:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 04:59:59 --> Utf8 Class Initialized
INFO - 2024-12-02 04:59:59 --> URI Class Initialized
INFO - 2024-12-02 04:59:59 --> Router Class Initialized
INFO - 2024-12-02 04:59:59 --> Output Class Initialized
INFO - 2024-12-02 04:59:59 --> Security Class Initialized
DEBUG - 2024-12-02 04:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 04:59:59 --> CSRF cookie sent
INFO - 2024-12-02 04:59:59 --> Input Class Initialized
INFO - 2024-12-02 04:59:59 --> Language Class Initialized
INFO - 2024-12-02 04:59:59 --> Loader Class Initialized
INFO - 2024-12-02 04:59:59 --> Helper loaded: url_helper
INFO - 2024-12-02 04:59:59 --> Helper loaded: form_helper
INFO - 2024-12-02 04:59:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 04:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 04:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 04:59:59 --> Form Validation Class Initialized
INFO - 2024-12-02 04:59:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 04:59:59 --> Controller Class Initialized
INFO - 2024-12-02 04:59:59 --> Model "User_model" initialized
INFO - 2024-12-02 04:59:59 --> Model "Category_model" initialized
INFO - 2024-12-02 04:59:59 --> Model "Review_model" initialized
INFO - 2024-12-02 04:59:59 --> Model "News_model" initialized
DEBUG - 2024-12-02 04:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 04:59:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 04:59:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 04:59:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-02 04:59:59 --> Final output sent to browser
DEBUG - 2024-12-02 04:59:59 --> Total execution time: 0.0576
INFO - 2024-12-02 05:00:01 --> Config Class Initialized
INFO - 2024-12-02 05:00:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:00:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:00:01 --> Utf8 Class Initialized
INFO - 2024-12-02 05:00:01 --> URI Class Initialized
INFO - 2024-12-02 05:00:01 --> Router Class Initialized
INFO - 2024-12-02 05:00:01 --> Output Class Initialized
INFO - 2024-12-02 05:00:01 --> Security Class Initialized
DEBUG - 2024-12-02 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:00:01 --> CSRF cookie sent
INFO - 2024-12-02 05:00:01 --> Input Class Initialized
INFO - 2024-12-02 05:00:01 --> Language Class Initialized
INFO - 2024-12-02 05:00:01 --> Loader Class Initialized
INFO - 2024-12-02 05:00:01 --> Helper loaded: url_helper
INFO - 2024-12-02 05:00:01 --> Helper loaded: form_helper
INFO - 2024-12-02 05:00:01 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:00:01 --> Form Validation Class Initialized
INFO - 2024-12-02 05:00:01 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:00:01 --> Controller Class Initialized
INFO - 2024-12-02 05:00:01 --> Model "User_model" initialized
INFO - 2024-12-02 05:00:01 --> Model "Category_model" initialized
INFO - 2024-12-02 05:00:01 --> Model "Review_model" initialized
INFO - 2024-12-02 05:00:01 --> Model "News_model" initialized
DEBUG - 2024-12-02 05:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:00:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 05:00:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 05:00:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 05:00:01 --> Final output sent to browser
DEBUG - 2024-12-02 05:00:01 --> Total execution time: 0.0645
INFO - 2024-12-02 05:00:01 --> Config Class Initialized
INFO - 2024-12-02 05:00:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:00:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:00:01 --> Utf8 Class Initialized
INFO - 2024-12-02 05:00:01 --> URI Class Initialized
INFO - 2024-12-02 05:00:01 --> Router Class Initialized
INFO - 2024-12-02 05:00:01 --> Output Class Initialized
INFO - 2024-12-02 05:00:01 --> Security Class Initialized
DEBUG - 2024-12-02 05:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:00:01 --> CSRF cookie sent
INFO - 2024-12-02 05:00:01 --> Input Class Initialized
INFO - 2024-12-02 05:00:01 --> Language Class Initialized
ERROR - 2024-12-02 05:00:01 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 05:02:56 --> Config Class Initialized
INFO - 2024-12-02 05:02:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:02:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:02:57 --> Utf8 Class Initialized
INFO - 2024-12-02 05:02:57 --> URI Class Initialized
INFO - 2024-12-02 05:02:57 --> Router Class Initialized
INFO - 2024-12-02 05:02:57 --> Output Class Initialized
INFO - 2024-12-02 05:02:57 --> Security Class Initialized
DEBUG - 2024-12-02 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:02:57 --> CSRF cookie sent
INFO - 2024-12-02 05:02:57 --> Input Class Initialized
INFO - 2024-12-02 05:02:57 --> Language Class Initialized
INFO - 2024-12-02 05:02:57 --> Loader Class Initialized
INFO - 2024-12-02 05:02:57 --> Helper loaded: url_helper
INFO - 2024-12-02 05:02:57 --> Helper loaded: form_helper
INFO - 2024-12-02 05:02:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:02:57 --> Form Validation Class Initialized
INFO - 2024-12-02 05:02:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:02:57 --> Controller Class Initialized
INFO - 2024-12-02 05:02:57 --> Model "User_model" initialized
INFO - 2024-12-02 05:02:57 --> Model "Category_model" initialized
INFO - 2024-12-02 05:02:57 --> Model "Review_model" initialized
INFO - 2024-12-02 05:02:57 --> Model "News_model" initialized
DEBUG - 2024-12-02 05:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:02:57 --> Config Class Initialized
INFO - 2024-12-02 05:02:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:02:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:02:57 --> Utf8 Class Initialized
INFO - 2024-12-02 05:02:57 --> URI Class Initialized
INFO - 2024-12-02 05:02:57 --> Router Class Initialized
INFO - 2024-12-02 05:02:57 --> Output Class Initialized
INFO - 2024-12-02 05:02:57 --> Security Class Initialized
DEBUG - 2024-12-02 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:02:57 --> CSRF cookie sent
INFO - 2024-12-02 05:02:57 --> Input Class Initialized
INFO - 2024-12-02 05:02:57 --> Language Class Initialized
INFO - 2024-12-02 05:02:57 --> Loader Class Initialized
INFO - 2024-12-02 05:02:57 --> Helper loaded: url_helper
INFO - 2024-12-02 05:02:57 --> Helper loaded: form_helper
INFO - 2024-12-02 05:02:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:02:57 --> Form Validation Class Initialized
INFO - 2024-12-02 05:02:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:02:57 --> Controller Class Initialized
INFO - 2024-12-02 05:02:57 --> Model "User_model" initialized
INFO - 2024-12-02 05:02:57 --> Model "Category_model" initialized
INFO - 2024-12-02 05:02:57 --> Model "Review_model" initialized
INFO - 2024-12-02 05:02:57 --> Model "News_model" initialized
DEBUG - 2024-12-02 05:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:02:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 05:02:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 05:02:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 05:02:57 --> Final output sent to browser
DEBUG - 2024-12-02 05:02:57 --> Total execution time: 0.0785
INFO - 2024-12-02 05:03:01 --> Config Class Initialized
INFO - 2024-12-02 05:03:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:03:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:03:01 --> Utf8 Class Initialized
INFO - 2024-12-02 05:03:01 --> URI Class Initialized
INFO - 2024-12-02 05:03:01 --> Router Class Initialized
INFO - 2024-12-02 05:03:01 --> Output Class Initialized
INFO - 2024-12-02 05:03:01 --> Security Class Initialized
DEBUG - 2024-12-02 05:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:03:01 --> CSRF cookie sent
INFO - 2024-12-02 05:03:01 --> CSRF token verified
INFO - 2024-12-02 05:03:01 --> Input Class Initialized
INFO - 2024-12-02 05:03:01 --> Language Class Initialized
INFO - 2024-12-02 05:03:01 --> Loader Class Initialized
INFO - 2024-12-02 05:03:01 --> Helper loaded: url_helper
INFO - 2024-12-02 05:03:01 --> Helper loaded: form_helper
INFO - 2024-12-02 05:03:01 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:03:01 --> Form Validation Class Initialized
INFO - 2024-12-02 05:03:01 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:03:01 --> Controller Class Initialized
INFO - 2024-12-02 05:03:01 --> Model "User_model" initialized
INFO - 2024-12-02 05:03:01 --> Model "Category_model" initialized
INFO - 2024-12-02 05:03:01 --> Model "Review_model" initialized
INFO - 2024-12-02 05:03:01 --> Model "News_model" initialized
DEBUG - 2024-12-02 05:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:03:01 --> Config Class Initialized
INFO - 2024-12-02 05:03:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:03:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:03:01 --> Utf8 Class Initialized
INFO - 2024-12-02 05:03:01 --> URI Class Initialized
INFO - 2024-12-02 05:03:01 --> Router Class Initialized
INFO - 2024-12-02 05:03:01 --> Output Class Initialized
INFO - 2024-12-02 05:03:01 --> Security Class Initialized
DEBUG - 2024-12-02 05:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:03:01 --> CSRF cookie sent
INFO - 2024-12-02 05:03:01 --> Input Class Initialized
INFO - 2024-12-02 05:03:01 --> Language Class Initialized
INFO - 2024-12-02 05:03:01 --> Loader Class Initialized
INFO - 2024-12-02 05:03:01 --> Helper loaded: url_helper
INFO - 2024-12-02 05:03:01 --> Helper loaded: form_helper
INFO - 2024-12-02 05:03:02 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:03:02 --> Form Validation Class Initialized
INFO - 2024-12-02 05:03:02 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:03:02 --> Controller Class Initialized
INFO - 2024-12-02 05:03:02 --> Model "Category_model" initialized
INFO - 2024-12-02 05:03:02 --> Model "User_model" initialized
INFO - 2024-12-02 05:03:02 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:03:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:03:02 --> Final output sent to browser
DEBUG - 2024-12-02 05:03:02 --> Total execution time: 0.0838
INFO - 2024-12-02 05:50:19 --> Config Class Initialized
INFO - 2024-12-02 05:50:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:19 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:19 --> URI Class Initialized
INFO - 2024-12-02 05:50:19 --> Router Class Initialized
INFO - 2024-12-02 05:50:19 --> Output Class Initialized
INFO - 2024-12-02 05:50:19 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:19 --> CSRF cookie sent
INFO - 2024-12-02 05:50:19 --> Input Class Initialized
INFO - 2024-12-02 05:50:19 --> Language Class Initialized
INFO - 2024-12-02 05:50:19 --> Loader Class Initialized
INFO - 2024-12-02 05:50:19 --> Helper loaded: url_helper
INFO - 2024-12-02 05:50:19 --> Helper loaded: form_helper
INFO - 2024-12-02 05:50:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:50:19 --> Form Validation Class Initialized
INFO - 2024-12-02 05:50:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:50:19 --> Controller Class Initialized
INFO - 2024-12-02 05:50:19 --> Model "Category_model" initialized
INFO - 2024-12-02 05:50:19 --> Model "User_model" initialized
INFO - 2024-12-02 05:50:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:50:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:50:20 --> Final output sent to browser
DEBUG - 2024-12-02 05:50:20 --> Total execution time: 0.7707
INFO - 2024-12-02 05:50:22 --> Config Class Initialized
INFO - 2024-12-02 05:50:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:22 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:22 --> URI Class Initialized
INFO - 2024-12-02 05:50:22 --> Router Class Initialized
INFO - 2024-12-02 05:50:22 --> Output Class Initialized
INFO - 2024-12-02 05:50:22 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:22 --> CSRF cookie sent
INFO - 2024-12-02 05:50:22 --> Input Class Initialized
INFO - 2024-12-02 05:50:22 --> Language Class Initialized
INFO - 2024-12-02 05:50:22 --> Loader Class Initialized
INFO - 2024-12-02 05:50:22 --> Helper loaded: url_helper
INFO - 2024-12-02 05:50:22 --> Helper loaded: form_helper
INFO - 2024-12-02 05:50:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:50:22 --> Form Validation Class Initialized
INFO - 2024-12-02 05:50:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:50:22 --> Controller Class Initialized
INFO - 2024-12-02 05:50:22 --> Model "Category_model" initialized
INFO - 2024-12-02 05:50:22 --> Model "User_model" initialized
INFO - 2024-12-02 05:50:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:50:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:50:22 --> Final output sent to browser
DEBUG - 2024-12-02 05:50:22 --> Total execution time: 0.0809
INFO - 2024-12-02 05:50:24 --> Config Class Initialized
INFO - 2024-12-02 05:50:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:24 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:24 --> URI Class Initialized
INFO - 2024-12-02 05:50:24 --> Router Class Initialized
INFO - 2024-12-02 05:50:24 --> Output Class Initialized
INFO - 2024-12-02 05:50:24 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:24 --> CSRF cookie sent
INFO - 2024-12-02 05:50:24 --> Input Class Initialized
INFO - 2024-12-02 05:50:24 --> Language Class Initialized
ERROR - 2024-12-02 05:50:24 --> 404 Page Not Found: Admin/news
INFO - 2024-12-02 05:50:26 --> Config Class Initialized
INFO - 2024-12-02 05:50:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:26 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:26 --> URI Class Initialized
INFO - 2024-12-02 05:50:26 --> Router Class Initialized
INFO - 2024-12-02 05:50:26 --> Output Class Initialized
INFO - 2024-12-02 05:50:26 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:26 --> CSRF cookie sent
INFO - 2024-12-02 05:50:26 --> Input Class Initialized
INFO - 2024-12-02 05:50:26 --> Language Class Initialized
ERROR - 2024-12-02 05:50:26 --> 404 Page Not Found: Admin/news
INFO - 2024-12-02 05:50:27 --> Config Class Initialized
INFO - 2024-12-02 05:50:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:27 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:27 --> URI Class Initialized
INFO - 2024-12-02 05:50:27 --> Router Class Initialized
INFO - 2024-12-02 05:50:27 --> Output Class Initialized
INFO - 2024-12-02 05:50:27 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:27 --> CSRF cookie sent
INFO - 2024-12-02 05:50:27 --> Input Class Initialized
INFO - 2024-12-02 05:50:27 --> Language Class Initialized
ERROR - 2024-12-02 05:50:27 --> 404 Page Not Found: Admin/news
INFO - 2024-12-02 05:50:27 --> Config Class Initialized
INFO - 2024-12-02 05:50:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:27 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:27 --> URI Class Initialized
INFO - 2024-12-02 05:50:27 --> Router Class Initialized
INFO - 2024-12-02 05:50:27 --> Output Class Initialized
INFO - 2024-12-02 05:50:27 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:27 --> CSRF cookie sent
INFO - 2024-12-02 05:50:27 --> Input Class Initialized
INFO - 2024-12-02 05:50:27 --> Language Class Initialized
ERROR - 2024-12-02 05:50:27 --> 404 Page Not Found: Admin/news
INFO - 2024-12-02 05:50:28 --> Config Class Initialized
INFO - 2024-12-02 05:50:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:50:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:50:28 --> Utf8 Class Initialized
INFO - 2024-12-02 05:50:28 --> URI Class Initialized
INFO - 2024-12-02 05:50:28 --> Router Class Initialized
INFO - 2024-12-02 05:50:28 --> Output Class Initialized
INFO - 2024-12-02 05:50:28 --> Security Class Initialized
DEBUG - 2024-12-02 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:50:28 --> CSRF cookie sent
INFO - 2024-12-02 05:50:28 --> Input Class Initialized
INFO - 2024-12-02 05:50:28 --> Language Class Initialized
INFO - 2024-12-02 05:50:28 --> Loader Class Initialized
INFO - 2024-12-02 05:50:28 --> Helper loaded: url_helper
INFO - 2024-12-02 05:50:28 --> Helper loaded: form_helper
INFO - 2024-12-02 05:50:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:50:28 --> Form Validation Class Initialized
INFO - 2024-12-02 05:50:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:50:28 --> Controller Class Initialized
INFO - 2024-12-02 05:50:28 --> Model "Category_model" initialized
INFO - 2024-12-02 05:50:28 --> Model "User_model" initialized
INFO - 2024-12-02 05:50:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:50:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:50:28 --> Final output sent to browser
DEBUG - 2024-12-02 05:50:28 --> Total execution time: 0.0677
INFO - 2024-12-02 05:51:14 --> Config Class Initialized
INFO - 2024-12-02 05:51:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:14 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:14 --> URI Class Initialized
INFO - 2024-12-02 05:51:14 --> Router Class Initialized
INFO - 2024-12-02 05:51:14 --> Output Class Initialized
INFO - 2024-12-02 05:51:14 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:14 --> CSRF cookie sent
INFO - 2024-12-02 05:51:14 --> Input Class Initialized
INFO - 2024-12-02 05:51:14 --> Language Class Initialized
INFO - 2024-12-02 05:51:14 --> Loader Class Initialized
INFO - 2024-12-02 05:51:14 --> Helper loaded: url_helper
INFO - 2024-12-02 05:51:14 --> Helper loaded: form_helper
INFO - 2024-12-02 05:51:14 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:51:14 --> Form Validation Class Initialized
INFO - 2024-12-02 05:51:14 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:51:14 --> Controller Class Initialized
INFO - 2024-12-02 05:51:14 --> Model "Category_model" initialized
INFO - 2024-12-02 05:51:14 --> Model "User_model" initialized
INFO - 2024-12-02 05:51:14 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:51:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:51:14 --> Final output sent to browser
DEBUG - 2024-12-02 05:51:14 --> Total execution time: 0.4864
INFO - 2024-12-02 05:51:17 --> Config Class Initialized
INFO - 2024-12-02 05:51:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:17 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:17 --> URI Class Initialized
INFO - 2024-12-02 05:51:17 --> Router Class Initialized
INFO - 2024-12-02 05:51:17 --> Output Class Initialized
INFO - 2024-12-02 05:51:17 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:17 --> CSRF cookie sent
INFO - 2024-12-02 05:51:17 --> Input Class Initialized
INFO - 2024-12-02 05:51:17 --> Language Class Initialized
ERROR - 2024-12-02 05:51:17 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:19 --> Config Class Initialized
INFO - 2024-12-02 05:51:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:19 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:19 --> URI Class Initialized
INFO - 2024-12-02 05:51:19 --> Router Class Initialized
INFO - 2024-12-02 05:51:19 --> Output Class Initialized
INFO - 2024-12-02 05:51:19 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:19 --> CSRF cookie sent
INFO - 2024-12-02 05:51:19 --> Input Class Initialized
INFO - 2024-12-02 05:51:19 --> Language Class Initialized
ERROR - 2024-12-02 05:51:19 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:20 --> Config Class Initialized
INFO - 2024-12-02 05:51:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:20 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:20 --> URI Class Initialized
INFO - 2024-12-02 05:51:20 --> Router Class Initialized
INFO - 2024-12-02 05:51:20 --> Output Class Initialized
INFO - 2024-12-02 05:51:20 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:20 --> CSRF cookie sent
INFO - 2024-12-02 05:51:20 --> Input Class Initialized
INFO - 2024-12-02 05:51:20 --> Language Class Initialized
ERROR - 2024-12-02 05:51:20 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:20 --> Config Class Initialized
INFO - 2024-12-02 05:51:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:20 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:20 --> URI Class Initialized
INFO - 2024-12-02 05:51:20 --> Router Class Initialized
INFO - 2024-12-02 05:51:20 --> Output Class Initialized
INFO - 2024-12-02 05:51:20 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:20 --> CSRF cookie sent
INFO - 2024-12-02 05:51:20 --> Input Class Initialized
INFO - 2024-12-02 05:51:20 --> Language Class Initialized
ERROR - 2024-12-02 05:51:20 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:20 --> Config Class Initialized
INFO - 2024-12-02 05:51:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:20 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:20 --> URI Class Initialized
INFO - 2024-12-02 05:51:20 --> Router Class Initialized
INFO - 2024-12-02 05:51:20 --> Output Class Initialized
INFO - 2024-12-02 05:51:20 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:20 --> CSRF cookie sent
INFO - 2024-12-02 05:51:20 --> Input Class Initialized
INFO - 2024-12-02 05:51:20 --> Language Class Initialized
ERROR - 2024-12-02 05:51:20 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:20 --> Config Class Initialized
INFO - 2024-12-02 05:51:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:20 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:20 --> URI Class Initialized
INFO - 2024-12-02 05:51:20 --> Router Class Initialized
INFO - 2024-12-02 05:51:20 --> Output Class Initialized
INFO - 2024-12-02 05:51:20 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:20 --> CSRF cookie sent
INFO - 2024-12-02 05:51:20 --> Input Class Initialized
INFO - 2024-12-02 05:51:20 --> Language Class Initialized
ERROR - 2024-12-02 05:51:20 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:21 --> Config Class Initialized
INFO - 2024-12-02 05:51:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:21 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:21 --> URI Class Initialized
INFO - 2024-12-02 05:51:21 --> Router Class Initialized
INFO - 2024-12-02 05:51:21 --> Output Class Initialized
INFO - 2024-12-02 05:51:21 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:21 --> CSRF cookie sent
INFO - 2024-12-02 05:51:21 --> Input Class Initialized
INFO - 2024-12-02 05:51:21 --> Language Class Initialized
ERROR - 2024-12-02 05:51:21 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:21 --> Config Class Initialized
INFO - 2024-12-02 05:51:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:21 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:21 --> URI Class Initialized
INFO - 2024-12-02 05:51:21 --> Router Class Initialized
INFO - 2024-12-02 05:51:21 --> Output Class Initialized
INFO - 2024-12-02 05:51:21 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:21 --> CSRF cookie sent
INFO - 2024-12-02 05:51:21 --> Input Class Initialized
INFO - 2024-12-02 05:51:21 --> Language Class Initialized
ERROR - 2024-12-02 05:51:21 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:22 --> Config Class Initialized
INFO - 2024-12-02 05:51:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:22 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:22 --> URI Class Initialized
INFO - 2024-12-02 05:51:22 --> Router Class Initialized
INFO - 2024-12-02 05:51:22 --> Output Class Initialized
INFO - 2024-12-02 05:51:22 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:22 --> CSRF cookie sent
INFO - 2024-12-02 05:51:22 --> Input Class Initialized
INFO - 2024-12-02 05:51:22 --> Language Class Initialized
ERROR - 2024-12-02 05:51:22 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:22 --> Config Class Initialized
INFO - 2024-12-02 05:51:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:22 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:22 --> URI Class Initialized
INFO - 2024-12-02 05:51:22 --> Router Class Initialized
INFO - 2024-12-02 05:51:22 --> Output Class Initialized
INFO - 2024-12-02 05:51:22 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:22 --> CSRF cookie sent
INFO - 2024-12-02 05:51:22 --> Input Class Initialized
INFO - 2024-12-02 05:51:22 --> Language Class Initialized
ERROR - 2024-12-02 05:51:22 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:51:25 --> Config Class Initialized
INFO - 2024-12-02 05:51:25 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:51:25 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:51:25 --> Utf8 Class Initialized
INFO - 2024-12-02 05:51:25 --> URI Class Initialized
INFO - 2024-12-02 05:51:25 --> Router Class Initialized
INFO - 2024-12-02 05:51:25 --> Output Class Initialized
INFO - 2024-12-02 05:51:25 --> Security Class Initialized
DEBUG - 2024-12-02 05:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:51:25 --> CSRF cookie sent
INFO - 2024-12-02 05:51:25 --> Input Class Initialized
INFO - 2024-12-02 05:51:25 --> Language Class Initialized
INFO - 2024-12-02 05:51:25 --> Loader Class Initialized
INFO - 2024-12-02 05:51:25 --> Helper loaded: url_helper
INFO - 2024-12-02 05:51:25 --> Helper loaded: form_helper
INFO - 2024-12-02 05:51:25 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:51:26 --> Form Validation Class Initialized
INFO - 2024-12-02 05:51:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:51:26 --> Controller Class Initialized
INFO - 2024-12-02 05:51:26 --> Model "Category_model" initialized
INFO - 2024-12-02 05:51:26 --> Model "User_model" initialized
INFO - 2024-12-02 05:51:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:51:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:51:26 --> Final output sent to browser
DEBUG - 2024-12-02 05:51:26 --> Total execution time: 0.3541
INFO - 2024-12-02 05:54:08 --> Config Class Initialized
INFO - 2024-12-02 05:54:08 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:08 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:08 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:08 --> URI Class Initialized
INFO - 2024-12-02 05:54:08 --> Router Class Initialized
INFO - 2024-12-02 05:54:08 --> Output Class Initialized
INFO - 2024-12-02 05:54:08 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:08 --> CSRF cookie sent
INFO - 2024-12-02 05:54:08 --> Input Class Initialized
INFO - 2024-12-02 05:54:08 --> Language Class Initialized
ERROR - 2024-12-02 05:54:08 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:54:16 --> Config Class Initialized
INFO - 2024-12-02 05:54:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:16 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:16 --> URI Class Initialized
INFO - 2024-12-02 05:54:16 --> Router Class Initialized
INFO - 2024-12-02 05:54:16 --> Output Class Initialized
INFO - 2024-12-02 05:54:16 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:16 --> CSRF cookie sent
INFO - 2024-12-02 05:54:16 --> Input Class Initialized
INFO - 2024-12-02 05:54:16 --> Language Class Initialized
ERROR - 2024-12-02 05:54:16 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:54:16 --> Config Class Initialized
INFO - 2024-12-02 05:54:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:16 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:16 --> URI Class Initialized
INFO - 2024-12-02 05:54:16 --> Router Class Initialized
INFO - 2024-12-02 05:54:16 --> Output Class Initialized
INFO - 2024-12-02 05:54:16 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:16 --> CSRF cookie sent
INFO - 2024-12-02 05:54:16 --> Input Class Initialized
INFO - 2024-12-02 05:54:16 --> Language Class Initialized
ERROR - 2024-12-02 05:54:16 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:54:17 --> Config Class Initialized
INFO - 2024-12-02 05:54:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:17 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:17 --> URI Class Initialized
INFO - 2024-12-02 05:54:17 --> Router Class Initialized
INFO - 2024-12-02 05:54:17 --> Output Class Initialized
INFO - 2024-12-02 05:54:17 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:17 --> CSRF cookie sent
INFO - 2024-12-02 05:54:17 --> Input Class Initialized
INFO - 2024-12-02 05:54:17 --> Language Class Initialized
ERROR - 2024-12-02 05:54:17 --> 404 Page Not Found: Admin/news_list
INFO - 2024-12-02 05:54:17 --> Config Class Initialized
INFO - 2024-12-02 05:54:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:17 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:17 --> URI Class Initialized
INFO - 2024-12-02 05:54:17 --> Router Class Initialized
INFO - 2024-12-02 05:54:17 --> Output Class Initialized
INFO - 2024-12-02 05:54:17 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:17 --> CSRF cookie sent
INFO - 2024-12-02 05:54:17 --> Input Class Initialized
INFO - 2024-12-02 05:54:17 --> Language Class Initialized
INFO - 2024-12-02 05:54:17 --> Loader Class Initialized
INFO - 2024-12-02 05:54:17 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:17 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:17 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:17 --> Controller Class Initialized
INFO - 2024-12-02 05:54:17 --> Model "Category_model" initialized
INFO - 2024-12-02 05:54:17 --> Model "User_model" initialized
INFO - 2024-12-02 05:54:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:54:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:54:18 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:18 --> Total execution time: 0.4071
INFO - 2024-12-02 05:54:19 --> Config Class Initialized
INFO - 2024-12-02 05:54:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:19 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:19 --> URI Class Initialized
INFO - 2024-12-02 05:54:19 --> Router Class Initialized
INFO - 2024-12-02 05:54:19 --> Output Class Initialized
INFO - 2024-12-02 05:54:19 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:19 --> CSRF cookie sent
INFO - 2024-12-02 05:54:19 --> Input Class Initialized
INFO - 2024-12-02 05:54:19 --> Language Class Initialized
INFO - 2024-12-02 05:54:19 --> Loader Class Initialized
INFO - 2024-12-02 05:54:19 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:19 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:19 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:19 --> Controller Class Initialized
INFO - 2024-12-02 05:54:19 --> Model "Category_model" initialized
INFO - 2024-12-02 05:54:19 --> Model "User_model" initialized
INFO - 2024-12-02 05:54:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:54:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:54:19 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:19 --> Total execution time: 0.0478
INFO - 2024-12-02 05:54:19 --> Config Class Initialized
INFO - 2024-12-02 05:54:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:19 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:19 --> URI Class Initialized
INFO - 2024-12-02 05:54:19 --> Router Class Initialized
INFO - 2024-12-02 05:54:19 --> Output Class Initialized
INFO - 2024-12-02 05:54:19 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:19 --> CSRF cookie sent
INFO - 2024-12-02 05:54:19 --> Input Class Initialized
INFO - 2024-12-02 05:54:19 --> Language Class Initialized
INFO - 2024-12-02 05:54:19 --> Loader Class Initialized
INFO - 2024-12-02 05:54:19 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:19 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:19 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:19 --> Controller Class Initialized
INFO - 2024-12-02 05:54:19 --> Model "Category_model" initialized
INFO - 2024-12-02 05:54:19 --> Model "User_model" initialized
INFO - 2024-12-02 05:54:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:54:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:54:19 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:19 --> Total execution time: 0.0867
INFO - 2024-12-02 05:54:19 --> Config Class Initialized
INFO - 2024-12-02 05:54:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:19 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:19 --> URI Class Initialized
INFO - 2024-12-02 05:54:19 --> Router Class Initialized
INFO - 2024-12-02 05:54:19 --> Output Class Initialized
INFO - 2024-12-02 05:54:19 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:19 --> CSRF cookie sent
INFO - 2024-12-02 05:54:19 --> Input Class Initialized
INFO - 2024-12-02 05:54:19 --> Language Class Initialized
INFO - 2024-12-02 05:54:19 --> Loader Class Initialized
INFO - 2024-12-02 05:54:19 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:19 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:19 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:19 --> Controller Class Initialized
INFO - 2024-12-02 05:54:19 --> Model "Category_model" initialized
INFO - 2024-12-02 05:54:19 --> Model "User_model" initialized
INFO - 2024-12-02 05:54:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:54:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:54:19 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:19 --> Total execution time: 0.0570
INFO - 2024-12-02 05:54:20 --> Config Class Initialized
INFO - 2024-12-02 05:54:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:20 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:20 --> URI Class Initialized
INFO - 2024-12-02 05:54:20 --> Router Class Initialized
INFO - 2024-12-02 05:54:20 --> Output Class Initialized
INFO - 2024-12-02 05:54:20 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:20 --> CSRF cookie sent
INFO - 2024-12-02 05:54:20 --> Input Class Initialized
INFO - 2024-12-02 05:54:20 --> Language Class Initialized
INFO - 2024-12-02 05:54:20 --> Loader Class Initialized
INFO - 2024-12-02 05:54:20 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:20 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:20 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:20 --> Controller Class Initialized
INFO - 2024-12-02 05:54:20 --> Model "Category_model" initialized
INFO - 2024-12-02 05:54:20 --> Model "User_model" initialized
INFO - 2024-12-02 05:54:20 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:54:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:54:20 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:20 --> Total execution time: 0.0640
INFO - 2024-12-02 05:54:20 --> Config Class Initialized
INFO - 2024-12-02 05:54:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:20 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:20 --> URI Class Initialized
INFO - 2024-12-02 05:54:20 --> Router Class Initialized
INFO - 2024-12-02 05:54:20 --> Output Class Initialized
INFO - 2024-12-02 05:54:20 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:20 --> CSRF cookie sent
INFO - 2024-12-02 05:54:20 --> Input Class Initialized
INFO - 2024-12-02 05:54:20 --> Language Class Initialized
INFO - 2024-12-02 05:54:20 --> Loader Class Initialized
INFO - 2024-12-02 05:54:20 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:20 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:20 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:20 --> Controller Class Initialized
INFO - 2024-12-02 05:54:20 --> Model "Category_model" initialized
INFO - 2024-12-02 05:54:20 --> Model "User_model" initialized
INFO - 2024-12-02 05:54:20 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 05:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 05:54:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 05:54:20 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:20 --> Total execution time: 0.0830
INFO - 2024-12-02 05:54:21 --> Config Class Initialized
INFO - 2024-12-02 05:54:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:21 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:21 --> URI Class Initialized
INFO - 2024-12-02 05:54:21 --> Router Class Initialized
INFO - 2024-12-02 05:54:21 --> Output Class Initialized
INFO - 2024-12-02 05:54:21 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:21 --> CSRF cookie sent
INFO - 2024-12-02 05:54:21 --> Input Class Initialized
INFO - 2024-12-02 05:54:21 --> Language Class Initialized
INFO - 2024-12-02 05:54:21 --> Loader Class Initialized
INFO - 2024-12-02 05:54:21 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:21 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:21 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:21 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:21 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:21 --> Controller Class Initialized
INFO - 2024-12-02 05:54:21 --> Model "News_model" initialized
INFO - 2024-12-02 05:54:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 05:54:21 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:21 --> Total execution time: 0.0986
INFO - 2024-12-02 05:54:28 --> Config Class Initialized
INFO - 2024-12-02 05:54:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 05:54:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 05:54:28 --> Utf8 Class Initialized
INFO - 2024-12-02 05:54:28 --> URI Class Initialized
INFO - 2024-12-02 05:54:28 --> Router Class Initialized
INFO - 2024-12-02 05:54:28 --> Output Class Initialized
INFO - 2024-12-02 05:54:28 --> Security Class Initialized
DEBUG - 2024-12-02 05:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 05:54:28 --> CSRF cookie sent
INFO - 2024-12-02 05:54:28 --> Input Class Initialized
INFO - 2024-12-02 05:54:28 --> Language Class Initialized
INFO - 2024-12-02 05:54:28 --> Loader Class Initialized
INFO - 2024-12-02 05:54:28 --> Helper loaded: url_helper
INFO - 2024-12-02 05:54:28 --> Helper loaded: form_helper
INFO - 2024-12-02 05:54:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 05:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 05:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 05:54:28 --> Form Validation Class Initialized
INFO - 2024-12-02 05:54:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 05:54:28 --> Controller Class Initialized
INFO - 2024-12-02 05:54:28 --> Model "News_model" initialized
INFO - 2024-12-02 05:54:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 05:54:28 --> Final output sent to browser
DEBUG - 2024-12-02 05:54:28 --> Total execution time: 0.0404
INFO - 2024-12-02 06:09:20 --> Config Class Initialized
INFO - 2024-12-02 06:09:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:09:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:09:20 --> Utf8 Class Initialized
INFO - 2024-12-02 06:09:20 --> URI Class Initialized
INFO - 2024-12-02 06:09:20 --> Router Class Initialized
INFO - 2024-12-02 06:09:20 --> Output Class Initialized
INFO - 2024-12-02 06:09:20 --> Security Class Initialized
DEBUG - 2024-12-02 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:09:20 --> CSRF cookie sent
INFO - 2024-12-02 06:11:21 --> Config Class Initialized
INFO - 2024-12-02 06:11:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:11:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:11:22 --> Utf8 Class Initialized
INFO - 2024-12-02 06:11:22 --> URI Class Initialized
INFO - 2024-12-02 06:11:22 --> Router Class Initialized
INFO - 2024-12-02 06:11:22 --> Output Class Initialized
INFO - 2024-12-02 06:11:22 --> Security Class Initialized
DEBUG - 2024-12-02 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:11:22 --> CSRF cookie sent
INFO - 2024-12-02 06:11:22 --> Input Class Initialized
INFO - 2024-12-02 06:11:22 --> Language Class Initialized
INFO - 2024-12-02 06:11:22 --> Loader Class Initialized
INFO - 2024-12-02 06:11:22 --> Helper loaded: url_helper
INFO - 2024-12-02 06:11:22 --> Helper loaded: form_helper
INFO - 2024-12-02 06:11:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:11:22 --> Form Validation Class Initialized
INFO - 2024-12-02 06:11:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:11:22 --> Controller Class Initialized
INFO - 2024-12-02 06:11:22 --> Model "News_model" initialized
INFO - 2024-12-02 06:11:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:11:22 --> Final output sent to browser
DEBUG - 2024-12-02 06:11:22 --> Total execution time: 0.5115
INFO - 2024-12-02 06:11:24 --> Config Class Initialized
INFO - 2024-12-02 06:11:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:11:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:11:24 --> Utf8 Class Initialized
INFO - 2024-12-02 06:11:24 --> URI Class Initialized
INFO - 2024-12-02 06:11:24 --> Router Class Initialized
INFO - 2024-12-02 06:11:24 --> Output Class Initialized
INFO - 2024-12-02 06:11:24 --> Security Class Initialized
DEBUG - 2024-12-02 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:11:24 --> CSRF cookie sent
INFO - 2024-12-02 06:14:39 --> Config Class Initialized
INFO - 2024-12-02 06:14:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:14:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:14:39 --> Utf8 Class Initialized
INFO - 2024-12-02 06:14:39 --> URI Class Initialized
INFO - 2024-12-02 06:14:39 --> Router Class Initialized
INFO - 2024-12-02 06:14:39 --> Output Class Initialized
INFO - 2024-12-02 06:14:39 --> Security Class Initialized
DEBUG - 2024-12-02 06:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:14:39 --> CSRF cookie sent
INFO - 2024-12-02 06:14:39 --> Input Class Initialized
INFO - 2024-12-02 06:14:39 --> Language Class Initialized
INFO - 2024-12-02 06:14:39 --> Loader Class Initialized
INFO - 2024-12-02 06:14:39 --> Helper loaded: url_helper
INFO - 2024-12-02 06:14:39 --> Helper loaded: form_helper
INFO - 2024-12-02 06:14:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:14:39 --> Form Validation Class Initialized
INFO - 2024-12-02 06:14:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:14:39 --> Controller Class Initialized
INFO - 2024-12-02 06:14:39 --> Model "News_model" initialized
INFO - 2024-12-02 06:14:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:14:39 --> Final output sent to browser
DEBUG - 2024-12-02 06:14:39 --> Total execution time: 0.2835
INFO - 2024-12-02 06:15:15 --> Config Class Initialized
INFO - 2024-12-02 06:15:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:15:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:15:15 --> Utf8 Class Initialized
INFO - 2024-12-02 06:15:15 --> URI Class Initialized
INFO - 2024-12-02 06:15:15 --> Router Class Initialized
INFO - 2024-12-02 06:15:15 --> Output Class Initialized
INFO - 2024-12-02 06:15:15 --> Security Class Initialized
DEBUG - 2024-12-02 06:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:15:15 --> CSRF cookie sent
INFO - 2024-12-02 06:15:15 --> Input Class Initialized
INFO - 2024-12-02 06:15:15 --> Language Class Initialized
INFO - 2024-12-02 06:15:15 --> Loader Class Initialized
INFO - 2024-12-02 06:15:15 --> Helper loaded: url_helper
INFO - 2024-12-02 06:15:15 --> Helper loaded: form_helper
INFO - 2024-12-02 06:15:15 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:15:15 --> Form Validation Class Initialized
INFO - 2024-12-02 06:15:15 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:15:15 --> Controller Class Initialized
INFO - 2024-12-02 06:15:15 --> Model "News_model" initialized
INFO - 2024-12-02 06:15:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:15:15 --> Final output sent to browser
DEBUG - 2024-12-02 06:15:15 --> Total execution time: 0.0686
INFO - 2024-12-02 06:15:20 --> Config Class Initialized
INFO - 2024-12-02 06:15:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:15:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:15:20 --> Utf8 Class Initialized
INFO - 2024-12-02 06:15:20 --> URI Class Initialized
INFO - 2024-12-02 06:15:20 --> Router Class Initialized
INFO - 2024-12-02 06:15:21 --> Output Class Initialized
INFO - 2024-12-02 06:15:21 --> Security Class Initialized
DEBUG - 2024-12-02 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:15:21 --> CSRF cookie sent
INFO - 2024-12-02 06:15:21 --> CSRF token verified
INFO - 2024-12-02 06:15:21 --> Input Class Initialized
INFO - 2024-12-02 06:15:21 --> Language Class Initialized
ERROR - 2024-12-02 06:15:21 --> 404 Page Not Found: Admin/news
INFO - 2024-12-02 06:15:31 --> Config Class Initialized
INFO - 2024-12-02 06:15:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:15:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:15:31 --> Utf8 Class Initialized
INFO - 2024-12-02 06:15:31 --> URI Class Initialized
INFO - 2024-12-02 06:15:31 --> Router Class Initialized
INFO - 2024-12-02 06:15:31 --> Output Class Initialized
INFO - 2024-12-02 06:15:31 --> Security Class Initialized
DEBUG - 2024-12-02 06:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:15:31 --> CSRF cookie sent
INFO - 2024-12-02 06:15:31 --> Input Class Initialized
INFO - 2024-12-02 06:15:31 --> Language Class Initialized
INFO - 2024-12-02 06:15:31 --> Loader Class Initialized
INFO - 2024-12-02 06:15:31 --> Helper loaded: url_helper
INFO - 2024-12-02 06:15:31 --> Helper loaded: form_helper
INFO - 2024-12-02 06:15:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:15:31 --> Form Validation Class Initialized
INFO - 2024-12-02 06:15:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:15:31 --> Controller Class Initialized
INFO - 2024-12-02 06:15:31 --> Model "News_model" initialized
INFO - 2024-12-02 06:15:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:15:31 --> Final output sent to browser
DEBUG - 2024-12-02 06:15:31 --> Total execution time: 0.0762
INFO - 2024-12-02 06:15:35 --> Config Class Initialized
INFO - 2024-12-02 06:15:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:15:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:15:35 --> Utf8 Class Initialized
INFO - 2024-12-02 06:15:35 --> URI Class Initialized
INFO - 2024-12-02 06:15:35 --> Router Class Initialized
INFO - 2024-12-02 06:15:35 --> Output Class Initialized
INFO - 2024-12-02 06:15:35 --> Security Class Initialized
DEBUG - 2024-12-02 06:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:15:35 --> CSRF cookie sent
INFO - 2024-12-02 06:15:35 --> CSRF token verified
INFO - 2024-12-02 06:15:35 --> Input Class Initialized
INFO - 2024-12-02 06:15:35 --> Language Class Initialized
ERROR - 2024-12-02 06:15:35 --> 404 Page Not Found: Admin/news
INFO - 2024-12-02 06:20:51 --> Config Class Initialized
INFO - 2024-12-02 06:20:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:20:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:20:51 --> Utf8 Class Initialized
INFO - 2024-12-02 06:20:51 --> URI Class Initialized
INFO - 2024-12-02 06:20:51 --> Router Class Initialized
INFO - 2024-12-02 06:20:51 --> Output Class Initialized
INFO - 2024-12-02 06:20:51 --> Security Class Initialized
DEBUG - 2024-12-02 06:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:20:51 --> CSRF cookie sent
INFO - 2024-12-02 06:20:51 --> Input Class Initialized
INFO - 2024-12-02 06:20:51 --> Language Class Initialized
INFO - 2024-12-02 06:20:51 --> Loader Class Initialized
INFO - 2024-12-02 06:20:51 --> Helper loaded: url_helper
INFO - 2024-12-02 06:20:51 --> Helper loaded: form_helper
INFO - 2024-12-02 06:20:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:20:52 --> Form Validation Class Initialized
INFO - 2024-12-02 06:20:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:20:52 --> Controller Class Initialized
INFO - 2024-12-02 06:20:52 --> Model "News_model" initialized
INFO - 2024-12-02 06:20:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:20:52 --> Final output sent to browser
DEBUG - 2024-12-02 06:20:52 --> Total execution time: 0.2871
INFO - 2024-12-02 06:20:53 --> Config Class Initialized
INFO - 2024-12-02 06:20:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:20:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:20:53 --> Utf8 Class Initialized
INFO - 2024-12-02 06:20:53 --> URI Class Initialized
INFO - 2024-12-02 06:20:53 --> Router Class Initialized
INFO - 2024-12-02 06:20:53 --> Output Class Initialized
INFO - 2024-12-02 06:20:53 --> Security Class Initialized
DEBUG - 2024-12-02 06:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:20:53 --> CSRF cookie sent
INFO - 2024-12-02 06:20:53 --> Input Class Initialized
INFO - 2024-12-02 06:20:53 --> Language Class Initialized
INFO - 2024-12-02 06:20:53 --> Loader Class Initialized
INFO - 2024-12-02 06:20:53 --> Helper loaded: url_helper
INFO - 2024-12-02 06:20:53 --> Helper loaded: form_helper
INFO - 2024-12-02 06:20:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:20:54 --> Form Validation Class Initialized
INFO - 2024-12-02 06:20:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:20:54 --> Controller Class Initialized
INFO - 2024-12-02 06:20:54 --> Model "News_model" initialized
INFO - 2024-12-02 06:20:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:20:54 --> Final output sent to browser
DEBUG - 2024-12-02 06:20:54 --> Total execution time: 0.0794
INFO - 2024-12-02 06:21:00 --> Config Class Initialized
INFO - 2024-12-02 06:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:00 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:00 --> URI Class Initialized
INFO - 2024-12-02 06:21:00 --> Router Class Initialized
INFO - 2024-12-02 06:21:00 --> Output Class Initialized
INFO - 2024-12-02 06:21:00 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:00 --> CSRF cookie sent
INFO - 2024-12-02 06:21:00 --> CSRF token verified
INFO - 2024-12-02 06:21:00 --> Input Class Initialized
INFO - 2024-12-02 06:21:00 --> Language Class Initialized
INFO - 2024-12-02 06:21:00 --> Loader Class Initialized
INFO - 2024-12-02 06:21:00 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:00 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:00 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:00 --> Controller Class Initialized
INFO - 2024-12-02 06:21:00 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:00 --> Config Class Initialized
INFO - 2024-12-02 06:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:00 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:00 --> URI Class Initialized
INFO - 2024-12-02 06:21:00 --> Router Class Initialized
INFO - 2024-12-02 06:21:00 --> Output Class Initialized
INFO - 2024-12-02 06:21:00 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:00 --> CSRF cookie sent
INFO - 2024-12-02 06:21:00 --> Input Class Initialized
INFO - 2024-12-02 06:21:00 --> Language Class Initialized
INFO - 2024-12-02 06:21:00 --> Loader Class Initialized
INFO - 2024-12-02 06:21:00 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:00 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:00 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:00 --> Controller Class Initialized
INFO - 2024-12-02 06:21:00 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:21:00 --> Final output sent to browser
DEBUG - 2024-12-02 06:21:00 --> Total execution time: 0.0613
INFO - 2024-12-02 06:21:00 --> Config Class Initialized
INFO - 2024-12-02 06:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:00 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:00 --> URI Class Initialized
INFO - 2024-12-02 06:21:00 --> Router Class Initialized
INFO - 2024-12-02 06:21:00 --> Output Class Initialized
INFO - 2024-12-02 06:21:00 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:00 --> CSRF cookie sent
INFO - 2024-12-02 06:21:00 --> Input Class Initialized
INFO - 2024-12-02 06:21:00 --> Language Class Initialized
ERROR - 2024-12-02 06:21:00 --> 404 Page Not Found: Admin/gtr
INFO - 2024-12-02 06:21:07 --> Config Class Initialized
INFO - 2024-12-02 06:21:07 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:07 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:07 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:07 --> URI Class Initialized
INFO - 2024-12-02 06:21:07 --> Router Class Initialized
INFO - 2024-12-02 06:21:07 --> Output Class Initialized
INFO - 2024-12-02 06:21:07 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:07 --> CSRF cookie sent
INFO - 2024-12-02 06:21:07 --> Input Class Initialized
INFO - 2024-12-02 06:21:07 --> Language Class Initialized
INFO - 2024-12-02 06:21:07 --> Loader Class Initialized
INFO - 2024-12-02 06:21:07 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:07 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:07 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:07 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:07 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:07 --> Controller Class Initialized
INFO - 2024-12-02 06:21:07 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:07 --> Config Class Initialized
INFO - 2024-12-02 06:21:07 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:07 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:07 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:07 --> URI Class Initialized
INFO - 2024-12-02 06:21:07 --> Router Class Initialized
INFO - 2024-12-02 06:21:07 --> Output Class Initialized
INFO - 2024-12-02 06:21:07 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:07 --> CSRF cookie sent
INFO - 2024-12-02 06:21:07 --> Input Class Initialized
INFO - 2024-12-02 06:21:07 --> Language Class Initialized
INFO - 2024-12-02 06:21:07 --> Loader Class Initialized
INFO - 2024-12-02 06:21:07 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:07 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:07 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:07 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:07 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:07 --> Controller Class Initialized
INFO - 2024-12-02 06:21:07 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:21:07 --> Final output sent to browser
DEBUG - 2024-12-02 06:21:07 --> Total execution time: 0.0470
INFO - 2024-12-02 06:21:13 --> Config Class Initialized
INFO - 2024-12-02 06:21:13 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:13 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:13 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:13 --> URI Class Initialized
INFO - 2024-12-02 06:21:13 --> Router Class Initialized
INFO - 2024-12-02 06:21:13 --> Output Class Initialized
INFO - 2024-12-02 06:21:13 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:13 --> CSRF cookie sent
INFO - 2024-12-02 06:21:13 --> Input Class Initialized
INFO - 2024-12-02 06:21:13 --> Language Class Initialized
INFO - 2024-12-02 06:21:13 --> Loader Class Initialized
INFO - 2024-12-02 06:21:13 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:13 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:13 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:13 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:13 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:13 --> Controller Class Initialized
INFO - 2024-12-02 06:21:13 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:21:13 --> Final output sent to browser
DEBUG - 2024-12-02 06:21:13 --> Total execution time: 0.0585
INFO - 2024-12-02 06:21:15 --> Config Class Initialized
INFO - 2024-12-02 06:21:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:15 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:15 --> URI Class Initialized
INFO - 2024-12-02 06:21:15 --> Router Class Initialized
INFO - 2024-12-02 06:21:15 --> Output Class Initialized
INFO - 2024-12-02 06:21:15 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:15 --> CSRF cookie sent
INFO - 2024-12-02 06:21:55 --> Config Class Initialized
INFO - 2024-12-02 06:21:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:55 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:55 --> URI Class Initialized
INFO - 2024-12-02 06:21:55 --> Router Class Initialized
INFO - 2024-12-02 06:21:55 --> Output Class Initialized
INFO - 2024-12-02 06:21:55 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:55 --> CSRF cookie sent
INFO - 2024-12-02 06:21:55 --> Input Class Initialized
INFO - 2024-12-02 06:21:55 --> Language Class Initialized
INFO - 2024-12-02 06:21:55 --> Loader Class Initialized
INFO - 2024-12-02 06:21:55 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:55 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:55 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:55 --> Controller Class Initialized
INFO - 2024-12-02 06:21:55 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:21:55 --> Final output sent to browser
DEBUG - 2024-12-02 06:21:55 --> Total execution time: 0.0512
INFO - 2024-12-02 06:21:57 --> Config Class Initialized
INFO - 2024-12-02 06:21:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:57 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:57 --> URI Class Initialized
INFO - 2024-12-02 06:21:57 --> Router Class Initialized
INFO - 2024-12-02 06:21:57 --> Output Class Initialized
INFO - 2024-12-02 06:21:57 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:57 --> CSRF cookie sent
INFO - 2024-12-02 06:21:59 --> Config Class Initialized
INFO - 2024-12-02 06:21:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:21:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:21:59 --> Utf8 Class Initialized
INFO - 2024-12-02 06:21:59 --> URI Class Initialized
INFO - 2024-12-02 06:21:59 --> Router Class Initialized
INFO - 2024-12-02 06:21:59 --> Output Class Initialized
INFO - 2024-12-02 06:21:59 --> Security Class Initialized
DEBUG - 2024-12-02 06:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:21:59 --> CSRF cookie sent
INFO - 2024-12-02 06:21:59 --> Input Class Initialized
INFO - 2024-12-02 06:21:59 --> Language Class Initialized
INFO - 2024-12-02 06:21:59 --> Loader Class Initialized
INFO - 2024-12-02 06:21:59 --> Helper loaded: url_helper
INFO - 2024-12-02 06:21:59 --> Helper loaded: form_helper
INFO - 2024-12-02 06:21:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:21:59 --> Form Validation Class Initialized
INFO - 2024-12-02 06:21:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:21:59 --> Controller Class Initialized
INFO - 2024-12-02 06:21:59 --> Model "News_model" initialized
INFO - 2024-12-02 06:21:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:21:59 --> Final output sent to browser
DEBUG - 2024-12-02 06:21:59 --> Total execution time: 0.0387
INFO - 2024-12-02 06:22:01 --> Config Class Initialized
INFO - 2024-12-02 06:22:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:22:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:22:01 --> Utf8 Class Initialized
INFO - 2024-12-02 06:22:01 --> URI Class Initialized
INFO - 2024-12-02 06:22:01 --> Router Class Initialized
INFO - 2024-12-02 06:22:01 --> Output Class Initialized
INFO - 2024-12-02 06:22:01 --> Security Class Initialized
DEBUG - 2024-12-02 06:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:22:01 --> CSRF cookie sent
INFO - 2024-12-02 06:22:01 --> Input Class Initialized
INFO - 2024-12-02 06:22:01 --> Language Class Initialized
INFO - 2024-12-02 06:22:01 --> Loader Class Initialized
INFO - 2024-12-02 06:22:01 --> Helper loaded: url_helper
INFO - 2024-12-02 06:22:01 --> Helper loaded: form_helper
INFO - 2024-12-02 06:22:01 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:22:01 --> Form Validation Class Initialized
INFO - 2024-12-02 06:22:01 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:22:01 --> Controller Class Initialized
INFO - 2024-12-02 06:22:01 --> Model "News_model" initialized
INFO - 2024-12-02 06:22:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:22:01 --> Final output sent to browser
DEBUG - 2024-12-02 06:22:01 --> Total execution time: 0.0484
INFO - 2024-12-02 06:22:02 --> Config Class Initialized
INFO - 2024-12-02 06:22:02 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:22:02 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:22:02 --> Utf8 Class Initialized
INFO - 2024-12-02 06:22:02 --> URI Class Initialized
INFO - 2024-12-02 06:22:02 --> Router Class Initialized
INFO - 2024-12-02 06:22:02 --> Output Class Initialized
INFO - 2024-12-02 06:22:02 --> Security Class Initialized
DEBUG - 2024-12-02 06:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:22:02 --> CSRF cookie sent
INFO - 2024-12-02 06:22:02 --> Input Class Initialized
INFO - 2024-12-02 06:22:02 --> Language Class Initialized
INFO - 2024-12-02 06:22:02 --> Loader Class Initialized
INFO - 2024-12-02 06:22:02 --> Helper loaded: url_helper
INFO - 2024-12-02 06:22:02 --> Helper loaded: form_helper
INFO - 2024-12-02 06:22:02 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:22:02 --> Form Validation Class Initialized
INFO - 2024-12-02 06:22:02 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:22:02 --> Controller Class Initialized
INFO - 2024-12-02 06:22:02 --> Model "News_model" initialized
INFO - 2024-12-02 06:22:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:22:02 --> Final output sent to browser
DEBUG - 2024-12-02 06:22:02 --> Total execution time: 0.0588
INFO - 2024-12-02 06:22:03 --> Config Class Initialized
INFO - 2024-12-02 06:22:03 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:22:03 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:22:03 --> Utf8 Class Initialized
INFO - 2024-12-02 06:22:03 --> URI Class Initialized
INFO - 2024-12-02 06:22:03 --> Router Class Initialized
INFO - 2024-12-02 06:22:03 --> Output Class Initialized
INFO - 2024-12-02 06:22:03 --> Security Class Initialized
DEBUG - 2024-12-02 06:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:22:03 --> CSRF cookie sent
INFO - 2024-12-02 06:22:03 --> Input Class Initialized
INFO - 2024-12-02 06:22:03 --> Language Class Initialized
INFO - 2024-12-02 06:22:03 --> Loader Class Initialized
INFO - 2024-12-02 06:22:03 --> Helper loaded: url_helper
INFO - 2024-12-02 06:22:03 --> Helper loaded: form_helper
INFO - 2024-12-02 06:22:03 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:22:03 --> Form Validation Class Initialized
INFO - 2024-12-02 06:22:03 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:22:03 --> Controller Class Initialized
INFO - 2024-12-02 06:22:03 --> Model "News_model" initialized
INFO - 2024-12-02 06:22:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:22:03 --> Final output sent to browser
DEBUG - 2024-12-02 06:22:03 --> Total execution time: 0.0559
INFO - 2024-12-02 06:22:08 --> Config Class Initialized
INFO - 2024-12-02 06:22:08 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:22:08 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:22:08 --> Utf8 Class Initialized
INFO - 2024-12-02 06:22:08 --> URI Class Initialized
INFO - 2024-12-02 06:22:08 --> Router Class Initialized
INFO - 2024-12-02 06:22:08 --> Output Class Initialized
INFO - 2024-12-02 06:22:08 --> Security Class Initialized
DEBUG - 2024-12-02 06:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:22:08 --> CSRF cookie sent
INFO - 2024-12-02 06:24:34 --> Config Class Initialized
INFO - 2024-12-02 06:24:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:24:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:24:34 --> Utf8 Class Initialized
INFO - 2024-12-02 06:24:34 --> URI Class Initialized
INFO - 2024-12-02 06:24:34 --> Router Class Initialized
INFO - 2024-12-02 06:24:34 --> Output Class Initialized
INFO - 2024-12-02 06:24:34 --> Security Class Initialized
DEBUG - 2024-12-02 06:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:24:34 --> CSRF cookie sent
INFO - 2024-12-02 06:24:34 --> Input Class Initialized
INFO - 2024-12-02 06:24:34 --> Language Class Initialized
INFO - 2024-12-02 06:24:34 --> Loader Class Initialized
INFO - 2024-12-02 06:24:34 --> Helper loaded: url_helper
INFO - 2024-12-02 06:24:34 --> Helper loaded: form_helper
INFO - 2024-12-02 06:24:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:24:34 --> Form Validation Class Initialized
INFO - 2024-12-02 06:24:34 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:24:34 --> Controller Class Initialized
INFO - 2024-12-02 06:24:34 --> Model "News_model" initialized
INFO - 2024-12-02 06:24:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:24:34 --> Final output sent to browser
DEBUG - 2024-12-02 06:24:34 --> Total execution time: 0.4526
INFO - 2024-12-02 06:24:37 --> Config Class Initialized
INFO - 2024-12-02 06:24:37 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:24:37 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:24:37 --> Utf8 Class Initialized
INFO - 2024-12-02 06:24:37 --> URI Class Initialized
INFO - 2024-12-02 06:24:37 --> Router Class Initialized
INFO - 2024-12-02 06:24:37 --> Output Class Initialized
INFO - 2024-12-02 06:24:37 --> Security Class Initialized
DEBUG - 2024-12-02 06:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:24:37 --> CSRF cookie sent
INFO - 2024-12-02 06:24:37 --> Input Class Initialized
INFO - 2024-12-02 06:24:37 --> Language Class Initialized
INFO - 2024-12-02 06:24:37 --> Loader Class Initialized
INFO - 2024-12-02 06:24:37 --> Helper loaded: url_helper
INFO - 2024-12-02 06:24:37 --> Helper loaded: form_helper
INFO - 2024-12-02 06:24:37 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:24:37 --> Form Validation Class Initialized
INFO - 2024-12-02 06:24:37 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:24:37 --> Controller Class Initialized
INFO - 2024-12-02 06:24:37 --> Model "News_model" initialized
INFO - 2024-12-02 06:24:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:24:37 --> Final output sent to browser
DEBUG - 2024-12-02 06:24:37 --> Total execution time: 0.0889
INFO - 2024-12-02 06:24:39 --> Config Class Initialized
INFO - 2024-12-02 06:24:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:24:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:24:39 --> Utf8 Class Initialized
INFO - 2024-12-02 06:24:39 --> URI Class Initialized
INFO - 2024-12-02 06:24:39 --> Router Class Initialized
INFO - 2024-12-02 06:24:39 --> Output Class Initialized
INFO - 2024-12-02 06:24:39 --> Security Class Initialized
DEBUG - 2024-12-02 06:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:24:39 --> CSRF cookie sent
INFO - 2024-12-02 06:24:39 --> CSRF token verified
INFO - 2024-12-02 06:24:39 --> Input Class Initialized
INFO - 2024-12-02 06:24:39 --> Language Class Initialized
INFO - 2024-12-02 06:24:39 --> Loader Class Initialized
INFO - 2024-12-02 06:24:39 --> Helper loaded: url_helper
INFO - 2024-12-02 06:24:39 --> Helper loaded: form_helper
INFO - 2024-12-02 06:24:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:24:39 --> Form Validation Class Initialized
INFO - 2024-12-02 06:24:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:24:39 --> Controller Class Initialized
INFO - 2024-12-02 06:24:39 --> Model "News_model" initialized
INFO - 2024-12-02 06:24:39 --> Config Class Initialized
INFO - 2024-12-02 06:24:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:24:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:24:39 --> Utf8 Class Initialized
INFO - 2024-12-02 06:24:39 --> URI Class Initialized
INFO - 2024-12-02 06:24:39 --> Router Class Initialized
INFO - 2024-12-02 06:24:39 --> Output Class Initialized
INFO - 2024-12-02 06:24:39 --> Security Class Initialized
DEBUG - 2024-12-02 06:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:24:39 --> CSRF cookie sent
INFO - 2024-12-02 06:24:39 --> Input Class Initialized
INFO - 2024-12-02 06:24:39 --> Language Class Initialized
INFO - 2024-12-02 06:24:39 --> Loader Class Initialized
INFO - 2024-12-02 06:24:39 --> Helper loaded: url_helper
INFO - 2024-12-02 06:24:39 --> Helper loaded: form_helper
INFO - 2024-12-02 06:24:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:24:39 --> Form Validation Class Initialized
INFO - 2024-12-02 06:24:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:24:39 --> Controller Class Initialized
INFO - 2024-12-02 06:24:39 --> Model "News_model" initialized
INFO - 2024-12-02 06:24:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:24:39 --> Final output sent to browser
DEBUG - 2024-12-02 06:24:39 --> Total execution time: 0.0636
INFO - 2024-12-02 06:25:10 --> Config Class Initialized
INFO - 2024-12-02 06:25:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:10 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:10 --> URI Class Initialized
DEBUG - 2024-12-02 06:25:10 --> No URI present. Default controller set.
INFO - 2024-12-02 06:25:10 --> Router Class Initialized
INFO - 2024-12-02 06:25:10 --> Output Class Initialized
INFO - 2024-12-02 06:25:10 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:10 --> CSRF cookie sent
INFO - 2024-12-02 06:25:10 --> Input Class Initialized
INFO - 2024-12-02 06:25:10 --> Language Class Initialized
INFO - 2024-12-02 06:25:10 --> Loader Class Initialized
INFO - 2024-12-02 06:25:10 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:10 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:10 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:10 --> Controller Class Initialized
INFO - 2024-12-02 06:25:10 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:10 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:10 --> Model "Review_model" initialized
INFO - 2024-12-02 06:25:10 --> Model "News_model" initialized
DEBUG - 2024-12-02 06:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 06:25:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 06:25:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 06:25:10 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:10 --> Total execution time: 0.1279
INFO - 2024-12-02 06:25:12 --> Config Class Initialized
INFO - 2024-12-02 06:25:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:12 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:12 --> URI Class Initialized
INFO - 2024-12-02 06:25:12 --> Router Class Initialized
INFO - 2024-12-02 06:25:12 --> Output Class Initialized
INFO - 2024-12-02 06:25:12 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:12 --> CSRF cookie sent
INFO - 2024-12-02 06:25:12 --> Input Class Initialized
INFO - 2024-12-02 06:25:12 --> Language Class Initialized
INFO - 2024-12-02 06:25:12 --> Loader Class Initialized
INFO - 2024-12-02 06:25:12 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:12 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:12 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:12 --> Controller Class Initialized
INFO - 2024-12-02 06:25:12 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:12 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:12 --> Model "Review_model" initialized
INFO - 2024-12-02 06:25:12 --> Model "News_model" initialized
DEBUG - 2024-12-02 06:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 06:25:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 06:25:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 06:25:12 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:12 --> Total execution time: 0.1488
INFO - 2024-12-02 06:25:14 --> Config Class Initialized
INFO - 2024-12-02 06:25:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:14 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:14 --> URI Class Initialized
INFO - 2024-12-02 06:25:14 --> Router Class Initialized
INFO - 2024-12-02 06:25:14 --> Output Class Initialized
INFO - 2024-12-02 06:25:14 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:14 --> CSRF cookie sent
INFO - 2024-12-02 06:25:14 --> CSRF token verified
INFO - 2024-12-02 06:25:14 --> Input Class Initialized
INFO - 2024-12-02 06:25:14 --> Language Class Initialized
INFO - 2024-12-02 06:25:14 --> Loader Class Initialized
INFO - 2024-12-02 06:25:14 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:14 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:14 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:14 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:14 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:14 --> Controller Class Initialized
INFO - 2024-12-02 06:25:14 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:14 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:14 --> Model "Review_model" initialized
INFO - 2024-12-02 06:25:14 --> Model "News_model" initialized
DEBUG - 2024-12-02 06:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:14 --> Config Class Initialized
INFO - 2024-12-02 06:25:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:14 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:14 --> URI Class Initialized
INFO - 2024-12-02 06:25:14 --> Router Class Initialized
INFO - 2024-12-02 06:25:14 --> Output Class Initialized
INFO - 2024-12-02 06:25:14 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:14 --> CSRF cookie sent
INFO - 2024-12-02 06:25:14 --> Input Class Initialized
INFO - 2024-12-02 06:25:14 --> Language Class Initialized
INFO - 2024-12-02 06:25:14 --> Loader Class Initialized
INFO - 2024-12-02 06:25:14 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:14 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:14 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:14 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:14 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:14 --> Controller Class Initialized
INFO - 2024-12-02 06:25:14 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:14 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:14 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:25:14 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:14 --> Total execution time: 0.1104
INFO - 2024-12-02 06:25:18 --> Config Class Initialized
INFO - 2024-12-02 06:25:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:18 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:18 --> URI Class Initialized
INFO - 2024-12-02 06:25:18 --> Router Class Initialized
INFO - 2024-12-02 06:25:18 --> Output Class Initialized
INFO - 2024-12-02 06:25:18 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:18 --> CSRF cookie sent
INFO - 2024-12-02 06:25:18 --> Input Class Initialized
INFO - 2024-12-02 06:25:18 --> Language Class Initialized
INFO - 2024-12-02 06:25:18 --> Loader Class Initialized
INFO - 2024-12-02 06:25:18 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:18 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:18 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:18 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:18 --> Controller Class Initialized
INFO - 2024-12-02 06:25:18 --> Model "News_model" initialized
INFO - 2024-12-02 06:25:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:25:18 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:18 --> Total execution time: 0.0595
INFO - 2024-12-02 06:25:23 --> Config Class Initialized
INFO - 2024-12-02 06:25:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:23 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:23 --> URI Class Initialized
INFO - 2024-12-02 06:25:23 --> Router Class Initialized
INFO - 2024-12-02 06:25:23 --> Output Class Initialized
INFO - 2024-12-02 06:25:23 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:23 --> CSRF cookie sent
INFO - 2024-12-02 06:25:23 --> Input Class Initialized
INFO - 2024-12-02 06:25:23 --> Language Class Initialized
INFO - 2024-12-02 06:25:23 --> Loader Class Initialized
INFO - 2024-12-02 06:25:23 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:23 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:23 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:23 --> Controller Class Initialized
INFO - 2024-12-02 06:25:23 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:23 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:25:23 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:23 --> Total execution time: 0.0594
INFO - 2024-12-02 06:25:25 --> Config Class Initialized
INFO - 2024-12-02 06:25:25 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:25 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:25 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:25 --> URI Class Initialized
INFO - 2024-12-02 06:25:25 --> Router Class Initialized
INFO - 2024-12-02 06:25:25 --> Output Class Initialized
INFO - 2024-12-02 06:25:25 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:25 --> CSRF cookie sent
INFO - 2024-12-02 06:25:25 --> Input Class Initialized
INFO - 2024-12-02 06:25:25 --> Language Class Initialized
INFO - 2024-12-02 06:25:25 --> Loader Class Initialized
INFO - 2024-12-02 06:25:25 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:25 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:25 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:25 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:25 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:25 --> Controller Class Initialized
INFO - 2024-12-02 06:25:25 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:25 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:25 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 06:25:25 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:25 --> Total execution time: 0.0605
INFO - 2024-12-02 06:25:28 --> Config Class Initialized
INFO - 2024-12-02 06:25:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:28 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:28 --> URI Class Initialized
INFO - 2024-12-02 06:25:28 --> Router Class Initialized
INFO - 2024-12-02 06:25:28 --> Output Class Initialized
INFO - 2024-12-02 06:25:28 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:28 --> CSRF cookie sent
INFO - 2024-12-02 06:25:28 --> Input Class Initialized
INFO - 2024-12-02 06:25:28 --> Language Class Initialized
INFO - 2024-12-02 06:25:28 --> Loader Class Initialized
INFO - 2024-12-02 06:25:28 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:28 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:28 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:28 --> Controller Class Initialized
INFO - 2024-12-02 06:25:28 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:28 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 06:25:28 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:28 --> Total execution time: 0.0477
INFO - 2024-12-02 06:25:31 --> Config Class Initialized
INFO - 2024-12-02 06:25:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:31 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:31 --> URI Class Initialized
INFO - 2024-12-02 06:25:31 --> Router Class Initialized
INFO - 2024-12-02 06:25:31 --> Output Class Initialized
INFO - 2024-12-02 06:25:31 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:31 --> CSRF cookie sent
INFO - 2024-12-02 06:25:31 --> Input Class Initialized
INFO - 2024-12-02 06:25:31 --> Language Class Initialized
INFO - 2024-12-02 06:25:31 --> Loader Class Initialized
INFO - 2024-12-02 06:25:31 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:31 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:31 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:31 --> Controller Class Initialized
INFO - 2024-12-02 06:25:31 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:31 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-02 06:25:31 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:31 --> Total execution time: 0.0409
INFO - 2024-12-02 06:25:35 --> Config Class Initialized
INFO - 2024-12-02 06:25:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:35 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:35 --> URI Class Initialized
INFO - 2024-12-02 06:25:35 --> Router Class Initialized
INFO - 2024-12-02 06:25:35 --> Output Class Initialized
INFO - 2024-12-02 06:25:35 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:35 --> CSRF cookie sent
INFO - 2024-12-02 06:25:35 --> Input Class Initialized
INFO - 2024-12-02 06:25:35 --> Language Class Initialized
INFO - 2024-12-02 06:25:35 --> Loader Class Initialized
INFO - 2024-12-02 06:25:35 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:35 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:35 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:35 --> Controller Class Initialized
INFO - 2024-12-02 06:25:35 --> Model "Category_model" initialized
INFO - 2024-12-02 06:25:35 --> Model "User_model" initialized
INFO - 2024-12-02 06:25:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:25:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:25:35 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:35 --> Total execution time: 0.0622
INFO - 2024-12-02 06:25:36 --> Config Class Initialized
INFO - 2024-12-02 06:25:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:25:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:25:36 --> Utf8 Class Initialized
INFO - 2024-12-02 06:25:36 --> URI Class Initialized
INFO - 2024-12-02 06:25:36 --> Router Class Initialized
INFO - 2024-12-02 06:25:36 --> Output Class Initialized
INFO - 2024-12-02 06:25:36 --> Security Class Initialized
DEBUG - 2024-12-02 06:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:25:36 --> CSRF cookie sent
INFO - 2024-12-02 06:25:36 --> Input Class Initialized
INFO - 2024-12-02 06:25:36 --> Language Class Initialized
INFO - 2024-12-02 06:25:36 --> Loader Class Initialized
INFO - 2024-12-02 06:25:36 --> Helper loaded: url_helper
INFO - 2024-12-02 06:25:36 --> Helper loaded: form_helper
INFO - 2024-12-02 06:25:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:25:36 --> Form Validation Class Initialized
INFO - 2024-12-02 06:25:36 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:25:36 --> Controller Class Initialized
INFO - 2024-12-02 06:25:36 --> Model "News_model" initialized
INFO - 2024-12-02 06:25:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:25:36 --> Final output sent to browser
DEBUG - 2024-12-02 06:25:36 --> Total execution time: 0.0450
INFO - 2024-12-02 06:30:27 --> Config Class Initialized
INFO - 2024-12-02 06:30:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:30:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:30:27 --> Utf8 Class Initialized
INFO - 2024-12-02 06:30:27 --> URI Class Initialized
INFO - 2024-12-02 06:30:27 --> Router Class Initialized
INFO - 2024-12-02 06:30:27 --> Output Class Initialized
INFO - 2024-12-02 06:30:27 --> Security Class Initialized
DEBUG - 2024-12-02 06:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:30:27 --> CSRF cookie sent
INFO - 2024-12-02 06:30:27 --> Input Class Initialized
INFO - 2024-12-02 06:30:27 --> Language Class Initialized
INFO - 2024-12-02 06:30:27 --> Loader Class Initialized
INFO - 2024-12-02 06:30:27 --> Helper loaded: url_helper
INFO - 2024-12-02 06:30:27 --> Helper loaded: form_helper
INFO - 2024-12-02 06:30:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:30:27 --> Form Validation Class Initialized
INFO - 2024-12-02 06:30:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:30:27 --> Controller Class Initialized
INFO - 2024-12-02 06:30:27 --> Model "News_model" initialized
INFO - 2024-12-02 06:30:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:30:28 --> Final output sent to browser
DEBUG - 2024-12-02 06:30:28 --> Total execution time: 0.6725
INFO - 2024-12-02 06:31:47 --> Config Class Initialized
INFO - 2024-12-02 06:31:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:31:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:31:47 --> Utf8 Class Initialized
INFO - 2024-12-02 06:31:47 --> URI Class Initialized
INFO - 2024-12-02 06:31:47 --> Router Class Initialized
INFO - 2024-12-02 06:31:47 --> Output Class Initialized
INFO - 2024-12-02 06:31:47 --> Security Class Initialized
DEBUG - 2024-12-02 06:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:31:47 --> CSRF cookie sent
INFO - 2024-12-02 06:31:47 --> Input Class Initialized
INFO - 2024-12-02 06:31:47 --> Language Class Initialized
INFO - 2024-12-02 06:31:47 --> Loader Class Initialized
INFO - 2024-12-02 06:31:47 --> Helper loaded: url_helper
INFO - 2024-12-02 06:31:47 --> Helper loaded: form_helper
INFO - 2024-12-02 06:31:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:31:47 --> Form Validation Class Initialized
INFO - 2024-12-02 06:31:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:31:47 --> Controller Class Initialized
INFO - 2024-12-02 06:31:47 --> Model "News_model" initialized
INFO - 2024-12-02 06:31:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:31:47 --> Final output sent to browser
DEBUG - 2024-12-02 06:31:47 --> Total execution time: 0.3809
INFO - 2024-12-02 06:33:26 --> Config Class Initialized
INFO - 2024-12-02 06:33:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:33:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:33:26 --> Utf8 Class Initialized
INFO - 2024-12-02 06:33:26 --> URI Class Initialized
INFO - 2024-12-02 06:33:26 --> Router Class Initialized
INFO - 2024-12-02 06:33:26 --> Output Class Initialized
INFO - 2024-12-02 06:33:26 --> Security Class Initialized
DEBUG - 2024-12-02 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:33:26 --> CSRF cookie sent
INFO - 2024-12-02 06:33:26 --> Input Class Initialized
INFO - 2024-12-02 06:33:26 --> Language Class Initialized
INFO - 2024-12-02 06:33:26 --> Loader Class Initialized
INFO - 2024-12-02 06:33:26 --> Helper loaded: url_helper
INFO - 2024-12-02 06:33:26 --> Helper loaded: form_helper
INFO - 2024-12-02 06:33:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:33:27 --> Form Validation Class Initialized
INFO - 2024-12-02 06:33:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:33:27 --> Controller Class Initialized
INFO - 2024-12-02 06:33:27 --> Model "News_model" initialized
INFO - 2024-12-02 06:33:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:33:27 --> Final output sent to browser
DEBUG - 2024-12-02 06:33:27 --> Total execution time: 0.4875
INFO - 2024-12-02 06:33:32 --> Config Class Initialized
INFO - 2024-12-02 06:33:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:33:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:33:32 --> Utf8 Class Initialized
INFO - 2024-12-02 06:33:32 --> URI Class Initialized
INFO - 2024-12-02 06:33:32 --> Router Class Initialized
INFO - 2024-12-02 06:33:32 --> Output Class Initialized
INFO - 2024-12-02 06:33:32 --> Security Class Initialized
DEBUG - 2024-12-02 06:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:33:32 --> CSRF cookie sent
INFO - 2024-12-02 06:33:32 --> Input Class Initialized
INFO - 2024-12-02 06:33:32 --> Language Class Initialized
INFO - 2024-12-02 06:33:32 --> Loader Class Initialized
INFO - 2024-12-02 06:33:32 --> Helper loaded: url_helper
INFO - 2024-12-02 06:33:32 --> Helper loaded: form_helper
INFO - 2024-12-02 06:33:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:33:32 --> Form Validation Class Initialized
INFO - 2024-12-02 06:33:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:33:32 --> Controller Class Initialized
INFO - 2024-12-02 06:33:32 --> Model "Category_model" initialized
INFO - 2024-12-02 06:33:32 --> Model "User_model" initialized
INFO - 2024-12-02 06:33:32 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:33:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:33:32 --> Final output sent to browser
DEBUG - 2024-12-02 06:33:32 --> Total execution time: 0.1271
INFO - 2024-12-02 06:33:40 --> Config Class Initialized
INFO - 2024-12-02 06:33:40 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:33:40 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:33:40 --> Utf8 Class Initialized
INFO - 2024-12-02 06:33:40 --> URI Class Initialized
INFO - 2024-12-02 06:33:40 --> Router Class Initialized
INFO - 2024-12-02 06:33:40 --> Output Class Initialized
INFO - 2024-12-02 06:33:40 --> Security Class Initialized
DEBUG - 2024-12-02 06:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:33:40 --> CSRF cookie sent
INFO - 2024-12-02 06:33:40 --> Input Class Initialized
INFO - 2024-12-02 06:33:40 --> Language Class Initialized
INFO - 2024-12-02 06:33:40 --> Loader Class Initialized
INFO - 2024-12-02 06:33:40 --> Helper loaded: url_helper
INFO - 2024-12-02 06:33:40 --> Helper loaded: form_helper
INFO - 2024-12-02 06:33:40 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:33:40 --> Form Validation Class Initialized
INFO - 2024-12-02 06:33:40 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:33:40 --> Controller Class Initialized
INFO - 2024-12-02 06:33:40 --> Model "News_model" initialized
INFO - 2024-12-02 06:33:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:33:40 --> Final output sent to browser
DEBUG - 2024-12-02 06:33:40 --> Total execution time: 0.0782
INFO - 2024-12-02 06:33:50 --> Config Class Initialized
INFO - 2024-12-02 06:33:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:33:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:33:50 --> Utf8 Class Initialized
INFO - 2024-12-02 06:33:50 --> URI Class Initialized
INFO - 2024-12-02 06:33:50 --> Router Class Initialized
INFO - 2024-12-02 06:33:50 --> Output Class Initialized
INFO - 2024-12-02 06:33:50 --> Security Class Initialized
DEBUG - 2024-12-02 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:33:50 --> CSRF cookie sent
INFO - 2024-12-02 06:33:50 --> Input Class Initialized
INFO - 2024-12-02 06:33:50 --> Language Class Initialized
INFO - 2024-12-02 06:33:50 --> Loader Class Initialized
INFO - 2024-12-02 06:33:50 --> Helper loaded: url_helper
INFO - 2024-12-02 06:33:50 --> Helper loaded: form_helper
INFO - 2024-12-02 06:33:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:33:50 --> Form Validation Class Initialized
INFO - 2024-12-02 06:33:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:33:50 --> Controller Class Initialized
INFO - 2024-12-02 06:33:50 --> Model "News_model" initialized
INFO - 2024-12-02 06:33:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:33:50 --> Final output sent to browser
DEBUG - 2024-12-02 06:33:50 --> Total execution time: 0.0695
INFO - 2024-12-02 06:33:51 --> Config Class Initialized
INFO - 2024-12-02 06:33:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:33:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:33:51 --> Utf8 Class Initialized
INFO - 2024-12-02 06:33:51 --> URI Class Initialized
INFO - 2024-12-02 06:33:51 --> Router Class Initialized
INFO - 2024-12-02 06:33:51 --> Output Class Initialized
INFO - 2024-12-02 06:33:51 --> Security Class Initialized
DEBUG - 2024-12-02 06:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:33:51 --> CSRF cookie sent
INFO - 2024-12-02 06:33:51 --> Input Class Initialized
INFO - 2024-12-02 06:33:51 --> Language Class Initialized
INFO - 2024-12-02 06:33:51 --> Loader Class Initialized
INFO - 2024-12-02 06:33:51 --> Helper loaded: url_helper
INFO - 2024-12-02 06:33:51 --> Helper loaded: form_helper
INFO - 2024-12-02 06:33:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:33:51 --> Form Validation Class Initialized
INFO - 2024-12-02 06:33:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:33:51 --> Controller Class Initialized
INFO - 2024-12-02 06:33:51 --> Model "News_model" initialized
INFO - 2024-12-02 06:33:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:33:51 --> Final output sent to browser
DEBUG - 2024-12-02 06:33:51 --> Total execution time: 0.0844
INFO - 2024-12-02 06:34:33 --> Config Class Initialized
INFO - 2024-12-02 06:34:33 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:33 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:33 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:33 --> URI Class Initialized
INFO - 2024-12-02 06:34:33 --> Router Class Initialized
INFO - 2024-12-02 06:34:33 --> Output Class Initialized
INFO - 2024-12-02 06:34:33 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:33 --> CSRF cookie sent
INFO - 2024-12-02 06:34:33 --> Input Class Initialized
INFO - 2024-12-02 06:34:33 --> Language Class Initialized
INFO - 2024-12-02 06:34:33 --> Loader Class Initialized
INFO - 2024-12-02 06:34:33 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:33 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:33 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:33 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:33 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:33 --> Controller Class Initialized
INFO - 2024-12-02 06:34:33 --> Model "News_model" initialized
INFO - 2024-12-02 06:34:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:34:33 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:33 --> Total execution time: 0.1102
INFO - 2024-12-02 06:34:35 --> Config Class Initialized
INFO - 2024-12-02 06:34:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:35 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:35 --> URI Class Initialized
INFO - 2024-12-02 06:34:35 --> Router Class Initialized
INFO - 2024-12-02 06:34:35 --> Output Class Initialized
INFO - 2024-12-02 06:34:35 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:35 --> CSRF cookie sent
INFO - 2024-12-02 06:34:35 --> Input Class Initialized
INFO - 2024-12-02 06:34:35 --> Language Class Initialized
INFO - 2024-12-02 06:34:35 --> Loader Class Initialized
INFO - 2024-12-02 06:34:35 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:35 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:35 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:35 --> Controller Class Initialized
INFO - 2024-12-02 06:34:35 --> Model "News_model" initialized
INFO - 2024-12-02 06:34:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:34:35 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:35 --> Total execution time: 0.0484
INFO - 2024-12-02 06:34:41 --> Config Class Initialized
INFO - 2024-12-02 06:34:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:41 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:41 --> URI Class Initialized
INFO - 2024-12-02 06:34:41 --> Router Class Initialized
INFO - 2024-12-02 06:34:41 --> Output Class Initialized
INFO - 2024-12-02 06:34:41 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:41 --> CSRF cookie sent
INFO - 2024-12-02 06:34:41 --> Input Class Initialized
INFO - 2024-12-02 06:34:41 --> Language Class Initialized
INFO - 2024-12-02 06:34:41 --> Loader Class Initialized
INFO - 2024-12-02 06:34:41 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:41 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:42 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:42 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:42 --> Controller Class Initialized
INFO - 2024-12-02 06:34:42 --> Model "Category_model" initialized
INFO - 2024-12-02 06:34:42 --> Model "User_model" initialized
INFO - 2024-12-02 06:34:42 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:34:42 --> Model "Contact_model" initialized
INFO - 2024-12-02 06:34:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-02 06:34:42 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:42 --> Total execution time: 0.0825
INFO - 2024-12-02 06:34:47 --> Config Class Initialized
INFO - 2024-12-02 06:34:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:47 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:47 --> URI Class Initialized
INFO - 2024-12-02 06:34:47 --> Router Class Initialized
INFO - 2024-12-02 06:34:47 --> Output Class Initialized
INFO - 2024-12-02 06:34:47 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:47 --> CSRF cookie sent
INFO - 2024-12-02 06:34:47 --> Input Class Initialized
INFO - 2024-12-02 06:34:47 --> Language Class Initialized
INFO - 2024-12-02 06:34:47 --> Loader Class Initialized
INFO - 2024-12-02 06:34:47 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:47 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:47 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:47 --> Controller Class Initialized
INFO - 2024-12-02 06:34:47 --> Model "Category_model" initialized
INFO - 2024-12-02 06:34:47 --> Model "User_model" initialized
INFO - 2024-12-02 06:34:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:34:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:34:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:34:47 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:47 --> Total execution time: 0.0544
INFO - 2024-12-02 06:34:50 --> Config Class Initialized
INFO - 2024-12-02 06:34:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:50 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:50 --> URI Class Initialized
INFO - 2024-12-02 06:34:50 --> Router Class Initialized
INFO - 2024-12-02 06:34:50 --> Output Class Initialized
INFO - 2024-12-02 06:34:50 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:50 --> CSRF cookie sent
INFO - 2024-12-02 06:34:50 --> Input Class Initialized
INFO - 2024-12-02 06:34:50 --> Language Class Initialized
INFO - 2024-12-02 06:34:50 --> Loader Class Initialized
INFO - 2024-12-02 06:34:50 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:50 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:50 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:50 --> Controller Class Initialized
INFO - 2024-12-02 06:34:50 --> Model "News_model" initialized
INFO - 2024-12-02 06:34:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:34:50 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:50 --> Total execution time: 0.0424
INFO - 2024-12-02 06:34:54 --> Config Class Initialized
INFO - 2024-12-02 06:34:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:54 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:54 --> URI Class Initialized
INFO - 2024-12-02 06:34:54 --> Router Class Initialized
INFO - 2024-12-02 06:34:54 --> Output Class Initialized
INFO - 2024-12-02 06:34:54 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:54 --> CSRF cookie sent
INFO - 2024-12-02 06:34:54 --> Input Class Initialized
INFO - 2024-12-02 06:34:54 --> Language Class Initialized
INFO - 2024-12-02 06:34:54 --> Loader Class Initialized
INFO - 2024-12-02 06:34:54 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:54 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:54 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:54 --> Controller Class Initialized
INFO - 2024-12-02 06:34:54 --> Model "Category_model" initialized
INFO - 2024-12-02 06:34:54 --> Model "User_model" initialized
INFO - 2024-12-02 06:34:54 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:34:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 06:34:54 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:54 --> Total execution time: 0.0401
INFO - 2024-12-02 06:34:55 --> Config Class Initialized
INFO - 2024-12-02 06:34:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:55 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:55 --> URI Class Initialized
INFO - 2024-12-02 06:34:55 --> Router Class Initialized
INFO - 2024-12-02 06:34:55 --> Output Class Initialized
INFO - 2024-12-02 06:34:55 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:55 --> CSRF cookie sent
INFO - 2024-12-02 06:34:55 --> Input Class Initialized
INFO - 2024-12-02 06:34:55 --> Language Class Initialized
INFO - 2024-12-02 06:34:55 --> Loader Class Initialized
INFO - 2024-12-02 06:34:55 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:55 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:55 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:55 --> Controller Class Initialized
INFO - 2024-12-02 06:34:55 --> Model "Category_model" initialized
INFO - 2024-12-02 06:34:55 --> Model "User_model" initialized
INFO - 2024-12-02 06:34:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:34:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:34:55 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:55 --> Total execution time: 0.0611
INFO - 2024-12-02 06:34:57 --> Config Class Initialized
INFO - 2024-12-02 06:34:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:34:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:34:57 --> Utf8 Class Initialized
INFO - 2024-12-02 06:34:57 --> URI Class Initialized
INFO - 2024-12-02 06:34:57 --> Router Class Initialized
INFO - 2024-12-02 06:34:57 --> Output Class Initialized
INFO - 2024-12-02 06:34:57 --> Security Class Initialized
DEBUG - 2024-12-02 06:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:34:57 --> CSRF cookie sent
INFO - 2024-12-02 06:34:57 --> Input Class Initialized
INFO - 2024-12-02 06:34:57 --> Language Class Initialized
INFO - 2024-12-02 06:34:57 --> Loader Class Initialized
INFO - 2024-12-02 06:34:57 --> Helper loaded: url_helper
INFO - 2024-12-02 06:34:57 --> Helper loaded: form_helper
INFO - 2024-12-02 06:34:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:34:57 --> Form Validation Class Initialized
INFO - 2024-12-02 06:34:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:34:57 --> Controller Class Initialized
INFO - 2024-12-02 06:34:57 --> Model "News_model" initialized
INFO - 2024-12-02 06:34:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:34:57 --> Final output sent to browser
DEBUG - 2024-12-02 06:34:57 --> Total execution time: 0.0410
INFO - 2024-12-02 06:37:33 --> Config Class Initialized
INFO - 2024-12-02 06:37:33 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:37:33 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:37:33 --> Utf8 Class Initialized
INFO - 2024-12-02 06:37:33 --> URI Class Initialized
INFO - 2024-12-02 06:37:33 --> Router Class Initialized
INFO - 2024-12-02 06:37:33 --> Output Class Initialized
INFO - 2024-12-02 06:37:33 --> Security Class Initialized
DEBUG - 2024-12-02 06:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:37:33 --> CSRF cookie sent
INFO - 2024-12-02 06:37:33 --> Input Class Initialized
INFO - 2024-12-02 06:37:33 --> Language Class Initialized
INFO - 2024-12-02 06:37:33 --> Loader Class Initialized
INFO - 2024-12-02 06:37:33 --> Helper loaded: url_helper
INFO - 2024-12-02 06:37:33 --> Helper loaded: form_helper
INFO - 2024-12-02 06:37:33 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:37:33 --> Form Validation Class Initialized
INFO - 2024-12-02 06:37:33 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:37:33 --> Controller Class Initialized
INFO - 2024-12-02 06:37:33 --> Model "News_model" initialized
INFO - 2024-12-02 06:37:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:37:33 --> Final output sent to browser
DEBUG - 2024-12-02 06:37:33 --> Total execution time: 0.2081
INFO - 2024-12-02 06:37:38 --> Config Class Initialized
INFO - 2024-12-02 06:37:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:37:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:37:38 --> Utf8 Class Initialized
INFO - 2024-12-02 06:37:38 --> URI Class Initialized
INFO - 2024-12-02 06:37:38 --> Router Class Initialized
INFO - 2024-12-02 06:37:38 --> Output Class Initialized
INFO - 2024-12-02 06:37:38 --> Security Class Initialized
DEBUG - 2024-12-02 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:37:38 --> CSRF cookie sent
INFO - 2024-12-02 06:37:38 --> Input Class Initialized
INFO - 2024-12-02 06:37:38 --> Language Class Initialized
INFO - 2024-12-02 06:37:38 --> Loader Class Initialized
INFO - 2024-12-02 06:37:38 --> Helper loaded: url_helper
INFO - 2024-12-02 06:37:38 --> Helper loaded: form_helper
INFO - 2024-12-02 06:37:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:37:38 --> Form Validation Class Initialized
INFO - 2024-12-02 06:37:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:37:38 --> Controller Class Initialized
INFO - 2024-12-02 06:37:38 --> Model "Category_model" initialized
INFO - 2024-12-02 06:37:38 --> Model "User_model" initialized
INFO - 2024-12-02 06:37:38 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:37:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 06:37:38 --> Final output sent to browser
DEBUG - 2024-12-02 06:37:38 --> Total execution time: 0.0584
INFO - 2024-12-02 06:37:41 --> Config Class Initialized
INFO - 2024-12-02 06:37:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:37:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:37:41 --> Utf8 Class Initialized
INFO - 2024-12-02 06:37:41 --> URI Class Initialized
INFO - 2024-12-02 06:37:41 --> Router Class Initialized
INFO - 2024-12-02 06:37:41 --> Output Class Initialized
INFO - 2024-12-02 06:37:41 --> Security Class Initialized
DEBUG - 2024-12-02 06:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:37:41 --> CSRF cookie sent
INFO - 2024-12-02 06:37:41 --> Input Class Initialized
INFO - 2024-12-02 06:37:41 --> Language Class Initialized
INFO - 2024-12-02 06:37:41 --> Loader Class Initialized
INFO - 2024-12-02 06:37:41 --> Helper loaded: url_helper
INFO - 2024-12-02 06:37:41 --> Helper loaded: form_helper
INFO - 2024-12-02 06:37:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:37:41 --> Form Validation Class Initialized
INFO - 2024-12-02 06:37:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:37:41 --> Controller Class Initialized
INFO - 2024-12-02 06:37:41 --> Model "Category_model" initialized
INFO - 2024-12-02 06:37:41 --> Model "User_model" initialized
INFO - 2024-12-02 06:37:41 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:37:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:37:41 --> Final output sent to browser
DEBUG - 2024-12-02 06:37:41 --> Total execution time: 0.0760
INFO - 2024-12-02 06:37:43 --> Config Class Initialized
INFO - 2024-12-02 06:37:43 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:37:43 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:37:43 --> Utf8 Class Initialized
INFO - 2024-12-02 06:37:43 --> URI Class Initialized
INFO - 2024-12-02 06:37:43 --> Router Class Initialized
INFO - 2024-12-02 06:37:43 --> Output Class Initialized
INFO - 2024-12-02 06:37:43 --> Security Class Initialized
DEBUG - 2024-12-02 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:37:43 --> CSRF cookie sent
INFO - 2024-12-02 06:37:43 --> Input Class Initialized
INFO - 2024-12-02 06:37:43 --> Language Class Initialized
INFO - 2024-12-02 06:37:43 --> Loader Class Initialized
INFO - 2024-12-02 06:37:43 --> Helper loaded: url_helper
INFO - 2024-12-02 06:37:43 --> Helper loaded: form_helper
INFO - 2024-12-02 06:37:43 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:37:43 --> Form Validation Class Initialized
INFO - 2024-12-02 06:37:43 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:37:43 --> Controller Class Initialized
INFO - 2024-12-02 06:37:43 --> Model "News_model" initialized
INFO - 2024-12-02 06:37:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:37:43 --> Final output sent to browser
DEBUG - 2024-12-02 06:37:43 --> Total execution time: 0.0532
INFO - 2024-12-02 06:37:51 --> Config Class Initialized
INFO - 2024-12-02 06:37:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:37:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:37:51 --> Utf8 Class Initialized
INFO - 2024-12-02 06:37:51 --> URI Class Initialized
INFO - 2024-12-02 06:37:51 --> Router Class Initialized
INFO - 2024-12-02 06:37:51 --> Output Class Initialized
INFO - 2024-12-02 06:37:51 --> Security Class Initialized
DEBUG - 2024-12-02 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:37:51 --> CSRF cookie sent
INFO - 2024-12-02 06:37:51 --> Input Class Initialized
INFO - 2024-12-02 06:37:51 --> Language Class Initialized
INFO - 2024-12-02 06:37:51 --> Loader Class Initialized
INFO - 2024-12-02 06:37:51 --> Helper loaded: url_helper
INFO - 2024-12-02 06:37:51 --> Helper loaded: form_helper
INFO - 2024-12-02 06:37:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:37:51 --> Form Validation Class Initialized
INFO - 2024-12-02 06:37:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:37:51 --> Controller Class Initialized
INFO - 2024-12-02 06:37:51 --> Model "Category_model" initialized
INFO - 2024-12-02 06:37:51 --> Model "User_model" initialized
INFO - 2024-12-02 06:37:51 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:37:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:37:51 --> Final output sent to browser
DEBUG - 2024-12-02 06:37:51 --> Total execution time: 0.0722
INFO - 2024-12-02 06:38:00 --> Config Class Initialized
INFO - 2024-12-02 06:38:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:00 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:00 --> URI Class Initialized
INFO - 2024-12-02 06:38:00 --> Router Class Initialized
INFO - 2024-12-02 06:38:00 --> Output Class Initialized
INFO - 2024-12-02 06:38:00 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:00 --> CSRF cookie sent
INFO - 2024-12-02 06:38:00 --> Input Class Initialized
INFO - 2024-12-02 06:38:00 --> Language Class Initialized
INFO - 2024-12-02 06:38:00 --> Loader Class Initialized
INFO - 2024-12-02 06:38:00 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:00 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:00 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:00 --> Controller Class Initialized
INFO - 2024-12-02 06:38:00 --> Model "Category_model" initialized
INFO - 2024-12-02 06:38:00 --> Model "User_model" initialized
INFO - 2024-12-02 06:38:00 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:38:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 06:38:00 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:00 --> Total execution time: 0.0464
INFO - 2024-12-02 06:38:30 --> Config Class Initialized
INFO - 2024-12-02 06:38:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:30 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:30 --> URI Class Initialized
INFO - 2024-12-02 06:38:30 --> Router Class Initialized
INFO - 2024-12-02 06:38:30 --> Output Class Initialized
INFO - 2024-12-02 06:38:30 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:30 --> CSRF cookie sent
INFO - 2024-12-02 06:38:30 --> Input Class Initialized
INFO - 2024-12-02 06:38:30 --> Language Class Initialized
INFO - 2024-12-02 06:38:30 --> Loader Class Initialized
INFO - 2024-12-02 06:38:30 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:30 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:30 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:30 --> Controller Class Initialized
INFO - 2024-12-02 06:38:30 --> Model "Category_model" initialized
INFO - 2024-12-02 06:38:30 --> Model "User_model" initialized
INFO - 2024-12-02 06:38:30 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:38:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:38:30 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:30 --> Total execution time: 0.0609
INFO - 2024-12-02 06:38:32 --> Config Class Initialized
INFO - 2024-12-02 06:38:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:32 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:32 --> URI Class Initialized
INFO - 2024-12-02 06:38:32 --> Router Class Initialized
INFO - 2024-12-02 06:38:32 --> Output Class Initialized
INFO - 2024-12-02 06:38:32 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:32 --> CSRF cookie sent
INFO - 2024-12-02 06:38:32 --> Input Class Initialized
INFO - 2024-12-02 06:38:32 --> Language Class Initialized
INFO - 2024-12-02 06:38:32 --> Loader Class Initialized
INFO - 2024-12-02 06:38:32 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:32 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:32 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:32 --> Controller Class Initialized
INFO - 2024-12-02 06:38:32 --> Model "News_model" initialized
INFO - 2024-12-02 06:38:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:38:32 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:32 --> Total execution time: 0.0647
INFO - 2024-12-02 06:38:35 --> Config Class Initialized
INFO - 2024-12-02 06:38:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:35 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:35 --> URI Class Initialized
INFO - 2024-12-02 06:38:35 --> Router Class Initialized
INFO - 2024-12-02 06:38:35 --> Output Class Initialized
INFO - 2024-12-02 06:38:35 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:35 --> CSRF cookie sent
INFO - 2024-12-02 06:38:35 --> Input Class Initialized
INFO - 2024-12-02 06:38:35 --> Language Class Initialized
INFO - 2024-12-02 06:38:35 --> Loader Class Initialized
INFO - 2024-12-02 06:38:35 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:35 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:35 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:35 --> Controller Class Initialized
INFO - 2024-12-02 06:38:35 --> Model "Category_model" initialized
INFO - 2024-12-02 06:38:35 --> Model "User_model" initialized
INFO - 2024-12-02 06:38:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:38:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:38:35 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:35 --> Total execution time: 0.0497
INFO - 2024-12-02 06:38:39 --> Config Class Initialized
INFO - 2024-12-02 06:38:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:39 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:39 --> URI Class Initialized
INFO - 2024-12-02 06:38:39 --> Router Class Initialized
INFO - 2024-12-02 06:38:39 --> Output Class Initialized
INFO - 2024-12-02 06:38:39 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:39 --> CSRF cookie sent
INFO - 2024-12-02 06:38:39 --> Input Class Initialized
INFO - 2024-12-02 06:38:39 --> Language Class Initialized
INFO - 2024-12-02 06:38:39 --> Loader Class Initialized
INFO - 2024-12-02 06:38:39 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:39 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:39 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:39 --> Controller Class Initialized
INFO - 2024-12-02 06:38:39 --> Model "News_model" initialized
INFO - 2024-12-02 06:38:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:38:39 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:39 --> Total execution time: 0.0553
INFO - 2024-12-02 06:38:43 --> Config Class Initialized
INFO - 2024-12-02 06:38:43 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:43 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:43 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:43 --> URI Class Initialized
INFO - 2024-12-02 06:38:43 --> Router Class Initialized
INFO - 2024-12-02 06:38:43 --> Output Class Initialized
INFO - 2024-12-02 06:38:43 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:43 --> CSRF cookie sent
INFO - 2024-12-02 06:38:43 --> Input Class Initialized
INFO - 2024-12-02 06:38:43 --> Language Class Initialized
INFO - 2024-12-02 06:38:43 --> Loader Class Initialized
INFO - 2024-12-02 06:38:43 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:43 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:43 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:43 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:43 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:43 --> Controller Class Initialized
INFO - 2024-12-02 06:38:43 --> Model "Category_model" initialized
INFO - 2024-12-02 06:38:43 --> Model "User_model" initialized
INFO - 2024-12-02 06:38:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:38:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:38:43 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:43 --> Total execution time: 0.0591
INFO - 2024-12-02 06:38:53 --> Config Class Initialized
INFO - 2024-12-02 06:38:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:53 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:53 --> URI Class Initialized
INFO - 2024-12-02 06:38:53 --> Router Class Initialized
INFO - 2024-12-02 06:38:53 --> Output Class Initialized
INFO - 2024-12-02 06:38:53 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:53 --> CSRF cookie sent
INFO - 2024-12-02 06:38:53 --> Input Class Initialized
INFO - 2024-12-02 06:38:53 --> Language Class Initialized
INFO - 2024-12-02 06:38:53 --> Loader Class Initialized
INFO - 2024-12-02 06:38:53 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:53 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:53 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:53 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:53 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:53 --> Controller Class Initialized
INFO - 2024-12-02 06:38:53 --> Model "News_model" initialized
INFO - 2024-12-02 06:38:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:38:53 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:53 --> Total execution time: 0.0595
INFO - 2024-12-02 06:38:56 --> Config Class Initialized
INFO - 2024-12-02 06:38:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:38:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:38:56 --> Utf8 Class Initialized
INFO - 2024-12-02 06:38:56 --> URI Class Initialized
INFO - 2024-12-02 06:38:56 --> Router Class Initialized
INFO - 2024-12-02 06:38:56 --> Output Class Initialized
INFO - 2024-12-02 06:38:56 --> Security Class Initialized
DEBUG - 2024-12-02 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:38:56 --> CSRF cookie sent
INFO - 2024-12-02 06:38:56 --> Input Class Initialized
INFO - 2024-12-02 06:38:56 --> Language Class Initialized
INFO - 2024-12-02 06:38:56 --> Loader Class Initialized
INFO - 2024-12-02 06:38:56 --> Helper loaded: url_helper
INFO - 2024-12-02 06:38:57 --> Helper loaded: form_helper
INFO - 2024-12-02 06:38:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:38:57 --> Form Validation Class Initialized
INFO - 2024-12-02 06:38:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:38:57 --> Controller Class Initialized
INFO - 2024-12-02 06:38:57 --> Model "News_model" initialized
INFO - 2024-12-02 06:38:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:38:57 --> Final output sent to browser
DEBUG - 2024-12-02 06:38:57 --> Total execution time: 0.1140
INFO - 2024-12-02 06:41:58 --> Config Class Initialized
INFO - 2024-12-02 06:41:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:41:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:41:58 --> Utf8 Class Initialized
INFO - 2024-12-02 06:41:58 --> URI Class Initialized
INFO - 2024-12-02 06:41:58 --> Router Class Initialized
INFO - 2024-12-02 06:41:58 --> Output Class Initialized
INFO - 2024-12-02 06:41:58 --> Security Class Initialized
DEBUG - 2024-12-02 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:41:58 --> CSRF cookie sent
INFO - 2024-12-02 06:41:58 --> Input Class Initialized
INFO - 2024-12-02 06:41:58 --> Language Class Initialized
INFO - 2024-12-02 06:41:58 --> Loader Class Initialized
INFO - 2024-12-02 06:41:58 --> Helper loaded: url_helper
INFO - 2024-12-02 06:41:58 --> Helper loaded: form_helper
INFO - 2024-12-02 06:41:58 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:41:58 --> Form Validation Class Initialized
INFO - 2024-12-02 06:41:58 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:41:58 --> Controller Class Initialized
INFO - 2024-12-02 06:41:58 --> Model "News_model" initialized
INFO - 2024-12-02 06:41:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:41:58 --> Final output sent to browser
DEBUG - 2024-12-02 06:41:58 --> Total execution time: 0.6258
INFO - 2024-12-02 06:43:27 --> Config Class Initialized
INFO - 2024-12-02 06:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:43:27 --> Utf8 Class Initialized
INFO - 2024-12-02 06:43:27 --> URI Class Initialized
INFO - 2024-12-02 06:43:27 --> Router Class Initialized
INFO - 2024-12-02 06:43:27 --> Output Class Initialized
INFO - 2024-12-02 06:43:27 --> Security Class Initialized
DEBUG - 2024-12-02 06:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:43:27 --> CSRF cookie sent
INFO - 2024-12-02 06:43:27 --> Input Class Initialized
INFO - 2024-12-02 06:43:27 --> Language Class Initialized
INFO - 2024-12-02 06:43:27 --> Loader Class Initialized
INFO - 2024-12-02 06:43:27 --> Helper loaded: url_helper
INFO - 2024-12-02 06:43:27 --> Helper loaded: form_helper
INFO - 2024-12-02 06:43:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:43:28 --> Form Validation Class Initialized
INFO - 2024-12-02 06:43:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:43:28 --> Controller Class Initialized
INFO - 2024-12-02 06:43:28 --> Model "News_model" initialized
INFO - 2024-12-02 06:43:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:43:28 --> Final output sent to browser
DEBUG - 2024-12-02 06:43:28 --> Total execution time: 0.8638
INFO - 2024-12-02 06:45:11 --> Config Class Initialized
INFO - 2024-12-02 06:45:11 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:45:11 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:45:11 --> Utf8 Class Initialized
INFO - 2024-12-02 06:45:11 --> URI Class Initialized
INFO - 2024-12-02 06:45:11 --> Router Class Initialized
INFO - 2024-12-02 06:45:11 --> Output Class Initialized
INFO - 2024-12-02 06:45:11 --> Security Class Initialized
DEBUG - 2024-12-02 06:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:45:11 --> CSRF cookie sent
INFO - 2024-12-02 06:45:11 --> Input Class Initialized
INFO - 2024-12-02 06:45:11 --> Language Class Initialized
INFO - 2024-12-02 06:45:11 --> Loader Class Initialized
INFO - 2024-12-02 06:45:11 --> Helper loaded: url_helper
INFO - 2024-12-02 06:45:11 --> Helper loaded: form_helper
INFO - 2024-12-02 06:45:11 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:45:12 --> Form Validation Class Initialized
INFO - 2024-12-02 06:45:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:45:12 --> Controller Class Initialized
INFO - 2024-12-02 06:45:12 --> Model "News_model" initialized
INFO - 2024-12-02 06:45:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:45:12 --> Final output sent to browser
DEBUG - 2024-12-02 06:45:12 --> Total execution time: 0.3820
INFO - 2024-12-02 06:45:52 --> Config Class Initialized
INFO - 2024-12-02 06:45:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:45:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:45:52 --> Utf8 Class Initialized
INFO - 2024-12-02 06:45:52 --> URI Class Initialized
INFO - 2024-12-02 06:45:52 --> Router Class Initialized
INFO - 2024-12-02 06:45:52 --> Output Class Initialized
INFO - 2024-12-02 06:45:52 --> Security Class Initialized
DEBUG - 2024-12-02 06:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:45:52 --> CSRF cookie sent
INFO - 2024-12-02 06:45:52 --> Input Class Initialized
INFO - 2024-12-02 06:45:52 --> Language Class Initialized
INFO - 2024-12-02 06:45:52 --> Loader Class Initialized
INFO - 2024-12-02 06:45:52 --> Helper loaded: url_helper
INFO - 2024-12-02 06:45:52 --> Helper loaded: form_helper
INFO - 2024-12-02 06:45:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:45:52 --> Form Validation Class Initialized
INFO - 2024-12-02 06:45:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:45:52 --> Controller Class Initialized
INFO - 2024-12-02 06:45:52 --> Model "News_model" initialized
INFO - 2024-12-02 06:45:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:45:52 --> Final output sent to browser
DEBUG - 2024-12-02 06:45:52 --> Total execution time: 0.1052
INFO - 2024-12-02 06:47:22 --> Config Class Initialized
INFO - 2024-12-02 06:47:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:22 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:22 --> URI Class Initialized
INFO - 2024-12-02 06:47:22 --> Router Class Initialized
INFO - 2024-12-02 06:47:22 --> Output Class Initialized
INFO - 2024-12-02 06:47:22 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:22 --> CSRF cookie sent
INFO - 2024-12-02 06:47:22 --> Input Class Initialized
INFO - 2024-12-02 06:47:22 --> Language Class Initialized
INFO - 2024-12-02 06:47:22 --> Loader Class Initialized
INFO - 2024-12-02 06:47:22 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:22 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:22 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:22 --> Controller Class Initialized
INFO - 2024-12-02 06:47:22 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:47:22 --> Final output sent to browser
DEBUG - 2024-12-02 06:47:22 --> Total execution time: 0.0750
INFO - 2024-12-02 06:47:26 --> Config Class Initialized
INFO - 2024-12-02 06:47:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:26 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:26 --> URI Class Initialized
INFO - 2024-12-02 06:47:26 --> Router Class Initialized
INFO - 2024-12-02 06:47:26 --> Output Class Initialized
INFO - 2024-12-02 06:47:26 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:26 --> CSRF cookie sent
INFO - 2024-12-02 06:47:26 --> Input Class Initialized
INFO - 2024-12-02 06:47:26 --> Language Class Initialized
INFO - 2024-12-02 06:47:26 --> Loader Class Initialized
INFO - 2024-12-02 06:47:26 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:26 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:27 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:27 --> Controller Class Initialized
INFO - 2024-12-02 06:47:27 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:47:27 --> Final output sent to browser
DEBUG - 2024-12-02 06:47:27 --> Total execution time: 0.0935
INFO - 2024-12-02 06:47:30 --> Config Class Initialized
INFO - 2024-12-02 06:47:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:30 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:30 --> URI Class Initialized
INFO - 2024-12-02 06:47:30 --> Router Class Initialized
INFO - 2024-12-02 06:47:30 --> Output Class Initialized
INFO - 2024-12-02 06:47:30 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:30 --> CSRF cookie sent
INFO - 2024-12-02 06:47:30 --> Input Class Initialized
INFO - 2024-12-02 06:47:30 --> Language Class Initialized
INFO - 2024-12-02 06:47:30 --> Loader Class Initialized
INFO - 2024-12-02 06:47:30 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:30 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:30 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:30 --> Controller Class Initialized
INFO - 2024-12-02 06:47:30 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 06:47:30 --> Final output sent to browser
DEBUG - 2024-12-02 06:47:30 --> Total execution time: 0.0488
INFO - 2024-12-02 06:47:32 --> Config Class Initialized
INFO - 2024-12-02 06:47:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:32 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:32 --> URI Class Initialized
INFO - 2024-12-02 06:47:32 --> Router Class Initialized
INFO - 2024-12-02 06:47:32 --> Output Class Initialized
INFO - 2024-12-02 06:47:32 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:32 --> CSRF cookie sent
INFO - 2024-12-02 06:47:32 --> CSRF token verified
INFO - 2024-12-02 06:47:32 --> Input Class Initialized
INFO - 2024-12-02 06:47:32 --> Language Class Initialized
INFO - 2024-12-02 06:47:32 --> Loader Class Initialized
INFO - 2024-12-02 06:47:32 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:32 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:32 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:32 --> Controller Class Initialized
INFO - 2024-12-02 06:47:32 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:32 --> Config Class Initialized
INFO - 2024-12-02 06:47:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:32 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:32 --> URI Class Initialized
INFO - 2024-12-02 06:47:32 --> Router Class Initialized
INFO - 2024-12-02 06:47:32 --> Output Class Initialized
INFO - 2024-12-02 06:47:32 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:32 --> CSRF cookie sent
INFO - 2024-12-02 06:47:32 --> Input Class Initialized
INFO - 2024-12-02 06:47:32 --> Language Class Initialized
INFO - 2024-12-02 06:47:32 --> Loader Class Initialized
INFO - 2024-12-02 06:47:32 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:32 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:32 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:32 --> Controller Class Initialized
INFO - 2024-12-02 06:47:32 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:47:32 --> Final output sent to browser
DEBUG - 2024-12-02 06:47:32 --> Total execution time: 0.0541
INFO - 2024-12-02 06:47:34 --> Config Class Initialized
INFO - 2024-12-02 06:47:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:34 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:34 --> URI Class Initialized
INFO - 2024-12-02 06:47:34 --> Router Class Initialized
INFO - 2024-12-02 06:47:34 --> Output Class Initialized
INFO - 2024-12-02 06:47:34 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:34 --> CSRF cookie sent
INFO - 2024-12-02 06:47:34 --> Input Class Initialized
INFO - 2024-12-02 06:47:34 --> Language Class Initialized
INFO - 2024-12-02 06:47:34 --> Loader Class Initialized
INFO - 2024-12-02 06:47:34 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:34 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:34 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:34 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:34 --> Controller Class Initialized
INFO - 2024-12-02 06:47:34 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 06:47:34 --> Final output sent to browser
DEBUG - 2024-12-02 06:47:34 --> Total execution time: 0.0451
INFO - 2024-12-02 06:47:36 --> Config Class Initialized
INFO - 2024-12-02 06:47:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:47:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:47:36 --> Utf8 Class Initialized
INFO - 2024-12-02 06:47:36 --> URI Class Initialized
INFO - 2024-12-02 06:47:36 --> Router Class Initialized
INFO - 2024-12-02 06:47:36 --> Output Class Initialized
INFO - 2024-12-02 06:47:36 --> Security Class Initialized
DEBUG - 2024-12-02 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:47:36 --> CSRF cookie sent
INFO - 2024-12-02 06:47:36 --> Input Class Initialized
INFO - 2024-12-02 06:47:36 --> Language Class Initialized
INFO - 2024-12-02 06:47:36 --> Loader Class Initialized
INFO - 2024-12-02 06:47:36 --> Helper loaded: url_helper
INFO - 2024-12-02 06:47:36 --> Helper loaded: form_helper
INFO - 2024-12-02 06:47:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:47:36 --> Form Validation Class Initialized
INFO - 2024-12-02 06:47:36 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:47:36 --> Controller Class Initialized
INFO - 2024-12-02 06:47:36 --> Model "News_model" initialized
INFO - 2024-12-02 06:47:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:47:36 --> Final output sent to browser
DEBUG - 2024-12-02 06:47:36 --> Total execution time: 0.0558
INFO - 2024-12-02 06:49:30 --> Config Class Initialized
INFO - 2024-12-02 06:49:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:49:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:49:30 --> Utf8 Class Initialized
INFO - 2024-12-02 06:49:30 --> URI Class Initialized
INFO - 2024-12-02 06:49:31 --> Router Class Initialized
INFO - 2024-12-02 06:49:31 --> Output Class Initialized
INFO - 2024-12-02 06:49:31 --> Security Class Initialized
DEBUG - 2024-12-02 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:49:31 --> CSRF cookie sent
INFO - 2024-12-02 06:49:31 --> Input Class Initialized
INFO - 2024-12-02 06:49:31 --> Language Class Initialized
INFO - 2024-12-02 06:49:31 --> Loader Class Initialized
INFO - 2024-12-02 06:49:31 --> Helper loaded: url_helper
INFO - 2024-12-02 06:49:31 --> Helper loaded: form_helper
INFO - 2024-12-02 06:49:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:49:31 --> Form Validation Class Initialized
INFO - 2024-12-02 06:49:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:49:31 --> Controller Class Initialized
INFO - 2024-12-02 06:49:31 --> Model "Category_model" initialized
INFO - 2024-12-02 06:49:31 --> Model "User_model" initialized
INFO - 2024-12-02 06:49:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:49:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 06:49:31 --> Final output sent to browser
DEBUG - 2024-12-02 06:49:31 --> Total execution time: 0.1293
INFO - 2024-12-02 06:49:34 --> Config Class Initialized
INFO - 2024-12-02 06:49:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:49:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:49:34 --> Utf8 Class Initialized
INFO - 2024-12-02 06:49:34 --> URI Class Initialized
INFO - 2024-12-02 06:49:34 --> Router Class Initialized
INFO - 2024-12-02 06:49:34 --> Output Class Initialized
INFO - 2024-12-02 06:49:34 --> Security Class Initialized
DEBUG - 2024-12-02 06:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:49:34 --> CSRF cookie sent
INFO - 2024-12-02 06:49:34 --> Input Class Initialized
INFO - 2024-12-02 06:49:34 --> Language Class Initialized
INFO - 2024-12-02 06:49:34 --> Loader Class Initialized
INFO - 2024-12-02 06:49:34 --> Helper loaded: url_helper
INFO - 2024-12-02 06:49:34 --> Helper loaded: form_helper
INFO - 2024-12-02 06:49:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:49:34 --> Form Validation Class Initialized
INFO - 2024-12-02 06:49:34 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:49:34 --> Controller Class Initialized
INFO - 2024-12-02 06:49:34 --> Model "Category_model" initialized
INFO - 2024-12-02 06:49:34 --> Model "User_model" initialized
INFO - 2024-12-02 06:49:34 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:49:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-02 06:49:34 --> Final output sent to browser
DEBUG - 2024-12-02 06:49:34 --> Total execution time: 0.0761
INFO - 2024-12-02 06:49:36 --> Config Class Initialized
INFO - 2024-12-02 06:49:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:49:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:49:36 --> Utf8 Class Initialized
INFO - 2024-12-02 06:49:36 --> URI Class Initialized
INFO - 2024-12-02 06:49:36 --> Router Class Initialized
INFO - 2024-12-02 06:49:36 --> Output Class Initialized
INFO - 2024-12-02 06:49:36 --> Security Class Initialized
DEBUG - 2024-12-02 06:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:49:36 --> CSRF cookie sent
INFO - 2024-12-02 06:49:36 --> Input Class Initialized
INFO - 2024-12-02 06:49:36 --> Language Class Initialized
INFO - 2024-12-02 06:49:36 --> Loader Class Initialized
INFO - 2024-12-02 06:49:36 --> Helper loaded: url_helper
INFO - 2024-12-02 06:49:36 --> Helper loaded: form_helper
INFO - 2024-12-02 06:49:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:49:37 --> Form Validation Class Initialized
INFO - 2024-12-02 06:49:37 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:49:37 --> Controller Class Initialized
INFO - 2024-12-02 06:49:37 --> Model "Category_model" initialized
INFO - 2024-12-02 06:49:37 --> Model "User_model" initialized
INFO - 2024-12-02 06:49:37 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 06:49:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 06:49:37 --> Final output sent to browser
DEBUG - 2024-12-02 06:49:37 --> Total execution time: 0.0678
INFO - 2024-12-02 06:49:38 --> Config Class Initialized
INFO - 2024-12-02 06:49:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 06:49:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 06:49:38 --> Utf8 Class Initialized
INFO - 2024-12-02 06:49:38 --> URI Class Initialized
INFO - 2024-12-02 06:49:38 --> Router Class Initialized
INFO - 2024-12-02 06:49:38 --> Output Class Initialized
INFO - 2024-12-02 06:49:38 --> Security Class Initialized
DEBUG - 2024-12-02 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 06:49:38 --> CSRF cookie sent
INFO - 2024-12-02 06:49:38 --> Input Class Initialized
INFO - 2024-12-02 06:49:38 --> Language Class Initialized
INFO - 2024-12-02 06:49:38 --> Loader Class Initialized
INFO - 2024-12-02 06:49:38 --> Helper loaded: url_helper
INFO - 2024-12-02 06:49:38 --> Helper loaded: form_helper
INFO - 2024-12-02 06:49:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 06:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 06:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 06:49:39 --> Form Validation Class Initialized
INFO - 2024-12-02 06:49:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 06:49:39 --> Controller Class Initialized
INFO - 2024-12-02 06:49:39 --> Model "News_model" initialized
INFO - 2024-12-02 06:49:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 06:49:39 --> Final output sent to browser
DEBUG - 2024-12-02 06:49:39 --> Total execution time: 0.0495
INFO - 2024-12-02 09:06:32 --> Config Class Initialized
INFO - 2024-12-02 09:06:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:06:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:06:32 --> Utf8 Class Initialized
INFO - 2024-12-02 09:06:32 --> URI Class Initialized
INFO - 2024-12-02 09:06:32 --> Router Class Initialized
INFO - 2024-12-02 09:06:32 --> Output Class Initialized
INFO - 2024-12-02 09:06:32 --> Security Class Initialized
DEBUG - 2024-12-02 09:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:06:32 --> CSRF cookie sent
INFO - 2024-12-02 09:06:32 --> Input Class Initialized
INFO - 2024-12-02 09:06:32 --> Language Class Initialized
INFO - 2024-12-02 09:06:32 --> Loader Class Initialized
INFO - 2024-12-02 09:06:32 --> Helper loaded: url_helper
INFO - 2024-12-02 09:06:32 --> Helper loaded: form_helper
INFO - 2024-12-02 09:06:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:06:32 --> Form Validation Class Initialized
INFO - 2024-12-02 09:06:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:06:32 --> Controller Class Initialized
INFO - 2024-12-02 09:06:32 --> Model "News_model" initialized
INFO - 2024-12-02 09:06:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 09:06:32 --> Final output sent to browser
DEBUG - 2024-12-02 09:06:32 --> Total execution time: 0.3799
INFO - 2024-12-02 09:06:45 --> Config Class Initialized
INFO - 2024-12-02 09:06:45 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:06:45 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:06:45 --> Utf8 Class Initialized
INFO - 2024-12-02 09:06:45 --> URI Class Initialized
INFO - 2024-12-02 09:06:45 --> Router Class Initialized
INFO - 2024-12-02 09:06:45 --> Output Class Initialized
INFO - 2024-12-02 09:06:45 --> Security Class Initialized
DEBUG - 2024-12-02 09:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:06:45 --> CSRF cookie sent
INFO - 2024-12-02 09:06:45 --> Input Class Initialized
INFO - 2024-12-02 09:06:45 --> Language Class Initialized
INFO - 2024-12-02 09:06:45 --> Loader Class Initialized
INFO - 2024-12-02 09:06:45 --> Helper loaded: url_helper
INFO - 2024-12-02 09:06:45 --> Helper loaded: form_helper
INFO - 2024-12-02 09:06:45 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:06:45 --> Form Validation Class Initialized
INFO - 2024-12-02 09:06:45 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:06:45 --> Controller Class Initialized
INFO - 2024-12-02 09:06:45 --> Model "News_model" initialized
INFO - 2024-12-02 09:06:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 09:06:45 --> Final output sent to browser
DEBUG - 2024-12-02 09:06:45 --> Total execution time: 0.3220
INFO - 2024-12-02 09:06:56 --> Config Class Initialized
INFO - 2024-12-02 09:06:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:06:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:06:56 --> Utf8 Class Initialized
INFO - 2024-12-02 09:06:56 --> URI Class Initialized
INFO - 2024-12-02 09:06:56 --> Router Class Initialized
INFO - 2024-12-02 09:06:56 --> Output Class Initialized
INFO - 2024-12-02 09:06:56 --> Security Class Initialized
DEBUG - 2024-12-02 09:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:06:56 --> CSRF cookie sent
INFO - 2024-12-02 09:06:56 --> Input Class Initialized
INFO - 2024-12-02 09:06:56 --> Language Class Initialized
INFO - 2024-12-02 09:06:56 --> Loader Class Initialized
INFO - 2024-12-02 09:06:56 --> Helper loaded: url_helper
INFO - 2024-12-02 09:06:56 --> Helper loaded: form_helper
INFO - 2024-12-02 09:06:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:06:56 --> Form Validation Class Initialized
INFO - 2024-12-02 09:06:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:06:56 --> Controller Class Initialized
INFO - 2024-12-02 09:06:56 --> Model "News_model" initialized
INFO - 2024-12-02 09:06:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 09:06:56 --> Final output sent to browser
DEBUG - 2024-12-02 09:06:56 --> Total execution time: 0.1021
INFO - 2024-12-02 09:06:58 --> Config Class Initialized
INFO - 2024-12-02 09:06:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:06:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:06:58 --> Utf8 Class Initialized
INFO - 2024-12-02 09:06:58 --> URI Class Initialized
INFO - 2024-12-02 09:06:58 --> Router Class Initialized
INFO - 2024-12-02 09:06:58 --> Output Class Initialized
INFO - 2024-12-02 09:06:58 --> Security Class Initialized
DEBUG - 2024-12-02 09:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:06:58 --> CSRF cookie sent
INFO - 2024-12-02 09:06:58 --> CSRF token verified
INFO - 2024-12-02 09:06:58 --> Input Class Initialized
INFO - 2024-12-02 09:06:58 --> Language Class Initialized
INFO - 2024-12-02 09:06:58 --> Loader Class Initialized
INFO - 2024-12-02 09:06:58 --> Helper loaded: url_helper
INFO - 2024-12-02 09:06:58 --> Helper loaded: form_helper
INFO - 2024-12-02 09:06:58 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:06:58 --> Form Validation Class Initialized
INFO - 2024-12-02 09:06:58 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:06:58 --> Controller Class Initialized
INFO - 2024-12-02 09:06:58 --> Model "News_model" initialized
INFO - 2024-12-02 09:06:58 --> Config Class Initialized
INFO - 2024-12-02 09:06:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:06:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:06:58 --> Utf8 Class Initialized
INFO - 2024-12-02 09:06:58 --> URI Class Initialized
INFO - 2024-12-02 09:06:58 --> Router Class Initialized
INFO - 2024-12-02 09:06:58 --> Output Class Initialized
INFO - 2024-12-02 09:06:58 --> Security Class Initialized
DEBUG - 2024-12-02 09:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:06:58 --> CSRF cookie sent
INFO - 2024-12-02 09:06:58 --> Input Class Initialized
INFO - 2024-12-02 09:06:58 --> Language Class Initialized
INFO - 2024-12-02 09:06:58 --> Loader Class Initialized
INFO - 2024-12-02 09:06:58 --> Helper loaded: url_helper
INFO - 2024-12-02 09:06:58 --> Helper loaded: form_helper
INFO - 2024-12-02 09:06:58 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:06:58 --> Form Validation Class Initialized
INFO - 2024-12-02 09:06:58 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:06:58 --> Controller Class Initialized
INFO - 2024-12-02 09:06:58 --> Model "News_model" initialized
INFO - 2024-12-02 09:06:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 09:06:58 --> Final output sent to browser
DEBUG - 2024-12-02 09:06:58 --> Total execution time: 0.0392
INFO - 2024-12-02 09:07:10 --> Config Class Initialized
INFO - 2024-12-02 09:07:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:07:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:07:10 --> Utf8 Class Initialized
INFO - 2024-12-02 09:07:10 --> URI Class Initialized
INFO - 2024-12-02 09:07:10 --> Router Class Initialized
INFO - 2024-12-02 09:07:10 --> Output Class Initialized
INFO - 2024-12-02 09:07:10 --> Security Class Initialized
DEBUG - 2024-12-02 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:07:10 --> CSRF cookie sent
INFO - 2024-12-02 09:07:10 --> Input Class Initialized
INFO - 2024-12-02 09:07:10 --> Language Class Initialized
INFO - 2024-12-02 09:07:10 --> Loader Class Initialized
INFO - 2024-12-02 09:07:10 --> Helper loaded: url_helper
INFO - 2024-12-02 09:07:10 --> Helper loaded: form_helper
INFO - 2024-12-02 09:07:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:07:10 --> Form Validation Class Initialized
INFO - 2024-12-02 09:07:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:07:10 --> Controller Class Initialized
INFO - 2024-12-02 09:07:10 --> Model "News_model" initialized
INFO - 2024-12-02 09:07:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 09:07:10 --> Final output sent to browser
DEBUG - 2024-12-02 09:07:10 --> Total execution time: 0.0653
INFO - 2024-12-02 09:08:06 --> Config Class Initialized
INFO - 2024-12-02 09:08:06 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:06 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:06 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:06 --> URI Class Initialized
INFO - 2024-12-02 09:08:06 --> Router Class Initialized
INFO - 2024-12-02 09:08:06 --> Output Class Initialized
INFO - 2024-12-02 09:08:06 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:06 --> CSRF cookie sent
INFO - 2024-12-02 09:08:06 --> Input Class Initialized
INFO - 2024-12-02 09:08:06 --> Language Class Initialized
INFO - 2024-12-02 09:08:06 --> Loader Class Initialized
INFO - 2024-12-02 09:08:06 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:06 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:06 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:06 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:06 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:06 --> Controller Class Initialized
INFO - 2024-12-02 09:08:06 --> Model "News_model" initialized
INFO - 2024-12-02 09:08:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 09:08:06 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:06 --> Total execution time: 0.0972
INFO - 2024-12-02 09:08:09 --> Config Class Initialized
INFO - 2024-12-02 09:08:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:09 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:09 --> URI Class Initialized
INFO - 2024-12-02 09:08:09 --> Router Class Initialized
INFO - 2024-12-02 09:08:09 --> Output Class Initialized
INFO - 2024-12-02 09:08:09 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:09 --> CSRF cookie sent
INFO - 2024-12-02 09:08:09 --> Input Class Initialized
INFO - 2024-12-02 09:08:09 --> Language Class Initialized
INFO - 2024-12-02 09:08:09 --> Loader Class Initialized
INFO - 2024-12-02 09:08:09 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:09 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:09 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:09 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:09 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:09 --> Controller Class Initialized
INFO - 2024-12-02 09:08:09 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:09 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:09 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:09 --> Config Class Initialized
INFO - 2024-12-02 09:08:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:09 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:09 --> URI Class Initialized
INFO - 2024-12-02 09:08:09 --> Router Class Initialized
INFO - 2024-12-02 09:08:09 --> Output Class Initialized
INFO - 2024-12-02 09:08:09 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:09 --> CSRF cookie sent
INFO - 2024-12-02 09:08:09 --> Input Class Initialized
INFO - 2024-12-02 09:08:09 --> Language Class Initialized
INFO - 2024-12-02 09:08:09 --> Loader Class Initialized
INFO - 2024-12-02 09:08:09 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:09 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:09 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:09 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:09 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:09 --> Controller Class Initialized
INFO - 2024-12-02 09:08:09 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:09 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:09 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:08:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:08:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 09:08:09 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:09 --> Total execution time: 0.0825
INFO - 2024-12-02 09:08:12 --> Config Class Initialized
INFO - 2024-12-02 09:08:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:12 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:12 --> URI Class Initialized
INFO - 2024-12-02 09:08:12 --> Router Class Initialized
INFO - 2024-12-02 09:08:12 --> Output Class Initialized
INFO - 2024-12-02 09:08:12 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:12 --> CSRF cookie sent
INFO - 2024-12-02 09:08:12 --> CSRF token verified
INFO - 2024-12-02 09:08:12 --> Input Class Initialized
INFO - 2024-12-02 09:08:12 --> Language Class Initialized
INFO - 2024-12-02 09:08:12 --> Loader Class Initialized
INFO - 2024-12-02 09:08:12 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:12 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:12 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:12 --> Controller Class Initialized
INFO - 2024-12-02 09:08:12 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:12 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:12 --> Model "Review_model" initialized
INFO - 2024-12-02 09:08:12 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:12 --> Config Class Initialized
INFO - 2024-12-02 09:08:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:12 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:12 --> URI Class Initialized
INFO - 2024-12-02 09:08:12 --> Router Class Initialized
INFO - 2024-12-02 09:08:12 --> Output Class Initialized
INFO - 2024-12-02 09:08:12 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:12 --> CSRF cookie sent
INFO - 2024-12-02 09:08:12 --> Input Class Initialized
INFO - 2024-12-02 09:08:12 --> Language Class Initialized
INFO - 2024-12-02 09:08:12 --> Loader Class Initialized
INFO - 2024-12-02 09:08:12 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:12 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:12 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:12 --> Controller Class Initialized
INFO - 2024-12-02 09:08:12 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:12 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 09:08:12 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:12 --> Total execution time: 0.0568
INFO - 2024-12-02 09:08:16 --> Config Class Initialized
INFO - 2024-12-02 09:08:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:16 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:16 --> URI Class Initialized
INFO - 2024-12-02 09:08:16 --> Router Class Initialized
INFO - 2024-12-02 09:08:16 --> Output Class Initialized
INFO - 2024-12-02 09:08:16 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:16 --> CSRF cookie sent
INFO - 2024-12-02 09:08:16 --> Input Class Initialized
INFO - 2024-12-02 09:08:16 --> Language Class Initialized
INFO - 2024-12-02 09:08:16 --> Loader Class Initialized
INFO - 2024-12-02 09:08:16 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:16 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:16 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:16 --> Controller Class Initialized
INFO - 2024-12-02 09:08:16 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:16 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:16 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 09:08:16 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:16 --> Total execution time: 0.0431
INFO - 2024-12-02 09:08:17 --> Config Class Initialized
INFO - 2024-12-02 09:08:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:17 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:17 --> URI Class Initialized
INFO - 2024-12-02 09:08:17 --> Router Class Initialized
INFO - 2024-12-02 09:08:17 --> Output Class Initialized
INFO - 2024-12-02 09:08:17 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:17 --> CSRF cookie sent
INFO - 2024-12-02 09:08:17 --> Input Class Initialized
INFO - 2024-12-02 09:08:17 --> Language Class Initialized
INFO - 2024-12-02 09:08:17 --> Loader Class Initialized
INFO - 2024-12-02 09:08:17 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:17 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:17 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:17 --> Controller Class Initialized
INFO - 2024-12-02 09:08:17 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:17 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 09:08:17 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:17 --> Total execution time: 0.0432
INFO - 2024-12-02 09:08:19 --> Config Class Initialized
INFO - 2024-12-02 09:08:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:19 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:19 --> URI Class Initialized
INFO - 2024-12-02 09:08:19 --> Router Class Initialized
INFO - 2024-12-02 09:08:19 --> Output Class Initialized
INFO - 2024-12-02 09:08:19 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:19 --> CSRF cookie sent
INFO - 2024-12-02 09:08:19 --> Input Class Initialized
INFO - 2024-12-02 09:08:19 --> Language Class Initialized
INFO - 2024-12-02 09:08:19 --> Loader Class Initialized
INFO - 2024-12-02 09:08:19 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:19 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:19 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:19 --> Controller Class Initialized
INFO - 2024-12-02 09:08:19 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:19 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 09:08:19 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:19 --> Total execution time: 0.0572
INFO - 2024-12-02 09:08:22 --> Config Class Initialized
INFO - 2024-12-02 09:08:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:22 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:22 --> URI Class Initialized
INFO - 2024-12-02 09:08:22 --> Router Class Initialized
INFO - 2024-12-02 09:08:22 --> Output Class Initialized
INFO - 2024-12-02 09:08:22 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:22 --> CSRF cookie sent
INFO - 2024-12-02 09:08:22 --> Input Class Initialized
INFO - 2024-12-02 09:08:22 --> Language Class Initialized
INFO - 2024-12-02 09:08:22 --> Loader Class Initialized
INFO - 2024-12-02 09:08:22 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:22 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:22 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:22 --> Controller Class Initialized
INFO - 2024-12-02 09:08:22 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:22 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 09:08:22 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:22 --> Total execution time: 0.0395
INFO - 2024-12-02 09:08:24 --> Config Class Initialized
INFO - 2024-12-02 09:08:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:24 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:24 --> URI Class Initialized
INFO - 2024-12-02 09:08:24 --> Router Class Initialized
INFO - 2024-12-02 09:08:24 --> Output Class Initialized
INFO - 2024-12-02 09:08:24 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:24 --> CSRF cookie sent
INFO - 2024-12-02 09:08:24 --> Input Class Initialized
INFO - 2024-12-02 09:08:24 --> Language Class Initialized
INFO - 2024-12-02 09:08:24 --> Loader Class Initialized
INFO - 2024-12-02 09:08:24 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:24 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:24 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:24 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:24 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:24 --> Controller Class Initialized
INFO - 2024-12-02 09:08:24 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:24 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 09:08:24 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:24 --> Total execution time: 0.0418
INFO - 2024-12-02 09:08:26 --> Config Class Initialized
INFO - 2024-12-02 09:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:26 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:26 --> URI Class Initialized
INFO - 2024-12-02 09:08:26 --> Router Class Initialized
INFO - 2024-12-02 09:08:26 --> Output Class Initialized
INFO - 2024-12-02 09:08:26 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:26 --> CSRF cookie sent
INFO - 2024-12-02 09:08:26 --> Input Class Initialized
INFO - 2024-12-02 09:08:26 --> Language Class Initialized
INFO - 2024-12-02 09:08:26 --> Loader Class Initialized
INFO - 2024-12-02 09:08:26 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:26 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:26 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:26 --> Controller Class Initialized
INFO - 2024-12-02 09:08:26 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:26 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 09:08:26 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:26 --> Total execution time: 0.0572
INFO - 2024-12-02 09:08:28 --> Config Class Initialized
INFO - 2024-12-02 09:08:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:28 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:28 --> URI Class Initialized
INFO - 2024-12-02 09:08:28 --> Router Class Initialized
INFO - 2024-12-02 09:08:28 --> Output Class Initialized
INFO - 2024-12-02 09:08:28 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:28 --> CSRF cookie sent
INFO - 2024-12-02 09:08:28 --> Input Class Initialized
INFO - 2024-12-02 09:08:28 --> Language Class Initialized
INFO - 2024-12-02 09:08:28 --> Loader Class Initialized
INFO - 2024-12-02 09:08:28 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:28 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:28 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:28 --> Controller Class Initialized
INFO - 2024-12-02 09:08:28 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:28 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 09:08:28 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:28 --> Total execution time: 0.0554
INFO - 2024-12-02 09:08:37 --> Config Class Initialized
INFO - 2024-12-02 09:08:37 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:37 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:37 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:37 --> URI Class Initialized
INFO - 2024-12-02 09:08:37 --> Router Class Initialized
INFO - 2024-12-02 09:08:37 --> Output Class Initialized
INFO - 2024-12-02 09:08:37 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:37 --> CSRF cookie sent
INFO - 2024-12-02 09:08:37 --> Input Class Initialized
INFO - 2024-12-02 09:08:37 --> Language Class Initialized
INFO - 2024-12-02 09:08:37 --> Loader Class Initialized
INFO - 2024-12-02 09:08:37 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:37 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:37 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:37 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:37 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:37 --> Controller Class Initialized
INFO - 2024-12-02 09:08:37 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:37 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:37 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:37 --> Model "Contact_model" initialized
INFO - 2024-12-02 09:08:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-02 09:08:37 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:37 --> Total execution time: 0.0542
INFO - 2024-12-02 09:08:41 --> Config Class Initialized
INFO - 2024-12-02 09:08:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:41 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:41 --> URI Class Initialized
INFO - 2024-12-02 09:08:41 --> Router Class Initialized
INFO - 2024-12-02 09:08:41 --> Output Class Initialized
INFO - 2024-12-02 09:08:41 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:41 --> CSRF cookie sent
INFO - 2024-12-02 09:08:41 --> Input Class Initialized
INFO - 2024-12-02 09:08:41 --> Language Class Initialized
INFO - 2024-12-02 09:08:41 --> Loader Class Initialized
INFO - 2024-12-02 09:08:41 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:41 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:41 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:41 --> Controller Class Initialized
INFO - 2024-12-02 09:08:41 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:41 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:41 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-02 09:08:41 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:41 --> Total execution time: 0.1105
INFO - 2024-12-02 09:08:44 --> Config Class Initialized
INFO - 2024-12-02 09:08:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:44 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:44 --> URI Class Initialized
INFO - 2024-12-02 09:08:44 --> Router Class Initialized
INFO - 2024-12-02 09:08:44 --> Output Class Initialized
INFO - 2024-12-02 09:08:44 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:44 --> CSRF cookie sent
INFO - 2024-12-02 09:08:44 --> Input Class Initialized
INFO - 2024-12-02 09:08:44 --> Language Class Initialized
INFO - 2024-12-02 09:08:44 --> Loader Class Initialized
INFO - 2024-12-02 09:08:44 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:44 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:44 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:44 --> Controller Class Initialized
INFO - 2024-12-02 09:08:44 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:44 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:44 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 09:08:44 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:44 --> Total execution time: 0.0469
INFO - 2024-12-02 09:08:45 --> Config Class Initialized
INFO - 2024-12-02 09:08:45 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:45 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:45 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:45 --> URI Class Initialized
INFO - 2024-12-02 09:08:45 --> Router Class Initialized
INFO - 2024-12-02 09:08:45 --> Output Class Initialized
INFO - 2024-12-02 09:08:45 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:45 --> CSRF cookie sent
INFO - 2024-12-02 09:08:45 --> Input Class Initialized
INFO - 2024-12-02 09:08:45 --> Language Class Initialized
INFO - 2024-12-02 09:08:45 --> Loader Class Initialized
INFO - 2024-12-02 09:08:45 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:45 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:45 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:45 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:45 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:45 --> Controller Class Initialized
INFO - 2024-12-02 09:08:45 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:45 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:45 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 09:08:45 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:45 --> Total execution time: 0.0453
INFO - 2024-12-02 09:08:46 --> Config Class Initialized
INFO - 2024-12-02 09:08:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:46 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:46 --> URI Class Initialized
INFO - 2024-12-02 09:08:46 --> Router Class Initialized
INFO - 2024-12-02 09:08:47 --> Output Class Initialized
INFO - 2024-12-02 09:08:47 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:47 --> CSRF cookie sent
INFO - 2024-12-02 09:08:47 --> Input Class Initialized
INFO - 2024-12-02 09:08:47 --> Language Class Initialized
INFO - 2024-12-02 09:08:47 --> Loader Class Initialized
INFO - 2024-12-02 09:08:47 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:47 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:47 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:47 --> Controller Class Initialized
INFO - 2024-12-02 09:08:47 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:47 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:47 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 09:08:47 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:47 --> Total execution time: 0.0588
INFO - 2024-12-02 09:08:48 --> Config Class Initialized
INFO - 2024-12-02 09:08:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:08:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:08:48 --> Utf8 Class Initialized
INFO - 2024-12-02 09:08:48 --> URI Class Initialized
INFO - 2024-12-02 09:08:48 --> Router Class Initialized
INFO - 2024-12-02 09:08:48 --> Output Class Initialized
INFO - 2024-12-02 09:08:48 --> Security Class Initialized
DEBUG - 2024-12-02 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:08:48 --> CSRF cookie sent
INFO - 2024-12-02 09:08:48 --> Input Class Initialized
INFO - 2024-12-02 09:08:48 --> Language Class Initialized
INFO - 2024-12-02 09:08:48 --> Loader Class Initialized
INFO - 2024-12-02 09:08:48 --> Helper loaded: url_helper
INFO - 2024-12-02 09:08:48 --> Helper loaded: form_helper
INFO - 2024-12-02 09:08:48 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:08:48 --> Form Validation Class Initialized
INFO - 2024-12-02 09:08:48 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:08:48 --> Controller Class Initialized
INFO - 2024-12-02 09:08:48 --> Model "Category_model" initialized
INFO - 2024-12-02 09:08:48 --> Model "User_model" initialized
INFO - 2024-12-02 09:08:48 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:08:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 09:08:48 --> Final output sent to browser
DEBUG - 2024-12-02 09:08:48 --> Total execution time: 0.0403
INFO - 2024-12-02 09:31:06 --> Config Class Initialized
INFO - 2024-12-02 09:31:06 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:31:06 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:31:06 --> Utf8 Class Initialized
INFO - 2024-12-02 09:31:06 --> URI Class Initialized
INFO - 2024-12-02 09:31:06 --> Router Class Initialized
INFO - 2024-12-02 09:31:06 --> Output Class Initialized
INFO - 2024-12-02 09:31:06 --> Security Class Initialized
DEBUG - 2024-12-02 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:31:06 --> CSRF cookie sent
INFO - 2024-12-02 09:31:06 --> Input Class Initialized
INFO - 2024-12-02 09:31:06 --> Language Class Initialized
INFO - 2024-12-02 09:31:06 --> Loader Class Initialized
INFO - 2024-12-02 09:31:06 --> Helper loaded: url_helper
INFO - 2024-12-02 09:31:06 --> Helper loaded: form_helper
INFO - 2024-12-02 09:31:06 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:31:06 --> Form Validation Class Initialized
INFO - 2024-12-02 09:31:06 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:31:06 --> Controller Class Initialized
INFO - 2024-12-02 09:31:06 --> Model "User_model" initialized
INFO - 2024-12-02 09:31:06 --> Model "Category_model" initialized
INFO - 2024-12-02 09:31:06 --> Model "Review_model" initialized
INFO - 2024-12-02 09:31:06 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:31:06 --> Config Class Initialized
INFO - 2024-12-02 09:31:06 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:31:06 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:31:06 --> Utf8 Class Initialized
INFO - 2024-12-02 09:31:06 --> URI Class Initialized
INFO - 2024-12-02 09:31:06 --> Router Class Initialized
INFO - 2024-12-02 09:31:06 --> Output Class Initialized
INFO - 2024-12-02 09:31:06 --> Security Class Initialized
DEBUG - 2024-12-02 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:31:06 --> CSRF cookie sent
INFO - 2024-12-02 09:31:06 --> Input Class Initialized
INFO - 2024-12-02 09:31:06 --> Language Class Initialized
INFO - 2024-12-02 09:31:06 --> Loader Class Initialized
INFO - 2024-12-02 09:31:06 --> Helper loaded: url_helper
INFO - 2024-12-02 09:31:06 --> Helper loaded: form_helper
INFO - 2024-12-02 09:31:06 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:31:06 --> Form Validation Class Initialized
INFO - 2024-12-02 09:31:06 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:31:06 --> Controller Class Initialized
INFO - 2024-12-02 09:31:06 --> Model "User_model" initialized
INFO - 2024-12-02 09:31:06 --> Model "Category_model" initialized
INFO - 2024-12-02 09:31:06 --> Model "Review_model" initialized
INFO - 2024-12-02 09:31:06 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:31:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:31:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:31:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 09:31:06 --> Final output sent to browser
DEBUG - 2024-12-02 09:31:06 --> Total execution time: 0.0544
INFO - 2024-12-02 09:31:11 --> Config Class Initialized
INFO - 2024-12-02 09:31:11 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:31:11 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:31:11 --> Utf8 Class Initialized
INFO - 2024-12-02 09:31:11 --> URI Class Initialized
INFO - 2024-12-02 09:31:11 --> Router Class Initialized
INFO - 2024-12-02 09:31:11 --> Output Class Initialized
INFO - 2024-12-02 09:31:11 --> Security Class Initialized
DEBUG - 2024-12-02 09:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:31:11 --> CSRF cookie sent
INFO - 2024-12-02 09:31:11 --> CSRF token verified
INFO - 2024-12-02 09:31:11 --> Input Class Initialized
INFO - 2024-12-02 09:31:11 --> Language Class Initialized
INFO - 2024-12-02 09:31:11 --> Loader Class Initialized
INFO - 2024-12-02 09:31:11 --> Helper loaded: url_helper
INFO - 2024-12-02 09:31:11 --> Helper loaded: form_helper
INFO - 2024-12-02 09:31:11 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:31:11 --> Form Validation Class Initialized
INFO - 2024-12-02 09:31:11 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:31:11 --> Controller Class Initialized
INFO - 2024-12-02 09:31:11 --> Model "User_model" initialized
INFO - 2024-12-02 09:31:11 --> Model "Category_model" initialized
INFO - 2024-12-02 09:31:11 --> Model "Review_model" initialized
INFO - 2024-12-02 09:31:11 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:31:12 --> Config Class Initialized
INFO - 2024-12-02 09:31:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:31:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:31:12 --> Utf8 Class Initialized
INFO - 2024-12-02 09:31:12 --> URI Class Initialized
INFO - 2024-12-02 09:31:12 --> Router Class Initialized
INFO - 2024-12-02 09:31:12 --> Output Class Initialized
INFO - 2024-12-02 09:31:12 --> Security Class Initialized
DEBUG - 2024-12-02 09:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:31:12 --> CSRF cookie sent
INFO - 2024-12-02 09:31:12 --> Input Class Initialized
INFO - 2024-12-02 09:31:12 --> Language Class Initialized
INFO - 2024-12-02 09:31:12 --> Loader Class Initialized
INFO - 2024-12-02 09:31:12 --> Helper loaded: url_helper
INFO - 2024-12-02 09:31:12 --> Helper loaded: form_helper
INFO - 2024-12-02 09:31:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:31:12 --> Form Validation Class Initialized
INFO - 2024-12-02 09:31:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:31:12 --> Controller Class Initialized
INFO - 2024-12-02 09:31:12 --> Model "User_model" initialized
INFO - 2024-12-02 09:31:12 --> Model "Category_model" initialized
INFO - 2024-12-02 09:31:12 --> Model "Review_model" initialized
INFO - 2024-12-02 09:31:12 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:31:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
ERROR - 2024-12-02 09:31:12 --> Severity: Warning --> Undefined variable $view_count C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 377
INFO - 2024-12-02 09:31:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:31:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:31:12 --> Final output sent to browser
DEBUG - 2024-12-02 09:31:12 --> Total execution time: 0.2730
INFO - 2024-12-02 09:31:12 --> Config Class Initialized
INFO - 2024-12-02 09:31:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:31:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:31:12 --> Utf8 Class Initialized
INFO - 2024-12-02 09:31:12 --> URI Class Initialized
INFO - 2024-12-02 09:31:12 --> Router Class Initialized
INFO - 2024-12-02 09:31:12 --> Output Class Initialized
INFO - 2024-12-02 09:31:12 --> Security Class Initialized
DEBUG - 2024-12-02 09:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:31:12 --> CSRF cookie sent
INFO - 2024-12-02 09:31:12 --> Input Class Initialized
INFO - 2024-12-02 09:31:12 --> Language Class Initialized
ERROR - 2024-12-02 09:31:12 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:35:48 --> Config Class Initialized
INFO - 2024-12-02 09:35:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:35:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:35:48 --> Utf8 Class Initialized
INFO - 2024-12-02 09:35:48 --> URI Class Initialized
INFO - 2024-12-02 09:35:48 --> Router Class Initialized
INFO - 2024-12-02 09:35:48 --> Output Class Initialized
INFO - 2024-12-02 09:35:48 --> Security Class Initialized
DEBUG - 2024-12-02 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:35:48 --> CSRF cookie sent
INFO - 2024-12-02 09:35:48 --> Input Class Initialized
INFO - 2024-12-02 09:35:48 --> Language Class Initialized
INFO - 2024-12-02 09:35:48 --> Loader Class Initialized
INFO - 2024-12-02 09:35:48 --> Helper loaded: url_helper
INFO - 2024-12-02 09:35:48 --> Helper loaded: form_helper
INFO - 2024-12-02 09:35:48 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:35:49 --> Form Validation Class Initialized
INFO - 2024-12-02 09:35:49 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:35:49 --> Controller Class Initialized
INFO - 2024-12-02 09:35:49 --> Model "User_model" initialized
INFO - 2024-12-02 09:35:49 --> Model "Category_model" initialized
INFO - 2024-12-02 09:35:49 --> Model "Review_model" initialized
INFO - 2024-12-02 09:35:49 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:35:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
ERROR - 2024-12-02 09:35:49 --> Severity: Warning --> Undefined variable $view_count C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\index.php 377
INFO - 2024-12-02 09:35:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:35:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:35:49 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:35:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:35:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:35:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:35:49 --> Final output sent to browser
DEBUG - 2024-12-02 09:35:49 --> Total execution time: 0.5007
INFO - 2024-12-02 09:35:50 --> Config Class Initialized
INFO - 2024-12-02 09:35:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:35:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:35:50 --> Utf8 Class Initialized
INFO - 2024-12-02 09:35:50 --> URI Class Initialized
INFO - 2024-12-02 09:35:50 --> Router Class Initialized
INFO - 2024-12-02 09:35:50 --> Output Class Initialized
INFO - 2024-12-02 09:35:50 --> Security Class Initialized
DEBUG - 2024-12-02 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:35:50 --> CSRF cookie sent
INFO - 2024-12-02 09:35:50 --> Input Class Initialized
INFO - 2024-12-02 09:35:50 --> Language Class Initialized
ERROR - 2024-12-02 09:35:50 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:40:04 --> Config Class Initialized
INFO - 2024-12-02 09:40:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:04 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:04 --> URI Class Initialized
INFO - 2024-12-02 09:40:04 --> Router Class Initialized
INFO - 2024-12-02 09:40:04 --> Output Class Initialized
INFO - 2024-12-02 09:40:04 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:04 --> CSRF cookie sent
INFO - 2024-12-02 09:40:04 --> Input Class Initialized
INFO - 2024-12-02 09:40:04 --> Language Class Initialized
INFO - 2024-12-02 09:40:04 --> Loader Class Initialized
INFO - 2024-12-02 09:40:04 --> Helper loaded: url_helper
INFO - 2024-12-02 09:40:04 --> Helper loaded: form_helper
INFO - 2024-12-02 09:40:04 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:40:04 --> Form Validation Class Initialized
INFO - 2024-12-02 09:40:04 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:40:04 --> Controller Class Initialized
INFO - 2024-12-02 09:40:04 --> Model "User_model" initialized
INFO - 2024-12-02 09:40:04 --> Model "Category_model" initialized
INFO - 2024-12-02 09:40:04 --> Model "Review_model" initialized
INFO - 2024-12-02 09:40:04 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:40:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:40:05 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:40:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:40:05 --> Final output sent to browser
DEBUG - 2024-12-02 09:40:05 --> Total execution time: 0.8206
INFO - 2024-12-02 09:40:14 --> Config Class Initialized
INFO - 2024-12-02 09:40:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:14 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:14 --> URI Class Initialized
INFO - 2024-12-02 09:40:14 --> Router Class Initialized
INFO - 2024-12-02 09:40:14 --> Output Class Initialized
INFO - 2024-12-02 09:40:14 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:14 --> CSRF cookie sent
INFO - 2024-12-02 09:40:14 --> Input Class Initialized
INFO - 2024-12-02 09:40:14 --> Language Class Initialized
INFO - 2024-12-02 09:40:14 --> Loader Class Initialized
INFO - 2024-12-02 09:40:14 --> Helper loaded: url_helper
INFO - 2024-12-02 09:40:14 --> Helper loaded: form_helper
INFO - 2024-12-02 09:40:14 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:40:14 --> Form Validation Class Initialized
INFO - 2024-12-02 09:40:14 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:40:14 --> Controller Class Initialized
INFO - 2024-12-02 09:40:14 --> Model "User_model" initialized
INFO - 2024-12-02 09:40:14 --> Model "Category_model" initialized
INFO - 2024-12-02 09:40:14 --> Model "Review_model" initialized
INFO - 2024-12-02 09:40:14 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:40:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 09:40:14 --> Final output sent to browser
DEBUG - 2024-12-02 09:40:14 --> Total execution time: 0.0745
INFO - 2024-12-02 09:40:17 --> Config Class Initialized
INFO - 2024-12-02 09:40:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:17 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:17 --> URI Class Initialized
INFO - 2024-12-02 09:40:17 --> Router Class Initialized
INFO - 2024-12-02 09:40:17 --> Output Class Initialized
INFO - 2024-12-02 09:40:17 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:17 --> CSRF cookie sent
INFO - 2024-12-02 09:40:17 --> CSRF token verified
INFO - 2024-12-02 09:40:17 --> Input Class Initialized
INFO - 2024-12-02 09:40:17 --> Language Class Initialized
INFO - 2024-12-02 09:40:17 --> Loader Class Initialized
INFO - 2024-12-02 09:40:17 --> Helper loaded: url_helper
INFO - 2024-12-02 09:40:17 --> Helper loaded: form_helper
INFO - 2024-12-02 09:40:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:40:17 --> Form Validation Class Initialized
INFO - 2024-12-02 09:40:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:40:17 --> Controller Class Initialized
INFO - 2024-12-02 09:40:17 --> Model "User_model" initialized
INFO - 2024-12-02 09:40:17 --> Model "Category_model" initialized
INFO - 2024-12-02 09:40:17 --> Model "Review_model" initialized
INFO - 2024-12-02 09:40:17 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:40:17 --> Config Class Initialized
INFO - 2024-12-02 09:40:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:17 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:17 --> URI Class Initialized
INFO - 2024-12-02 09:40:17 --> Router Class Initialized
INFO - 2024-12-02 09:40:17 --> Output Class Initialized
INFO - 2024-12-02 09:40:17 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:17 --> CSRF cookie sent
INFO - 2024-12-02 09:40:17 --> Input Class Initialized
INFO - 2024-12-02 09:40:17 --> Language Class Initialized
INFO - 2024-12-02 09:40:17 --> Loader Class Initialized
INFO - 2024-12-02 09:40:17 --> Helper loaded: url_helper
INFO - 2024-12-02 09:40:17 --> Helper loaded: form_helper
INFO - 2024-12-02 09:40:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:40:17 --> Form Validation Class Initialized
INFO - 2024-12-02 09:40:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:40:17 --> Controller Class Initialized
INFO - 2024-12-02 09:40:17 --> Model "User_model" initialized
INFO - 2024-12-02 09:40:17 --> Model "Category_model" initialized
INFO - 2024-12-02 09:40:17 --> Model "Review_model" initialized
INFO - 2024-12-02 09:40:17 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:40:17 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:40:17 --> Final output sent to browser
DEBUG - 2024-12-02 09:40:17 --> Total execution time: 0.0639
INFO - 2024-12-02 09:40:17 --> Config Class Initialized
INFO - 2024-12-02 09:40:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:17 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:17 --> URI Class Initialized
INFO - 2024-12-02 09:40:17 --> Router Class Initialized
INFO - 2024-12-02 09:40:17 --> Output Class Initialized
INFO - 2024-12-02 09:40:17 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:17 --> CSRF cookie sent
INFO - 2024-12-02 09:40:17 --> Input Class Initialized
INFO - 2024-12-02 09:40:17 --> Language Class Initialized
ERROR - 2024-12-02 09:40:17 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:40:22 --> Config Class Initialized
INFO - 2024-12-02 09:40:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:22 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:22 --> URI Class Initialized
INFO - 2024-12-02 09:40:22 --> Router Class Initialized
INFO - 2024-12-02 09:40:22 --> Output Class Initialized
INFO - 2024-12-02 09:40:22 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:22 --> CSRF cookie sent
INFO - 2024-12-02 09:40:22 --> Input Class Initialized
INFO - 2024-12-02 09:40:22 --> Language Class Initialized
INFO - 2024-12-02 09:40:22 --> Loader Class Initialized
INFO - 2024-12-02 09:40:22 --> Helper loaded: url_helper
INFO - 2024-12-02 09:40:22 --> Helper loaded: form_helper
INFO - 2024-12-02 09:40:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:40:22 --> Form Validation Class Initialized
INFO - 2024-12-02 09:40:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:40:22 --> Controller Class Initialized
INFO - 2024-12-02 09:40:22 --> Model "User_model" initialized
INFO - 2024-12-02 09:40:22 --> Model "Category_model" initialized
INFO - 2024-12-02 09:40:22 --> Model "Review_model" initialized
INFO - 2024-12-02 09:40:22 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:40:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:40:22 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:40:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:40:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:40:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:40:22 --> Final output sent to browser
DEBUG - 2024-12-02 09:40:22 --> Total execution time: 0.1011
INFO - 2024-12-02 09:40:22 --> Config Class Initialized
INFO - 2024-12-02 09:40:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:40:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:40:22 --> Utf8 Class Initialized
INFO - 2024-12-02 09:40:22 --> URI Class Initialized
INFO - 2024-12-02 09:40:22 --> Router Class Initialized
INFO - 2024-12-02 09:40:22 --> Output Class Initialized
INFO - 2024-12-02 09:40:22 --> Security Class Initialized
DEBUG - 2024-12-02 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:40:22 --> CSRF cookie sent
INFO - 2024-12-02 09:40:22 --> Input Class Initialized
INFO - 2024-12-02 09:40:22 --> Language Class Initialized
ERROR - 2024-12-02 09:40:22 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:41:02 --> Config Class Initialized
INFO - 2024-12-02 09:41:02 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:02 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:02 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:02 --> URI Class Initialized
INFO - 2024-12-02 09:41:02 --> Router Class Initialized
INFO - 2024-12-02 09:41:02 --> Output Class Initialized
INFO - 2024-12-02 09:41:02 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:02 --> CSRF cookie sent
INFO - 2024-12-02 09:41:02 --> Input Class Initialized
INFO - 2024-12-02 09:41:02 --> Language Class Initialized
INFO - 2024-12-02 09:41:02 --> Loader Class Initialized
INFO - 2024-12-02 09:41:02 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:02 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:02 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:02 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:02 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:02 --> Controller Class Initialized
INFO - 2024-12-02 09:41:02 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:02 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:02 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:02 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:03 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:03 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:03 --> Total execution time: 0.9359
INFO - 2024-12-02 09:41:09 --> Config Class Initialized
INFO - 2024-12-02 09:41:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:10 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:10 --> URI Class Initialized
INFO - 2024-12-02 09:41:10 --> Router Class Initialized
INFO - 2024-12-02 09:41:10 --> Output Class Initialized
INFO - 2024-12-02 09:41:10 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:10 --> CSRF cookie sent
INFO - 2024-12-02 09:41:10 --> Input Class Initialized
INFO - 2024-12-02 09:41:10 --> Language Class Initialized
INFO - 2024-12-02 09:41:10 --> Loader Class Initialized
INFO - 2024-12-02 09:41:10 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:10 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:11 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:11 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:11 --> Controller Class Initialized
INFO - 2024-12-02 09:41:11 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:11 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:11 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:11 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 09:41:11 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:11 --> Total execution time: 1.3208
INFO - 2024-12-02 09:41:44 --> Config Class Initialized
INFO - 2024-12-02 09:41:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:44 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:44 --> URI Class Initialized
INFO - 2024-12-02 09:41:44 --> Router Class Initialized
INFO - 2024-12-02 09:41:44 --> Output Class Initialized
INFO - 2024-12-02 09:41:44 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:44 --> CSRF cookie sent
INFO - 2024-12-02 09:41:44 --> CSRF token verified
INFO - 2024-12-02 09:41:44 --> Input Class Initialized
INFO - 2024-12-02 09:41:44 --> Language Class Initialized
INFO - 2024-12-02 09:41:44 --> Loader Class Initialized
INFO - 2024-12-02 09:41:44 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:44 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:44 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:44 --> Controller Class Initialized
INFO - 2024-12-02 09:41:44 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:44 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:44 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:44 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:44 --> Config Class Initialized
INFO - 2024-12-02 09:41:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:44 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:44 --> URI Class Initialized
INFO - 2024-12-02 09:41:44 --> Router Class Initialized
INFO - 2024-12-02 09:41:44 --> Output Class Initialized
INFO - 2024-12-02 09:41:44 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:44 --> CSRF cookie sent
INFO - 2024-12-02 09:41:44 --> Input Class Initialized
INFO - 2024-12-02 09:41:44 --> Language Class Initialized
INFO - 2024-12-02 09:41:44 --> Loader Class Initialized
INFO - 2024-12-02 09:41:44 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:44 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:44 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:44 --> Controller Class Initialized
INFO - 2024-12-02 09:41:44 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:44 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:44 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:44 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:44 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:41:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:44 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:44 --> Total execution time: 0.1539
INFO - 2024-12-02 09:41:45 --> Config Class Initialized
INFO - 2024-12-02 09:41:45 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:45 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:45 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:45 --> URI Class Initialized
INFO - 2024-12-02 09:41:45 --> Router Class Initialized
INFO - 2024-12-02 09:41:45 --> Output Class Initialized
INFO - 2024-12-02 09:41:45 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:45 --> CSRF cookie sent
INFO - 2024-12-02 09:41:45 --> Input Class Initialized
INFO - 2024-12-02 09:41:45 --> Language Class Initialized
ERROR - 2024-12-02 09:41:45 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:41:48 --> Config Class Initialized
INFO - 2024-12-02 09:41:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:48 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:48 --> URI Class Initialized
INFO - 2024-12-02 09:41:48 --> Router Class Initialized
INFO - 2024-12-02 09:41:48 --> Output Class Initialized
INFO - 2024-12-02 09:41:48 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:48 --> CSRF cookie sent
INFO - 2024-12-02 09:41:48 --> Input Class Initialized
INFO - 2024-12-02 09:41:48 --> Language Class Initialized
INFO - 2024-12-02 09:41:48 --> Loader Class Initialized
INFO - 2024-12-02 09:41:48 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:48 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:48 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:48 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:48 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:48 --> Controller Class Initialized
INFO - 2024-12-02 09:41:48 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:48 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:48 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:48 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:48 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:41:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:48 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:48 --> Total execution time: 0.0889
INFO - 2024-12-02 09:41:48 --> Config Class Initialized
INFO - 2024-12-02 09:41:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:48 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:48 --> URI Class Initialized
INFO - 2024-12-02 09:41:48 --> Router Class Initialized
INFO - 2024-12-02 09:41:48 --> Output Class Initialized
INFO - 2024-12-02 09:41:48 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:48 --> CSRF cookie sent
INFO - 2024-12-02 09:41:48 --> Input Class Initialized
INFO - 2024-12-02 09:41:48 --> Language Class Initialized
ERROR - 2024-12-02 09:41:48 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:41:52 --> Config Class Initialized
INFO - 2024-12-02 09:41:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:52 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:52 --> URI Class Initialized
DEBUG - 2024-12-02 09:41:52 --> No URI present. Default controller set.
INFO - 2024-12-02 09:41:52 --> Router Class Initialized
INFO - 2024-12-02 09:41:52 --> Output Class Initialized
INFO - 2024-12-02 09:41:52 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:52 --> CSRF cookie sent
INFO - 2024-12-02 09:41:52 --> Input Class Initialized
INFO - 2024-12-02 09:41:52 --> Language Class Initialized
INFO - 2024-12-02 09:41:52 --> Loader Class Initialized
INFO - 2024-12-02 09:41:52 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:52 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:52 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:52 --> Controller Class Initialized
INFO - 2024-12-02 09:41:52 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:52 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:52 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:52 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:52 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:41:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:52 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:52 --> Total execution time: 0.1160
INFO - 2024-12-02 09:41:56 --> Config Class Initialized
INFO - 2024-12-02 09:41:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:56 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:56 --> URI Class Initialized
INFO - 2024-12-02 09:41:56 --> Router Class Initialized
INFO - 2024-12-02 09:41:56 --> Output Class Initialized
INFO - 2024-12-02 09:41:56 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:56 --> CSRF cookie sent
INFO - 2024-12-02 09:41:56 --> Input Class Initialized
INFO - 2024-12-02 09:41:56 --> Language Class Initialized
INFO - 2024-12-02 09:41:56 --> Loader Class Initialized
INFO - 2024-12-02 09:41:56 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:56 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:56 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:56 --> Controller Class Initialized
INFO - 2024-12-02 09:41:56 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:56 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:56 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:56 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 09:41:56 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:56 --> Total execution time: 0.1242
INFO - 2024-12-02 09:41:59 --> Config Class Initialized
INFO - 2024-12-02 09:41:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:59 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:59 --> URI Class Initialized
INFO - 2024-12-02 09:41:59 --> Router Class Initialized
INFO - 2024-12-02 09:41:59 --> Output Class Initialized
INFO - 2024-12-02 09:41:59 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:59 --> CSRF cookie sent
INFO - 2024-12-02 09:41:59 --> CSRF token verified
INFO - 2024-12-02 09:41:59 --> Input Class Initialized
INFO - 2024-12-02 09:41:59 --> Language Class Initialized
INFO - 2024-12-02 09:41:59 --> Loader Class Initialized
INFO - 2024-12-02 09:41:59 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:59 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:59 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:59 --> Controller Class Initialized
INFO - 2024-12-02 09:41:59 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:59 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:59 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:59 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:59 --> Config Class Initialized
INFO - 2024-12-02 09:41:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:59 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:59 --> URI Class Initialized
INFO - 2024-12-02 09:41:59 --> Router Class Initialized
INFO - 2024-12-02 09:41:59 --> Output Class Initialized
INFO - 2024-12-02 09:41:59 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:59 --> CSRF cookie sent
INFO - 2024-12-02 09:41:59 --> Input Class Initialized
INFO - 2024-12-02 09:41:59 --> Language Class Initialized
INFO - 2024-12-02 09:41:59 --> Loader Class Initialized
INFO - 2024-12-02 09:41:59 --> Helper loaded: url_helper
INFO - 2024-12-02 09:41:59 --> Helper loaded: form_helper
INFO - 2024-12-02 09:41:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:41:59 --> Form Validation Class Initialized
INFO - 2024-12-02 09:41:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:41:59 --> Controller Class Initialized
INFO - 2024-12-02 09:41:59 --> Model "User_model" initialized
INFO - 2024-12-02 09:41:59 --> Model "Category_model" initialized
INFO - 2024-12-02 09:41:59 --> Model "Review_model" initialized
INFO - 2024-12-02 09:41:59 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:41:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:59 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:41:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:41:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:41:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:41:59 --> Final output sent to browser
DEBUG - 2024-12-02 09:41:59 --> Total execution time: 0.0827
INFO - 2024-12-02 09:41:59 --> Config Class Initialized
INFO - 2024-12-02 09:41:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:41:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:41:59 --> Utf8 Class Initialized
INFO - 2024-12-02 09:41:59 --> URI Class Initialized
INFO - 2024-12-02 09:41:59 --> Router Class Initialized
INFO - 2024-12-02 09:41:59 --> Output Class Initialized
INFO - 2024-12-02 09:41:59 --> Security Class Initialized
DEBUG - 2024-12-02 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:41:59 --> CSRF cookie sent
INFO - 2024-12-02 09:41:59 --> Input Class Initialized
INFO - 2024-12-02 09:41:59 --> Language Class Initialized
ERROR - 2024-12-02 09:41:59 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:42:01 --> Config Class Initialized
INFO - 2024-12-02 09:42:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:01 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:01 --> URI Class Initialized
INFO - 2024-12-02 09:42:01 --> Router Class Initialized
INFO - 2024-12-02 09:42:01 --> Output Class Initialized
INFO - 2024-12-02 09:42:01 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:01 --> CSRF cookie sent
INFO - 2024-12-02 09:42:01 --> Input Class Initialized
INFO - 2024-12-02 09:42:01 --> Language Class Initialized
INFO - 2024-12-02 09:42:01 --> Loader Class Initialized
INFO - 2024-12-02 09:42:01 --> Helper loaded: url_helper
INFO - 2024-12-02 09:42:01 --> Helper loaded: form_helper
INFO - 2024-12-02 09:42:01 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:42:01 --> Form Validation Class Initialized
INFO - 2024-12-02 09:42:01 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:42:01 --> Controller Class Initialized
INFO - 2024-12-02 09:42:01 --> Model "User_model" initialized
INFO - 2024-12-02 09:42:01 --> Model "Category_model" initialized
INFO - 2024-12-02 09:42:01 --> Model "Review_model" initialized
INFO - 2024-12-02 09:42:01 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:42:01 --> Config Class Initialized
INFO - 2024-12-02 09:42:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:01 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:01 --> URI Class Initialized
INFO - 2024-12-02 09:42:01 --> Router Class Initialized
INFO - 2024-12-02 09:42:01 --> Output Class Initialized
INFO - 2024-12-02 09:42:01 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:01 --> CSRF cookie sent
INFO - 2024-12-02 09:42:01 --> Input Class Initialized
INFO - 2024-12-02 09:42:01 --> Language Class Initialized
INFO - 2024-12-02 09:42:01 --> Loader Class Initialized
INFO - 2024-12-02 09:42:01 --> Helper loaded: url_helper
INFO - 2024-12-02 09:42:01 --> Helper loaded: form_helper
INFO - 2024-12-02 09:42:01 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:42:01 --> Form Validation Class Initialized
INFO - 2024-12-02 09:42:01 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:42:01 --> Controller Class Initialized
INFO - 2024-12-02 09:42:01 --> Model "User_model" initialized
INFO - 2024-12-02 09:42:01 --> Model "Category_model" initialized
INFO - 2024-12-02 09:42:01 --> Model "Review_model" initialized
INFO - 2024-12-02 09:42:01 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:42:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:42:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:42:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 09:42:01 --> Final output sent to browser
DEBUG - 2024-12-02 09:42:01 --> Total execution time: 0.0782
INFO - 2024-12-02 09:42:03 --> Config Class Initialized
INFO - 2024-12-02 09:42:03 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:03 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:03 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:03 --> URI Class Initialized
INFO - 2024-12-02 09:42:03 --> Router Class Initialized
INFO - 2024-12-02 09:42:03 --> Output Class Initialized
INFO - 2024-12-02 09:42:03 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:03 --> CSRF cookie sent
INFO - 2024-12-02 09:42:03 --> Input Class Initialized
INFO - 2024-12-02 09:42:03 --> Language Class Initialized
INFO - 2024-12-02 09:42:03 --> Loader Class Initialized
INFO - 2024-12-02 09:42:03 --> Helper loaded: url_helper
INFO - 2024-12-02 09:42:03 --> Helper loaded: form_helper
INFO - 2024-12-02 09:42:03 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:42:03 --> Form Validation Class Initialized
INFO - 2024-12-02 09:42:03 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:42:03 --> Controller Class Initialized
INFO - 2024-12-02 09:42:03 --> Model "Category_model" initialized
INFO - 2024-12-02 09:42:03 --> Model "User_model" initialized
INFO - 2024-12-02 09:42:03 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 09:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:42:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:42:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:42:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 09:42:03 --> Final output sent to browser
DEBUG - 2024-12-02 09:42:03 --> Total execution time: 0.0703
INFO - 2024-12-02 09:42:14 --> Config Class Initialized
INFO - 2024-12-02 09:42:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:14 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:14 --> URI Class Initialized
INFO - 2024-12-02 09:42:14 --> Router Class Initialized
INFO - 2024-12-02 09:42:14 --> Output Class Initialized
INFO - 2024-12-02 09:42:14 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:14 --> CSRF cookie sent
INFO - 2024-12-02 09:42:14 --> Input Class Initialized
INFO - 2024-12-02 09:42:14 --> Language Class Initialized
INFO - 2024-12-02 09:42:14 --> Loader Class Initialized
INFO - 2024-12-02 09:42:14 --> Helper loaded: url_helper
INFO - 2024-12-02 09:42:14 --> Helper loaded: form_helper
INFO - 2024-12-02 09:42:14 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:42:14 --> Form Validation Class Initialized
INFO - 2024-12-02 09:42:14 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:42:14 --> Controller Class Initialized
INFO - 2024-12-02 09:42:14 --> Model "User_model" initialized
INFO - 2024-12-02 09:42:14 --> Model "Category_model" initialized
INFO - 2024-12-02 09:42:14 --> Model "Review_model" initialized
INFO - 2024-12-02 09:42:14 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:42:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:42:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:42:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:42:14 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:42:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:42:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:42:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:42:14 --> Final output sent to browser
DEBUG - 2024-12-02 09:42:14 --> Total execution time: 0.0739
INFO - 2024-12-02 09:42:15 --> Config Class Initialized
INFO - 2024-12-02 09:42:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:15 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:15 --> URI Class Initialized
INFO - 2024-12-02 09:42:15 --> Router Class Initialized
INFO - 2024-12-02 09:42:15 --> Output Class Initialized
INFO - 2024-12-02 09:42:15 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:15 --> CSRF cookie sent
INFO - 2024-12-02 09:42:15 --> Input Class Initialized
INFO - 2024-12-02 09:42:15 --> Language Class Initialized
ERROR - 2024-12-02 09:42:15 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:42:15 --> Config Class Initialized
INFO - 2024-12-02 09:42:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:15 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:15 --> URI Class Initialized
INFO - 2024-12-02 09:42:15 --> Router Class Initialized
INFO - 2024-12-02 09:42:15 --> Output Class Initialized
INFO - 2024-12-02 09:42:15 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:15 --> CSRF cookie sent
INFO - 2024-12-02 09:42:15 --> Input Class Initialized
INFO - 2024-12-02 09:42:15 --> Language Class Initialized
INFO - 2024-12-02 09:42:15 --> Loader Class Initialized
INFO - 2024-12-02 09:42:15 --> Helper loaded: url_helper
INFO - 2024-12-02 09:42:15 --> Helper loaded: form_helper
INFO - 2024-12-02 09:42:15 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:42:15 --> Form Validation Class Initialized
INFO - 2024-12-02 09:42:15 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:42:15 --> Controller Class Initialized
INFO - 2024-12-02 09:42:15 --> Model "User_model" initialized
INFO - 2024-12-02 09:42:15 --> Model "Category_model" initialized
INFO - 2024-12-02 09:42:15 --> Model "Review_model" initialized
INFO - 2024-12-02 09:42:15 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:42:15 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:42:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:42:15 --> Final output sent to browser
DEBUG - 2024-12-02 09:42:15 --> Total execution time: 0.0591
INFO - 2024-12-02 09:42:15 --> Config Class Initialized
INFO - 2024-12-02 09:42:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:42:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:42:15 --> Utf8 Class Initialized
INFO - 2024-12-02 09:42:15 --> URI Class Initialized
INFO - 2024-12-02 09:42:15 --> Router Class Initialized
INFO - 2024-12-02 09:42:15 --> Output Class Initialized
INFO - 2024-12-02 09:42:15 --> Security Class Initialized
DEBUG - 2024-12-02 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:42:15 --> CSRF cookie sent
INFO - 2024-12-02 09:42:15 --> Input Class Initialized
INFO - 2024-12-02 09:42:15 --> Language Class Initialized
ERROR - 2024-12-02 09:42:15 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:44:46 --> Config Class Initialized
INFO - 2024-12-02 09:44:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:46 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:46 --> URI Class Initialized
INFO - 2024-12-02 09:44:46 --> Router Class Initialized
INFO - 2024-12-02 09:44:46 --> Output Class Initialized
INFO - 2024-12-02 09:44:46 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:46 --> CSRF cookie sent
INFO - 2024-12-02 09:44:46 --> Input Class Initialized
INFO - 2024-12-02 09:44:46 --> Language Class Initialized
INFO - 2024-12-02 09:44:46 --> Loader Class Initialized
INFO - 2024-12-02 09:44:46 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:46 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:46 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:46 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:46 --> Controller Class Initialized
INFO - 2024-12-02 09:44:46 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:46 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:46 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:46 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:47 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:44:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:47 --> Final output sent to browser
DEBUG - 2024-12-02 09:44:47 --> Total execution time: 0.6161
INFO - 2024-12-02 09:44:48 --> Config Class Initialized
INFO - 2024-12-02 09:44:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:48 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:48 --> URI Class Initialized
INFO - 2024-12-02 09:44:48 --> Router Class Initialized
INFO - 2024-12-02 09:44:48 --> Output Class Initialized
INFO - 2024-12-02 09:44:48 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:48 --> CSRF cookie sent
INFO - 2024-12-02 09:44:48 --> Input Class Initialized
INFO - 2024-12-02 09:44:48 --> Language Class Initialized
INFO - 2024-12-02 09:44:48 --> Loader Class Initialized
INFO - 2024-12-02 09:44:48 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:48 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:48 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:48 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:48 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:48 --> Controller Class Initialized
INFO - 2024-12-02 09:44:48 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:48 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:48 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:48 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:48 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:44:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:49 --> Final output sent to browser
DEBUG - 2024-12-02 09:44:49 --> Total execution time: 0.1901
INFO - 2024-12-02 09:44:49 --> Config Class Initialized
INFO - 2024-12-02 09:44:49 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:49 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:49 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:49 --> URI Class Initialized
INFO - 2024-12-02 09:44:49 --> Router Class Initialized
INFO - 2024-12-02 09:44:49 --> Output Class Initialized
INFO - 2024-12-02 09:44:49 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:49 --> CSRF cookie sent
INFO - 2024-12-02 09:44:49 --> Input Class Initialized
INFO - 2024-12-02 09:44:49 --> Language Class Initialized
ERROR - 2024-12-02 09:44:49 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:44:53 --> Config Class Initialized
INFO - 2024-12-02 09:44:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:53 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:53 --> URI Class Initialized
INFO - 2024-12-02 09:44:53 --> Router Class Initialized
INFO - 2024-12-02 09:44:53 --> Output Class Initialized
INFO - 2024-12-02 09:44:53 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:53 --> CSRF cookie sent
INFO - 2024-12-02 09:44:53 --> Input Class Initialized
INFO - 2024-12-02 09:44:53 --> Language Class Initialized
INFO - 2024-12-02 09:44:53 --> Loader Class Initialized
INFO - 2024-12-02 09:44:53 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:53 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:54 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:54 --> Controller Class Initialized
INFO - 2024-12-02 09:44:54 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:54 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:54 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:54 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:54 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:44:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:54 --> Final output sent to browser
DEBUG - 2024-12-02 09:44:54 --> Total execution time: 0.3138
INFO - 2024-12-02 09:44:54 --> Config Class Initialized
INFO - 2024-12-02 09:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:54 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:54 --> URI Class Initialized
INFO - 2024-12-02 09:44:54 --> Router Class Initialized
INFO - 2024-12-02 09:44:54 --> Output Class Initialized
INFO - 2024-12-02 09:44:54 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:54 --> CSRF cookie sent
INFO - 2024-12-02 09:44:54 --> Input Class Initialized
INFO - 2024-12-02 09:44:54 --> Language Class Initialized
ERROR - 2024-12-02 09:44:54 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:44:56 --> Config Class Initialized
INFO - 2024-12-02 09:44:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:56 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:56 --> URI Class Initialized
INFO - 2024-12-02 09:44:56 --> Router Class Initialized
INFO - 2024-12-02 09:44:56 --> Output Class Initialized
INFO - 2024-12-02 09:44:56 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:56 --> CSRF cookie sent
INFO - 2024-12-02 09:44:56 --> Input Class Initialized
INFO - 2024-12-02 09:44:56 --> Language Class Initialized
INFO - 2024-12-02 09:44:56 --> Loader Class Initialized
INFO - 2024-12-02 09:44:56 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:56 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:56 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:56 --> Controller Class Initialized
INFO - 2024-12-02 09:44:56 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:56 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:56 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:56 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:56 --> Config Class Initialized
INFO - 2024-12-02 09:44:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:56 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:56 --> URI Class Initialized
INFO - 2024-12-02 09:44:56 --> Router Class Initialized
INFO - 2024-12-02 09:44:56 --> Output Class Initialized
INFO - 2024-12-02 09:44:56 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:56 --> CSRF cookie sent
INFO - 2024-12-02 09:44:56 --> Input Class Initialized
INFO - 2024-12-02 09:44:56 --> Language Class Initialized
INFO - 2024-12-02 09:44:56 --> Loader Class Initialized
INFO - 2024-12-02 09:44:56 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:56 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:56 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:56 --> Controller Class Initialized
INFO - 2024-12-02 09:44:56 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:56 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:56 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:56 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 09:44:56 --> Final output sent to browser
DEBUG - 2024-12-02 09:44:56 --> Total execution time: 0.1028
INFO - 2024-12-02 09:44:59 --> Config Class Initialized
INFO - 2024-12-02 09:44:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:59 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:59 --> URI Class Initialized
INFO - 2024-12-02 09:44:59 --> Router Class Initialized
INFO - 2024-12-02 09:44:59 --> Output Class Initialized
INFO - 2024-12-02 09:44:59 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:59 --> CSRF cookie sent
INFO - 2024-12-02 09:44:59 --> CSRF token verified
INFO - 2024-12-02 09:44:59 --> Input Class Initialized
INFO - 2024-12-02 09:44:59 --> Language Class Initialized
INFO - 2024-12-02 09:44:59 --> Loader Class Initialized
INFO - 2024-12-02 09:44:59 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:59 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:59 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:59 --> Controller Class Initialized
INFO - 2024-12-02 09:44:59 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:59 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:59 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:59 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:59 --> Config Class Initialized
INFO - 2024-12-02 09:44:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:44:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:44:59 --> Utf8 Class Initialized
INFO - 2024-12-02 09:44:59 --> URI Class Initialized
INFO - 2024-12-02 09:44:59 --> Router Class Initialized
INFO - 2024-12-02 09:44:59 --> Output Class Initialized
INFO - 2024-12-02 09:44:59 --> Security Class Initialized
DEBUG - 2024-12-02 09:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:44:59 --> CSRF cookie sent
INFO - 2024-12-02 09:44:59 --> Input Class Initialized
INFO - 2024-12-02 09:44:59 --> Language Class Initialized
INFO - 2024-12-02 09:44:59 --> Loader Class Initialized
INFO - 2024-12-02 09:44:59 --> Helper loaded: url_helper
INFO - 2024-12-02 09:44:59 --> Helper loaded: form_helper
INFO - 2024-12-02 09:44:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:44:59 --> Form Validation Class Initialized
INFO - 2024-12-02 09:44:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:44:59 --> Controller Class Initialized
INFO - 2024-12-02 09:44:59 --> Model "User_model" initialized
INFO - 2024-12-02 09:44:59 --> Model "Category_model" initialized
INFO - 2024-12-02 09:44:59 --> Model "Review_model" initialized
INFO - 2024-12-02 09:44:59 --> Model "News_model" initialized
DEBUG - 2024-12-02 09:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:44:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:44:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:44:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:44:59 --> Model "PageView_model" initialized
INFO - 2024-12-02 09:45:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:45:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:45:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:45:00 --> Final output sent to browser
DEBUG - 2024-12-02 09:45:00 --> Total execution time: 0.0681
INFO - 2024-12-02 09:45:00 --> Config Class Initialized
INFO - 2024-12-02 09:45:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:45:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:45:00 --> Utf8 Class Initialized
INFO - 2024-12-02 09:45:00 --> URI Class Initialized
INFO - 2024-12-02 09:45:00 --> Router Class Initialized
INFO - 2024-12-02 09:45:00 --> Output Class Initialized
INFO - 2024-12-02 09:45:00 --> Security Class Initialized
DEBUG - 2024-12-02 09:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:45:00 --> CSRF cookie sent
INFO - 2024-12-02 09:45:00 --> Input Class Initialized
INFO - 2024-12-02 09:45:00 --> Language Class Initialized
ERROR - 2024-12-02 09:45:00 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:52:32 --> Config Class Initialized
INFO - 2024-12-02 09:52:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:32 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:32 --> URI Class Initialized
INFO - 2024-12-02 09:52:32 --> Router Class Initialized
INFO - 2024-12-02 09:52:32 --> Output Class Initialized
INFO - 2024-12-02 09:52:32 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:32 --> CSRF cookie sent
INFO - 2024-12-02 09:52:32 --> Input Class Initialized
INFO - 2024-12-02 09:52:32 --> Language Class Initialized
INFO - 2024-12-02 09:52:33 --> Loader Class Initialized
INFO - 2024-12-02 09:52:33 --> Helper loaded: url_helper
INFO - 2024-12-02 09:52:33 --> Helper loaded: form_helper
INFO - 2024-12-02 09:52:33 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:52:33 --> Form Validation Class Initialized
INFO - 2024-12-02 09:52:33 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:52:33 --> Controller Class Initialized
INFO - 2024-12-02 09:52:33 --> Model "User_model" initialized
INFO - 2024-12-02 09:52:33 --> Model "Category_model" initialized
INFO - 2024-12-02 09:52:33 --> Model "Review_model" initialized
INFO - 2024-12-02 09:52:33 --> Model "News_model" initialized
INFO - 2024-12-02 09:52:33 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:52:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:52:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:52:33 --> View count: 12
INFO - 2024-12-02 09:52:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:52:33 --> Final output sent to browser
DEBUG - 2024-12-02 09:52:33 --> Total execution time: 0.5817
INFO - 2024-12-02 09:52:34 --> Config Class Initialized
INFO - 2024-12-02 09:52:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:34 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:34 --> URI Class Initialized
INFO - 2024-12-02 09:52:34 --> Router Class Initialized
INFO - 2024-12-02 09:52:34 --> Output Class Initialized
INFO - 2024-12-02 09:52:34 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:34 --> CSRF cookie sent
INFO - 2024-12-02 09:52:34 --> Input Class Initialized
INFO - 2024-12-02 09:52:34 --> Language Class Initialized
ERROR - 2024-12-02 09:52:34 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:52:37 --> Config Class Initialized
INFO - 2024-12-02 09:52:37 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:37 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:37 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:37 --> URI Class Initialized
INFO - 2024-12-02 09:52:37 --> Router Class Initialized
INFO - 2024-12-02 09:52:37 --> Output Class Initialized
INFO - 2024-12-02 09:52:37 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:37 --> CSRF cookie sent
INFO - 2024-12-02 09:52:37 --> Input Class Initialized
INFO - 2024-12-02 09:52:37 --> Language Class Initialized
INFO - 2024-12-02 09:52:37 --> Loader Class Initialized
INFO - 2024-12-02 09:52:37 --> Helper loaded: url_helper
INFO - 2024-12-02 09:52:37 --> Helper loaded: form_helper
INFO - 2024-12-02 09:52:37 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:52:37 --> Form Validation Class Initialized
INFO - 2024-12-02 09:52:37 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:52:37 --> Controller Class Initialized
INFO - 2024-12-02 09:52:37 --> Model "User_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "Category_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "Review_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "News_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:52:37 --> View count: 13
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:52:37 --> Final output sent to browser
DEBUG - 2024-12-02 09:52:37 --> Total execution time: 0.0985
INFO - 2024-12-02 09:52:37 --> Config Class Initialized
INFO - 2024-12-02 09:52:37 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:37 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:37 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:37 --> URI Class Initialized
INFO - 2024-12-02 09:52:37 --> Router Class Initialized
INFO - 2024-12-02 09:52:37 --> Output Class Initialized
INFO - 2024-12-02 09:52:37 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:37 --> CSRF cookie sent
INFO - 2024-12-02 09:52:37 --> Input Class Initialized
INFO - 2024-12-02 09:52:37 --> Language Class Initialized
ERROR - 2024-12-02 09:52:37 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:52:37 --> Config Class Initialized
INFO - 2024-12-02 09:52:37 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:37 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:37 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:37 --> URI Class Initialized
INFO - 2024-12-02 09:52:37 --> Router Class Initialized
INFO - 2024-12-02 09:52:37 --> Output Class Initialized
INFO - 2024-12-02 09:52:37 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:37 --> CSRF cookie sent
INFO - 2024-12-02 09:52:37 --> Input Class Initialized
INFO - 2024-12-02 09:52:37 --> Language Class Initialized
INFO - 2024-12-02 09:52:37 --> Loader Class Initialized
INFO - 2024-12-02 09:52:37 --> Helper loaded: url_helper
INFO - 2024-12-02 09:52:37 --> Helper loaded: form_helper
INFO - 2024-12-02 09:52:37 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:52:37 --> Form Validation Class Initialized
INFO - 2024-12-02 09:52:37 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:52:37 --> Controller Class Initialized
INFO - 2024-12-02 09:52:37 --> Model "User_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "Category_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "Review_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "News_model" initialized
INFO - 2024-12-02 09:52:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:52:37 --> View count: 14
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:52:37 --> Final output sent to browser
DEBUG - 2024-12-02 09:52:37 --> Total execution time: 0.0667
INFO - 2024-12-02 09:52:38 --> Config Class Initialized
INFO - 2024-12-02 09:52:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:38 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:38 --> URI Class Initialized
INFO - 2024-12-02 09:52:38 --> Router Class Initialized
INFO - 2024-12-02 09:52:38 --> Output Class Initialized
INFO - 2024-12-02 09:52:38 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:38 --> CSRF cookie sent
INFO - 2024-12-02 09:52:38 --> Input Class Initialized
INFO - 2024-12-02 09:52:38 --> Language Class Initialized
ERROR - 2024-12-02 09:52:38 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:52:38 --> Config Class Initialized
INFO - 2024-12-02 09:52:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:38 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:38 --> URI Class Initialized
INFO - 2024-12-02 09:52:38 --> Router Class Initialized
INFO - 2024-12-02 09:52:38 --> Output Class Initialized
INFO - 2024-12-02 09:52:38 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:38 --> CSRF cookie sent
INFO - 2024-12-02 09:52:38 --> Input Class Initialized
INFO - 2024-12-02 09:52:38 --> Language Class Initialized
INFO - 2024-12-02 09:52:38 --> Loader Class Initialized
INFO - 2024-12-02 09:52:38 --> Helper loaded: url_helper
INFO - 2024-12-02 09:52:38 --> Helper loaded: form_helper
INFO - 2024-12-02 09:52:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:52:38 --> Form Validation Class Initialized
INFO - 2024-12-02 09:52:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:52:38 --> Controller Class Initialized
INFO - 2024-12-02 09:52:38 --> Model "User_model" initialized
INFO - 2024-12-02 09:52:38 --> Model "Category_model" initialized
INFO - 2024-12-02 09:52:38 --> Model "Review_model" initialized
INFO - 2024-12-02 09:52:38 --> Model "News_model" initialized
INFO - 2024-12-02 09:52:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:52:38 --> View count: 15
INFO - 2024-12-02 09:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:52:38 --> Final output sent to browser
DEBUG - 2024-12-02 09:52:38 --> Total execution time: 0.1075
INFO - 2024-12-02 09:52:38 --> Config Class Initialized
INFO - 2024-12-02 09:52:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:52:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:52:38 --> Utf8 Class Initialized
INFO - 2024-12-02 09:52:38 --> URI Class Initialized
INFO - 2024-12-02 09:52:38 --> Router Class Initialized
INFO - 2024-12-02 09:52:38 --> Output Class Initialized
INFO - 2024-12-02 09:52:38 --> Security Class Initialized
DEBUG - 2024-12-02 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:52:38 --> CSRF cookie sent
INFO - 2024-12-02 09:52:38 --> Input Class Initialized
INFO - 2024-12-02 09:52:38 --> Language Class Initialized
ERROR - 2024-12-02 09:52:38 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:54:59 --> Config Class Initialized
INFO - 2024-12-02 09:54:59 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:54:59 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:54:59 --> Utf8 Class Initialized
INFO - 2024-12-02 09:54:59 --> URI Class Initialized
INFO - 2024-12-02 09:54:59 --> Router Class Initialized
INFO - 2024-12-02 09:54:59 --> Output Class Initialized
INFO - 2024-12-02 09:54:59 --> Security Class Initialized
DEBUG - 2024-12-02 09:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:54:59 --> CSRF cookie sent
INFO - 2024-12-02 09:54:59 --> Input Class Initialized
INFO - 2024-12-02 09:54:59 --> Language Class Initialized
INFO - 2024-12-02 09:54:59 --> Loader Class Initialized
INFO - 2024-12-02 09:54:59 --> Helper loaded: url_helper
INFO - 2024-12-02 09:54:59 --> Helper loaded: form_helper
INFO - 2024-12-02 09:54:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:54:59 --> Form Validation Class Initialized
INFO - 2024-12-02 09:54:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:54:59 --> Controller Class Initialized
INFO - 2024-12-02 09:54:59 --> Model "User_model" initialized
INFO - 2024-12-02 09:54:59 --> Model "Category_model" initialized
INFO - 2024-12-02 09:54:59 --> Model "Review_model" initialized
INFO - 2024-12-02 09:54:59 --> Model "News_model" initialized
INFO - 2024-12-02 09:54:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:54:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:54:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:54:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:54:59 --> Query result: stdClass Object
(
    [view_count] => 16
)

DEBUG - 2024-12-02 09:54:59 --> View count: 16
INFO - 2024-12-02 09:54:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:54:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:54:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:54:59 --> Final output sent to browser
DEBUG - 2024-12-02 09:54:59 --> Total execution time: 0.5997
INFO - 2024-12-02 09:55:00 --> Config Class Initialized
INFO - 2024-12-02 09:55:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:00 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:00 --> URI Class Initialized
INFO - 2024-12-02 09:55:00 --> Router Class Initialized
INFO - 2024-12-02 09:55:00 --> Output Class Initialized
INFO - 2024-12-02 09:55:00 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:00 --> CSRF cookie sent
INFO - 2024-12-02 09:55:00 --> Input Class Initialized
INFO - 2024-12-02 09:55:00 --> Language Class Initialized
ERROR - 2024-12-02 09:55:00 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:55:03 --> Config Class Initialized
INFO - 2024-12-02 09:55:03 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:03 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:03 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:03 --> URI Class Initialized
INFO - 2024-12-02 09:55:03 --> Router Class Initialized
INFO - 2024-12-02 09:55:03 --> Output Class Initialized
INFO - 2024-12-02 09:55:03 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:03 --> CSRF cookie sent
INFO - 2024-12-02 09:55:03 --> Input Class Initialized
INFO - 2024-12-02 09:55:03 --> Language Class Initialized
INFO - 2024-12-02 09:55:03 --> Loader Class Initialized
INFO - 2024-12-02 09:55:03 --> Helper loaded: url_helper
INFO - 2024-12-02 09:55:03 --> Helper loaded: form_helper
INFO - 2024-12-02 09:55:04 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:55:04 --> Form Validation Class Initialized
INFO - 2024-12-02 09:55:04 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:55:04 --> Controller Class Initialized
INFO - 2024-12-02 09:55:04 --> Model "User_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "Category_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "Review_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "News_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:55:04 --> Query result: stdClass Object
(
    [view_count] => 17
)

DEBUG - 2024-12-02 09:55:04 --> View count: 17
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:55:04 --> Final output sent to browser
DEBUG - 2024-12-02 09:55:04 --> Total execution time: 0.1505
INFO - 2024-12-02 09:55:04 --> Config Class Initialized
INFO - 2024-12-02 09:55:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:04 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:04 --> URI Class Initialized
INFO - 2024-12-02 09:55:04 --> Router Class Initialized
INFO - 2024-12-02 09:55:04 --> Output Class Initialized
INFO - 2024-12-02 09:55:04 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:04 --> CSRF cookie sent
INFO - 2024-12-02 09:55:04 --> Input Class Initialized
INFO - 2024-12-02 09:55:04 --> Language Class Initialized
ERROR - 2024-12-02 09:55:04 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:55:04 --> Config Class Initialized
INFO - 2024-12-02 09:55:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:04 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:04 --> URI Class Initialized
INFO - 2024-12-02 09:55:04 --> Router Class Initialized
INFO - 2024-12-02 09:55:04 --> Output Class Initialized
INFO - 2024-12-02 09:55:04 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:04 --> CSRF cookie sent
INFO - 2024-12-02 09:55:04 --> Input Class Initialized
INFO - 2024-12-02 09:55:04 --> Language Class Initialized
INFO - 2024-12-02 09:55:04 --> Loader Class Initialized
INFO - 2024-12-02 09:55:04 --> Helper loaded: url_helper
INFO - 2024-12-02 09:55:04 --> Helper loaded: form_helper
INFO - 2024-12-02 09:55:04 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:55:04 --> Form Validation Class Initialized
INFO - 2024-12-02 09:55:04 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:55:04 --> Controller Class Initialized
INFO - 2024-12-02 09:55:04 --> Model "User_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "Category_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "Review_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "News_model" initialized
INFO - 2024-12-02 09:55:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:55:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:55:05 --> Query result: stdClass Object
(
    [view_count] => 18
)

DEBUG - 2024-12-02 09:55:05 --> View count: 18
INFO - 2024-12-02 09:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:55:05 --> Final output sent to browser
DEBUG - 2024-12-02 09:55:05 --> Total execution time: 0.0888
INFO - 2024-12-02 09:55:05 --> Config Class Initialized
INFO - 2024-12-02 09:55:05 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:05 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:05 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:05 --> URI Class Initialized
INFO - 2024-12-02 09:55:05 --> Router Class Initialized
INFO - 2024-12-02 09:55:05 --> Output Class Initialized
INFO - 2024-12-02 09:55:05 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:05 --> CSRF cookie sent
INFO - 2024-12-02 09:55:05 --> Input Class Initialized
INFO - 2024-12-02 09:55:05 --> Language Class Initialized
ERROR - 2024-12-02 09:55:05 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:55:09 --> Config Class Initialized
INFO - 2024-12-02 09:55:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:09 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:09 --> URI Class Initialized
INFO - 2024-12-02 09:55:09 --> Router Class Initialized
INFO - 2024-12-02 09:55:09 --> Output Class Initialized
INFO - 2024-12-02 09:55:09 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:09 --> CSRF cookie sent
INFO - 2024-12-02 09:55:09 --> Input Class Initialized
INFO - 2024-12-02 09:55:09 --> Language Class Initialized
INFO - 2024-12-02 09:55:09 --> Loader Class Initialized
INFO - 2024-12-02 09:55:09 --> Helper loaded: url_helper
INFO - 2024-12-02 09:55:09 --> Helper loaded: form_helper
INFO - 2024-12-02 09:55:09 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:55:09 --> Form Validation Class Initialized
INFO - 2024-12-02 09:55:09 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:55:09 --> Controller Class Initialized
INFO - 2024-12-02 09:55:09 --> Model "User_model" initialized
INFO - 2024-12-02 09:55:09 --> Model "Category_model" initialized
INFO - 2024-12-02 09:55:09 --> Model "Review_model" initialized
INFO - 2024-12-02 09:55:09 --> Model "News_model" initialized
INFO - 2024-12-02 09:55:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:55:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:55:09 --> Query result: stdClass Object
(
    [view_count] => 19
)

DEBUG - 2024-12-02 09:55:09 --> View count: 19
INFO - 2024-12-02 09:55:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:55:09 --> Final output sent to browser
DEBUG - 2024-12-02 09:55:09 --> Total execution time: 0.0831
INFO - 2024-12-02 09:55:10 --> Config Class Initialized
INFO - 2024-12-02 09:55:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:10 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:10 --> URI Class Initialized
INFO - 2024-12-02 09:55:10 --> Router Class Initialized
INFO - 2024-12-02 09:55:10 --> Output Class Initialized
INFO - 2024-12-02 09:55:10 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:10 --> CSRF cookie sent
INFO - 2024-12-02 09:55:10 --> Input Class Initialized
INFO - 2024-12-02 09:55:10 --> Language Class Initialized
ERROR - 2024-12-02 09:55:10 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:55:10 --> Config Class Initialized
INFO - 2024-12-02 09:55:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:10 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:10 --> URI Class Initialized
INFO - 2024-12-02 09:55:10 --> Router Class Initialized
INFO - 2024-12-02 09:55:10 --> Output Class Initialized
INFO - 2024-12-02 09:55:10 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:10 --> CSRF cookie sent
INFO - 2024-12-02 09:55:10 --> Input Class Initialized
INFO - 2024-12-02 09:55:10 --> Language Class Initialized
INFO - 2024-12-02 09:55:10 --> Loader Class Initialized
INFO - 2024-12-02 09:55:10 --> Helper loaded: url_helper
INFO - 2024-12-02 09:55:10 --> Helper loaded: form_helper
INFO - 2024-12-02 09:55:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:55:10 --> Form Validation Class Initialized
INFO - 2024-12-02 09:55:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:55:10 --> Controller Class Initialized
INFO - 2024-12-02 09:55:10 --> Model "User_model" initialized
INFO - 2024-12-02 09:55:10 --> Model "Category_model" initialized
INFO - 2024-12-02 09:55:10 --> Model "Review_model" initialized
INFO - 2024-12-02 09:55:10 --> Model "News_model" initialized
INFO - 2024-12-02 09:55:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:55:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:55:10 --> Query result: stdClass Object
(
    [view_count] => 20
)

DEBUG - 2024-12-02 09:55:10 --> View count: 20
INFO - 2024-12-02 09:55:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:55:10 --> Final output sent to browser
DEBUG - 2024-12-02 09:55:10 --> Total execution time: 0.0950
INFO - 2024-12-02 09:55:10 --> Config Class Initialized
INFO - 2024-12-02 09:55:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:10 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:10 --> URI Class Initialized
INFO - 2024-12-02 09:55:10 --> Router Class Initialized
INFO - 2024-12-02 09:55:10 --> Output Class Initialized
INFO - 2024-12-02 09:55:10 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:10 --> CSRF cookie sent
INFO - 2024-12-02 09:55:10 --> Input Class Initialized
INFO - 2024-12-02 09:55:10 --> Language Class Initialized
ERROR - 2024-12-02 09:55:10 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:55:10 --> Config Class Initialized
INFO - 2024-12-02 09:55:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:10 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:10 --> URI Class Initialized
INFO - 2024-12-02 09:55:10 --> Router Class Initialized
INFO - 2024-12-02 09:55:10 --> Output Class Initialized
INFO - 2024-12-02 09:55:10 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:10 --> CSRF cookie sent
INFO - 2024-12-02 09:55:10 --> Input Class Initialized
INFO - 2024-12-02 09:55:10 --> Language Class Initialized
INFO - 2024-12-02 09:55:10 --> Loader Class Initialized
INFO - 2024-12-02 09:55:10 --> Helper loaded: url_helper
INFO - 2024-12-02 09:55:10 --> Helper loaded: form_helper
INFO - 2024-12-02 09:55:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:55:11 --> Form Validation Class Initialized
INFO - 2024-12-02 09:55:11 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:55:11 --> Controller Class Initialized
INFO - 2024-12-02 09:55:11 --> Model "User_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "Category_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "Review_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "News_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:55:11 --> Query result: stdClass Object
(
    [view_count] => 21
)

DEBUG - 2024-12-02 09:55:11 --> View count: 21
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:55:11 --> Final output sent to browser
DEBUG - 2024-12-02 09:55:11 --> Total execution time: 0.1269
INFO - 2024-12-02 09:55:11 --> Config Class Initialized
INFO - 2024-12-02 09:55:11 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:11 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:11 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:11 --> URI Class Initialized
INFO - 2024-12-02 09:55:11 --> Router Class Initialized
INFO - 2024-12-02 09:55:11 --> Output Class Initialized
INFO - 2024-12-02 09:55:11 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:11 --> CSRF cookie sent
INFO - 2024-12-02 09:55:11 --> Input Class Initialized
INFO - 2024-12-02 09:55:11 --> Language Class Initialized
ERROR - 2024-12-02 09:55:11 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 09:55:11 --> Config Class Initialized
INFO - 2024-12-02 09:55:11 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:11 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:11 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:11 --> URI Class Initialized
INFO - 2024-12-02 09:55:11 --> Router Class Initialized
INFO - 2024-12-02 09:55:11 --> Output Class Initialized
INFO - 2024-12-02 09:55:11 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:11 --> CSRF cookie sent
INFO - 2024-12-02 09:55:11 --> Input Class Initialized
INFO - 2024-12-02 09:55:11 --> Language Class Initialized
INFO - 2024-12-02 09:55:11 --> Loader Class Initialized
INFO - 2024-12-02 09:55:11 --> Helper loaded: url_helper
INFO - 2024-12-02 09:55:11 --> Helper loaded: form_helper
INFO - 2024-12-02 09:55:11 --> Database Driver Class Initialized
DEBUG - 2024-12-02 09:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 09:55:11 --> Form Validation Class Initialized
INFO - 2024-12-02 09:55:11 --> Model "Culinary_model" initialized
INFO - 2024-12-02 09:55:11 --> Controller Class Initialized
INFO - 2024-12-02 09:55:11 --> Model "User_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "Category_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "Review_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "News_model" initialized
INFO - 2024-12-02 09:55:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 09:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
DEBUG - 2024-12-02 09:55:11 --> Query result: stdClass Object
(
    [view_count] => 22
)

DEBUG - 2024-12-02 09:55:11 --> View count: 22
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 09:55:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 09:55:11 --> Final output sent to browser
DEBUG - 2024-12-02 09:55:11 --> Total execution time: 0.0985
INFO - 2024-12-02 09:55:11 --> Config Class Initialized
INFO - 2024-12-02 09:55:11 --> Hooks Class Initialized
DEBUG - 2024-12-02 09:55:11 --> UTF-8 Support Enabled
INFO - 2024-12-02 09:55:11 --> Utf8 Class Initialized
INFO - 2024-12-02 09:55:11 --> URI Class Initialized
INFO - 2024-12-02 09:55:11 --> Router Class Initialized
INFO - 2024-12-02 09:55:11 --> Output Class Initialized
INFO - 2024-12-02 09:55:11 --> Security Class Initialized
DEBUG - 2024-12-02 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 09:55:11 --> CSRF cookie sent
INFO - 2024-12-02 09:55:11 --> Input Class Initialized
INFO - 2024-12-02 09:55:11 --> Language Class Initialized
ERROR - 2024-12-02 09:55:11 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:01:41 --> Config Class Initialized
INFO - 2024-12-02 10:01:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:01:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:01:41 --> Utf8 Class Initialized
INFO - 2024-12-02 10:01:41 --> URI Class Initialized
INFO - 2024-12-02 10:01:41 --> Router Class Initialized
INFO - 2024-12-02 10:01:41 --> Output Class Initialized
INFO - 2024-12-02 10:01:41 --> Security Class Initialized
DEBUG - 2024-12-02 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:01:41 --> CSRF cookie sent
INFO - 2024-12-02 10:01:41 --> Input Class Initialized
INFO - 2024-12-02 10:01:41 --> Language Class Initialized
INFO - 2024-12-02 10:01:41 --> Loader Class Initialized
INFO - 2024-12-02 10:01:41 --> Helper loaded: url_helper
INFO - 2024-12-02 10:01:41 --> Helper loaded: form_helper
INFO - 2024-12-02 10:01:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:01:41 --> Form Validation Class Initialized
INFO - 2024-12-02 10:01:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:01:41 --> Controller Class Initialized
INFO - 2024-12-02 10:01:41 --> Model "User_model" initialized
INFO - 2024-12-02 10:01:41 --> Model "Category_model" initialized
INFO - 2024-12-02 10:01:41 --> Model "Review_model" initialized
INFO - 2024-12-02 10:01:41 --> Model "News_model" initialized
INFO - 2024-12-02 10:01:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:01:41 --> Query result: stdClass Object
(
    [view_count] => 23
)

INFO - 2024-12-02 10:01:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:01:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:01:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:01:41 --> Final output sent to browser
DEBUG - 2024-12-02 10:01:41 --> Total execution time: 0.4922
INFO - 2024-12-02 10:01:42 --> Config Class Initialized
INFO - 2024-12-02 10:01:42 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:01:42 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:01:42 --> Utf8 Class Initialized
INFO - 2024-12-02 10:01:42 --> URI Class Initialized
INFO - 2024-12-02 10:01:42 --> Router Class Initialized
INFO - 2024-12-02 10:01:42 --> Output Class Initialized
INFO - 2024-12-02 10:01:42 --> Security Class Initialized
DEBUG - 2024-12-02 10:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:01:42 --> CSRF cookie sent
INFO - 2024-12-02 10:01:42 --> Input Class Initialized
INFO - 2024-12-02 10:01:42 --> Language Class Initialized
ERROR - 2024-12-02 10:01:42 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:33:47 --> Config Class Initialized
INFO - 2024-12-02 10:33:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:47 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:47 --> URI Class Initialized
INFO - 2024-12-02 10:33:47 --> Router Class Initialized
INFO - 2024-12-02 10:33:47 --> Output Class Initialized
INFO - 2024-12-02 10:33:47 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:47 --> CSRF cookie sent
INFO - 2024-12-02 10:33:47 --> Input Class Initialized
INFO - 2024-12-02 10:33:47 --> Language Class Initialized
INFO - 2024-12-02 10:33:47 --> Loader Class Initialized
INFO - 2024-12-02 10:33:47 --> Helper loaded: url_helper
INFO - 2024-12-02 10:33:47 --> Helper loaded: form_helper
INFO - 2024-12-02 10:33:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:33:47 --> Form Validation Class Initialized
INFO - 2024-12-02 10:33:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:33:47 --> Controller Class Initialized
INFO - 2024-12-02 10:33:47 --> Model "User_model" initialized
INFO - 2024-12-02 10:33:47 --> Model "Category_model" initialized
INFO - 2024-12-02 10:33:47 --> Model "Review_model" initialized
INFO - 2024-12-02 10:33:47 --> Model "News_model" initialized
INFO - 2024-12-02 10:33:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:33:47 --> Query result: stdClass Object
(
    [view_count] => 24
)

INFO - 2024-12-02 10:33:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:33:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:33:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:33:47 --> Final output sent to browser
DEBUG - 2024-12-02 10:33:47 --> Total execution time: 0.5669
INFO - 2024-12-02 10:33:48 --> Config Class Initialized
INFO - 2024-12-02 10:33:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:48 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:48 --> URI Class Initialized
INFO - 2024-12-02 10:33:48 --> Router Class Initialized
INFO - 2024-12-02 10:33:48 --> Output Class Initialized
INFO - 2024-12-02 10:33:48 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:48 --> CSRF cookie sent
INFO - 2024-12-02 10:33:48 --> Input Class Initialized
INFO - 2024-12-02 10:33:48 --> Language Class Initialized
ERROR - 2024-12-02 10:33:48 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:33:57 --> Config Class Initialized
INFO - 2024-12-02 10:33:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:57 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:57 --> URI Class Initialized
INFO - 2024-12-02 10:33:57 --> Router Class Initialized
INFO - 2024-12-02 10:33:57 --> Output Class Initialized
INFO - 2024-12-02 10:33:57 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:57 --> CSRF cookie sent
INFO - 2024-12-02 10:33:57 --> Input Class Initialized
INFO - 2024-12-02 10:33:57 --> Language Class Initialized
INFO - 2024-12-02 10:33:57 --> Loader Class Initialized
INFO - 2024-12-02 10:33:57 --> Helper loaded: url_helper
INFO - 2024-12-02 10:33:57 --> Helper loaded: form_helper
INFO - 2024-12-02 10:33:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:33:57 --> Form Validation Class Initialized
INFO - 2024-12-02 10:33:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:33:57 --> Controller Class Initialized
INFO - 2024-12-02 10:33:57 --> Model "User_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "Category_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "Review_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "News_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:33:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:33:57 --> Query result: stdClass Object
(
    [view_count] => 25
)

INFO - 2024-12-02 10:33:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:33:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:33:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:33:57 --> Final output sent to browser
DEBUG - 2024-12-02 10:33:57 --> Total execution time: 0.0907
INFO - 2024-12-02 10:33:57 --> Config Class Initialized
INFO - 2024-12-02 10:33:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:57 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:57 --> URI Class Initialized
INFO - 2024-12-02 10:33:57 --> Router Class Initialized
INFO - 2024-12-02 10:33:57 --> Output Class Initialized
INFO - 2024-12-02 10:33:57 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:57 --> CSRF cookie sent
INFO - 2024-12-02 10:33:57 --> Input Class Initialized
INFO - 2024-12-02 10:33:57 --> Language Class Initialized
ERROR - 2024-12-02 10:33:57 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:33:57 --> Config Class Initialized
INFO - 2024-12-02 10:33:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:57 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:57 --> URI Class Initialized
INFO - 2024-12-02 10:33:57 --> Router Class Initialized
INFO - 2024-12-02 10:33:57 --> Output Class Initialized
INFO - 2024-12-02 10:33:57 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:57 --> CSRF cookie sent
INFO - 2024-12-02 10:33:57 --> Input Class Initialized
INFO - 2024-12-02 10:33:57 --> Language Class Initialized
INFO - 2024-12-02 10:33:57 --> Loader Class Initialized
INFO - 2024-12-02 10:33:57 --> Helper loaded: url_helper
INFO - 2024-12-02 10:33:57 --> Helper loaded: form_helper
INFO - 2024-12-02 10:33:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:33:57 --> Form Validation Class Initialized
INFO - 2024-12-02 10:33:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:33:57 --> Controller Class Initialized
INFO - 2024-12-02 10:33:57 --> Model "User_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "Category_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "Review_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "News_model" initialized
INFO - 2024-12-02 10:33:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:33:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:33:57 --> Query result: stdClass Object
(
    [view_count] => 26
)

INFO - 2024-12-02 10:33:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:33:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:33:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:33:57 --> Final output sent to browser
DEBUG - 2024-12-02 10:33:57 --> Total execution time: 0.0834
INFO - 2024-12-02 10:33:57 --> Config Class Initialized
INFO - 2024-12-02 10:33:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:57 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:57 --> URI Class Initialized
INFO - 2024-12-02 10:33:57 --> Router Class Initialized
INFO - 2024-12-02 10:33:57 --> Output Class Initialized
INFO - 2024-12-02 10:33:57 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:57 --> CSRF cookie sent
INFO - 2024-12-02 10:33:57 --> Input Class Initialized
INFO - 2024-12-02 10:33:57 --> Language Class Initialized
ERROR - 2024-12-02 10:33:57 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:33:58 --> Config Class Initialized
INFO - 2024-12-02 10:33:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:58 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:58 --> URI Class Initialized
INFO - 2024-12-02 10:33:58 --> Router Class Initialized
INFO - 2024-12-02 10:33:58 --> Output Class Initialized
INFO - 2024-12-02 10:33:58 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:58 --> CSRF cookie sent
INFO - 2024-12-02 10:33:58 --> Input Class Initialized
INFO - 2024-12-02 10:33:58 --> Language Class Initialized
INFO - 2024-12-02 10:33:58 --> Loader Class Initialized
INFO - 2024-12-02 10:33:58 --> Helper loaded: url_helper
INFO - 2024-12-02 10:33:58 --> Helper loaded: form_helper
INFO - 2024-12-02 10:33:58 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:33:58 --> Form Validation Class Initialized
INFO - 2024-12-02 10:33:58 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:33:58 --> Controller Class Initialized
INFO - 2024-12-02 10:33:58 --> Model "User_model" initialized
INFO - 2024-12-02 10:33:58 --> Model "Category_model" initialized
INFO - 2024-12-02 10:33:58 --> Model "Review_model" initialized
INFO - 2024-12-02 10:33:58 --> Model "News_model" initialized
INFO - 2024-12-02 10:33:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:33:58 --> Query result: stdClass Object
(
    [view_count] => 27
)

INFO - 2024-12-02 10:33:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:33:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:33:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:33:58 --> Final output sent to browser
DEBUG - 2024-12-02 10:33:58 --> Total execution time: 0.0972
INFO - 2024-12-02 10:33:58 --> Config Class Initialized
INFO - 2024-12-02 10:33:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:33:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:33:58 --> Utf8 Class Initialized
INFO - 2024-12-02 10:33:58 --> URI Class Initialized
INFO - 2024-12-02 10:33:58 --> Router Class Initialized
INFO - 2024-12-02 10:33:58 --> Output Class Initialized
INFO - 2024-12-02 10:33:58 --> Security Class Initialized
DEBUG - 2024-12-02 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:33:58 --> CSRF cookie sent
INFO - 2024-12-02 10:33:58 --> Input Class Initialized
INFO - 2024-12-02 10:33:58 --> Language Class Initialized
ERROR - 2024-12-02 10:33:58 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:35:21 --> Config Class Initialized
INFO - 2024-12-02 10:35:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:35:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:35:21 --> Utf8 Class Initialized
INFO - 2024-12-02 10:35:21 --> URI Class Initialized
INFO - 2024-12-02 10:35:21 --> Router Class Initialized
INFO - 2024-12-02 10:35:21 --> Output Class Initialized
INFO - 2024-12-02 10:35:21 --> Security Class Initialized
DEBUG - 2024-12-02 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:35:21 --> CSRF cookie sent
INFO - 2024-12-02 10:35:21 --> Input Class Initialized
INFO - 2024-12-02 10:35:21 --> Language Class Initialized
INFO - 2024-12-02 10:35:21 --> Loader Class Initialized
INFO - 2024-12-02 10:35:21 --> Helper loaded: url_helper
INFO - 2024-12-02 10:35:21 --> Helper loaded: form_helper
INFO - 2024-12-02 10:35:21 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:35:21 --> Form Validation Class Initialized
INFO - 2024-12-02 10:35:21 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:35:21 --> Controller Class Initialized
INFO - 2024-12-02 10:35:21 --> Model "User_model" initialized
INFO - 2024-12-02 10:35:21 --> Model "Category_model" initialized
INFO - 2024-12-02 10:35:21 --> Model "Review_model" initialized
INFO - 2024-12-02 10:35:21 --> Model "News_model" initialized
INFO - 2024-12-02 10:35:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:35:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:35:22 --> Query result: stdClass Object
(
    [view_count] => 28
)

INFO - 2024-12-02 10:35:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:35:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:35:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:35:22 --> Final output sent to browser
DEBUG - 2024-12-02 10:35:22 --> Total execution time: 0.4141
INFO - 2024-12-02 10:35:22 --> Config Class Initialized
INFO - 2024-12-02 10:35:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:35:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:35:22 --> Utf8 Class Initialized
INFO - 2024-12-02 10:35:22 --> URI Class Initialized
INFO - 2024-12-02 10:35:22 --> Router Class Initialized
INFO - 2024-12-02 10:35:22 --> Output Class Initialized
INFO - 2024-12-02 10:35:22 --> Security Class Initialized
DEBUG - 2024-12-02 10:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:35:22 --> CSRF cookie sent
INFO - 2024-12-02 10:35:22 --> Input Class Initialized
INFO - 2024-12-02 10:35:22 --> Language Class Initialized
ERROR - 2024-12-02 10:35:22 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 10:42:16 --> Config Class Initialized
INFO - 2024-12-02 10:42:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:42:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:42:16 --> Utf8 Class Initialized
INFO - 2024-12-02 10:42:16 --> URI Class Initialized
INFO - 2024-12-02 10:42:16 --> Router Class Initialized
INFO - 2024-12-02 10:42:16 --> Output Class Initialized
INFO - 2024-12-02 10:42:16 --> Security Class Initialized
DEBUG - 2024-12-02 10:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:42:16 --> CSRF cookie sent
INFO - 2024-12-02 10:42:16 --> Input Class Initialized
INFO - 2024-12-02 10:42:16 --> Language Class Initialized
INFO - 2024-12-02 10:42:16 --> Loader Class Initialized
INFO - 2024-12-02 10:42:16 --> Helper loaded: url_helper
INFO - 2024-12-02 10:42:16 --> Helper loaded: form_helper
INFO - 2024-12-02 10:42:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 10:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 10:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 10:42:16 --> Form Validation Class Initialized
INFO - 2024-12-02 10:42:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 10:42:16 --> Controller Class Initialized
INFO - 2024-12-02 10:42:16 --> Model "User_model" initialized
INFO - 2024-12-02 10:42:16 --> Model "Category_model" initialized
INFO - 2024-12-02 10:42:16 --> Model "Review_model" initialized
INFO - 2024-12-02 10:42:16 --> Model "News_model" initialized
INFO - 2024-12-02 10:42:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 10:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 10:42:16 --> Query result: stdClass Object
(
    [view_count] => 29
)

INFO - 2024-12-02 10:42:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 10:42:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 10:42:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 10:42:16 --> Final output sent to browser
DEBUG - 2024-12-02 10:42:16 --> Total execution time: 0.7122
INFO - 2024-12-02 10:42:17 --> Config Class Initialized
INFO - 2024-12-02 10:42:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 10:42:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 10:42:17 --> Utf8 Class Initialized
INFO - 2024-12-02 10:42:17 --> URI Class Initialized
INFO - 2024-12-02 10:42:17 --> Router Class Initialized
INFO - 2024-12-02 10:42:17 --> Output Class Initialized
INFO - 2024-12-02 10:42:17 --> Security Class Initialized
DEBUG - 2024-12-02 10:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 10:42:18 --> CSRF cookie sent
INFO - 2024-12-02 10:42:18 --> Input Class Initialized
INFO - 2024-12-02 10:42:18 --> Language Class Initialized
ERROR - 2024-12-02 10:42:18 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 12:45:44 --> Config Class Initialized
INFO - 2024-12-02 12:45:44 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:45:44 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:45:44 --> Utf8 Class Initialized
INFO - 2024-12-02 12:45:44 --> URI Class Initialized
INFO - 2024-12-02 12:45:44 --> Router Class Initialized
INFO - 2024-12-02 12:45:44 --> Output Class Initialized
INFO - 2024-12-02 12:45:44 --> Security Class Initialized
DEBUG - 2024-12-02 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:45:44 --> CSRF cookie sent
INFO - 2024-12-02 12:45:44 --> Input Class Initialized
INFO - 2024-12-02 12:45:44 --> Language Class Initialized
INFO - 2024-12-02 12:45:44 --> Loader Class Initialized
INFO - 2024-12-02 12:45:44 --> Helper loaded: url_helper
INFO - 2024-12-02 12:45:44 --> Helper loaded: form_helper
INFO - 2024-12-02 12:45:44 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:45:44 --> Form Validation Class Initialized
INFO - 2024-12-02 12:45:44 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:45:44 --> Controller Class Initialized
INFO - 2024-12-02 12:45:44 --> Model "User_model" initialized
INFO - 2024-12-02 12:45:44 --> Model "Category_model" initialized
INFO - 2024-12-02 12:45:44 --> Model "Review_model" initialized
INFO - 2024-12-02 12:45:44 --> Model "News_model" initialized
INFO - 2024-12-02 12:45:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 12:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 12:45:44 --> Query result: stdClass Object
(
    [view_count] => 30
)

INFO - 2024-12-02 12:45:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 12:45:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 12:45:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 12:45:44 --> Final output sent to browser
DEBUG - 2024-12-02 12:45:44 --> Total execution time: 0.5719
INFO - 2024-12-02 12:45:46 --> Config Class Initialized
INFO - 2024-12-02 12:45:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:45:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:45:47 --> Utf8 Class Initialized
INFO - 2024-12-02 12:45:47 --> URI Class Initialized
INFO - 2024-12-02 12:45:47 --> Router Class Initialized
INFO - 2024-12-02 12:45:47 --> Output Class Initialized
INFO - 2024-12-02 12:45:47 --> Security Class Initialized
DEBUG - 2024-12-02 12:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:45:47 --> CSRF cookie sent
INFO - 2024-12-02 12:45:47 --> Input Class Initialized
INFO - 2024-12-02 12:45:47 --> Language Class Initialized
ERROR - 2024-12-02 12:45:47 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 12:46:14 --> Config Class Initialized
INFO - 2024-12-02 12:46:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:46:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:46:14 --> Utf8 Class Initialized
INFO - 2024-12-02 12:46:14 --> URI Class Initialized
INFO - 2024-12-02 12:46:14 --> Router Class Initialized
INFO - 2024-12-02 12:46:14 --> Output Class Initialized
INFO - 2024-12-02 12:46:14 --> Security Class Initialized
DEBUG - 2024-12-02 12:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:46:14 --> CSRF cookie sent
INFO - 2024-12-02 12:46:14 --> Input Class Initialized
INFO - 2024-12-02 12:46:14 --> Language Class Initialized
INFO - 2024-12-02 12:46:14 --> Loader Class Initialized
INFO - 2024-12-02 12:46:15 --> Helper loaded: url_helper
INFO - 2024-12-02 12:46:15 --> Helper loaded: form_helper
INFO - 2024-12-02 12:46:15 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:46:15 --> Form Validation Class Initialized
INFO - 2024-12-02 12:46:15 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:46:15 --> Controller Class Initialized
INFO - 2024-12-02 12:46:15 --> Model "User_model" initialized
INFO - 2024-12-02 12:46:15 --> Model "Category_model" initialized
INFO - 2024-12-02 12:46:15 --> Model "Review_model" initialized
INFO - 2024-12-02 12:46:15 --> Model "News_model" initialized
INFO - 2024-12-02 12:46:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 12:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 12:46:15 --> Query result: stdClass Object
(
    [view_count] => 31
)

INFO - 2024-12-02 12:46:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 12:46:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 12:46:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 12:46:15 --> Final output sent to browser
DEBUG - 2024-12-02 12:46:15 --> Total execution time: 0.1640
INFO - 2024-12-02 12:46:15 --> Config Class Initialized
INFO - 2024-12-02 12:46:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:46:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:46:15 --> Utf8 Class Initialized
INFO - 2024-12-02 12:46:15 --> URI Class Initialized
INFO - 2024-12-02 12:46:15 --> Router Class Initialized
INFO - 2024-12-02 12:46:15 --> Output Class Initialized
INFO - 2024-12-02 12:46:15 --> Security Class Initialized
DEBUG - 2024-12-02 12:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:46:15 --> CSRF cookie sent
INFO - 2024-12-02 12:46:15 --> Input Class Initialized
INFO - 2024-12-02 12:46:15 --> Language Class Initialized
ERROR - 2024-12-02 12:46:15 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 12:46:32 --> Config Class Initialized
INFO - 2024-12-02 12:46:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:46:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:46:32 --> Utf8 Class Initialized
INFO - 2024-12-02 12:46:32 --> URI Class Initialized
INFO - 2024-12-02 12:46:32 --> Router Class Initialized
INFO - 2024-12-02 12:46:32 --> Output Class Initialized
INFO - 2024-12-02 12:46:32 --> Security Class Initialized
DEBUG - 2024-12-02 12:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:46:32 --> CSRF cookie sent
INFO - 2024-12-02 12:46:32 --> Input Class Initialized
INFO - 2024-12-02 12:46:32 --> Language Class Initialized
INFO - 2024-12-02 12:46:32 --> Loader Class Initialized
INFO - 2024-12-02 12:46:32 --> Helper loaded: url_helper
INFO - 2024-12-02 12:46:32 --> Helper loaded: form_helper
INFO - 2024-12-02 12:46:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:46:32 --> Form Validation Class Initialized
INFO - 2024-12-02 12:46:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:46:32 --> Controller Class Initialized
INFO - 2024-12-02 12:46:32 --> Model "User_model" initialized
INFO - 2024-12-02 12:46:32 --> Model "Category_model" initialized
INFO - 2024-12-02 12:46:32 --> Model "Review_model" initialized
INFO - 2024-12-02 12:46:32 --> Model "News_model" initialized
INFO - 2024-12-02 12:46:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 12:46:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 12:46:32 --> Query result: stdClass Object
(
    [view_count] => 32
)

INFO - 2024-12-02 12:46:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 12:46:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 12:46:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 12:46:32 --> Final output sent to browser
DEBUG - 2024-12-02 12:46:32 --> Total execution time: 0.0845
INFO - 2024-12-02 12:46:33 --> Config Class Initialized
INFO - 2024-12-02 12:46:33 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:46:33 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:46:33 --> Utf8 Class Initialized
INFO - 2024-12-02 12:46:33 --> URI Class Initialized
INFO - 2024-12-02 12:46:33 --> Router Class Initialized
INFO - 2024-12-02 12:46:33 --> Output Class Initialized
INFO - 2024-12-02 12:46:33 --> Security Class Initialized
DEBUG - 2024-12-02 12:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:46:33 --> CSRF cookie sent
INFO - 2024-12-02 12:46:33 --> Input Class Initialized
INFO - 2024-12-02 12:46:33 --> Language Class Initialized
ERROR - 2024-12-02 12:46:33 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 12:48:40 --> Config Class Initialized
INFO - 2024-12-02 12:48:40 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:48:40 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:48:40 --> Utf8 Class Initialized
INFO - 2024-12-02 12:48:40 --> URI Class Initialized
INFO - 2024-12-02 12:48:40 --> Router Class Initialized
INFO - 2024-12-02 12:48:40 --> Output Class Initialized
INFO - 2024-12-02 12:48:40 --> Security Class Initialized
DEBUG - 2024-12-02 12:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:48:40 --> CSRF cookie sent
INFO - 2024-12-02 12:48:40 --> Input Class Initialized
INFO - 2024-12-02 12:48:40 --> Language Class Initialized
INFO - 2024-12-02 12:48:40 --> Loader Class Initialized
INFO - 2024-12-02 12:48:40 --> Helper loaded: url_helper
INFO - 2024-12-02 12:48:40 --> Helper loaded: form_helper
INFO - 2024-12-02 12:48:40 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:48:40 --> Form Validation Class Initialized
INFO - 2024-12-02 12:48:40 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:48:40 --> Controller Class Initialized
INFO - 2024-12-02 12:48:40 --> Model "Category_model" initialized
INFO - 2024-12-02 12:48:40 --> Model "User_model" initialized
INFO - 2024-12-02 12:48:40 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 12:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 12:48:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 12:48:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 12:48:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 12:48:40 --> Final output sent to browser
DEBUG - 2024-12-02 12:48:40 --> Total execution time: 0.5037
INFO - 2024-12-02 12:48:46 --> Config Class Initialized
INFO - 2024-12-02 12:48:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:48:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:48:46 --> Utf8 Class Initialized
INFO - 2024-12-02 12:48:46 --> URI Class Initialized
INFO - 2024-12-02 12:48:46 --> Router Class Initialized
INFO - 2024-12-02 12:48:46 --> Output Class Initialized
INFO - 2024-12-02 12:48:46 --> Security Class Initialized
DEBUG - 2024-12-02 12:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:48:46 --> CSRF cookie sent
INFO - 2024-12-02 12:48:46 --> CSRF token verified
INFO - 2024-12-02 12:48:46 --> Input Class Initialized
INFO - 2024-12-02 12:48:46 --> Language Class Initialized
INFO - 2024-12-02 12:48:46 --> Loader Class Initialized
INFO - 2024-12-02 12:48:46 --> Helper loaded: url_helper
INFO - 2024-12-02 12:48:46 --> Helper loaded: form_helper
INFO - 2024-12-02 12:48:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:48:46 --> Form Validation Class Initialized
INFO - 2024-12-02 12:48:46 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:48:46 --> Controller Class Initialized
INFO - 2024-12-02 12:48:46 --> Model "User_model" initialized
INFO - 2024-12-02 12:48:46 --> Model "Category_model" initialized
INFO - 2024-12-02 12:48:46 --> Model "Review_model" initialized
INFO - 2024-12-02 12:48:46 --> Model "News_model" initialized
INFO - 2024-12-02 12:48:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 12:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 12:48:46 --> Config Class Initialized
INFO - 2024-12-02 12:48:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:48:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:48:46 --> Utf8 Class Initialized
INFO - 2024-12-02 12:48:46 --> URI Class Initialized
INFO - 2024-12-02 12:48:46 --> Router Class Initialized
INFO - 2024-12-02 12:48:46 --> Output Class Initialized
INFO - 2024-12-02 12:48:46 --> Security Class Initialized
DEBUG - 2024-12-02 12:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:48:46 --> CSRF cookie sent
INFO - 2024-12-02 12:48:46 --> Input Class Initialized
INFO - 2024-12-02 12:48:46 --> Language Class Initialized
INFO - 2024-12-02 12:48:46 --> Loader Class Initialized
INFO - 2024-12-02 12:48:46 --> Helper loaded: url_helper
INFO - 2024-12-02 12:48:46 --> Helper loaded: form_helper
INFO - 2024-12-02 12:48:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:48:46 --> Form Validation Class Initialized
INFO - 2024-12-02 12:48:46 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:48:46 --> Controller Class Initialized
INFO - 2024-12-02 12:48:46 --> Model "Category_model" initialized
INFO - 2024-12-02 12:48:46 --> Model "User_model" initialized
INFO - 2024-12-02 12:48:46 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 12:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 12:48:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 12:48:46 --> Final output sent to browser
DEBUG - 2024-12-02 12:48:46 --> Total execution time: 0.0804
INFO - 2024-12-02 12:48:51 --> Config Class Initialized
INFO - 2024-12-02 12:48:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 12:48:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 12:48:51 --> Utf8 Class Initialized
INFO - 2024-12-02 12:48:51 --> URI Class Initialized
INFO - 2024-12-02 12:48:51 --> Router Class Initialized
INFO - 2024-12-02 12:48:51 --> Output Class Initialized
INFO - 2024-12-02 12:48:51 --> Security Class Initialized
DEBUG - 2024-12-02 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 12:48:51 --> CSRF cookie sent
INFO - 2024-12-02 12:48:51 --> Input Class Initialized
INFO - 2024-12-02 12:48:51 --> Language Class Initialized
INFO - 2024-12-02 12:48:51 --> Loader Class Initialized
INFO - 2024-12-02 12:48:51 --> Helper loaded: url_helper
INFO - 2024-12-02 12:48:51 --> Helper loaded: form_helper
INFO - 2024-12-02 12:48:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 12:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 12:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 12:48:51 --> Form Validation Class Initialized
INFO - 2024-12-02 12:48:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 12:48:51 --> Controller Class Initialized
INFO - 2024-12-02 12:48:51 --> Model "News_model" initialized
INFO - 2024-12-02 12:48:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 12:48:51 --> Final output sent to browser
DEBUG - 2024-12-02 12:48:51 --> Total execution time: 0.0993
INFO - 2024-12-02 13:08:06 --> Config Class Initialized
INFO - 2024-12-02 13:08:06 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:06 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:06 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:06 --> URI Class Initialized
INFO - 2024-12-02 13:08:06 --> Router Class Initialized
INFO - 2024-12-02 13:08:06 --> Output Class Initialized
INFO - 2024-12-02 13:08:06 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:06 --> CSRF cookie sent
INFO - 2024-12-02 13:08:06 --> Input Class Initialized
INFO - 2024-12-02 13:08:06 --> Language Class Initialized
INFO - 2024-12-02 13:08:06 --> Loader Class Initialized
INFO - 2024-12-02 13:08:06 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:06 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:06 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:06 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:07 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:07 --> Controller Class Initialized
INFO - 2024-12-02 13:08:07 --> Model "News_model" initialized
INFO - 2024-12-02 13:08:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 13:08:07 --> Final output sent to browser
DEBUG - 2024-12-02 13:08:07 --> Total execution time: 0.7902
INFO - 2024-12-02 13:08:22 --> Config Class Initialized
INFO - 2024-12-02 13:08:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:22 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:22 --> URI Class Initialized
INFO - 2024-12-02 13:08:22 --> Router Class Initialized
INFO - 2024-12-02 13:08:22 --> Output Class Initialized
INFO - 2024-12-02 13:08:22 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:22 --> CSRF cookie sent
INFO - 2024-12-02 13:08:22 --> Input Class Initialized
INFO - 2024-12-02 13:08:22 --> Language Class Initialized
INFO - 2024-12-02 13:08:22 --> Loader Class Initialized
INFO - 2024-12-02 13:08:22 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:22 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:22 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:22 --> Controller Class Initialized
INFO - 2024-12-02 13:08:22 --> Model "Category_model" initialized
INFO - 2024-12-02 13:08:22 --> Model "User_model" initialized
INFO - 2024-12-02 13:08:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:08:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 13:08:23 --> Final output sent to browser
DEBUG - 2024-12-02 13:08:23 --> Total execution time: 0.3900
INFO - 2024-12-02 13:08:31 --> Config Class Initialized
INFO - 2024-12-02 13:08:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:31 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:31 --> URI Class Initialized
INFO - 2024-12-02 13:08:31 --> Router Class Initialized
INFO - 2024-12-02 13:08:31 --> Output Class Initialized
INFO - 2024-12-02 13:08:31 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:31 --> CSRF cookie sent
INFO - 2024-12-02 13:08:31 --> Input Class Initialized
INFO - 2024-12-02 13:08:31 --> Language Class Initialized
INFO - 2024-12-02 13:08:31 --> Loader Class Initialized
INFO - 2024-12-02 13:08:31 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:31 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:31 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:31 --> Controller Class Initialized
INFO - 2024-12-02 13:08:31 --> Model "News_model" initialized
INFO - 2024-12-02 13:08:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 13:08:31 --> Final output sent to browser
DEBUG - 2024-12-02 13:08:31 --> Total execution time: 0.0700
INFO - 2024-12-02 13:08:39 --> Config Class Initialized
INFO - 2024-12-02 13:08:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:39 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:39 --> URI Class Initialized
INFO - 2024-12-02 13:08:39 --> Router Class Initialized
INFO - 2024-12-02 13:08:39 --> Output Class Initialized
INFO - 2024-12-02 13:08:39 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:39 --> CSRF cookie sent
INFO - 2024-12-02 13:08:39 --> Input Class Initialized
INFO - 2024-12-02 13:08:39 --> Language Class Initialized
INFO - 2024-12-02 13:08:39 --> Loader Class Initialized
INFO - 2024-12-02 13:08:39 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:39 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:39 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:39 --> Controller Class Initialized
INFO - 2024-12-02 13:08:39 --> Model "User_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "Category_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "Review_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "News_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:08:39 --> Config Class Initialized
INFO - 2024-12-02 13:08:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:39 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:39 --> URI Class Initialized
INFO - 2024-12-02 13:08:39 --> Router Class Initialized
INFO - 2024-12-02 13:08:39 --> Output Class Initialized
INFO - 2024-12-02 13:08:39 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:39 --> CSRF cookie sent
INFO - 2024-12-02 13:08:39 --> Input Class Initialized
INFO - 2024-12-02 13:08:39 --> Language Class Initialized
INFO - 2024-12-02 13:08:39 --> Loader Class Initialized
INFO - 2024-12-02 13:08:39 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:39 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:39 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:39 --> Controller Class Initialized
INFO - 2024-12-02 13:08:39 --> Model "User_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "Category_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "Review_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "News_model" initialized
INFO - 2024-12-02 13:08:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:08:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:08:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:08:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 13:08:39 --> Final output sent to browser
DEBUG - 2024-12-02 13:08:39 --> Total execution time: 0.0930
INFO - 2024-12-02 13:08:50 --> Config Class Initialized
INFO - 2024-12-02 13:08:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:50 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:50 --> URI Class Initialized
INFO - 2024-12-02 13:08:50 --> Router Class Initialized
INFO - 2024-12-02 13:08:50 --> Output Class Initialized
INFO - 2024-12-02 13:08:50 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:50 --> CSRF cookie sent
INFO - 2024-12-02 13:08:50 --> CSRF token verified
INFO - 2024-12-02 13:08:50 --> Input Class Initialized
INFO - 2024-12-02 13:08:50 --> Language Class Initialized
INFO - 2024-12-02 13:08:50 --> Loader Class Initialized
INFO - 2024-12-02 13:08:50 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:50 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:50 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:50 --> Controller Class Initialized
INFO - 2024-12-02 13:08:50 --> Model "User_model" initialized
INFO - 2024-12-02 13:08:50 --> Model "Category_model" initialized
INFO - 2024-12-02 13:08:50 --> Model "Review_model" initialized
INFO - 2024-12-02 13:08:50 --> Model "News_model" initialized
INFO - 2024-12-02 13:08:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:08:51 --> Config Class Initialized
INFO - 2024-12-02 13:08:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:51 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:51 --> URI Class Initialized
INFO - 2024-12-02 13:08:51 --> Router Class Initialized
INFO - 2024-12-02 13:08:51 --> Output Class Initialized
INFO - 2024-12-02 13:08:51 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:51 --> CSRF cookie sent
INFO - 2024-12-02 13:08:51 --> Input Class Initialized
INFO - 2024-12-02 13:08:51 --> Language Class Initialized
INFO - 2024-12-02 13:08:51 --> Loader Class Initialized
INFO - 2024-12-02 13:08:51 --> Helper loaded: url_helper
INFO - 2024-12-02 13:08:51 --> Helper loaded: form_helper
INFO - 2024-12-02 13:08:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:08:51 --> Form Validation Class Initialized
INFO - 2024-12-02 13:08:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:08:51 --> Controller Class Initialized
INFO - 2024-12-02 13:08:51 --> Model "User_model" initialized
INFO - 2024-12-02 13:08:51 --> Model "Category_model" initialized
INFO - 2024-12-02 13:08:51 --> Model "Review_model" initialized
INFO - 2024-12-02 13:08:51 --> Model "News_model" initialized
INFO - 2024-12-02 13:08:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:08:51 --> Query result: stdClass Object
(
    [view_count] => 33
)

INFO - 2024-12-02 13:08:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:08:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:08:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:08:51 --> Final output sent to browser
DEBUG - 2024-12-02 13:08:51 --> Total execution time: 0.1657
INFO - 2024-12-02 13:08:51 --> Config Class Initialized
INFO - 2024-12-02 13:08:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:08:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:08:51 --> Utf8 Class Initialized
INFO - 2024-12-02 13:08:51 --> URI Class Initialized
INFO - 2024-12-02 13:08:51 --> Router Class Initialized
INFO - 2024-12-02 13:08:51 --> Output Class Initialized
INFO - 2024-12-02 13:08:51 --> Security Class Initialized
DEBUG - 2024-12-02 13:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:08:51 --> CSRF cookie sent
INFO - 2024-12-02 13:08:51 --> Input Class Initialized
INFO - 2024-12-02 13:08:51 --> Language Class Initialized
ERROR - 2024-12-02 13:08:51 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:09:04 --> Config Class Initialized
INFO - 2024-12-02 13:09:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:09:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:09:04 --> Utf8 Class Initialized
INFO - 2024-12-02 13:09:04 --> URI Class Initialized
INFO - 2024-12-02 13:09:04 --> Router Class Initialized
INFO - 2024-12-02 13:09:04 --> Output Class Initialized
INFO - 2024-12-02 13:09:04 --> Security Class Initialized
DEBUG - 2024-12-02 13:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:09:04 --> CSRF cookie sent
INFO - 2024-12-02 13:09:04 --> Input Class Initialized
INFO - 2024-12-02 13:09:04 --> Language Class Initialized
INFO - 2024-12-02 13:09:04 --> Loader Class Initialized
INFO - 2024-12-02 13:09:04 --> Helper loaded: url_helper
INFO - 2024-12-02 13:09:04 --> Helper loaded: form_helper
INFO - 2024-12-02 13:09:04 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:09:04 --> Form Validation Class Initialized
INFO - 2024-12-02 13:09:04 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:09:04 --> Controller Class Initialized
INFO - 2024-12-02 13:09:04 --> Model "User_model" initialized
INFO - 2024-12-02 13:09:04 --> Model "Category_model" initialized
INFO - 2024-12-02 13:09:04 --> Model "Review_model" initialized
INFO - 2024-12-02 13:09:04 --> Model "News_model" initialized
INFO - 2024-12-02 13:09:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:09:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:09:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:09:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:09:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-02 13:09:04 --> Final output sent to browser
DEBUG - 2024-12-02 13:09:04 --> Total execution time: 0.1331
INFO - 2024-12-02 13:09:54 --> Config Class Initialized
INFO - 2024-12-02 13:09:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:09:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:09:54 --> Utf8 Class Initialized
INFO - 2024-12-02 13:09:54 --> URI Class Initialized
INFO - 2024-12-02 13:09:54 --> Router Class Initialized
INFO - 2024-12-02 13:09:54 --> Output Class Initialized
INFO - 2024-12-02 13:09:54 --> Security Class Initialized
DEBUG - 2024-12-02 13:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:09:54 --> CSRF cookie sent
INFO - 2024-12-02 13:09:54 --> Input Class Initialized
INFO - 2024-12-02 13:09:54 --> Language Class Initialized
INFO - 2024-12-02 13:09:54 --> Loader Class Initialized
INFO - 2024-12-02 13:09:54 --> Helper loaded: url_helper
INFO - 2024-12-02 13:09:54 --> Helper loaded: form_helper
INFO - 2024-12-02 13:09:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:09:54 --> Form Validation Class Initialized
INFO - 2024-12-02 13:09:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:09:54 --> Controller Class Initialized
INFO - 2024-12-02 13:09:54 --> Model "User_model" initialized
INFO - 2024-12-02 13:09:54 --> Model "Category_model" initialized
INFO - 2024-12-02 13:09:54 --> Model "Review_model" initialized
INFO - 2024-12-02 13:09:54 --> Model "News_model" initialized
INFO - 2024-12-02 13:09:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:09:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:09:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:09:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 13:09:54 --> Final output sent to browser
DEBUG - 2024-12-02 13:09:54 --> Total execution time: 0.0792
INFO - 2024-12-02 13:09:57 --> Config Class Initialized
INFO - 2024-12-02 13:09:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:09:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:09:57 --> Utf8 Class Initialized
INFO - 2024-12-02 13:09:57 --> URI Class Initialized
INFO - 2024-12-02 13:09:57 --> Router Class Initialized
INFO - 2024-12-02 13:09:57 --> Output Class Initialized
INFO - 2024-12-02 13:09:57 --> Security Class Initialized
DEBUG - 2024-12-02 13:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:09:57 --> CSRF cookie sent
INFO - 2024-12-02 13:09:57 --> CSRF token verified
INFO - 2024-12-02 13:09:57 --> Input Class Initialized
INFO - 2024-12-02 13:09:57 --> Language Class Initialized
INFO - 2024-12-02 13:09:57 --> Loader Class Initialized
INFO - 2024-12-02 13:09:57 --> Helper loaded: url_helper
INFO - 2024-12-02 13:09:57 --> Helper loaded: form_helper
INFO - 2024-12-02 13:09:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:09:57 --> Form Validation Class Initialized
INFO - 2024-12-02 13:09:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:09:57 --> Controller Class Initialized
INFO - 2024-12-02 13:09:57 --> Model "User_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "Category_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "Review_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "News_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:09:57 --> Config Class Initialized
INFO - 2024-12-02 13:09:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:09:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:09:57 --> Utf8 Class Initialized
INFO - 2024-12-02 13:09:57 --> URI Class Initialized
INFO - 2024-12-02 13:09:57 --> Router Class Initialized
INFO - 2024-12-02 13:09:57 --> Output Class Initialized
INFO - 2024-12-02 13:09:57 --> Security Class Initialized
DEBUG - 2024-12-02 13:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:09:57 --> CSRF cookie sent
INFO - 2024-12-02 13:09:57 --> Input Class Initialized
INFO - 2024-12-02 13:09:57 --> Language Class Initialized
INFO - 2024-12-02 13:09:57 --> Loader Class Initialized
INFO - 2024-12-02 13:09:57 --> Helper loaded: url_helper
INFO - 2024-12-02 13:09:57 --> Helper loaded: form_helper
INFO - 2024-12-02 13:09:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:09:57 --> Form Validation Class Initialized
INFO - 2024-12-02 13:09:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:09:57 --> Controller Class Initialized
INFO - 2024-12-02 13:09:57 --> Model "User_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "Category_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "Review_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "News_model" initialized
INFO - 2024-12-02 13:09:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:09:57 --> Query result: stdClass Object
(
    [view_count] => 34
)

INFO - 2024-12-02 13:09:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:09:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:09:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:09:57 --> Final output sent to browser
DEBUG - 2024-12-02 13:09:57 --> Total execution time: 0.0675
INFO - 2024-12-02 13:09:57 --> Config Class Initialized
INFO - 2024-12-02 13:09:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:09:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:09:57 --> Utf8 Class Initialized
INFO - 2024-12-02 13:09:57 --> URI Class Initialized
INFO - 2024-12-02 13:09:57 --> Router Class Initialized
INFO - 2024-12-02 13:09:58 --> Output Class Initialized
INFO - 2024-12-02 13:09:58 --> Security Class Initialized
DEBUG - 2024-12-02 13:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:09:58 --> CSRF cookie sent
INFO - 2024-12-02 13:09:58 --> Input Class Initialized
INFO - 2024-12-02 13:09:58 --> Language Class Initialized
ERROR - 2024-12-02 13:09:58 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:10:33 --> Config Class Initialized
INFO - 2024-12-02 13:10:33 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:10:33 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:10:33 --> Utf8 Class Initialized
INFO - 2024-12-02 13:10:33 --> URI Class Initialized
INFO - 2024-12-02 13:10:33 --> Router Class Initialized
INFO - 2024-12-02 13:10:33 --> Output Class Initialized
INFO - 2024-12-02 13:10:33 --> Security Class Initialized
DEBUG - 2024-12-02 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:10:33 --> CSRF cookie sent
INFO - 2024-12-02 13:10:33 --> Input Class Initialized
INFO - 2024-12-02 13:10:33 --> Language Class Initialized
INFO - 2024-12-02 13:10:33 --> Loader Class Initialized
INFO - 2024-12-02 13:10:33 --> Helper loaded: url_helper
INFO - 2024-12-02 13:10:33 --> Helper loaded: form_helper
INFO - 2024-12-02 13:10:33 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:10:33 --> Form Validation Class Initialized
INFO - 2024-12-02 13:10:33 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:10:33 --> Controller Class Initialized
INFO - 2024-12-02 13:10:33 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:10:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:10:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:10:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-02 13:10:33 --> Final output sent to browser
DEBUG - 2024-12-02 13:10:33 --> Total execution time: 0.1179
INFO - 2024-12-02 13:10:38 --> Config Class Initialized
INFO - 2024-12-02 13:10:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:10:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:10:38 --> Utf8 Class Initialized
INFO - 2024-12-02 13:10:38 --> URI Class Initialized
INFO - 2024-12-02 13:10:38 --> Router Class Initialized
INFO - 2024-12-02 13:10:38 --> Output Class Initialized
INFO - 2024-12-02 13:10:38 --> Security Class Initialized
DEBUG - 2024-12-02 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:10:38 --> CSRF cookie sent
INFO - 2024-12-02 13:10:38 --> Input Class Initialized
INFO - 2024-12-02 13:10:38 --> Language Class Initialized
INFO - 2024-12-02 13:10:38 --> Loader Class Initialized
INFO - 2024-12-02 13:10:38 --> Helper loaded: url_helper
INFO - 2024-12-02 13:10:38 --> Helper loaded: form_helper
INFO - 2024-12-02 13:10:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:10:38 --> Form Validation Class Initialized
INFO - 2024-12-02 13:10:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:10:38 --> Controller Class Initialized
INFO - 2024-12-02 13:10:38 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:10:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:10:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:10:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:10:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-02 13:10:38 --> Final output sent to browser
DEBUG - 2024-12-02 13:10:38 --> Total execution time: 0.0705
INFO - 2024-12-02 13:10:49 --> Config Class Initialized
INFO - 2024-12-02 13:10:49 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:10:49 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:10:49 --> Utf8 Class Initialized
INFO - 2024-12-02 13:10:49 --> URI Class Initialized
INFO - 2024-12-02 13:10:49 --> Router Class Initialized
INFO - 2024-12-02 13:10:49 --> Output Class Initialized
INFO - 2024-12-02 13:10:49 --> Security Class Initialized
DEBUG - 2024-12-02 13:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:10:49 --> CSRF cookie sent
INFO - 2024-12-02 13:10:49 --> CSRF token verified
INFO - 2024-12-02 13:10:49 --> Input Class Initialized
INFO - 2024-12-02 13:10:49 --> Language Class Initialized
INFO - 2024-12-02 13:10:49 --> Loader Class Initialized
INFO - 2024-12-02 13:10:49 --> Helper loaded: url_helper
INFO - 2024-12-02 13:10:49 --> Helper loaded: form_helper
INFO - 2024-12-02 13:10:49 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:10:49 --> Form Validation Class Initialized
INFO - 2024-12-02 13:10:49 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:10:49 --> Controller Class Initialized
INFO - 2024-12-02 13:10:49 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:10:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:10:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-12-02 13:10:49 --> Update was executed but no rows were affected for user ID 2.
INFO - 2024-12-02 13:10:49 --> Config Class Initialized
INFO - 2024-12-02 13:10:49 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:10:49 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:10:49 --> Utf8 Class Initialized
INFO - 2024-12-02 13:10:49 --> URI Class Initialized
INFO - 2024-12-02 13:10:49 --> Router Class Initialized
INFO - 2024-12-02 13:10:49 --> Output Class Initialized
INFO - 2024-12-02 13:10:49 --> Security Class Initialized
DEBUG - 2024-12-02 13:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:10:49 --> CSRF cookie sent
INFO - 2024-12-02 13:10:49 --> Input Class Initialized
INFO - 2024-12-02 13:10:49 --> Language Class Initialized
INFO - 2024-12-02 13:10:50 --> Loader Class Initialized
INFO - 2024-12-02 13:10:50 --> Helper loaded: url_helper
INFO - 2024-12-02 13:10:50 --> Helper loaded: form_helper
INFO - 2024-12-02 13:10:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:10:50 --> Form Validation Class Initialized
INFO - 2024-12-02 13:10:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:10:50 --> Controller Class Initialized
INFO - 2024-12-02 13:10:50 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:10:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:10:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:10:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:10:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-02 13:10:50 --> Final output sent to browser
DEBUG - 2024-12-02 13:10:50 --> Total execution time: 0.0670
INFO - 2024-12-02 13:10:56 --> Config Class Initialized
INFO - 2024-12-02 13:10:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:10:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:10:56 --> Utf8 Class Initialized
INFO - 2024-12-02 13:10:56 --> URI Class Initialized
INFO - 2024-12-02 13:10:56 --> Router Class Initialized
INFO - 2024-12-02 13:10:56 --> Output Class Initialized
INFO - 2024-12-02 13:10:56 --> Security Class Initialized
DEBUG - 2024-12-02 13:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:10:56 --> CSRF cookie sent
INFO - 2024-12-02 13:10:56 --> Input Class Initialized
INFO - 2024-12-02 13:10:56 --> Language Class Initialized
INFO - 2024-12-02 13:10:56 --> Loader Class Initialized
INFO - 2024-12-02 13:10:56 --> Helper loaded: url_helper
INFO - 2024-12-02 13:10:56 --> Helper loaded: form_helper
INFO - 2024-12-02 13:10:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:10:56 --> Form Validation Class Initialized
INFO - 2024-12-02 13:10:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:10:56 --> Controller Class Initialized
INFO - 2024-12-02 13:10:56 --> Model "User_model" initialized
INFO - 2024-12-02 13:10:56 --> Model "Category_model" initialized
INFO - 2024-12-02 13:10:56 --> Model "Review_model" initialized
INFO - 2024-12-02 13:10:56 --> Model "News_model" initialized
INFO - 2024-12-02 13:10:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:10:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:10:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:10:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-02 13:10:56 --> Final output sent to browser
DEBUG - 2024-12-02 13:10:56 --> Total execution time: 0.1180
INFO - 2024-12-02 13:11:00 --> Config Class Initialized
INFO - 2024-12-02 13:11:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:00 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:00 --> URI Class Initialized
INFO - 2024-12-02 13:11:00 --> Router Class Initialized
INFO - 2024-12-02 13:11:00 --> Output Class Initialized
INFO - 2024-12-02 13:11:00 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:00 --> CSRF cookie sent
INFO - 2024-12-02 13:11:00 --> Input Class Initialized
INFO - 2024-12-02 13:11:00 --> Language Class Initialized
INFO - 2024-12-02 13:11:00 --> Loader Class Initialized
INFO - 2024-12-02 13:11:00 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:00 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:00 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:00 --> Controller Class Initialized
INFO - 2024-12-02 13:11:00 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:00 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:00 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:00 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 13:11:00 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:00 --> Total execution time: 0.1219
INFO - 2024-12-02 13:11:16 --> Config Class Initialized
INFO - 2024-12-02 13:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:16 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:16 --> URI Class Initialized
INFO - 2024-12-02 13:11:16 --> Router Class Initialized
INFO - 2024-12-02 13:11:16 --> Output Class Initialized
INFO - 2024-12-02 13:11:16 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:16 --> CSRF cookie sent
INFO - 2024-12-02 13:11:16 --> Input Class Initialized
INFO - 2024-12-02 13:11:16 --> Language Class Initialized
INFO - 2024-12-02 13:11:16 --> Loader Class Initialized
INFO - 2024-12-02 13:11:16 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:16 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:16 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:16 --> Controller Class Initialized
INFO - 2024-12-02 13:11:16 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:16 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:16 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:16 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-02 13:11:16 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:16 --> Total execution time: 0.1102
INFO - 2024-12-02 13:11:16 --> Config Class Initialized
INFO - 2024-12-02 13:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:16 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:16 --> URI Class Initialized
INFO - 2024-12-02 13:11:16 --> Router Class Initialized
INFO - 2024-12-02 13:11:16 --> Output Class Initialized
INFO - 2024-12-02 13:11:16 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:16 --> CSRF cookie sent
INFO - 2024-12-02 13:11:16 --> Input Class Initialized
INFO - 2024-12-02 13:11:16 --> Language Class Initialized
INFO - 2024-12-02 13:11:16 --> Loader Class Initialized
INFO - 2024-12-02 13:11:16 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:16 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:16 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:16 --> Controller Class Initialized
INFO - 2024-12-02 13:11:16 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-02 13:11:16 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:16 --> Total execution time: 0.0745
INFO - 2024-12-02 13:11:16 --> Config Class Initialized
INFO - 2024-12-02 13:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:17 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:17 --> URI Class Initialized
INFO - 2024-12-02 13:11:17 --> Router Class Initialized
INFO - 2024-12-02 13:11:17 --> Output Class Initialized
INFO - 2024-12-02 13:11:17 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:17 --> CSRF cookie sent
INFO - 2024-12-02 13:11:17 --> Input Class Initialized
INFO - 2024-12-02 13:11:17 --> Language Class Initialized
INFO - 2024-12-02 13:11:17 --> Loader Class Initialized
INFO - 2024-12-02 13:11:17 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:17 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:17 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:17 --> Controller Class Initialized
INFO - 2024-12-02 13:11:17 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/edit.php
INFO - 2024-12-02 13:11:17 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:17 --> Total execution time: 0.0602
INFO - 2024-12-02 13:11:17 --> Config Class Initialized
INFO - 2024-12-02 13:11:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:17 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:17 --> URI Class Initialized
INFO - 2024-12-02 13:11:17 --> Router Class Initialized
INFO - 2024-12-02 13:11:17 --> Output Class Initialized
INFO - 2024-12-02 13:11:17 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:17 --> CSRF cookie sent
INFO - 2024-12-02 13:11:17 --> Input Class Initialized
INFO - 2024-12-02 13:11:17 --> Language Class Initialized
INFO - 2024-12-02 13:11:17 --> Loader Class Initialized
INFO - 2024-12-02 13:11:17 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:17 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:17 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:17 --> Controller Class Initialized
INFO - 2024-12-02 13:11:17 --> Model "User_model" initialized
DEBUG - 2024-12-02 13:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-02 13:11:17 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:17 --> Total execution time: 0.0542
INFO - 2024-12-02 13:11:17 --> Config Class Initialized
INFO - 2024-12-02 13:11:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:17 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:17 --> URI Class Initialized
INFO - 2024-12-02 13:11:17 --> Router Class Initialized
INFO - 2024-12-02 13:11:17 --> Output Class Initialized
INFO - 2024-12-02 13:11:17 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:17 --> CSRF cookie sent
INFO - 2024-12-02 13:11:17 --> Input Class Initialized
INFO - 2024-12-02 13:11:17 --> Language Class Initialized
INFO - 2024-12-02 13:11:17 --> Loader Class Initialized
INFO - 2024-12-02 13:11:17 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:17 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:17 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:17 --> Controller Class Initialized
INFO - 2024-12-02 13:11:17 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:17 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:17 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:17 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:17 --> Query result: stdClass Object
(
    [view_count] => 35
)

INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:11:17 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:17 --> Total execution time: 0.0846
INFO - 2024-12-02 13:11:17 --> Config Class Initialized
INFO - 2024-12-02 13:11:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:17 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:17 --> URI Class Initialized
INFO - 2024-12-02 13:11:17 --> Router Class Initialized
INFO - 2024-12-02 13:11:17 --> Output Class Initialized
INFO - 2024-12-02 13:11:17 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:17 --> CSRF cookie sent
INFO - 2024-12-02 13:11:17 --> Input Class Initialized
INFO - 2024-12-02 13:11:17 --> Language Class Initialized
ERROR - 2024-12-02 13:11:17 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:11:18 --> Config Class Initialized
INFO - 2024-12-02 13:11:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:18 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:18 --> URI Class Initialized
INFO - 2024-12-02 13:11:18 --> Router Class Initialized
INFO - 2024-12-02 13:11:18 --> Output Class Initialized
INFO - 2024-12-02 13:11:18 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:18 --> CSRF cookie sent
INFO - 2024-12-02 13:11:18 --> Input Class Initialized
INFO - 2024-12-02 13:11:18 --> Language Class Initialized
INFO - 2024-12-02 13:11:18 --> Loader Class Initialized
INFO - 2024-12-02 13:11:18 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:18 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:18 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:18 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:18 --> Controller Class Initialized
INFO - 2024-12-02 13:11:18 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:18 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:18 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:18 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 13:11:18 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:18 --> Total execution time: 0.0814
INFO - 2024-12-02 13:11:18 --> Config Class Initialized
INFO - 2024-12-02 13:11:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:18 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:18 --> URI Class Initialized
INFO - 2024-12-02 13:11:18 --> Router Class Initialized
INFO - 2024-12-02 13:11:18 --> Output Class Initialized
INFO - 2024-12-02 13:11:18 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:18 --> CSRF cookie sent
INFO - 2024-12-02 13:11:18 --> Input Class Initialized
INFO - 2024-12-02 13:11:18 --> Language Class Initialized
INFO - 2024-12-02 13:11:18 --> Loader Class Initialized
INFO - 2024-12-02 13:11:18 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:18 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:18 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:18 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:18 --> Controller Class Initialized
INFO - 2024-12-02 13:11:18 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-02 13:11:19 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:19 --> Total execution time: 0.0698
INFO - 2024-12-02 13:11:19 --> Config Class Initialized
INFO - 2024-12-02 13:11:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:19 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:19 --> URI Class Initialized
INFO - 2024-12-02 13:11:19 --> Router Class Initialized
INFO - 2024-12-02 13:11:19 --> Output Class Initialized
INFO - 2024-12-02 13:11:19 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:19 --> CSRF cookie sent
INFO - 2024-12-02 13:11:19 --> Input Class Initialized
INFO - 2024-12-02 13:11:19 --> Language Class Initialized
INFO - 2024-12-02 13:11:19 --> Loader Class Initialized
INFO - 2024-12-02 13:11:19 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:19 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:19 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:19 --> Controller Class Initialized
INFO - 2024-12-02 13:11:19 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:19 --> Query result: stdClass Object
(
    [view_count] => 36
)

INFO - 2024-12-02 13:11:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:11:19 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:19 --> Total execution time: 0.0809
INFO - 2024-12-02 13:11:19 --> Config Class Initialized
INFO - 2024-12-02 13:11:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:19 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:19 --> URI Class Initialized
INFO - 2024-12-02 13:11:19 --> Router Class Initialized
INFO - 2024-12-02 13:11:19 --> Output Class Initialized
INFO - 2024-12-02 13:11:19 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:19 --> CSRF cookie sent
INFO - 2024-12-02 13:11:19 --> Input Class Initialized
INFO - 2024-12-02 13:11:19 --> Language Class Initialized
ERROR - 2024-12-02 13:11:19 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:11:20 --> Config Class Initialized
INFO - 2024-12-02 13:11:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:20 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:20 --> URI Class Initialized
INFO - 2024-12-02 13:11:20 --> Router Class Initialized
INFO - 2024-12-02 13:11:20 --> Output Class Initialized
INFO - 2024-12-02 13:11:20 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:20 --> CSRF cookie sent
INFO - 2024-12-02 13:11:20 --> Input Class Initialized
INFO - 2024-12-02 13:11:20 --> Language Class Initialized
INFO - 2024-12-02 13:11:20 --> Loader Class Initialized
INFO - 2024-12-02 13:11:20 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:20 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:20 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:20 --> Controller Class Initialized
INFO - 2024-12-02 13:11:20 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:20 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:20 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:20 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 13:11:20 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:20 --> Total execution time: 0.0591
INFO - 2024-12-02 13:11:20 --> Config Class Initialized
INFO - 2024-12-02 13:11:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:20 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:20 --> URI Class Initialized
INFO - 2024-12-02 13:11:20 --> Router Class Initialized
INFO - 2024-12-02 13:11:20 --> Output Class Initialized
INFO - 2024-12-02 13:11:20 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:20 --> CSRF cookie sent
INFO - 2024-12-02 13:11:20 --> Input Class Initialized
INFO - 2024-12-02 13:11:20 --> Language Class Initialized
INFO - 2024-12-02 13:11:20 --> Loader Class Initialized
INFO - 2024-12-02 13:11:20 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:20 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:20 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:20 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:20 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:20 --> Controller Class Initialized
INFO - 2024-12-02 13:11:20 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 13:11:20 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:20 --> Total execution time: 0.0693
INFO - 2024-12-02 13:11:21 --> Config Class Initialized
INFO - 2024-12-02 13:11:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:21 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:21 --> URI Class Initialized
INFO - 2024-12-02 13:11:21 --> Router Class Initialized
INFO - 2024-12-02 13:11:21 --> Output Class Initialized
INFO - 2024-12-02 13:11:21 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:21 --> CSRF cookie sent
INFO - 2024-12-02 13:11:21 --> Input Class Initialized
INFO - 2024-12-02 13:11:21 --> Language Class Initialized
INFO - 2024-12-02 13:11:21 --> Loader Class Initialized
INFO - 2024-12-02 13:11:21 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:21 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:21 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:21 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:21 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:21 --> Controller Class Initialized
INFO - 2024-12-02 13:11:21 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:21 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:21 --> Config Class Initialized
INFO - 2024-12-02 13:11:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:21 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:21 --> URI Class Initialized
INFO - 2024-12-02 13:11:21 --> Router Class Initialized
INFO - 2024-12-02 13:11:21 --> Output Class Initialized
INFO - 2024-12-02 13:11:21 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:21 --> CSRF cookie sent
INFO - 2024-12-02 13:11:21 --> Input Class Initialized
INFO - 2024-12-02 13:11:21 --> Language Class Initialized
INFO - 2024-12-02 13:11:21 --> Loader Class Initialized
INFO - 2024-12-02 13:11:21 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:21 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:21 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:21 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:21 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:21 --> Controller Class Initialized
INFO - 2024-12-02 13:11:21 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:21 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:21 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:21 --> Total execution time: 0.0516
INFO - 2024-12-02 13:11:22 --> Config Class Initialized
INFO - 2024-12-02 13:11:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:22 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:22 --> URI Class Initialized
INFO - 2024-12-02 13:11:22 --> Router Class Initialized
INFO - 2024-12-02 13:11:22 --> Output Class Initialized
INFO - 2024-12-02 13:11:22 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:22 --> CSRF cookie sent
INFO - 2024-12-02 13:11:22 --> Input Class Initialized
INFO - 2024-12-02 13:11:22 --> Language Class Initialized
INFO - 2024-12-02 13:11:22 --> Loader Class Initialized
INFO - 2024-12-02 13:11:22 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:22 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:22 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:22 --> Controller Class Initialized
INFO - 2024-12-02 13:11:22 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 13:11:22 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:22 --> Total execution time: 0.0652
INFO - 2024-12-02 13:11:22 --> Config Class Initialized
INFO - 2024-12-02 13:11:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:22 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:22 --> URI Class Initialized
INFO - 2024-12-02 13:11:22 --> Router Class Initialized
INFO - 2024-12-02 13:11:22 --> Output Class Initialized
INFO - 2024-12-02 13:11:22 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:22 --> CSRF cookie sent
INFO - 2024-12-02 13:11:22 --> Input Class Initialized
INFO - 2024-12-02 13:11:22 --> Language Class Initialized
INFO - 2024-12-02 13:11:22 --> Loader Class Initialized
INFO - 2024-12-02 13:11:22 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:22 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:22 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:22 --> Controller Class Initialized
INFO - 2024-12-02 13:11:22 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:22 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:22 --> Config Class Initialized
INFO - 2024-12-02 13:11:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:22 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:22 --> URI Class Initialized
INFO - 2024-12-02 13:11:22 --> Router Class Initialized
INFO - 2024-12-02 13:11:22 --> Output Class Initialized
INFO - 2024-12-02 13:11:22 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:22 --> CSRF cookie sent
INFO - 2024-12-02 13:11:22 --> Input Class Initialized
INFO - 2024-12-02 13:11:22 --> Language Class Initialized
INFO - 2024-12-02 13:11:22 --> Loader Class Initialized
INFO - 2024-12-02 13:11:22 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:22 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:22 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:22 --> Controller Class Initialized
INFO - 2024-12-02 13:11:22 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:22 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:22 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:22 --> Total execution time: 0.0493
INFO - 2024-12-02 13:11:23 --> Config Class Initialized
INFO - 2024-12-02 13:11:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:23 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:23 --> URI Class Initialized
INFO - 2024-12-02 13:11:23 --> Router Class Initialized
INFO - 2024-12-02 13:11:23 --> Output Class Initialized
INFO - 2024-12-02 13:11:23 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:23 --> CSRF cookie sent
INFO - 2024-12-02 13:11:23 --> Input Class Initialized
INFO - 2024-12-02 13:11:23 --> Language Class Initialized
INFO - 2024-12-02 13:11:23 --> Loader Class Initialized
INFO - 2024-12-02 13:11:23 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:23 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:23 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:23 --> Controller Class Initialized
INFO - 2024-12-02 13:11:23 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:23 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:23 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:23 --> Total execution time: 0.0689
INFO - 2024-12-02 13:11:23 --> Config Class Initialized
INFO - 2024-12-02 13:11:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:23 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:23 --> URI Class Initialized
INFO - 2024-12-02 13:11:23 --> Router Class Initialized
INFO - 2024-12-02 13:11:23 --> Output Class Initialized
INFO - 2024-12-02 13:11:23 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:23 --> CSRF cookie sent
INFO - 2024-12-02 13:11:23 --> Input Class Initialized
INFO - 2024-12-02 13:11:23 --> Language Class Initialized
INFO - 2024-12-02 13:11:23 --> Loader Class Initialized
INFO - 2024-12-02 13:11:23 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:23 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:24 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:24 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:24 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:24 --> Controller Class Initialized
INFO - 2024-12-02 13:11:24 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:24 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:24 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:24 --> Total execution time: 0.0846
INFO - 2024-12-02 13:11:24 --> Config Class Initialized
INFO - 2024-12-02 13:11:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:24 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:24 --> URI Class Initialized
INFO - 2024-12-02 13:11:24 --> Router Class Initialized
INFO - 2024-12-02 13:11:24 --> Output Class Initialized
INFO - 2024-12-02 13:11:24 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:24 --> CSRF cookie sent
INFO - 2024-12-02 13:11:24 --> Input Class Initialized
INFO - 2024-12-02 13:11:24 --> Language Class Initialized
INFO - 2024-12-02 13:11:24 --> Loader Class Initialized
INFO - 2024-12-02 13:11:24 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:24 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:24 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:24 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:24 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:24 --> Controller Class Initialized
INFO - 2024-12-02 13:11:24 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:24 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:24 --> Config Class Initialized
INFO - 2024-12-02 13:11:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:24 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:24 --> URI Class Initialized
INFO - 2024-12-02 13:11:24 --> Router Class Initialized
INFO - 2024-12-02 13:11:24 --> Output Class Initialized
INFO - 2024-12-02 13:11:24 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:24 --> CSRF cookie sent
INFO - 2024-12-02 13:11:24 --> Input Class Initialized
INFO - 2024-12-02 13:11:24 --> Language Class Initialized
INFO - 2024-12-02 13:11:24 --> Loader Class Initialized
INFO - 2024-12-02 13:11:24 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:24 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:24 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:24 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:24 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:24 --> Controller Class Initialized
INFO - 2024-12-02 13:11:24 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:24 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:24 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:24 --> Total execution time: 0.0533
INFO - 2024-12-02 13:11:25 --> Config Class Initialized
INFO - 2024-12-02 13:11:25 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:25 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:25 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:25 --> URI Class Initialized
INFO - 2024-12-02 13:11:25 --> Router Class Initialized
INFO - 2024-12-02 13:11:25 --> Output Class Initialized
INFO - 2024-12-02 13:11:25 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:25 --> CSRF cookie sent
INFO - 2024-12-02 13:11:25 --> Input Class Initialized
INFO - 2024-12-02 13:11:25 --> Language Class Initialized
INFO - 2024-12-02 13:11:25 --> Loader Class Initialized
INFO - 2024-12-02 13:11:25 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:25 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:25 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:25 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:25 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:25 --> Controller Class Initialized
INFO - 2024-12-02 13:11:25 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:25 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:25 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:25 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:25 --> Total execution time: 0.1071
INFO - 2024-12-02 13:11:28 --> Config Class Initialized
INFO - 2024-12-02 13:11:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:28 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:28 --> URI Class Initialized
INFO - 2024-12-02 13:11:28 --> Router Class Initialized
INFO - 2024-12-02 13:11:28 --> Output Class Initialized
INFO - 2024-12-02 13:11:28 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:28 --> CSRF cookie sent
INFO - 2024-12-02 13:11:28 --> Input Class Initialized
INFO - 2024-12-02 13:11:28 --> Language Class Initialized
INFO - 2024-12-02 13:11:28 --> Loader Class Initialized
INFO - 2024-12-02 13:11:28 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:28 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:28 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:28 --> Controller Class Initialized
INFO - 2024-12-02 13:11:28 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:28 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:28 --> Config Class Initialized
INFO - 2024-12-02 13:11:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:28 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:28 --> URI Class Initialized
INFO - 2024-12-02 13:11:28 --> Router Class Initialized
INFO - 2024-12-02 13:11:28 --> Output Class Initialized
INFO - 2024-12-02 13:11:28 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:28 --> CSRF cookie sent
INFO - 2024-12-02 13:11:28 --> Input Class Initialized
INFO - 2024-12-02 13:11:28 --> Language Class Initialized
INFO - 2024-12-02 13:11:28 --> Loader Class Initialized
INFO - 2024-12-02 13:11:28 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:28 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:28 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:28 --> Controller Class Initialized
INFO - 2024-12-02 13:11:28 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:28 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:28 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:28 --> Total execution time: 0.0572
INFO - 2024-12-02 13:11:29 --> Config Class Initialized
INFO - 2024-12-02 13:11:29 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:29 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:29 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:29 --> URI Class Initialized
INFO - 2024-12-02 13:11:29 --> Router Class Initialized
INFO - 2024-12-02 13:11:29 --> Output Class Initialized
INFO - 2024-12-02 13:11:29 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:29 --> CSRF cookie sent
INFO - 2024-12-02 13:11:29 --> Input Class Initialized
INFO - 2024-12-02 13:11:29 --> Language Class Initialized
INFO - 2024-12-02 13:11:29 --> Loader Class Initialized
INFO - 2024-12-02 13:11:29 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:29 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:29 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:29 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:29 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:29 --> Controller Class Initialized
INFO - 2024-12-02 13:11:29 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:29 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:29 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:29 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:29 --> Total execution time: 0.0661
INFO - 2024-12-02 13:11:30 --> Config Class Initialized
INFO - 2024-12-02 13:11:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:30 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:30 --> URI Class Initialized
INFO - 2024-12-02 13:11:30 --> Router Class Initialized
INFO - 2024-12-02 13:11:30 --> Output Class Initialized
INFO - 2024-12-02 13:11:30 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:30 --> CSRF cookie sent
INFO - 2024-12-02 13:11:30 --> Input Class Initialized
INFO - 2024-12-02 13:11:30 --> Language Class Initialized
INFO - 2024-12-02 13:11:30 --> Loader Class Initialized
INFO - 2024-12-02 13:11:30 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:30 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:30 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:30 --> Controller Class Initialized
INFO - 2024-12-02 13:11:30 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:30 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:30 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:30 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:30 --> Total execution time: 0.1272
INFO - 2024-12-02 13:11:31 --> Config Class Initialized
INFO - 2024-12-02 13:11:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:31 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:31 --> URI Class Initialized
INFO - 2024-12-02 13:11:31 --> Router Class Initialized
INFO - 2024-12-02 13:11:31 --> Output Class Initialized
INFO - 2024-12-02 13:11:31 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:31 --> CSRF cookie sent
INFO - 2024-12-02 13:11:31 --> Input Class Initialized
INFO - 2024-12-02 13:11:31 --> Language Class Initialized
INFO - 2024-12-02 13:11:31 --> Loader Class Initialized
INFO - 2024-12-02 13:11:31 --> Config Class Initialized
INFO - 2024-12-02 13:11:31 --> Hooks Class Initialized
INFO - 2024-12-02 13:11:31 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:31 --> Helper loaded: form_helper
DEBUG - 2024-12-02 13:11:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:31 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:31 --> URI Class Initialized
INFO - 2024-12-02 13:11:31 --> Database Driver Class Initialized
INFO - 2024-12-02 13:11:31 --> Router Class Initialized
INFO - 2024-12-02 13:11:31 --> Output Class Initialized
INFO - 2024-12-02 13:11:31 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-12-02 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:31 --> CSRF cookie sent
INFO - 2024-12-02 13:11:31 --> Input Class Initialized
INFO - 2024-12-02 13:11:31 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:31 --> Language Class Initialized
INFO - 2024-12-02 13:11:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:31 --> Controller Class Initialized
INFO - 2024-12-02 13:11:31 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:31 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:31 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:31 --> Total execution time: 0.0797
INFO - 2024-12-02 13:11:31 --> Loader Class Initialized
INFO - 2024-12-02 13:11:31 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:31 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:31 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:31 --> Controller Class Initialized
INFO - 2024-12-02 13:11:31 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:31 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:31 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:31 --> Total execution time: 0.1091
INFO - 2024-12-02 13:11:31 --> Config Class Initialized
INFO - 2024-12-02 13:11:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:31 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:32 --> URI Class Initialized
INFO - 2024-12-02 13:11:32 --> Router Class Initialized
INFO - 2024-12-02 13:11:32 --> Output Class Initialized
INFO - 2024-12-02 13:11:32 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:32 --> CSRF cookie sent
INFO - 2024-12-02 13:11:32 --> Input Class Initialized
INFO - 2024-12-02 13:11:32 --> Language Class Initialized
INFO - 2024-12-02 13:11:32 --> Loader Class Initialized
INFO - 2024-12-02 13:11:32 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:32 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:32 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:32 --> Controller Class Initialized
INFO - 2024-12-02 13:11:32 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:32 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:32 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:32 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:32 --> Total execution time: 0.1272
INFO - 2024-12-02 13:11:32 --> Config Class Initialized
INFO - 2024-12-02 13:11:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:32 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:32 --> URI Class Initialized
INFO - 2024-12-02 13:11:32 --> Router Class Initialized
INFO - 2024-12-02 13:11:32 --> Output Class Initialized
INFO - 2024-12-02 13:11:32 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:32 --> CSRF cookie sent
INFO - 2024-12-02 13:11:32 --> Input Class Initialized
INFO - 2024-12-02 13:11:32 --> Language Class Initialized
INFO - 2024-12-02 13:11:32 --> Loader Class Initialized
INFO - 2024-12-02 13:11:32 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:32 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:32 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:32 --> Controller Class Initialized
INFO - 2024-12-02 13:11:32 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:32 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:32 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:32 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:32 --> Total execution time: 0.0786
INFO - 2024-12-02 13:11:32 --> Config Class Initialized
INFO - 2024-12-02 13:11:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:32 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:32 --> URI Class Initialized
INFO - 2024-12-02 13:11:32 --> Router Class Initialized
INFO - 2024-12-02 13:11:32 --> Output Class Initialized
INFO - 2024-12-02 13:11:32 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:32 --> CSRF cookie sent
INFO - 2024-12-02 13:11:32 --> Input Class Initialized
INFO - 2024-12-02 13:11:32 --> Language Class Initialized
INFO - 2024-12-02 13:11:32 --> Loader Class Initialized
INFO - 2024-12-02 13:11:32 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:32 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:32 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:32 --> Controller Class Initialized
INFO - 2024-12-02 13:11:32 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:32 --> Config Class Initialized
INFO - 2024-12-02 13:11:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:32 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:32 --> URI Class Initialized
INFO - 2024-12-02 13:11:32 --> Router Class Initialized
INFO - 2024-12-02 13:11:32 --> Output Class Initialized
INFO - 2024-12-02 13:11:32 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:32 --> CSRF cookie sent
INFO - 2024-12-02 13:11:32 --> Input Class Initialized
INFO - 2024-12-02 13:11:32 --> Language Class Initialized
INFO - 2024-12-02 13:11:32 --> Loader Class Initialized
INFO - 2024-12-02 13:11:32 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:32 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 13:11:33 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:33 --> Total execution time: 0.2979
INFO - 2024-12-02 13:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:33 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:33 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:33 --> Controller Class Initialized
INFO - 2024-12-02 13:11:33 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:33 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:33 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 13:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-02 13:11:33 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:33 --> Total execution time: 0.1923
INFO - 2024-12-02 13:11:34 --> Config Class Initialized
INFO - 2024-12-02 13:11:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:34 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:34 --> URI Class Initialized
INFO - 2024-12-02 13:11:34 --> Router Class Initialized
INFO - 2024-12-02 13:11:34 --> Output Class Initialized
INFO - 2024-12-02 13:11:34 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:34 --> CSRF cookie sent
INFO - 2024-12-02 13:11:34 --> Input Class Initialized
INFO - 2024-12-02 13:11:34 --> Language Class Initialized
INFO - 2024-12-02 13:11:34 --> Loader Class Initialized
INFO - 2024-12-02 13:11:34 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:34 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:34 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:34 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:34 --> Controller Class Initialized
INFO - 2024-12-02 13:11:34 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 13:11:34 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:34 --> Total execution time: 0.0853
INFO - 2024-12-02 13:11:35 --> Config Class Initialized
INFO - 2024-12-02 13:11:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:35 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:35 --> URI Class Initialized
INFO - 2024-12-02 13:11:35 --> Router Class Initialized
INFO - 2024-12-02 13:11:35 --> Output Class Initialized
INFO - 2024-12-02 13:11:35 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:35 --> CSRF cookie sent
INFO - 2024-12-02 13:11:35 --> Input Class Initialized
INFO - 2024-12-02 13:11:35 --> Language Class Initialized
INFO - 2024-12-02 13:11:35 --> Loader Class Initialized
INFO - 2024-12-02 13:11:35 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:35 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:35 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:35 --> Controller Class Initialized
INFO - 2024-12-02 13:11:35 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:35 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:35 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:35 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 13:11:35 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:35 --> Total execution time: 0.1578
INFO - 2024-12-02 13:11:38 --> Config Class Initialized
INFO - 2024-12-02 13:11:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:38 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:38 --> URI Class Initialized
INFO - 2024-12-02 13:11:38 --> Router Class Initialized
INFO - 2024-12-02 13:11:38 --> Output Class Initialized
INFO - 2024-12-02 13:11:38 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:38 --> CSRF cookie sent
INFO - 2024-12-02 13:11:38 --> CSRF token verified
INFO - 2024-12-02 13:11:38 --> Input Class Initialized
INFO - 2024-12-02 13:11:38 --> Language Class Initialized
INFO - 2024-12-02 13:11:38 --> Loader Class Initialized
INFO - 2024-12-02 13:11:38 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:38 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:38 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:38 --> Controller Class Initialized
INFO - 2024-12-02 13:11:38 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:38 --> Config Class Initialized
INFO - 2024-12-02 13:11:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:38 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:38 --> URI Class Initialized
INFO - 2024-12-02 13:11:38 --> Router Class Initialized
INFO - 2024-12-02 13:11:38 --> Output Class Initialized
INFO - 2024-12-02 13:11:38 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:38 --> CSRF cookie sent
INFO - 2024-12-02 13:11:38 --> Input Class Initialized
INFO - 2024-12-02 13:11:38 --> Language Class Initialized
INFO - 2024-12-02 13:11:38 --> Loader Class Initialized
INFO - 2024-12-02 13:11:38 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:38 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:38 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:38 --> Controller Class Initialized
INFO - 2024-12-02 13:11:38 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:11:38 --> Query result: stdClass Object
(
    [view_count] => 37
)

INFO - 2024-12-02 13:11:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:11:38 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:38 --> Total execution time: 0.1915
INFO - 2024-12-02 13:11:39 --> Config Class Initialized
INFO - 2024-12-02 13:11:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:39 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:39 --> URI Class Initialized
INFO - 2024-12-02 13:11:39 --> Router Class Initialized
INFO - 2024-12-02 13:11:39 --> Output Class Initialized
INFO - 2024-12-02 13:11:39 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:39 --> CSRF cookie sent
INFO - 2024-12-02 13:11:39 --> Input Class Initialized
INFO - 2024-12-02 13:11:39 --> Language Class Initialized
ERROR - 2024-12-02 13:11:39 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:11:50 --> Config Class Initialized
INFO - 2024-12-02 13:11:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:50 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:50 --> URI Class Initialized
INFO - 2024-12-02 13:11:50 --> Router Class Initialized
INFO - 2024-12-02 13:11:50 --> Output Class Initialized
INFO - 2024-12-02 13:11:50 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:50 --> CSRF cookie sent
INFO - 2024-12-02 13:11:50 --> Input Class Initialized
INFO - 2024-12-02 13:11:50 --> Language Class Initialized
INFO - 2024-12-02 13:11:50 --> Loader Class Initialized
INFO - 2024-12-02 13:11:50 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:50 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:51 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:51 --> Controller Class Initialized
INFO - 2024-12-02 13:11:51 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:51 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:51 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:51 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-02 13:11:51 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:51 --> Total execution time: 0.0764
INFO - 2024-12-02 13:11:56 --> Config Class Initialized
INFO - 2024-12-02 13:11:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:11:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:11:56 --> Utf8 Class Initialized
INFO - 2024-12-02 13:11:56 --> URI Class Initialized
INFO - 2024-12-02 13:11:56 --> Router Class Initialized
INFO - 2024-12-02 13:11:56 --> Output Class Initialized
INFO - 2024-12-02 13:11:56 --> Security Class Initialized
DEBUG - 2024-12-02 13:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:11:56 --> CSRF cookie sent
INFO - 2024-12-02 13:11:56 --> Input Class Initialized
INFO - 2024-12-02 13:11:56 --> Language Class Initialized
INFO - 2024-12-02 13:11:56 --> Loader Class Initialized
INFO - 2024-12-02 13:11:56 --> Helper loaded: url_helper
INFO - 2024-12-02 13:11:56 --> Helper loaded: form_helper
INFO - 2024-12-02 13:11:56 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:11:56 --> Form Validation Class Initialized
INFO - 2024-12-02 13:11:56 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:11:56 --> Controller Class Initialized
INFO - 2024-12-02 13:11:56 --> Model "User_model" initialized
INFO - 2024-12-02 13:11:56 --> Model "Category_model" initialized
INFO - 2024-12-02 13:11:56 --> Model "Review_model" initialized
INFO - 2024-12-02 13:11:56 --> Model "News_model" initialized
INFO - 2024-12-02 13:11:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:11:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:11:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:11:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-02 13:11:56 --> Final output sent to browser
DEBUG - 2024-12-02 13:11:56 --> Total execution time: 0.0709
INFO - 2024-12-02 13:16:56 --> Config Class Initialized
INFO - 2024-12-02 13:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:16:56 --> Utf8 Class Initialized
INFO - 2024-12-02 13:16:56 --> URI Class Initialized
INFO - 2024-12-02 13:16:56 --> Router Class Initialized
INFO - 2024-12-02 13:16:56 --> Output Class Initialized
INFO - 2024-12-02 13:16:56 --> Security Class Initialized
DEBUG - 2024-12-02 13:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:16:56 --> CSRF cookie sent
INFO - 2024-12-02 13:16:56 --> Input Class Initialized
INFO - 2024-12-02 13:16:56 --> Language Class Initialized
INFO - 2024-12-02 13:16:56 --> Loader Class Initialized
INFO - 2024-12-02 13:16:56 --> Helper loaded: url_helper
INFO - 2024-12-02 13:16:56 --> Helper loaded: form_helper
INFO - 2024-12-02 13:16:57 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:16:57 --> Form Validation Class Initialized
INFO - 2024-12-02 13:16:57 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:16:57 --> Controller Class Initialized
INFO - 2024-12-02 13:16:57 --> Model "User_model" initialized
INFO - 2024-12-02 13:16:57 --> Model "Category_model" initialized
INFO - 2024-12-02 13:16:57 --> Model "Review_model" initialized
INFO - 2024-12-02 13:16:57 --> Model "News_model" initialized
INFO - 2024-12-02 13:16:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:16:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:16:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:16:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-02 13:16:57 --> Final output sent to browser
DEBUG - 2024-12-02 13:16:57 --> Total execution time: 0.5777
INFO - 2024-12-02 13:23:50 --> Config Class Initialized
INFO - 2024-12-02 13:23:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:23:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:23:50 --> Utf8 Class Initialized
INFO - 2024-12-02 13:23:51 --> URI Class Initialized
DEBUG - 2024-12-02 13:23:51 --> No URI present. Default controller set.
INFO - 2024-12-02 13:23:51 --> Router Class Initialized
INFO - 2024-12-02 13:23:51 --> Output Class Initialized
INFO - 2024-12-02 13:23:51 --> Security Class Initialized
DEBUG - 2024-12-02 13:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:23:51 --> CSRF cookie sent
INFO - 2024-12-02 13:23:51 --> Input Class Initialized
INFO - 2024-12-02 13:23:51 --> Language Class Initialized
INFO - 2024-12-02 13:23:51 --> Loader Class Initialized
INFO - 2024-12-02 13:23:51 --> Helper loaded: url_helper
INFO - 2024-12-02 13:23:51 --> Helper loaded: form_helper
INFO - 2024-12-02 13:23:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:23:51 --> Form Validation Class Initialized
INFO - 2024-12-02 13:23:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:23:51 --> Controller Class Initialized
INFO - 2024-12-02 13:23:51 --> Model "User_model" initialized
INFO - 2024-12-02 13:23:51 --> Model "Category_model" initialized
INFO - 2024-12-02 13:23:51 --> Model "Review_model" initialized
INFO - 2024-12-02 13:23:51 --> Model "News_model" initialized
INFO - 2024-12-02 13:23:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:23:51 --> Query result: stdClass Object
(
    [view_count] => 38
)

INFO - 2024-12-02 13:23:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:23:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:23:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:23:51 --> Final output sent to browser
DEBUG - 2024-12-02 13:23:51 --> Total execution time: 0.9442
INFO - 2024-12-02 13:24:00 --> Config Class Initialized
INFO - 2024-12-02 13:24:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:24:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:24:00 --> Utf8 Class Initialized
INFO - 2024-12-02 13:24:00 --> URI Class Initialized
DEBUG - 2024-12-02 13:24:00 --> No URI present. Default controller set.
INFO - 2024-12-02 13:24:00 --> Router Class Initialized
INFO - 2024-12-02 13:24:00 --> Output Class Initialized
INFO - 2024-12-02 13:24:00 --> Security Class Initialized
DEBUG - 2024-12-02 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:24:00 --> CSRF cookie sent
INFO - 2024-12-02 13:24:00 --> Input Class Initialized
INFO - 2024-12-02 13:24:00 --> Language Class Initialized
INFO - 2024-12-02 13:24:00 --> Loader Class Initialized
INFO - 2024-12-02 13:24:00 --> Helper loaded: url_helper
INFO - 2024-12-02 13:24:00 --> Helper loaded: form_helper
INFO - 2024-12-02 13:24:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:24:00 --> Form Validation Class Initialized
INFO - 2024-12-02 13:24:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:24:00 --> Controller Class Initialized
INFO - 2024-12-02 13:24:00 --> Model "User_model" initialized
INFO - 2024-12-02 13:24:00 --> Model "Category_model" initialized
INFO - 2024-12-02 13:24:00 --> Model "Review_model" initialized
INFO - 2024-12-02 13:24:00 --> Model "News_model" initialized
INFO - 2024-12-02 13:24:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:24:00 --> Query result: stdClass Object
(
    [view_count] => 39
)

INFO - 2024-12-02 13:24:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:24:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:24:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:24:00 --> Final output sent to browser
DEBUG - 2024-12-02 13:24:00 --> Total execution time: 0.1871
INFO - 2024-12-02 13:24:19 --> Config Class Initialized
INFO - 2024-12-02 13:24:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:24:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:24:19 --> Utf8 Class Initialized
INFO - 2024-12-02 13:24:19 --> URI Class Initialized
DEBUG - 2024-12-02 13:24:19 --> No URI present. Default controller set.
INFO - 2024-12-02 13:24:19 --> Router Class Initialized
INFO - 2024-12-02 13:24:19 --> Output Class Initialized
INFO - 2024-12-02 13:24:19 --> Security Class Initialized
DEBUG - 2024-12-02 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:24:19 --> CSRF cookie sent
INFO - 2024-12-02 13:24:19 --> Input Class Initialized
INFO - 2024-12-02 13:24:19 --> Language Class Initialized
INFO - 2024-12-02 13:24:19 --> Loader Class Initialized
INFO - 2024-12-02 13:24:19 --> Helper loaded: url_helper
INFO - 2024-12-02 13:24:19 --> Helper loaded: form_helper
INFO - 2024-12-02 13:24:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:24:19 --> Form Validation Class Initialized
INFO - 2024-12-02 13:24:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:24:19 --> Controller Class Initialized
INFO - 2024-12-02 13:24:19 --> Model "User_model" initialized
INFO - 2024-12-02 13:24:19 --> Model "Category_model" initialized
INFO - 2024-12-02 13:24:19 --> Model "Review_model" initialized
INFO - 2024-12-02 13:24:19 --> Model "News_model" initialized
INFO - 2024-12-02 13:24:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:24:19 --> Query result: stdClass Object
(
    [view_count] => 40
)

INFO - 2024-12-02 13:24:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:24:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:24:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:24:19 --> Final output sent to browser
DEBUG - 2024-12-02 13:24:19 --> Total execution time: 0.2366
INFO - 2024-12-02 13:24:25 --> Config Class Initialized
INFO - 2024-12-02 13:24:25 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:24:25 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:24:25 --> Utf8 Class Initialized
INFO - 2024-12-02 13:24:25 --> URI Class Initialized
DEBUG - 2024-12-02 13:24:25 --> No URI present. Default controller set.
INFO - 2024-12-02 13:24:25 --> Router Class Initialized
INFO - 2024-12-02 13:24:25 --> Output Class Initialized
INFO - 2024-12-02 13:24:25 --> Security Class Initialized
DEBUG - 2024-12-02 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:24:25 --> CSRF cookie sent
INFO - 2024-12-02 13:24:25 --> Input Class Initialized
INFO - 2024-12-02 13:24:25 --> Language Class Initialized
INFO - 2024-12-02 13:24:25 --> Loader Class Initialized
INFO - 2024-12-02 13:24:25 --> Helper loaded: url_helper
INFO - 2024-12-02 13:24:25 --> Helper loaded: form_helper
INFO - 2024-12-02 13:24:25 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:24:25 --> Form Validation Class Initialized
INFO - 2024-12-02 13:24:25 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:24:25 --> Controller Class Initialized
INFO - 2024-12-02 13:24:25 --> Model "User_model" initialized
INFO - 2024-12-02 13:24:25 --> Model "Category_model" initialized
INFO - 2024-12-02 13:24:25 --> Model "Review_model" initialized
INFO - 2024-12-02 13:24:25 --> Model "News_model" initialized
INFO - 2024-12-02 13:24:25 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:24:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:24:25 --> Query result: stdClass Object
(
    [view_count] => 41
)

INFO - 2024-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:24:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:24:25 --> Final output sent to browser
DEBUG - 2024-12-02 13:24:25 --> Total execution time: 0.3923
INFO - 2024-12-02 13:24:40 --> Config Class Initialized
INFO - 2024-12-02 13:24:40 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:24:40 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:24:40 --> Utf8 Class Initialized
INFO - 2024-12-02 13:24:40 --> URI Class Initialized
INFO - 2024-12-02 13:24:41 --> Router Class Initialized
INFO - 2024-12-02 13:24:41 --> Output Class Initialized
INFO - 2024-12-02 13:24:41 --> Security Class Initialized
DEBUG - 2024-12-02 13:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:24:41 --> CSRF cookie sent
INFO - 2024-12-02 13:24:41 --> Input Class Initialized
INFO - 2024-12-02 13:24:41 --> Language Class Initialized
INFO - 2024-12-02 13:24:41 --> Loader Class Initialized
INFO - 2024-12-02 13:24:41 --> Helper loaded: url_helper
INFO - 2024-12-02 13:24:41 --> Helper loaded: form_helper
INFO - 2024-12-02 13:24:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:24:41 --> Form Validation Class Initialized
INFO - 2024-12-02 13:24:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:24:41 --> Controller Class Initialized
INFO - 2024-12-02 13:24:41 --> Model "User_model" initialized
INFO - 2024-12-02 13:24:41 --> Model "Category_model" initialized
INFO - 2024-12-02 13:24:41 --> Model "Review_model" initialized
INFO - 2024-12-02 13:24:41 --> Model "News_model" initialized
INFO - 2024-12-02 13:24:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:24:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:24:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:24:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:24:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-02 13:24:41 --> Final output sent to browser
DEBUG - 2024-12-02 13:24:41 --> Total execution time: 0.3287
INFO - 2024-12-02 13:25:07 --> Config Class Initialized
INFO - 2024-12-02 13:25:07 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:25:08 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:25:08 --> Utf8 Class Initialized
INFO - 2024-12-02 13:25:08 --> URI Class Initialized
DEBUG - 2024-12-02 13:25:08 --> No URI present. Default controller set.
INFO - 2024-12-02 13:25:08 --> Router Class Initialized
INFO - 2024-12-02 13:25:08 --> Output Class Initialized
INFO - 2024-12-02 13:25:08 --> Security Class Initialized
DEBUG - 2024-12-02 13:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:25:08 --> CSRF cookie sent
INFO - 2024-12-02 13:25:08 --> Input Class Initialized
INFO - 2024-12-02 13:25:08 --> Language Class Initialized
INFO - 2024-12-02 13:25:08 --> Loader Class Initialized
INFO - 2024-12-02 13:25:08 --> Helper loaded: url_helper
INFO - 2024-12-02 13:25:08 --> Helper loaded: form_helper
INFO - 2024-12-02 13:25:08 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:25:08 --> Form Validation Class Initialized
INFO - 2024-12-02 13:25:08 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:25:08 --> Controller Class Initialized
INFO - 2024-12-02 13:25:08 --> Model "User_model" initialized
INFO - 2024-12-02 13:25:08 --> Model "Category_model" initialized
INFO - 2024-12-02 13:25:08 --> Model "Review_model" initialized
INFO - 2024-12-02 13:25:08 --> Model "News_model" initialized
INFO - 2024-12-02 13:25:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:25:08 --> Query result: stdClass Object
(
    [view_count] => 42
)

INFO - 2024-12-02 13:25:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:25:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:25:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:25:08 --> Final output sent to browser
DEBUG - 2024-12-02 13:25:08 --> Total execution time: 0.1739
INFO - 2024-12-02 13:35:09 --> Config Class Initialized
INFO - 2024-12-02 13:35:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:35:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:35:09 --> Utf8 Class Initialized
INFO - 2024-12-02 13:35:09 --> URI Class Initialized
DEBUG - 2024-12-02 13:35:09 --> No URI present. Default controller set.
INFO - 2024-12-02 13:35:09 --> Router Class Initialized
INFO - 2024-12-02 13:35:09 --> Output Class Initialized
INFO - 2024-12-02 13:35:09 --> Security Class Initialized
DEBUG - 2024-12-02 13:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:35:09 --> CSRF cookie sent
INFO - 2024-12-02 13:35:09 --> Input Class Initialized
INFO - 2024-12-02 13:35:09 --> Language Class Initialized
INFO - 2024-12-02 13:35:09 --> Loader Class Initialized
INFO - 2024-12-02 13:35:09 --> Helper loaded: url_helper
INFO - 2024-12-02 13:35:09 --> Helper loaded: form_helper
INFO - 2024-12-02 13:35:09 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:35:09 --> Form Validation Class Initialized
INFO - 2024-12-02 13:35:09 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:35:09 --> Controller Class Initialized
INFO - 2024-12-02 13:35:09 --> Model "User_model" initialized
INFO - 2024-12-02 13:35:09 --> Model "Category_model" initialized
INFO - 2024-12-02 13:35:09 --> Model "Review_model" initialized
INFO - 2024-12-02 13:35:09 --> Model "News_model" initialized
INFO - 2024-12-02 13:35:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:35:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:35:09 --> Query result: stdClass Object
(
    [view_count] => 43
)

INFO - 2024-12-02 13:35:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:35:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:35:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:35:09 --> Final output sent to browser
DEBUG - 2024-12-02 13:35:09 --> Total execution time: 0.2179
INFO - 2024-12-02 13:46:18 --> Config Class Initialized
INFO - 2024-12-02 13:46:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:18 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:18 --> URI Class Initialized
INFO - 2024-12-02 13:46:18 --> Router Class Initialized
INFO - 2024-12-02 13:46:18 --> Output Class Initialized
INFO - 2024-12-02 13:46:18 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:18 --> CSRF cookie sent
INFO - 2024-12-02 13:46:18 --> Input Class Initialized
INFO - 2024-12-02 13:46:18 --> Language Class Initialized
INFO - 2024-12-02 13:46:18 --> Loader Class Initialized
INFO - 2024-12-02 13:46:18 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:18 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:18 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:18 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:18 --> Controller Class Initialized
INFO - 2024-12-02 13:46:18 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:18 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:18 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:18 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:46:19 --> Config Class Initialized
INFO - 2024-12-02 13:46:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:19 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:19 --> URI Class Initialized
INFO - 2024-12-02 13:46:19 --> Router Class Initialized
INFO - 2024-12-02 13:46:19 --> Output Class Initialized
INFO - 2024-12-02 13:46:19 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:19 --> CSRF cookie sent
INFO - 2024-12-02 13:46:19 --> Input Class Initialized
INFO - 2024-12-02 13:46:19 --> Language Class Initialized
INFO - 2024-12-02 13:46:19 --> Loader Class Initialized
INFO - 2024-12-02 13:46:19 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:19 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:19 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:19 --> Controller Class Initialized
INFO - 2024-12-02 13:46:19 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:19 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:19 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:19 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:46:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:46:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:46:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 13:46:19 --> Final output sent to browser
DEBUG - 2024-12-02 13:46:19 --> Total execution time: 0.1369
INFO - 2024-12-02 13:46:23 --> Config Class Initialized
INFO - 2024-12-02 13:46:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:23 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:23 --> URI Class Initialized
INFO - 2024-12-02 13:46:23 --> Router Class Initialized
INFO - 2024-12-02 13:46:23 --> Output Class Initialized
INFO - 2024-12-02 13:46:23 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:23 --> CSRF cookie sent
INFO - 2024-12-02 13:46:23 --> CSRF token verified
INFO - 2024-12-02 13:46:23 --> Input Class Initialized
INFO - 2024-12-02 13:46:23 --> Language Class Initialized
INFO - 2024-12-02 13:46:23 --> Loader Class Initialized
INFO - 2024-12-02 13:46:23 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:23 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:23 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:23 --> Controller Class Initialized
INFO - 2024-12-02 13:46:23 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:46:23 --> Config Class Initialized
INFO - 2024-12-02 13:46:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:23 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:23 --> URI Class Initialized
INFO - 2024-12-02 13:46:23 --> Router Class Initialized
INFO - 2024-12-02 13:46:23 --> Output Class Initialized
INFO - 2024-12-02 13:46:23 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:23 --> CSRF cookie sent
INFO - 2024-12-02 13:46:23 --> Input Class Initialized
INFO - 2024-12-02 13:46:23 --> Language Class Initialized
INFO - 2024-12-02 13:46:23 --> Loader Class Initialized
INFO - 2024-12-02 13:46:23 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:23 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:23 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:23 --> Controller Class Initialized
INFO - 2024-12-02 13:46:23 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:46:23 --> Query result: stdClass Object
(
    [view_count] => 44
)

INFO - 2024-12-02 13:46:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:46:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:46:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:46:23 --> Final output sent to browser
DEBUG - 2024-12-02 13:46:23 --> Total execution time: 0.1375
INFO - 2024-12-02 13:46:24 --> Config Class Initialized
INFO - 2024-12-02 13:46:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:24 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:24 --> URI Class Initialized
INFO - 2024-12-02 13:46:24 --> Router Class Initialized
INFO - 2024-12-02 13:46:24 --> Output Class Initialized
INFO - 2024-12-02 13:46:24 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:24 --> CSRF cookie sent
INFO - 2024-12-02 13:46:24 --> Input Class Initialized
INFO - 2024-12-02 13:46:24 --> Language Class Initialized
ERROR - 2024-12-02 13:46:24 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:46:26 --> Config Class Initialized
INFO - 2024-12-02 13:46:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:26 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:26 --> URI Class Initialized
INFO - 2024-12-02 13:46:26 --> Router Class Initialized
INFO - 2024-12-02 13:46:26 --> Output Class Initialized
INFO - 2024-12-02 13:46:26 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:26 --> CSRF cookie sent
INFO - 2024-12-02 13:46:26 --> Input Class Initialized
INFO - 2024-12-02 13:46:26 --> Language Class Initialized
INFO - 2024-12-02 13:46:26 --> Loader Class Initialized
INFO - 2024-12-02 13:46:26 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:26 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:26 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:26 --> Controller Class Initialized
INFO - 2024-12-02 13:46:26 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:26 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:26 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:26 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:46:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:46:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:46:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-02 13:46:26 --> Final output sent to browser
DEBUG - 2024-12-02 13:46:26 --> Total execution time: 0.1055
INFO - 2024-12-02 13:46:51 --> Config Class Initialized
INFO - 2024-12-02 13:46:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:51 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:51 --> URI Class Initialized
INFO - 2024-12-02 13:46:51 --> Router Class Initialized
INFO - 2024-12-02 13:46:51 --> Output Class Initialized
INFO - 2024-12-02 13:46:51 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:51 --> CSRF cookie sent
INFO - 2024-12-02 13:46:51 --> Input Class Initialized
INFO - 2024-12-02 13:46:51 --> Language Class Initialized
INFO - 2024-12-02 13:46:51 --> Loader Class Initialized
INFO - 2024-12-02 13:46:51 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:51 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:51 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:51 --> Controller Class Initialized
INFO - 2024-12-02 13:46:51 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:51 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:51 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:51 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-02 13:46:51 --> Query result: stdClass Object
(
    [view_count] => 45
)

INFO - 2024-12-02 13:46:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:46:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:46:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-02 13:46:51 --> Final output sent to browser
DEBUG - 2024-12-02 13:46:51 --> Total execution time: 0.0968
INFO - 2024-12-02 13:46:51 --> Config Class Initialized
INFO - 2024-12-02 13:46:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:51 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:51 --> URI Class Initialized
INFO - 2024-12-02 13:46:51 --> Router Class Initialized
INFO - 2024-12-02 13:46:51 --> Output Class Initialized
INFO - 2024-12-02 13:46:51 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:51 --> CSRF cookie sent
INFO - 2024-12-02 13:46:51 --> Input Class Initialized
INFO - 2024-12-02 13:46:51 --> Language Class Initialized
ERROR - 2024-12-02 13:46:51 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-02 13:46:55 --> Config Class Initialized
INFO - 2024-12-02 13:46:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:46:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:46:55 --> Utf8 Class Initialized
INFO - 2024-12-02 13:46:55 --> URI Class Initialized
INFO - 2024-12-02 13:46:55 --> Router Class Initialized
INFO - 2024-12-02 13:46:55 --> Output Class Initialized
INFO - 2024-12-02 13:46:55 --> Security Class Initialized
DEBUG - 2024-12-02 13:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:46:55 --> CSRF cookie sent
INFO - 2024-12-02 13:46:55 --> Input Class Initialized
INFO - 2024-12-02 13:46:55 --> Language Class Initialized
INFO - 2024-12-02 13:46:55 --> Loader Class Initialized
INFO - 2024-12-02 13:46:55 --> Helper loaded: url_helper
INFO - 2024-12-02 13:46:55 --> Helper loaded: form_helper
INFO - 2024-12-02 13:46:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:46:55 --> Form Validation Class Initialized
INFO - 2024-12-02 13:46:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:46:55 --> Controller Class Initialized
INFO - 2024-12-02 13:46:55 --> Model "User_model" initialized
INFO - 2024-12-02 13:46:55 --> Model "Category_model" initialized
INFO - 2024-12-02 13:46:55 --> Model "Review_model" initialized
INFO - 2024-12-02 13:46:55 --> Model "News_model" initialized
INFO - 2024-12-02 13:46:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:46:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:46:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:46:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 13:46:56 --> Final output sent to browser
DEBUG - 2024-12-02 13:46:56 --> Total execution time: 0.1232
INFO - 2024-12-02 13:49:15 --> Config Class Initialized
INFO - 2024-12-02 13:49:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:49:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:49:15 --> Utf8 Class Initialized
INFO - 2024-12-02 13:49:15 --> URI Class Initialized
INFO - 2024-12-02 13:49:15 --> Router Class Initialized
INFO - 2024-12-02 13:49:15 --> Output Class Initialized
INFO - 2024-12-02 13:49:15 --> Security Class Initialized
DEBUG - 2024-12-02 13:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:49:15 --> CSRF cookie sent
INFO - 2024-12-02 13:49:15 --> Input Class Initialized
INFO - 2024-12-02 13:49:15 --> Language Class Initialized
INFO - 2024-12-02 13:49:15 --> Loader Class Initialized
INFO - 2024-12-02 13:49:15 --> Helper loaded: url_helper
INFO - 2024-12-02 13:49:15 --> Helper loaded: form_helper
INFO - 2024-12-02 13:49:15 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:49:15 --> Form Validation Class Initialized
INFO - 2024-12-02 13:49:15 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:49:15 --> Controller Class Initialized
INFO - 2024-12-02 13:49:15 --> Model "User_model" initialized
INFO - 2024-12-02 13:49:15 --> Model "Category_model" initialized
INFO - 2024-12-02 13:49:15 --> Model "Review_model" initialized
INFO - 2024-12-02 13:49:15 --> Model "News_model" initialized
INFO - 2024-12-02 13:49:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:49:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:49:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:49:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 13:49:15 --> Final output sent to browser
DEBUG - 2024-12-02 13:49:15 --> Total execution time: 0.2308
INFO - 2024-12-02 13:59:28 --> Config Class Initialized
INFO - 2024-12-02 13:59:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 13:59:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 13:59:28 --> Utf8 Class Initialized
INFO - 2024-12-02 13:59:28 --> URI Class Initialized
INFO - 2024-12-02 13:59:28 --> Router Class Initialized
INFO - 2024-12-02 13:59:28 --> Output Class Initialized
INFO - 2024-12-02 13:59:28 --> Security Class Initialized
DEBUG - 2024-12-02 13:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 13:59:28 --> CSRF cookie sent
INFO - 2024-12-02 13:59:28 --> Input Class Initialized
INFO - 2024-12-02 13:59:28 --> Language Class Initialized
INFO - 2024-12-02 13:59:28 --> Loader Class Initialized
INFO - 2024-12-02 13:59:28 --> Helper loaded: url_helper
INFO - 2024-12-02 13:59:28 --> Helper loaded: form_helper
INFO - 2024-12-02 13:59:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 13:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 13:59:28 --> Form Validation Class Initialized
INFO - 2024-12-02 13:59:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 13:59:28 --> Controller Class Initialized
INFO - 2024-12-02 13:59:28 --> Model "User_model" initialized
INFO - 2024-12-02 13:59:28 --> Model "Category_model" initialized
INFO - 2024-12-02 13:59:28 --> Model "Review_model" initialized
INFO - 2024-12-02 13:59:28 --> Model "News_model" initialized
INFO - 2024-12-02 13:59:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 13:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 13:59:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 13:59:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 13:59:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 13:59:28 --> Final output sent to browser
DEBUG - 2024-12-02 13:59:28 --> Total execution time: 0.6351
INFO - 2024-12-02 14:00:02 --> Config Class Initialized
INFO - 2024-12-02 14:00:02 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:00:02 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:00:02 --> Utf8 Class Initialized
INFO - 2024-12-02 14:00:02 --> URI Class Initialized
INFO - 2024-12-02 14:00:02 --> Router Class Initialized
INFO - 2024-12-02 14:00:02 --> Output Class Initialized
INFO - 2024-12-02 14:00:02 --> Security Class Initialized
DEBUG - 2024-12-02 14:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:00:02 --> CSRF cookie sent
INFO - 2024-12-02 14:00:02 --> Input Class Initialized
INFO - 2024-12-02 14:00:02 --> Language Class Initialized
INFO - 2024-12-02 14:00:02 --> Loader Class Initialized
INFO - 2024-12-02 14:00:02 --> Helper loaded: url_helper
INFO - 2024-12-02 14:00:02 --> Helper loaded: form_helper
INFO - 2024-12-02 14:00:02 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:00:02 --> Form Validation Class Initialized
INFO - 2024-12-02 14:00:02 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:00:02 --> Controller Class Initialized
INFO - 2024-12-02 14:00:02 --> Model "User_model" initialized
INFO - 2024-12-02 14:00:02 --> Model "Category_model" initialized
INFO - 2024-12-02 14:00:02 --> Model "Review_model" initialized
INFO - 2024-12-02 14:00:02 --> Model "News_model" initialized
INFO - 2024-12-02 14:00:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:00:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-12-02 14:00:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting "elseif" or "else" or "endif" C:\xampp\htdocs\CAMA\Culinary\application\views\culinary\culinary_detail.php 254
INFO - 2024-12-02 14:01:21 --> Config Class Initialized
INFO - 2024-12-02 14:01:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:01:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:01:21 --> Utf8 Class Initialized
INFO - 2024-12-02 14:01:21 --> URI Class Initialized
INFO - 2024-12-02 14:01:21 --> Router Class Initialized
INFO - 2024-12-02 14:01:21 --> Output Class Initialized
INFO - 2024-12-02 14:01:21 --> Security Class Initialized
DEBUG - 2024-12-02 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:01:21 --> CSRF cookie sent
INFO - 2024-12-02 14:01:21 --> Input Class Initialized
INFO - 2024-12-02 14:01:21 --> Language Class Initialized
INFO - 2024-12-02 14:01:21 --> Loader Class Initialized
INFO - 2024-12-02 14:01:21 --> Helper loaded: url_helper
INFO - 2024-12-02 14:01:21 --> Helper loaded: form_helper
INFO - 2024-12-02 14:01:21 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:01:21 --> Form Validation Class Initialized
INFO - 2024-12-02 14:01:21 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:01:21 --> Controller Class Initialized
INFO - 2024-12-02 14:01:21 --> Model "User_model" initialized
INFO - 2024-12-02 14:01:21 --> Model "Category_model" initialized
INFO - 2024-12-02 14:01:21 --> Model "Review_model" initialized
INFO - 2024-12-02 14:01:21 --> Model "News_model" initialized
INFO - 2024-12-02 14:01:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:01:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:01:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:01:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:01:21 --> Final output sent to browser
DEBUG - 2024-12-02 14:01:21 --> Total execution time: 0.1256
INFO - 2024-12-02 14:02:15 --> Config Class Initialized
INFO - 2024-12-02 14:02:15 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:02:15 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:02:15 --> Utf8 Class Initialized
INFO - 2024-12-02 14:02:15 --> URI Class Initialized
INFO - 2024-12-02 14:02:15 --> Router Class Initialized
INFO - 2024-12-02 14:02:15 --> Output Class Initialized
INFO - 2024-12-02 14:02:15 --> Security Class Initialized
DEBUG - 2024-12-02 14:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:02:15 --> CSRF cookie sent
INFO - 2024-12-02 14:02:15 --> Input Class Initialized
INFO - 2024-12-02 14:02:15 --> Language Class Initialized
INFO - 2024-12-02 14:02:15 --> Loader Class Initialized
INFO - 2024-12-02 14:02:15 --> Helper loaded: url_helper
INFO - 2024-12-02 14:02:15 --> Helper loaded: form_helper
INFO - 2024-12-02 14:02:15 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:02:15 --> Form Validation Class Initialized
INFO - 2024-12-02 14:02:15 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:02:15 --> Controller Class Initialized
INFO - 2024-12-02 14:02:15 --> Model "User_model" initialized
INFO - 2024-12-02 14:02:15 --> Model "Category_model" initialized
INFO - 2024-12-02 14:02:15 --> Model "Review_model" initialized
INFO - 2024-12-02 14:02:15 --> Model "News_model" initialized
INFO - 2024-12-02 14:02:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:02:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:02:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:02:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:02:15 --> Final output sent to browser
DEBUG - 2024-12-02 14:02:15 --> Total execution time: 0.2825
INFO - 2024-12-02 14:02:52 --> Config Class Initialized
INFO - 2024-12-02 14:02:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:02:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:02:52 --> Utf8 Class Initialized
INFO - 2024-12-02 14:02:52 --> URI Class Initialized
INFO - 2024-12-02 14:02:52 --> Router Class Initialized
INFO - 2024-12-02 14:02:52 --> Output Class Initialized
INFO - 2024-12-02 14:02:52 --> Security Class Initialized
DEBUG - 2024-12-02 14:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:02:52 --> CSRF cookie sent
INFO - 2024-12-02 14:02:52 --> Input Class Initialized
INFO - 2024-12-02 14:02:52 --> Language Class Initialized
INFO - 2024-12-02 14:02:52 --> Loader Class Initialized
INFO - 2024-12-02 14:02:52 --> Helper loaded: url_helper
INFO - 2024-12-02 14:02:52 --> Helper loaded: form_helper
INFO - 2024-12-02 14:02:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:02:52 --> Form Validation Class Initialized
INFO - 2024-12-02 14:02:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:02:52 --> Controller Class Initialized
INFO - 2024-12-02 14:02:52 --> Model "User_model" initialized
INFO - 2024-12-02 14:02:52 --> Model "Category_model" initialized
INFO - 2024-12-02 14:02:52 --> Model "Review_model" initialized
INFO - 2024-12-02 14:02:52 --> Model "News_model" initialized
INFO - 2024-12-02 14:02:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:02:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:02:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:02:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:02:52 --> Final output sent to browser
DEBUG - 2024-12-02 14:02:52 --> Total execution time: 0.2219
INFO - 2024-12-02 14:03:17 --> Config Class Initialized
INFO - 2024-12-02 14:03:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:03:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:03:17 --> Utf8 Class Initialized
INFO - 2024-12-02 14:03:17 --> URI Class Initialized
INFO - 2024-12-02 14:03:17 --> Router Class Initialized
INFO - 2024-12-02 14:03:17 --> Output Class Initialized
INFO - 2024-12-02 14:03:17 --> Security Class Initialized
DEBUG - 2024-12-02 14:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:03:17 --> CSRF cookie sent
INFO - 2024-12-02 14:03:17 --> Input Class Initialized
INFO - 2024-12-02 14:03:17 --> Language Class Initialized
INFO - 2024-12-02 14:03:17 --> Loader Class Initialized
INFO - 2024-12-02 14:03:17 --> Helper loaded: url_helper
INFO - 2024-12-02 14:03:17 --> Helper loaded: form_helper
INFO - 2024-12-02 14:03:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:03:17 --> Form Validation Class Initialized
INFO - 2024-12-02 14:03:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:03:17 --> Controller Class Initialized
INFO - 2024-12-02 14:03:17 --> Model "User_model" initialized
INFO - 2024-12-02 14:03:17 --> Model "Category_model" initialized
INFO - 2024-12-02 14:03:17 --> Model "Review_model" initialized
INFO - 2024-12-02 14:03:17 --> Model "News_model" initialized
INFO - 2024-12-02 14:03:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:03:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:03:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:03:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:03:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:03:17 --> Final output sent to browser
DEBUG - 2024-12-02 14:03:17 --> Total execution time: 0.1347
INFO - 2024-12-02 14:03:23 --> Config Class Initialized
INFO - 2024-12-02 14:03:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:03:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:03:23 --> Utf8 Class Initialized
INFO - 2024-12-02 14:03:23 --> URI Class Initialized
INFO - 2024-12-02 14:03:23 --> Router Class Initialized
INFO - 2024-12-02 14:03:23 --> Output Class Initialized
INFO - 2024-12-02 14:03:23 --> Security Class Initialized
DEBUG - 2024-12-02 14:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:03:23 --> CSRF cookie sent
INFO - 2024-12-02 14:03:23 --> Input Class Initialized
INFO - 2024-12-02 14:03:23 --> Language Class Initialized
INFO - 2024-12-02 14:03:23 --> Loader Class Initialized
INFO - 2024-12-02 14:03:23 --> Helper loaded: url_helper
INFO - 2024-12-02 14:03:23 --> Helper loaded: form_helper
INFO - 2024-12-02 14:03:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:03:23 --> Form Validation Class Initialized
INFO - 2024-12-02 14:03:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:03:23 --> Controller Class Initialized
INFO - 2024-12-02 14:03:23 --> Model "User_model" initialized
INFO - 2024-12-02 14:03:23 --> Model "Category_model" initialized
INFO - 2024-12-02 14:03:23 --> Model "Review_model" initialized
INFO - 2024-12-02 14:03:23 --> Model "News_model" initialized
INFO - 2024-12-02 14:03:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:03:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:03:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:03:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:03:23 --> Final output sent to browser
DEBUG - 2024-12-02 14:03:23 --> Total execution time: 0.0760
INFO - 2024-12-02 14:07:14 --> Config Class Initialized
INFO - 2024-12-02 14:07:14 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:07:14 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:07:14 --> Utf8 Class Initialized
INFO - 2024-12-02 14:07:14 --> URI Class Initialized
INFO - 2024-12-02 14:07:14 --> Router Class Initialized
INFO - 2024-12-02 14:07:14 --> Output Class Initialized
INFO - 2024-12-02 14:07:14 --> Security Class Initialized
DEBUG - 2024-12-02 14:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:07:14 --> CSRF cookie sent
INFO - 2024-12-02 14:07:14 --> Input Class Initialized
INFO - 2024-12-02 14:07:14 --> Language Class Initialized
INFO - 2024-12-02 14:07:14 --> Loader Class Initialized
INFO - 2024-12-02 14:07:14 --> Helper loaded: url_helper
INFO - 2024-12-02 14:07:14 --> Helper loaded: form_helper
INFO - 2024-12-02 14:07:14 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:07:14 --> Form Validation Class Initialized
INFO - 2024-12-02 14:07:14 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:07:14 --> Controller Class Initialized
INFO - 2024-12-02 14:07:14 --> Model "User_model" initialized
INFO - 2024-12-02 14:07:14 --> Model "Category_model" initialized
INFO - 2024-12-02 14:07:14 --> Model "Review_model" initialized
INFO - 2024-12-02 14:07:14 --> Model "News_model" initialized
INFO - 2024-12-02 14:07:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:07:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:07:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:07:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:07:14 --> Final output sent to browser
DEBUG - 2024-12-02 14:07:14 --> Total execution time: 0.3977
INFO - 2024-12-02 14:11:39 --> Config Class Initialized
INFO - 2024-12-02 14:11:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:11:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:11:39 --> Utf8 Class Initialized
INFO - 2024-12-02 14:11:39 --> URI Class Initialized
INFO - 2024-12-02 14:11:39 --> Router Class Initialized
INFO - 2024-12-02 14:11:39 --> Output Class Initialized
INFO - 2024-12-02 14:11:39 --> Security Class Initialized
DEBUG - 2024-12-02 14:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:11:39 --> CSRF cookie sent
INFO - 2024-12-02 14:11:39 --> Input Class Initialized
INFO - 2024-12-02 14:11:39 --> Language Class Initialized
INFO - 2024-12-02 14:11:39 --> Loader Class Initialized
INFO - 2024-12-02 14:11:39 --> Helper loaded: url_helper
INFO - 2024-12-02 14:11:39 --> Helper loaded: form_helper
INFO - 2024-12-02 14:11:40 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:11:40 --> Form Validation Class Initialized
INFO - 2024-12-02 14:11:40 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:11:40 --> Controller Class Initialized
INFO - 2024-12-02 14:11:40 --> Model "User_model" initialized
INFO - 2024-12-02 14:11:40 --> Model "Category_model" initialized
INFO - 2024-12-02 14:11:40 --> Model "Review_model" initialized
INFO - 2024-12-02 14:11:40 --> Model "News_model" initialized
INFO - 2024-12-02 14:11:40 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:11:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:11:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:11:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:11:40 --> Final output sent to browser
DEBUG - 2024-12-02 14:11:40 --> Total execution time: 0.5059
INFO - 2024-12-02 14:19:29 --> Config Class Initialized
INFO - 2024-12-02 14:19:29 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:19:29 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:19:29 --> Utf8 Class Initialized
INFO - 2024-12-02 14:19:29 --> URI Class Initialized
INFO - 2024-12-02 14:19:29 --> Router Class Initialized
INFO - 2024-12-02 14:19:29 --> Output Class Initialized
INFO - 2024-12-02 14:19:29 --> Security Class Initialized
DEBUG - 2024-12-02 14:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:19:29 --> CSRF cookie sent
INFO - 2024-12-02 14:19:29 --> Input Class Initialized
INFO - 2024-12-02 14:19:29 --> Language Class Initialized
INFO - 2024-12-02 14:19:29 --> Loader Class Initialized
INFO - 2024-12-02 14:19:29 --> Helper loaded: url_helper
INFO - 2024-12-02 14:19:29 --> Helper loaded: form_helper
INFO - 2024-12-02 14:19:29 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:19:30 --> Form Validation Class Initialized
INFO - 2024-12-02 14:19:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:19:30 --> Controller Class Initialized
INFO - 2024-12-02 14:19:30 --> Model "User_model" initialized
INFO - 2024-12-02 14:19:30 --> Model "Category_model" initialized
INFO - 2024-12-02 14:19:30 --> Model "Review_model" initialized
INFO - 2024-12-02 14:19:30 --> Model "News_model" initialized
INFO - 2024-12-02 14:19:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:19:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:19:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:19:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:19:30 --> Final output sent to browser
DEBUG - 2024-12-02 14:19:30 --> Total execution time: 0.6451
INFO - 2024-12-02 14:20:47 --> Config Class Initialized
INFO - 2024-12-02 14:20:47 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:20:47 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:20:47 --> Utf8 Class Initialized
INFO - 2024-12-02 14:20:47 --> URI Class Initialized
INFO - 2024-12-02 14:20:47 --> Router Class Initialized
INFO - 2024-12-02 14:20:47 --> Output Class Initialized
INFO - 2024-12-02 14:20:47 --> Security Class Initialized
DEBUG - 2024-12-02 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:20:47 --> CSRF cookie sent
INFO - 2024-12-02 14:20:47 --> Input Class Initialized
INFO - 2024-12-02 14:20:47 --> Language Class Initialized
INFO - 2024-12-02 14:20:47 --> Loader Class Initialized
INFO - 2024-12-02 14:20:47 --> Helper loaded: url_helper
INFO - 2024-12-02 14:20:47 --> Helper loaded: form_helper
INFO - 2024-12-02 14:20:47 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:20:47 --> Form Validation Class Initialized
INFO - 2024-12-02 14:20:47 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:20:47 --> Controller Class Initialized
INFO - 2024-12-02 14:20:47 --> Model "User_model" initialized
INFO - 2024-12-02 14:20:47 --> Model "Category_model" initialized
INFO - 2024-12-02 14:20:47 --> Model "Review_model" initialized
INFO - 2024-12-02 14:20:47 --> Model "News_model" initialized
INFO - 2024-12-02 14:20:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:20:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:20:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:20:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:20:47 --> Final output sent to browser
DEBUG - 2024-12-02 14:20:47 --> Total execution time: 0.3375
INFO - 2024-12-02 14:21:09 --> Config Class Initialized
INFO - 2024-12-02 14:21:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:21:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:21:09 --> Utf8 Class Initialized
INFO - 2024-12-02 14:21:09 --> URI Class Initialized
INFO - 2024-12-02 14:21:10 --> Router Class Initialized
INFO - 2024-12-02 14:21:10 --> Output Class Initialized
INFO - 2024-12-02 14:21:10 --> Security Class Initialized
DEBUG - 2024-12-02 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:21:10 --> CSRF cookie sent
INFO - 2024-12-02 14:21:10 --> Input Class Initialized
INFO - 2024-12-02 14:21:10 --> Language Class Initialized
INFO - 2024-12-02 14:21:10 --> Loader Class Initialized
INFO - 2024-12-02 14:21:10 --> Helper loaded: url_helper
INFO - 2024-12-02 14:21:10 --> Helper loaded: form_helper
INFO - 2024-12-02 14:21:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:21:10 --> Form Validation Class Initialized
INFO - 2024-12-02 14:21:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:21:10 --> Controller Class Initialized
INFO - 2024-12-02 14:21:10 --> Model "User_model" initialized
INFO - 2024-12-02 14:21:10 --> Model "Category_model" initialized
INFO - 2024-12-02 14:21:10 --> Model "Review_model" initialized
INFO - 2024-12-02 14:21:10 --> Model "News_model" initialized
INFO - 2024-12-02 14:21:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:21:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:21:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:21:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-02 14:21:10 --> Final output sent to browser
DEBUG - 2024-12-02 14:21:10 --> Total execution time: 0.1612
INFO - 2024-12-02 14:24:16 --> Config Class Initialized
INFO - 2024-12-02 14:24:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:16 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:16 --> URI Class Initialized
INFO - 2024-12-02 14:24:16 --> Router Class Initialized
INFO - 2024-12-02 14:24:16 --> Output Class Initialized
INFO - 2024-12-02 14:24:16 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:16 --> CSRF cookie sent
INFO - 2024-12-02 14:24:16 --> Input Class Initialized
INFO - 2024-12-02 14:24:16 --> Language Class Initialized
INFO - 2024-12-02 14:24:16 --> Loader Class Initialized
INFO - 2024-12-02 14:24:16 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:16 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:17 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:17 --> Controller Class Initialized
INFO - 2024-12-02 14:24:17 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "Review_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "News_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:17 --> Config Class Initialized
INFO - 2024-12-02 14:24:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:17 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:17 --> URI Class Initialized
INFO - 2024-12-02 14:24:17 --> Router Class Initialized
INFO - 2024-12-02 14:24:17 --> Output Class Initialized
INFO - 2024-12-02 14:24:17 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:17 --> CSRF cookie sent
INFO - 2024-12-02 14:24:17 --> Input Class Initialized
INFO - 2024-12-02 14:24:17 --> Language Class Initialized
INFO - 2024-12-02 14:24:17 --> Loader Class Initialized
INFO - 2024-12-02 14:24:17 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:17 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:17 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:17 --> Controller Class Initialized
INFO - 2024-12-02 14:24:17 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "Review_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "News_model" initialized
INFO - 2024-12-02 14:24:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:24:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:24:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-02 14:24:17 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:17 --> Total execution time: 0.0626
INFO - 2024-12-02 14:24:26 --> Config Class Initialized
INFO - 2024-12-02 14:24:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:26 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:26 --> URI Class Initialized
INFO - 2024-12-02 14:24:26 --> Router Class Initialized
INFO - 2024-12-02 14:24:26 --> Output Class Initialized
INFO - 2024-12-02 14:24:26 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:26 --> CSRF cookie sent
INFO - 2024-12-02 14:24:26 --> CSRF token verified
INFO - 2024-12-02 14:24:26 --> Input Class Initialized
INFO - 2024-12-02 14:24:26 --> Language Class Initialized
INFO - 2024-12-02 14:24:26 --> Loader Class Initialized
INFO - 2024-12-02 14:24:26 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:26 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:26 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:26 --> Controller Class Initialized
INFO - 2024-12-02 14:24:26 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:26 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:26 --> Model "Review_model" initialized
INFO - 2024-12-02 14:24:26 --> Model "News_model" initialized
INFO - 2024-12-02 14:24:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:27 --> Config Class Initialized
INFO - 2024-12-02 14:24:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:27 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:27 --> URI Class Initialized
INFO - 2024-12-02 14:24:27 --> Router Class Initialized
INFO - 2024-12-02 14:24:27 --> Output Class Initialized
INFO - 2024-12-02 14:24:27 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:27 --> CSRF cookie sent
INFO - 2024-12-02 14:24:27 --> Input Class Initialized
INFO - 2024-12-02 14:24:27 --> Language Class Initialized
INFO - 2024-12-02 14:24:27 --> Loader Class Initialized
INFO - 2024-12-02 14:24:27 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:27 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:27 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:27 --> Controller Class Initialized
INFO - 2024-12-02 14:24:27 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:27 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:27 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:24:27 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:27 --> Total execution time: 0.0881
INFO - 2024-12-02 14:24:31 --> Config Class Initialized
INFO - 2024-12-02 14:24:31 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:31 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:31 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:31 --> URI Class Initialized
INFO - 2024-12-02 14:24:31 --> Router Class Initialized
INFO - 2024-12-02 14:24:31 --> Output Class Initialized
INFO - 2024-12-02 14:24:31 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:31 --> CSRF cookie sent
INFO - 2024-12-02 14:24:31 --> Input Class Initialized
INFO - 2024-12-02 14:24:31 --> Language Class Initialized
INFO - 2024-12-02 14:24:31 --> Loader Class Initialized
INFO - 2024-12-02 14:24:31 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:31 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:31 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:31 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:31 --> Controller Class Initialized
INFO - 2024-12-02 14:24:31 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:31 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:24:31 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:31 --> Total execution time: 0.0560
INFO - 2024-12-02 14:24:33 --> Config Class Initialized
INFO - 2024-12-02 14:24:33 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:33 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:33 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:33 --> URI Class Initialized
INFO - 2024-12-02 14:24:33 --> Router Class Initialized
INFO - 2024-12-02 14:24:33 --> Output Class Initialized
INFO - 2024-12-02 14:24:33 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:33 --> CSRF cookie sent
INFO - 2024-12-02 14:24:33 --> Input Class Initialized
INFO - 2024-12-02 14:24:33 --> Language Class Initialized
INFO - 2024-12-02 14:24:33 --> Loader Class Initialized
INFO - 2024-12-02 14:24:33 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:33 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:33 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:33 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:33 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:33 --> Controller Class Initialized
INFO - 2024-12-02 14:24:33 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:33 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:33 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:33 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:24:33 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:33 --> Total execution time: 0.0554
INFO - 2024-12-02 14:24:34 --> Config Class Initialized
INFO - 2024-12-02 14:24:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:34 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:34 --> URI Class Initialized
INFO - 2024-12-02 14:24:34 --> Router Class Initialized
INFO - 2024-12-02 14:24:34 --> Output Class Initialized
INFO - 2024-12-02 14:24:34 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:34 --> CSRF cookie sent
INFO - 2024-12-02 14:24:34 --> Input Class Initialized
INFO - 2024-12-02 14:24:34 --> Language Class Initialized
INFO - 2024-12-02 14:24:34 --> Loader Class Initialized
INFO - 2024-12-02 14:24:34 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:34 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:35 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:35 --> Controller Class Initialized
INFO - 2024-12-02 14:24:35 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:35 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 14:24:35 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:35 --> Total execution time: 0.1018
INFO - 2024-12-02 14:24:49 --> Config Class Initialized
INFO - 2024-12-02 14:24:49 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:49 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:49 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:49 --> URI Class Initialized
INFO - 2024-12-02 14:24:49 --> Router Class Initialized
INFO - 2024-12-02 14:24:49 --> Output Class Initialized
INFO - 2024-12-02 14:24:49 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:49 --> CSRF cookie sent
INFO - 2024-12-02 14:24:49 --> Input Class Initialized
INFO - 2024-12-02 14:24:49 --> Language Class Initialized
INFO - 2024-12-02 14:24:49 --> Loader Class Initialized
INFO - 2024-12-02 14:24:49 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:49 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:49 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:49 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:49 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:49 --> Controller Class Initialized
INFO - 2024-12-02 14:24:49 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:49 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:49 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:24:49 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:49 --> Total execution time: 0.0399
INFO - 2024-12-02 14:24:50 --> Config Class Initialized
INFO - 2024-12-02 14:24:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:50 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:50 --> URI Class Initialized
INFO - 2024-12-02 14:24:50 --> Router Class Initialized
INFO - 2024-12-02 14:24:50 --> Output Class Initialized
INFO - 2024-12-02 14:24:50 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:50 --> CSRF cookie sent
INFO - 2024-12-02 14:24:50 --> Input Class Initialized
INFO - 2024-12-02 14:24:50 --> Language Class Initialized
INFO - 2024-12-02 14:24:50 --> Loader Class Initialized
INFO - 2024-12-02 14:24:50 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:50 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:50 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:50 --> Controller Class Initialized
INFO - 2024-12-02 14:24:50 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:50 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:50 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:24:50 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:50 --> Total execution time: 0.0383
INFO - 2024-12-02 14:24:52 --> Config Class Initialized
INFO - 2024-12-02 14:24:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:52 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:52 --> URI Class Initialized
INFO - 2024-12-02 14:24:52 --> Router Class Initialized
INFO - 2024-12-02 14:24:52 --> Output Class Initialized
INFO - 2024-12-02 14:24:52 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:52 --> CSRF cookie sent
INFO - 2024-12-02 14:24:52 --> Input Class Initialized
INFO - 2024-12-02 14:24:52 --> Language Class Initialized
INFO - 2024-12-02 14:24:52 --> Loader Class Initialized
INFO - 2024-12-02 14:24:52 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:52 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:52 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:52 --> Controller Class Initialized
INFO - 2024-12-02 14:24:52 --> Model "News_model" initialized
INFO - 2024-12-02 14:24:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:24:52 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:52 --> Total execution time: 0.0452
INFO - 2024-12-02 14:24:55 --> Config Class Initialized
INFO - 2024-12-02 14:24:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:24:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:24:55 --> Utf8 Class Initialized
INFO - 2024-12-02 14:24:55 --> URI Class Initialized
INFO - 2024-12-02 14:24:55 --> Router Class Initialized
INFO - 2024-12-02 14:24:55 --> Output Class Initialized
INFO - 2024-12-02 14:24:55 --> Security Class Initialized
DEBUG - 2024-12-02 14:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:24:55 --> CSRF cookie sent
INFO - 2024-12-02 14:24:55 --> Input Class Initialized
INFO - 2024-12-02 14:24:55 --> Language Class Initialized
INFO - 2024-12-02 14:24:55 --> Loader Class Initialized
INFO - 2024-12-02 14:24:55 --> Helper loaded: url_helper
INFO - 2024-12-02 14:24:55 --> Helper loaded: form_helper
INFO - 2024-12-02 14:24:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:24:55 --> Form Validation Class Initialized
INFO - 2024-12-02 14:24:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:24:55 --> Controller Class Initialized
INFO - 2024-12-02 14:24:55 --> Model "Category_model" initialized
INFO - 2024-12-02 14:24:55 --> Model "User_model" initialized
INFO - 2024-12-02 14:24:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:24:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:24:55 --> Final output sent to browser
DEBUG - 2024-12-02 14:24:55 --> Total execution time: 0.0399
INFO - 2024-12-02 14:25:00 --> Config Class Initialized
INFO - 2024-12-02 14:25:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:25:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:25:00 --> Utf8 Class Initialized
INFO - 2024-12-02 14:25:00 --> URI Class Initialized
INFO - 2024-12-02 14:25:00 --> Router Class Initialized
INFO - 2024-12-02 14:25:00 --> Output Class Initialized
INFO - 2024-12-02 14:25:00 --> Security Class Initialized
DEBUG - 2024-12-02 14:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:25:00 --> CSRF cookie sent
INFO - 2024-12-02 14:25:00 --> Input Class Initialized
INFO - 2024-12-02 14:25:00 --> Language Class Initialized
INFO - 2024-12-02 14:25:00 --> Loader Class Initialized
INFO - 2024-12-02 14:25:00 --> Helper loaded: url_helper
INFO - 2024-12-02 14:25:00 --> Helper loaded: form_helper
INFO - 2024-12-02 14:25:00 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:25:00 --> Form Validation Class Initialized
INFO - 2024-12-02 14:25:00 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:25:00 --> Controller Class Initialized
INFO - 2024-12-02 14:25:00 --> Model "Category_model" initialized
INFO - 2024-12-02 14:25:00 --> Model "User_model" initialized
INFO - 2024-12-02 14:25:00 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:25:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-02 14:25:00 --> Final output sent to browser
DEBUG - 2024-12-02 14:25:00 --> Total execution time: 0.1173
INFO - 2024-12-02 14:27:41 --> Config Class Initialized
INFO - 2024-12-02 14:27:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:27:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:27:41 --> Utf8 Class Initialized
INFO - 2024-12-02 14:27:41 --> URI Class Initialized
INFO - 2024-12-02 14:27:41 --> Router Class Initialized
INFO - 2024-12-02 14:27:41 --> Output Class Initialized
INFO - 2024-12-02 14:27:41 --> Security Class Initialized
DEBUG - 2024-12-02 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:27:41 --> CSRF cookie sent
INFO - 2024-12-02 14:27:41 --> Input Class Initialized
INFO - 2024-12-02 14:27:41 --> Language Class Initialized
INFO - 2024-12-02 14:27:41 --> Loader Class Initialized
INFO - 2024-12-02 14:27:41 --> Helper loaded: url_helper
INFO - 2024-12-02 14:27:41 --> Helper loaded: form_helper
INFO - 2024-12-02 14:27:41 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:27:41 --> Form Validation Class Initialized
INFO - 2024-12-02 14:27:41 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:27:41 --> Controller Class Initialized
INFO - 2024-12-02 14:27:41 --> Model "User_model" initialized
INFO - 2024-12-02 14:27:41 --> Model "Category_model" initialized
INFO - 2024-12-02 14:27:41 --> Model "Review_model" initialized
INFO - 2024-12-02 14:27:41 --> Model "News_model" initialized
INFO - 2024-12-02 14:27:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:27:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:27:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:27:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:27:42 --> Final output sent to browser
DEBUG - 2024-12-02 14:27:42 --> Total execution time: 0.5804
INFO - 2024-12-02 14:28:34 --> Config Class Initialized
INFO - 2024-12-02 14:28:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:28:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:28:34 --> Utf8 Class Initialized
INFO - 2024-12-02 14:28:34 --> URI Class Initialized
INFO - 2024-12-02 14:28:34 --> Router Class Initialized
INFO - 2024-12-02 14:28:34 --> Output Class Initialized
INFO - 2024-12-02 14:28:34 --> Security Class Initialized
DEBUG - 2024-12-02 14:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:28:34 --> CSRF cookie sent
INFO - 2024-12-02 14:28:34 --> Input Class Initialized
INFO - 2024-12-02 14:28:34 --> Language Class Initialized
INFO - 2024-12-02 14:28:34 --> Loader Class Initialized
INFO - 2024-12-02 14:28:34 --> Helper loaded: url_helper
INFO - 2024-12-02 14:28:34 --> Helper loaded: form_helper
INFO - 2024-12-02 14:28:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:28:35 --> Form Validation Class Initialized
INFO - 2024-12-02 14:28:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:28:35 --> Controller Class Initialized
INFO - 2024-12-02 14:28:35 --> Model "User_model" initialized
INFO - 2024-12-02 14:28:35 --> Model "Category_model" initialized
INFO - 2024-12-02 14:28:35 --> Model "Review_model" initialized
INFO - 2024-12-02 14:28:35 --> Model "News_model" initialized
INFO - 2024-12-02 14:28:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-02 14:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:28:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-02 14:28:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-02 14:28:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-02 14:28:35 --> Final output sent to browser
DEBUG - 2024-12-02 14:28:35 --> Total execution time: 0.1545
INFO - 2024-12-02 14:28:53 --> Config Class Initialized
INFO - 2024-12-02 14:28:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:28:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:28:53 --> Utf8 Class Initialized
INFO - 2024-12-02 14:28:53 --> URI Class Initialized
INFO - 2024-12-02 14:28:53 --> Router Class Initialized
INFO - 2024-12-02 14:28:53 --> Output Class Initialized
INFO - 2024-12-02 14:28:53 --> Security Class Initialized
DEBUG - 2024-12-02 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:28:53 --> CSRF cookie sent
INFO - 2024-12-02 14:28:53 --> Input Class Initialized
INFO - 2024-12-02 14:28:53 --> Language Class Initialized
INFO - 2024-12-02 14:28:53 --> Loader Class Initialized
INFO - 2024-12-02 14:28:53 --> Helper loaded: url_helper
INFO - 2024-12-02 14:28:53 --> Helper loaded: form_helper
INFO - 2024-12-02 14:28:53 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:28:53 --> Form Validation Class Initialized
INFO - 2024-12-02 14:28:53 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:28:53 --> Controller Class Initialized
INFO - 2024-12-02 14:28:53 --> Model "Category_model" initialized
INFO - 2024-12-02 14:28:53 --> Model "User_model" initialized
INFO - 2024-12-02 14:28:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:28:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:28:53 --> Final output sent to browser
DEBUG - 2024-12-02 14:28:53 --> Total execution time: 0.3678
INFO - 2024-12-02 14:29:01 --> Config Class Initialized
INFO - 2024-12-02 14:29:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:01 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:01 --> URI Class Initialized
INFO - 2024-12-02 14:29:01 --> Router Class Initialized
INFO - 2024-12-02 14:29:01 --> Output Class Initialized
INFO - 2024-12-02 14:29:01 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:01 --> CSRF cookie sent
INFO - 2024-12-02 14:29:01 --> Input Class Initialized
INFO - 2024-12-02 14:29:01 --> Language Class Initialized
INFO - 2024-12-02 14:29:01 --> Loader Class Initialized
INFO - 2024-12-02 14:29:02 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:02 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:02 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:02 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:02 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:02 --> Controller Class Initialized
INFO - 2024-12-02 14:29:02 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:02 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:02 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:29:02 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:02 --> Total execution time: 0.1781
INFO - 2024-12-02 14:29:04 --> Config Class Initialized
INFO - 2024-12-02 14:29:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:04 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:04 --> URI Class Initialized
INFO - 2024-12-02 14:29:04 --> Router Class Initialized
INFO - 2024-12-02 14:29:04 --> Output Class Initialized
INFO - 2024-12-02 14:29:04 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:04 --> CSRF cookie sent
INFO - 2024-12-02 14:29:04 --> Input Class Initialized
INFO - 2024-12-02 14:29:04 --> Language Class Initialized
INFO - 2024-12-02 14:29:04 --> Loader Class Initialized
INFO - 2024-12-02 14:29:04 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:04 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:04 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:04 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:04 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:04 --> Controller Class Initialized
INFO - 2024-12-02 14:29:04 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:04 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:04 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-02 14:29:04 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:04 --> Total execution time: 0.1302
INFO - 2024-12-02 14:29:08 --> Config Class Initialized
INFO - 2024-12-02 14:29:08 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:08 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:08 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:08 --> URI Class Initialized
INFO - 2024-12-02 14:29:08 --> Router Class Initialized
INFO - 2024-12-02 14:29:08 --> Output Class Initialized
INFO - 2024-12-02 14:29:08 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:08 --> CSRF cookie sent
INFO - 2024-12-02 14:29:08 --> Input Class Initialized
INFO - 2024-12-02 14:29:08 --> Language Class Initialized
INFO - 2024-12-02 14:29:08 --> Loader Class Initialized
INFO - 2024-12-02 14:29:08 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:08 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:08 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:08 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:08 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:08 --> Controller Class Initialized
INFO - 2024-12-02 14:29:08 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:08 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:08 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:29:08 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:08 --> Total execution time: 0.0556
INFO - 2024-12-02 14:29:10 --> Config Class Initialized
INFO - 2024-12-02 14:29:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:10 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:10 --> URI Class Initialized
INFO - 2024-12-02 14:29:10 --> Router Class Initialized
INFO - 2024-12-02 14:29:10 --> Output Class Initialized
INFO - 2024-12-02 14:29:10 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:10 --> CSRF cookie sent
INFO - 2024-12-02 14:29:10 --> Input Class Initialized
INFO - 2024-12-02 14:29:10 --> Language Class Initialized
INFO - 2024-12-02 14:29:10 --> Loader Class Initialized
INFO - 2024-12-02 14:29:10 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:10 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:10 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:10 --> Controller Class Initialized
INFO - 2024-12-02 14:29:10 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:10 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:10 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:29:10 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:10 --> Total execution time: 0.0444
INFO - 2024-12-02 14:29:12 --> Config Class Initialized
INFO - 2024-12-02 14:29:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:12 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:12 --> URI Class Initialized
INFO - 2024-12-02 14:29:12 --> Router Class Initialized
INFO - 2024-12-02 14:29:12 --> Output Class Initialized
INFO - 2024-12-02 14:29:12 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:12 --> CSRF cookie sent
INFO - 2024-12-02 14:29:12 --> Input Class Initialized
INFO - 2024-12-02 14:29:12 --> Language Class Initialized
INFO - 2024-12-02 14:29:12 --> Loader Class Initialized
INFO - 2024-12-02 14:29:12 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:12 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:12 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:12 --> Controller Class Initialized
INFO - 2024-12-02 14:29:12 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:12 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-02 14:29:12 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:12 --> Total execution time: 0.0480
INFO - 2024-12-02 14:29:16 --> Config Class Initialized
INFO - 2024-12-02 14:29:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:16 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:16 --> URI Class Initialized
INFO - 2024-12-02 14:29:16 --> Router Class Initialized
INFO - 2024-12-02 14:29:16 --> Output Class Initialized
INFO - 2024-12-02 14:29:16 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:16 --> CSRF cookie sent
INFO - 2024-12-02 14:29:16 --> CSRF token verified
INFO - 2024-12-02 14:29:16 --> Input Class Initialized
INFO - 2024-12-02 14:29:16 --> Language Class Initialized
INFO - 2024-12-02 14:29:16 --> Loader Class Initialized
INFO - 2024-12-02 14:29:16 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:16 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:16 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:16 --> Controller Class Initialized
INFO - 2024-12-02 14:29:16 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:16 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:16 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-02 14:29:17 --> Config Class Initialized
INFO - 2024-12-02 14:29:17 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:17 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:17 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:17 --> URI Class Initialized
INFO - 2024-12-02 14:29:17 --> Router Class Initialized
INFO - 2024-12-02 14:29:17 --> Output Class Initialized
INFO - 2024-12-02 14:29:17 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:17 --> CSRF cookie sent
INFO - 2024-12-02 14:29:17 --> Input Class Initialized
INFO - 2024-12-02 14:29:17 --> Language Class Initialized
INFO - 2024-12-02 14:29:17 --> Loader Class Initialized
INFO - 2024-12-02 14:29:17 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:17 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:17 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:17 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:17 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:17 --> Controller Class Initialized
INFO - 2024-12-02 14:29:17 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:17 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:17 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:29:17 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:17 --> Total execution time: 0.0411
INFO - 2024-12-02 14:29:18 --> Config Class Initialized
INFO - 2024-12-02 14:29:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:18 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:18 --> URI Class Initialized
INFO - 2024-12-02 14:29:18 --> Router Class Initialized
INFO - 2024-12-02 14:29:18 --> Output Class Initialized
INFO - 2024-12-02 14:29:18 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:18 --> CSRF cookie sent
INFO - 2024-12-02 14:29:18 --> Input Class Initialized
INFO - 2024-12-02 14:29:18 --> Language Class Initialized
INFO - 2024-12-02 14:29:18 --> Loader Class Initialized
INFO - 2024-12-02 14:29:18 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:18 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:18 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:18 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:18 --> Controller Class Initialized
INFO - 2024-12-02 14:29:18 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:18 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:18 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:29:18 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:18 --> Total execution time: 0.0748
INFO - 2024-12-02 14:29:30 --> Config Class Initialized
INFO - 2024-12-02 14:29:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:30 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:30 --> URI Class Initialized
INFO - 2024-12-02 14:29:30 --> Router Class Initialized
INFO - 2024-12-02 14:29:30 --> Output Class Initialized
INFO - 2024-12-02 14:29:30 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:30 --> CSRF cookie sent
INFO - 2024-12-02 14:29:30 --> Input Class Initialized
INFO - 2024-12-02 14:29:30 --> Language Class Initialized
INFO - 2024-12-02 14:29:30 --> Loader Class Initialized
INFO - 2024-12-02 14:29:30 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:30 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:30 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:30 --> Controller Class Initialized
INFO - 2024-12-02 14:29:30 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:30 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:30 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:29:30 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:30 --> Total execution time: 0.0592
INFO - 2024-12-02 14:29:35 --> Config Class Initialized
INFO - 2024-12-02 14:29:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:35 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:35 --> URI Class Initialized
INFO - 2024-12-02 14:29:35 --> Router Class Initialized
INFO - 2024-12-02 14:29:35 --> Output Class Initialized
INFO - 2024-12-02 14:29:35 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:35 --> CSRF cookie sent
INFO - 2024-12-02 14:29:35 --> Input Class Initialized
INFO - 2024-12-02 14:29:35 --> Language Class Initialized
INFO - 2024-12-02 14:29:35 --> Loader Class Initialized
INFO - 2024-12-02 14:29:35 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:35 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:35 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:35 --> Controller Class Initialized
INFO - 2024-12-02 14:29:35 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:35 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:29:35 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:35 --> Total execution time: 0.0710
INFO - 2024-12-02 14:29:40 --> Config Class Initialized
INFO - 2024-12-02 14:29:40 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:40 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:40 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:40 --> URI Class Initialized
INFO - 2024-12-02 14:29:40 --> Router Class Initialized
INFO - 2024-12-02 14:29:40 --> Output Class Initialized
INFO - 2024-12-02 14:29:40 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:40 --> CSRF cookie sent
INFO - 2024-12-02 14:29:40 --> Input Class Initialized
INFO - 2024-12-02 14:29:40 --> Language Class Initialized
INFO - 2024-12-02 14:29:40 --> Loader Class Initialized
INFO - 2024-12-02 14:29:40 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:40 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:40 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:40 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:40 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:40 --> Controller Class Initialized
INFO - 2024-12-02 14:29:40 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:40 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:40 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:29:40 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:40 --> Total execution time: 0.0667
INFO - 2024-12-02 14:29:45 --> Config Class Initialized
INFO - 2024-12-02 14:29:45 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:29:45 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:29:45 --> Utf8 Class Initialized
INFO - 2024-12-02 14:29:45 --> URI Class Initialized
INFO - 2024-12-02 14:29:45 --> Router Class Initialized
INFO - 2024-12-02 14:29:45 --> Output Class Initialized
INFO - 2024-12-02 14:29:45 --> Security Class Initialized
DEBUG - 2024-12-02 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:29:45 --> CSRF cookie sent
INFO - 2024-12-02 14:29:45 --> Input Class Initialized
INFO - 2024-12-02 14:29:45 --> Language Class Initialized
INFO - 2024-12-02 14:29:45 --> Loader Class Initialized
INFO - 2024-12-02 14:29:45 --> Helper loaded: url_helper
INFO - 2024-12-02 14:29:45 --> Helper loaded: form_helper
INFO - 2024-12-02 14:29:45 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:29:45 --> Form Validation Class Initialized
INFO - 2024-12-02 14:29:45 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:29:45 --> Controller Class Initialized
INFO - 2024-12-02 14:29:45 --> Model "Category_model" initialized
INFO - 2024-12-02 14:29:45 --> Model "User_model" initialized
INFO - 2024-12-02 14:29:45 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:29:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:29:45 --> Final output sent to browser
DEBUG - 2024-12-02 14:29:45 --> Total execution time: 0.0761
INFO - 2024-12-02 14:37:36 --> Config Class Initialized
INFO - 2024-12-02 14:37:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:37:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:37:36 --> Utf8 Class Initialized
INFO - 2024-12-02 14:37:36 --> URI Class Initialized
INFO - 2024-12-02 14:37:36 --> Router Class Initialized
INFO - 2024-12-02 14:37:36 --> Output Class Initialized
INFO - 2024-12-02 14:37:36 --> Security Class Initialized
DEBUG - 2024-12-02 14:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:37:36 --> CSRF cookie sent
INFO - 2024-12-02 14:37:36 --> Input Class Initialized
INFO - 2024-12-02 14:37:36 --> Language Class Initialized
INFO - 2024-12-02 14:37:36 --> Loader Class Initialized
INFO - 2024-12-02 14:37:36 --> Helper loaded: url_helper
INFO - 2024-12-02 14:37:36 --> Helper loaded: form_helper
INFO - 2024-12-02 14:37:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:37:36 --> Form Validation Class Initialized
INFO - 2024-12-02 14:37:36 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:37:36 --> Controller Class Initialized
INFO - 2024-12-02 14:37:36 --> Model "Category_model" initialized
INFO - 2024-12-02 14:37:36 --> Model "User_model" initialized
INFO - 2024-12-02 14:37:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:37:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:37:36 --> Final output sent to browser
DEBUG - 2024-12-02 14:37:36 --> Total execution time: 0.4093
INFO - 2024-12-02 14:37:43 --> Config Class Initialized
INFO - 2024-12-02 14:37:43 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:37:43 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:37:43 --> Utf8 Class Initialized
INFO - 2024-12-02 14:37:43 --> URI Class Initialized
INFO - 2024-12-02 14:37:43 --> Router Class Initialized
INFO - 2024-12-02 14:37:43 --> Output Class Initialized
INFO - 2024-12-02 14:37:43 --> Security Class Initialized
DEBUG - 2024-12-02 14:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:37:43 --> CSRF cookie sent
INFO - 2024-12-02 14:37:43 --> Input Class Initialized
INFO - 2024-12-02 14:37:43 --> Language Class Initialized
INFO - 2024-12-02 14:37:43 --> Loader Class Initialized
INFO - 2024-12-02 14:37:43 --> Helper loaded: url_helper
INFO - 2024-12-02 14:37:43 --> Helper loaded: form_helper
INFO - 2024-12-02 14:37:43 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:37:43 --> Form Validation Class Initialized
INFO - 2024-12-02 14:37:43 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:37:43 --> Controller Class Initialized
INFO - 2024-12-02 14:37:43 --> Model "Category_model" initialized
INFO - 2024-12-02 14:37:43 --> Model "User_model" initialized
INFO - 2024-12-02 14:37:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:37:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:37:43 --> Final output sent to browser
DEBUG - 2024-12-02 14:37:43 --> Total execution time: 0.0667
INFO - 2024-12-02 14:38:13 --> Config Class Initialized
INFO - 2024-12-02 14:38:13 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:38:13 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:38:13 --> Utf8 Class Initialized
INFO - 2024-12-02 14:38:13 --> URI Class Initialized
INFO - 2024-12-02 14:38:13 --> Router Class Initialized
INFO - 2024-12-02 14:38:13 --> Output Class Initialized
INFO - 2024-12-02 14:38:13 --> Security Class Initialized
DEBUG - 2024-12-02 14:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:38:13 --> CSRF cookie sent
INFO - 2024-12-02 14:38:13 --> Input Class Initialized
INFO - 2024-12-02 14:38:13 --> Language Class Initialized
INFO - 2024-12-02 14:38:13 --> Loader Class Initialized
INFO - 2024-12-02 14:38:13 --> Helper loaded: url_helper
INFO - 2024-12-02 14:38:13 --> Helper loaded: form_helper
INFO - 2024-12-02 14:38:13 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:38:13 --> Form Validation Class Initialized
INFO - 2024-12-02 14:38:13 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:38:13 --> Controller Class Initialized
INFO - 2024-12-02 14:38:13 --> Model "Category_model" initialized
INFO - 2024-12-02 14:38:13 --> Model "User_model" initialized
INFO - 2024-12-02 14:38:13 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:38:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:38:13 --> Final output sent to browser
DEBUG - 2024-12-02 14:38:13 --> Total execution time: 0.0746
INFO - 2024-12-02 14:38:16 --> Config Class Initialized
INFO - 2024-12-02 14:38:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:38:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:38:16 --> Utf8 Class Initialized
INFO - 2024-12-02 14:38:16 --> URI Class Initialized
INFO - 2024-12-02 14:38:16 --> Router Class Initialized
INFO - 2024-12-02 14:38:16 --> Output Class Initialized
INFO - 2024-12-02 14:38:16 --> Security Class Initialized
DEBUG - 2024-12-02 14:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:38:16 --> CSRF cookie sent
INFO - 2024-12-02 14:38:16 --> Input Class Initialized
INFO - 2024-12-02 14:38:16 --> Language Class Initialized
INFO - 2024-12-02 14:38:16 --> Loader Class Initialized
INFO - 2024-12-02 14:38:16 --> Helper loaded: url_helper
INFO - 2024-12-02 14:38:16 --> Helper loaded: form_helper
INFO - 2024-12-02 14:38:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:38:16 --> Form Validation Class Initialized
INFO - 2024-12-02 14:38:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:38:16 --> Controller Class Initialized
INFO - 2024-12-02 14:38:16 --> Model "Category_model" initialized
INFO - 2024-12-02 14:38:16 --> Model "User_model" initialized
INFO - 2024-12-02 14:38:16 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:38:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kategori.php
INFO - 2024-12-02 14:38:16 --> Final output sent to browser
DEBUG - 2024-12-02 14:38:16 --> Total execution time: 0.0600
INFO - 2024-12-02 14:38:21 --> Config Class Initialized
INFO - 2024-12-02 14:38:21 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:38:21 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:38:21 --> Utf8 Class Initialized
INFO - 2024-12-02 14:38:21 --> URI Class Initialized
INFO - 2024-12-02 14:38:21 --> Router Class Initialized
INFO - 2024-12-02 14:38:21 --> Output Class Initialized
INFO - 2024-12-02 14:38:21 --> Security Class Initialized
DEBUG - 2024-12-02 14:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:38:21 --> CSRF cookie sent
INFO - 2024-12-02 14:38:21 --> Input Class Initialized
INFO - 2024-12-02 14:38:21 --> Language Class Initialized
INFO - 2024-12-02 14:38:21 --> Loader Class Initialized
INFO - 2024-12-02 14:38:21 --> Helper loaded: url_helper
INFO - 2024-12-02 14:38:21 --> Helper loaded: form_helper
INFO - 2024-12-02 14:38:21 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:38:21 --> Form Validation Class Initialized
INFO - 2024-12-02 14:38:21 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:38:21 --> Controller Class Initialized
INFO - 2024-12-02 14:38:21 --> Model "Category_model" initialized
INFO - 2024-12-02 14:38:21 --> Model "User_model" initialized
INFO - 2024-12-02 14:38:21 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:38:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:38:21 --> Final output sent to browser
DEBUG - 2024-12-02 14:38:21 --> Total execution time: 0.0735
INFO - 2024-12-02 14:38:48 --> Config Class Initialized
INFO - 2024-12-02 14:38:48 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:38:48 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:38:48 --> Utf8 Class Initialized
INFO - 2024-12-02 14:38:48 --> URI Class Initialized
INFO - 2024-12-02 14:38:48 --> Router Class Initialized
INFO - 2024-12-02 14:38:48 --> Output Class Initialized
INFO - 2024-12-02 14:38:48 --> Security Class Initialized
DEBUG - 2024-12-02 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:38:48 --> CSRF cookie sent
INFO - 2024-12-02 14:38:48 --> Input Class Initialized
INFO - 2024-12-02 14:38:48 --> Language Class Initialized
INFO - 2024-12-02 14:38:48 --> Loader Class Initialized
INFO - 2024-12-02 14:38:48 --> Helper loaded: url_helper
INFO - 2024-12-02 14:38:48 --> Helper loaded: form_helper
INFO - 2024-12-02 14:38:48 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:38:48 --> Form Validation Class Initialized
INFO - 2024-12-02 14:38:48 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:38:48 --> Controller Class Initialized
INFO - 2024-12-02 14:38:48 --> Model "Category_model" initialized
INFO - 2024-12-02 14:38:48 --> Model "User_model" initialized
INFO - 2024-12-02 14:38:48 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:38:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:38:48 --> Final output sent to browser
DEBUG - 2024-12-02 14:38:48 --> Total execution time: 0.0652
INFO - 2024-12-02 14:38:50 --> Config Class Initialized
INFO - 2024-12-02 14:38:50 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:38:50 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:38:50 --> Utf8 Class Initialized
INFO - 2024-12-02 14:38:50 --> URI Class Initialized
INFO - 2024-12-02 14:38:50 --> Router Class Initialized
INFO - 2024-12-02 14:38:50 --> Output Class Initialized
INFO - 2024-12-02 14:38:50 --> Security Class Initialized
DEBUG - 2024-12-02 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:38:50 --> CSRF cookie sent
INFO - 2024-12-02 14:38:50 --> Input Class Initialized
INFO - 2024-12-02 14:38:50 --> Language Class Initialized
INFO - 2024-12-02 14:38:50 --> Loader Class Initialized
INFO - 2024-12-02 14:38:50 --> Helper loaded: url_helper
INFO - 2024-12-02 14:38:50 --> Helper loaded: form_helper
INFO - 2024-12-02 14:38:50 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:38:50 --> Form Validation Class Initialized
INFO - 2024-12-02 14:38:50 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:38:50 --> Controller Class Initialized
INFO - 2024-12-02 14:38:50 --> Model "Category_model" initialized
INFO - 2024-12-02 14:38:50 --> Model "User_model" initialized
INFO - 2024-12-02 14:38:50 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:38:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:38:50 --> Final output sent to browser
DEBUG - 2024-12-02 14:38:50 --> Total execution time: 0.0472
INFO - 2024-12-02 14:39:16 --> Config Class Initialized
INFO - 2024-12-02 14:39:16 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:16 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:16 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:16 --> URI Class Initialized
INFO - 2024-12-02 14:39:16 --> Router Class Initialized
INFO - 2024-12-02 14:39:16 --> Output Class Initialized
INFO - 2024-12-02 14:39:16 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:16 --> CSRF cookie sent
INFO - 2024-12-02 14:39:16 --> Input Class Initialized
INFO - 2024-12-02 14:39:16 --> Language Class Initialized
INFO - 2024-12-02 14:39:16 --> Loader Class Initialized
INFO - 2024-12-02 14:39:16 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:16 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:16 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:16 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:16 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:16 --> Controller Class Initialized
INFO - 2024-12-02 14:39:16 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:16 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:16 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:39:16 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:16 --> Total execution time: 0.0786
INFO - 2024-12-02 14:39:19 --> Config Class Initialized
INFO - 2024-12-02 14:39:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:19 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:19 --> URI Class Initialized
INFO - 2024-12-02 14:39:19 --> Router Class Initialized
INFO - 2024-12-02 14:39:19 --> Output Class Initialized
INFO - 2024-12-02 14:39:19 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:19 --> CSRF cookie sent
INFO - 2024-12-02 14:39:19 --> Input Class Initialized
INFO - 2024-12-02 14:39:19 --> Language Class Initialized
INFO - 2024-12-02 14:39:19 --> Loader Class Initialized
INFO - 2024-12-02 14:39:19 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:19 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:19 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:19 --> Controller Class Initialized
INFO - 2024-12-02 14:39:19 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:19 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:39:19 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:19 --> Total execution time: 0.0621
INFO - 2024-12-02 14:39:23 --> Config Class Initialized
INFO - 2024-12-02 14:39:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:23 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:23 --> URI Class Initialized
INFO - 2024-12-02 14:39:23 --> Router Class Initialized
INFO - 2024-12-02 14:39:23 --> Output Class Initialized
INFO - 2024-12-02 14:39:23 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:23 --> CSRF cookie sent
INFO - 2024-12-02 14:39:23 --> Input Class Initialized
INFO - 2024-12-02 14:39:23 --> Language Class Initialized
INFO - 2024-12-02 14:39:23 --> Loader Class Initialized
INFO - 2024-12-02 14:39:23 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:23 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:23 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:23 --> Controller Class Initialized
INFO - 2024-12-02 14:39:23 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:23 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:39:23 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:23 --> Total execution time: 0.0440
INFO - 2024-12-02 14:39:23 --> Config Class Initialized
INFO - 2024-12-02 14:39:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:23 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:23 --> URI Class Initialized
INFO - 2024-12-02 14:39:23 --> Router Class Initialized
INFO - 2024-12-02 14:39:23 --> Output Class Initialized
INFO - 2024-12-02 14:39:23 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:23 --> CSRF cookie sent
INFO - 2024-12-02 14:39:23 --> Input Class Initialized
INFO - 2024-12-02 14:39:23 --> Language Class Initialized
INFO - 2024-12-02 14:39:23 --> Loader Class Initialized
INFO - 2024-12-02 14:39:23 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:23 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:23 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:23 --> Controller Class Initialized
INFO - 2024-12-02 14:39:23 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:23 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:39:23 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:23 --> Total execution time: 0.0448
INFO - 2024-12-02 14:39:24 --> Config Class Initialized
INFO - 2024-12-02 14:39:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:24 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:24 --> URI Class Initialized
INFO - 2024-12-02 14:39:24 --> Router Class Initialized
INFO - 2024-12-02 14:39:24 --> Output Class Initialized
INFO - 2024-12-02 14:39:24 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:24 --> CSRF cookie sent
INFO - 2024-12-02 14:39:24 --> Input Class Initialized
INFO - 2024-12-02 14:39:24 --> Language Class Initialized
INFO - 2024-12-02 14:39:24 --> Loader Class Initialized
INFO - 2024-12-02 14:39:24 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:24 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:24 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:24 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:24 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:24 --> Controller Class Initialized
INFO - 2024-12-02 14:39:24 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:24 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:24 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:39:24 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:24 --> Total execution time: 0.0472
INFO - 2024-12-02 14:39:27 --> Config Class Initialized
INFO - 2024-12-02 14:39:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:27 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:27 --> URI Class Initialized
INFO - 2024-12-02 14:39:27 --> Router Class Initialized
INFO - 2024-12-02 14:39:27 --> Output Class Initialized
INFO - 2024-12-02 14:39:27 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:27 --> CSRF cookie sent
INFO - 2024-12-02 14:39:27 --> Input Class Initialized
INFO - 2024-12-02 14:39:27 --> Language Class Initialized
INFO - 2024-12-02 14:39:27 --> Loader Class Initialized
INFO - 2024-12-02 14:39:27 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:27 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:27 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:27 --> Controller Class Initialized
INFO - 2024-12-02 14:39:27 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:27 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:27 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:39:27 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:27 --> Total execution time: 0.0430
INFO - 2024-12-02 14:39:28 --> Config Class Initialized
INFO - 2024-12-02 14:39:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:39:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:39:28 --> Utf8 Class Initialized
INFO - 2024-12-02 14:39:28 --> URI Class Initialized
INFO - 2024-12-02 14:39:28 --> Router Class Initialized
INFO - 2024-12-02 14:39:28 --> Output Class Initialized
INFO - 2024-12-02 14:39:28 --> Security Class Initialized
DEBUG - 2024-12-02 14:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:39:28 --> CSRF cookie sent
INFO - 2024-12-02 14:39:28 --> Input Class Initialized
INFO - 2024-12-02 14:39:28 --> Language Class Initialized
INFO - 2024-12-02 14:39:28 --> Loader Class Initialized
INFO - 2024-12-02 14:39:28 --> Helper loaded: url_helper
INFO - 2024-12-02 14:39:28 --> Helper loaded: form_helper
INFO - 2024-12-02 14:39:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:39:28 --> Form Validation Class Initialized
INFO - 2024-12-02 14:39:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:39:28 --> Controller Class Initialized
INFO - 2024-12-02 14:39:28 --> Model "Category_model" initialized
INFO - 2024-12-02 14:39:28 --> Model "User_model" initialized
INFO - 2024-12-02 14:39:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:39:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:39:28 --> Final output sent to browser
DEBUG - 2024-12-02 14:39:28 --> Total execution time: 0.0427
INFO - 2024-12-02 14:41:04 --> Config Class Initialized
INFO - 2024-12-02 14:41:04 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:04 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:04 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:04 --> URI Class Initialized
INFO - 2024-12-02 14:41:04 --> Router Class Initialized
INFO - 2024-12-02 14:41:04 --> Output Class Initialized
INFO - 2024-12-02 14:41:04 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:04 --> CSRF cookie sent
INFO - 2024-12-02 14:41:04 --> Input Class Initialized
INFO - 2024-12-02 14:41:04 --> Language Class Initialized
INFO - 2024-12-02 14:41:04 --> Loader Class Initialized
INFO - 2024-12-02 14:41:04 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:04 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:04 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:04 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:04 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:04 --> Controller Class Initialized
INFO - 2024-12-02 14:41:04 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:04 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:04 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:41:04 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:04 --> Total execution time: 0.0745
INFO - 2024-12-02 14:41:10 --> Config Class Initialized
INFO - 2024-12-02 14:41:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:10 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:10 --> URI Class Initialized
INFO - 2024-12-02 14:41:10 --> Router Class Initialized
INFO - 2024-12-02 14:41:10 --> Output Class Initialized
INFO - 2024-12-02 14:41:10 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:10 --> CSRF cookie sent
INFO - 2024-12-02 14:41:10 --> Input Class Initialized
INFO - 2024-12-02 14:41:10 --> Language Class Initialized
INFO - 2024-12-02 14:41:10 --> Loader Class Initialized
INFO - 2024-12-02 14:41:10 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:10 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:10 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:10 --> Controller Class Initialized
INFO - 2024-12-02 14:41:10 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:10 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:10 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:41:10 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:10 --> Total execution time: 0.0627
INFO - 2024-12-02 14:41:11 --> Config Class Initialized
INFO - 2024-12-02 14:41:11 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:11 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:11 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:11 --> URI Class Initialized
INFO - 2024-12-02 14:41:11 --> Router Class Initialized
INFO - 2024-12-02 14:41:11 --> Output Class Initialized
INFO - 2024-12-02 14:41:11 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:11 --> CSRF cookie sent
INFO - 2024-12-02 14:41:11 --> Input Class Initialized
INFO - 2024-12-02 14:41:11 --> Language Class Initialized
INFO - 2024-12-02 14:41:11 --> Loader Class Initialized
INFO - 2024-12-02 14:41:11 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:11 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:11 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:11 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:11 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:11 --> Controller Class Initialized
INFO - 2024-12-02 14:41:11 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:11 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:11 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:41:11 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:11 --> Total execution time: 0.0476
INFO - 2024-12-02 14:41:12 --> Config Class Initialized
INFO - 2024-12-02 14:41:12 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:12 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:12 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:12 --> URI Class Initialized
INFO - 2024-12-02 14:41:12 --> Router Class Initialized
INFO - 2024-12-02 14:41:12 --> Output Class Initialized
INFO - 2024-12-02 14:41:12 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:12 --> CSRF cookie sent
INFO - 2024-12-02 14:41:12 --> Input Class Initialized
INFO - 2024-12-02 14:41:12 --> Language Class Initialized
INFO - 2024-12-02 14:41:12 --> Loader Class Initialized
INFO - 2024-12-02 14:41:12 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:12 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:12 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:12 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:12 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:12 --> Controller Class Initialized
INFO - 2024-12-02 14:41:12 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:12 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:12 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:41:12 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:12 --> Total execution time: 0.0434
INFO - 2024-12-02 14:41:18 --> Config Class Initialized
INFO - 2024-12-02 14:41:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:18 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:18 --> URI Class Initialized
INFO - 2024-12-02 14:41:18 --> Router Class Initialized
INFO - 2024-12-02 14:41:18 --> Output Class Initialized
INFO - 2024-12-02 14:41:18 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:18 --> CSRF cookie sent
INFO - 2024-12-02 14:41:18 --> Input Class Initialized
INFO - 2024-12-02 14:41:18 --> Language Class Initialized
INFO - 2024-12-02 14:41:18 --> Loader Class Initialized
INFO - 2024-12-02 14:41:18 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:18 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:18 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:18 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:18 --> Controller Class Initialized
INFO - 2024-12-02 14:41:18 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:18 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:18 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:41:18 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:18 --> Total execution time: 0.0711
INFO - 2024-12-02 14:41:22 --> Config Class Initialized
INFO - 2024-12-02 14:41:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:22 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:22 --> URI Class Initialized
INFO - 2024-12-02 14:41:22 --> Router Class Initialized
INFO - 2024-12-02 14:41:22 --> Output Class Initialized
INFO - 2024-12-02 14:41:22 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:22 --> CSRF cookie sent
INFO - 2024-12-02 14:41:22 --> Input Class Initialized
INFO - 2024-12-02 14:41:22 --> Language Class Initialized
INFO - 2024-12-02 14:41:22 --> Loader Class Initialized
INFO - 2024-12-02 14:41:22 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:22 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:22 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:22 --> Controller Class Initialized
INFO - 2024-12-02 14:41:22 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:22 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 14:41:22 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:22 --> Total execution time: 0.0405
INFO - 2024-12-02 14:41:26 --> Config Class Initialized
INFO - 2024-12-02 14:41:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:26 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:26 --> URI Class Initialized
INFO - 2024-12-02 14:41:26 --> Router Class Initialized
INFO - 2024-12-02 14:41:26 --> Output Class Initialized
INFO - 2024-12-02 14:41:26 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:26 --> CSRF cookie sent
INFO - 2024-12-02 14:41:26 --> Input Class Initialized
INFO - 2024-12-02 14:41:26 --> Language Class Initialized
INFO - 2024-12-02 14:41:26 --> Loader Class Initialized
INFO - 2024-12-02 14:41:26 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:26 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:26 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:26 --> Controller Class Initialized
INFO - 2024-12-02 14:41:26 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:26 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:41:26 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:26 --> Total execution time: 0.0378
INFO - 2024-12-02 14:41:28 --> Config Class Initialized
INFO - 2024-12-02 14:41:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:41:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:41:28 --> Utf8 Class Initialized
INFO - 2024-12-02 14:41:28 --> URI Class Initialized
INFO - 2024-12-02 14:41:28 --> Router Class Initialized
INFO - 2024-12-02 14:41:28 --> Output Class Initialized
INFO - 2024-12-02 14:41:28 --> Security Class Initialized
DEBUG - 2024-12-02 14:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:41:28 --> CSRF cookie sent
INFO - 2024-12-02 14:41:28 --> Input Class Initialized
INFO - 2024-12-02 14:41:28 --> Language Class Initialized
INFO - 2024-12-02 14:41:28 --> Loader Class Initialized
INFO - 2024-12-02 14:41:28 --> Helper loaded: url_helper
INFO - 2024-12-02 14:41:28 --> Helper loaded: form_helper
INFO - 2024-12-02 14:41:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:41:28 --> Form Validation Class Initialized
INFO - 2024-12-02 14:41:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:41:28 --> Controller Class Initialized
INFO - 2024-12-02 14:41:28 --> Model "Category_model" initialized
INFO - 2024-12-02 14:41:28 --> Model "User_model" initialized
INFO - 2024-12-02 14:41:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:41:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-02 14:41:28 --> Final output sent to browser
DEBUG - 2024-12-02 14:41:28 --> Total execution time: 0.0699
INFO - 2024-12-02 14:42:25 --> Config Class Initialized
INFO - 2024-12-02 14:42:25 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:42:25 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:42:25 --> Utf8 Class Initialized
INFO - 2024-12-02 14:42:25 --> URI Class Initialized
INFO - 2024-12-02 14:42:25 --> Router Class Initialized
INFO - 2024-12-02 14:42:25 --> Output Class Initialized
INFO - 2024-12-02 14:42:25 --> Security Class Initialized
DEBUG - 2024-12-02 14:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:42:25 --> CSRF cookie sent
INFO - 2024-12-02 14:42:25 --> Input Class Initialized
INFO - 2024-12-02 14:42:25 --> Language Class Initialized
INFO - 2024-12-02 14:42:25 --> Loader Class Initialized
INFO - 2024-12-02 14:42:25 --> Helper loaded: url_helper
INFO - 2024-12-02 14:42:25 --> Helper loaded: form_helper
INFO - 2024-12-02 14:42:25 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:42:25 --> Form Validation Class Initialized
INFO - 2024-12-02 14:42:25 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:42:25 --> Controller Class Initialized
INFO - 2024-12-02 14:42:25 --> Model "Category_model" initialized
INFO - 2024-12-02 14:42:25 --> Model "User_model" initialized
INFO - 2024-12-02 14:42:25 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:42:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-02 14:42:25 --> Final output sent to browser
DEBUG - 2024-12-02 14:42:25 --> Total execution time: 0.3212
INFO - 2024-12-02 14:43:22 --> Config Class Initialized
INFO - 2024-12-02 14:43:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:22 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:22 --> URI Class Initialized
INFO - 2024-12-02 14:43:22 --> Router Class Initialized
INFO - 2024-12-02 14:43:22 --> Output Class Initialized
INFO - 2024-12-02 14:43:22 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:22 --> CSRF cookie sent
INFO - 2024-12-02 14:43:22 --> Input Class Initialized
INFO - 2024-12-02 14:43:22 --> Language Class Initialized
INFO - 2024-12-02 14:43:22 --> Loader Class Initialized
INFO - 2024-12-02 14:43:22 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:22 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:22 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:22 --> Controller Class Initialized
INFO - 2024-12-02 14:43:22 --> Model "Category_model" initialized
INFO - 2024-12-02 14:43:22 --> Model "User_model" initialized
INFO - 2024-12-02 14:43:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:43:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_kuliner.php
INFO - 2024-12-02 14:43:22 --> Final output sent to browser
DEBUG - 2024-12-02 14:43:22 --> Total execution time: 0.0883
INFO - 2024-12-02 14:43:26 --> Config Class Initialized
INFO - 2024-12-02 14:43:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:26 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:26 --> URI Class Initialized
INFO - 2024-12-02 14:43:26 --> Router Class Initialized
INFO - 2024-12-02 14:43:26 --> Output Class Initialized
INFO - 2024-12-02 14:43:26 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:26 --> CSRF cookie sent
INFO - 2024-12-02 14:43:26 --> CSRF token verified
INFO - 2024-12-02 14:43:26 --> Input Class Initialized
INFO - 2024-12-02 14:43:26 --> Language Class Initialized
INFO - 2024-12-02 14:43:26 --> Loader Class Initialized
INFO - 2024-12-02 14:43:26 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:26 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:26 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:26 --> Controller Class Initialized
INFO - 2024-12-02 14:43:26 --> Model "Category_model" initialized
INFO - 2024-12-02 14:43:26 --> Model "User_model" initialized
INFO - 2024-12-02 14:43:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:43:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-02 14:43:26 --> Config Class Initialized
INFO - 2024-12-02 14:43:26 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:26 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:26 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:26 --> URI Class Initialized
INFO - 2024-12-02 14:43:26 --> Router Class Initialized
INFO - 2024-12-02 14:43:26 --> Output Class Initialized
INFO - 2024-12-02 14:43:26 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:26 --> CSRF cookie sent
INFO - 2024-12-02 14:43:26 --> Input Class Initialized
INFO - 2024-12-02 14:43:26 --> Language Class Initialized
INFO - 2024-12-02 14:43:26 --> Loader Class Initialized
INFO - 2024-12-02 14:43:26 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:26 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:26 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:26 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:26 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:26 --> Controller Class Initialized
INFO - 2024-12-02 14:43:26 --> Model "Category_model" initialized
INFO - 2024-12-02 14:43:26 --> Model "User_model" initialized
INFO - 2024-12-02 14:43:26 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:43:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:43:26 --> Final output sent to browser
DEBUG - 2024-12-02 14:43:26 --> Total execution time: 0.0577
INFO - 2024-12-02 14:43:34 --> Config Class Initialized
INFO - 2024-12-02 14:43:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:34 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:34 --> URI Class Initialized
INFO - 2024-12-02 14:43:34 --> Router Class Initialized
INFO - 2024-12-02 14:43:34 --> Output Class Initialized
INFO - 2024-12-02 14:43:34 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:34 --> CSRF cookie sent
INFO - 2024-12-02 14:43:34 --> Input Class Initialized
INFO - 2024-12-02 14:43:34 --> Language Class Initialized
INFO - 2024-12-02 14:43:34 --> Loader Class Initialized
INFO - 2024-12-02 14:43:34 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:34 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:34 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:34 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:34 --> Controller Class Initialized
INFO - 2024-12-02 14:43:34 --> Model "Category_model" initialized
INFO - 2024-12-02 14:43:34 --> Model "User_model" initialized
INFO - 2024-12-02 14:43:34 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:43:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:43:34 --> Final output sent to browser
DEBUG - 2024-12-02 14:43:34 --> Total execution time: 0.0444
INFO - 2024-12-02 14:43:36 --> Config Class Initialized
INFO - 2024-12-02 14:43:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:36 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:36 --> URI Class Initialized
INFO - 2024-12-02 14:43:36 --> Router Class Initialized
INFO - 2024-12-02 14:43:36 --> Output Class Initialized
INFO - 2024-12-02 14:43:36 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:36 --> CSRF cookie sent
INFO - 2024-12-02 14:43:36 --> Input Class Initialized
INFO - 2024-12-02 14:43:36 --> Language Class Initialized
INFO - 2024-12-02 14:43:36 --> Loader Class Initialized
INFO - 2024-12-02 14:43:36 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:36 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:36 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:36 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:36 --> Controller Class Initialized
INFO - 2024-12-02 14:43:36 --> Model "Category_model" initialized
INFO - 2024-12-02 14:43:36 --> Model "User_model" initialized
INFO - 2024-12-02 14:43:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:43:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:43:36 --> Final output sent to browser
DEBUG - 2024-12-02 14:43:36 --> Total execution time: 0.0570
INFO - 2024-12-02 14:43:41 --> Config Class Initialized
INFO - 2024-12-02 14:43:41 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:41 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:41 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:41 --> URI Class Initialized
INFO - 2024-12-02 14:43:41 --> Router Class Initialized
INFO - 2024-12-02 14:43:41 --> Output Class Initialized
INFO - 2024-12-02 14:43:41 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:41 --> CSRF cookie sent
INFO - 2024-12-02 14:43:41 --> Input Class Initialized
INFO - 2024-12-02 14:43:41 --> Language Class Initialized
INFO - 2024-12-02 14:43:41 --> Loader Class Initialized
INFO - 2024-12-02 14:43:41 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:41 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:42 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:42 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:42 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:42 --> Controller Class Initialized
INFO - 2024-12-02 14:43:42 --> Model "Category_model" initialized
INFO - 2024-12-02 14:43:42 --> Model "User_model" initialized
INFO - 2024-12-02 14:43:42 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:43:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:43:42 --> Final output sent to browser
DEBUG - 2024-12-02 14:43:42 --> Total execution time: 0.0580
INFO - 2024-12-02 14:43:43 --> Config Class Initialized
INFO - 2024-12-02 14:43:43 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:43:43 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:43:43 --> Utf8 Class Initialized
INFO - 2024-12-02 14:43:43 --> URI Class Initialized
INFO - 2024-12-02 14:43:43 --> Router Class Initialized
INFO - 2024-12-02 14:43:43 --> Output Class Initialized
INFO - 2024-12-02 14:43:43 --> Security Class Initialized
DEBUG - 2024-12-02 14:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:43:43 --> CSRF cookie sent
INFO - 2024-12-02 14:43:43 --> Input Class Initialized
INFO - 2024-12-02 14:43:43 --> Language Class Initialized
INFO - 2024-12-02 14:43:43 --> Loader Class Initialized
INFO - 2024-12-02 14:43:43 --> Helper loaded: url_helper
INFO - 2024-12-02 14:43:43 --> Helper loaded: form_helper
INFO - 2024-12-02 14:43:43 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:43:43 --> Form Validation Class Initialized
INFO - 2024-12-02 14:43:43 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:43:43 --> Controller Class Initialized
INFO - 2024-12-02 14:43:43 --> Model "News_model" initialized
INFO - 2024-12-02 14:43:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:43:43 --> Final output sent to browser
DEBUG - 2024-12-02 14:43:43 --> Total execution time: 0.0617
INFO - 2024-12-02 14:44:36 --> Config Class Initialized
INFO - 2024-12-02 14:44:36 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:44:36 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:44:36 --> Utf8 Class Initialized
INFO - 2024-12-02 14:44:36 --> URI Class Initialized
INFO - 2024-12-02 14:44:36 --> Router Class Initialized
INFO - 2024-12-02 14:44:36 --> Output Class Initialized
INFO - 2024-12-02 14:44:36 --> Security Class Initialized
DEBUG - 2024-12-02 14:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:44:36 --> CSRF cookie sent
INFO - 2024-12-02 14:44:36 --> Input Class Initialized
INFO - 2024-12-02 14:44:36 --> Language Class Initialized
INFO - 2024-12-02 14:44:36 --> Loader Class Initialized
INFO - 2024-12-02 14:44:36 --> Helper loaded: url_helper
INFO - 2024-12-02 14:44:36 --> Helper loaded: form_helper
INFO - 2024-12-02 14:44:36 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:44:36 --> Form Validation Class Initialized
INFO - 2024-12-02 14:44:36 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:44:36 --> Controller Class Initialized
INFO - 2024-12-02 14:44:36 --> Model "Category_model" initialized
INFO - 2024-12-02 14:44:36 --> Model "User_model" initialized
INFO - 2024-12-02 14:44:36 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:44:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:44:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:44:36 --> Final output sent to browser
DEBUG - 2024-12-02 14:44:36 --> Total execution time: 0.1434
INFO - 2024-12-02 14:44:43 --> Config Class Initialized
INFO - 2024-12-02 14:44:43 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:44:43 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:44:43 --> Utf8 Class Initialized
INFO - 2024-12-02 14:44:43 --> URI Class Initialized
INFO - 2024-12-02 14:44:43 --> Router Class Initialized
INFO - 2024-12-02 14:44:43 --> Output Class Initialized
INFO - 2024-12-02 14:44:43 --> Security Class Initialized
DEBUG - 2024-12-02 14:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:44:43 --> CSRF cookie sent
INFO - 2024-12-02 14:44:43 --> Input Class Initialized
INFO - 2024-12-02 14:44:43 --> Language Class Initialized
INFO - 2024-12-02 14:44:43 --> Loader Class Initialized
INFO - 2024-12-02 14:44:43 --> Helper loaded: url_helper
INFO - 2024-12-02 14:44:43 --> Helper loaded: form_helper
INFO - 2024-12-02 14:44:43 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:44:43 --> Form Validation Class Initialized
INFO - 2024-12-02 14:44:43 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:44:43 --> Controller Class Initialized
INFO - 2024-12-02 14:44:43 --> Model "Category_model" initialized
INFO - 2024-12-02 14:44:43 --> Model "User_model" initialized
INFO - 2024-12-02 14:44:43 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:44:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:44:43 --> Final output sent to browser
DEBUG - 2024-12-02 14:44:43 --> Total execution time: 0.0678
INFO - 2024-12-02 14:44:45 --> Config Class Initialized
INFO - 2024-12-02 14:44:45 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:44:45 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:44:45 --> Utf8 Class Initialized
INFO - 2024-12-02 14:44:45 --> URI Class Initialized
INFO - 2024-12-02 14:44:45 --> Router Class Initialized
INFO - 2024-12-02 14:44:45 --> Output Class Initialized
INFO - 2024-12-02 14:44:45 --> Security Class Initialized
DEBUG - 2024-12-02 14:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:44:45 --> CSRF cookie sent
INFO - 2024-12-02 14:44:45 --> Input Class Initialized
INFO - 2024-12-02 14:44:45 --> Language Class Initialized
INFO - 2024-12-02 14:44:45 --> Loader Class Initialized
INFO - 2024-12-02 14:44:45 --> Helper loaded: url_helper
INFO - 2024-12-02 14:44:45 --> Helper loaded: form_helper
INFO - 2024-12-02 14:44:45 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:44:45 --> Form Validation Class Initialized
INFO - 2024-12-02 14:44:45 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:44:45 --> Controller Class Initialized
INFO - 2024-12-02 14:44:45 --> Model "News_model" initialized
INFO - 2024-12-02 14:44:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:44:45 --> Final output sent to browser
DEBUG - 2024-12-02 14:44:45 --> Total execution time: 0.0595
INFO - 2024-12-02 14:47:53 --> Config Class Initialized
INFO - 2024-12-02 14:47:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:47:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:47:53 --> Utf8 Class Initialized
INFO - 2024-12-02 14:47:53 --> URI Class Initialized
INFO - 2024-12-02 14:47:53 --> Router Class Initialized
INFO - 2024-12-02 14:47:53 --> Output Class Initialized
INFO - 2024-12-02 14:47:53 --> Security Class Initialized
DEBUG - 2024-12-02 14:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:47:53 --> CSRF cookie sent
INFO - 2024-12-02 14:47:53 --> Input Class Initialized
INFO - 2024-12-02 14:47:53 --> Language Class Initialized
INFO - 2024-12-02 14:47:53 --> Loader Class Initialized
INFO - 2024-12-02 14:47:53 --> Helper loaded: url_helper
INFO - 2024-12-02 14:47:53 --> Helper loaded: form_helper
INFO - 2024-12-02 14:47:53 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:47:54 --> Form Validation Class Initialized
INFO - 2024-12-02 14:47:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:47:54 --> Controller Class Initialized
INFO - 2024-12-02 14:47:54 --> Model "News_model" initialized
INFO - 2024-12-02 14:47:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:47:54 --> Final output sent to browser
DEBUG - 2024-12-02 14:47:54 --> Total execution time: 0.4284
INFO - 2024-12-02 14:48:06 --> Config Class Initialized
INFO - 2024-12-02 14:48:06 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:48:06 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:48:06 --> Utf8 Class Initialized
INFO - 2024-12-02 14:48:06 --> URI Class Initialized
INFO - 2024-12-02 14:48:06 --> Router Class Initialized
INFO - 2024-12-02 14:48:06 --> Output Class Initialized
INFO - 2024-12-02 14:48:06 --> Security Class Initialized
DEBUG - 2024-12-02 14:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:48:06 --> CSRF cookie sent
INFO - 2024-12-02 14:48:06 --> Input Class Initialized
INFO - 2024-12-02 14:48:06 --> Language Class Initialized
INFO - 2024-12-02 14:48:06 --> Loader Class Initialized
INFO - 2024-12-02 14:48:06 --> Helper loaded: url_helper
INFO - 2024-12-02 14:48:06 --> Helper loaded: form_helper
INFO - 2024-12-02 14:48:06 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:48:06 --> Form Validation Class Initialized
INFO - 2024-12-02 14:48:06 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:48:06 --> Controller Class Initialized
INFO - 2024-12-02 14:48:06 --> Model "Category_model" initialized
INFO - 2024-12-02 14:48:06 --> Model "User_model" initialized
INFO - 2024-12-02 14:48:06 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:48:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:48:06 --> Final output sent to browser
DEBUG - 2024-12-02 14:48:06 --> Total execution time: 0.1287
INFO - 2024-12-02 14:48:10 --> Config Class Initialized
INFO - 2024-12-02 14:48:10 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:48:10 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:48:10 --> Utf8 Class Initialized
INFO - 2024-12-02 14:48:10 --> URI Class Initialized
INFO - 2024-12-02 14:48:10 --> Router Class Initialized
INFO - 2024-12-02 14:48:10 --> Output Class Initialized
INFO - 2024-12-02 14:48:10 --> Security Class Initialized
DEBUG - 2024-12-02 14:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:48:10 --> CSRF cookie sent
INFO - 2024-12-02 14:48:10 --> Input Class Initialized
INFO - 2024-12-02 14:48:10 --> Language Class Initialized
INFO - 2024-12-02 14:48:10 --> Loader Class Initialized
INFO - 2024-12-02 14:48:10 --> Helper loaded: url_helper
INFO - 2024-12-02 14:48:10 --> Helper loaded: form_helper
INFO - 2024-12-02 14:48:10 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:48:10 --> Form Validation Class Initialized
INFO - 2024-12-02 14:48:10 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:48:10 --> Controller Class Initialized
INFO - 2024-12-02 14:48:10 --> Model "News_model" initialized
INFO - 2024-12-02 14:48:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:48:10 --> Final output sent to browser
DEBUG - 2024-12-02 14:48:10 --> Total execution time: 0.0405
INFO - 2024-12-02 14:51:55 --> Config Class Initialized
INFO - 2024-12-02 14:51:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:51:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:51:55 --> Utf8 Class Initialized
INFO - 2024-12-02 14:51:55 --> URI Class Initialized
INFO - 2024-12-02 14:51:55 --> Router Class Initialized
INFO - 2024-12-02 14:51:55 --> Output Class Initialized
INFO - 2024-12-02 14:51:55 --> Security Class Initialized
DEBUG - 2024-12-02 14:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:51:55 --> CSRF cookie sent
INFO - 2024-12-02 14:51:55 --> Input Class Initialized
INFO - 2024-12-02 14:51:55 --> Language Class Initialized
INFO - 2024-12-02 14:51:55 --> Loader Class Initialized
INFO - 2024-12-02 14:51:55 --> Helper loaded: url_helper
INFO - 2024-12-02 14:51:55 --> Helper loaded: form_helper
INFO - 2024-12-02 14:51:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:51:55 --> Form Validation Class Initialized
INFO - 2024-12-02 14:51:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:51:55 --> Controller Class Initialized
INFO - 2024-12-02 14:51:55 --> Model "News_model" initialized
INFO - 2024-12-02 14:51:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:51:55 --> Final output sent to browser
DEBUG - 2024-12-02 14:51:55 --> Total execution time: 0.2714
INFO - 2024-12-02 14:51:58 --> Config Class Initialized
INFO - 2024-12-02 14:51:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:51:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:51:58 --> Utf8 Class Initialized
INFO - 2024-12-02 14:51:58 --> URI Class Initialized
INFO - 2024-12-02 14:51:58 --> Router Class Initialized
INFO - 2024-12-02 14:51:58 --> Output Class Initialized
INFO - 2024-12-02 14:51:58 --> Security Class Initialized
DEBUG - 2024-12-02 14:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:51:58 --> CSRF cookie sent
INFO - 2024-12-02 14:51:58 --> Input Class Initialized
INFO - 2024-12-02 14:51:58 --> Language Class Initialized
INFO - 2024-12-02 14:51:58 --> Loader Class Initialized
INFO - 2024-12-02 14:51:58 --> Helper loaded: url_helper
INFO - 2024-12-02 14:51:58 --> Helper loaded: form_helper
INFO - 2024-12-02 14:51:59 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:51:59 --> Form Validation Class Initialized
INFO - 2024-12-02 14:51:59 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:51:59 --> Controller Class Initialized
INFO - 2024-12-02 14:51:59 --> Model "News_model" initialized
INFO - 2024-12-02 14:51:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_edit.php
INFO - 2024-12-02 14:51:59 --> Final output sent to browser
DEBUG - 2024-12-02 14:51:59 --> Total execution time: 0.0818
INFO - 2024-12-02 14:52:03 --> Config Class Initialized
INFO - 2024-12-02 14:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:03 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:03 --> URI Class Initialized
INFO - 2024-12-02 14:52:03 --> Router Class Initialized
INFO - 2024-12-02 14:52:03 --> Output Class Initialized
INFO - 2024-12-02 14:52:03 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:03 --> CSRF cookie sent
INFO - 2024-12-02 14:52:03 --> Input Class Initialized
INFO - 2024-12-02 14:52:03 --> Language Class Initialized
INFO - 2024-12-02 14:52:03 --> Loader Class Initialized
INFO - 2024-12-02 14:52:03 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:03 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:03 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:03 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:03 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:03 --> Controller Class Initialized
INFO - 2024-12-02 14:52:03 --> Model "News_model" initialized
INFO - 2024-12-02 14:52:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:52:03 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:03 --> Total execution time: 0.0564
INFO - 2024-12-02 14:52:09 --> Config Class Initialized
INFO - 2024-12-02 14:52:09 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:09 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:09 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:09 --> URI Class Initialized
INFO - 2024-12-02 14:52:09 --> Router Class Initialized
INFO - 2024-12-02 14:52:09 --> Output Class Initialized
INFO - 2024-12-02 14:52:09 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:09 --> CSRF cookie sent
INFO - 2024-12-02 14:52:09 --> Input Class Initialized
INFO - 2024-12-02 14:52:09 --> Language Class Initialized
INFO - 2024-12-02 14:52:09 --> Loader Class Initialized
INFO - 2024-12-02 14:52:09 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:09 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:09 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:09 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:09 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:09 --> Controller Class Initialized
INFO - 2024-12-02 14:52:09 --> Model "News_model" initialized
INFO - 2024-12-02 14:52:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 14:52:09 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:09 --> Total execution time: 0.0541
INFO - 2024-12-02 14:52:22 --> Config Class Initialized
INFO - 2024-12-02 14:52:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:22 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:22 --> URI Class Initialized
INFO - 2024-12-02 14:52:22 --> Router Class Initialized
INFO - 2024-12-02 14:52:22 --> Output Class Initialized
INFO - 2024-12-02 14:52:22 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:22 --> CSRF cookie sent
INFO - 2024-12-02 14:52:22 --> Input Class Initialized
INFO - 2024-12-02 14:52:22 --> Language Class Initialized
INFO - 2024-12-02 14:52:22 --> Loader Class Initialized
INFO - 2024-12-02 14:52:22 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:22 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:22 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:22 --> Controller Class Initialized
INFO - 2024-12-02 14:52:22 --> Model "News_model" initialized
INFO - 2024-12-02 14:52:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 14:52:22 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:22 --> Total execution time: 0.0676
INFO - 2024-12-02 14:52:28 --> Config Class Initialized
INFO - 2024-12-02 14:52:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:28 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:28 --> URI Class Initialized
INFO - 2024-12-02 14:52:28 --> Router Class Initialized
INFO - 2024-12-02 14:52:28 --> Output Class Initialized
INFO - 2024-12-02 14:52:28 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:28 --> CSRF cookie sent
INFO - 2024-12-02 14:52:28 --> Input Class Initialized
INFO - 2024-12-02 14:52:28 --> Language Class Initialized
INFO - 2024-12-02 14:52:28 --> Loader Class Initialized
INFO - 2024-12-02 14:52:28 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:28 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:28 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:28 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:28 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:28 --> Controller Class Initialized
INFO - 2024-12-02 14:52:28 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:28 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:28 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:52:28 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:28 --> Total execution time: 0.0955
INFO - 2024-12-02 14:52:30 --> Config Class Initialized
INFO - 2024-12-02 14:52:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:30 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:30 --> URI Class Initialized
INFO - 2024-12-02 14:52:30 --> Router Class Initialized
INFO - 2024-12-02 14:52:30 --> Output Class Initialized
INFO - 2024-12-02 14:52:30 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:30 --> CSRF cookie sent
INFO - 2024-12-02 14:52:30 --> Input Class Initialized
INFO - 2024-12-02 14:52:30 --> Language Class Initialized
INFO - 2024-12-02 14:52:30 --> Loader Class Initialized
INFO - 2024-12-02 14:52:30 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:30 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:31 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:31 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:31 --> Controller Class Initialized
INFO - 2024-12-02 14:52:31 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:31 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:31 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 14:52:31 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:31 --> Total execution time: 0.0616
INFO - 2024-12-02 14:52:32 --> Config Class Initialized
INFO - 2024-12-02 14:52:32 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:32 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:32 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:32 --> URI Class Initialized
INFO - 2024-12-02 14:52:32 --> Router Class Initialized
INFO - 2024-12-02 14:52:32 --> Output Class Initialized
INFO - 2024-12-02 14:52:32 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:32 --> CSRF cookie sent
INFO - 2024-12-02 14:52:32 --> Input Class Initialized
INFO - 2024-12-02 14:52:32 --> Language Class Initialized
INFO - 2024-12-02 14:52:32 --> Loader Class Initialized
INFO - 2024-12-02 14:52:32 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:32 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:32 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:32 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:32 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:32 --> Controller Class Initialized
INFO - 2024-12-02 14:52:32 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:32 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:32 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 14:52:32 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:32 --> Total execution time: 0.0564
INFO - 2024-12-02 14:52:34 --> Config Class Initialized
INFO - 2024-12-02 14:52:34 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:34 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:34 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:34 --> URI Class Initialized
INFO - 2024-12-02 14:52:34 --> Router Class Initialized
INFO - 2024-12-02 14:52:34 --> Output Class Initialized
INFO - 2024-12-02 14:52:34 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:34 --> CSRF cookie sent
INFO - 2024-12-02 14:52:34 --> Input Class Initialized
INFO - 2024-12-02 14:52:34 --> Language Class Initialized
INFO - 2024-12-02 14:52:34 --> Loader Class Initialized
INFO - 2024-12-02 14:52:34 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:34 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:34 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:34 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:34 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:34 --> Controller Class Initialized
INFO - 2024-12-02 14:52:34 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:34 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:34 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 14:52:34 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:34 --> Total execution time: 0.0492
INFO - 2024-12-02 14:52:35 --> Config Class Initialized
INFO - 2024-12-02 14:52:35 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:35 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:35 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:35 --> URI Class Initialized
INFO - 2024-12-02 14:52:35 --> Router Class Initialized
INFO - 2024-12-02 14:52:35 --> Output Class Initialized
INFO - 2024-12-02 14:52:35 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:35 --> CSRF cookie sent
INFO - 2024-12-02 14:52:35 --> Input Class Initialized
INFO - 2024-12-02 14:52:35 --> Language Class Initialized
INFO - 2024-12-02 14:52:35 --> Loader Class Initialized
INFO - 2024-12-02 14:52:35 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:35 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:35 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:35 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:35 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:35 --> Controller Class Initialized
INFO - 2024-12-02 14:52:35 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:35 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:35 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-02 14:52:35 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:35 --> Total execution time: 0.0711
INFO - 2024-12-02 14:52:37 --> Config Class Initialized
INFO - 2024-12-02 14:52:37 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:37 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:37 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:37 --> URI Class Initialized
INFO - 2024-12-02 14:52:37 --> Router Class Initialized
INFO - 2024-12-02 14:52:37 --> Output Class Initialized
INFO - 2024-12-02 14:52:37 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:37 --> CSRF cookie sent
INFO - 2024-12-02 14:52:37 --> Input Class Initialized
INFO - 2024-12-02 14:52:37 --> Language Class Initialized
INFO - 2024-12-02 14:52:37 --> Loader Class Initialized
INFO - 2024-12-02 14:52:37 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:37 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:38 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:38 --> Controller Class Initialized
INFO - 2024-12-02 14:52:38 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:38 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:38 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:38 --> Model "Contact_model" initialized
INFO - 2024-12-02 14:52:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-02 14:52:38 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:38 --> Total execution time: 0.0675
INFO - 2024-12-02 14:52:39 --> Config Class Initialized
INFO - 2024-12-02 14:52:39 --> Hooks Class Initialized
DEBUG - 2024-12-02 14:52:39 --> UTF-8 Support Enabled
INFO - 2024-12-02 14:52:39 --> Utf8 Class Initialized
INFO - 2024-12-02 14:52:39 --> URI Class Initialized
INFO - 2024-12-02 14:52:39 --> Router Class Initialized
INFO - 2024-12-02 14:52:39 --> Output Class Initialized
INFO - 2024-12-02 14:52:39 --> Security Class Initialized
DEBUG - 2024-12-02 14:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 14:52:39 --> CSRF cookie sent
INFO - 2024-12-02 14:52:39 --> Input Class Initialized
INFO - 2024-12-02 14:52:39 --> Language Class Initialized
INFO - 2024-12-02 14:52:39 --> Loader Class Initialized
INFO - 2024-12-02 14:52:39 --> Helper loaded: url_helper
INFO - 2024-12-02 14:52:39 --> Helper loaded: form_helper
INFO - 2024-12-02 14:52:39 --> Database Driver Class Initialized
DEBUG - 2024-12-02 14:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 14:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 14:52:39 --> Form Validation Class Initialized
INFO - 2024-12-02 14:52:39 --> Model "Culinary_model" initialized
INFO - 2024-12-02 14:52:39 --> Controller Class Initialized
INFO - 2024-12-02 14:52:39 --> Model "Category_model" initialized
INFO - 2024-12-02 14:52:39 --> Model "User_model" initialized
INFO - 2024-12-02 14:52:39 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 14:52:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 14:52:39 --> Final output sent to browser
DEBUG - 2024-12-02 14:52:39 --> Total execution time: 0.0570
INFO - 2024-12-02 16:01:18 --> Config Class Initialized
INFO - 2024-12-02 16:01:18 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:18 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:18 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:18 --> URI Class Initialized
INFO - 2024-12-02 16:01:18 --> Router Class Initialized
INFO - 2024-12-02 16:01:18 --> Output Class Initialized
INFO - 2024-12-02 16:01:18 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:18 --> CSRF cookie sent
INFO - 2024-12-02 16:01:18 --> Input Class Initialized
INFO - 2024-12-02 16:01:18 --> Language Class Initialized
INFO - 2024-12-02 16:01:18 --> Loader Class Initialized
INFO - 2024-12-02 16:01:18 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:18 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:18 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:19 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:19 --> Controller Class Initialized
INFO - 2024-12-02 16:01:19 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:19 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 16:01:19 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:19 --> Total execution time: 0.9287
INFO - 2024-12-02 16:01:19 --> Config Class Initialized
INFO - 2024-12-02 16:01:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:19 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:19 --> URI Class Initialized
INFO - 2024-12-02 16:01:19 --> Router Class Initialized
INFO - 2024-12-02 16:01:19 --> Output Class Initialized
INFO - 2024-12-02 16:01:19 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:19 --> CSRF cookie sent
INFO - 2024-12-02 16:01:19 --> Input Class Initialized
INFO - 2024-12-02 16:01:19 --> Language Class Initialized
INFO - 2024-12-02 16:01:19 --> Loader Class Initialized
INFO - 2024-12-02 16:01:19 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:19 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:19 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:19 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:19 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:19 --> Controller Class Initialized
INFO - 2024-12-02 16:01:19 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:19 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:19 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 16:01:19 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:19 --> Total execution time: 0.0620
INFO - 2024-12-02 16:01:22 --> Config Class Initialized
INFO - 2024-12-02 16:01:22 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:22 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:22 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:22 --> URI Class Initialized
INFO - 2024-12-02 16:01:22 --> Router Class Initialized
INFO - 2024-12-02 16:01:22 --> Output Class Initialized
INFO - 2024-12-02 16:01:22 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:22 --> CSRF cookie sent
INFO - 2024-12-02 16:01:22 --> Input Class Initialized
INFO - 2024-12-02 16:01:22 --> Language Class Initialized
INFO - 2024-12-02 16:01:22 --> Loader Class Initialized
INFO - 2024-12-02 16:01:22 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:22 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:22 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:22 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:22 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:22 --> Controller Class Initialized
INFO - 2024-12-02 16:01:22 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:22 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:22 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 16:01:22 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:22 --> Total execution time: 0.0455
INFO - 2024-12-02 16:01:23 --> Config Class Initialized
INFO - 2024-12-02 16:01:23 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:23 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:23 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:23 --> URI Class Initialized
INFO - 2024-12-02 16:01:23 --> Router Class Initialized
INFO - 2024-12-02 16:01:23 --> Output Class Initialized
INFO - 2024-12-02 16:01:23 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:23 --> CSRF cookie sent
INFO - 2024-12-02 16:01:23 --> Input Class Initialized
INFO - 2024-12-02 16:01:23 --> Language Class Initialized
INFO - 2024-12-02 16:01:23 --> Loader Class Initialized
INFO - 2024-12-02 16:01:23 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:23 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:23 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:23 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:23 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:23 --> Controller Class Initialized
INFO - 2024-12-02 16:01:23 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:23 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:23 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 16:01:23 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:23 --> Total execution time: 0.0670
INFO - 2024-12-02 16:01:24 --> Config Class Initialized
INFO - 2024-12-02 16:01:24 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:24 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:24 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:24 --> URI Class Initialized
INFO - 2024-12-02 16:01:24 --> Router Class Initialized
INFO - 2024-12-02 16:01:24 --> Output Class Initialized
INFO - 2024-12-02 16:01:24 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:24 --> CSRF cookie sent
INFO - 2024-12-02 16:01:24 --> Input Class Initialized
INFO - 2024-12-02 16:01:24 --> Language Class Initialized
INFO - 2024-12-02 16:01:24 --> Loader Class Initialized
INFO - 2024-12-02 16:01:24 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:24 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:24 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:25 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:25 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:25 --> Controller Class Initialized
INFO - 2024-12-02 16:01:25 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:25 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:25 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:25 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 16:01:25 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:25 --> Total execution time: 0.0678
INFO - 2024-12-02 16:01:27 --> Config Class Initialized
INFO - 2024-12-02 16:01:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:27 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:27 --> URI Class Initialized
INFO - 2024-12-02 16:01:27 --> Router Class Initialized
INFO - 2024-12-02 16:01:27 --> Output Class Initialized
INFO - 2024-12-02 16:01:27 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:27 --> CSRF cookie sent
INFO - 2024-12-02 16:01:27 --> Input Class Initialized
INFO - 2024-12-02 16:01:27 --> Language Class Initialized
INFO - 2024-12-02 16:01:27 --> Loader Class Initialized
INFO - 2024-12-02 16:01:27 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:27 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:27 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:27 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:27 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:27 --> Controller Class Initialized
INFO - 2024-12-02 16:01:27 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:27 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:27 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/tambah_kuliner.php
INFO - 2024-12-02 16:01:27 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:27 --> Total execution time: 0.0655
INFO - 2024-12-02 16:01:30 --> Config Class Initialized
INFO - 2024-12-02 16:01:30 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:30 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:30 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:30 --> URI Class Initialized
INFO - 2024-12-02 16:01:30 --> Router Class Initialized
INFO - 2024-12-02 16:01:30 --> Output Class Initialized
INFO - 2024-12-02 16:01:30 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:30 --> CSRF cookie sent
INFO - 2024-12-02 16:01:30 --> Input Class Initialized
INFO - 2024-12-02 16:01:30 --> Language Class Initialized
INFO - 2024-12-02 16:01:30 --> Loader Class Initialized
INFO - 2024-12-02 16:01:30 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:30 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:30 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:30 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:30 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:30 --> Controller Class Initialized
INFO - 2024-12-02 16:01:30 --> Model "News_model" initialized
INFO - 2024-12-02 16:01:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-02 16:01:30 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:30 --> Total execution time: 0.0420
INFO - 2024-12-02 16:01:38 --> Config Class Initialized
INFO - 2024-12-02 16:01:38 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:38 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:38 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:38 --> URI Class Initialized
INFO - 2024-12-02 16:01:38 --> Router Class Initialized
INFO - 2024-12-02 16:01:38 --> Output Class Initialized
INFO - 2024-12-02 16:01:38 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:38 --> CSRF cookie sent
INFO - 2024-12-02 16:01:38 --> Input Class Initialized
INFO - 2024-12-02 16:01:38 --> Language Class Initialized
INFO - 2024-12-02 16:01:38 --> Loader Class Initialized
INFO - 2024-12-02 16:01:38 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:38 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:38 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:38 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:38 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:38 --> Controller Class Initialized
INFO - 2024-12-02 16:01:38 --> Model "News_model" initialized
INFO - 2024-12-02 16:01:38 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_add.php
INFO - 2024-12-02 16:01:38 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:38 --> Total execution time: 0.0358
INFO - 2024-12-02 16:01:46 --> Config Class Initialized
INFO - 2024-12-02 16:01:46 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:46 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:46 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:46 --> URI Class Initialized
INFO - 2024-12-02 16:01:46 --> Router Class Initialized
INFO - 2024-12-02 16:01:46 --> Output Class Initialized
INFO - 2024-12-02 16:01:46 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:46 --> CSRF cookie sent
INFO - 2024-12-02 16:01:46 --> Input Class Initialized
INFO - 2024-12-02 16:01:46 --> Language Class Initialized
INFO - 2024-12-02 16:01:46 --> Loader Class Initialized
INFO - 2024-12-02 16:01:46 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:46 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:46 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:46 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:46 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:46 --> Controller Class Initialized
INFO - 2024-12-02 16:01:46 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:46 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:46 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 16:01:46 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:46 --> Total execution time: 0.0886
INFO - 2024-12-02 16:01:51 --> Config Class Initialized
INFO - 2024-12-02 16:01:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:51 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:51 --> URI Class Initialized
INFO - 2024-12-02 16:01:51 --> Router Class Initialized
INFO - 2024-12-02 16:01:51 --> Output Class Initialized
INFO - 2024-12-02 16:01:51 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:51 --> CSRF cookie sent
INFO - 2024-12-02 16:01:51 --> Input Class Initialized
INFO - 2024-12-02 16:01:51 --> Language Class Initialized
INFO - 2024-12-02 16:01:51 --> Loader Class Initialized
INFO - 2024-12-02 16:01:51 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:51 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:51 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:51 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:51 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:51 --> Controller Class Initialized
INFO - 2024-12-02 16:01:51 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:51 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:51 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 16:01:51 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:51 --> Total execution time: 0.0540
INFO - 2024-12-02 16:01:52 --> Config Class Initialized
INFO - 2024-12-02 16:01:52 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:52 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:52 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:52 --> URI Class Initialized
INFO - 2024-12-02 16:01:52 --> Router Class Initialized
INFO - 2024-12-02 16:01:52 --> Output Class Initialized
INFO - 2024-12-02 16:01:52 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:52 --> CSRF cookie sent
INFO - 2024-12-02 16:01:52 --> Input Class Initialized
INFO - 2024-12-02 16:01:52 --> Language Class Initialized
INFO - 2024-12-02 16:01:52 --> Loader Class Initialized
INFO - 2024-12-02 16:01:52 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:52 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:52 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:52 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:52 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:52 --> Controller Class Initialized
INFO - 2024-12-02 16:01:52 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:52 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:52 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-02 16:01:52 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:52 --> Total execution time: 0.0503
INFO - 2024-12-02 16:01:53 --> Config Class Initialized
INFO - 2024-12-02 16:01:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:53 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:53 --> URI Class Initialized
INFO - 2024-12-02 16:01:53 --> Router Class Initialized
INFO - 2024-12-02 16:01:53 --> Output Class Initialized
INFO - 2024-12-02 16:01:53 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:53 --> CSRF cookie sent
INFO - 2024-12-02 16:01:53 --> Input Class Initialized
INFO - 2024-12-02 16:01:53 --> Language Class Initialized
INFO - 2024-12-02 16:01:53 --> Loader Class Initialized
INFO - 2024-12-02 16:01:53 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:53 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:53 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:53 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:53 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:53 --> Controller Class Initialized
INFO - 2024-12-02 16:01:53 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:53 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:53 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-02 16:01:53 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:53 --> Total execution time: 0.0615
INFO - 2024-12-02 16:01:53 --> Config Class Initialized
INFO - 2024-12-02 16:01:53 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:53 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:53 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:53 --> URI Class Initialized
INFO - 2024-12-02 16:01:53 --> Router Class Initialized
INFO - 2024-12-02 16:01:53 --> Output Class Initialized
INFO - 2024-12-02 16:01:53 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:53 --> CSRF cookie sent
INFO - 2024-12-02 16:01:53 --> Input Class Initialized
INFO - 2024-12-02 16:01:53 --> Language Class Initialized
INFO - 2024-12-02 16:01:53 --> Loader Class Initialized
INFO - 2024-12-02 16:01:53 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:53 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:53 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:53 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:53 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:53 --> Controller Class Initialized
INFO - 2024-12-02 16:01:54 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:54 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:54 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 16:01:54 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:54 --> Total execution time: 0.0381
INFO - 2024-12-02 16:01:54 --> Config Class Initialized
INFO - 2024-12-02 16:01:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:54 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:54 --> URI Class Initialized
INFO - 2024-12-02 16:01:54 --> Router Class Initialized
INFO - 2024-12-02 16:01:54 --> Output Class Initialized
INFO - 2024-12-02 16:01:54 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:54 --> CSRF cookie sent
INFO - 2024-12-02 16:01:54 --> Input Class Initialized
INFO - 2024-12-02 16:01:54 --> Language Class Initialized
INFO - 2024-12-02 16:01:54 --> Loader Class Initialized
INFO - 2024-12-02 16:01:54 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:54 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:54 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:54 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:54 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:54 --> Controller Class Initialized
INFO - 2024-12-02 16:01:54 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:54 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:54 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-02 16:01:54 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:54 --> Total execution time: 0.0426
INFO - 2024-12-02 16:01:55 --> Config Class Initialized
INFO - 2024-12-02 16:01:55 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:01:55 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:01:55 --> Utf8 Class Initialized
INFO - 2024-12-02 16:01:55 --> URI Class Initialized
INFO - 2024-12-02 16:01:55 --> Router Class Initialized
INFO - 2024-12-02 16:01:55 --> Output Class Initialized
INFO - 2024-12-02 16:01:55 --> Security Class Initialized
DEBUG - 2024-12-02 16:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:01:55 --> CSRF cookie sent
INFO - 2024-12-02 16:01:55 --> Input Class Initialized
INFO - 2024-12-02 16:01:55 --> Language Class Initialized
INFO - 2024-12-02 16:01:55 --> Loader Class Initialized
INFO - 2024-12-02 16:01:55 --> Helper loaded: url_helper
INFO - 2024-12-02 16:01:55 --> Helper loaded: form_helper
INFO - 2024-12-02 16:01:55 --> Database Driver Class Initialized
DEBUG - 2024-12-02 16:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-02 16:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:01:55 --> Form Validation Class Initialized
INFO - 2024-12-02 16:01:55 --> Model "Culinary_model" initialized
INFO - 2024-12-02 16:01:55 --> Controller Class Initialized
INFO - 2024-12-02 16:01:55 --> Model "Category_model" initialized
INFO - 2024-12-02 16:01:55 --> Model "User_model" initialized
INFO - 2024-12-02 16:01:55 --> Model "UserActivityLog_model" initialized
DEBUG - 2024-12-02 16:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-02 16:01:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-02 16:01:55 --> Final output sent to browser
DEBUG - 2024-12-02 16:01:55 --> Total execution time: 0.0618
