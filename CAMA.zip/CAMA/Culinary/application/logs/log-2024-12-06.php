<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-06 00:57:55 --> Config Class Initialized
INFO - 2024-12-06 00:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 00:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 00:57:55 --> Utf8 Class Initialized
INFO - 2024-12-06 00:57:55 --> URI Class Initialized
INFO - 2024-12-06 00:57:55 --> Router Class Initialized
INFO - 2024-12-06 00:57:55 --> Output Class Initialized
INFO - 2024-12-06 00:57:55 --> Security Class Initialized
DEBUG - 2024-12-06 00:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 00:57:55 --> CSRF cookie sent
INFO - 2024-12-06 00:57:55 --> Input Class Initialized
INFO - 2024-12-06 00:57:55 --> Language Class Initialized
INFO - 2024-12-06 00:57:55 --> Loader Class Initialized
INFO - 2024-12-06 00:57:55 --> Helper loaded: url_helper
INFO - 2024-12-06 00:57:55 --> Helper loaded: form_helper
INFO - 2024-12-06 00:57:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 00:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 00:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 00:57:56 --> Form Validation Class Initialized
INFO - 2024-12-06 00:57:56 --> Model "Culinary_model" initialized
INFO - 2024-12-06 00:57:56 --> Controller Class Initialized
INFO - 2024-12-06 00:57:56 --> Model "Review_model" initialized
INFO - 2024-12-06 00:57:56 --> Model "Category_model" initialized
INFO - 2024-12-06 00:57:56 --> Model "User_model" initialized
INFO - 2024-12-06 00:57:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 00:57:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 00:57:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 00:57:56 --> Query result: stdClass Object
(
    [view_count] => 76
)

INFO - 2024-12-06 00:57:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 00:57:56 --> Final output sent to browser
DEBUG - 2024-12-06 00:57:56 --> Total execution time: 1.1129
INFO - 2024-12-06 00:59:53 --> Config Class Initialized
INFO - 2024-12-06 00:59:53 --> Hooks Class Initialized
DEBUG - 2024-12-06 00:59:53 --> UTF-8 Support Enabled
INFO - 2024-12-06 00:59:53 --> Utf8 Class Initialized
INFO - 2024-12-06 00:59:53 --> URI Class Initialized
INFO - 2024-12-06 00:59:53 --> Router Class Initialized
INFO - 2024-12-06 00:59:53 --> Output Class Initialized
INFO - 2024-12-06 00:59:53 --> Security Class Initialized
DEBUG - 2024-12-06 00:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 00:59:53 --> CSRF cookie sent
INFO - 2024-12-06 00:59:53 --> Input Class Initialized
INFO - 2024-12-06 00:59:53 --> Language Class Initialized
INFO - 2024-12-06 00:59:53 --> Loader Class Initialized
INFO - 2024-12-06 00:59:53 --> Helper loaded: url_helper
INFO - 2024-12-06 00:59:53 --> Helper loaded: form_helper
INFO - 2024-12-06 00:59:53 --> Database Driver Class Initialized
DEBUG - 2024-12-06 00:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 00:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 00:59:53 --> Form Validation Class Initialized
INFO - 2024-12-06 00:59:53 --> Model "Culinary_model" initialized
INFO - 2024-12-06 00:59:53 --> Controller Class Initialized
INFO - 2024-12-06 00:59:53 --> Model "Review_model" initialized
INFO - 2024-12-06 00:59:53 --> Model "Category_model" initialized
INFO - 2024-12-06 00:59:53 --> Model "User_model" initialized
INFO - 2024-12-06 00:59:53 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 00:59:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 00:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 00:59:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 00:59:53 --> Final output sent to browser
DEBUG - 2024-12-06 00:59:53 --> Total execution time: 0.1448
INFO - 2024-12-06 00:59:55 --> Config Class Initialized
INFO - 2024-12-06 00:59:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 00:59:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 00:59:55 --> Utf8 Class Initialized
INFO - 2024-12-06 00:59:55 --> URI Class Initialized
INFO - 2024-12-06 00:59:55 --> Router Class Initialized
INFO - 2024-12-06 00:59:55 --> Output Class Initialized
INFO - 2024-12-06 00:59:55 --> Security Class Initialized
DEBUG - 2024-12-06 00:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 00:59:55 --> CSRF cookie sent
INFO - 2024-12-06 00:59:55 --> Input Class Initialized
INFO - 2024-12-06 00:59:55 --> Language Class Initialized
INFO - 2024-12-06 00:59:55 --> Loader Class Initialized
INFO - 2024-12-06 00:59:55 --> Helper loaded: url_helper
INFO - 2024-12-06 00:59:55 --> Helper loaded: form_helper
INFO - 2024-12-06 00:59:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 00:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 00:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 00:59:55 --> Form Validation Class Initialized
INFO - 2024-12-06 00:59:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 00:59:55 --> Controller Class Initialized
INFO - 2024-12-06 00:59:55 --> Model "Review_model" initialized
INFO - 2024-12-06 00:59:55 --> Model "Category_model" initialized
INFO - 2024-12-06 00:59:55 --> Model "User_model" initialized
INFO - 2024-12-06 00:59:55 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 00:59:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 00:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 00:59:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 00:59:55 --> Final output sent to browser
DEBUG - 2024-12-06 00:59:55 --> Total execution time: 0.0613
INFO - 2024-12-06 00:59:58 --> Config Class Initialized
INFO - 2024-12-06 00:59:58 --> Hooks Class Initialized
DEBUG - 2024-12-06 00:59:58 --> UTF-8 Support Enabled
INFO - 2024-12-06 00:59:58 --> Utf8 Class Initialized
INFO - 2024-12-06 00:59:58 --> URI Class Initialized
INFO - 2024-12-06 00:59:58 --> Router Class Initialized
INFO - 2024-12-06 00:59:58 --> Output Class Initialized
INFO - 2024-12-06 00:59:58 --> Security Class Initialized
DEBUG - 2024-12-06 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 00:59:58 --> CSRF cookie sent
INFO - 2024-12-06 00:59:58 --> Input Class Initialized
INFO - 2024-12-06 00:59:58 --> Language Class Initialized
INFO - 2024-12-06 00:59:58 --> Loader Class Initialized
INFO - 2024-12-06 00:59:58 --> Helper loaded: url_helper
INFO - 2024-12-06 00:59:58 --> Helper loaded: form_helper
INFO - 2024-12-06 00:59:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 00:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 00:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 00:59:58 --> Form Validation Class Initialized
INFO - 2024-12-06 00:59:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 00:59:58 --> Controller Class Initialized
INFO - 2024-12-06 00:59:58 --> Model "Review_model" initialized
INFO - 2024-12-06 00:59:58 --> Model "Category_model" initialized
INFO - 2024-12-06 00:59:58 --> Model "User_model" initialized
INFO - 2024-12-06 00:59:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 00:59:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 00:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 00:59:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 00:59:58 --> Final output sent to browser
DEBUG - 2024-12-06 00:59:58 --> Total execution time: 0.0772
INFO - 2024-12-06 01:00:06 --> Config Class Initialized
INFO - 2024-12-06 01:00:06 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:00:06 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:00:06 --> Utf8 Class Initialized
INFO - 2024-12-06 01:00:06 --> URI Class Initialized
INFO - 2024-12-06 01:00:06 --> Router Class Initialized
INFO - 2024-12-06 01:00:06 --> Output Class Initialized
INFO - 2024-12-06 01:00:06 --> Security Class Initialized
DEBUG - 2024-12-06 01:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:00:06 --> CSRF cookie sent
INFO - 2024-12-06 01:00:06 --> Input Class Initialized
INFO - 2024-12-06 01:00:06 --> Language Class Initialized
INFO - 2024-12-06 01:00:06 --> Loader Class Initialized
INFO - 2024-12-06 01:00:06 --> Helper loaded: url_helper
INFO - 2024-12-06 01:00:06 --> Helper loaded: form_helper
INFO - 2024-12-06 01:00:06 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:00:06 --> Form Validation Class Initialized
INFO - 2024-12-06 01:00:06 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:00:06 --> Controller Class Initialized
INFO - 2024-12-06 01:00:06 --> Model "User_model" initialized
INFO - 2024-12-06 01:00:06 --> Model "Category_model" initialized
INFO - 2024-12-06 01:00:06 --> Model "Review_model" initialized
INFO - 2024-12-06 01:00:06 --> Model "News_model" initialized
INFO - 2024-12-06 01:00:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:00:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:00:06 --> Query result: stdClass Object
(
    [view_count] => 77
)

INFO - 2024-12-06 01:00:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:00:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:00:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 01:00:06 --> Final output sent to browser
DEBUG - 2024-12-06 01:00:06 --> Total execution time: 0.4382
INFO - 2024-12-06 01:00:49 --> Config Class Initialized
INFO - 2024-12-06 01:00:49 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:00:49 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:00:49 --> Utf8 Class Initialized
INFO - 2024-12-06 01:00:49 --> URI Class Initialized
INFO - 2024-12-06 01:00:49 --> Router Class Initialized
INFO - 2024-12-06 01:00:49 --> Output Class Initialized
INFO - 2024-12-06 01:00:49 --> Security Class Initialized
DEBUG - 2024-12-06 01:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:00:49 --> CSRF cookie sent
INFO - 2024-12-06 01:00:49 --> Input Class Initialized
INFO - 2024-12-06 01:00:49 --> Language Class Initialized
INFO - 2024-12-06 01:00:49 --> Loader Class Initialized
INFO - 2024-12-06 01:00:49 --> Helper loaded: url_helper
INFO - 2024-12-06 01:00:49 --> Helper loaded: form_helper
INFO - 2024-12-06 01:00:49 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:00:49 --> Form Validation Class Initialized
INFO - 2024-12-06 01:00:49 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:00:49 --> Controller Class Initialized
INFO - 2024-12-06 01:00:49 --> Model "Review_model" initialized
INFO - 2024-12-06 01:00:49 --> Model "Category_model" initialized
INFO - 2024-12-06 01:00:49 --> Model "User_model" initialized
INFO - 2024-12-06 01:00:49 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:00:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:00:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 01:00:49 --> Final output sent to browser
DEBUG - 2024-12-06 01:00:49 --> Total execution time: 0.1855
INFO - 2024-12-06 01:00:52 --> Config Class Initialized
INFO - 2024-12-06 01:00:52 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:00:52 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:00:52 --> Utf8 Class Initialized
INFO - 2024-12-06 01:00:52 --> URI Class Initialized
INFO - 2024-12-06 01:00:52 --> Router Class Initialized
INFO - 2024-12-06 01:00:52 --> Output Class Initialized
INFO - 2024-12-06 01:00:52 --> Security Class Initialized
DEBUG - 2024-12-06 01:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:00:52 --> CSRF cookie sent
INFO - 2024-12-06 01:00:52 --> Input Class Initialized
INFO - 2024-12-06 01:00:52 --> Language Class Initialized
INFO - 2024-12-06 01:00:52 --> Loader Class Initialized
INFO - 2024-12-06 01:00:52 --> Helper loaded: url_helper
INFO - 2024-12-06 01:00:52 --> Helper loaded: form_helper
INFO - 2024-12-06 01:00:52 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:00:52 --> Form Validation Class Initialized
INFO - 2024-12-06 01:00:52 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:00:52 --> Controller Class Initialized
INFO - 2024-12-06 01:00:52 --> Model "Review_model" initialized
INFO - 2024-12-06 01:00:52 --> Model "Category_model" initialized
INFO - 2024-12-06 01:00:52 --> Model "User_model" initialized
INFO - 2024-12-06 01:00:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:00:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:00:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 01:00:52 --> Final output sent to browser
DEBUG - 2024-12-06 01:00:52 --> Total execution time: 0.0628
INFO - 2024-12-06 01:00:54 --> Config Class Initialized
INFO - 2024-12-06 01:00:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:00:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:00:54 --> Utf8 Class Initialized
INFO - 2024-12-06 01:00:54 --> URI Class Initialized
INFO - 2024-12-06 01:00:54 --> Router Class Initialized
INFO - 2024-12-06 01:00:54 --> Output Class Initialized
INFO - 2024-12-06 01:00:54 --> Security Class Initialized
DEBUG - 2024-12-06 01:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:00:54 --> CSRF cookie sent
INFO - 2024-12-06 01:00:54 --> Input Class Initialized
INFO - 2024-12-06 01:00:54 --> Language Class Initialized
INFO - 2024-12-06 01:00:54 --> Loader Class Initialized
INFO - 2024-12-06 01:00:54 --> Helper loaded: url_helper
INFO - 2024-12-06 01:00:54 --> Helper loaded: form_helper
INFO - 2024-12-06 01:00:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:00:54 --> Form Validation Class Initialized
INFO - 2024-12-06 01:00:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:00:54 --> Controller Class Initialized
INFO - 2024-12-06 01:00:54 --> Model "Review_model" initialized
INFO - 2024-12-06 01:00:54 --> Model "Category_model" initialized
INFO - 2024-12-06 01:00:54 --> Model "User_model" initialized
INFO - 2024-12-06 01:00:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:00:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:00:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 01:00:54 --> Final output sent to browser
DEBUG - 2024-12-06 01:00:54 --> Total execution time: 0.0596
INFO - 2024-12-06 01:00:55 --> Config Class Initialized
INFO - 2024-12-06 01:00:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:00:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:00:55 --> Utf8 Class Initialized
INFO - 2024-12-06 01:00:55 --> URI Class Initialized
INFO - 2024-12-06 01:00:55 --> Router Class Initialized
INFO - 2024-12-06 01:00:55 --> Output Class Initialized
INFO - 2024-12-06 01:00:55 --> Security Class Initialized
DEBUG - 2024-12-06 01:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:00:55 --> CSRF cookie sent
INFO - 2024-12-06 01:00:55 --> Input Class Initialized
INFO - 2024-12-06 01:00:55 --> Language Class Initialized
INFO - 2024-12-06 01:00:55 --> Loader Class Initialized
INFO - 2024-12-06 01:00:55 --> Helper loaded: url_helper
INFO - 2024-12-06 01:00:55 --> Helper loaded: form_helper
INFO - 2024-12-06 01:00:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:00:55 --> Form Validation Class Initialized
INFO - 2024-12-06 01:00:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:00:55 --> Controller Class Initialized
INFO - 2024-12-06 01:00:55 --> Model "Review_model" initialized
INFO - 2024-12-06 01:00:55 --> Model "Category_model" initialized
INFO - 2024-12-06 01:00:55 --> Model "User_model" initialized
INFO - 2024-12-06 01:00:55 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:00:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:00:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 01:00:55 --> Final output sent to browser
DEBUG - 2024-12-06 01:00:55 --> Total execution time: 0.0827
INFO - 2024-12-06 01:00:59 --> Config Class Initialized
INFO - 2024-12-06 01:00:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:00:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:00:59 --> Utf8 Class Initialized
INFO - 2024-12-06 01:00:59 --> URI Class Initialized
INFO - 2024-12-06 01:00:59 --> Router Class Initialized
INFO - 2024-12-06 01:00:59 --> Output Class Initialized
INFO - 2024-12-06 01:00:59 --> Security Class Initialized
DEBUG - 2024-12-06 01:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:00:59 --> CSRF cookie sent
INFO - 2024-12-06 01:00:59 --> Input Class Initialized
INFO - 2024-12-06 01:00:59 --> Language Class Initialized
INFO - 2024-12-06 01:00:59 --> Loader Class Initialized
INFO - 2024-12-06 01:00:59 --> Helper loaded: url_helper
INFO - 2024-12-06 01:00:59 --> Helper loaded: form_helper
INFO - 2024-12-06 01:00:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:00:59 --> Form Validation Class Initialized
INFO - 2024-12-06 01:00:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:00:59 --> Controller Class Initialized
INFO - 2024-12-06 01:00:59 --> Model "Review_model" initialized
INFO - 2024-12-06 01:00:59 --> Model "Category_model" initialized
INFO - 2024-12-06 01:00:59 --> Model "User_model" initialized
INFO - 2024-12-06 01:00:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:00:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:00:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 01:00:59 --> Final output sent to browser
DEBUG - 2024-12-06 01:00:59 --> Total execution time: 0.0646
INFO - 2024-12-06 01:01:01 --> Config Class Initialized
INFO - 2024-12-06 01:01:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:01:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:01:01 --> Utf8 Class Initialized
INFO - 2024-12-06 01:01:01 --> URI Class Initialized
INFO - 2024-12-06 01:01:01 --> Router Class Initialized
INFO - 2024-12-06 01:01:01 --> Output Class Initialized
INFO - 2024-12-06 01:01:01 --> Security Class Initialized
DEBUG - 2024-12-06 01:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:01:01 --> CSRF cookie sent
INFO - 2024-12-06 01:01:01 --> Input Class Initialized
INFO - 2024-12-06 01:01:01 --> Language Class Initialized
INFO - 2024-12-06 01:01:01 --> Loader Class Initialized
INFO - 2024-12-06 01:01:01 --> Helper loaded: url_helper
INFO - 2024-12-06 01:01:01 --> Helper loaded: form_helper
INFO - 2024-12-06 01:01:01 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:01:01 --> Form Validation Class Initialized
INFO - 2024-12-06 01:01:01 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:01:01 --> Controller Class Initialized
INFO - 2024-12-06 01:01:01 --> Model "News_model" initialized
INFO - 2024-12-06 01:01:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 01:01:01 --> Final output sent to browser
DEBUG - 2024-12-06 01:01:01 --> Total execution time: 0.0644
INFO - 2024-12-06 01:01:05 --> Config Class Initialized
INFO - 2024-12-06 01:01:05 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:01:05 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:01:05 --> Utf8 Class Initialized
INFO - 2024-12-06 01:01:05 --> URI Class Initialized
INFO - 2024-12-06 01:01:05 --> Router Class Initialized
INFO - 2024-12-06 01:01:05 --> Output Class Initialized
INFO - 2024-12-06 01:01:05 --> Security Class Initialized
DEBUG - 2024-12-06 01:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:01:05 --> CSRF cookie sent
INFO - 2024-12-06 01:01:05 --> Input Class Initialized
INFO - 2024-12-06 01:01:05 --> Language Class Initialized
INFO - 2024-12-06 01:01:05 --> Loader Class Initialized
INFO - 2024-12-06 01:01:05 --> Helper loaded: url_helper
INFO - 2024-12-06 01:01:05 --> Helper loaded: form_helper
INFO - 2024-12-06 01:01:05 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:01:05 --> Form Validation Class Initialized
INFO - 2024-12-06 01:01:05 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:01:05 --> Controller Class Initialized
INFO - 2024-12-06 01:01:05 --> Model "Review_model" initialized
INFO - 2024-12-06 01:01:05 --> Model "Category_model" initialized
INFO - 2024-12-06 01:01:05 --> Model "User_model" initialized
INFO - 2024-12-06 01:01:05 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:01:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:01:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 01:01:05 --> Final output sent to browser
DEBUG - 2024-12-06 01:01:05 --> Total execution time: 0.0673
INFO - 2024-12-06 01:01:11 --> Config Class Initialized
INFO - 2024-12-06 01:01:11 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:01:11 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:01:11 --> Utf8 Class Initialized
INFO - 2024-12-06 01:01:11 --> URI Class Initialized
INFO - 2024-12-06 01:01:11 --> Router Class Initialized
INFO - 2024-12-06 01:01:11 --> Output Class Initialized
INFO - 2024-12-06 01:01:11 --> Security Class Initialized
DEBUG - 2024-12-06 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:01:11 --> CSRF cookie sent
INFO - 2024-12-06 01:01:11 --> Input Class Initialized
INFO - 2024-12-06 01:01:11 --> Language Class Initialized
INFO - 2024-12-06 01:01:11 --> Loader Class Initialized
INFO - 2024-12-06 01:01:11 --> Helper loaded: url_helper
INFO - 2024-12-06 01:01:11 --> Helper loaded: form_helper
INFO - 2024-12-06 01:01:11 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:01:11 --> Form Validation Class Initialized
INFO - 2024-12-06 01:01:11 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:01:11 --> Controller Class Initialized
INFO - 2024-12-06 01:01:11 --> Model "Review_model" initialized
INFO - 2024-12-06 01:01:11 --> Model "Category_model" initialized
INFO - 2024-12-06 01:01:11 --> Model "User_model" initialized
INFO - 2024-12-06 01:01:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:01:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:01:11 --> Model "Contact_model" initialized
INFO - 2024-12-06 01:01:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-06 01:01:11 --> Final output sent to browser
DEBUG - 2024-12-06 01:01:11 --> Total execution time: 0.0827
INFO - 2024-12-06 01:01:14 --> Config Class Initialized
INFO - 2024-12-06 01:01:14 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:01:14 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:01:14 --> Utf8 Class Initialized
INFO - 2024-12-06 01:01:14 --> URI Class Initialized
INFO - 2024-12-06 01:01:14 --> Router Class Initialized
INFO - 2024-12-06 01:01:14 --> Output Class Initialized
INFO - 2024-12-06 01:01:14 --> Security Class Initialized
DEBUG - 2024-12-06 01:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:01:14 --> CSRF cookie sent
INFO - 2024-12-06 01:01:14 --> Input Class Initialized
INFO - 2024-12-06 01:01:14 --> Language Class Initialized
INFO - 2024-12-06 01:01:14 --> Loader Class Initialized
INFO - 2024-12-06 01:01:14 --> Helper loaded: url_helper
INFO - 2024-12-06 01:01:14 --> Helper loaded: form_helper
INFO - 2024-12-06 01:01:14 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:01:14 --> Form Validation Class Initialized
INFO - 2024-12-06 01:01:14 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:01:14 --> Controller Class Initialized
INFO - 2024-12-06 01:01:14 --> Model "Review_model" initialized
INFO - 2024-12-06 01:01:14 --> Model "Category_model" initialized
INFO - 2024-12-06 01:01:14 --> Model "User_model" initialized
INFO - 2024-12-06 01:01:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:01:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:01:14 --> Query result: stdClass Object
(
    [view_count] => 77
)

INFO - 2024-12-06 01:01:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 01:01:14 --> Final output sent to browser
DEBUG - 2024-12-06 01:01:14 --> Total execution time: 0.0828
INFO - 2024-12-06 01:11:00 --> Config Class Initialized
INFO - 2024-12-06 01:11:00 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:00 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:00 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:00 --> URI Class Initialized
INFO - 2024-12-06 01:11:00 --> Router Class Initialized
INFO - 2024-12-06 01:11:00 --> Output Class Initialized
INFO - 2024-12-06 01:11:00 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:00 --> CSRF cookie sent
INFO - 2024-12-06 01:11:00 --> Input Class Initialized
INFO - 2024-12-06 01:11:00 --> Language Class Initialized
INFO - 2024-12-06 01:11:00 --> Loader Class Initialized
INFO - 2024-12-06 01:11:00 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:00 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:00 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:00 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:00 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:00 --> Controller Class Initialized
INFO - 2024-12-06 01:11:00 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:00 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:00 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:11:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 01:11:00 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:00 --> Total execution time: 0.7433
INFO - 2024-12-06 01:11:03 --> Config Class Initialized
INFO - 2024-12-06 01:11:03 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:03 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:03 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:03 --> URI Class Initialized
INFO - 2024-12-06 01:11:03 --> Router Class Initialized
INFO - 2024-12-06 01:11:03 --> Output Class Initialized
INFO - 2024-12-06 01:11:03 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:03 --> CSRF cookie sent
INFO - 2024-12-06 01:11:03 --> Input Class Initialized
INFO - 2024-12-06 01:11:03 --> Language Class Initialized
INFO - 2024-12-06 01:11:03 --> Loader Class Initialized
INFO - 2024-12-06 01:11:03 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:03 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:03 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:03 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:03 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:03 --> Controller Class Initialized
INFO - 2024-12-06 01:11:03 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:03 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:03 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:03 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:11:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 01:11:03 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:03 --> Total execution time: 0.1163
INFO - 2024-12-06 01:11:05 --> Config Class Initialized
INFO - 2024-12-06 01:11:05 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:05 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:05 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:05 --> URI Class Initialized
INFO - 2024-12-06 01:11:05 --> Router Class Initialized
INFO - 2024-12-06 01:11:05 --> Output Class Initialized
INFO - 2024-12-06 01:11:05 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:05 --> CSRF cookie sent
INFO - 2024-12-06 01:11:05 --> Input Class Initialized
INFO - 2024-12-06 01:11:05 --> Language Class Initialized
INFO - 2024-12-06 01:11:05 --> Loader Class Initialized
INFO - 2024-12-06 01:11:05 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:05 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:05 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:05 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:05 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:05 --> Controller Class Initialized
INFO - 2024-12-06 01:11:05 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:05 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:05 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:05 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:11:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 01:11:05 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:05 --> Total execution time: 0.0747
INFO - 2024-12-06 01:11:07 --> Config Class Initialized
INFO - 2024-12-06 01:11:07 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:07 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:07 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:07 --> URI Class Initialized
INFO - 2024-12-06 01:11:07 --> Router Class Initialized
INFO - 2024-12-06 01:11:07 --> Output Class Initialized
INFO - 2024-12-06 01:11:07 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:07 --> CSRF cookie sent
INFO - 2024-12-06 01:11:07 --> Input Class Initialized
INFO - 2024-12-06 01:11:07 --> Language Class Initialized
INFO - 2024-12-06 01:11:07 --> Loader Class Initialized
INFO - 2024-12-06 01:11:07 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:07 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:07 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:07 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:07 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:07 --> Controller Class Initialized
INFO - 2024-12-06 01:11:07 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:07 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:07 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:07 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:11:07 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:07 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 01:11:07 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:07 --> Total execution time: 0.0920
INFO - 2024-12-06 01:11:08 --> Config Class Initialized
INFO - 2024-12-06 01:11:08 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:08 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:08 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:08 --> URI Class Initialized
INFO - 2024-12-06 01:11:08 --> Router Class Initialized
INFO - 2024-12-06 01:11:08 --> Output Class Initialized
INFO - 2024-12-06 01:11:08 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:08 --> CSRF cookie sent
INFO - 2024-12-06 01:11:08 --> Input Class Initialized
INFO - 2024-12-06 01:11:08 --> Language Class Initialized
INFO - 2024-12-06 01:11:08 --> Loader Class Initialized
INFO - 2024-12-06 01:11:08 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:08 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:08 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:08 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:08 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:08 --> Controller Class Initialized
INFO - 2024-12-06 01:11:08 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 01:11:08 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:08 --> Total execution time: 0.0510
INFO - 2024-12-06 01:11:10 --> Config Class Initialized
INFO - 2024-12-06 01:11:10 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:10 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:10 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:10 --> URI Class Initialized
INFO - 2024-12-06 01:11:10 --> Router Class Initialized
INFO - 2024-12-06 01:11:10 --> Output Class Initialized
INFO - 2024-12-06 01:11:10 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:10 --> CSRF cookie sent
INFO - 2024-12-06 01:11:10 --> Input Class Initialized
INFO - 2024-12-06 01:11:10 --> Language Class Initialized
INFO - 2024-12-06 01:11:10 --> Loader Class Initialized
INFO - 2024-12-06 01:11:10 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:10 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:10 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:10 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:10 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:10 --> Controller Class Initialized
INFO - 2024-12-06 01:11:10 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:10 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:10 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:10 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:11:10 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:10 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 01:11:10 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:10 --> Total execution time: 0.1172
INFO - 2024-12-06 01:11:12 --> Config Class Initialized
INFO - 2024-12-06 01:11:12 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:12 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:12 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:12 --> URI Class Initialized
INFO - 2024-12-06 01:11:12 --> Router Class Initialized
INFO - 2024-12-06 01:11:12 --> Output Class Initialized
INFO - 2024-12-06 01:11:12 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:12 --> CSRF cookie sent
INFO - 2024-12-06 01:11:12 --> Input Class Initialized
INFO - 2024-12-06 01:11:12 --> Language Class Initialized
INFO - 2024-12-06 01:11:12 --> Loader Class Initialized
INFO - 2024-12-06 01:11:12 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:12 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:12 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:12 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:12 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:12 --> Controller Class Initialized
INFO - 2024-12-06 01:11:12 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:12 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:12 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:11:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:12 --> Model "Contact_model" initialized
INFO - 2024-12-06 01:11:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-06 01:11:12 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:12 --> Total execution time: 0.0571
INFO - 2024-12-06 01:11:13 --> Config Class Initialized
INFO - 2024-12-06 01:11:13 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:13 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:13 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:13 --> URI Class Initialized
INFO - 2024-12-06 01:11:13 --> Router Class Initialized
INFO - 2024-12-06 01:11:13 --> Output Class Initialized
INFO - 2024-12-06 01:11:13 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:13 --> CSRF cookie sent
INFO - 2024-12-06 01:11:13 --> Input Class Initialized
INFO - 2024-12-06 01:11:13 --> Language Class Initialized
INFO - 2024-12-06 01:11:13 --> Loader Class Initialized
INFO - 2024-12-06 01:11:13 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:13 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:13 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:13 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:13 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:13 --> Controller Class Initialized
INFO - 2024-12-06 01:11:13 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:13 --> Config Class Initialized
INFO - 2024-12-06 01:11:13 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:13 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:13 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:13 --> URI Class Initialized
INFO - 2024-12-06 01:11:13 --> Router Class Initialized
INFO - 2024-12-06 01:11:13 --> Output Class Initialized
INFO - 2024-12-06 01:11:13 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:13 --> CSRF cookie sent
INFO - 2024-12-06 01:11:13 --> Input Class Initialized
INFO - 2024-12-06 01:11:13 --> Language Class Initialized
INFO - 2024-12-06 01:11:13 --> Loader Class Initialized
INFO - 2024-12-06 01:11:13 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:13 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:13 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:13 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:13 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:13 --> Controller Class Initialized
INFO - 2024-12-06 01:11:13 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:11:13 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:13 --> Total execution time: 0.0695
INFO - 2024-12-06 01:11:16 --> Config Class Initialized
INFO - 2024-12-06 01:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:16 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:16 --> URI Class Initialized
INFO - 2024-12-06 01:11:16 --> Router Class Initialized
INFO - 2024-12-06 01:11:16 --> Output Class Initialized
INFO - 2024-12-06 01:11:16 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:16 --> CSRF cookie sent
INFO - 2024-12-06 01:11:16 --> CSRF token verified
INFO - 2024-12-06 01:11:16 --> Input Class Initialized
INFO - 2024-12-06 01:11:16 --> Language Class Initialized
INFO - 2024-12-06 01:11:16 --> Loader Class Initialized
INFO - 2024-12-06 01:11:16 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:16 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:16 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:16 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:16 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:16 --> Controller Class Initialized
INFO - 2024-12-06 01:11:16 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:16 --> Config Class Initialized
INFO - 2024-12-06 01:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:16 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:16 --> URI Class Initialized
INFO - 2024-12-06 01:11:16 --> Router Class Initialized
INFO - 2024-12-06 01:11:16 --> Output Class Initialized
INFO - 2024-12-06 01:11:16 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:16 --> CSRF cookie sent
INFO - 2024-12-06 01:11:16 --> Input Class Initialized
INFO - 2024-12-06 01:11:16 --> Language Class Initialized
INFO - 2024-12-06 01:11:16 --> Loader Class Initialized
INFO - 2024-12-06 01:11:16 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:16 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:16 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:16 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:16 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:16 --> Controller Class Initialized
INFO - 2024-12-06 01:11:16 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:11:16 --> Query result: stdClass Object
(
    [view_count] => 78
)

INFO - 2024-12-06 01:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 01:11:16 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:17 --> Total execution time: 0.2151
INFO - 2024-12-06 01:11:17 --> Config Class Initialized
INFO - 2024-12-06 01:11:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:17 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:17 --> URI Class Initialized
INFO - 2024-12-06 01:11:17 --> Router Class Initialized
INFO - 2024-12-06 01:11:17 --> Output Class Initialized
INFO - 2024-12-06 01:11:17 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:17 --> CSRF cookie sent
INFO - 2024-12-06 01:11:17 --> Input Class Initialized
INFO - 2024-12-06 01:11:17 --> Language Class Initialized
ERROR - 2024-12-06 01:11:17 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 01:11:38 --> Config Class Initialized
INFO - 2024-12-06 01:11:38 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:38 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:38 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:38 --> URI Class Initialized
INFO - 2024-12-06 01:11:38 --> Router Class Initialized
INFO - 2024-12-06 01:11:38 --> Output Class Initialized
INFO - 2024-12-06 01:11:38 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:38 --> CSRF cookie sent
INFO - 2024-12-06 01:11:38 --> Input Class Initialized
INFO - 2024-12-06 01:11:38 --> Language Class Initialized
INFO - 2024-12-06 01:11:38 --> Loader Class Initialized
INFO - 2024-12-06 01:11:38 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:38 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:39 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:39 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:39 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:39 --> Controller Class Initialized
INFO - 2024-12-06 01:11:39 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:39 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:39 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:39 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-06 01:11:39 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:39 --> Total execution time: 0.1506
INFO - 2024-12-06 01:11:42 --> Config Class Initialized
INFO - 2024-12-06 01:11:42 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:42 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:42 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:42 --> URI Class Initialized
INFO - 2024-12-06 01:11:42 --> Router Class Initialized
INFO - 2024-12-06 01:11:42 --> Output Class Initialized
INFO - 2024-12-06 01:11:42 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:42 --> CSRF cookie sent
INFO - 2024-12-06 01:11:42 --> Input Class Initialized
INFO - 2024-12-06 01:11:42 --> Language Class Initialized
INFO - 2024-12-06 01:11:42 --> Loader Class Initialized
INFO - 2024-12-06 01:11:42 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:42 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:42 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:43 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:43 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:43 --> Controller Class Initialized
INFO - 2024-12-06 01:11:43 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:43 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:43 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:43 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-06 01:11:43 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:43 --> Total execution time: 0.2499
INFO - 2024-12-06 01:11:45 --> Config Class Initialized
INFO - 2024-12-06 01:11:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:45 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:45 --> URI Class Initialized
INFO - 2024-12-06 01:11:45 --> Router Class Initialized
INFO - 2024-12-06 01:11:45 --> Output Class Initialized
INFO - 2024-12-06 01:11:45 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:45 --> CSRF cookie sent
INFO - 2024-12-06 01:11:45 --> Input Class Initialized
INFO - 2024-12-06 01:11:45 --> Language Class Initialized
INFO - 2024-12-06 01:11:45 --> Loader Class Initialized
INFO - 2024-12-06 01:11:45 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:45 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:45 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:45 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:45 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:45 --> Controller Class Initialized
INFO - 2024-12-06 01:11:45 --> Model "User_model" initialized
DEBUG - 2024-12-06 01:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:11:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\profile/index.php
INFO - 2024-12-06 01:11:45 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:45 --> Total execution time: 0.0638
INFO - 2024-12-06 01:11:49 --> Config Class Initialized
INFO - 2024-12-06 01:11:49 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:49 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:49 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:49 --> URI Class Initialized
INFO - 2024-12-06 01:11:49 --> Router Class Initialized
INFO - 2024-12-06 01:11:49 --> Output Class Initialized
INFO - 2024-12-06 01:11:49 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:49 --> CSRF cookie sent
INFO - 2024-12-06 01:11:49 --> Input Class Initialized
INFO - 2024-12-06 01:11:49 --> Language Class Initialized
INFO - 2024-12-06 01:11:49 --> Loader Class Initialized
INFO - 2024-12-06 01:11:49 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:49 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:49 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:49 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:49 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:49 --> Controller Class Initialized
INFO - 2024-12-06 01:11:49 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:49 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:49 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:49 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/add.php
INFO - 2024-12-06 01:11:49 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:49 --> Total execution time: 0.0546
INFO - 2024-12-06 01:11:57 --> Config Class Initialized
INFO - 2024-12-06 01:11:57 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:57 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:57 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:57 --> URI Class Initialized
INFO - 2024-12-06 01:11:57 --> Router Class Initialized
INFO - 2024-12-06 01:11:57 --> Output Class Initialized
INFO - 2024-12-06 01:11:57 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:57 --> CSRF cookie sent
INFO - 2024-12-06 01:11:57 --> Input Class Initialized
INFO - 2024-12-06 01:11:57 --> Language Class Initialized
INFO - 2024-12-06 01:11:57 --> Loader Class Initialized
INFO - 2024-12-06 01:11:57 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:57 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:58 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:58 --> Controller Class Initialized
INFO - 2024-12-06 01:11:58 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:58 --> Config Class Initialized
INFO - 2024-12-06 01:11:58 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:58 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:58 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:58 --> URI Class Initialized
INFO - 2024-12-06 01:11:58 --> Router Class Initialized
INFO - 2024-12-06 01:11:58 --> Output Class Initialized
INFO - 2024-12-06 01:11:58 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:58 --> CSRF cookie sent
INFO - 2024-12-06 01:11:58 --> Input Class Initialized
INFO - 2024-12-06 01:11:58 --> Language Class Initialized
INFO - 2024-12-06 01:11:58 --> Loader Class Initialized
INFO - 2024-12-06 01:11:58 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:58 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:58 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:58 --> Controller Class Initialized
INFO - 2024-12-06 01:11:58 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:11:58 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:58 --> Total execution time: 0.0648
INFO - 2024-12-06 01:11:59 --> Config Class Initialized
INFO - 2024-12-06 01:11:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:59 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:59 --> URI Class Initialized
INFO - 2024-12-06 01:11:59 --> Router Class Initialized
INFO - 2024-12-06 01:11:59 --> Output Class Initialized
INFO - 2024-12-06 01:11:59 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:59 --> CSRF cookie sent
INFO - 2024-12-06 01:11:59 --> Input Class Initialized
INFO - 2024-12-06 01:11:59 --> Language Class Initialized
INFO - 2024-12-06 01:11:59 --> Loader Class Initialized
INFO - 2024-12-06 01:11:59 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:59 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:59 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:59 --> Controller Class Initialized
INFO - 2024-12-06 01:11:59 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:59 --> Config Class Initialized
INFO - 2024-12-06 01:11:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:11:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:11:59 --> Utf8 Class Initialized
INFO - 2024-12-06 01:11:59 --> URI Class Initialized
INFO - 2024-12-06 01:11:59 --> Router Class Initialized
INFO - 2024-12-06 01:11:59 --> Output Class Initialized
INFO - 2024-12-06 01:11:59 --> Security Class Initialized
DEBUG - 2024-12-06 01:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:11:59 --> CSRF cookie sent
INFO - 2024-12-06 01:11:59 --> Input Class Initialized
INFO - 2024-12-06 01:11:59 --> Language Class Initialized
INFO - 2024-12-06 01:11:59 --> Loader Class Initialized
INFO - 2024-12-06 01:11:59 --> Helper loaded: url_helper
INFO - 2024-12-06 01:11:59 --> Helper loaded: form_helper
INFO - 2024-12-06 01:11:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:11:59 --> Form Validation Class Initialized
INFO - 2024-12-06 01:11:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:11:59 --> Controller Class Initialized
INFO - 2024-12-06 01:11:59 --> Model "User_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "Category_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "Review_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "News_model" initialized
INFO - 2024-12-06 01:11:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:11:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:11:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:11:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:11:59 --> Final output sent to browser
DEBUG - 2024-12-06 01:11:59 --> Total execution time: 0.0513
INFO - 2024-12-06 01:21:51 --> Config Class Initialized
INFO - 2024-12-06 01:21:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:21:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:21:51 --> Utf8 Class Initialized
INFO - 2024-12-06 01:21:51 --> URI Class Initialized
DEBUG - 2024-12-06 01:21:51 --> No URI present. Default controller set.
INFO - 2024-12-06 01:21:51 --> Router Class Initialized
INFO - 2024-12-06 01:21:51 --> Output Class Initialized
INFO - 2024-12-06 01:21:51 --> Security Class Initialized
DEBUG - 2024-12-06 01:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:21:51 --> CSRF cookie sent
INFO - 2024-12-06 01:21:51 --> Input Class Initialized
INFO - 2024-12-06 01:21:51 --> Language Class Initialized
INFO - 2024-12-06 01:21:51 --> Loader Class Initialized
INFO - 2024-12-06 01:21:51 --> Helper loaded: url_helper
INFO - 2024-12-06 01:21:51 --> Helper loaded: form_helper
INFO - 2024-12-06 01:21:51 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:21:51 --> Form Validation Class Initialized
INFO - 2024-12-06 01:21:51 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:21:51 --> Controller Class Initialized
INFO - 2024-12-06 01:21:51 --> Model "User_model" initialized
INFO - 2024-12-06 01:21:51 --> Model "Category_model" initialized
INFO - 2024-12-06 01:21:51 --> Model "Review_model" initialized
INFO - 2024-12-06 01:21:51 --> Model "News_model" initialized
INFO - 2024-12-06 01:21:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:21:51 --> Query result: stdClass Object
(
    [view_count] => 79
)

INFO - 2024-12-06 01:21:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:21:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:21:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 01:21:51 --> Final output sent to browser
DEBUG - 2024-12-06 01:21:51 --> Total execution time: 0.7168
INFO - 2024-12-06 01:25:48 --> Config Class Initialized
INFO - 2024-12-06 01:25:48 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:25:48 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:25:48 --> Utf8 Class Initialized
INFO - 2024-12-06 01:25:48 --> URI Class Initialized
DEBUG - 2024-12-06 01:25:48 --> No URI present. Default controller set.
INFO - 2024-12-06 01:25:48 --> Router Class Initialized
INFO - 2024-12-06 01:25:48 --> Output Class Initialized
INFO - 2024-12-06 01:25:48 --> Security Class Initialized
DEBUG - 2024-12-06 01:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:25:48 --> CSRF cookie sent
INFO - 2024-12-06 01:25:48 --> Input Class Initialized
INFO - 2024-12-06 01:25:48 --> Language Class Initialized
INFO - 2024-12-06 01:25:48 --> Loader Class Initialized
INFO - 2024-12-06 01:25:48 --> Helper loaded: url_helper
INFO - 2024-12-06 01:25:48 --> Helper loaded: form_helper
INFO - 2024-12-06 01:25:48 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:25:48 --> Form Validation Class Initialized
INFO - 2024-12-06 01:25:48 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:25:48 --> Controller Class Initialized
INFO - 2024-12-06 01:25:48 --> Model "User_model" initialized
INFO - 2024-12-06 01:25:48 --> Model "Category_model" initialized
INFO - 2024-12-06 01:25:48 --> Model "Review_model" initialized
INFO - 2024-12-06 01:25:48 --> Model "News_model" initialized
INFO - 2024-12-06 01:25:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:25:48 --> Query result: stdClass Object
(
    [view_count] => 80
)

INFO - 2024-12-06 01:25:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:25:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:25:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 01:25:48 --> Final output sent to browser
DEBUG - 2024-12-06 01:25:48 --> Total execution time: 0.0973
INFO - 2024-12-06 01:25:49 --> Config Class Initialized
INFO - 2024-12-06 01:25:49 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:25:49 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:25:49 --> Utf8 Class Initialized
INFO - 2024-12-06 01:25:50 --> URI Class Initialized
INFO - 2024-12-06 01:25:50 --> Router Class Initialized
INFO - 2024-12-06 01:25:50 --> Output Class Initialized
INFO - 2024-12-06 01:25:50 --> Security Class Initialized
DEBUG - 2024-12-06 01:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:25:50 --> CSRF cookie sent
INFO - 2024-12-06 01:25:50 --> Input Class Initialized
INFO - 2024-12-06 01:25:50 --> Language Class Initialized
INFO - 2024-12-06 01:25:50 --> Loader Class Initialized
INFO - 2024-12-06 01:25:50 --> Helper loaded: url_helper
INFO - 2024-12-06 01:25:50 --> Helper loaded: form_helper
INFO - 2024-12-06 01:25:50 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:25:50 --> Form Validation Class Initialized
INFO - 2024-12-06 01:25:50 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:25:50 --> Controller Class Initialized
INFO - 2024-12-06 01:25:50 --> Model "User_model" initialized
INFO - 2024-12-06 01:25:50 --> Model "Category_model" initialized
INFO - 2024-12-06 01:25:50 --> Model "Review_model" initialized
INFO - 2024-12-06 01:25:50 --> Model "News_model" initialized
INFO - 2024-12-06 01:25:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:25:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:25:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:25:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:25:50 --> Final output sent to browser
DEBUG - 2024-12-06 01:25:50 --> Total execution time: 0.0782
INFO - 2024-12-06 01:25:54 --> Config Class Initialized
INFO - 2024-12-06 01:25:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:25:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:25:54 --> Utf8 Class Initialized
INFO - 2024-12-06 01:25:54 --> URI Class Initialized
INFO - 2024-12-06 01:25:54 --> Router Class Initialized
INFO - 2024-12-06 01:25:54 --> Output Class Initialized
INFO - 2024-12-06 01:25:54 --> Security Class Initialized
DEBUG - 2024-12-06 01:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:25:54 --> CSRF cookie sent
INFO - 2024-12-06 01:25:54 --> CSRF token verified
INFO - 2024-12-06 01:25:54 --> Input Class Initialized
INFO - 2024-12-06 01:25:54 --> Language Class Initialized
INFO - 2024-12-06 01:25:54 --> Loader Class Initialized
INFO - 2024-12-06 01:25:54 --> Helper loaded: url_helper
INFO - 2024-12-06 01:25:54 --> Helper loaded: form_helper
INFO - 2024-12-06 01:25:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:25:54 --> Form Validation Class Initialized
INFO - 2024-12-06 01:25:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:25:54 --> Controller Class Initialized
INFO - 2024-12-06 01:25:54 --> Model "User_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "Category_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "Review_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "News_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:25:54 --> Config Class Initialized
INFO - 2024-12-06 01:25:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:25:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:25:54 --> Utf8 Class Initialized
INFO - 2024-12-06 01:25:54 --> URI Class Initialized
INFO - 2024-12-06 01:25:54 --> Router Class Initialized
INFO - 2024-12-06 01:25:54 --> Output Class Initialized
INFO - 2024-12-06 01:25:54 --> Security Class Initialized
DEBUG - 2024-12-06 01:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:25:54 --> CSRF cookie sent
INFO - 2024-12-06 01:25:54 --> Input Class Initialized
INFO - 2024-12-06 01:25:54 --> Language Class Initialized
INFO - 2024-12-06 01:25:54 --> Loader Class Initialized
INFO - 2024-12-06 01:25:54 --> Helper loaded: url_helper
INFO - 2024-12-06 01:25:54 --> Helper loaded: form_helper
INFO - 2024-12-06 01:25:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:25:54 --> Form Validation Class Initialized
INFO - 2024-12-06 01:25:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:25:54 --> Controller Class Initialized
INFO - 2024-12-06 01:25:54 --> Model "Review_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "Category_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "User_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:25:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:25:54 --> Query result: stdClass Object
(
    [view_count] => 80
)

INFO - 2024-12-06 01:25:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 01:25:54 --> Final output sent to browser
DEBUG - 2024-12-06 01:25:54 --> Total execution time: 0.1818
INFO - 2024-12-06 01:54:46 --> Config Class Initialized
INFO - 2024-12-06 01:54:46 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:54:46 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:54:46 --> Utf8 Class Initialized
INFO - 2024-12-06 01:54:46 --> URI Class Initialized
INFO - 2024-12-06 01:54:46 --> Router Class Initialized
INFO - 2024-12-06 01:54:46 --> Output Class Initialized
INFO - 2024-12-06 01:54:46 --> Security Class Initialized
DEBUG - 2024-12-06 01:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:54:46 --> CSRF cookie sent
INFO - 2024-12-06 01:54:46 --> Input Class Initialized
INFO - 2024-12-06 01:54:46 --> Language Class Initialized
INFO - 2024-12-06 01:54:46 --> Loader Class Initialized
INFO - 2024-12-06 01:54:46 --> Helper loaded: url_helper
INFO - 2024-12-06 01:54:46 --> Helper loaded: form_helper
INFO - 2024-12-06 01:54:46 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:54:46 --> Form Validation Class Initialized
INFO - 2024-12-06 01:54:46 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:54:46 --> Controller Class Initialized
INFO - 2024-12-06 01:54:46 --> Model "User_model" initialized
INFO - 2024-12-06 01:54:46 --> Model "Category_model" initialized
INFO - 2024-12-06 01:54:46 --> Model "Review_model" initialized
INFO - 2024-12-06 01:54:46 --> Model "News_model" initialized
INFO - 2024-12-06 01:54:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:54:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:54:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:54:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:54:46 --> Final output sent to browser
DEBUG - 2024-12-06 01:54:46 --> Total execution time: 0.7909
INFO - 2024-12-06 01:57:21 --> Config Class Initialized
INFO - 2024-12-06 01:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:57:21 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:57:21 --> Utf8 Class Initialized
INFO - 2024-12-06 01:57:21 --> URI Class Initialized
INFO - 2024-12-06 01:57:21 --> Router Class Initialized
INFO - 2024-12-06 01:57:21 --> Output Class Initialized
INFO - 2024-12-06 01:57:21 --> Security Class Initialized
DEBUG - 2024-12-06 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:57:21 --> CSRF cookie sent
INFO - 2024-12-06 01:57:21 --> Input Class Initialized
INFO - 2024-12-06 01:57:21 --> Language Class Initialized
INFO - 2024-12-06 01:57:21 --> Loader Class Initialized
INFO - 2024-12-06 01:57:21 --> Helper loaded: url_helper
INFO - 2024-12-06 01:57:21 --> Helper loaded: form_helper
INFO - 2024-12-06 01:57:21 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:57:21 --> Form Validation Class Initialized
INFO - 2024-12-06 01:57:21 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:57:21 --> Controller Class Initialized
INFO - 2024-12-06 01:57:21 --> Model "Review_model" initialized
INFO - 2024-12-06 01:57:21 --> Model "Category_model" initialized
INFO - 2024-12-06 01:57:21 --> Model "User_model" initialized
INFO - 2024-12-06 01:57:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:57:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:57:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 01:57:21 --> Final output sent to browser
DEBUG - 2024-12-06 01:57:21 --> Total execution time: 0.1715
INFO - 2024-12-06 01:58:06 --> Config Class Initialized
INFO - 2024-12-06 01:58:06 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:58:06 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:58:06 --> Utf8 Class Initialized
INFO - 2024-12-06 01:58:06 --> URI Class Initialized
INFO - 2024-12-06 01:58:06 --> Router Class Initialized
INFO - 2024-12-06 01:58:06 --> Output Class Initialized
INFO - 2024-12-06 01:58:06 --> Security Class Initialized
DEBUG - 2024-12-06 01:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:58:06 --> CSRF cookie sent
INFO - 2024-12-06 01:58:06 --> CSRF token verified
INFO - 2024-12-06 01:58:06 --> Input Class Initialized
INFO - 2024-12-06 01:58:06 --> Language Class Initialized
INFO - 2024-12-06 01:58:06 --> Loader Class Initialized
INFO - 2024-12-06 01:58:06 --> Helper loaded: url_helper
INFO - 2024-12-06 01:58:06 --> Helper loaded: form_helper
INFO - 2024-12-06 01:58:06 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:58:06 --> Form Validation Class Initialized
INFO - 2024-12-06 01:58:06 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:58:06 --> Controller Class Initialized
INFO - 2024-12-06 01:58:06 --> Model "User_model" initialized
INFO - 2024-12-06 01:58:06 --> Model "Category_model" initialized
INFO - 2024-12-06 01:58:06 --> Model "Review_model" initialized
INFO - 2024-12-06 01:58:06 --> Model "News_model" initialized
INFO - 2024-12-06 01:58:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:58:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:58:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:58:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:58:06 --> Final output sent to browser
DEBUG - 2024-12-06 01:58:06 --> Total execution time: 0.0954
INFO - 2024-12-06 01:58:15 --> Config Class Initialized
INFO - 2024-12-06 01:58:15 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:58:15 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:58:15 --> Utf8 Class Initialized
INFO - 2024-12-06 01:58:15 --> URI Class Initialized
INFO - 2024-12-06 01:58:15 --> Router Class Initialized
INFO - 2024-12-06 01:58:15 --> Output Class Initialized
INFO - 2024-12-06 01:58:15 --> Security Class Initialized
DEBUG - 2024-12-06 01:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:58:15 --> CSRF cookie sent
INFO - 2024-12-06 01:58:15 --> Input Class Initialized
INFO - 2024-12-06 01:58:15 --> Language Class Initialized
INFO - 2024-12-06 01:58:15 --> Loader Class Initialized
INFO - 2024-12-06 01:58:15 --> Helper loaded: url_helper
INFO - 2024-12-06 01:58:15 --> Helper loaded: form_helper
INFO - 2024-12-06 01:58:15 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:58:15 --> Form Validation Class Initialized
INFO - 2024-12-06 01:58:15 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:58:15 --> Controller Class Initialized
INFO - 2024-12-06 01:58:15 --> Model "Review_model" initialized
INFO - 2024-12-06 01:58:15 --> Model "Category_model" initialized
INFO - 2024-12-06 01:58:15 --> Model "User_model" initialized
INFO - 2024-12-06 01:58:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:58:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:58:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-06 01:58:15 --> Final output sent to browser
DEBUG - 2024-12-06 01:58:15 --> Total execution time: 0.0813
INFO - 2024-12-06 01:58:46 --> Config Class Initialized
INFO - 2024-12-06 01:58:46 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:58:46 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:58:46 --> Utf8 Class Initialized
INFO - 2024-12-06 01:58:46 --> URI Class Initialized
INFO - 2024-12-06 01:58:46 --> Router Class Initialized
INFO - 2024-12-06 01:58:46 --> Output Class Initialized
INFO - 2024-12-06 01:58:46 --> Security Class Initialized
DEBUG - 2024-12-06 01:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:58:46 --> CSRF cookie sent
INFO - 2024-12-06 01:58:46 --> CSRF token verified
INFO - 2024-12-06 01:58:46 --> Input Class Initialized
INFO - 2024-12-06 01:58:46 --> Language Class Initialized
INFO - 2024-12-06 01:58:46 --> Loader Class Initialized
INFO - 2024-12-06 01:58:46 --> Helper loaded: url_helper
INFO - 2024-12-06 01:58:46 --> Helper loaded: form_helper
INFO - 2024-12-06 01:58:46 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:58:46 --> Form Validation Class Initialized
INFO - 2024-12-06 01:58:46 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:58:46 --> Controller Class Initialized
INFO - 2024-12-06 01:58:46 --> Model "User_model" initialized
INFO - 2024-12-06 01:58:46 --> Model "Category_model" initialized
INFO - 2024-12-06 01:58:46 --> Model "Review_model" initialized
INFO - 2024-12-06 01:58:46 --> Model "News_model" initialized
INFO - 2024-12-06 01:58:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:58:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:58:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:58:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:58:46 --> Final output sent to browser
DEBUG - 2024-12-06 01:58:46 --> Total execution time: 0.0566
INFO - 2024-12-06 01:58:55 --> Config Class Initialized
INFO - 2024-12-06 01:58:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:58:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:58:55 --> Utf8 Class Initialized
INFO - 2024-12-06 01:58:55 --> URI Class Initialized
INFO - 2024-12-06 01:58:55 --> Router Class Initialized
INFO - 2024-12-06 01:58:55 --> Output Class Initialized
INFO - 2024-12-06 01:58:55 --> Security Class Initialized
DEBUG - 2024-12-06 01:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:58:55 --> CSRF cookie sent
INFO - 2024-12-06 01:58:55 --> CSRF token verified
INFO - 2024-12-06 01:58:55 --> Input Class Initialized
INFO - 2024-12-06 01:58:55 --> Language Class Initialized
INFO - 2024-12-06 01:58:55 --> Loader Class Initialized
INFO - 2024-12-06 01:58:55 --> Helper loaded: url_helper
INFO - 2024-12-06 01:58:55 --> Helper loaded: form_helper
INFO - 2024-12-06 01:58:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:58:55 --> Form Validation Class Initialized
INFO - 2024-12-06 01:58:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:58:55 --> Controller Class Initialized
INFO - 2024-12-06 01:58:55 --> Model "User_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "Category_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "Review_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "News_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:58:55 --> Config Class Initialized
INFO - 2024-12-06 01:58:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:58:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:58:55 --> Utf8 Class Initialized
INFO - 2024-12-06 01:58:55 --> URI Class Initialized
INFO - 2024-12-06 01:58:55 --> Router Class Initialized
INFO - 2024-12-06 01:58:55 --> Output Class Initialized
INFO - 2024-12-06 01:58:55 --> Security Class Initialized
DEBUG - 2024-12-06 01:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:58:55 --> CSRF cookie sent
INFO - 2024-12-06 01:58:55 --> Input Class Initialized
INFO - 2024-12-06 01:58:55 --> Language Class Initialized
INFO - 2024-12-06 01:58:55 --> Loader Class Initialized
INFO - 2024-12-06 01:58:55 --> Helper loaded: url_helper
INFO - 2024-12-06 01:58:55 --> Helper loaded: form_helper
INFO - 2024-12-06 01:58:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:58:55 --> Form Validation Class Initialized
INFO - 2024-12-06 01:58:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:58:55 --> Controller Class Initialized
INFO - 2024-12-06 01:58:55 --> Model "User_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "Category_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "Review_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "News_model" initialized
INFO - 2024-12-06 01:58:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:58:55 --> Query result: stdClass Object
(
    [view_count] => 81
)

INFO - 2024-12-06 01:58:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:58:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:58:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 01:58:55 --> Final output sent to browser
DEBUG - 2024-12-06 01:58:55 --> Total execution time: 0.2340
INFO - 2024-12-06 01:58:56 --> Config Class Initialized
INFO - 2024-12-06 01:58:56 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:58:56 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:58:56 --> Utf8 Class Initialized
INFO - 2024-12-06 01:58:56 --> URI Class Initialized
INFO - 2024-12-06 01:58:56 --> Router Class Initialized
INFO - 2024-12-06 01:58:56 --> Output Class Initialized
INFO - 2024-12-06 01:58:56 --> Security Class Initialized
DEBUG - 2024-12-06 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:58:56 --> CSRF cookie sent
INFO - 2024-12-06 01:58:56 --> Input Class Initialized
INFO - 2024-12-06 01:58:56 --> Language Class Initialized
ERROR - 2024-12-06 01:58:56 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 01:59:01 --> Config Class Initialized
INFO - 2024-12-06 01:59:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:01 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:01 --> URI Class Initialized
INFO - 2024-12-06 01:59:01 --> Router Class Initialized
INFO - 2024-12-06 01:59:01 --> Output Class Initialized
INFO - 2024-12-06 01:59:01 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:01 --> CSRF cookie sent
INFO - 2024-12-06 01:59:01 --> Input Class Initialized
INFO - 2024-12-06 01:59:01 --> Language Class Initialized
INFO - 2024-12-06 01:59:01 --> Loader Class Initialized
INFO - 2024-12-06 01:59:01 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:01 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:01 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:01 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:01 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:01 --> Controller Class Initialized
INFO - 2024-12-06 01:59:01 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "News_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:01 --> Config Class Initialized
INFO - 2024-12-06 01:59:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:01 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:01 --> URI Class Initialized
INFO - 2024-12-06 01:59:01 --> Router Class Initialized
INFO - 2024-12-06 01:59:01 --> Output Class Initialized
INFO - 2024-12-06 01:59:01 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:01 --> CSRF cookie sent
INFO - 2024-12-06 01:59:01 --> Input Class Initialized
INFO - 2024-12-06 01:59:01 --> Language Class Initialized
INFO - 2024-12-06 01:59:01 --> Loader Class Initialized
INFO - 2024-12-06 01:59:01 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:01 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:01 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:01 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:01 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:01 --> Controller Class Initialized
INFO - 2024-12-06 01:59:01 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "News_model" initialized
INFO - 2024-12-06 01:59:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:59:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:59:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:59:01 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:01 --> Total execution time: 0.0529
INFO - 2024-12-06 01:59:03 --> Config Class Initialized
INFO - 2024-12-06 01:59:03 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:03 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:03 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:03 --> URI Class Initialized
INFO - 2024-12-06 01:59:03 --> Router Class Initialized
INFO - 2024-12-06 01:59:03 --> Output Class Initialized
INFO - 2024-12-06 01:59:03 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:03 --> CSRF cookie sent
INFO - 2024-12-06 01:59:03 --> Input Class Initialized
INFO - 2024-12-06 01:59:03 --> Language Class Initialized
INFO - 2024-12-06 01:59:03 --> Loader Class Initialized
INFO - 2024-12-06 01:59:03 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:03 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:03 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:03 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:03 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:03 --> Controller Class Initialized
INFO - 2024-12-06 01:59:03 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:03 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:03 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:03 --> Model "News_model" initialized
INFO - 2024-12-06 01:59:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:59:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:59:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:59:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-06 01:59:03 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:03 --> Total execution time: 0.0516
INFO - 2024-12-06 01:59:09 --> Config Class Initialized
INFO - 2024-12-06 01:59:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:09 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:09 --> URI Class Initialized
INFO - 2024-12-06 01:59:09 --> Router Class Initialized
INFO - 2024-12-06 01:59:09 --> Output Class Initialized
INFO - 2024-12-06 01:59:09 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:09 --> CSRF cookie sent
INFO - 2024-12-06 01:59:09 --> Input Class Initialized
INFO - 2024-12-06 01:59:09 --> Language Class Initialized
INFO - 2024-12-06 01:59:09 --> Loader Class Initialized
INFO - 2024-12-06 01:59:09 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:09 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:09 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:09 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:09 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:09 --> Controller Class Initialized
INFO - 2024-12-06 01:59:09 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:09 --> Config Class Initialized
INFO - 2024-12-06 01:59:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:09 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:09 --> URI Class Initialized
INFO - 2024-12-06 01:59:09 --> Router Class Initialized
INFO - 2024-12-06 01:59:09 --> Output Class Initialized
INFO - 2024-12-06 01:59:09 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:09 --> CSRF cookie sent
INFO - 2024-12-06 01:59:09 --> Input Class Initialized
INFO - 2024-12-06 01:59:09 --> Language Class Initialized
INFO - 2024-12-06 01:59:09 --> Loader Class Initialized
INFO - 2024-12-06 01:59:09 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:09 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:09 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:09 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:09 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:09 --> Controller Class Initialized
INFO - 2024-12-06 01:59:09 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:59:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:59:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:59:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-06 01:59:09 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:09 --> Total execution time: 0.0539
INFO - 2024-12-06 01:59:13 --> Config Class Initialized
INFO - 2024-12-06 01:59:13 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:13 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:13 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:13 --> URI Class Initialized
INFO - 2024-12-06 01:59:13 --> Router Class Initialized
INFO - 2024-12-06 01:59:13 --> Output Class Initialized
INFO - 2024-12-06 01:59:13 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:13 --> CSRF cookie sent
INFO - 2024-12-06 01:59:13 --> CSRF token verified
INFO - 2024-12-06 01:59:13 --> Input Class Initialized
INFO - 2024-12-06 01:59:13 --> Language Class Initialized
INFO - 2024-12-06 01:59:13 --> Loader Class Initialized
INFO - 2024-12-06 01:59:13 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:13 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:13 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:13 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:13 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:13 --> Controller Class Initialized
INFO - 2024-12-06 01:59:13 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "News_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:13 --> Config Class Initialized
INFO - 2024-12-06 01:59:13 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:13 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:13 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:13 --> URI Class Initialized
INFO - 2024-12-06 01:59:13 --> Router Class Initialized
INFO - 2024-12-06 01:59:13 --> Output Class Initialized
INFO - 2024-12-06 01:59:13 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:13 --> CSRF cookie sent
INFO - 2024-12-06 01:59:13 --> Input Class Initialized
INFO - 2024-12-06 01:59:13 --> Language Class Initialized
INFO - 2024-12-06 01:59:13 --> Loader Class Initialized
INFO - 2024-12-06 01:59:13 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:13 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:13 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:13 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:13 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:13 --> Controller Class Initialized
INFO - 2024-12-06 01:59:13 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:59:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:59:13 --> Query result: stdClass Object
(
    [view_count] => 81
)

INFO - 2024-12-06 01:59:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 01:59:13 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:13 --> Total execution time: 0.0626
INFO - 2024-12-06 01:59:17 --> Config Class Initialized
INFO - 2024-12-06 01:59:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:17 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:17 --> URI Class Initialized
INFO - 2024-12-06 01:59:17 --> Router Class Initialized
INFO - 2024-12-06 01:59:17 --> Output Class Initialized
INFO - 2024-12-06 01:59:17 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:17 --> CSRF cookie sent
INFO - 2024-12-06 01:59:17 --> Input Class Initialized
INFO - 2024-12-06 01:59:17 --> Language Class Initialized
INFO - 2024-12-06 01:59:17 --> Loader Class Initialized
INFO - 2024-12-06 01:59:17 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:17 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:17 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:17 --> Controller Class Initialized
INFO - 2024-12-06 01:59:17 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:17 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:17 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 01:59:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 01:59:17 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:17 --> Total execution time: 0.0752
INFO - 2024-12-06 01:59:39 --> Config Class Initialized
INFO - 2024-12-06 01:59:39 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:39 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:39 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:39 --> URI Class Initialized
INFO - 2024-12-06 01:59:39 --> Router Class Initialized
INFO - 2024-12-06 01:59:39 --> Output Class Initialized
INFO - 2024-12-06 01:59:39 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:39 --> CSRF cookie sent
INFO - 2024-12-06 01:59:49 --> Config Class Initialized
INFO - 2024-12-06 01:59:49 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:49 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:49 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:49 --> URI Class Initialized
INFO - 2024-12-06 01:59:49 --> Router Class Initialized
INFO - 2024-12-06 01:59:49 --> Output Class Initialized
INFO - 2024-12-06 01:59:49 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:49 --> CSRF cookie sent
INFO - 2024-12-06 01:59:49 --> Input Class Initialized
INFO - 2024-12-06 01:59:49 --> Language Class Initialized
INFO - 2024-12-06 01:59:49 --> Loader Class Initialized
INFO - 2024-12-06 01:59:49 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:49 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:49 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:49 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:49 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:49 --> Controller Class Initialized
INFO - 2024-12-06 01:59:49 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:49 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:49 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:49 --> Model "News_model" initialized
INFO - 2024-12-06 01:59:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 01:59:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:59:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:59:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-06 01:59:49 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:49 --> Total execution time: 0.0613
INFO - 2024-12-06 01:59:59 --> Config Class Initialized
INFO - 2024-12-06 01:59:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:59 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:59 --> URI Class Initialized
INFO - 2024-12-06 01:59:59 --> Router Class Initialized
INFO - 2024-12-06 01:59:59 --> Output Class Initialized
INFO - 2024-12-06 01:59:59 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:59 --> CSRF cookie sent
INFO - 2024-12-06 01:59:59 --> CSRF token verified
INFO - 2024-12-06 01:59:59 --> Input Class Initialized
INFO - 2024-12-06 01:59:59 --> Language Class Initialized
INFO - 2024-12-06 01:59:59 --> Loader Class Initialized
INFO - 2024-12-06 01:59:59 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:59 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:59 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:59 --> Controller Class Initialized
INFO - 2024-12-06 01:59:59 --> Model "User_model" initialized
DEBUG - 2024-12-06 01:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:59 --> User activity log successfully inserted into the user_activity_logs table.
INFO - 2024-12-06 01:59:59 --> Config Class Initialized
INFO - 2024-12-06 01:59:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 01:59:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 01:59:59 --> Utf8 Class Initialized
INFO - 2024-12-06 01:59:59 --> URI Class Initialized
INFO - 2024-12-06 01:59:59 --> Router Class Initialized
INFO - 2024-12-06 01:59:59 --> Output Class Initialized
INFO - 2024-12-06 01:59:59 --> Security Class Initialized
DEBUG - 2024-12-06 01:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 01:59:59 --> CSRF cookie sent
INFO - 2024-12-06 01:59:59 --> Input Class Initialized
INFO - 2024-12-06 01:59:59 --> Language Class Initialized
INFO - 2024-12-06 01:59:59 --> Loader Class Initialized
INFO - 2024-12-06 01:59:59 --> Helper loaded: url_helper
INFO - 2024-12-06 01:59:59 --> Helper loaded: form_helper
INFO - 2024-12-06 01:59:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 01:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 01:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 01:59:59 --> Form Validation Class Initialized
INFO - 2024-12-06 01:59:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 01:59:59 --> Controller Class Initialized
INFO - 2024-12-06 01:59:59 --> Model "User_model" initialized
INFO - 2024-12-06 01:59:59 --> Model "Category_model" initialized
INFO - 2024-12-06 01:59:59 --> Model "Review_model" initialized
INFO - 2024-12-06 01:59:59 --> Model "News_model" initialized
INFO - 2024-12-06 01:59:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 01:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 01:59:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 01:59:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 01:59:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 01:59:59 --> Final output sent to browser
DEBUG - 2024-12-06 01:59:59 --> Total execution time: 0.0876
INFO - 2024-12-06 02:00:17 --> Config Class Initialized
INFO - 2024-12-06 02:00:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:17 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:17 --> URI Class Initialized
INFO - 2024-12-06 02:00:17 --> Router Class Initialized
INFO - 2024-12-06 02:00:17 --> Output Class Initialized
INFO - 2024-12-06 02:00:17 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:17 --> CSRF cookie sent
INFO - 2024-12-06 02:00:17 --> CSRF token verified
INFO - 2024-12-06 02:00:17 --> Input Class Initialized
INFO - 2024-12-06 02:00:17 --> Language Class Initialized
INFO - 2024-12-06 02:00:17 --> Loader Class Initialized
INFO - 2024-12-06 02:00:17 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:17 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:17 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:17 --> Controller Class Initialized
INFO - 2024-12-06 02:00:17 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:17 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:17 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:17 --> Model "News_model" initialized
INFO - 2024-12-06 02:00:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:18 --> Config Class Initialized
INFO - 2024-12-06 02:00:18 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:18 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:18 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:18 --> URI Class Initialized
INFO - 2024-12-06 02:00:18 --> Router Class Initialized
INFO - 2024-12-06 02:00:18 --> Output Class Initialized
INFO - 2024-12-06 02:00:18 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:18 --> CSRF cookie sent
INFO - 2024-12-06 02:00:18 --> Input Class Initialized
INFO - 2024-12-06 02:00:18 --> Language Class Initialized
INFO - 2024-12-06 02:00:18 --> Loader Class Initialized
INFO - 2024-12-06 02:00:18 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:18 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:18 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:18 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:18 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:18 --> Controller Class Initialized
INFO - 2024-12-06 02:00:18 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:18 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:18 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:18 --> Model "News_model" initialized
INFO - 2024-12-06 02:00:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:00:18 --> Query result: stdClass Object
(
    [view_count] => 82
)

INFO - 2024-12-06 02:00:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:00:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:00:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:00:18 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:18 --> Total execution time: 0.0549
INFO - 2024-12-06 02:00:18 --> Config Class Initialized
INFO - 2024-12-06 02:00:18 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:18 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:18 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:18 --> URI Class Initialized
INFO - 2024-12-06 02:00:18 --> Router Class Initialized
INFO - 2024-12-06 02:00:18 --> Output Class Initialized
INFO - 2024-12-06 02:00:18 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:18 --> CSRF cookie sent
INFO - 2024-12-06 02:00:18 --> Input Class Initialized
INFO - 2024-12-06 02:00:18 --> Language Class Initialized
ERROR - 2024-12-06 02:00:18 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 02:00:24 --> Config Class Initialized
INFO - 2024-12-06 02:00:24 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:24 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:24 --> URI Class Initialized
INFO - 2024-12-06 02:00:24 --> Router Class Initialized
INFO - 2024-12-06 02:00:24 --> Output Class Initialized
INFO - 2024-12-06 02:00:24 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:24 --> CSRF cookie sent
INFO - 2024-12-06 02:00:24 --> Input Class Initialized
INFO - 2024-12-06 02:00:24 --> Language Class Initialized
INFO - 2024-12-06 02:00:24 --> Loader Class Initialized
INFO - 2024-12-06 02:00:24 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:24 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:24 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:24 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:24 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:24 --> Controller Class Initialized
INFO - 2024-12-06 02:00:24 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:24 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:24 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:24 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:24 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:24 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:00:24 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:24 --> Total execution time: 0.0470
INFO - 2024-12-06 02:00:28 --> Config Class Initialized
INFO - 2024-12-06 02:00:28 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:28 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:28 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:28 --> URI Class Initialized
INFO - 2024-12-06 02:00:28 --> Router Class Initialized
INFO - 2024-12-06 02:00:28 --> Output Class Initialized
INFO - 2024-12-06 02:00:28 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:28 --> CSRF cookie sent
INFO - 2024-12-06 02:00:28 --> Input Class Initialized
INFO - 2024-12-06 02:00:28 --> Language Class Initialized
INFO - 2024-12-06 02:00:28 --> Loader Class Initialized
INFO - 2024-12-06 02:00:28 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:28 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:28 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:28 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:28 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:28 --> Controller Class Initialized
INFO - 2024-12-06 02:00:28 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:28 --> User data with ID 18 successfully deleted.
INFO - 2024-12-06 02:00:28 --> Config Class Initialized
INFO - 2024-12-06 02:00:28 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:28 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:28 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:28 --> URI Class Initialized
INFO - 2024-12-06 02:00:28 --> Router Class Initialized
INFO - 2024-12-06 02:00:28 --> Output Class Initialized
INFO - 2024-12-06 02:00:28 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:28 --> CSRF cookie sent
INFO - 2024-12-06 02:00:28 --> Input Class Initialized
INFO - 2024-12-06 02:00:28 --> Language Class Initialized
INFO - 2024-12-06 02:00:28 --> Loader Class Initialized
INFO - 2024-12-06 02:00:28 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:28 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:28 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:28 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:28 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:28 --> Controller Class Initialized
INFO - 2024-12-06 02:00:28 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:00:28 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:28 --> Total execution time: 0.0463
INFO - 2024-12-06 02:00:30 --> Config Class Initialized
INFO - 2024-12-06 02:00:30 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:30 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:30 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:30 --> URI Class Initialized
INFO - 2024-12-06 02:00:30 --> Router Class Initialized
INFO - 2024-12-06 02:00:30 --> Output Class Initialized
INFO - 2024-12-06 02:00:30 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:30 --> CSRF cookie sent
INFO - 2024-12-06 02:00:30 --> Input Class Initialized
INFO - 2024-12-06 02:00:30 --> Language Class Initialized
INFO - 2024-12-06 02:00:30 --> Loader Class Initialized
INFO - 2024-12-06 02:00:30 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:30 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:30 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:31 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:31 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:31 --> Controller Class Initialized
INFO - 2024-12-06 02:00:31 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:31 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:31 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:31 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:31 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:00:31 --> Query result: stdClass Object
(
    [view_count] => 82
)

INFO - 2024-12-06 02:00:31 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 02:00:31 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:31 --> Total execution time: 0.0651
INFO - 2024-12-06 02:00:31 --> Config Class Initialized
INFO - 2024-12-06 02:00:31 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:31 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:31 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:31 --> URI Class Initialized
INFO - 2024-12-06 02:00:31 --> Router Class Initialized
INFO - 2024-12-06 02:00:31 --> Output Class Initialized
INFO - 2024-12-06 02:00:31 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:31 --> CSRF cookie sent
INFO - 2024-12-06 02:00:31 --> Input Class Initialized
INFO - 2024-12-06 02:00:31 --> Language Class Initialized
INFO - 2024-12-06 02:00:32 --> Loader Class Initialized
INFO - 2024-12-06 02:00:32 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:32 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:32 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:32 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:32 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:32 --> Controller Class Initialized
INFO - 2024-12-06 02:00:32 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:32 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:32 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 02:00:32 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:32 --> Total execution time: 0.0644
INFO - 2024-12-06 02:00:34 --> Config Class Initialized
INFO - 2024-12-06 02:00:34 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:34 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:34 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:34 --> URI Class Initialized
INFO - 2024-12-06 02:00:34 --> Router Class Initialized
INFO - 2024-12-06 02:00:34 --> Output Class Initialized
INFO - 2024-12-06 02:00:34 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:34 --> CSRF cookie sent
INFO - 2024-12-06 02:00:34 --> Input Class Initialized
INFO - 2024-12-06 02:00:34 --> Language Class Initialized
INFO - 2024-12-06 02:00:34 --> Loader Class Initialized
INFO - 2024-12-06 02:00:34 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:34 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:34 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:34 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:34 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:34 --> Controller Class Initialized
INFO - 2024-12-06 02:00:34 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:34 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:34 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 02:00:34 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:34 --> Total execution time: 0.0568
INFO - 2024-12-06 02:00:48 --> Config Class Initialized
INFO - 2024-12-06 02:00:48 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:48 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:48 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:48 --> URI Class Initialized
INFO - 2024-12-06 02:00:48 --> Router Class Initialized
INFO - 2024-12-06 02:00:48 --> Output Class Initialized
INFO - 2024-12-06 02:00:48 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:48 --> CSRF cookie sent
INFO - 2024-12-06 02:00:48 --> Input Class Initialized
INFO - 2024-12-06 02:00:48 --> Language Class Initialized
INFO - 2024-12-06 02:00:48 --> Loader Class Initialized
INFO - 2024-12-06 02:00:48 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:48 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:48 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:48 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:48 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:48 --> Controller Class Initialized
INFO - 2024-12-06 02:00:48 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:48 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:48 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:48 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:48 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 02:00:48 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:48 --> Total execution time: 0.0720
INFO - 2024-12-06 02:00:51 --> Config Class Initialized
INFO - 2024-12-06 02:00:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:51 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:51 --> URI Class Initialized
INFO - 2024-12-06 02:00:51 --> Router Class Initialized
INFO - 2024-12-06 02:00:51 --> Output Class Initialized
INFO - 2024-12-06 02:00:51 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:51 --> CSRF cookie sent
INFO - 2024-12-06 02:00:51 --> Input Class Initialized
INFO - 2024-12-06 02:00:51 --> Language Class Initialized
INFO - 2024-12-06 02:00:51 --> Loader Class Initialized
INFO - 2024-12-06 02:00:51 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:51 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:51 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:51 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:51 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:51 --> Controller Class Initialized
INFO - 2024-12-06 02:00:51 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:51 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:51 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:00:51 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:51 --> Total execution time: 0.0599
INFO - 2024-12-06 02:00:52 --> Config Class Initialized
INFO - 2024-12-06 02:00:52 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:52 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:52 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:52 --> URI Class Initialized
INFO - 2024-12-06 02:00:52 --> Router Class Initialized
INFO - 2024-12-06 02:00:52 --> Output Class Initialized
INFO - 2024-12-06 02:00:52 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:52 --> CSRF cookie sent
INFO - 2024-12-06 02:00:52 --> Input Class Initialized
INFO - 2024-12-06 02:00:52 --> Language Class Initialized
INFO - 2024-12-06 02:00:52 --> Loader Class Initialized
INFO - 2024-12-06 02:00:52 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:52 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:52 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:52 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:52 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:52 --> Controller Class Initialized
INFO - 2024-12-06 02:00:52 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:52 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:52 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 02:00:52 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:52 --> Total execution time: 0.0540
INFO - 2024-12-06 02:00:54 --> Config Class Initialized
INFO - 2024-12-06 02:00:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:54 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:54 --> URI Class Initialized
INFO - 2024-12-06 02:00:54 --> Router Class Initialized
INFO - 2024-12-06 02:00:54 --> Output Class Initialized
INFO - 2024-12-06 02:00:54 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:54 --> CSRF cookie sent
INFO - 2024-12-06 02:00:54 --> Input Class Initialized
INFO - 2024-12-06 02:00:54 --> Language Class Initialized
INFO - 2024-12-06 02:00:54 --> Loader Class Initialized
INFO - 2024-12-06 02:00:54 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:54 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:54 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:54 --> Controller Class Initialized
INFO - 2024-12-06 02:00:54 --> Model "News_model" initialized
INFO - 2024-12-06 02:00:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 02:00:54 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:54 --> Total execution time: 0.0568
INFO - 2024-12-06 02:00:56 --> Config Class Initialized
INFO - 2024-12-06 02:00:56 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:56 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:56 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:56 --> URI Class Initialized
INFO - 2024-12-06 02:00:56 --> Router Class Initialized
INFO - 2024-12-06 02:00:56 --> Output Class Initialized
INFO - 2024-12-06 02:00:56 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:56 --> CSRF cookie sent
INFO - 2024-12-06 02:00:56 --> Input Class Initialized
INFO - 2024-12-06 02:00:56 --> Language Class Initialized
INFO - 2024-12-06 02:00:56 --> Loader Class Initialized
INFO - 2024-12-06 02:00:56 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:56 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:56 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:56 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:56 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:56 --> Controller Class Initialized
INFO - 2024-12-06 02:00:56 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:56 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:56 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 02:00:56 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:56 --> Total execution time: 0.0705
INFO - 2024-12-06 02:00:59 --> Config Class Initialized
INFO - 2024-12-06 02:00:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:00:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:00:59 --> Utf8 Class Initialized
INFO - 2024-12-06 02:00:59 --> URI Class Initialized
INFO - 2024-12-06 02:00:59 --> Router Class Initialized
INFO - 2024-12-06 02:00:59 --> Output Class Initialized
INFO - 2024-12-06 02:00:59 --> Security Class Initialized
DEBUG - 2024-12-06 02:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:00:59 --> CSRF cookie sent
INFO - 2024-12-06 02:00:59 --> Input Class Initialized
INFO - 2024-12-06 02:00:59 --> Language Class Initialized
INFO - 2024-12-06 02:00:59 --> Loader Class Initialized
INFO - 2024-12-06 02:00:59 --> Helper loaded: url_helper
INFO - 2024-12-06 02:00:59 --> Helper loaded: form_helper
INFO - 2024-12-06 02:00:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:00:59 --> Form Validation Class Initialized
INFO - 2024-12-06 02:00:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:00:59 --> Controller Class Initialized
INFO - 2024-12-06 02:00:59 --> Model "Review_model" initialized
INFO - 2024-12-06 02:00:59 --> Model "Category_model" initialized
INFO - 2024-12-06 02:00:59 --> Model "User_model" initialized
INFO - 2024-12-06 02:00:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:00:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:00:59 --> Model "Contact_model" initialized
INFO - 2024-12-06 02:00:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-06 02:00:59 --> Final output sent to browser
DEBUG - 2024-12-06 02:00:59 --> Total execution time: 0.0883
INFO - 2024-12-06 02:01:01 --> Config Class Initialized
INFO - 2024-12-06 02:01:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:01 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:01 --> URI Class Initialized
INFO - 2024-12-06 02:01:01 --> Router Class Initialized
INFO - 2024-12-06 02:01:01 --> Output Class Initialized
INFO - 2024-12-06 02:01:01 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:01 --> CSRF cookie sent
INFO - 2024-12-06 02:01:01 --> Input Class Initialized
INFO - 2024-12-06 02:01:01 --> Language Class Initialized
INFO - 2024-12-06 02:01:01 --> Loader Class Initialized
INFO - 2024-12-06 02:01:01 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:01 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:01 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:01 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:01 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:01 --> Controller Class Initialized
INFO - 2024-12-06 02:01:01 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:01 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:01 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:01:01 --> Query result: stdClass Object
(
    [view_count] => 82
)

INFO - 2024-12-06 02:01:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 02:01:01 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:01 --> Total execution time: 0.0570
INFO - 2024-12-06 02:01:17 --> Config Class Initialized
INFO - 2024-12-06 02:01:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:17 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:17 --> URI Class Initialized
INFO - 2024-12-06 02:01:17 --> Router Class Initialized
INFO - 2024-12-06 02:01:17 --> Output Class Initialized
INFO - 2024-12-06 02:01:17 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:17 --> CSRF cookie sent
INFO - 2024-12-06 02:01:17 --> Input Class Initialized
INFO - 2024-12-06 02:01:17 --> Language Class Initialized
INFO - 2024-12-06 02:01:17 --> Loader Class Initialized
INFO - 2024-12-06 02:01:17 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:17 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:17 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:17 --> Controller Class Initialized
INFO - 2024-12-06 02:01:17 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "News_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:17 --> Config Class Initialized
INFO - 2024-12-06 02:01:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:17 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:17 --> URI Class Initialized
INFO - 2024-12-06 02:01:17 --> Router Class Initialized
INFO - 2024-12-06 02:01:17 --> Output Class Initialized
INFO - 2024-12-06 02:01:17 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:17 --> CSRF cookie sent
INFO - 2024-12-06 02:01:17 --> Input Class Initialized
INFO - 2024-12-06 02:01:17 --> Language Class Initialized
INFO - 2024-12-06 02:01:17 --> Loader Class Initialized
INFO - 2024-12-06 02:01:17 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:17 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:17 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:17 --> Controller Class Initialized
INFO - 2024-12-06 02:01:17 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "News_model" initialized
INFO - 2024-12-06 02:01:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:01:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:01:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 02:01:17 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:17 --> Total execution time: 0.0436
INFO - 2024-12-06 02:01:19 --> Config Class Initialized
INFO - 2024-12-06 02:01:19 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:19 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:19 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:19 --> URI Class Initialized
INFO - 2024-12-06 02:01:19 --> Router Class Initialized
INFO - 2024-12-06 02:01:19 --> Output Class Initialized
INFO - 2024-12-06 02:01:19 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:19 --> CSRF cookie sent
INFO - 2024-12-06 02:01:19 --> Input Class Initialized
INFO - 2024-12-06 02:01:19 --> Language Class Initialized
INFO - 2024-12-06 02:01:19 --> Loader Class Initialized
INFO - 2024-12-06 02:01:19 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:19 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:19 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:19 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:19 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:19 --> Controller Class Initialized
INFO - 2024-12-06 02:01:19 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:19 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:19 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:19 --> Model "News_model" initialized
INFO - 2024-12-06 02:01:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:01:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:01:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:01:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/register.php
INFO - 2024-12-06 02:01:19 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:19 --> Total execution time: 0.0732
INFO - 2024-12-06 02:01:36 --> Config Class Initialized
INFO - 2024-12-06 02:01:36 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:36 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:36 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:36 --> URI Class Initialized
INFO - 2024-12-06 02:01:36 --> Router Class Initialized
INFO - 2024-12-06 02:01:36 --> Output Class Initialized
INFO - 2024-12-06 02:01:36 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:36 --> CSRF cookie sent
INFO - 2024-12-06 02:01:36 --> CSRF token verified
INFO - 2024-12-06 02:01:36 --> Input Class Initialized
INFO - 2024-12-06 02:01:36 --> Language Class Initialized
INFO - 2024-12-06 02:01:36 --> Loader Class Initialized
INFO - 2024-12-06 02:01:36 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:36 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:36 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:36 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:36 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:36 --> Controller Class Initialized
INFO - 2024-12-06 02:01:36 --> Model "User_model" initialized
DEBUG - 2024-12-06 02:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:36 --> User activity log successfully inserted into the user_activity_logs table.
INFO - 2024-12-06 02:01:36 --> Config Class Initialized
INFO - 2024-12-06 02:01:36 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:36 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:36 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:36 --> URI Class Initialized
INFO - 2024-12-06 02:01:36 --> Router Class Initialized
INFO - 2024-12-06 02:01:36 --> Output Class Initialized
INFO - 2024-12-06 02:01:36 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:36 --> CSRF cookie sent
INFO - 2024-12-06 02:01:36 --> Input Class Initialized
INFO - 2024-12-06 02:01:36 --> Language Class Initialized
INFO - 2024-12-06 02:01:36 --> Loader Class Initialized
INFO - 2024-12-06 02:01:36 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:36 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:36 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:36 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:36 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:36 --> Controller Class Initialized
INFO - 2024-12-06 02:01:36 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:36 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:36 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:36 --> Model "News_model" initialized
INFO - 2024-12-06 02:01:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:01:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:01:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 02:01:36 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:36 --> Total execution time: 0.0453
INFO - 2024-12-06 02:01:41 --> Config Class Initialized
INFO - 2024-12-06 02:01:41 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:41 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:41 --> URI Class Initialized
INFO - 2024-12-06 02:01:41 --> Router Class Initialized
INFO - 2024-12-06 02:01:41 --> Output Class Initialized
INFO - 2024-12-06 02:01:41 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:41 --> CSRF cookie sent
INFO - 2024-12-06 02:01:41 --> Input Class Initialized
INFO - 2024-12-06 02:01:41 --> Language Class Initialized
INFO - 2024-12-06 02:01:41 --> Loader Class Initialized
INFO - 2024-12-06 02:01:41 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:41 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:41 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:41 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:41 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:41 --> Controller Class Initialized
INFO - 2024-12-06 02:01:41 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:41 --> Config Class Initialized
INFO - 2024-12-06 02:01:41 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:41 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:41 --> URI Class Initialized
INFO - 2024-12-06 02:01:41 --> Router Class Initialized
INFO - 2024-12-06 02:01:41 --> Output Class Initialized
INFO - 2024-12-06 02:01:41 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:41 --> CSRF cookie sent
INFO - 2024-12-06 02:01:41 --> Input Class Initialized
INFO - 2024-12-06 02:01:41 --> Language Class Initialized
INFO - 2024-12-06 02:01:41 --> Loader Class Initialized
INFO - 2024-12-06 02:01:41 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:41 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:41 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:41 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:41 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:41 --> Controller Class Initialized
INFO - 2024-12-06 02:01:41 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:41 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:01:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:01:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-06 02:01:41 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:41 --> Total execution time: 0.0382
INFO - 2024-12-06 02:01:46 --> Config Class Initialized
INFO - 2024-12-06 02:01:46 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:47 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:47 --> URI Class Initialized
INFO - 2024-12-06 02:01:47 --> Router Class Initialized
INFO - 2024-12-06 02:01:47 --> Output Class Initialized
INFO - 2024-12-06 02:01:47 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:47 --> CSRF cookie sent
INFO - 2024-12-06 02:01:47 --> CSRF token verified
INFO - 2024-12-06 02:01:47 --> Input Class Initialized
INFO - 2024-12-06 02:01:47 --> Language Class Initialized
INFO - 2024-12-06 02:01:47 --> Loader Class Initialized
INFO - 2024-12-06 02:01:47 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:47 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:47 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:47 --> Controller Class Initialized
INFO - 2024-12-06 02:01:47 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "News_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:47 --> Config Class Initialized
INFO - 2024-12-06 02:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:47 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:47 --> URI Class Initialized
INFO - 2024-12-06 02:01:47 --> Router Class Initialized
INFO - 2024-12-06 02:01:47 --> Output Class Initialized
INFO - 2024-12-06 02:01:47 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:47 --> CSRF cookie sent
INFO - 2024-12-06 02:01:47 --> Input Class Initialized
INFO - 2024-12-06 02:01:47 --> Language Class Initialized
INFO - 2024-12-06 02:01:47 --> Loader Class Initialized
INFO - 2024-12-06 02:01:47 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:47 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:47 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:47 --> Controller Class Initialized
INFO - 2024-12-06 02:01:47 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:01:47 --> Query result: stdClass Object
(
    [view_count] => 82
)

INFO - 2024-12-06 02:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 02:01:47 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:47 --> Total execution time: 0.0682
INFO - 2024-12-06 02:01:52 --> Config Class Initialized
INFO - 2024-12-06 02:01:52 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:52 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:52 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:52 --> URI Class Initialized
INFO - 2024-12-06 02:01:52 --> Router Class Initialized
INFO - 2024-12-06 02:01:52 --> Output Class Initialized
INFO - 2024-12-06 02:01:52 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:52 --> CSRF cookie sent
INFO - 2024-12-06 02:01:52 --> Input Class Initialized
INFO - 2024-12-06 02:01:52 --> Language Class Initialized
INFO - 2024-12-06 02:01:52 --> Loader Class Initialized
INFO - 2024-12-06 02:01:52 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:52 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:52 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:52 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:52 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:52 --> Controller Class Initialized
INFO - 2024-12-06 02:01:52 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:52 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:52 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:52 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 02:01:52 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:52 --> Total execution time: 0.0517
INFO - 2024-12-06 02:01:54 --> Config Class Initialized
INFO - 2024-12-06 02:01:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:54 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:54 --> URI Class Initialized
INFO - 2024-12-06 02:01:54 --> Router Class Initialized
INFO - 2024-12-06 02:01:54 --> Output Class Initialized
INFO - 2024-12-06 02:01:54 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:54 --> CSRF cookie sent
INFO - 2024-12-06 02:01:54 --> Input Class Initialized
INFO - 2024-12-06 02:01:54 --> Language Class Initialized
INFO - 2024-12-06 02:01:54 --> Loader Class Initialized
INFO - 2024-12-06 02:01:54 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:54 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:54 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:54 --> Controller Class Initialized
INFO - 2024-12-06 02:01:54 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:54 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:54 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 02:01:54 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:54 --> Total execution time: 0.0590
INFO - 2024-12-06 02:01:55 --> Config Class Initialized
INFO - 2024-12-06 02:01:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:55 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:55 --> URI Class Initialized
INFO - 2024-12-06 02:01:55 --> Router Class Initialized
INFO - 2024-12-06 02:01:55 --> Output Class Initialized
INFO - 2024-12-06 02:01:55 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:55 --> CSRF cookie sent
INFO - 2024-12-06 02:01:55 --> Input Class Initialized
INFO - 2024-12-06 02:01:55 --> Language Class Initialized
INFO - 2024-12-06 02:01:55 --> Loader Class Initialized
INFO - 2024-12-06 02:01:55 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:55 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:55 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:55 --> Controller Class Initialized
INFO - 2024-12-06 02:01:55 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:55 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:55 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:55 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 02:01:55 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:55 --> Total execution time: 0.0710
INFO - 2024-12-06 02:01:56 --> Config Class Initialized
INFO - 2024-12-06 02:01:56 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:56 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:56 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:56 --> URI Class Initialized
INFO - 2024-12-06 02:01:56 --> Router Class Initialized
INFO - 2024-12-06 02:01:56 --> Output Class Initialized
INFO - 2024-12-06 02:01:56 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:56 --> CSRF cookie sent
INFO - 2024-12-06 02:01:56 --> Input Class Initialized
INFO - 2024-12-06 02:01:56 --> Language Class Initialized
INFO - 2024-12-06 02:01:56 --> Loader Class Initialized
INFO - 2024-12-06 02:01:56 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:56 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:56 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:56 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:56 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:56 --> Controller Class Initialized
INFO - 2024-12-06 02:01:56 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:56 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:56 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:01:56 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:56 --> Total execution time: 0.0751
INFO - 2024-12-06 02:01:59 --> Config Class Initialized
INFO - 2024-12-06 02:01:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:59 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:59 --> URI Class Initialized
INFO - 2024-12-06 02:01:59 --> Router Class Initialized
INFO - 2024-12-06 02:01:59 --> Output Class Initialized
INFO - 2024-12-06 02:01:59 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:59 --> CSRF cookie sent
INFO - 2024-12-06 02:01:59 --> Input Class Initialized
INFO - 2024-12-06 02:01:59 --> Language Class Initialized
INFO - 2024-12-06 02:01:59 --> Loader Class Initialized
INFO - 2024-12-06 02:01:59 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:59 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:59 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:59 --> Controller Class Initialized
INFO - 2024-12-06 02:01:59 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:59 --> User data with ID 19 successfully deleted.
INFO - 2024-12-06 02:01:59 --> Config Class Initialized
INFO - 2024-12-06 02:01:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:01:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:01:59 --> Utf8 Class Initialized
INFO - 2024-12-06 02:01:59 --> URI Class Initialized
INFO - 2024-12-06 02:01:59 --> Router Class Initialized
INFO - 2024-12-06 02:01:59 --> Output Class Initialized
INFO - 2024-12-06 02:01:59 --> Security Class Initialized
DEBUG - 2024-12-06 02:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:01:59 --> CSRF cookie sent
INFO - 2024-12-06 02:01:59 --> Input Class Initialized
INFO - 2024-12-06 02:01:59 --> Language Class Initialized
INFO - 2024-12-06 02:01:59 --> Loader Class Initialized
INFO - 2024-12-06 02:01:59 --> Helper loaded: url_helper
INFO - 2024-12-06 02:01:59 --> Helper loaded: form_helper
INFO - 2024-12-06 02:01:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:01:59 --> Form Validation Class Initialized
INFO - 2024-12-06 02:01:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:01:59 --> Controller Class Initialized
INFO - 2024-12-06 02:01:59 --> Model "Review_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "Category_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "User_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:01:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:01:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:01:59 --> Final output sent to browser
DEBUG - 2024-12-06 02:01:59 --> Total execution time: 0.0658
INFO - 2024-12-06 02:02:00 --> Config Class Initialized
INFO - 2024-12-06 02:02:00 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:02:00 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:02:00 --> Utf8 Class Initialized
INFO - 2024-12-06 02:02:00 --> URI Class Initialized
INFO - 2024-12-06 02:02:00 --> Router Class Initialized
INFO - 2024-12-06 02:02:00 --> Output Class Initialized
INFO - 2024-12-06 02:02:00 --> Security Class Initialized
DEBUG - 2024-12-06 02:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:02:00 --> CSRF cookie sent
INFO - 2024-12-06 02:02:00 --> Input Class Initialized
INFO - 2024-12-06 02:02:00 --> Language Class Initialized
INFO - 2024-12-06 02:02:00 --> Loader Class Initialized
INFO - 2024-12-06 02:02:00 --> Helper loaded: url_helper
INFO - 2024-12-06 02:02:00 --> Helper loaded: form_helper
INFO - 2024-12-06 02:02:00 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:02:00 --> Form Validation Class Initialized
INFO - 2024-12-06 02:02:00 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:02:00 --> Controller Class Initialized
INFO - 2024-12-06 02:02:00 --> Model "Review_model" initialized
INFO - 2024-12-06 02:02:00 --> Model "Category_model" initialized
INFO - 2024-12-06 02:02:00 --> Model "User_model" initialized
INFO - 2024-12-06 02:02:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:02:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:02:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:02:00 --> Query result: stdClass Object
(
    [view_count] => 82
)

INFO - 2024-12-06 02:02:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 02:02:00 --> Final output sent to browser
DEBUG - 2024-12-06 02:02:00 --> Total execution time: 0.0508
INFO - 2024-12-06 02:06:57 --> Config Class Initialized
INFO - 2024-12-06 02:06:57 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:06:57 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:06:57 --> Utf8 Class Initialized
INFO - 2024-12-06 02:06:57 --> URI Class Initialized
INFO - 2024-12-06 02:06:57 --> Router Class Initialized
INFO - 2024-12-06 02:06:57 --> Output Class Initialized
INFO - 2024-12-06 02:06:57 --> Security Class Initialized
DEBUG - 2024-12-06 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:06:57 --> CSRF cookie sent
INFO - 2024-12-06 02:06:57 --> Input Class Initialized
INFO - 2024-12-06 02:06:57 --> Language Class Initialized
INFO - 2024-12-06 02:06:57 --> Loader Class Initialized
INFO - 2024-12-06 02:06:57 --> Helper loaded: url_helper
INFO - 2024-12-06 02:06:57 --> Helper loaded: form_helper
INFO - 2024-12-06 02:06:57 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:06:57 --> Form Validation Class Initialized
INFO - 2024-12-06 02:06:57 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:06:57 --> Controller Class Initialized
INFO - 2024-12-06 02:06:57 --> Model "Review_model" initialized
INFO - 2024-12-06 02:06:57 --> Model "Category_model" initialized
INFO - 2024-12-06 02:06:57 --> Model "User_model" initialized
INFO - 2024-12-06 02:06:57 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:06:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:06:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:06:57 --> Final output sent to browser
DEBUG - 2024-12-06 02:06:57 --> Total execution time: 0.0847
INFO - 2024-12-06 02:06:58 --> Config Class Initialized
INFO - 2024-12-06 02:06:58 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:06:58 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:06:58 --> Utf8 Class Initialized
INFO - 2024-12-06 02:06:58 --> URI Class Initialized
INFO - 2024-12-06 02:06:58 --> Router Class Initialized
INFO - 2024-12-06 02:06:58 --> Output Class Initialized
INFO - 2024-12-06 02:06:58 --> Security Class Initialized
DEBUG - 2024-12-06 02:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:06:58 --> CSRF cookie sent
INFO - 2024-12-06 02:06:58 --> Input Class Initialized
INFO - 2024-12-06 02:06:58 --> Language Class Initialized
INFO - 2024-12-06 02:06:58 --> Loader Class Initialized
INFO - 2024-12-06 02:06:58 --> Helper loaded: url_helper
INFO - 2024-12-06 02:06:58 --> Helper loaded: form_helper
INFO - 2024-12-06 02:06:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:06:58 --> Form Validation Class Initialized
INFO - 2024-12-06 02:06:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:06:58 --> Controller Class Initialized
INFO - 2024-12-06 02:06:58 --> Model "Review_model" initialized
INFO - 2024-12-06 02:06:58 --> Model "Category_model" initialized
INFO - 2024-12-06 02:06:58 --> Model "User_model" initialized
INFO - 2024-12-06 02:06:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:06:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:06:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 02:06:58 --> Final output sent to browser
DEBUG - 2024-12-06 02:06:58 --> Total execution time: 0.0536
INFO - 2024-12-06 02:10:44 --> Config Class Initialized
INFO - 2024-12-06 02:10:44 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:10:44 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:10:44 --> Utf8 Class Initialized
INFO - 2024-12-06 02:10:44 --> URI Class Initialized
INFO - 2024-12-06 02:10:44 --> Router Class Initialized
INFO - 2024-12-06 02:10:44 --> Output Class Initialized
INFO - 2024-12-06 02:10:44 --> Security Class Initialized
DEBUG - 2024-12-06 02:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:10:44 --> CSRF cookie sent
INFO - 2024-12-06 02:10:44 --> Input Class Initialized
INFO - 2024-12-06 02:10:44 --> Language Class Initialized
INFO - 2024-12-06 02:10:44 --> Loader Class Initialized
INFO - 2024-12-06 02:10:44 --> Helper loaded: url_helper
INFO - 2024-12-06 02:10:44 --> Helper loaded: form_helper
INFO - 2024-12-06 02:10:44 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:10:45 --> Form Validation Class Initialized
INFO - 2024-12-06 02:10:45 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:10:45 --> Controller Class Initialized
INFO - 2024-12-06 02:10:45 --> Model "Review_model" initialized
INFO - 2024-12-06 02:10:45 --> Model "Category_model" initialized
INFO - 2024-12-06 02:10:45 --> Model "User_model" initialized
INFO - 2024-12-06 02:10:45 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:10:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:10:45 --> Model "Contact_model" initialized
INFO - 2024-12-06 02:10:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-06 02:10:45 --> Final output sent to browser
DEBUG - 2024-12-06 02:10:45 --> Total execution time: 0.0585
INFO - 2024-12-06 02:10:46 --> Config Class Initialized
INFO - 2024-12-06 02:10:46 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:10:46 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:10:46 --> Utf8 Class Initialized
INFO - 2024-12-06 02:10:46 --> URI Class Initialized
INFO - 2024-12-06 02:10:46 --> Router Class Initialized
INFO - 2024-12-06 02:10:46 --> Output Class Initialized
INFO - 2024-12-06 02:10:46 --> Security Class Initialized
DEBUG - 2024-12-06 02:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:10:46 --> CSRF cookie sent
INFO - 2024-12-06 02:10:46 --> Input Class Initialized
INFO - 2024-12-06 02:10:46 --> Language Class Initialized
INFO - 2024-12-06 02:10:46 --> Loader Class Initialized
INFO - 2024-12-06 02:10:46 --> Helper loaded: url_helper
INFO - 2024-12-06 02:10:46 --> Helper loaded: form_helper
INFO - 2024-12-06 02:10:46 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:10:46 --> Form Validation Class Initialized
INFO - 2024-12-06 02:10:46 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:10:46 --> Controller Class Initialized
INFO - 2024-12-06 02:10:46 --> Model "Review_model" initialized
INFO - 2024-12-06 02:10:46 --> Model "Category_model" initialized
INFO - 2024-12-06 02:10:46 --> Model "User_model" initialized
INFO - 2024-12-06 02:10:46 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:10:46 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:10:46 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 02:10:46 --> Final output sent to browser
DEBUG - 2024-12-06 02:10:46 --> Total execution time: 0.0603
INFO - 2024-12-06 02:10:47 --> Config Class Initialized
INFO - 2024-12-06 02:10:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:10:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:10:47 --> Utf8 Class Initialized
INFO - 2024-12-06 02:10:47 --> URI Class Initialized
INFO - 2024-12-06 02:10:47 --> Router Class Initialized
INFO - 2024-12-06 02:10:47 --> Output Class Initialized
INFO - 2024-12-06 02:10:47 --> Security Class Initialized
DEBUG - 2024-12-06 02:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:10:47 --> CSRF cookie sent
INFO - 2024-12-06 02:10:47 --> Input Class Initialized
INFO - 2024-12-06 02:10:47 --> Language Class Initialized
INFO - 2024-12-06 02:10:47 --> Loader Class Initialized
INFO - 2024-12-06 02:10:47 --> Helper loaded: url_helper
INFO - 2024-12-06 02:10:47 --> Helper loaded: form_helper
INFO - 2024-12-06 02:10:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:10:47 --> Form Validation Class Initialized
INFO - 2024-12-06 02:10:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:10:47 --> Controller Class Initialized
INFO - 2024-12-06 02:10:47 --> Model "Review_model" initialized
INFO - 2024-12-06 02:10:47 --> Model "Category_model" initialized
INFO - 2024-12-06 02:10:47 --> Model "User_model" initialized
INFO - 2024-12-06 02:10:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:10:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:10:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 02:10:47 --> Final output sent to browser
DEBUG - 2024-12-06 02:10:47 --> Total execution time: 0.0503
INFO - 2024-12-06 02:10:48 --> Config Class Initialized
INFO - 2024-12-06 02:10:48 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:10:48 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:10:48 --> Utf8 Class Initialized
INFO - 2024-12-06 02:10:48 --> URI Class Initialized
INFO - 2024-12-06 02:10:48 --> Router Class Initialized
INFO - 2024-12-06 02:10:48 --> Output Class Initialized
INFO - 2024-12-06 02:10:48 --> Security Class Initialized
DEBUG - 2024-12-06 02:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:10:48 --> CSRF cookie sent
INFO - 2024-12-06 02:10:48 --> Input Class Initialized
INFO - 2024-12-06 02:10:48 --> Language Class Initialized
INFO - 2024-12-06 02:10:48 --> Loader Class Initialized
INFO - 2024-12-06 02:10:48 --> Helper loaded: url_helper
INFO - 2024-12-06 02:10:48 --> Helper loaded: form_helper
INFO - 2024-12-06 02:10:48 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:10:48 --> Form Validation Class Initialized
INFO - 2024-12-06 02:10:48 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:10:48 --> Controller Class Initialized
INFO - 2024-12-06 02:10:48 --> Model "News_model" initialized
INFO - 2024-12-06 02:10:48 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 02:10:48 --> Final output sent to browser
DEBUG - 2024-12-06 02:10:48 --> Total execution time: 0.0525
INFO - 2024-12-06 02:10:51 --> Config Class Initialized
INFO - 2024-12-06 02:10:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:10:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:10:51 --> Utf8 Class Initialized
INFO - 2024-12-06 02:10:51 --> URI Class Initialized
INFO - 2024-12-06 02:10:51 --> Router Class Initialized
INFO - 2024-12-06 02:10:51 --> Output Class Initialized
INFO - 2024-12-06 02:10:51 --> Security Class Initialized
DEBUG - 2024-12-06 02:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:10:51 --> CSRF cookie sent
INFO - 2024-12-06 02:10:51 --> Input Class Initialized
INFO - 2024-12-06 02:10:51 --> Language Class Initialized
INFO - 2024-12-06 02:10:51 --> Loader Class Initialized
INFO - 2024-12-06 02:10:51 --> Helper loaded: url_helper
INFO - 2024-12-06 02:10:51 --> Helper loaded: form_helper
INFO - 2024-12-06 02:10:51 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:10:51 --> Form Validation Class Initialized
INFO - 2024-12-06 02:10:51 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:10:51 --> Controller Class Initialized
INFO - 2024-12-06 02:10:51 --> Model "Review_model" initialized
INFO - 2024-12-06 02:10:51 --> Model "Category_model" initialized
INFO - 2024-12-06 02:10:51 --> Model "User_model" initialized
INFO - 2024-12-06 02:10:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:10:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:10:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 02:10:51 --> Final output sent to browser
DEBUG - 2024-12-06 02:10:51 --> Total execution time: 0.0613
INFO - 2024-12-06 02:11:00 --> Config Class Initialized
INFO - 2024-12-06 02:11:00 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:11:00 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:11:00 --> Utf8 Class Initialized
INFO - 2024-12-06 02:11:00 --> URI Class Initialized
INFO - 2024-12-06 02:11:00 --> Router Class Initialized
INFO - 2024-12-06 02:11:00 --> Output Class Initialized
INFO - 2024-12-06 02:11:00 --> Security Class Initialized
DEBUG - 2024-12-06 02:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:11:00 --> CSRF cookie sent
INFO - 2024-12-06 02:11:00 --> Input Class Initialized
INFO - 2024-12-06 02:11:00 --> Language Class Initialized
INFO - 2024-12-06 02:11:00 --> Loader Class Initialized
INFO - 2024-12-06 02:11:00 --> Helper loaded: url_helper
INFO - 2024-12-06 02:11:00 --> Helper loaded: form_helper
INFO - 2024-12-06 02:11:00 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:11:00 --> Form Validation Class Initialized
INFO - 2024-12-06 02:11:00 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:11:00 --> Controller Class Initialized
INFO - 2024-12-06 02:11:00 --> Model "Review_model" initialized
INFO - 2024-12-06 02:11:00 --> Model "Category_model" initialized
INFO - 2024-12-06 02:11:00 --> Model "User_model" initialized
INFO - 2024-12-06 02:11:00 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 02:11:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:11:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 02:11:00 --> Final output sent to browser
DEBUG - 2024-12-06 02:11:00 --> Total execution time: 0.0579
INFO - 2024-12-06 02:11:16 --> Config Class Initialized
INFO - 2024-12-06 02:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:11:16 --> Utf8 Class Initialized
INFO - 2024-12-06 02:11:16 --> URI Class Initialized
INFO - 2024-12-06 02:11:16 --> Router Class Initialized
INFO - 2024-12-06 02:11:16 --> Output Class Initialized
INFO - 2024-12-06 02:11:16 --> Security Class Initialized
DEBUG - 2024-12-06 02:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:11:16 --> CSRF cookie sent
INFO - 2024-12-06 02:11:18 --> Config Class Initialized
INFO - 2024-12-06 02:11:18 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:11:18 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:11:18 --> Utf8 Class Initialized
INFO - 2024-12-06 02:11:18 --> URI Class Initialized
INFO - 2024-12-06 02:11:18 --> Router Class Initialized
INFO - 2024-12-06 02:11:18 --> Output Class Initialized
INFO - 2024-12-06 02:11:18 --> Security Class Initialized
DEBUG - 2024-12-06 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:11:18 --> CSRF cookie sent
INFO - 2024-12-06 02:11:18 --> Input Class Initialized
INFO - 2024-12-06 02:11:18 --> Language Class Initialized
INFO - 2024-12-06 02:11:18 --> Loader Class Initialized
INFO - 2024-12-06 02:11:18 --> Helper loaded: url_helper
INFO - 2024-12-06 02:11:18 --> Helper loaded: form_helper
INFO - 2024-12-06 02:11:18 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:11:18 --> Form Validation Class Initialized
INFO - 2024-12-06 02:11:18 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:11:18 --> Controller Class Initialized
INFO - 2024-12-06 02:11:18 --> Model "User_model" initialized
INFO - 2024-12-06 02:11:18 --> Model "Category_model" initialized
INFO - 2024-12-06 02:11:18 --> Model "Review_model" initialized
INFO - 2024-12-06 02:11:18 --> Model "News_model" initialized
INFO - 2024-12-06 02:11:18 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:11:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:11:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:11:18 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 02:11:18 --> Final output sent to browser
DEBUG - 2024-12-06 02:11:18 --> Total execution time: 0.0605
INFO - 2024-12-06 02:11:26 --> Config Class Initialized
INFO - 2024-12-06 02:11:26 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:11:26 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:11:26 --> Utf8 Class Initialized
INFO - 2024-12-06 02:11:26 --> URI Class Initialized
INFO - 2024-12-06 02:11:26 --> Router Class Initialized
INFO - 2024-12-06 02:11:26 --> Output Class Initialized
INFO - 2024-12-06 02:11:26 --> Security Class Initialized
DEBUG - 2024-12-06 02:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:11:26 --> CSRF cookie sent
INFO - 2024-12-06 02:11:26 --> CSRF token verified
INFO - 2024-12-06 02:11:26 --> Input Class Initialized
INFO - 2024-12-06 02:11:26 --> Language Class Initialized
INFO - 2024-12-06 02:11:26 --> Loader Class Initialized
INFO - 2024-12-06 02:11:26 --> Helper loaded: url_helper
INFO - 2024-12-06 02:11:26 --> Helper loaded: form_helper
INFO - 2024-12-06 02:11:26 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:11:26 --> Form Validation Class Initialized
INFO - 2024-12-06 02:11:26 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:11:26 --> Controller Class Initialized
INFO - 2024-12-06 02:11:26 --> Model "User_model" initialized
INFO - 2024-12-06 02:11:26 --> Model "Category_model" initialized
INFO - 2024-12-06 02:11:26 --> Model "Review_model" initialized
INFO - 2024-12-06 02:11:26 --> Model "News_model" initialized
INFO - 2024-12-06 02:11:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:11:27 --> Config Class Initialized
INFO - 2024-12-06 02:11:27 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:11:27 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:11:27 --> Utf8 Class Initialized
INFO - 2024-12-06 02:11:27 --> URI Class Initialized
INFO - 2024-12-06 02:11:27 --> Router Class Initialized
INFO - 2024-12-06 02:11:27 --> Output Class Initialized
INFO - 2024-12-06 02:11:27 --> Security Class Initialized
DEBUG - 2024-12-06 02:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:11:27 --> CSRF cookie sent
INFO - 2024-12-06 02:11:27 --> Input Class Initialized
INFO - 2024-12-06 02:11:27 --> Language Class Initialized
INFO - 2024-12-06 02:11:27 --> Loader Class Initialized
INFO - 2024-12-06 02:11:27 --> Helper loaded: url_helper
INFO - 2024-12-06 02:11:27 --> Helper loaded: form_helper
INFO - 2024-12-06 02:11:27 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:11:27 --> Form Validation Class Initialized
INFO - 2024-12-06 02:11:27 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:11:27 --> Controller Class Initialized
INFO - 2024-12-06 02:11:27 --> Model "User_model" initialized
INFO - 2024-12-06 02:11:27 --> Model "Category_model" initialized
INFO - 2024-12-06 02:11:27 --> Model "Review_model" initialized
INFO - 2024-12-06 02:11:27 --> Model "News_model" initialized
INFO - 2024-12-06 02:11:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:11:27 --> Query result: stdClass Object
(
    [view_count] => 83
)

INFO - 2024-12-06 02:11:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:11:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:11:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:11:27 --> Final output sent to browser
DEBUG - 2024-12-06 02:11:27 --> Total execution time: 0.0619
INFO - 2024-12-06 02:11:28 --> Config Class Initialized
INFO - 2024-12-06 02:11:28 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:11:28 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:11:28 --> Utf8 Class Initialized
INFO - 2024-12-06 02:11:28 --> URI Class Initialized
INFO - 2024-12-06 02:11:28 --> Router Class Initialized
INFO - 2024-12-06 02:11:28 --> Output Class Initialized
INFO - 2024-12-06 02:11:28 --> Security Class Initialized
DEBUG - 2024-12-06 02:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:11:28 --> CSRF cookie sent
INFO - 2024-12-06 02:11:28 --> Input Class Initialized
INFO - 2024-12-06 02:11:28 --> Language Class Initialized
ERROR - 2024-12-06 02:11:28 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 02:26:32 --> Config Class Initialized
INFO - 2024-12-06 02:26:32 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:26:32 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:26:32 --> Utf8 Class Initialized
INFO - 2024-12-06 02:26:32 --> URI Class Initialized
INFO - 2024-12-06 02:26:32 --> Router Class Initialized
INFO - 2024-12-06 02:26:32 --> Output Class Initialized
INFO - 2024-12-06 02:26:32 --> Security Class Initialized
DEBUG - 2024-12-06 02:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:26:32 --> CSRF cookie sent
INFO - 2024-12-06 02:26:32 --> Input Class Initialized
INFO - 2024-12-06 02:26:32 --> Language Class Initialized
INFO - 2024-12-06 02:26:32 --> Loader Class Initialized
INFO - 2024-12-06 02:26:32 --> Helper loaded: url_helper
INFO - 2024-12-06 02:26:32 --> Helper loaded: form_helper
INFO - 2024-12-06 02:26:32 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:26:32 --> Form Validation Class Initialized
INFO - 2024-12-06 02:26:32 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:26:32 --> Controller Class Initialized
INFO - 2024-12-06 02:26:32 --> Model "User_model" initialized
INFO - 2024-12-06 02:26:32 --> Model "Category_model" initialized
INFO - 2024-12-06 02:26:32 --> Model "Review_model" initialized
INFO - 2024-12-06 02:26:32 --> Model "News_model" initialized
INFO - 2024-12-06 02:26:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:26:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:26:32 --> Query result: stdClass Object
(
    [view_count] => 84
)

INFO - 2024-12-06 02:26:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:26:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:26:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:26:32 --> Final output sent to browser
DEBUG - 2024-12-06 02:26:32 --> Total execution time: 0.1750
INFO - 2024-12-06 02:26:33 --> Config Class Initialized
INFO - 2024-12-06 02:26:33 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:26:33 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:26:33 --> Utf8 Class Initialized
INFO - 2024-12-06 02:26:33 --> URI Class Initialized
INFO - 2024-12-06 02:26:33 --> Router Class Initialized
INFO - 2024-12-06 02:26:33 --> Output Class Initialized
INFO - 2024-12-06 02:26:33 --> Security Class Initialized
DEBUG - 2024-12-06 02:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:26:33 --> CSRF cookie sent
INFO - 2024-12-06 02:26:33 --> Input Class Initialized
INFO - 2024-12-06 02:26:33 --> Language Class Initialized
ERROR - 2024-12-06 02:26:33 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 02:26:49 --> Config Class Initialized
INFO - 2024-12-06 02:26:49 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:26:49 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:26:49 --> Utf8 Class Initialized
INFO - 2024-12-06 02:26:49 --> URI Class Initialized
INFO - 2024-12-06 02:26:49 --> Router Class Initialized
INFO - 2024-12-06 02:26:49 --> Output Class Initialized
INFO - 2024-12-06 02:26:49 --> Security Class Initialized
DEBUG - 2024-12-06 02:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:26:49 --> CSRF cookie sent
INFO - 2024-12-06 02:26:49 --> Input Class Initialized
INFO - 2024-12-06 02:26:49 --> Language Class Initialized
INFO - 2024-12-06 02:26:49 --> Loader Class Initialized
INFO - 2024-12-06 02:26:49 --> Helper loaded: url_helper
INFO - 2024-12-06 02:26:49 --> Helper loaded: form_helper
INFO - 2024-12-06 02:26:49 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:26:49 --> Form Validation Class Initialized
INFO - 2024-12-06 02:26:49 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:26:49 --> Controller Class Initialized
INFO - 2024-12-06 02:26:49 --> Model "User_model" initialized
INFO - 2024-12-06 02:26:49 --> Model "Category_model" initialized
INFO - 2024-12-06 02:26:49 --> Model "Review_model" initialized
INFO - 2024-12-06 02:26:49 --> Model "News_model" initialized
INFO - 2024-12-06 02:26:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:26:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:26:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:26:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 02:26:49 --> Final output sent to browser
DEBUG - 2024-12-06 02:26:49 --> Total execution time: 0.0918
INFO - 2024-12-06 02:26:50 --> Config Class Initialized
INFO - 2024-12-06 02:26:50 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:26:50 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:26:50 --> Utf8 Class Initialized
INFO - 2024-12-06 02:26:50 --> URI Class Initialized
INFO - 2024-12-06 02:26:50 --> Router Class Initialized
INFO - 2024-12-06 02:26:50 --> Output Class Initialized
INFO - 2024-12-06 02:26:50 --> Security Class Initialized
DEBUG - 2024-12-06 02:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:26:50 --> CSRF cookie sent
INFO - 2024-12-06 02:26:50 --> Input Class Initialized
INFO - 2024-12-06 02:26:50 --> Language Class Initialized
INFO - 2024-12-06 02:26:50 --> Loader Class Initialized
INFO - 2024-12-06 02:26:50 --> Helper loaded: url_helper
INFO - 2024-12-06 02:26:50 --> Helper loaded: form_helper
INFO - 2024-12-06 02:26:50 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:26:50 --> Form Validation Class Initialized
INFO - 2024-12-06 02:26:50 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:26:50 --> Controller Class Initialized
INFO - 2024-12-06 02:26:50 --> Model "User_model" initialized
INFO - 2024-12-06 02:26:50 --> Model "Category_model" initialized
INFO - 2024-12-06 02:26:50 --> Model "Review_model" initialized
INFO - 2024-12-06 02:26:50 --> Model "News_model" initialized
INFO - 2024-12-06 02:26:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:26:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:26:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:26:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 02:26:50 --> Final output sent to browser
DEBUG - 2024-12-06 02:26:50 --> Total execution time: 0.0527
INFO - 2024-12-06 02:27:04 --> Config Class Initialized
INFO - 2024-12-06 02:27:04 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:04 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:04 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:04 --> URI Class Initialized
INFO - 2024-12-06 02:27:04 --> Router Class Initialized
INFO - 2024-12-06 02:27:04 --> Output Class Initialized
INFO - 2024-12-06 02:27:04 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:04 --> CSRF cookie sent
INFO - 2024-12-06 02:27:04 --> CSRF token verified
INFO - 2024-12-06 02:27:04 --> Input Class Initialized
INFO - 2024-12-06 02:27:04 --> Language Class Initialized
INFO - 2024-12-06 02:27:04 --> Loader Class Initialized
INFO - 2024-12-06 02:27:04 --> Helper loaded: url_helper
INFO - 2024-12-06 02:27:04 --> Helper loaded: form_helper
INFO - 2024-12-06 02:27:04 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:27:04 --> Form Validation Class Initialized
INFO - 2024-12-06 02:27:04 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:27:04 --> Controller Class Initialized
INFO - 2024-12-06 02:27:04 --> Model "User_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "Category_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "Review_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "News_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:27:04 --> Config Class Initialized
INFO - 2024-12-06 02:27:04 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:04 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:04 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:04 --> URI Class Initialized
INFO - 2024-12-06 02:27:04 --> Router Class Initialized
INFO - 2024-12-06 02:27:04 --> Output Class Initialized
INFO - 2024-12-06 02:27:04 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:04 --> CSRF cookie sent
INFO - 2024-12-06 02:27:04 --> Input Class Initialized
INFO - 2024-12-06 02:27:04 --> Language Class Initialized
INFO - 2024-12-06 02:27:04 --> Loader Class Initialized
INFO - 2024-12-06 02:27:04 --> Helper loaded: url_helper
INFO - 2024-12-06 02:27:04 --> Helper loaded: form_helper
INFO - 2024-12-06 02:27:04 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:27:04 --> Form Validation Class Initialized
INFO - 2024-12-06 02:27:04 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:27:04 --> Controller Class Initialized
INFO - 2024-12-06 02:27:04 --> Model "User_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "Category_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "Review_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "News_model" initialized
INFO - 2024-12-06 02:27:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:27:04 --> Query result: stdClass Object
(
    [view_count] => 85
)

INFO - 2024-12-06 02:27:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:27:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:27:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:27:04 --> Final output sent to browser
DEBUG - 2024-12-06 02:27:04 --> Total execution time: 0.0545
INFO - 2024-12-06 02:27:04 --> Config Class Initialized
INFO - 2024-12-06 02:27:04 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:04 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:04 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:04 --> URI Class Initialized
INFO - 2024-12-06 02:27:04 --> Router Class Initialized
INFO - 2024-12-06 02:27:04 --> Output Class Initialized
INFO - 2024-12-06 02:27:04 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:04 --> CSRF cookie sent
INFO - 2024-12-06 02:27:04 --> Input Class Initialized
INFO - 2024-12-06 02:27:04 --> Language Class Initialized
ERROR - 2024-12-06 02:27:04 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 02:27:12 --> Config Class Initialized
INFO - 2024-12-06 02:27:12 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:12 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:12 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:12 --> URI Class Initialized
INFO - 2024-12-06 02:27:12 --> Router Class Initialized
INFO - 2024-12-06 02:27:12 --> Output Class Initialized
INFO - 2024-12-06 02:27:12 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:12 --> CSRF cookie sent
INFO - 2024-12-06 02:27:12 --> Input Class Initialized
INFO - 2024-12-06 02:27:12 --> Language Class Initialized
INFO - 2024-12-06 02:27:12 --> Loader Class Initialized
INFO - 2024-12-06 02:27:12 --> Helper loaded: url_helper
INFO - 2024-12-06 02:27:12 --> Helper loaded: form_helper
INFO - 2024-12-06 02:27:12 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:27:12 --> Form Validation Class Initialized
INFO - 2024-12-06 02:27:12 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:27:12 --> Controller Class Initialized
INFO - 2024-12-06 02:27:12 --> Model "User_model" initialized
INFO - 2024-12-06 02:27:12 --> Model "Category_model" initialized
INFO - 2024-12-06 02:27:12 --> Model "Review_model" initialized
INFO - 2024-12-06 02:27:12 --> Model "News_model" initialized
INFO - 2024-12-06 02:27:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:27:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:27:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:27:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-06 02:27:13 --> Final output sent to browser
DEBUG - 2024-12-06 02:27:13 --> Total execution time: 0.1558
INFO - 2024-12-06 02:27:23 --> Config Class Initialized
INFO - 2024-12-06 02:27:23 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:23 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:23 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:23 --> URI Class Initialized
INFO - 2024-12-06 02:27:23 --> Router Class Initialized
INFO - 2024-12-06 02:27:23 --> Output Class Initialized
INFO - 2024-12-06 02:27:23 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:23 --> CSRF cookie sent
INFO - 2024-12-06 02:27:23 --> Input Class Initialized
INFO - 2024-12-06 02:27:23 --> Language Class Initialized
INFO - 2024-12-06 02:27:23 --> Loader Class Initialized
INFO - 2024-12-06 02:27:23 --> Helper loaded: url_helper
INFO - 2024-12-06 02:27:23 --> Helper loaded: form_helper
INFO - 2024-12-06 02:27:23 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:27:23 --> Form Validation Class Initialized
INFO - 2024-12-06 02:27:23 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:27:23 --> Controller Class Initialized
INFO - 2024-12-06 02:27:23 --> Model "User_model" initialized
INFO - 2024-12-06 02:27:23 --> Model "Category_model" initialized
INFO - 2024-12-06 02:27:23 --> Model "Review_model" initialized
INFO - 2024-12-06 02:27:23 --> Model "News_model" initialized
INFO - 2024-12-06 02:27:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:27:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:27:23 --> Query result: stdClass Object
(
    [view_count] => 86
)

INFO - 2024-12-06 02:27:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:27:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:27:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:27:23 --> Final output sent to browser
DEBUG - 2024-12-06 02:27:23 --> Total execution time: 0.0635
INFO - 2024-12-06 02:27:24 --> Config Class Initialized
INFO - 2024-12-06 02:27:24 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:24 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:24 --> URI Class Initialized
INFO - 2024-12-06 02:27:24 --> Router Class Initialized
INFO - 2024-12-06 02:27:24 --> Output Class Initialized
INFO - 2024-12-06 02:27:24 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:24 --> CSRF cookie sent
INFO - 2024-12-06 02:27:24 --> Input Class Initialized
INFO - 2024-12-06 02:27:24 --> Language Class Initialized
ERROR - 2024-12-06 02:27:24 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 02:27:56 --> Config Class Initialized
INFO - 2024-12-06 02:27:56 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:27:56 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:27:56 --> Utf8 Class Initialized
INFO - 2024-12-06 02:27:56 --> URI Class Initialized
DEBUG - 2024-12-06 02:27:56 --> No URI present. Default controller set.
INFO - 2024-12-06 02:27:56 --> Router Class Initialized
INFO - 2024-12-06 02:27:56 --> Output Class Initialized
INFO - 2024-12-06 02:27:56 --> Security Class Initialized
DEBUG - 2024-12-06 02:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:27:56 --> CSRF cookie sent
INFO - 2024-12-06 02:27:56 --> Input Class Initialized
INFO - 2024-12-06 02:27:56 --> Language Class Initialized
INFO - 2024-12-06 02:27:56 --> Loader Class Initialized
INFO - 2024-12-06 02:27:56 --> Helper loaded: url_helper
INFO - 2024-12-06 02:27:56 --> Helper loaded: form_helper
INFO - 2024-12-06 02:27:56 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:27:56 --> Form Validation Class Initialized
INFO - 2024-12-06 02:27:56 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:27:56 --> Controller Class Initialized
INFO - 2024-12-06 02:27:56 --> Model "User_model" initialized
INFO - 2024-12-06 02:27:56 --> Model "Category_model" initialized
INFO - 2024-12-06 02:27:56 --> Model "Review_model" initialized
INFO - 2024-12-06 02:27:56 --> Model "News_model" initialized
INFO - 2024-12-06 02:27:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:27:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:27:56 --> Query result: stdClass Object
(
    [view_count] => 87
)

INFO - 2024-12-06 02:27:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:27:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:27:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:27:56 --> Final output sent to browser
DEBUG - 2024-12-06 02:27:56 --> Total execution time: 0.0716
INFO - 2024-12-06 02:29:55 --> Config Class Initialized
INFO - 2024-12-06 02:29:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:29:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:29:55 --> Utf8 Class Initialized
INFO - 2024-12-06 02:29:55 --> URI Class Initialized
DEBUG - 2024-12-06 02:29:55 --> No URI present. Default controller set.
INFO - 2024-12-06 02:29:55 --> Router Class Initialized
INFO - 2024-12-06 02:29:55 --> Output Class Initialized
INFO - 2024-12-06 02:29:55 --> Security Class Initialized
DEBUG - 2024-12-06 02:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:29:55 --> CSRF cookie sent
INFO - 2024-12-06 02:29:55 --> Input Class Initialized
INFO - 2024-12-06 02:29:55 --> Language Class Initialized
INFO - 2024-12-06 02:29:55 --> Loader Class Initialized
INFO - 2024-12-06 02:29:55 --> Helper loaded: url_helper
INFO - 2024-12-06 02:29:55 --> Helper loaded: form_helper
INFO - 2024-12-06 02:29:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:29:55 --> Form Validation Class Initialized
INFO - 2024-12-06 02:29:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:29:55 --> Controller Class Initialized
INFO - 2024-12-06 02:29:55 --> Model "User_model" initialized
INFO - 2024-12-06 02:29:55 --> Model "Category_model" initialized
INFO - 2024-12-06 02:29:55 --> Model "Review_model" initialized
INFO - 2024-12-06 02:29:55 --> Model "News_model" initialized
INFO - 2024-12-06 02:29:55 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:29:55 --> Query result: stdClass Object
(
    [view_count] => 88
)

INFO - 2024-12-06 02:29:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:29:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:29:55 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:29:55 --> Final output sent to browser
DEBUG - 2024-12-06 02:29:55 --> Total execution time: 0.0745
INFO - 2024-12-06 02:34:16 --> Config Class Initialized
INFO - 2024-12-06 02:34:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:34:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:34:16 --> Utf8 Class Initialized
INFO - 2024-12-06 02:34:16 --> URI Class Initialized
INFO - 2024-12-06 02:34:16 --> Router Class Initialized
INFO - 2024-12-06 02:34:16 --> Output Class Initialized
INFO - 2024-12-06 02:34:16 --> Security Class Initialized
DEBUG - 2024-12-06 02:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:34:16 --> CSRF cookie sent
INFO - 2024-12-06 02:34:16 --> Input Class Initialized
INFO - 2024-12-06 02:34:16 --> Language Class Initialized
INFO - 2024-12-06 02:34:16 --> Loader Class Initialized
INFO - 2024-12-06 02:34:16 --> Helper loaded: url_helper
INFO - 2024-12-06 02:34:16 --> Helper loaded: form_helper
INFO - 2024-12-06 02:34:16 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:34:16 --> Form Validation Class Initialized
INFO - 2024-12-06 02:34:16 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:34:16 --> Controller Class Initialized
INFO - 2024-12-06 02:34:16 --> Model "User_model" initialized
INFO - 2024-12-06 02:34:16 --> Model "Category_model" initialized
INFO - 2024-12-06 02:34:16 --> Model "Review_model" initialized
INFO - 2024-12-06 02:34:16 --> Model "News_model" initialized
INFO - 2024-12-06 02:34:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:34:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:34:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:34:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-06 02:34:16 --> Final output sent to browser
DEBUG - 2024-12-06 02:34:16 --> Total execution time: 0.1009
INFO - 2024-12-06 02:34:21 --> Config Class Initialized
INFO - 2024-12-06 02:34:21 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:34:21 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:34:21 --> Utf8 Class Initialized
INFO - 2024-12-06 02:34:21 --> URI Class Initialized
INFO - 2024-12-06 02:34:21 --> Router Class Initialized
INFO - 2024-12-06 02:34:21 --> Output Class Initialized
INFO - 2024-12-06 02:34:21 --> Security Class Initialized
DEBUG - 2024-12-06 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:34:21 --> CSRF cookie sent
INFO - 2024-12-06 02:34:21 --> Input Class Initialized
INFO - 2024-12-06 02:34:21 --> Language Class Initialized
INFO - 2024-12-06 02:34:21 --> Loader Class Initialized
INFO - 2024-12-06 02:34:21 --> Helper loaded: url_helper
INFO - 2024-12-06 02:34:21 --> Helper loaded: form_helper
INFO - 2024-12-06 02:34:21 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:34:21 --> Form Validation Class Initialized
INFO - 2024-12-06 02:34:21 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:34:21 --> Controller Class Initialized
INFO - 2024-12-06 02:34:21 --> Model "User_model" initialized
INFO - 2024-12-06 02:34:21 --> Model "Category_model" initialized
INFO - 2024-12-06 02:34:21 --> Model "Review_model" initialized
INFO - 2024-12-06 02:34:21 --> Model "News_model" initialized
INFO - 2024-12-06 02:34:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 02:34:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:34:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:34:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-06 02:34:21 --> Final output sent to browser
DEBUG - 2024-12-06 02:34:21 --> Total execution time: 0.0769
INFO - 2024-12-06 02:37:30 --> Config Class Initialized
INFO - 2024-12-06 02:37:30 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:37:30 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:37:30 --> Utf8 Class Initialized
INFO - 2024-12-06 02:37:30 --> URI Class Initialized
INFO - 2024-12-06 02:37:30 --> Router Class Initialized
INFO - 2024-12-06 02:37:30 --> Output Class Initialized
INFO - 2024-12-06 02:37:30 --> Security Class Initialized
DEBUG - 2024-12-06 02:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:37:30 --> CSRF cookie sent
INFO - 2024-12-06 02:37:30 --> Input Class Initialized
INFO - 2024-12-06 02:37:30 --> Language Class Initialized
INFO - 2024-12-06 02:37:30 --> Loader Class Initialized
INFO - 2024-12-06 02:37:30 --> Helper loaded: url_helper
INFO - 2024-12-06 02:37:30 --> Helper loaded: form_helper
INFO - 2024-12-06 02:37:30 --> Database Driver Class Initialized
DEBUG - 2024-12-06 02:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 02:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 02:37:30 --> Form Validation Class Initialized
INFO - 2024-12-06 02:37:30 --> Model "Culinary_model" initialized
INFO - 2024-12-06 02:37:30 --> Controller Class Initialized
INFO - 2024-12-06 02:37:30 --> Model "User_model" initialized
INFO - 2024-12-06 02:37:30 --> Model "Category_model" initialized
INFO - 2024-12-06 02:37:30 --> Model "Review_model" initialized
INFO - 2024-12-06 02:37:30 --> Model "News_model" initialized
INFO - 2024-12-06 02:37:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 02:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 02:37:30 --> Query result: stdClass Object
(
    [view_count] => 89
)

INFO - 2024-12-06 02:37:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 02:37:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 02:37:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 02:37:30 --> Final output sent to browser
DEBUG - 2024-12-06 02:37:30 --> Total execution time: 0.0936
INFO - 2024-12-06 02:37:30 --> Config Class Initialized
INFO - 2024-12-06 02:37:30 --> Hooks Class Initialized
DEBUG - 2024-12-06 02:37:30 --> UTF-8 Support Enabled
INFO - 2024-12-06 02:37:30 --> Utf8 Class Initialized
INFO - 2024-12-06 02:37:30 --> URI Class Initialized
INFO - 2024-12-06 02:37:30 --> Router Class Initialized
INFO - 2024-12-06 02:37:30 --> Output Class Initialized
INFO - 2024-12-06 02:37:30 --> Security Class Initialized
DEBUG - 2024-12-06 02:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 02:37:30 --> CSRF cookie sent
INFO - 2024-12-06 02:37:30 --> Input Class Initialized
INFO - 2024-12-06 02:37:30 --> Language Class Initialized
ERROR - 2024-12-06 02:37:30 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 03:01:47 --> Config Class Initialized
INFO - 2024-12-06 03:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:01:47 --> Utf8 Class Initialized
INFO - 2024-12-06 03:01:47 --> URI Class Initialized
INFO - 2024-12-06 03:01:47 --> Router Class Initialized
INFO - 2024-12-06 03:01:47 --> Output Class Initialized
INFO - 2024-12-06 03:01:47 --> Security Class Initialized
DEBUG - 2024-12-06 03:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:01:47 --> CSRF cookie sent
INFO - 2024-12-06 03:01:47 --> Input Class Initialized
INFO - 2024-12-06 03:01:47 --> Language Class Initialized
INFO - 2024-12-06 03:01:47 --> Loader Class Initialized
INFO - 2024-12-06 03:01:47 --> Helper loaded: url_helper
INFO - 2024-12-06 03:01:47 --> Helper loaded: form_helper
INFO - 2024-12-06 03:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 03:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 03:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 03:01:47 --> Form Validation Class Initialized
INFO - 2024-12-06 03:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 03:01:47 --> Controller Class Initialized
INFO - 2024-12-06 03:01:47 --> Model "User_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "Category_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "Review_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "News_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 03:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 03:01:47 --> Config Class Initialized
INFO - 2024-12-06 03:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:01:47 --> Utf8 Class Initialized
INFO - 2024-12-06 03:01:47 --> URI Class Initialized
INFO - 2024-12-06 03:01:47 --> Router Class Initialized
INFO - 2024-12-06 03:01:47 --> Output Class Initialized
INFO - 2024-12-06 03:01:47 --> Security Class Initialized
DEBUG - 2024-12-06 03:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:01:47 --> CSRF cookie sent
INFO - 2024-12-06 03:01:47 --> Input Class Initialized
INFO - 2024-12-06 03:01:47 --> Language Class Initialized
INFO - 2024-12-06 03:01:47 --> Loader Class Initialized
INFO - 2024-12-06 03:01:47 --> Helper loaded: url_helper
INFO - 2024-12-06 03:01:47 --> Helper loaded: form_helper
INFO - 2024-12-06 03:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 03:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 03:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 03:01:47 --> Form Validation Class Initialized
INFO - 2024-12-06 03:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 03:01:47 --> Controller Class Initialized
INFO - 2024-12-06 03:01:47 --> Model "User_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "Category_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "Review_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "News_model" initialized
INFO - 2024-12-06 03:01:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 03:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 03:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 03:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 03:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 03:01:47 --> Final output sent to browser
DEBUG - 2024-12-06 03:01:47 --> Total execution time: 0.0425
INFO - 2024-12-06 03:07:21 --> Config Class Initialized
INFO - 2024-12-06 03:07:21 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:07:21 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:07:21 --> Utf8 Class Initialized
INFO - 2024-12-06 03:07:21 --> URI Class Initialized
INFO - 2024-12-06 03:07:21 --> Router Class Initialized
INFO - 2024-12-06 03:07:21 --> Output Class Initialized
INFO - 2024-12-06 03:07:21 --> Security Class Initialized
DEBUG - 2024-12-06 03:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:07:21 --> CSRF cookie sent
INFO - 2024-12-06 03:07:21 --> CSRF token verified
INFO - 2024-12-06 03:07:21 --> Input Class Initialized
INFO - 2024-12-06 03:07:21 --> Language Class Initialized
INFO - 2024-12-06 03:07:21 --> Loader Class Initialized
INFO - 2024-12-06 03:07:21 --> Helper loaded: url_helper
INFO - 2024-12-06 03:07:21 --> Helper loaded: form_helper
INFO - 2024-12-06 03:07:21 --> Database Driver Class Initialized
DEBUG - 2024-12-06 03:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 03:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 03:07:21 --> Form Validation Class Initialized
INFO - 2024-12-06 03:07:21 --> Model "Culinary_model" initialized
INFO - 2024-12-06 03:07:21 --> Controller Class Initialized
INFO - 2024-12-06 03:07:21 --> Model "User_model" initialized
INFO - 2024-12-06 03:07:21 --> Model "Category_model" initialized
INFO - 2024-12-06 03:07:21 --> Model "Review_model" initialized
INFO - 2024-12-06 03:07:21 --> Model "News_model" initialized
INFO - 2024-12-06 03:07:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 03:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 03:07:22 --> Config Class Initialized
INFO - 2024-12-06 03:07:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:07:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:07:22 --> Utf8 Class Initialized
INFO - 2024-12-06 03:07:22 --> URI Class Initialized
INFO - 2024-12-06 03:07:22 --> Router Class Initialized
INFO - 2024-12-06 03:07:22 --> Output Class Initialized
INFO - 2024-12-06 03:07:22 --> Security Class Initialized
DEBUG - 2024-12-06 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:07:22 --> CSRF cookie sent
INFO - 2024-12-06 03:07:22 --> Input Class Initialized
INFO - 2024-12-06 03:07:22 --> Language Class Initialized
INFO - 2024-12-06 03:07:22 --> Loader Class Initialized
INFO - 2024-12-06 03:07:22 --> Helper loaded: url_helper
INFO - 2024-12-06 03:07:22 --> Helper loaded: form_helper
INFO - 2024-12-06 03:07:22 --> Database Driver Class Initialized
DEBUG - 2024-12-06 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 03:07:22 --> Form Validation Class Initialized
INFO - 2024-12-06 03:07:22 --> Model "Culinary_model" initialized
INFO - 2024-12-06 03:07:22 --> Controller Class Initialized
INFO - 2024-12-06 03:07:22 --> Model "User_model" initialized
INFO - 2024-12-06 03:07:22 --> Model "Category_model" initialized
INFO - 2024-12-06 03:07:22 --> Model "Review_model" initialized
INFO - 2024-12-06 03:07:22 --> Model "News_model" initialized
INFO - 2024-12-06 03:07:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 03:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 03:07:22 --> Query result: stdClass Object
(
    [view_count] => 90
)

INFO - 2024-12-06 03:07:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 03:07:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 03:07:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 03:07:22 --> Final output sent to browser
DEBUG - 2024-12-06 03:07:22 --> Total execution time: 0.0930
INFO - 2024-12-06 03:07:22 --> Config Class Initialized
INFO - 2024-12-06 03:07:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:07:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:07:22 --> Utf8 Class Initialized
INFO - 2024-12-06 03:07:22 --> URI Class Initialized
INFO - 2024-12-06 03:07:22 --> Router Class Initialized
INFO - 2024-12-06 03:07:22 --> Output Class Initialized
INFO - 2024-12-06 03:07:22 --> Security Class Initialized
DEBUG - 2024-12-06 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:07:22 --> CSRF cookie sent
INFO - 2024-12-06 03:07:22 --> Input Class Initialized
INFO - 2024-12-06 03:07:22 --> Language Class Initialized
ERROR - 2024-12-06 03:07:22 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 03:07:26 --> Config Class Initialized
INFO - 2024-12-06 03:07:26 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:07:26 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:07:26 --> Utf8 Class Initialized
INFO - 2024-12-06 03:07:26 --> URI Class Initialized
INFO - 2024-12-06 03:07:26 --> Router Class Initialized
INFO - 2024-12-06 03:07:26 --> Output Class Initialized
INFO - 2024-12-06 03:07:26 --> Security Class Initialized
DEBUG - 2024-12-06 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:07:26 --> CSRF cookie sent
INFO - 2024-12-06 03:07:26 --> Input Class Initialized
INFO - 2024-12-06 03:07:26 --> Language Class Initialized
INFO - 2024-12-06 03:07:26 --> Loader Class Initialized
INFO - 2024-12-06 03:07:26 --> Helper loaded: url_helper
INFO - 2024-12-06 03:07:26 --> Helper loaded: form_helper
INFO - 2024-12-06 03:07:26 --> Database Driver Class Initialized
DEBUG - 2024-12-06 03:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 03:07:26 --> Form Validation Class Initialized
INFO - 2024-12-06 03:07:26 --> Model "Culinary_model" initialized
INFO - 2024-12-06 03:07:26 --> Controller Class Initialized
INFO - 2024-12-06 03:07:26 --> Model "User_model" initialized
INFO - 2024-12-06 03:07:26 --> Model "Category_model" initialized
INFO - 2024-12-06 03:07:26 --> Model "Review_model" initialized
INFO - 2024-12-06 03:07:26 --> Model "News_model" initialized
INFO - 2024-12-06 03:07:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 03:07:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 03:07:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 03:07:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/details_by_category.php
INFO - 2024-12-06 03:07:26 --> Final output sent to browser
DEBUG - 2024-12-06 03:07:26 --> Total execution time: 0.0752
INFO - 2024-12-06 03:07:28 --> Config Class Initialized
INFO - 2024-12-06 03:07:28 --> Hooks Class Initialized
DEBUG - 2024-12-06 03:07:28 --> UTF-8 Support Enabled
INFO - 2024-12-06 03:07:28 --> Utf8 Class Initialized
INFO - 2024-12-06 03:07:28 --> URI Class Initialized
INFO - 2024-12-06 03:07:28 --> Router Class Initialized
INFO - 2024-12-06 03:07:28 --> Output Class Initialized
INFO - 2024-12-06 03:07:28 --> Security Class Initialized
DEBUG - 2024-12-06 03:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 03:07:28 --> CSRF cookie sent
INFO - 2024-12-06 03:07:28 --> Input Class Initialized
INFO - 2024-12-06 03:07:28 --> Language Class Initialized
INFO - 2024-12-06 03:07:28 --> Loader Class Initialized
INFO - 2024-12-06 03:07:28 --> Helper loaded: url_helper
INFO - 2024-12-06 03:07:28 --> Helper loaded: form_helper
INFO - 2024-12-06 03:07:28 --> Database Driver Class Initialized
DEBUG - 2024-12-06 03:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 03:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 03:07:28 --> Form Validation Class Initialized
INFO - 2024-12-06 03:07:28 --> Model "Culinary_model" initialized
INFO - 2024-12-06 03:07:28 --> Controller Class Initialized
INFO - 2024-12-06 03:07:28 --> Model "User_model" initialized
INFO - 2024-12-06 03:07:28 --> Model "Category_model" initialized
INFO - 2024-12-06 03:07:28 --> Model "Review_model" initialized
INFO - 2024-12-06 03:07:28 --> Model "News_model" initialized
INFO - 2024-12-06 03:07:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 03:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 03:07:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 03:07:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 03:07:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-06 03:07:28 --> Final output sent to browser
DEBUG - 2024-12-06 03:07:28 --> Total execution time: 0.0427
INFO - 2024-12-06 04:00:52 --> Config Class Initialized
INFO - 2024-12-06 04:00:52 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:00:52 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:00:52 --> Utf8 Class Initialized
INFO - 2024-12-06 04:00:52 --> URI Class Initialized
DEBUG - 2024-12-06 04:00:52 --> No URI present. Default controller set.
INFO - 2024-12-06 04:00:52 --> Router Class Initialized
INFO - 2024-12-06 04:00:52 --> Output Class Initialized
INFO - 2024-12-06 04:00:52 --> Security Class Initialized
DEBUG - 2024-12-06 04:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:00:52 --> CSRF cookie sent
INFO - 2024-12-06 04:00:52 --> Input Class Initialized
INFO - 2024-12-06 04:00:52 --> Language Class Initialized
INFO - 2024-12-06 04:00:52 --> Loader Class Initialized
INFO - 2024-12-06 04:00:52 --> Helper loaded: url_helper
INFO - 2024-12-06 04:00:52 --> Helper loaded: form_helper
INFO - 2024-12-06 04:00:52 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:00:52 --> Form Validation Class Initialized
INFO - 2024-12-06 04:00:52 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:00:52 --> Controller Class Initialized
INFO - 2024-12-06 04:00:52 --> Model "User_model" initialized
INFO - 2024-12-06 04:00:52 --> Model "Category_model" initialized
INFO - 2024-12-06 04:00:52 --> Model "Review_model" initialized
INFO - 2024-12-06 04:00:52 --> Model "News_model" initialized
INFO - 2024-12-06 04:00:52 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:00:52 --> Query result: stdClass Object
(
    [view_count] => 91
)

INFO - 2024-12-06 04:00:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:00:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:00:52 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 04:00:52 --> Final output sent to browser
DEBUG - 2024-12-06 04:00:52 --> Total execution time: 0.7083
INFO - 2024-12-06 04:00:58 --> Config Class Initialized
INFO - 2024-12-06 04:00:58 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:00:58 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:00:58 --> Utf8 Class Initialized
INFO - 2024-12-06 04:00:58 --> URI Class Initialized
DEBUG - 2024-12-06 04:00:58 --> No URI present. Default controller set.
INFO - 2024-12-06 04:00:58 --> Router Class Initialized
INFO - 2024-12-06 04:00:58 --> Output Class Initialized
INFO - 2024-12-06 04:00:58 --> Security Class Initialized
DEBUG - 2024-12-06 04:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:00:58 --> CSRF cookie sent
INFO - 2024-12-06 04:00:58 --> Input Class Initialized
INFO - 2024-12-06 04:00:58 --> Language Class Initialized
INFO - 2024-12-06 04:00:58 --> Loader Class Initialized
INFO - 2024-12-06 04:00:58 --> Helper loaded: url_helper
INFO - 2024-12-06 04:00:58 --> Helper loaded: form_helper
INFO - 2024-12-06 04:00:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:00:58 --> Form Validation Class Initialized
INFO - 2024-12-06 04:00:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:00:58 --> Controller Class Initialized
INFO - 2024-12-06 04:00:58 --> Model "User_model" initialized
INFO - 2024-12-06 04:00:58 --> Model "Category_model" initialized
INFO - 2024-12-06 04:00:58 --> Model "Review_model" initialized
INFO - 2024-12-06 04:00:58 --> Model "News_model" initialized
INFO - 2024-12-06 04:00:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:00:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:00:58 --> Query result: stdClass Object
(
    [view_count] => 92
)

INFO - 2024-12-06 04:00:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:00:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:00:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 04:00:58 --> Final output sent to browser
DEBUG - 2024-12-06 04:00:58 --> Total execution time: 0.1335
INFO - 2024-12-06 04:01:15 --> Config Class Initialized
INFO - 2024-12-06 04:01:15 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:15 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:15 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:15 --> URI Class Initialized
INFO - 2024-12-06 04:01:15 --> Router Class Initialized
INFO - 2024-12-06 04:01:15 --> Output Class Initialized
INFO - 2024-12-06 04:01:15 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:15 --> CSRF cookie sent
INFO - 2024-12-06 04:01:15 --> Input Class Initialized
INFO - 2024-12-06 04:01:15 --> Language Class Initialized
INFO - 2024-12-06 04:01:15 --> Loader Class Initialized
INFO - 2024-12-06 04:01:15 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:15 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:15 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:15 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:15 --> Controller Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:15 --> Config Class Initialized
INFO - 2024-12-06 04:01:15 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:15 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:15 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:15 --> URI Class Initialized
INFO - 2024-12-06 04:01:15 --> Router Class Initialized
INFO - 2024-12-06 04:01:15 --> Config Class Initialized
INFO - 2024-12-06 04:01:15 --> Hooks Class Initialized
INFO - 2024-12-06 04:01:15 --> Output Class Initialized
INFO - 2024-12-06 04:01:15 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:15 --> CSRF cookie sent
DEBUG - 2024-12-06 04:01:15 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:15 --> Input Class Initialized
INFO - 2024-12-06 04:01:15 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:15 --> Language Class Initialized
INFO - 2024-12-06 04:01:15 --> URI Class Initialized
INFO - 2024-12-06 04:01:15 --> Router Class Initialized
INFO - 2024-12-06 04:01:15 --> Loader Class Initialized
INFO - 2024-12-06 04:01:15 --> Output Class Initialized
INFO - 2024-12-06 04:01:15 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:15 --> Security Class Initialized
INFO - 2024-12-06 04:01:15 --> Helper loaded: form_helper
DEBUG - 2024-12-06 04:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:15 --> CSRF cookie sent
INFO - 2024-12-06 04:01:15 --> Input Class Initialized
INFO - 2024-12-06 04:01:15 --> Language Class Initialized
INFO - 2024-12-06 04:01:15 --> Database Driver Class Initialized
INFO - 2024-12-06 04:01:15 --> Loader Class Initialized
INFO - 2024-12-06 04:01:15 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:15 --> Helper loaded: form_helper
DEBUG - 2024-12-06 04:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:15 --> Database Driver Class Initialized
INFO - 2024-12-06 04:01:15 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:15 --> Controller Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-12-06 04:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:15 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 04:01:15 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:15 --> Total execution time: 0.0768
INFO - 2024-12-06 04:01:15 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:15 --> Controller Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 04:01:15 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:15 --> Total execution time: 0.0712
INFO - 2024-12-06 04:01:15 --> Config Class Initialized
INFO - 2024-12-06 04:01:15 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:15 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:15 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:15 --> URI Class Initialized
INFO - 2024-12-06 04:01:15 --> Router Class Initialized
INFO - 2024-12-06 04:01:15 --> Output Class Initialized
INFO - 2024-12-06 04:01:15 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:15 --> CSRF cookie sent
INFO - 2024-12-06 04:01:15 --> Input Class Initialized
INFO - 2024-12-06 04:01:15 --> Language Class Initialized
INFO - 2024-12-06 04:01:15 --> Loader Class Initialized
INFO - 2024-12-06 04:01:15 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:15 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:15 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:15 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:15 --> Controller Class Initialized
INFO - 2024-12-06 04:01:15 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 04:01:15 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:15 --> Total execution time: 0.0690
INFO - 2024-12-06 04:01:16 --> Config Class Initialized
INFO - 2024-12-06 04:01:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:16 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:16 --> URI Class Initialized
INFO - 2024-12-06 04:01:16 --> Router Class Initialized
INFO - 2024-12-06 04:01:16 --> Output Class Initialized
INFO - 2024-12-06 04:01:16 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:16 --> CSRF cookie sent
INFO - 2024-12-06 04:01:16 --> Input Class Initialized
INFO - 2024-12-06 04:01:16 --> Language Class Initialized
INFO - 2024-12-06 04:01:16 --> Loader Class Initialized
INFO - 2024-12-06 04:01:16 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:16 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:17 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:17 --> Controller Class Initialized
INFO - 2024-12-06 04:01:17 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:17 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:17 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:17 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 04:01:17 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:17 --> Total execution time: 0.0648
INFO - 2024-12-06 04:01:23 --> Config Class Initialized
INFO - 2024-12-06 04:01:23 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:23 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:23 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:23 --> URI Class Initialized
INFO - 2024-12-06 04:01:23 --> Router Class Initialized
INFO - 2024-12-06 04:01:23 --> Output Class Initialized
INFO - 2024-12-06 04:01:23 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:23 --> CSRF cookie sent
INFO - 2024-12-06 04:01:23 --> CSRF token verified
INFO - 2024-12-06 04:01:23 --> Input Class Initialized
INFO - 2024-12-06 04:01:23 --> Language Class Initialized
INFO - 2024-12-06 04:01:23 --> Loader Class Initialized
INFO - 2024-12-06 04:01:23 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:23 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:23 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:23 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:23 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:23 --> Controller Class Initialized
INFO - 2024-12-06 04:01:23 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:23 --> Config Class Initialized
INFO - 2024-12-06 04:01:23 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:23 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:23 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:23 --> URI Class Initialized
INFO - 2024-12-06 04:01:23 --> Router Class Initialized
INFO - 2024-12-06 04:01:23 --> Output Class Initialized
INFO - 2024-12-06 04:01:23 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:23 --> CSRF cookie sent
INFO - 2024-12-06 04:01:23 --> Input Class Initialized
INFO - 2024-12-06 04:01:23 --> Language Class Initialized
INFO - 2024-12-06 04:01:23 --> Loader Class Initialized
INFO - 2024-12-06 04:01:23 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:23 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:23 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:23 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:23 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:23 --> Controller Class Initialized
INFO - 2024-12-06 04:01:23 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:01:23 --> Query result: stdClass Object
(
    [view_count] => 93
)

INFO - 2024-12-06 04:01:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 04:01:23 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:23 --> Total execution time: 0.0701
INFO - 2024-12-06 04:01:24 --> Config Class Initialized
INFO - 2024-12-06 04:01:24 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:24 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:24 --> URI Class Initialized
INFO - 2024-12-06 04:01:24 --> Router Class Initialized
INFO - 2024-12-06 04:01:24 --> Output Class Initialized
INFO - 2024-12-06 04:01:24 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:24 --> CSRF cookie sent
INFO - 2024-12-06 04:01:24 --> Input Class Initialized
INFO - 2024-12-06 04:01:24 --> Language Class Initialized
ERROR - 2024-12-06 04:01:24 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 04:01:39 --> Config Class Initialized
INFO - 2024-12-06 04:01:39 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:39 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:39 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:39 --> URI Class Initialized
INFO - 2024-12-06 04:01:39 --> Router Class Initialized
INFO - 2024-12-06 04:01:39 --> Output Class Initialized
INFO - 2024-12-06 04:01:39 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:39 --> CSRF cookie sent
INFO - 2024-12-06 04:01:39 --> Input Class Initialized
INFO - 2024-12-06 04:01:39 --> Language Class Initialized
INFO - 2024-12-06 04:01:39 --> Loader Class Initialized
INFO - 2024-12-06 04:01:39 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:39 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:39 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:39 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:39 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:39 --> Controller Class Initialized
INFO - 2024-12-06 04:01:39 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:39 --> Config Class Initialized
INFO - 2024-12-06 04:01:39 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:39 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:39 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:39 --> URI Class Initialized
INFO - 2024-12-06 04:01:39 --> Router Class Initialized
INFO - 2024-12-06 04:01:39 --> Output Class Initialized
INFO - 2024-12-06 04:01:39 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:39 --> CSRF cookie sent
INFO - 2024-12-06 04:01:39 --> Input Class Initialized
INFO - 2024-12-06 04:01:39 --> Language Class Initialized
INFO - 2024-12-06 04:01:39 --> Loader Class Initialized
INFO - 2024-12-06 04:01:39 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:39 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:39 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:39 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:39 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:39 --> Controller Class Initialized
INFO - 2024-12-06 04:01:39 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:01:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/login.php
INFO - 2024-12-06 04:01:39 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:39 --> Total execution time: 0.0564
INFO - 2024-12-06 04:01:44 --> Config Class Initialized
INFO - 2024-12-06 04:01:44 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:44 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:44 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:44 --> URI Class Initialized
INFO - 2024-12-06 04:01:44 --> Router Class Initialized
INFO - 2024-12-06 04:01:44 --> Output Class Initialized
INFO - 2024-12-06 04:01:44 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:44 --> CSRF cookie sent
INFO - 2024-12-06 04:01:44 --> CSRF token verified
INFO - 2024-12-06 04:01:44 --> Input Class Initialized
INFO - 2024-12-06 04:01:44 --> Language Class Initialized
INFO - 2024-12-06 04:01:44 --> Loader Class Initialized
INFO - 2024-12-06 04:01:44 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:44 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:44 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:44 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:44 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:44 --> Controller Class Initialized
INFO - 2024-12-06 04:01:44 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:44 --> Config Class Initialized
INFO - 2024-12-06 04:01:44 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:44 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:44 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:44 --> URI Class Initialized
INFO - 2024-12-06 04:01:44 --> Router Class Initialized
INFO - 2024-12-06 04:01:44 --> Output Class Initialized
INFO - 2024-12-06 04:01:44 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:44 --> CSRF cookie sent
INFO - 2024-12-06 04:01:44 --> Input Class Initialized
INFO - 2024-12-06 04:01:44 --> Language Class Initialized
INFO - 2024-12-06 04:01:44 --> Loader Class Initialized
INFO - 2024-12-06 04:01:44 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:44 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:44 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:44 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:44 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:44 --> Controller Class Initialized
INFO - 2024-12-06 04:01:44 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:01:44 --> Query result: stdClass Object
(
    [view_count] => 94
)

INFO - 2024-12-06 04:01:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 04:01:44 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:44 --> Total execution time: 0.0579
INFO - 2024-12-06 04:01:44 --> Config Class Initialized
INFO - 2024-12-06 04:01:44 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:44 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:44 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:44 --> URI Class Initialized
INFO - 2024-12-06 04:01:44 --> Router Class Initialized
INFO - 2024-12-06 04:01:44 --> Output Class Initialized
INFO - 2024-12-06 04:01:44 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:44 --> CSRF cookie sent
INFO - 2024-12-06 04:01:44 --> Input Class Initialized
INFO - 2024-12-06 04:01:44 --> Language Class Initialized
ERROR - 2024-12-06 04:01:44 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 04:01:47 --> Config Class Initialized
INFO - 2024-12-06 04:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:47 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:47 --> URI Class Initialized
INFO - 2024-12-06 04:01:47 --> Router Class Initialized
INFO - 2024-12-06 04:01:47 --> Output Class Initialized
INFO - 2024-12-06 04:01:47 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:47 --> CSRF cookie sent
INFO - 2024-12-06 04:01:47 --> Input Class Initialized
INFO - 2024-12-06 04:01:47 --> Language Class Initialized
INFO - 2024-12-06 04:01:47 --> Loader Class Initialized
INFO - 2024-12-06 04:01:47 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:47 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:47 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:47 --> Controller Class Initialized
INFO - 2024-12-06 04:01:47 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:47 --> Config Class Initialized
INFO - 2024-12-06 04:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:47 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:47 --> URI Class Initialized
INFO - 2024-12-06 04:01:47 --> Router Class Initialized
INFO - 2024-12-06 04:01:47 --> Output Class Initialized
INFO - 2024-12-06 04:01:47 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:47 --> CSRF cookie sent
INFO - 2024-12-06 04:01:47 --> Input Class Initialized
INFO - 2024-12-06 04:01:47 --> Language Class Initialized
INFO - 2024-12-06 04:01:47 --> Loader Class Initialized
INFO - 2024-12-06 04:01:47 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:47 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:47 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:47 --> Controller Class Initialized
INFO - 2024-12-06 04:01:47 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:01:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 04:01:47 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:47 --> Total execution time: 0.0725
INFO - 2024-12-06 04:01:51 --> Config Class Initialized
INFO - 2024-12-06 04:01:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:51 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:51 --> URI Class Initialized
INFO - 2024-12-06 04:01:51 --> Router Class Initialized
INFO - 2024-12-06 04:01:51 --> Output Class Initialized
INFO - 2024-12-06 04:01:51 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:51 --> CSRF cookie sent
INFO - 2024-12-06 04:01:51 --> CSRF token verified
INFO - 2024-12-06 04:01:51 --> Input Class Initialized
INFO - 2024-12-06 04:01:51 --> Language Class Initialized
INFO - 2024-12-06 04:01:51 --> Loader Class Initialized
INFO - 2024-12-06 04:01:51 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:51 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:51 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:51 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:51 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:51 --> Controller Class Initialized
INFO - 2024-12-06 04:01:51 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "News_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:51 --> Config Class Initialized
INFO - 2024-12-06 04:01:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:51 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:51 --> URI Class Initialized
INFO - 2024-12-06 04:01:51 --> Router Class Initialized
INFO - 2024-12-06 04:01:51 --> Output Class Initialized
INFO - 2024-12-06 04:01:51 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:51 --> CSRF cookie sent
INFO - 2024-12-06 04:01:51 --> Input Class Initialized
INFO - 2024-12-06 04:01:51 --> Language Class Initialized
INFO - 2024-12-06 04:01:51 --> Loader Class Initialized
INFO - 2024-12-06 04:01:51 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:51 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:51 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:51 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:51 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:51 --> Controller Class Initialized
INFO - 2024-12-06 04:01:51 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:01:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:01:51 --> Query result: stdClass Object
(
    [view_count] => 94
)

INFO - 2024-12-06 04:01:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 04:01:51 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:51 --> Total execution time: 0.0928
INFO - 2024-12-06 04:01:56 --> Config Class Initialized
INFO - 2024-12-06 04:01:56 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:01:56 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:01:56 --> Utf8 Class Initialized
INFO - 2024-12-06 04:01:56 --> URI Class Initialized
INFO - 2024-12-06 04:01:56 --> Router Class Initialized
INFO - 2024-12-06 04:01:56 --> Output Class Initialized
INFO - 2024-12-06 04:01:56 --> Security Class Initialized
DEBUG - 2024-12-06 04:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:01:56 --> CSRF cookie sent
INFO - 2024-12-06 04:01:56 --> Input Class Initialized
INFO - 2024-12-06 04:01:56 --> Language Class Initialized
INFO - 2024-12-06 04:01:56 --> Loader Class Initialized
INFO - 2024-12-06 04:01:56 --> Helper loaded: url_helper
INFO - 2024-12-06 04:01:56 --> Helper loaded: form_helper
INFO - 2024-12-06 04:01:56 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:01:56 --> Form Validation Class Initialized
INFO - 2024-12-06 04:01:56 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:01:56 --> Controller Class Initialized
INFO - 2024-12-06 04:01:56 --> Model "Review_model" initialized
INFO - 2024-12-06 04:01:56 --> Model "Category_model" initialized
INFO - 2024-12-06 04:01:56 --> Model "User_model" initialized
INFO - 2024-12-06 04:01:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:01:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:01:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 04:01:56 --> Final output sent to browser
DEBUG - 2024-12-06 04:01:56 --> Total execution time: 0.0789
INFO - 2024-12-06 04:47:41 --> Config Class Initialized
INFO - 2024-12-06 04:47:42 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:47:42 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:47:42 --> Utf8 Class Initialized
INFO - 2024-12-06 04:47:42 --> URI Class Initialized
INFO - 2024-12-06 04:47:42 --> Router Class Initialized
INFO - 2024-12-06 04:47:43 --> Output Class Initialized
INFO - 2024-12-06 04:47:43 --> Security Class Initialized
DEBUG - 2024-12-06 04:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:47:43 --> CSRF cookie sent
INFO - 2024-12-06 04:47:43 --> Input Class Initialized
INFO - 2024-12-06 04:47:43 --> Language Class Initialized
INFO - 2024-12-06 04:47:43 --> Loader Class Initialized
INFO - 2024-12-06 04:47:44 --> Helper loaded: url_helper
INFO - 2024-12-06 04:47:44 --> Helper loaded: form_helper
INFO - 2024-12-06 04:47:44 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:47:44 --> Form Validation Class Initialized
INFO - 2024-12-06 04:47:44 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:47:44 --> Controller Class Initialized
INFO - 2024-12-06 04:47:44 --> Model "Review_model" initialized
INFO - 2024-12-06 04:47:44 --> Model "Category_model" initialized
INFO - 2024-12-06 04:47:44 --> Model "User_model" initialized
INFO - 2024-12-06 04:47:44 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:47:44 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:47:44 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 04:47:44 --> Final output sent to browser
DEBUG - 2024-12-06 04:47:44 --> Total execution time: 3.4357
INFO - 2024-12-06 04:47:57 --> Config Class Initialized
INFO - 2024-12-06 04:47:57 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:47:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:47:59 --> Utf8 Class Initialized
INFO - 2024-12-06 04:47:59 --> URI Class Initialized
INFO - 2024-12-06 04:48:01 --> Router Class Initialized
INFO - 2024-12-06 04:48:02 --> Output Class Initialized
INFO - 2024-12-06 04:48:04 --> Security Class Initialized
DEBUG - 2024-12-06 04:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:48:06 --> CSRF cookie sent
INFO - 2024-12-06 04:48:06 --> Input Class Initialized
INFO - 2024-12-06 04:48:08 --> Language Class Initialized
INFO - 2024-12-06 04:48:13 --> Loader Class Initialized
INFO - 2024-12-06 04:48:19 --> Helper loaded: url_helper
INFO - 2024-12-06 04:48:21 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:06 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:06 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:06 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:06 --> Controller Class Initialized
INFO - 2024-12-06 04:49:06 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:06 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:06 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:06 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:49:06 --> Query result: stdClass Object
(
    [view_count] => 94
)

INFO - 2024-12-06 04:49:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 04:49:06 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:06 --> Total execution time: 69.8704
INFO - 2024-12-06 04:49:34 --> Config Class Initialized
INFO - 2024-12-06 04:49:34 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:34 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:34 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:34 --> URI Class Initialized
INFO - 2024-12-06 04:49:34 --> Router Class Initialized
INFO - 2024-12-06 04:49:34 --> Output Class Initialized
INFO - 2024-12-06 04:49:34 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:34 --> CSRF cookie sent
INFO - 2024-12-06 04:49:34 --> Input Class Initialized
INFO - 2024-12-06 04:49:34 --> Language Class Initialized
INFO - 2024-12-06 04:49:34 --> Loader Class Initialized
INFO - 2024-12-06 04:49:34 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:34 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:34 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:34 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:34 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:34 --> Controller Class Initialized
INFO - 2024-12-06 04:49:34 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:34 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:34 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:34 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:34 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:34 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 04:49:34 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:34 --> Total execution time: 0.1164
INFO - 2024-12-06 04:49:36 --> Config Class Initialized
INFO - 2024-12-06 04:49:36 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:36 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:36 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:36 --> URI Class Initialized
INFO - 2024-12-06 04:49:36 --> Router Class Initialized
INFO - 2024-12-06 04:49:36 --> Output Class Initialized
INFO - 2024-12-06 04:49:36 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:36 --> CSRF cookie sent
INFO - 2024-12-06 04:49:36 --> Input Class Initialized
INFO - 2024-12-06 04:49:36 --> Language Class Initialized
INFO - 2024-12-06 04:49:36 --> Loader Class Initialized
INFO - 2024-12-06 04:49:36 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:36 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:36 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:36 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:36 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:36 --> Controller Class Initialized
INFO - 2024-12-06 04:49:36 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:36 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:36 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:36 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 04:49:36 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:36 --> Total execution time: 0.0570
INFO - 2024-12-06 04:49:37 --> Config Class Initialized
INFO - 2024-12-06 04:49:37 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:37 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:37 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:37 --> URI Class Initialized
INFO - 2024-12-06 04:49:37 --> Router Class Initialized
INFO - 2024-12-06 04:49:37 --> Output Class Initialized
INFO - 2024-12-06 04:49:37 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:37 --> CSRF cookie sent
INFO - 2024-12-06 04:49:37 --> Input Class Initialized
INFO - 2024-12-06 04:49:37 --> Language Class Initialized
INFO - 2024-12-06 04:49:37 --> Loader Class Initialized
INFO - 2024-12-06 04:49:37 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:37 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:37 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:37 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:37 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:37 --> Controller Class Initialized
INFO - 2024-12-06 04:49:37 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:37 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:37 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:37 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:37 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:37 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 04:49:37 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:37 --> Total execution time: 0.0776
INFO - 2024-12-06 04:49:39 --> Config Class Initialized
INFO - 2024-12-06 04:49:39 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:39 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:39 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:39 --> URI Class Initialized
INFO - 2024-12-06 04:49:39 --> Router Class Initialized
INFO - 2024-12-06 04:49:39 --> Output Class Initialized
INFO - 2024-12-06 04:49:39 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:39 --> CSRF cookie sent
INFO - 2024-12-06 04:49:39 --> Input Class Initialized
INFO - 2024-12-06 04:49:39 --> Language Class Initialized
INFO - 2024-12-06 04:49:39 --> Loader Class Initialized
INFO - 2024-12-06 04:49:39 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:39 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:39 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:39 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:39 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:39 --> Controller Class Initialized
INFO - 2024-12-06 04:49:39 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:39 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:39 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:40 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 04:49:40 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:40 --> Total execution time: 0.0558
INFO - 2024-12-06 04:49:41 --> Config Class Initialized
INFO - 2024-12-06 04:49:41 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:41 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:41 --> URI Class Initialized
INFO - 2024-12-06 04:49:41 --> Router Class Initialized
INFO - 2024-12-06 04:49:41 --> Output Class Initialized
INFO - 2024-12-06 04:49:41 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:41 --> CSRF cookie sent
INFO - 2024-12-06 04:49:41 --> Input Class Initialized
INFO - 2024-12-06 04:49:41 --> Language Class Initialized
INFO - 2024-12-06 04:49:41 --> Loader Class Initialized
INFO - 2024-12-06 04:49:41 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:41 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:41 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:41 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:41 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:41 --> Controller Class Initialized
INFO - 2024-12-06 04:49:41 --> Model "News_model" initialized
INFO - 2024-12-06 04:49:41 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 04:49:41 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:41 --> Total execution time: 0.0511
INFO - 2024-12-06 04:49:49 --> Config Class Initialized
INFO - 2024-12-06 04:49:49 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:49 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:49 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:49 --> URI Class Initialized
INFO - 2024-12-06 04:49:49 --> Router Class Initialized
INFO - 2024-12-06 04:49:49 --> Output Class Initialized
INFO - 2024-12-06 04:49:49 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:49 --> CSRF cookie sent
INFO - 2024-12-06 04:49:49 --> Input Class Initialized
INFO - 2024-12-06 04:49:49 --> Language Class Initialized
INFO - 2024-12-06 04:49:49 --> Loader Class Initialized
INFO - 2024-12-06 04:49:49 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:49 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:49 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:49 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:49 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:49 --> Controller Class Initialized
INFO - 2024-12-06 04:49:49 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:49 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:49 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:49 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:49 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 04:49:49 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:49 --> Total execution time: 0.0617
INFO - 2024-12-06 04:49:53 --> Config Class Initialized
INFO - 2024-12-06 04:49:53 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:53 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:53 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:53 --> URI Class Initialized
INFO - 2024-12-06 04:49:53 --> Router Class Initialized
INFO - 2024-12-06 04:49:53 --> Output Class Initialized
INFO - 2024-12-06 04:49:53 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:53 --> CSRF cookie sent
INFO - 2024-12-06 04:49:53 --> Input Class Initialized
INFO - 2024-12-06 04:49:53 --> Language Class Initialized
INFO - 2024-12-06 04:49:53 --> Loader Class Initialized
INFO - 2024-12-06 04:49:53 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:53 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:53 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:53 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:53 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:53 --> Controller Class Initialized
INFO - 2024-12-06 04:49:53 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:53 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:53 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:53 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:53 --> Model "Contact_model" initialized
INFO - 2024-12-06 04:49:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-06 04:49:53 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:53 --> Total execution time: 0.0596
INFO - 2024-12-06 04:49:54 --> Config Class Initialized
INFO - 2024-12-06 04:49:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:54 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:54 --> URI Class Initialized
INFO - 2024-12-06 04:49:54 --> Router Class Initialized
INFO - 2024-12-06 04:49:54 --> Output Class Initialized
INFO - 2024-12-06 04:49:54 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:54 --> CSRF cookie sent
INFO - 2024-12-06 04:49:54 --> Input Class Initialized
INFO - 2024-12-06 04:49:54 --> Language Class Initialized
INFO - 2024-12-06 04:49:54 --> Loader Class Initialized
INFO - 2024-12-06 04:49:54 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:54 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:54 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:54 --> Controller Class Initialized
INFO - 2024-12-06 04:49:54 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:54 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:54 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:54 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 04:49:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:49:54 --> Query result: stdClass Object
(
    [view_count] => 94
)

INFO - 2024-12-06 04:49:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 04:49:54 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:54 --> Total execution time: 0.0592
INFO - 2024-12-06 04:49:57 --> Config Class Initialized
INFO - 2024-12-06 04:49:57 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:49:57 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:49:57 --> Utf8 Class Initialized
INFO - 2024-12-06 04:49:57 --> URI Class Initialized
INFO - 2024-12-06 04:49:57 --> Router Class Initialized
INFO - 2024-12-06 04:49:57 --> Output Class Initialized
INFO - 2024-12-06 04:49:57 --> Security Class Initialized
DEBUG - 2024-12-06 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:49:57 --> CSRF cookie sent
INFO - 2024-12-06 04:49:57 --> Input Class Initialized
INFO - 2024-12-06 04:49:57 --> Language Class Initialized
INFO - 2024-12-06 04:49:57 --> Loader Class Initialized
INFO - 2024-12-06 04:49:58 --> Helper loaded: url_helper
INFO - 2024-12-06 04:49:58 --> Helper loaded: form_helper
INFO - 2024-12-06 04:49:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:49:58 --> Form Validation Class Initialized
INFO - 2024-12-06 04:49:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:49:58 --> Controller Class Initialized
INFO - 2024-12-06 04:49:58 --> Model "User_model" initialized
INFO - 2024-12-06 04:49:58 --> Model "Category_model" initialized
INFO - 2024-12-06 04:49:58 --> Model "Review_model" initialized
INFO - 2024-12-06 04:49:58 --> Model "News_model" initialized
INFO - 2024-12-06 04:49:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:49:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:49:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:49:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-06 04:49:58 --> Final output sent to browser
DEBUG - 2024-12-06 04:49:58 --> Total execution time: 0.3546
INFO - 2024-12-06 04:50:00 --> Config Class Initialized
INFO - 2024-12-06 04:50:00 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:50:00 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:50:00 --> Utf8 Class Initialized
INFO - 2024-12-06 04:50:00 --> URI Class Initialized
INFO - 2024-12-06 04:50:00 --> Router Class Initialized
INFO - 2024-12-06 04:50:00 --> Output Class Initialized
INFO - 2024-12-06 04:50:00 --> Security Class Initialized
DEBUG - 2024-12-06 04:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:50:00 --> CSRF cookie sent
INFO - 2024-12-06 04:50:00 --> Input Class Initialized
INFO - 2024-12-06 04:50:00 --> Language Class Initialized
INFO - 2024-12-06 04:50:00 --> Loader Class Initialized
INFO - 2024-12-06 04:50:00 --> Helper loaded: url_helper
INFO - 2024-12-06 04:50:00 --> Helper loaded: form_helper
INFO - 2024-12-06 04:50:00 --> Database Driver Class Initialized
DEBUG - 2024-12-06 04:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:50:00 --> Form Validation Class Initialized
INFO - 2024-12-06 04:50:00 --> Model "Culinary_model" initialized
INFO - 2024-12-06 04:50:00 --> Controller Class Initialized
INFO - 2024-12-06 04:50:00 --> Model "User_model" initialized
INFO - 2024-12-06 04:50:00 --> Model "Category_model" initialized
INFO - 2024-12-06 04:50:00 --> Model "Review_model" initialized
INFO - 2024-12-06 04:50:00 --> Model "News_model" initialized
INFO - 2024-12-06 04:50:00 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 04:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 04:50:00 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 04:50:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 04:50:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 04:50:00 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 04:50:00 --> Final output sent to browser
DEBUG - 2024-12-06 04:50:00 --> Total execution time: 0.1391
INFO - 2024-12-06 04:50:00 --> Config Class Initialized
INFO - 2024-12-06 04:50:00 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:50:00 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:50:00 --> Utf8 Class Initialized
INFO - 2024-12-06 04:50:00 --> URI Class Initialized
INFO - 2024-12-06 04:50:00 --> Router Class Initialized
INFO - 2024-12-06 04:50:00 --> Output Class Initialized
INFO - 2024-12-06 04:50:00 --> Security Class Initialized
DEBUG - 2024-12-06 04:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:50:00 --> CSRF cookie sent
INFO - 2024-12-06 04:50:00 --> Input Class Initialized
INFO - 2024-12-06 04:50:00 --> Language Class Initialized
ERROR - 2024-12-06 04:50:00 --> 404 Page Not Found: Path-to-your-imagejpg/index
INFO - 2024-12-06 09:59:29 --> Config Class Initialized
INFO - 2024-12-06 09:59:29 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:59:29 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:59:29 --> Utf8 Class Initialized
INFO - 2024-12-06 09:59:29 --> URI Class Initialized
INFO - 2024-12-06 09:59:29 --> Router Class Initialized
INFO - 2024-12-06 09:59:29 --> Output Class Initialized
INFO - 2024-12-06 09:59:29 --> Security Class Initialized
DEBUG - 2024-12-06 09:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:59:29 --> CSRF cookie sent
INFO - 2024-12-06 09:59:29 --> Input Class Initialized
INFO - 2024-12-06 09:59:29 --> Language Class Initialized
INFO - 2024-12-06 09:59:29 --> Loader Class Initialized
INFO - 2024-12-06 09:59:29 --> Helper loaded: url_helper
INFO - 2024-12-06 09:59:29 --> Helper loaded: form_helper
INFO - 2024-12-06 09:59:29 --> Database Driver Class Initialized
DEBUG - 2024-12-06 09:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:59:29 --> Form Validation Class Initialized
INFO - 2024-12-06 09:59:29 --> Model "Culinary_model" initialized
INFO - 2024-12-06 09:59:29 --> Controller Class Initialized
INFO - 2024-12-06 09:59:29 --> Model "User_model" initialized
INFO - 2024-12-06 09:59:29 --> Model "Category_model" initialized
INFO - 2024-12-06 09:59:29 --> Model "Review_model" initialized
INFO - 2024-12-06 09:59:29 --> Model "News_model" initialized
INFO - 2024-12-06 09:59:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 09:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 09:59:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 09:59:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 09:59:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/culinary_detail.php
INFO - 2024-12-06 09:59:29 --> Final output sent to browser
DEBUG - 2024-12-06 09:59:29 --> Total execution time: 0.4534
INFO - 2024-12-06 09:59:42 --> Config Class Initialized
INFO - 2024-12-06 09:59:42 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:59:42 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:59:42 --> Utf8 Class Initialized
INFO - 2024-12-06 09:59:42 --> URI Class Initialized
INFO - 2024-12-06 09:59:42 --> Router Class Initialized
INFO - 2024-12-06 09:59:42 --> Output Class Initialized
INFO - 2024-12-06 09:59:42 --> Security Class Initialized
DEBUG - 2024-12-06 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:59:42 --> CSRF cookie sent
INFO - 2024-12-06 09:59:42 --> Input Class Initialized
INFO - 2024-12-06 09:59:42 --> Language Class Initialized
INFO - 2024-12-06 09:59:42 --> Loader Class Initialized
INFO - 2024-12-06 09:59:42 --> Helper loaded: url_helper
INFO - 2024-12-06 09:59:42 --> Helper loaded: form_helper
INFO - 2024-12-06 09:59:42 --> Database Driver Class Initialized
DEBUG - 2024-12-06 09:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:59:42 --> Form Validation Class Initialized
INFO - 2024-12-06 09:59:42 --> Model "Culinary_model" initialized
INFO - 2024-12-06 09:59:42 --> Controller Class Initialized
INFO - 2024-12-06 09:59:42 --> Model "User_model" initialized
INFO - 2024-12-06 09:59:42 --> Model "Category_model" initialized
INFO - 2024-12-06 09:59:42 --> Model "Review_model" initialized
INFO - 2024-12-06 09:59:42 --> Model "News_model" initialized
INFO - 2024-12-06 09:59:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 09:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 09:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 09:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 09:59:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/contact.php
INFO - 2024-12-06 09:59:42 --> Final output sent to browser
DEBUG - 2024-12-06 09:59:42 --> Total execution time: 0.0775
INFO - 2024-12-06 09:59:51 --> Config Class Initialized
INFO - 2024-12-06 09:59:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:59:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:59:51 --> Utf8 Class Initialized
INFO - 2024-12-06 09:59:51 --> URI Class Initialized
INFO - 2024-12-06 09:59:51 --> Router Class Initialized
INFO - 2024-12-06 09:59:51 --> Output Class Initialized
INFO - 2024-12-06 09:59:51 --> Security Class Initialized
DEBUG - 2024-12-06 09:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:59:51 --> CSRF cookie sent
INFO - 2024-12-06 09:59:51 --> Input Class Initialized
INFO - 2024-12-06 09:59:51 --> Language Class Initialized
INFO - 2024-12-06 09:59:51 --> Loader Class Initialized
INFO - 2024-12-06 09:59:51 --> Helper loaded: url_helper
INFO - 2024-12-06 09:59:51 --> Helper loaded: form_helper
INFO - 2024-12-06 09:59:51 --> Database Driver Class Initialized
DEBUG - 2024-12-06 09:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:59:51 --> Form Validation Class Initialized
INFO - 2024-12-06 09:59:51 --> Model "Culinary_model" initialized
INFO - 2024-12-06 09:59:51 --> Controller Class Initialized
INFO - 2024-12-06 09:59:51 --> Model "User_model" initialized
INFO - 2024-12-06 09:59:51 --> Model "Category_model" initialized
INFO - 2024-12-06 09:59:51 --> Model "Review_model" initialized
INFO - 2024-12-06 09:59:51 --> Model "News_model" initialized
INFO - 2024-12-06 09:59:51 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 09:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 09:59:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 09:59:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 09:59:51 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/search_results.php
INFO - 2024-12-06 09:59:51 --> Final output sent to browser
DEBUG - 2024-12-06 09:59:51 --> Total execution time: 0.2199
INFO - 2024-12-06 09:59:54 --> Config Class Initialized
INFO - 2024-12-06 09:59:54 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:59:54 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:59:54 --> Utf8 Class Initialized
INFO - 2024-12-06 09:59:54 --> URI Class Initialized
INFO - 2024-12-06 09:59:54 --> Router Class Initialized
INFO - 2024-12-06 09:59:54 --> Output Class Initialized
INFO - 2024-12-06 09:59:54 --> Security Class Initialized
DEBUG - 2024-12-06 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:59:54 --> CSRF cookie sent
INFO - 2024-12-06 09:59:54 --> Input Class Initialized
INFO - 2024-12-06 09:59:54 --> Language Class Initialized
INFO - 2024-12-06 09:59:54 --> Loader Class Initialized
INFO - 2024-12-06 09:59:54 --> Helper loaded: url_helper
INFO - 2024-12-06 09:59:54 --> Helper loaded: form_helper
INFO - 2024-12-06 09:59:54 --> Database Driver Class Initialized
DEBUG - 2024-12-06 09:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:59:54 --> Form Validation Class Initialized
INFO - 2024-12-06 09:59:54 --> Model "Culinary_model" initialized
INFO - 2024-12-06 09:59:54 --> Controller Class Initialized
INFO - 2024-12-06 09:59:54 --> Model "User_model" initialized
INFO - 2024-12-06 09:59:54 --> Model "Category_model" initialized
INFO - 2024-12-06 09:59:54 --> Model "Review_model" initialized
INFO - 2024-12-06 09:59:54 --> Model "News_model" initialized
INFO - 2024-12-06 09:59:54 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 09:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 09:59:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 09:59:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 09:59:54 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 09:59:54 --> Final output sent to browser
DEBUG - 2024-12-06 09:59:54 --> Total execution time: 0.0703
INFO - 2024-12-06 09:59:58 --> Config Class Initialized
INFO - 2024-12-06 09:59:58 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:59:58 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:59:58 --> Utf8 Class Initialized
INFO - 2024-12-06 09:59:58 --> URI Class Initialized
INFO - 2024-12-06 09:59:58 --> Router Class Initialized
INFO - 2024-12-06 09:59:58 --> Output Class Initialized
INFO - 2024-12-06 09:59:58 --> Security Class Initialized
DEBUG - 2024-12-06 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:59:58 --> CSRF cookie sent
INFO - 2024-12-06 09:59:58 --> CSRF token verified
INFO - 2024-12-06 09:59:58 --> Input Class Initialized
INFO - 2024-12-06 09:59:58 --> Language Class Initialized
INFO - 2024-12-06 09:59:58 --> Loader Class Initialized
INFO - 2024-12-06 09:59:58 --> Helper loaded: url_helper
INFO - 2024-12-06 09:59:58 --> Helper loaded: form_helper
INFO - 2024-12-06 09:59:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:59:58 --> Form Validation Class Initialized
INFO - 2024-12-06 09:59:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 09:59:58 --> Controller Class Initialized
INFO - 2024-12-06 09:59:58 --> Model "User_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "Category_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "Review_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "News_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 09:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 09:59:58 --> Config Class Initialized
INFO - 2024-12-06 09:59:58 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:59:58 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:59:58 --> Utf8 Class Initialized
INFO - 2024-12-06 09:59:58 --> URI Class Initialized
INFO - 2024-12-06 09:59:58 --> Router Class Initialized
INFO - 2024-12-06 09:59:58 --> Output Class Initialized
INFO - 2024-12-06 09:59:58 --> Security Class Initialized
DEBUG - 2024-12-06 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:59:58 --> CSRF cookie sent
INFO - 2024-12-06 09:59:58 --> Input Class Initialized
INFO - 2024-12-06 09:59:58 --> Language Class Initialized
INFO - 2024-12-06 09:59:58 --> Loader Class Initialized
INFO - 2024-12-06 09:59:58 --> Helper loaded: url_helper
INFO - 2024-12-06 09:59:58 --> Helper loaded: form_helper
INFO - 2024-12-06 09:59:58 --> Database Driver Class Initialized
DEBUG - 2024-12-06 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:59:58 --> Form Validation Class Initialized
INFO - 2024-12-06 09:59:58 --> Model "Culinary_model" initialized
INFO - 2024-12-06 09:59:58 --> Controller Class Initialized
INFO - 2024-12-06 09:59:58 --> Model "Review_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "Category_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "User_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 09:59:58 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 09:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 09:59:58 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 09:59:58 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 09:59:58 --> Final output sent to browser
DEBUG - 2024-12-06 09:59:58 --> Total execution time: 0.1080
INFO - 2024-12-06 10:00:01 --> Config Class Initialized
INFO - 2024-12-06 10:00:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:01 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:01 --> URI Class Initialized
INFO - 2024-12-06 10:00:01 --> Router Class Initialized
INFO - 2024-12-06 10:00:01 --> Output Class Initialized
INFO - 2024-12-06 10:00:01 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:01 --> CSRF cookie sent
INFO - 2024-12-06 10:00:01 --> Input Class Initialized
INFO - 2024-12-06 10:00:01 --> Language Class Initialized
INFO - 2024-12-06 10:00:01 --> Loader Class Initialized
INFO - 2024-12-06 10:00:01 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:01 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:01 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:01 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:01 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:01 --> Controller Class Initialized
INFO - 2024-12-06 10:00:01 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:01 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:01 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 10:00:01 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:01 --> Total execution time: 0.0676
INFO - 2024-12-06 10:00:03 --> Config Class Initialized
INFO - 2024-12-06 10:00:03 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:03 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:03 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:03 --> URI Class Initialized
INFO - 2024-12-06 10:00:03 --> Router Class Initialized
INFO - 2024-12-06 10:00:03 --> Output Class Initialized
INFO - 2024-12-06 10:00:03 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:03 --> CSRF cookie sent
INFO - 2024-12-06 10:00:03 --> Input Class Initialized
INFO - 2024-12-06 10:00:03 --> Language Class Initialized
INFO - 2024-12-06 10:00:03 --> Loader Class Initialized
INFO - 2024-12-06 10:00:03 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:03 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:03 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:03 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:03 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:03 --> Controller Class Initialized
INFO - 2024-12-06 10:00:03 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:03 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:03 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:03 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:03 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:03 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:00:03 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:03 --> Total execution time: 0.0661
INFO - 2024-12-06 10:00:05 --> Config Class Initialized
INFO - 2024-12-06 10:00:05 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:05 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:05 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:05 --> URI Class Initialized
INFO - 2024-12-06 10:00:05 --> Router Class Initialized
INFO - 2024-12-06 10:00:05 --> Output Class Initialized
INFO - 2024-12-06 10:00:05 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:05 --> CSRF cookie sent
INFO - 2024-12-06 10:00:05 --> Input Class Initialized
INFO - 2024-12-06 10:00:05 --> Language Class Initialized
INFO - 2024-12-06 10:00:05 --> Loader Class Initialized
INFO - 2024-12-06 10:00:05 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:05 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:05 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:05 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:05 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:05 --> Controller Class Initialized
INFO - 2024-12-06 10:00:05 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:05 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:05 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:05 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:05 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:05 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:05 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:05 --> Total execution time: 0.0650
INFO - 2024-12-06 10:00:09 --> Config Class Initialized
INFO - 2024-12-06 10:00:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:09 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:09 --> URI Class Initialized
INFO - 2024-12-06 10:00:09 --> Router Class Initialized
INFO - 2024-12-06 10:00:09 --> Output Class Initialized
INFO - 2024-12-06 10:00:09 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:09 --> CSRF cookie sent
INFO - 2024-12-06 10:00:09 --> Input Class Initialized
INFO - 2024-12-06 10:00:09 --> Language Class Initialized
INFO - 2024-12-06 10:00:09 --> Loader Class Initialized
INFO - 2024-12-06 10:00:09 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:09 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:09 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:09 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:09 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:09 --> Controller Class Initialized
INFO - 2024-12-06 10:00:09 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:09 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:09 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:09 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:00:09 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:09 --> Total execution time: 0.0658
INFO - 2024-12-06 10:00:11 --> Config Class Initialized
INFO - 2024-12-06 10:00:11 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:11 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:11 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:11 --> URI Class Initialized
INFO - 2024-12-06 10:00:11 --> Router Class Initialized
INFO - 2024-12-06 10:00:11 --> Output Class Initialized
INFO - 2024-12-06 10:00:11 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:11 --> CSRF cookie sent
INFO - 2024-12-06 10:00:11 --> Input Class Initialized
INFO - 2024-12-06 10:00:11 --> Language Class Initialized
INFO - 2024-12-06 10:00:11 --> Loader Class Initialized
INFO - 2024-12-06 10:00:11 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:11 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:11 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:11 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:11 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:11 --> Controller Class Initialized
INFO - 2024-12-06 10:00:11 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:11 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:11 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:11 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:11 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:11 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:11 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:11 --> Total execution time: 0.0556
INFO - 2024-12-06 10:00:13 --> Config Class Initialized
INFO - 2024-12-06 10:00:13 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:13 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:13 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:13 --> URI Class Initialized
INFO - 2024-12-06 10:00:13 --> Router Class Initialized
INFO - 2024-12-06 10:00:13 --> Output Class Initialized
INFO - 2024-12-06 10:00:13 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:13 --> CSRF cookie sent
INFO - 2024-12-06 10:00:13 --> Input Class Initialized
INFO - 2024-12-06 10:00:13 --> Language Class Initialized
INFO - 2024-12-06 10:00:13 --> Loader Class Initialized
INFO - 2024-12-06 10:00:13 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:13 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:13 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:13 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:13 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:13 --> Controller Class Initialized
INFO - 2024-12-06 10:00:13 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:13 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:13 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:13 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:13 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:13 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:00:13 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:13 --> Total execution time: 0.0579
INFO - 2024-12-06 10:00:15 --> Config Class Initialized
INFO - 2024-12-06 10:00:15 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:15 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:15 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:15 --> URI Class Initialized
INFO - 2024-12-06 10:00:15 --> Router Class Initialized
INFO - 2024-12-06 10:00:15 --> Output Class Initialized
INFO - 2024-12-06 10:00:15 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:15 --> CSRF cookie sent
INFO - 2024-12-06 10:00:15 --> Input Class Initialized
INFO - 2024-12-06 10:00:15 --> Language Class Initialized
INFO - 2024-12-06 10:00:15 --> Loader Class Initialized
INFO - 2024-12-06 10:00:15 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:15 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:15 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:15 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:15 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:15 --> Controller Class Initialized
INFO - 2024-12-06 10:00:15 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:15 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:15 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:15 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:15 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:00:15 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:00:15 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:00:15 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:15 --> Total execution time: 0.0785
INFO - 2024-12-06 10:00:17 --> Config Class Initialized
INFO - 2024-12-06 10:00:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:17 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:17 --> URI Class Initialized
INFO - 2024-12-06 10:00:17 --> Router Class Initialized
INFO - 2024-12-06 10:00:17 --> Output Class Initialized
INFO - 2024-12-06 10:00:17 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:17 --> CSRF cookie sent
INFO - 2024-12-06 10:00:17 --> Input Class Initialized
INFO - 2024-12-06 10:00:17 --> Language Class Initialized
INFO - 2024-12-06 10:00:17 --> Loader Class Initialized
INFO - 2024-12-06 10:00:17 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:17 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:17 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:17 --> Controller Class Initialized
INFO - 2024-12-06 10:00:17 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:17 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:17 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:17 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:17 --> Total execution time: 0.0547
INFO - 2024-12-06 10:00:21 --> Config Class Initialized
INFO - 2024-12-06 10:00:21 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:21 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:21 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:21 --> URI Class Initialized
INFO - 2024-12-06 10:00:21 --> Router Class Initialized
INFO - 2024-12-06 10:00:21 --> Output Class Initialized
INFO - 2024-12-06 10:00:21 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:21 --> CSRF cookie sent
INFO - 2024-12-06 10:00:21 --> Input Class Initialized
INFO - 2024-12-06 10:00:21 --> Language Class Initialized
INFO - 2024-12-06 10:00:21 --> Loader Class Initialized
INFO - 2024-12-06 10:00:21 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:21 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:21 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:21 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:21 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:21 --> Controller Class Initialized
INFO - 2024-12-06 10:00:21 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:21 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:21 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:21 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:21 --> Total execution time: 0.0566
INFO - 2024-12-06 10:00:22 --> Config Class Initialized
INFO - 2024-12-06 10:00:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:22 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:22 --> URI Class Initialized
INFO - 2024-12-06 10:00:22 --> Router Class Initialized
INFO - 2024-12-06 10:00:22 --> Output Class Initialized
INFO - 2024-12-06 10:00:22 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:22 --> CSRF cookie sent
INFO - 2024-12-06 10:00:22 --> Input Class Initialized
INFO - 2024-12-06 10:00:22 --> Language Class Initialized
INFO - 2024-12-06 10:00:22 --> Loader Class Initialized
INFO - 2024-12-06 10:00:22 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:22 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:22 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:22 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:22 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:22 --> Controller Class Initialized
INFO - 2024-12-06 10:00:22 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:22 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:22 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:22 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:22 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:22 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:22 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:22 --> Total execution time: 0.0605
INFO - 2024-12-06 10:00:23 --> Config Class Initialized
INFO - 2024-12-06 10:00:23 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:23 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:23 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:23 --> URI Class Initialized
INFO - 2024-12-06 10:00:23 --> Router Class Initialized
INFO - 2024-12-06 10:00:23 --> Output Class Initialized
INFO - 2024-12-06 10:00:23 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:23 --> CSRF cookie sent
INFO - 2024-12-06 10:00:23 --> Input Class Initialized
INFO - 2024-12-06 10:00:23 --> Language Class Initialized
INFO - 2024-12-06 10:00:23 --> Loader Class Initialized
INFO - 2024-12-06 10:00:23 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:23 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:23 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:23 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:23 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:23 --> Controller Class Initialized
INFO - 2024-12-06 10:00:23 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:23 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:23 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:23 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:23 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:23 --> Total execution time: 0.0551
INFO - 2024-12-06 10:00:26 --> Config Class Initialized
INFO - 2024-12-06 10:00:26 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:26 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:26 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:26 --> URI Class Initialized
INFO - 2024-12-06 10:00:26 --> Router Class Initialized
INFO - 2024-12-06 10:00:26 --> Output Class Initialized
INFO - 2024-12-06 10:00:26 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:26 --> CSRF cookie sent
INFO - 2024-12-06 10:00:26 --> Input Class Initialized
INFO - 2024-12-06 10:00:26 --> Language Class Initialized
INFO - 2024-12-06 10:00:26 --> Loader Class Initialized
INFO - 2024-12-06 10:00:26 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:26 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:26 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:26 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:26 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:26 --> Controller Class Initialized
INFO - 2024-12-06 10:00:26 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:26 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:26 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:26 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:26 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:00:26 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:00:26 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:00:26 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:26 --> Total execution time: 0.0642
INFO - 2024-12-06 10:00:29 --> Config Class Initialized
INFO - 2024-12-06 10:00:29 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:29 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:29 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:29 --> URI Class Initialized
INFO - 2024-12-06 10:00:29 --> Router Class Initialized
INFO - 2024-12-06 10:00:29 --> Output Class Initialized
INFO - 2024-12-06 10:00:29 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:29 --> CSRF cookie sent
INFO - 2024-12-06 10:00:29 --> Input Class Initialized
INFO - 2024-12-06 10:00:29 --> Language Class Initialized
INFO - 2024-12-06 10:00:29 --> Loader Class Initialized
INFO - 2024-12-06 10:00:29 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:29 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:29 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:29 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:29 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:29 --> Controller Class Initialized
INFO - 2024-12-06 10:00:29 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:29 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:29 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:29 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:29 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:29 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:29 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:29 --> Total execution time: 0.0586
INFO - 2024-12-06 10:00:32 --> Config Class Initialized
INFO - 2024-12-06 10:00:32 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:32 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:32 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:32 --> URI Class Initialized
INFO - 2024-12-06 10:00:32 --> Router Class Initialized
INFO - 2024-12-06 10:00:32 --> Output Class Initialized
INFO - 2024-12-06 10:00:32 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:32 --> CSRF cookie sent
INFO - 2024-12-06 10:00:32 --> Input Class Initialized
INFO - 2024-12-06 10:00:32 --> Language Class Initialized
INFO - 2024-12-06 10:00:32 --> Loader Class Initialized
INFO - 2024-12-06 10:00:32 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:32 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:32 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:32 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:32 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:32 --> Controller Class Initialized
INFO - 2024-12-06 10:00:32 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:32 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:32 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:32 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:32 --> Total execution time: 0.0841
INFO - 2024-12-06 10:00:35 --> Config Class Initialized
INFO - 2024-12-06 10:00:35 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:35 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:35 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:35 --> URI Class Initialized
INFO - 2024-12-06 10:00:35 --> Router Class Initialized
INFO - 2024-12-06 10:00:35 --> Output Class Initialized
INFO - 2024-12-06 10:00:35 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:35 --> CSRF cookie sent
INFO - 2024-12-06 10:00:35 --> Input Class Initialized
INFO - 2024-12-06 10:00:35 --> Language Class Initialized
INFO - 2024-12-06 10:00:35 --> Loader Class Initialized
INFO - 2024-12-06 10:00:35 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:35 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:35 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:35 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:35 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:35 --> Controller Class Initialized
INFO - 2024-12-06 10:00:35 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:35 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:35 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-06 10:00:35 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:35 --> Total execution time: 0.0651
INFO - 2024-12-06 10:00:38 --> Config Class Initialized
INFO - 2024-12-06 10:00:38 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:00:38 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:00:38 --> Utf8 Class Initialized
INFO - 2024-12-06 10:00:38 --> URI Class Initialized
INFO - 2024-12-06 10:00:38 --> Router Class Initialized
INFO - 2024-12-06 10:00:38 --> Output Class Initialized
INFO - 2024-12-06 10:00:38 --> Security Class Initialized
DEBUG - 2024-12-06 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:00:39 --> CSRF cookie sent
INFO - 2024-12-06 10:00:39 --> Input Class Initialized
INFO - 2024-12-06 10:00:39 --> Language Class Initialized
INFO - 2024-12-06 10:00:39 --> Loader Class Initialized
INFO - 2024-12-06 10:00:39 --> Helper loaded: url_helper
INFO - 2024-12-06 10:00:39 --> Helper loaded: form_helper
INFO - 2024-12-06 10:00:39 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:00:39 --> Form Validation Class Initialized
INFO - 2024-12-06 10:00:39 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:00:39 --> Controller Class Initialized
INFO - 2024-12-06 10:00:39 --> Model "Review_model" initialized
INFO - 2024-12-06 10:00:39 --> Model "Category_model" initialized
INFO - 2024-12-06 10:00:39 --> Model "User_model" initialized
INFO - 2024-12-06 10:00:39 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:00:39 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:00:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:00:39 --> Final output sent to browser
DEBUG - 2024-12-06 10:00:39 --> Total execution time: 0.0573
INFO - 2024-12-06 10:01:53 --> Config Class Initialized
INFO - 2024-12-06 10:01:53 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:01:53 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:01:53 --> Utf8 Class Initialized
INFO - 2024-12-06 10:01:53 --> URI Class Initialized
INFO - 2024-12-06 10:01:53 --> Router Class Initialized
INFO - 2024-12-06 10:01:53 --> Output Class Initialized
INFO - 2024-12-06 10:01:53 --> Security Class Initialized
DEBUG - 2024-12-06 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:01:53 --> CSRF cookie sent
INFO - 2024-12-06 10:01:53 --> Input Class Initialized
INFO - 2024-12-06 10:01:53 --> Language Class Initialized
INFO - 2024-12-06 10:01:53 --> Loader Class Initialized
INFO - 2024-12-06 10:01:53 --> Helper loaded: url_helper
INFO - 2024-12-06 10:01:53 --> Helper loaded: form_helper
INFO - 2024-12-06 10:01:53 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:01:53 --> Form Validation Class Initialized
INFO - 2024-12-06 10:01:53 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:01:53 --> Controller Class Initialized
INFO - 2024-12-06 10:01:53 --> Model "Review_model" initialized
INFO - 2024-12-06 10:01:53 --> Model "Category_model" initialized
INFO - 2024-12-06 10:01:53 --> Model "User_model" initialized
INFO - 2024-12-06 10:01:53 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:01:53 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:01:53 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:01:53 --> Final output sent to browser
DEBUG - 2024-12-06 10:01:53 --> Total execution time: 0.0916
INFO - 2024-12-06 10:01:55 --> Config Class Initialized
INFO - 2024-12-06 10:01:55 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:01:55 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:01:55 --> Utf8 Class Initialized
INFO - 2024-12-06 10:01:55 --> URI Class Initialized
INFO - 2024-12-06 10:01:55 --> Router Class Initialized
INFO - 2024-12-06 10:01:55 --> Output Class Initialized
INFO - 2024-12-06 10:01:55 --> Security Class Initialized
DEBUG - 2024-12-06 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:01:55 --> CSRF cookie sent
INFO - 2024-12-06 10:01:55 --> Input Class Initialized
INFO - 2024-12-06 10:01:55 --> Language Class Initialized
INFO - 2024-12-06 10:01:55 --> Loader Class Initialized
INFO - 2024-12-06 10:01:55 --> Helper loaded: url_helper
INFO - 2024-12-06 10:01:55 --> Helper loaded: form_helper
INFO - 2024-12-06 10:01:55 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:01:55 --> Form Validation Class Initialized
INFO - 2024-12-06 10:01:55 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:01:55 --> Controller Class Initialized
INFO - 2024-12-06 10:01:55 --> Model "Review_model" initialized
INFO - 2024-12-06 10:01:55 --> Model "Category_model" initialized
INFO - 2024-12-06 10:01:55 --> Model "User_model" initialized
INFO - 2024-12-06 10:01:55 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:01:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:01:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:01:56 --> Final output sent to browser
DEBUG - 2024-12-06 10:01:56 --> Total execution time: 0.0575
INFO - 2024-12-06 10:01:57 --> Config Class Initialized
INFO - 2024-12-06 10:01:57 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:01:57 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:01:57 --> Utf8 Class Initialized
INFO - 2024-12-06 10:01:57 --> URI Class Initialized
INFO - 2024-12-06 10:01:57 --> Router Class Initialized
INFO - 2024-12-06 10:01:57 --> Output Class Initialized
INFO - 2024-12-06 10:01:57 --> Security Class Initialized
DEBUG - 2024-12-06 10:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:01:57 --> CSRF cookie sent
INFO - 2024-12-06 10:01:57 --> Input Class Initialized
INFO - 2024-12-06 10:01:57 --> Language Class Initialized
INFO - 2024-12-06 10:01:57 --> Loader Class Initialized
INFO - 2024-12-06 10:01:57 --> Helper loaded: url_helper
INFO - 2024-12-06 10:01:57 --> Helper loaded: form_helper
INFO - 2024-12-06 10:01:57 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:01:57 --> Form Validation Class Initialized
INFO - 2024-12-06 10:01:57 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:01:57 --> Controller Class Initialized
INFO - 2024-12-06 10:01:57 --> Model "Review_model" initialized
INFO - 2024-12-06 10:01:57 --> Model "Category_model" initialized
INFO - 2024-12-06 10:01:57 --> Model "User_model" initialized
INFO - 2024-12-06 10:01:57 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:01:57 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:01:57 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-06 10:01:57 --> Final output sent to browser
DEBUG - 2024-12-06 10:01:57 --> Total execution time: 0.0580
INFO - 2024-12-06 10:01:59 --> Config Class Initialized
INFO - 2024-12-06 10:01:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:01:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:01:59 --> Utf8 Class Initialized
INFO - 2024-12-06 10:01:59 --> URI Class Initialized
INFO - 2024-12-06 10:01:59 --> Router Class Initialized
INFO - 2024-12-06 10:01:59 --> Output Class Initialized
INFO - 2024-12-06 10:01:59 --> Security Class Initialized
DEBUG - 2024-12-06 10:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:01:59 --> CSRF cookie sent
INFO - 2024-12-06 10:01:59 --> Input Class Initialized
INFO - 2024-12-06 10:01:59 --> Language Class Initialized
INFO - 2024-12-06 10:01:59 --> Loader Class Initialized
INFO - 2024-12-06 10:01:59 --> Helper loaded: url_helper
INFO - 2024-12-06 10:01:59 --> Helper loaded: form_helper
INFO - 2024-12-06 10:01:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:01:59 --> Form Validation Class Initialized
INFO - 2024-12-06 10:01:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:01:59 --> Controller Class Initialized
INFO - 2024-12-06 10:01:59 --> Model "Review_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "Category_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "User_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:01:59 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:01:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:01:59 --> Final output sent to browser
DEBUG - 2024-12-06 10:01:59 --> Total execution time: 0.0588
INFO - 2024-12-06 10:01:59 --> Config Class Initialized
INFO - 2024-12-06 10:01:59 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:01:59 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:01:59 --> Utf8 Class Initialized
INFO - 2024-12-06 10:01:59 --> URI Class Initialized
INFO - 2024-12-06 10:01:59 --> Router Class Initialized
INFO - 2024-12-06 10:01:59 --> Output Class Initialized
INFO - 2024-12-06 10:01:59 --> Security Class Initialized
DEBUG - 2024-12-06 10:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:01:59 --> CSRF cookie sent
INFO - 2024-12-06 10:01:59 --> Input Class Initialized
INFO - 2024-12-06 10:01:59 --> Language Class Initialized
INFO - 2024-12-06 10:01:59 --> Loader Class Initialized
INFO - 2024-12-06 10:01:59 --> Helper loaded: url_helper
INFO - 2024-12-06 10:01:59 --> Helper loaded: form_helper
INFO - 2024-12-06 10:01:59 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:01:59 --> Form Validation Class Initialized
INFO - 2024-12-06 10:01:59 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:01:59 --> Controller Class Initialized
INFO - 2024-12-06 10:01:59 --> Model "Review_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "Category_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "User_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:01:59 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:01:59 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:01:59 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:01:59 --> Final output sent to browser
DEBUG - 2024-12-06 10:01:59 --> Total execution time: 0.0742
INFO - 2024-12-06 10:02:01 --> Config Class Initialized
INFO - 2024-12-06 10:02:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:02:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:02:01 --> Utf8 Class Initialized
INFO - 2024-12-06 10:02:01 --> URI Class Initialized
INFO - 2024-12-06 10:02:01 --> Router Class Initialized
INFO - 2024-12-06 10:02:01 --> Output Class Initialized
INFO - 2024-12-06 10:02:01 --> Security Class Initialized
DEBUG - 2024-12-06 10:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:02:01 --> CSRF cookie sent
INFO - 2024-12-06 10:02:01 --> Input Class Initialized
INFO - 2024-12-06 10:02:01 --> Language Class Initialized
INFO - 2024-12-06 10:02:01 --> Loader Class Initialized
INFO - 2024-12-06 10:02:01 --> Helper loaded: url_helper
INFO - 2024-12-06 10:02:01 --> Helper loaded: form_helper
INFO - 2024-12-06 10:02:01 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:02:01 --> Form Validation Class Initialized
INFO - 2024-12-06 10:02:01 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:02:01 --> Controller Class Initialized
INFO - 2024-12-06 10:02:01 --> Model "Review_model" initialized
INFO - 2024-12-06 10:02:01 --> Model "Category_model" initialized
INFO - 2024-12-06 10:02:01 --> Model "User_model" initialized
INFO - 2024-12-06 10:02:01 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:02:01 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:02:01 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 10:02:01 --> Final output sent to browser
DEBUG - 2024-12-06 10:02:01 --> Total execution time: 0.0510
INFO - 2024-12-06 10:02:02 --> Config Class Initialized
INFO - 2024-12-06 10:02:02 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:02:02 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:02:02 --> Utf8 Class Initialized
INFO - 2024-12-06 10:02:02 --> URI Class Initialized
INFO - 2024-12-06 10:02:02 --> Router Class Initialized
INFO - 2024-12-06 10:02:02 --> Output Class Initialized
INFO - 2024-12-06 10:02:02 --> Security Class Initialized
DEBUG - 2024-12-06 10:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:02:02 --> CSRF cookie sent
INFO - 2024-12-06 10:02:02 --> Input Class Initialized
INFO - 2024-12-06 10:02:02 --> Language Class Initialized
INFO - 2024-12-06 10:02:02 --> Loader Class Initialized
INFO - 2024-12-06 10:02:02 --> Helper loaded: url_helper
INFO - 2024-12-06 10:02:02 --> Helper loaded: form_helper
INFO - 2024-12-06 10:02:02 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:02:02 --> Form Validation Class Initialized
INFO - 2024-12-06 10:02:02 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:02:02 --> Controller Class Initialized
INFO - 2024-12-06 10:02:02 --> Model "Review_model" initialized
INFO - 2024-12-06 10:02:02 --> Model "Category_model" initialized
INFO - 2024-12-06 10:02:02 --> Model "User_model" initialized
INFO - 2024-12-06 10:02:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:02:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:02:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:02:02 --> Final output sent to browser
DEBUG - 2024-12-06 10:02:02 --> Total execution time: 0.0762
INFO - 2024-12-06 10:02:04 --> Config Class Initialized
INFO - 2024-12-06 10:02:04 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:02:04 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:02:04 --> Utf8 Class Initialized
INFO - 2024-12-06 10:02:04 --> URI Class Initialized
INFO - 2024-12-06 10:02:04 --> Router Class Initialized
INFO - 2024-12-06 10:02:04 --> Output Class Initialized
INFO - 2024-12-06 10:02:04 --> Security Class Initialized
DEBUG - 2024-12-06 10:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:02:04 --> CSRF cookie sent
INFO - 2024-12-06 10:02:04 --> Input Class Initialized
INFO - 2024-12-06 10:02:04 --> Language Class Initialized
INFO - 2024-12-06 10:02:04 --> Loader Class Initialized
INFO - 2024-12-06 10:02:04 --> Helper loaded: url_helper
INFO - 2024-12-06 10:02:04 --> Helper loaded: form_helper
INFO - 2024-12-06 10:02:04 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:02:04 --> Form Validation Class Initialized
INFO - 2024-12-06 10:02:04 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:02:04 --> Controller Class Initialized
INFO - 2024-12-06 10:02:04 --> Model "Review_model" initialized
INFO - 2024-12-06 10:02:04 --> Model "Category_model" initialized
INFO - 2024-12-06 10:02:04 --> Model "User_model" initialized
INFO - 2024-12-06 10:02:04 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:02:04 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:02:04 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:02:04 --> Final output sent to browser
DEBUG - 2024-12-06 10:02:04 --> Total execution time: 0.0435
INFO - 2024-12-06 10:02:09 --> Config Class Initialized
INFO - 2024-12-06 10:02:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:02:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:02:09 --> Utf8 Class Initialized
INFO - 2024-12-06 10:02:09 --> URI Class Initialized
INFO - 2024-12-06 10:02:09 --> Router Class Initialized
INFO - 2024-12-06 10:02:09 --> Output Class Initialized
INFO - 2024-12-06 10:02:09 --> Security Class Initialized
DEBUG - 2024-12-06 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:02:09 --> CSRF cookie sent
INFO - 2024-12-06 10:02:09 --> Input Class Initialized
INFO - 2024-12-06 10:02:09 --> Language Class Initialized
INFO - 2024-12-06 10:02:09 --> Loader Class Initialized
INFO - 2024-12-06 10:02:09 --> Helper loaded: url_helper
INFO - 2024-12-06 10:02:09 --> Helper loaded: form_helper
INFO - 2024-12-06 10:02:09 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:02:09 --> Form Validation Class Initialized
INFO - 2024-12-06 10:02:09 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:02:09 --> Controller Class Initialized
INFO - 2024-12-06 10:02:09 --> Model "Review_model" initialized
INFO - 2024-12-06 10:02:09 --> Model "Category_model" initialized
INFO - 2024-12-06 10:02:09 --> Model "User_model" initialized
INFO - 2024-12-06 10:02:09 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:02:09 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:02:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:02:09 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/edit_pengguna.php
INFO - 2024-12-06 10:02:09 --> Final output sent to browser
DEBUG - 2024-12-06 10:02:09 --> Total execution time: 0.0614
INFO - 2024-12-06 10:02:12 --> Config Class Initialized
INFO - 2024-12-06 10:02:12 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:02:12 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:02:12 --> Utf8 Class Initialized
INFO - 2024-12-06 10:02:12 --> URI Class Initialized
INFO - 2024-12-06 10:02:12 --> Router Class Initialized
INFO - 2024-12-06 10:02:12 --> Output Class Initialized
INFO - 2024-12-06 10:02:12 --> Security Class Initialized
DEBUG - 2024-12-06 10:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:02:12 --> CSRF cookie sent
INFO - 2024-12-06 10:02:12 --> Input Class Initialized
INFO - 2024-12-06 10:02:12 --> Language Class Initialized
INFO - 2024-12-06 10:02:12 --> Loader Class Initialized
INFO - 2024-12-06 10:02:12 --> Helper loaded: url_helper
INFO - 2024-12-06 10:02:12 --> Helper loaded: form_helper
INFO - 2024-12-06 10:02:12 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:02:12 --> Form Validation Class Initialized
INFO - 2024-12-06 10:02:12 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:02:12 --> Controller Class Initialized
INFO - 2024-12-06 10:02:12 --> Model "Review_model" initialized
INFO - 2024-12-06 10:02:12 --> Model "Category_model" initialized
INFO - 2024-12-06 10:02:12 --> Model "User_model" initialized
INFO - 2024-12-06 10:02:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:02:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:02:12 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:02:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:02:12 --> Final output sent to browser
DEBUG - 2024-12-06 10:02:12 --> Total execution time: 0.0579
INFO - 2024-12-06 10:03:20 --> Config Class Initialized
INFO - 2024-12-06 10:03:20 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:20 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:20 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:20 --> URI Class Initialized
INFO - 2024-12-06 10:03:20 --> Router Class Initialized
INFO - 2024-12-06 10:03:20 --> Output Class Initialized
INFO - 2024-12-06 10:03:20 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:20 --> CSRF cookie sent
INFO - 2024-12-06 10:03:20 --> Input Class Initialized
INFO - 2024-12-06 10:03:20 --> Language Class Initialized
INFO - 2024-12-06 10:03:20 --> Loader Class Initialized
INFO - 2024-12-06 10:03:20 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:20 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:20 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:20 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:20 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:20 --> Controller Class Initialized
INFO - 2024-12-06 10:03:20 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:20 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:20 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:20 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:20 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:03:20 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:03:20 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:03:20 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:20 --> Total execution time: 0.0615
INFO - 2024-12-06 10:03:23 --> Config Class Initialized
INFO - 2024-12-06 10:03:23 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:23 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:23 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:23 --> URI Class Initialized
INFO - 2024-12-06 10:03:23 --> Router Class Initialized
INFO - 2024-12-06 10:03:23 --> Output Class Initialized
INFO - 2024-12-06 10:03:23 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:23 --> CSRF cookie sent
INFO - 2024-12-06 10:03:23 --> Input Class Initialized
INFO - 2024-12-06 10:03:23 --> Language Class Initialized
INFO - 2024-12-06 10:03:23 --> Loader Class Initialized
INFO - 2024-12-06 10:03:23 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:23 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:23 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:23 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:23 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:23 --> Controller Class Initialized
INFO - 2024-12-06 10:03:23 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:23 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:23 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:23 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:23 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:23 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:03:23 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:23 --> Total execution time: 0.0569
INFO - 2024-12-06 10:03:27 --> Config Class Initialized
INFO - 2024-12-06 10:03:27 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:27 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:27 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:27 --> URI Class Initialized
INFO - 2024-12-06 10:03:27 --> Router Class Initialized
INFO - 2024-12-06 10:03:27 --> Output Class Initialized
INFO - 2024-12-06 10:03:27 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:27 --> CSRF cookie sent
INFO - 2024-12-06 10:03:27 --> Input Class Initialized
INFO - 2024-12-06 10:03:27 --> Language Class Initialized
INFO - 2024-12-06 10:03:27 --> Loader Class Initialized
INFO - 2024-12-06 10:03:27 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:27 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:27 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:27 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:27 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:27 --> Controller Class Initialized
INFO - 2024-12-06 10:03:27 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:27 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:27 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:27 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:27 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:27 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:03:27 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:27 --> Total execution time: 0.0577
INFO - 2024-12-06 10:03:28 --> Config Class Initialized
INFO - 2024-12-06 10:03:28 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:28 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:28 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:28 --> URI Class Initialized
INFO - 2024-12-06 10:03:28 --> Router Class Initialized
INFO - 2024-12-06 10:03:28 --> Output Class Initialized
INFO - 2024-12-06 10:03:28 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:28 --> CSRF cookie sent
INFO - 2024-12-06 10:03:28 --> Input Class Initialized
INFO - 2024-12-06 10:03:28 --> Language Class Initialized
INFO - 2024-12-06 10:03:28 --> Loader Class Initialized
INFO - 2024-12-06 10:03:28 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:28 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:28 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:28 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:28 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:28 --> Controller Class Initialized
INFO - 2024-12-06 10:03:28 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:28 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:28 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:28 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:28 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:28 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:03:28 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:28 --> Total execution time: 0.0533
INFO - 2024-12-06 10:03:30 --> Config Class Initialized
INFO - 2024-12-06 10:03:30 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:30 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:30 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:30 --> URI Class Initialized
INFO - 2024-12-06 10:03:30 --> Router Class Initialized
INFO - 2024-12-06 10:03:30 --> Output Class Initialized
INFO - 2024-12-06 10:03:30 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:30 --> CSRF cookie sent
INFO - 2024-12-06 10:03:30 --> Input Class Initialized
INFO - 2024-12-06 10:03:30 --> Language Class Initialized
INFO - 2024-12-06 10:03:30 --> Loader Class Initialized
INFO - 2024-12-06 10:03:30 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:30 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:30 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:30 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:30 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:30 --> Controller Class Initialized
INFO - 2024-12-06 10:03:30 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:30 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:30 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:30 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:30 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:30 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 10:03:30 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:30 --> Total execution time: 0.0693
INFO - 2024-12-06 10:03:32 --> Config Class Initialized
INFO - 2024-12-06 10:03:32 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:32 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:32 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:32 --> URI Class Initialized
INFO - 2024-12-06 10:03:32 --> Router Class Initialized
INFO - 2024-12-06 10:03:32 --> Output Class Initialized
INFO - 2024-12-06 10:03:32 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:32 --> CSRF cookie sent
INFO - 2024-12-06 10:03:32 --> Input Class Initialized
INFO - 2024-12-06 10:03:32 --> Language Class Initialized
INFO - 2024-12-06 10:03:32 --> Loader Class Initialized
INFO - 2024-12-06 10:03:32 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:32 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:32 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:32 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:32 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:32 --> Controller Class Initialized
INFO - 2024-12-06 10:03:32 --> Model "News_model" initialized
INFO - 2024-12-06 10:03:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 10:03:32 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:32 --> Total execution time: 0.0552
INFO - 2024-12-06 10:03:35 --> Config Class Initialized
INFO - 2024-12-06 10:03:35 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:35 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:35 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:35 --> URI Class Initialized
INFO - 2024-12-06 10:03:35 --> Router Class Initialized
INFO - 2024-12-06 10:03:35 --> Output Class Initialized
INFO - 2024-12-06 10:03:35 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:35 --> CSRF cookie sent
INFO - 2024-12-06 10:03:35 --> Input Class Initialized
INFO - 2024-12-06 10:03:35 --> Language Class Initialized
INFO - 2024-12-06 10:03:35 --> Loader Class Initialized
INFO - 2024-12-06 10:03:35 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:35 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:35 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:35 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:35 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:35 --> Controller Class Initialized
INFO - 2024-12-06 10:03:35 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:35 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:35 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:35 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:35 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:35 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:03:35 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:35 --> Total execution time: 0.0552
INFO - 2024-12-06 10:03:39 --> Config Class Initialized
INFO - 2024-12-06 10:03:39 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:39 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:39 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:39 --> URI Class Initialized
INFO - 2024-12-06 10:03:39 --> Router Class Initialized
INFO - 2024-12-06 10:03:39 --> Output Class Initialized
INFO - 2024-12-06 10:03:39 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:39 --> CSRF cookie sent
INFO - 2024-12-06 10:03:39 --> Input Class Initialized
INFO - 2024-12-06 10:03:39 --> Language Class Initialized
INFO - 2024-12-06 10:03:39 --> Loader Class Initialized
INFO - 2024-12-06 10:03:39 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:39 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:39 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:39 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:39 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:39 --> Controller Class Initialized
INFO - 2024-12-06 10:03:39 --> Model "News_model" initialized
INFO - 2024-12-06 10:03:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 10:03:39 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:39 --> Total execution time: 0.0552
INFO - 2024-12-06 10:03:42 --> Config Class Initialized
INFO - 2024-12-06 10:03:42 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:42 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:42 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:42 --> URI Class Initialized
INFO - 2024-12-06 10:03:42 --> Router Class Initialized
INFO - 2024-12-06 10:03:42 --> Output Class Initialized
INFO - 2024-12-06 10:03:42 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:42 --> CSRF cookie sent
INFO - 2024-12-06 10:03:42 --> Input Class Initialized
INFO - 2024-12-06 10:03:42 --> Language Class Initialized
INFO - 2024-12-06 10:03:42 --> Loader Class Initialized
INFO - 2024-12-06 10:03:42 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:42 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:42 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:42 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:42 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:42 --> Controller Class Initialized
INFO - 2024-12-06 10:03:42 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:42 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:42 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:42 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:42 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:42 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 10:03:42 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:42 --> Total execution time: 0.0622
INFO - 2024-12-06 10:03:43 --> Config Class Initialized
INFO - 2024-12-06 10:03:43 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:43 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:43 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:43 --> URI Class Initialized
INFO - 2024-12-06 10:03:43 --> Router Class Initialized
INFO - 2024-12-06 10:03:43 --> Output Class Initialized
INFO - 2024-12-06 10:03:43 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:43 --> CSRF cookie sent
INFO - 2024-12-06 10:03:43 --> Input Class Initialized
INFO - 2024-12-06 10:03:43 --> Language Class Initialized
INFO - 2024-12-06 10:03:43 --> Loader Class Initialized
INFO - 2024-12-06 10:03:43 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:43 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:43 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:43 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:43 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:43 --> Controller Class Initialized
INFO - 2024-12-06 10:03:43 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:43 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:43 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:43 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:43 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:43 --> Model "Contact_model" initialized
INFO - 2024-12-06 10:03:43 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/contact_messages.php
INFO - 2024-12-06 10:03:43 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:43 --> Total execution time: 0.0574
INFO - 2024-12-06 10:03:45 --> Config Class Initialized
INFO - 2024-12-06 10:03:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:45 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:45 --> URI Class Initialized
INFO - 2024-12-06 10:03:45 --> Router Class Initialized
INFO - 2024-12-06 10:03:45 --> Output Class Initialized
INFO - 2024-12-06 10:03:45 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:45 --> CSRF cookie sent
INFO - 2024-12-06 10:03:45 --> Input Class Initialized
INFO - 2024-12-06 10:03:45 --> Language Class Initialized
INFO - 2024-12-06 10:03:45 --> Loader Class Initialized
INFO - 2024-12-06 10:03:45 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:45 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:45 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:45 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:45 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:45 --> Controller Class Initialized
INFO - 2024-12-06 10:03:45 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:45 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:45 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:45 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:45 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:45 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:03:45 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:45 --> Total execution time: 0.0818
INFO - 2024-12-06 10:03:47 --> Config Class Initialized
INFO - 2024-12-06 10:03:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:47 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:47 --> URI Class Initialized
INFO - 2024-12-06 10:03:47 --> Router Class Initialized
INFO - 2024-12-06 10:03:47 --> Output Class Initialized
INFO - 2024-12-06 10:03:47 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:47 --> CSRF cookie sent
INFO - 2024-12-06 10:03:47 --> Input Class Initialized
INFO - 2024-12-06 10:03:47 --> Language Class Initialized
INFO - 2024-12-06 10:03:47 --> Loader Class Initialized
INFO - 2024-12-06 10:03:47 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:47 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:47 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:47 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:47 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:47 --> Controller Class Initialized
INFO - 2024-12-06 10:03:47 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:47 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:47 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:47 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:47 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:47 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 10:03:47 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:47 --> Total execution time: 0.0626
INFO - 2024-12-06 10:03:48 --> Config Class Initialized
INFO - 2024-12-06 10:03:48 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:48 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:48 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:48 --> URI Class Initialized
INFO - 2024-12-06 10:03:48 --> Router Class Initialized
INFO - 2024-12-06 10:03:48 --> Output Class Initialized
INFO - 2024-12-06 10:03:48 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:48 --> CSRF cookie sent
INFO - 2024-12-06 10:03:48 --> Input Class Initialized
INFO - 2024-12-06 10:03:48 --> Language Class Initialized
INFO - 2024-12-06 10:03:48 --> Loader Class Initialized
INFO - 2024-12-06 10:03:48 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:48 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:48 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:49 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:49 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:49 --> Controller Class Initialized
INFO - 2024-12-06 10:03:49 --> Model "News_model" initialized
INFO - 2024-12-06 10:03:49 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 10:03:49 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:49 --> Total execution time: 0.0410
INFO - 2024-12-06 10:03:50 --> Config Class Initialized
INFO - 2024-12-06 10:03:50 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:50 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:50 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:50 --> URI Class Initialized
INFO - 2024-12-06 10:03:50 --> Router Class Initialized
INFO - 2024-12-06 10:03:50 --> Output Class Initialized
INFO - 2024-12-06 10:03:50 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:50 --> CSRF cookie sent
INFO - 2024-12-06 10:03:50 --> Input Class Initialized
INFO - 2024-12-06 10:03:50 --> Language Class Initialized
INFO - 2024-12-06 10:03:50 --> Loader Class Initialized
INFO - 2024-12-06 10:03:50 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:50 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:50 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:50 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:50 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:50 --> Controller Class Initialized
INFO - 2024-12-06 10:03:50 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:50 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:50 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:50 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:50 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:03:50 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:03:50 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:50 --> Total execution time: 0.0806
INFO - 2024-12-06 10:03:56 --> Config Class Initialized
INFO - 2024-12-06 10:03:56 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:03:56 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:03:56 --> Utf8 Class Initialized
INFO - 2024-12-06 10:03:56 --> URI Class Initialized
INFO - 2024-12-06 10:03:56 --> Router Class Initialized
INFO - 2024-12-06 10:03:56 --> Output Class Initialized
INFO - 2024-12-06 10:03:56 --> Security Class Initialized
DEBUG - 2024-12-06 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:03:56 --> CSRF cookie sent
INFO - 2024-12-06 10:03:56 --> Input Class Initialized
INFO - 2024-12-06 10:03:56 --> Language Class Initialized
INFO - 2024-12-06 10:03:56 --> Loader Class Initialized
INFO - 2024-12-06 10:03:56 --> Helper loaded: url_helper
INFO - 2024-12-06 10:03:56 --> Helper loaded: form_helper
INFO - 2024-12-06 10:03:56 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:03:56 --> Form Validation Class Initialized
INFO - 2024-12-06 10:03:56 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:03:56 --> Controller Class Initialized
INFO - 2024-12-06 10:03:56 --> Model "Review_model" initialized
INFO - 2024-12-06 10:03:56 --> Model "Category_model" initialized
INFO - 2024-12-06 10:03:56 --> Model "User_model" initialized
INFO - 2024-12-06 10:03:56 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:03:56 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:03:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:03:56 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:03:56 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:03:56 --> Final output sent to browser
DEBUG - 2024-12-06 10:03:56 --> Total execution time: 0.0596
INFO - 2024-12-06 10:04:02 --> Config Class Initialized
INFO - 2024-12-06 10:04:02 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:02 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:02 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:02 --> URI Class Initialized
INFO - 2024-12-06 10:04:02 --> Router Class Initialized
INFO - 2024-12-06 10:04:02 --> Output Class Initialized
INFO - 2024-12-06 10:04:02 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:02 --> CSRF cookie sent
INFO - 2024-12-06 10:04:02 --> Input Class Initialized
INFO - 2024-12-06 10:04:02 --> Language Class Initialized
INFO - 2024-12-06 10:04:02 --> Loader Class Initialized
INFO - 2024-12-06 10:04:02 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:02 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:02 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:02 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:02 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:02 --> Controller Class Initialized
INFO - 2024-12-06 10:04:02 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:02 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:02 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:02 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:02 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:04:02 --> Query result: stdClass Object
(
    [view_count] => 95
)

INFO - 2024-12-06 10:04:02 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/dashboard.php
INFO - 2024-12-06 10:04:02 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:02 --> Total execution time: 0.0615
INFO - 2024-12-06 10:04:06 --> Config Class Initialized
INFO - 2024-12-06 10:04:06 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:06 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:06 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:06 --> URI Class Initialized
INFO - 2024-12-06 10:04:06 --> Router Class Initialized
INFO - 2024-12-06 10:04:06 --> Output Class Initialized
INFO - 2024-12-06 10:04:06 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:06 --> CSRF cookie sent
INFO - 2024-12-06 10:04:06 --> Input Class Initialized
INFO - 2024-12-06 10:04:06 --> Language Class Initialized
INFO - 2024-12-06 10:04:06 --> Loader Class Initialized
INFO - 2024-12-06 10:04:06 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:06 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:06 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:06 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:06 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:06 --> Controller Class Initialized
INFO - 2024-12-06 10:04:06 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:06 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:06 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:06 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:06 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:06 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 10:04:06 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:06 --> Total execution time: 0.0590
INFO - 2024-12-06 10:04:08 --> Config Class Initialized
INFO - 2024-12-06 10:04:08 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:08 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:08 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:08 --> URI Class Initialized
INFO - 2024-12-06 10:04:08 --> Router Class Initialized
INFO - 2024-12-06 10:04:08 --> Output Class Initialized
INFO - 2024-12-06 10:04:08 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:08 --> CSRF cookie sent
INFO - 2024-12-06 10:04:08 --> Input Class Initialized
INFO - 2024-12-06 10:04:08 --> Language Class Initialized
INFO - 2024-12-06 10:04:08 --> Loader Class Initialized
INFO - 2024-12-06 10:04:08 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:08 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:08 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:08 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:08 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:08 --> Controller Class Initialized
INFO - 2024-12-06 10:04:08 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:08 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:08 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:08 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:08 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:08 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:04:08 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:08 --> Total execution time: 0.0761
INFO - 2024-12-06 10:04:12 --> Config Class Initialized
INFO - 2024-12-06 10:04:12 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:12 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:12 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:12 --> URI Class Initialized
INFO - 2024-12-06 10:04:12 --> Router Class Initialized
INFO - 2024-12-06 10:04:12 --> Output Class Initialized
INFO - 2024-12-06 10:04:12 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:12 --> CSRF cookie sent
INFO - 2024-12-06 10:04:12 --> Input Class Initialized
INFO - 2024-12-06 10:04:12 --> Language Class Initialized
INFO - 2024-12-06 10:04:12 --> Loader Class Initialized
INFO - 2024-12-06 10:04:12 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:12 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:12 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:12 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:12 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:12 --> Controller Class Initialized
INFO - 2024-12-06 10:04:12 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:12 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:12 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:12 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:12 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:12 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kategori.php
INFO - 2024-12-06 10:04:12 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:12 --> Total execution time: 0.0662
INFO - 2024-12-06 10:04:14 --> Config Class Initialized
INFO - 2024-12-06 10:04:14 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:14 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:14 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:14 --> URI Class Initialized
INFO - 2024-12-06 10:04:14 --> Router Class Initialized
INFO - 2024-12-06 10:04:14 --> Output Class Initialized
INFO - 2024-12-06 10:04:14 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:14 --> CSRF cookie sent
INFO - 2024-12-06 10:04:14 --> Input Class Initialized
INFO - 2024-12-06 10:04:14 --> Language Class Initialized
INFO - 2024-12-06 10:04:14 --> Loader Class Initialized
INFO - 2024-12-06 10:04:14 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:14 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:14 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:14 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:14 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:14 --> Controller Class Initialized
INFO - 2024-12-06 10:04:14 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:14 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:14 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:14 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:14 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:14 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-06 10:04:14 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:14 --> Total execution time: 0.0524
INFO - 2024-12-06 10:04:16 --> Config Class Initialized
INFO - 2024-12-06 10:04:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:16 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:16 --> URI Class Initialized
INFO - 2024-12-06 10:04:16 --> Router Class Initialized
INFO - 2024-12-06 10:04:16 --> Output Class Initialized
INFO - 2024-12-06 10:04:16 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:16 --> CSRF cookie sent
INFO - 2024-12-06 10:04:16 --> Input Class Initialized
INFO - 2024-12-06 10:04:16 --> Language Class Initialized
INFO - 2024-12-06 10:04:16 --> Loader Class Initialized
INFO - 2024-12-06 10:04:16 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:16 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:16 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:16 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:16 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:16 --> Controller Class Initialized
INFO - 2024-12-06 10:04:16 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:16 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:16 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:16 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:16 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:16 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:04:16 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:16 --> Total execution time: 0.0587
INFO - 2024-12-06 10:04:17 --> Config Class Initialized
INFO - 2024-12-06 10:04:17 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:17 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:17 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:17 --> URI Class Initialized
INFO - 2024-12-06 10:04:17 --> Router Class Initialized
INFO - 2024-12-06 10:04:17 --> Output Class Initialized
INFO - 2024-12-06 10:04:17 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:17 --> CSRF cookie sent
INFO - 2024-12-06 10:04:17 --> Input Class Initialized
INFO - 2024-12-06 10:04:17 --> Language Class Initialized
INFO - 2024-12-06 10:04:17 --> Loader Class Initialized
INFO - 2024-12-06 10:04:17 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:17 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:17 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:17 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:17 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:17 --> Controller Class Initialized
INFO - 2024-12-06 10:04:17 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:17 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:17 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/verifikasi_kuliner.php
INFO - 2024-12-06 10:04:17 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:17 --> Total execution time: 0.0608
INFO - 2024-12-06 10:04:19 --> Config Class Initialized
INFO - 2024-12-06 10:04:19 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:19 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:19 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:19 --> URI Class Initialized
INFO - 2024-12-06 10:04:19 --> Router Class Initialized
INFO - 2024-12-06 10:04:19 --> Output Class Initialized
INFO - 2024-12-06 10:04:19 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:19 --> CSRF cookie sent
INFO - 2024-12-06 10:04:19 --> Input Class Initialized
INFO - 2024-12-06 10:04:19 --> Language Class Initialized
INFO - 2024-12-06 10:04:19 --> Loader Class Initialized
INFO - 2024-12-06 10:04:19 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:19 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:19 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:19 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:19 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:19 --> Controller Class Initialized
INFO - 2024-12-06 10:04:19 --> Model "News_model" initialized
INFO - 2024-12-06 10:04:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/news_list.php
INFO - 2024-12-06 10:04:19 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:19 --> Total execution time: 0.0523
INFO - 2024-12-06 10:04:21 --> Config Class Initialized
INFO - 2024-12-06 10:04:21 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:21 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:21 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:21 --> URI Class Initialized
INFO - 2024-12-06 10:04:21 --> Router Class Initialized
INFO - 2024-12-06 10:04:21 --> Output Class Initialized
INFO - 2024-12-06 10:04:21 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:21 --> CSRF cookie sent
INFO - 2024-12-06 10:04:21 --> Input Class Initialized
INFO - 2024-12-06 10:04:21 --> Language Class Initialized
INFO - 2024-12-06 10:04:21 --> Loader Class Initialized
INFO - 2024-12-06 10:04:21 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:21 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:21 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:21 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:21 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:21 --> Controller Class Initialized
INFO - 2024-12-06 10:04:21 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:21 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:21 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:21 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:21 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:21 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-06 10:04:21 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:21 --> Total execution time: 0.0588
INFO - 2024-12-06 10:04:32 --> Config Class Initialized
INFO - 2024-12-06 10:04:32 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:32 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:32 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:32 --> URI Class Initialized
INFO - 2024-12-06 10:04:32 --> Router Class Initialized
INFO - 2024-12-06 10:04:32 --> Output Class Initialized
INFO - 2024-12-06 10:04:32 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:32 --> CSRF cookie sent
INFO - 2024-12-06 10:04:32 --> Input Class Initialized
INFO - 2024-12-06 10:04:32 --> Language Class Initialized
INFO - 2024-12-06 10:04:32 --> Loader Class Initialized
INFO - 2024-12-06 10:04:32 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:32 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:32 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:32 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:32 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:32 --> Controller Class Initialized
INFO - 2024-12-06 10:04:32 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:32 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:32 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:32 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-06 10:04:32 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:32 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/pengguna.php
INFO - 2024-12-06 10:04:32 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:32 --> Total execution time: 0.0661
INFO - 2024-12-06 10:04:36 --> Config Class Initialized
INFO - 2024-12-06 10:04:36 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:36 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:36 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:36 --> URI Class Initialized
INFO - 2024-12-06 10:04:36 --> Router Class Initialized
INFO - 2024-12-06 10:04:36 --> Output Class Initialized
INFO - 2024-12-06 10:04:36 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:36 --> CSRF cookie sent
INFO - 2024-12-06 10:04:36 --> Input Class Initialized
INFO - 2024-12-06 10:04:36 --> Language Class Initialized
INFO - 2024-12-06 10:04:36 --> Loader Class Initialized
INFO - 2024-12-06 10:04:36 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:36 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:36 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:36 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:36 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:36 --> Controller Class Initialized
INFO - 2024-12-06 10:04:36 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "News_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:36 --> Config Class Initialized
INFO - 2024-12-06 10:04:36 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:36 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:36 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:36 --> URI Class Initialized
INFO - 2024-12-06 10:04:36 --> Router Class Initialized
INFO - 2024-12-06 10:04:36 --> Output Class Initialized
INFO - 2024-12-06 10:04:36 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:36 --> CSRF cookie sent
INFO - 2024-12-06 10:04:36 --> Input Class Initialized
INFO - 2024-12-06 10:04:36 --> Language Class Initialized
INFO - 2024-12-06 10:04:36 --> Loader Class Initialized
INFO - 2024-12-06 10:04:36 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:36 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:36 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:36 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:36 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:36 --> Controller Class Initialized
INFO - 2024-12-06 10:04:36 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "News_model" initialized
INFO - 2024-12-06 10:04:36 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-06 10:04:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 10:04:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 10:04:36 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/login.php
INFO - 2024-12-06 10:04:36 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:36 --> Total execution time: 0.0482
INFO - 2024-12-06 10:04:38 --> Config Class Initialized
INFO - 2024-12-06 10:04:38 --> Hooks Class Initialized
DEBUG - 2024-12-06 10:04:38 --> UTF-8 Support Enabled
INFO - 2024-12-06 10:04:38 --> Utf8 Class Initialized
INFO - 2024-12-06 10:04:38 --> URI Class Initialized
INFO - 2024-12-06 10:04:38 --> Router Class Initialized
INFO - 2024-12-06 10:04:38 --> Output Class Initialized
INFO - 2024-12-06 10:04:38 --> Security Class Initialized
DEBUG - 2024-12-06 10:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 10:04:38 --> CSRF cookie sent
INFO - 2024-12-06 10:04:38 --> Input Class Initialized
INFO - 2024-12-06 10:04:38 --> Language Class Initialized
INFO - 2024-12-06 10:04:38 --> Loader Class Initialized
INFO - 2024-12-06 10:04:38 --> Helper loaded: url_helper
INFO - 2024-12-06 10:04:38 --> Helper loaded: form_helper
INFO - 2024-12-06 10:04:38 --> Database Driver Class Initialized
DEBUG - 2024-12-06 10:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 10:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 10:04:38 --> Form Validation Class Initialized
INFO - 2024-12-06 10:04:38 --> Model "Culinary_model" initialized
INFO - 2024-12-06 10:04:38 --> Controller Class Initialized
INFO - 2024-12-06 10:04:38 --> Model "User_model" initialized
INFO - 2024-12-06 10:04:38 --> Model "Category_model" initialized
INFO - 2024-12-06 10:04:38 --> Model "Review_model" initialized
INFO - 2024-12-06 10:04:38 --> Model "News_model" initialized
INFO - 2024-12-06 10:04:38 --> Model "PageView_model" initialized
DEBUG - 2024-12-06 10:04:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2024-12-06 10:04:39 --> Query result: stdClass Object
(
    [view_count] => 96
)

INFO - 2024-12-06 10:04:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/header.php
INFO - 2024-12-06 10:04:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\layouts/footer.php
INFO - 2024-12-06 10:04:39 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\culinary/index.php
INFO - 2024-12-06 10:04:39 --> Final output sent to browser
DEBUG - 2024-12-06 10:04:39 --> Total execution time: 0.0903
