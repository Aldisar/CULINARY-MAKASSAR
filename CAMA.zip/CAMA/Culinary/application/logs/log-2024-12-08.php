<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-08 13:40:16 --> Config Class Initialized
INFO - 2024-12-08 13:40:16 --> Hooks Class Initialized
DEBUG - 2024-12-08 13:40:16 --> UTF-8 Support Enabled
INFO - 2024-12-08 13:40:16 --> Utf8 Class Initialized
INFO - 2024-12-08 13:40:16 --> URI Class Initialized
INFO - 2024-12-08 13:40:16 --> Router Class Initialized
INFO - 2024-12-08 13:40:16 --> Output Class Initialized
INFO - 2024-12-08 13:40:16 --> Security Class Initialized
DEBUG - 2024-12-08 13:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 13:40:16 --> CSRF cookie sent
INFO - 2024-12-08 13:40:16 --> Input Class Initialized
INFO - 2024-12-08 13:40:16 --> Language Class Initialized
INFO - 2024-12-08 13:40:16 --> Loader Class Initialized
INFO - 2024-12-08 13:40:16 --> Helper loaded: url_helper
INFO - 2024-12-08 13:40:16 --> Helper loaded: form_helper
INFO - 2024-12-08 13:40:16 --> Database Driver Class Initialized
DEBUG - 2024-12-08 13:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-08 13:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-08 13:40:17 --> Form Validation Class Initialized
INFO - 2024-12-08 13:40:17 --> Model "Culinary_model" initialized
INFO - 2024-12-08 13:40:17 --> Controller Class Initialized
INFO - 2024-12-08 13:40:17 --> Model "Review_model" initialized
INFO - 2024-12-08 13:40:17 --> Model "Category_model" initialized
INFO - 2024-12-08 13:40:17 --> Model "User_model" initialized
INFO - 2024-12-08 13:40:17 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-08 13:40:17 --> Model "PageView_model" initialized
DEBUG - 2024-12-08 13:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-08 13:40:17 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/review_list.php
INFO - 2024-12-08 13:40:17 --> Final output sent to browser
DEBUG - 2024-12-08 13:40:17 --> Total execution time: 0.9418
INFO - 2024-12-08 13:40:19 --> Config Class Initialized
INFO - 2024-12-08 13:40:19 --> Hooks Class Initialized
DEBUG - 2024-12-08 13:40:19 --> UTF-8 Support Enabled
INFO - 2024-12-08 13:40:19 --> Utf8 Class Initialized
INFO - 2024-12-08 13:40:19 --> URI Class Initialized
INFO - 2024-12-08 13:40:19 --> Router Class Initialized
INFO - 2024-12-08 13:40:19 --> Output Class Initialized
INFO - 2024-12-08 13:40:19 --> Security Class Initialized
DEBUG - 2024-12-08 13:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 13:40:19 --> CSRF cookie sent
INFO - 2024-12-08 13:40:19 --> Input Class Initialized
INFO - 2024-12-08 13:40:19 --> Language Class Initialized
INFO - 2024-12-08 13:40:19 --> Loader Class Initialized
INFO - 2024-12-08 13:40:19 --> Helper loaded: url_helper
INFO - 2024-12-08 13:40:19 --> Helper loaded: form_helper
INFO - 2024-12-08 13:40:19 --> Database Driver Class Initialized
DEBUG - 2024-12-08 13:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-08 13:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-08 13:40:19 --> Form Validation Class Initialized
INFO - 2024-12-08 13:40:19 --> Model "Culinary_model" initialized
INFO - 2024-12-08 13:40:19 --> Controller Class Initialized
INFO - 2024-12-08 13:40:19 --> Model "Review_model" initialized
INFO - 2024-12-08 13:40:19 --> Model "Category_model" initialized
INFO - 2024-12-08 13:40:19 --> Model "User_model" initialized
INFO - 2024-12-08 13:40:19 --> Model "UserActivityLog_model" initialized
INFO - 2024-12-08 13:40:19 --> Model "PageView_model" initialized
DEBUG - 2024-12-08 13:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-08 13:40:19 --> File loaded: C:\xampp\htdocs\CAMA\Culinary\application\views\admin/kuliner.php
INFO - 2024-12-08 13:40:19 --> Final output sent to browser
DEBUG - 2024-12-08 13:40:19 --> Total execution time: 0.0692
