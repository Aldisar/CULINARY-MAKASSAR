<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PageView extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('PageView_model'); // Memuat model PageView_model
    }

    public function home() {
        // Nama halaman untuk dilacak
        $page_name = 'home';

        // Menambah view count
        $this->PageView_model->increment_view_count($page_name);

        // Mengambil jumlah view terbaru
        $view_count = $this->PageView_model->get_view_count($page_name);

        // Memuat halaman dan menampilkan view count
        $data['view_count'] = $view_count;
        $this->load->view('home', $data);
    }
}
