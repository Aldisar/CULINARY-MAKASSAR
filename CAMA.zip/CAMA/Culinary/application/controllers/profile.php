<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('form_validation'); // Pastikan form_validation dimuat
    }

    // Method untuk menampilkan halaman profil
    public function index() {
        // Pastikan user sudah login
        if (!$this->session->userdata('user_logged_in')) {
            redirect('culinary/login');
        }

        $user_id = $this->session->userdata('user_id');
        $data['user'] = $this->User_model->get_by_id($user_id);

        // Load view untuk profil pengguna
        $this->load->view('profile/index', $data);
    }

    // Method untuk menampilkan halaman edit profil
    public function edit() {
        if (!$this->session->userdata('user_logged_in')) {
            redirect('culinary/login');
        }

        $user_id = $this->session->userdata('user_id');
        $data['user'] = $this->User_model->get_by_id($user_id);

        // Load view untuk form edit profil
        $this->load->view('profile/edit', $data);
    }

    // Method untuk update profil
    public function update() {
        if (!$this->session->userdata('user_logged_in')) {
            redirect('culinary/login');
        }
    
        $user_id = $this->session->userdata('user_id');
        
        // Data untuk update profil
        $data = array(
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'phone' => $this->input->post('phone'),
            'address' => $this->input->post('address'),
        );
    
        // Validasi password baru
        $new_password = $this->input->post('new_password');
        $confirm_password = $this->input->post('confirm_password');
    
        if ($new_password && $new_password === $confirm_password) {
            // Enkripsi password baru dan update
            $data['password'] = password_hash($new_password, PASSWORD_BCRYPT);
        } elseif ($new_password !== $confirm_password) {
            $this->session->set_flashdata('error', 'Password dan konfirmasi password tidak cocok.');
            redirect('profile/edit');
            return;
        }
    
        // Update data pengguna
        $this->User_model->update($user_id, $data);
    
        // Set flash message dan redirect
        $this->session->set_flashdata('success', 'Profil berhasil diperbarui.');
        redirect('profile/edit');
    }
    
}

