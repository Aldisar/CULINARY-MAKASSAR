<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Contact_model'); // Load model
        $this->load->helper(array('url', 'form')); // Load helper URL dan form
        $this->load->library('form_validation'); // Load library form validation
    }

    public function index() {
        $this->load->view('culinary/contact');
    }

    public function submit_message() {
        // Pastikan bahwa hanya request POST yang diproses
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            
            // Set aturan validasi untuk form
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('message', 'Message', 'required');

            if ($this->form_validation->run() == FALSE) {
                // Jika validasi gagal, tampilkan kembali halaman form dengan error
                $this->load->view('contact_view');
            } else {
                // Ambil data dari form
                $name = $this->input->post('name');
                $email = $this->input->post('email');
                $message = $this->input->post('message');

                // Buat array data yang akan disimpan
                $data = array(
                    'name' => $name,
                    'email' => $email,
                    'message' => $message,
                    'created_at' => date('Y-m-d H:i:s')
                );

                // Simpan data menggunakan Contact_model
                if ($this->Contact_model->insert_message($data)) {
                    $this->session->set_flashdata('success', 'Pesan Anda telah berhasil dikirim.');
                } else {
                    $this->session->set_flashdata('error', 'Terjadi kesalahan saat mengirim pesan. Silakan coba lagi.');
                }

                // Redirect kembali ke halaman kontak
                redirect('contact');
            }
        } else {
            // Jika bukan metode POST, tampilkan error
            show_error('The action you have requested is not allowed.', 403);
        }
    }
}
?>
