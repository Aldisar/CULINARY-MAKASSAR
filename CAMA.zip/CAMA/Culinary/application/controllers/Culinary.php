<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Culinary extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Culinary_model');
        $this->load->model('User_model');// Memastikan User_model dimuat untuk keperluan login dan register
        $this->load->model('Category_model'); // Memastikan Category_model dimuat untuk mengakses kategori kuliner
        $this->load->model('Review_model'); // Menambahkan Review_model agar dapat diakses
        $this->load->model('News_model');  // Model ini yang memuat fungsi get_all_news()
        $this->load->model('PageView_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
    }
    
    // Method untuk register pengguna baru
    public function register() {
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
    
        // Validasi input form
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
    
        // Jika validasi gagal, kembali ke halaman register
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('culinary/register');
        } else {
            // Menyimpan data pengguna ke dalam database
            $username = $this->input->post('username');
            $email = $this->input->post('email');
            $password = password_hash($this->input->post('password'), PASSWORD_BCRYPT);
            $phone = $this->input->post('phone');
           $address = $this->input->post('address');

            $data = array(
            'username' => $username,
              'email' => $email,
            'password' => $password,
             'phone' => $phone,
            'address' => $address,
            'role' => 'user' // Menambahkan default role sebagai user
                );
    
            $this->load->model('User_model');
            if ($this->User_model->insert_user($data)) {
                // Log aktivitas: User berhasil registrasi
                $log_data = array(
                    'user_id' => $this->db->insert_id(), // Mengambil ID dari user yang baru saja dibuat
                    'activity' => 'User registered',
                    'created_at' => date('Y-m-d H:i:s')
                );
                $this->User_model->insert_activity_log($log_data);
    
                // Set pesan berhasil dan redirect ke halaman login
                $this->session->set_flashdata('success', 'Pendaftaran berhasil. Silakan login.');
                redirect('culinary/login'); // Pastikan redirect menuju halaman login culinary
            } else {
                // Set pesan error jika terjadi masalah dalam penyimpanan
                $this->session->set_flashdata('error', 'Pendaftaran gagal. Silakan coba lagi.');
                $this->load->view('culinary/register');
            }
        }
    }  
    
    public function search() {
        $query = $this->input->get('query'); // Mendapatkan parameter 'query' dari URL
        if ($query) {
            // Pencarian kuliner menggunakan fungsi dari model
            $data['results'] = $this->Culinary_model->search_culinaries($query);
            // Tampilkan hasil pencarian ke view
            $this->load->view('culinary/search_results', $data);
        } else {
            // Jika query kosong, tampilkan halaman tidak ada hasil
            $this->load->view('culinary/no_results');
        }
    }

    // Method untuk login
    public function login() {
        if ($this->input->post()) {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            // Ambil data user berdasarkan email
            $user = $this->User_model->get_by_email($email);

            // Verifikasi password
            if ($user && password_verify($password, $user->password)) {
                // Jika email dan password cocok, buat session untuk user
                $this->session->set_userdata('user_logged_in', true);
                $this->session->set_userdata('user_id', $user->id);
                $this->session->set_userdata('username', $user->username);
                redirect('culinary'); // Arahkan ke halaman utama kuliner setelah login berhasil
            } elseif ($email == 'admin@cama.com' && $password == 'admin') {
                // Jika admin login
                $this->session->set_userdata('admin_logged_in', true);
                $this->session->set_userdata('role', 'admin');
                redirect('admin/dashboard');
            } else {
                // Jika gagal, kembali ke halaman login dengan pesan error
                $data['error'] = "Email atau password salah";
                $this->load->view('culinary/login', $data);
            }
        } else {
            // Tampilkan halaman login
            $this->load->view('culinary/login');
        }
    }

    // Method untuk logout
    public function logout() {
        // Menghapus session saat logout
        $this->session->unset_userdata('user_logged_in');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('admin_logged_in');
        $this->session->unset_userdata('role');
        $this->load->model('News_model');
        redirect('culinary/login');
    }

    public function reset_password() {
        $this->load->view('culinary/reset_password');
    }

    public function reset_password_action() {
        $email = $this->input->post('email');
        $current_password = $this->input->post('current_password');
        $new_password = $this->input->post('password');
    
        // Validasi input
        if (!$email || !$current_password || !$new_password) {
            $this->session->set_flashdata('error', 'Semua kolom wajib diisi.');
            redirect('culinary/reset_password');
        }
    
        $this->load->model('User_model');
        $user = $this->User_model->get_user_by_email($email);
    
        if (!$user) {
            $this->session->set_flashdata('error', 'Email tidak ditemukan.');
            redirect('culinary/reset_password');
        }
    
        // Verifikasi password lama
        if (!password_verify($current_password, $user->password)) {
            $this->session->set_flashdata('error', 'Password lama tidak sesuai.');
            redirect('culinary/reset_password');
        }
    
        // Update password baru
        $success = $this->User_model->update_password($email, $new_password);
    
        if ($success) {
            $this->session->set_flashdata('success', 'Password berhasil diubah. Silakan login.');
            redirect('culinary/login');
        } else {
            $this->session->set_flashdata('error', 'Terjadi kesalahan. Silakan coba lagi.');
            redirect('culinary/reset_password');
        }
    }
    
    

    // Method untuk menampilkan daftar kuliner yang disetujui
    public function index() {
        $data['news'] = $this->News_model->get_all_news();
        $data['high_rating_culinaries'] = $this->Culinary_model->get_high_rating_culinaries();
        $page_name = 'login';

        // Tambah view setiap kali halaman diakses
        $this->PageView_model->increment_view_count($page_name);

        // Ambil jumlah view dari database
        $view_count = $this->PageView_model->get_view_count($page_name);

        // Kirim data view_count ke view
        $data['view_count'] = $view_count;
        
        // Memuat view dengan data
        $this->load->view('culinary/index', $data);
    }
    
    
    public function add() {
        // Memastikan user sudah login sebelum menambahkan kuliner
        if (!$this->session->userdata('user_logged_in')) {
            redirect('culinary/login');
        }
    
        // Mengambil semua kategori untuk dropdown
        $this->load->model('Category_model');
        $data['categories'] = $this->Category_model->get_all();
    
        // Menangani request POST ketika user submit form tambah kuliner
        if ($this->input->post()) {
            $data_insert = array(
                'name' => $this->input->post('name'),
                'description' => $this->input->post('description'),
                'location' => $this->input->post('location'),
                'category_id' => $this->input->post('category_id'),
                'user_id' => $this->session->userdata('user_id'),
                'status' => 'pending', // Pastikan statusnya "pending"
                'ingredients' => $this->input->post('ingredients'), // Sesuai kolom di tabel
                'youtube_video_id' => $this->input->post('youtube_video_id'), // Pastikan sesuai
                'google_maps_location' => $this->input->post('google_maps_location') // Pastikan sesuai
            );
    
            // Menangani upload foto kuliner
            if (!empty($_FILES['photo']['name'])) {
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|jpeg|png';
                $config['max_size'] = 2048;  // Batas ukuran file maksimal 2MB
                $this->load->library('upload', $config);
    
                if ($this->upload->do_upload('photo')) {
                    $data_insert['photo'] = $this->upload->data('file_name');
                } else {
                    // Menampilkan pesan error jika upload gagal
                    $data['error'] = $this->upload->display_errors();
                    $this->load->view('culinary/add', $data);
                    return;
                }
            }
    
            // Insert data kuliner ke dalam database
            $this->Culinary_model->insert($data_insert);
    
            // Redirect ke halaman utama dengan pesan sukses
            $this->session->set_flashdata('success', 'Kuliner berhasil ditambahkan. Mohon tunggu verifikasi dari admin.');
            redirect('culinary/index');
        }
    
        // Menampilkan form tambah kuliner
        $this->load->view('culinary/add', $data);
    }

    public function details_by_category($category = null) {
        $this->load->model('Culinary_model');
        $data['categories'] = $this->Culinary_model->get_categories();
        $data['culinaries'] = $this->Culinary_model->get_culinaries_grouped_by_category();
    
        if ($category === 'makanan_berat') {
            $this->load->view('culinary/makanan_berat', $data);
        } elseif ($category === 'makanan_ringan') {
            $this->load->view('culinary/makanan_ringan', $data);
        } elseif ($category === 'minuman') {
            $this->load->view('culinary/minuman', $data);
        } else {
            $this->load->view('culinary/lihat_semua', $data);
        }
    }
    
    

    // Method untuk melihat detail kuliner berdasarkan ID
    public function details($id) {
        $data['culinary'] = $this->Culinary_model->get_by_id($id);
        if (empty($data['culinary'])) {
            show_404();
        }
        
        // Ubah dari 'culinary/details' menjadi 'culinary/culinary_detail'
        $this->load->view('culinary/culinary_detail', $data);

    }     
    
    public function detail($culinary_id) {
        // Pastikan model Culinary_model sudah dimuat
        $this->load->model('Culinary_model');
        $this->load->model('Review_model');  // Pastikan model Review sudah dimuat untuk akses review
    
        // Ambil data kuliner berdasarkan ID
        $culinary = $this->Culinary_model->get_by_id($culinary_id);
        // Ambil ulasan-ulasan kuliner berdasarkan ID kuliner
        $reviews = $this->Culinary_model->get_reviews_by_culinary_id($culinary_id);
    
        // Menghitung rata-rata rating
        $totalRating = 0;
        $countRating = count($reviews);
        foreach ($reviews as $review) {
            $totalRating += $review->rating;
        }
    
        $averageRating = $countRating > 0 ? round($totalRating / $countRating, 1) : 0;
    
        // Memeriksa apakah pengguna sudah memberikan review
        $user_id = $this->session->userdata('user_id');  // ID pengguna yang sedang login
        $user_reviewed = $this->Review_model->check_user_reviewed($culinary_id, $user_id);
    
        // Mengirim data ke view
        $data['culinary'] = $culinary;
        $data['reviews'] = $reviews;
        $data['averageRating'] = $averageRating;
        $data['totalReviews'] = $countRating;
        $data['user_reviewed'] = $user_reviewed;  // Menambahkan status apakah pengguna sudah memberi review
    
        $this->load->view('culinary/culinary_detail', $data);
    }
    
    

    public function add_review($culinary_id) {
        $user_id = $this->session->userdata('user_id');
        $comment = $this->input->post('comment');
        $rating = $this->input->post('rating');
    
        // Validasi rating
        if (!$rating || !is_numeric($rating) || $rating < 1 || $rating > 5) {
            $this->session->set_flashdata('error', 'Rating tidak valid. Silakan coba lagi.');
            redirect('culinary/detail/' . $culinary_id);
        }
    
        if (!empty($user_id) && !empty($comment) && !empty($rating)) {
            $data = [
                'culinary_id' => $culinary_id,
                'user_id' => $user_id,
                'rating' => $rating,
                'comment' => $comment,
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->db->insert('reviews', $data);
            $this->session->set_flashdata('success', 'Review berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan review, pastikan semua data sudah diisi.');
        }
    
        redirect('culinary/detail/' . $culinary_id);
    }    
    
    // Method untuk admin menyetujui kuliner
    public function approve($id) {
        // Memastikan hanya admin yang bisa menyetujui kuliner
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('culinary/login');
        }

        $this->Culinary_model->update_status($id, 'approved');
        redirect('admin/dashboard');
    }

    // Method untuk admin menolak kuliner
    public function reject($id) {
        // Memastikan hanya admin yang bisa menolak kuliner
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('culinary/login');
        }

        $this->Culinary_model->update_status($id, 'rejected');
        redirect('admin/dashboard');
    }

    // Method untuk menghapus kuliner (baik oleh admin maupun oleh user pemilik kuliner)
    public function delete($id) {
        // Menghapus kuliner berdasarkan ID
        $culinary = $this->Culinary_model->get_by_id($id);

        // Hanya pemilik kuliner atau admin yang bisa menghapus
        if ($this->session->userdata('user_id') == $culinary->user_id || $this->session->userdata('admin_logged_in')) {
            $this->Culinary_model->delete($id);
        }

        redirect('culinary/index');
    }
    public function contact() {
        $this->load->view('culinary/contact');
    }
    public function send_contact() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('message', 'Message', 'required');
    
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', 'Please fill all fields correctly.');
            redirect('culinary/contact');
        } else {
            // Di sini Anda bisa menyimpan pesan ke database atau mengirimkannya ke email admin.
            $this->session->set_flashdata('success', 'Thank you for your message. We will get back to you soon.');
            redirect('culinary/contact');
        }
    }    
    
    // Method untuk update kuliner (biasanya dilakukan oleh user pemilik kuliner)
    public function edit($id) {
        // Memastikan user sudah login
        if (!$this->session->userdata('user_logged_in')) {
            redirect('culinary/login');
        }

        $data['culinary'] = $this->Culinary_model->get_by_id($id);

        // Memastikan user hanya bisa mengedit kuliner yang dimiliki
        if ($this->session->userdata('user_id') != $data['culinary']->user_id) {
            redirect('culinary/index');
        }

        if ($this->input->post()) {
            $update_data = array(
                'name' => $this->input->post('name'),
                'description' => $this->input->post('description'),
                'location' => $this->input->post('location'),
                'category_id' => $this->input->post('category_id')
            );

            // Menghandle update foto jika di-upload ulang
            if (!empty($_FILES['photo']['name'])) {
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|jpeg|png';
                $config['max_size'] = 2048; // Batas ukuran file maksimal 2MB
                $this->load->library('upload', $config);

                if ($this->upload->do_upload('photo')) {
                    $update_data['photo'] = $this->upload->data('file_name');
                } else {
                    // Menampilkan pesan error jika upload gagal
                    $data['error'] = $this->upload->display_errors();
                    $this->load->view('culinary/edit', $data);
                    return;
                }
            }

            // Update data kuliner
            $this->Culinary_model->update($id, $update_data);
            redirect('culinary/index');
        }
        

        // Load view untuk edit kuliner
        $this->load->view('culinary/edit', $data);
    }
}
