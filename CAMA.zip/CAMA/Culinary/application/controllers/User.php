<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('session');
        $this->load->helper(array('form', 'url'));
    }

    // Fungsi untuk login user
    public function login() {
        if ($this->input->post()) {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $user = $this->User_model->get_user_by_email($email);

            if ($user && password_verify($password, $user->password)) {
                // Set session data
                $session_data = array(
                    'user_id' => $user->id,
                    'username' => $user->username,
                    'role' => $user->role,
                    'logged_in' => TRUE
                );
                $this->session->set_userdata($session_data);

                // Log aktivitas: User berhasil login
                $log_data = array(
                    'user_id' => $user->id,
                    'activity' => 'User logged in',
                    'created_at' => date('Y-m-d H:i:s')
                );
                $this->User_model->insert_activity_log($log_data); // Fungsi untuk menyimpan log

                // Redirect berdasarkan peran user
                if ($user->role == 'admin') {
                    redirect('admin/dashboard');
                } else {
                    redirect('culinary/index');
                }
            } else {
                $this->session->set_flashdata('error', 'Email atau password salah');
                redirect('user/login');
            }
        }
        $this->load->view('user/login');
    }

    // Fungsi untuk registrasi user baru
    public function register() {
        if ($this->input->post()) {
            // Ambil data dari form
            $username = $this->input->post('username');
            $email = $this->input->post('email');
            $password = password_hash($this->input->post('password'), PASSWORD_BCRYPT);
    
            // Validasi input
            if (empty($username) || empty($email) || empty($password)) {
                $this->session->set_flashdata('error', 'Semua field wajib diisi.');
                redirect('user/register');
            }
    
            // Buat data array untuk insert
            $data = array(
                'username' => $username,
                'email' => $email,
                'password' => $password,
                'role' => 'user' // Default role adalah 'user'
            );
    
            // Panggil fungsi insert_user di model User_model
            if ($this->User_model->insert_user($data)) {
                // Log aktivitas: User berhasil registrasi
                $log_data = array(
                    'user_id' => $this->db->insert_id(), // Mengambil ID dari user yang baru saja dibuat
                    'activity' => 'User registered',
                    'created_at' => date('Y-m-d H:i:s')
                );
                $this->User_model->insert_activity_log($log_data); // Fungsi untuk menyimpan log
    
                $this->session->set_flashdata('success', 'Registrasi berhasil, silakan login.');
                redirect('culinary/login');
            } else {
                $this->session->set_flashdata('error', 'Gagal melakukan registrasi, silakan coba lagi.');
                redirect('user/register');
            }
        }
    
        $this->load->view('user/register');
    }
    
    

    // Fungsi untuk logout user
    public function logout() {
        $user_id = $this->session->userdata('user_id');

        // Log aktivitas: User logout
        $log_data = array(
            'user_id' => $user_id,
            'activity' => 'User logged out',
            'created_at' => date('Y-m-d H:i:s')
        );
        $this->User_model->insert_activity_log($log_data); // Fungsi untuk menyimpan log

        // Hancurkan session untuk logout user
        $this->session->sess_destroy();
        redirect('user/login');
    }
}
