<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load model dan library yang dibutuhkan
        $this->load->model('Culinary_model');
        $this->load->model('Review_model');
        $this->load->model('Category_model');
        $this->load->model('User_model');
        $this->load->model('UserActivityLog_model');
        $this->load->model('PageView_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library('session', 'form_validation');

    }

    // Fungsi untuk login admin
    public function login() {
        if ($this->input->post()) {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            // Hardcoded admin login, bisa diganti dengan data dari database jika diperlukan
            if ($email == 'admin@cama.com' && $password == 'admin') {
                // Mengatur session untuk admin
                $this->session->set_userdata('admin_logged_in', true);
                $this->session->set_userdata('role', 'admin');
                redirect('admin/dashboard');
            } else {
                $data['error'] = "Email atau password salah";
                $this->load->view('admin/login', $data);
            }
        } else {
            $this->load->view('admin/login');
        }
    }

    // Fungsi untuk logout admin
    public function logout() {
        // Menghapus session saat logout
        $this->session->unset_userdata('admin_logged_in');
        $this->session->unset_userdata('role');
        redirect('admin/login');
    }

    // Fungsi untuk menampilkan dashboard admin
    public function dashboard() {
        // Pastikan admin telah login
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }

        // Ambil total data dari database
        $data['total_kuliner'] = $this->Culinary_model->count_approved_culinaries();
        $data['login_page_views'] = $this->PageView_model->get_view_count('login');
        $data['total_pengguna'] = $this->User_model->count_all_users();
        $data['total_kategori'] = $this->Category_model->count_all();
        $data['logs'] = $this->User_model->get_recent_logs(10);
        // Load view dengan data
        $this->load->view('admin/dashboard', $data);
    }

    // Fungsi untuk memverifikasi kuliner yang ditambahkan pengguna
    public function verifikasi() {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }

        // Ambil semua kuliner yang menunggu persetujuan dan tampilkan pada halaman verifikasi
        $data['pending_culinaries'] = $this->Culinary_model->get_all_pending();
        $this->load->view('admin/verifikasi_kuliner', $data);
    }

    // Fungsi untuk melihat kategori yang ada
    public function kategori() {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
        
        $data['categories'] = $this->Category_model->get_all();
        $this->load->view('admin/kategori', $data);
    }

    // Fungsi untuk menambah kategori baru
    public function tambah_kategori() {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }

        if ($this->input->post()) {
            $data = array(
                'name' => $this->input->post('name'),
            );
            $this->Category_model->insert($data);
            redirect('admin/kategori');
        }
        
        $this->load->view('admin/tambah_kategori');
    }

    // Fungsi untuk mengedit kategori
    public function edit_kategori($id) {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
    
        // Dapatkan data kategori berdasarkan ID
        $data['category'] = $this->Category_model->get_by_id($id);
    
        if ($this->input->post()) {
            // Update data kategori
            $update_data = array(
                'name' => $this->input->post('name')
            );
            $this->Category_model->update($id, $update_data);
            redirect('admin/kategori');
        }
    
        $this->load->view('admin/edit_kategori', $data);
    }

    // Fungsi untuk menghapus kategori
    public function delete_kategori($id) {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
        
        // Pastikan ID tidak kosong
        if (!empty($id)) {
            // Gunakan model untuk menghapus kategori berdasarkan ID
            $this->Category_model->delete($id);
            $this->session->set_flashdata('success', 'Kategori berhasil dihapus');
        } else {
            $this->session->set_flashdata('error', 'ID kategori tidak valid');
        }
    
        redirect('admin/kategori');
    }
    public function contact_messages() {
        $this->load->model('Contact_model');
        $data['messages'] = $this->Contact_model->get_all_messages();
        $this->load->view('admin/contact_messages', $data);
    }    

    public function kuliner() {
        $this->load->model('Culinary_model');
        $this->load->library('pagination');
        
        // Ambil total jumlah kuliner yang sudah disetujui
        $total_rows = $this->Culinary_model->get_approved_count();
        
        // Pastikan total_rows adalah angka yang valid
        $total_rows = is_numeric($total_rows) ? $total_rows : 0;
        
        // Konfigurasi pagination
        $config['base_url'] = site_url('admin/kuliner');
        $config['total_rows'] = $total_rows; // Total jumlah kuliner yang valid
        $config['per_page'] = 12; // Menampilkan 12 kuliner per halaman
        $config['uri_segment'] = 3;  // Segment ke-3 untuk halaman
        
        // Pengaturan pagination lainnya
        $config['full_tag_open'] = '<nav><ul class="pagination justify-center space-x-2">';
        $config['full_tag_close'] = '</ul></nav>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
        $config['next_tag_open'] = '<li><a class="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100" href="#">';
        $config['next_tag_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li><a class="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100" href="#">';
        $config['prev_tag_close'] = '</a></li>';
        
        // Inisialisasi pagination
        $this->pagination->initialize($config);
        
        // Ambil halaman saat ini dan pastikan itu adalah integer
        $page = $this->uri->segment(3, 0);  // Jika segment 3 tidak ada, defaultkan ke 0
        
        // Pastikan page adalah integer
        $page = (int) $page;
        
        // Ambil data kuliner berdasarkan pagination
        $data['culinaries'] = $this->Culinary_model->get_all_approved($config['per_page'], $page);
        
        // Tentukan current_page dan total_pages
        $data['current_page'] = ($page / $config['per_page']) + 1;
        $data['total_pages'] = ceil($total_rows / $config['per_page']);
        
        // Load view dengan data kuliner
        $this->load->view('admin/kuliner', $data);
    }
    
    

    // Fungsi untuk menampilkan halaman form edit kuliner
public function edit_kuliner($id) {
    if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
    }

    // Ambil data kuliner berdasarkan ID
    $data['kuliner'] = $this->Culinary_model->get_culinary_by_id($id);
    $data['categories'] = $this->Category_model->get_all_categories();

    if (empty($data['kuliner'])) {
        show_404(); // Jika kuliner tidak ditemukan
    }

    // Tampilkan halaman edit kuliner
    $this->load->view('admin/edit_kuliner', $data);
}

// Fungsi untuk update kuliner
public function update_kuliner() {
    $id = $this->input->post('id');  // Ambil ID kuliner dari form
    
    // Validasi input form
    $this->form_validation->set_rules('name', 'Nama Kuliner', 'required');
    $this->form_validation->set_rules('description', 'Deskripsi', 'required');
    $this->form_validation->set_rules('ingredients', 'Bahan-bahan', 'required');
    $this->form_validation->set_rules('category_id', 'Kategori', 'required');
    $this->form_validation->set_rules('location', 'Lokasi', 'required');

     // Menambahkan validasi untuk youtube_video_id dan google_maps_location jika diperlukan
     $this->form_validation->set_rules('youtube_video_id', 'YouTube Video ID', 'required');
     $this->form_validation->set_rules('google_maps_location', 'Google Maps Location', 'required');
    
    if ($this->form_validation->run() == FALSE) {
        // Jika validasi gagal, kembali ke halaman edit dengan pesan error
        $data['kuliner'] = $this->Culinary_model->get_culinary_by_id($id);
        $data['categories'] = $this->Category_model->get_all_categories();
        $this->load->view('admin/edit_kuliner', $data);
    } else {
        // Jika validasi berhasil, lakukan update
        $data = [
            'name' => $this->input->post('name'),
            'description' => $this->input->post('description'),
            'ingredients' => $this->input->post('ingredients'),
            'category_id' => $this->input->post('category_id'),
            'location' => $this->input->post('location'),
            'youtube_video_id' => $this->input->post('youtube_video_id'),
            'google_maps_location' => $this->input->post('google_maps_location'),
        ];

        // Jika ada foto baru yang diupload
        if (!empty($_FILES['photo']['name'])) {
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name'] = time() . $_FILES['photo']['name']; // Menambahkan timestamp agar nama unik

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('photo')) {
                $uploaded_data = $this->upload->data();
                $data['photo'] = $uploaded_data['file_name']; // Menyimpan nama file foto
            } else {
                // Jika gagal upload, kirim pesan error
                $this->session->set_flashdata('error', 'Gagal meng-upload foto kuliner');
                redirect('admin/edit_kuliner/' . $id);
            }
        }


        // Update kuliner di database
        if ($this->Culinary_model->update_culinary($id, $data)) {
            // Jika update berhasil, redirect ke halaman daftar kuliner dengan pesan sukses
            $this->session->set_flashdata('success', 'Kuliner berhasil diperbarui');
            redirect('admin/kuliner'); // Redirect ke halaman daftar kuliner
        } else {
            // Jika update gagal, redirect kembali ke halaman edit kuliner dengan pesan error
            $this->session->set_flashdata('error', 'Gagal memperbarui kuliner');
            redirect('admin/edit_kuliner/' . $id); // Kembali ke halaman edit kuliner
        }
    }
}

    // Fungsi untuk menghapus kuliner
    public function delete_kuliner($id) {
        if ($this->Culinary_model->delete_culinary($id)) {
            $this->session->set_flashdata('success', 'Kuliner berhasil dihapus');
            redirect('admin/kuliner');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus kuliner');
            redirect('admin/kuliner');
        }
    }

    public function tambah_kuliner()
    {
        // Mengambil data kategori untuk dropdown
        $data['categories'] = $this->Category_model->get_all();

        // Tampilkan halaman tambah kuliner
        $this->load->view('admin/tambah_kuliner', $data);
    }

    // Menyimpan data kuliner
    public function simpan_kuliner() {
        // Mengambil data yang dikirimkan melalui POST
        $data_insert = array(
            'name' => $this->input->post('name'),
            'description' => $this->input->post('description'),
            'location' => $this->input->post('location'),
            'category_id' => $this->input->post('category_id'),
            'user_id' => 1, // Admin ID hardcoded atau sesuai dengan session jika ada
            'ingredients' => $this->input->post('ingredients'),
            'youtube_video_id' => $this->input->post('youtube_video_id'),
            'google_maps_location' => $this->input->post('google_maps_location'),
            'status' => 'approved' // Status langsung diset menjadi approved
        );
    
        // Menangani upload foto kuliner
        if (!empty($_FILES['photo']['name'])) {
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['max_size'] = 2048;  // Maksimum ukuran file 2MB
            $this->load->library('upload', $config);
    
            if ($this->upload->do_upload('photo')) {
                $data_insert['photo'] = $this->upload->data('file_name');
            } else {
                // Jika upload gagal, tampilkan pesan error
                $this->session->set_flashdata('error', 'Error saat mengupload foto: ' . $this->upload->display_errors());
                $this->load->view('admin/tambah_kuliner');
                return;
            }
        }
    
        // Insert data kuliner ke dalam database
        if ($this->Culinary_model->insert($data_insert)) {
            // Set flashdata untuk pesan sukses
            $this->session->set_flashdata('success', 'Kuliner berhasil ditambahkan.');
            redirect('admin/kuliner'); // Redirect ke halaman daftar kuliner
        } else {
            // Jika gagal, beri pesan error
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat menyimpan kuliner.');
            $this->load->view('admin/tambah_kuliner');
        }
    }
    

    // Fungsi untuk mengelola pengguna
    public function pengguna() {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
    
        // Mengambil semua data pengguna dengan memanggil metode dari User_model
        $data['users'] = $this->User_model->get_all_users();
        $this->load->view('admin/pengguna', $data); // Pastikan ada view 'pengguna' untuk menampilkan data
    }

    // Fungsi untuk mengedit pengguna
    public function edit_pengguna($id) {
        // Ambil data pengguna berdasarkan ID
        $data['user'] = $this->User_model->get_user_by_id($id);
    
        // Jika form disubmit
        if ($this->input->post()) {
            // Ambil data dari form
            $update_data = [
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'role' => $this->input->post('role'),
                'phone' => $this->input->post('phone'),
                'address' => $this->input->post('address'),
            ];
    
            // Update data di database
            $this->User_model->update_user($id, $update_data);
    
            // Redirect ke halaman daftar pengguna
            redirect('admin/pengguna');
        }
    
        // Tampilkan view edit pengguna
        $this->load->view('admin/edit_pengguna', $data);
    }

    // Fungsi untuk menghapus pengguna
    public function delete_pengguna($id) {
        // Delete related records in user_activity_logs first
        $this->db->where('User_id', $id);
        $this->db->delete('User_activity_logs');

        // Now delete the user from users table
        if ($this->User_model->delete($id)) {
            $this->session->set_flashdata('success', 'Pengguna berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus pengguna.');
        }
        redirect('admin/pengguna');
    }    

// Fungsi untuk menyetujui kuliner (approve)
public function approve($id) {
    if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
    }

    // Setujui kuliner dengan mengubah statusnya menjadi 'approved'
    if ($this->Culinary_model->update_status($id, 'approved')) {
        $this->session->set_flashdata('success', 'Kuliner berhasil disetujui.');
    } else {
        $this->session->set_flashdata('error', 'Gagal menyetujui kuliner.');
    }

    redirect('admin/verifikasi_kuliner');
}

// Fungsi untuk menolak kuliner (reject)
public function reject($id) {
    if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
    }

    // Mengubah status kuliner menjadi 'rejected' atau menghapus kuliner
    if ($this->Culinary_model->delete_culinary($id)) {
        $this->session->set_flashdata('success', 'Kuliner berhasil ditolak dan dihapus.');
    } else {
        $this->session->set_flashdata('error', 'Gagal menolak kuliner.');
    }

    redirect('admin/verifikasi_kuliner');
}


// Fungsi untuk menampilkan daftar kuliner yang menunggu persetujuan
public function verifikasi_kuliner() {
    if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
    }

    // Mengambil daftar kuliner dengan status 'pending'
    $data['pending_culinaries'] = $this->Culinary_model->get_all_pending();
    $this->load->view('admin/verifikasi_kuliner', $data);
}



    public function manage_news() {
        // Ambil semua data berita dari model
        $data['news'] = $this->News_model->get_all_news();
        // Panggil view untuk menampilkan daftar berita
        $this->load->view('admin/news_list', $data);
    }

    // Halaman untuk menambah berita
    public function add_news() {
        // Menampilkan view untuk menambah berita
        $this->load->view('admin/add_news');
    }

    public function create_news() {
        // Menyimpan berita yang baru ditambahkan
        $data = array(
            'title' => $this->input->post('title'),
            'content' => $this->input->post('content'),
            'image_url' => $this->input->post('image_url'),
            'created_at' => date('Y-m-d H:i:s')
        );
        if ($this->News_model->add_news($data)) {
            redirect('admin/manage_news');  // Redirect ke halaman manage_news setelah tambah berita
        } else {
            $this->session->set_flashdata('error', 'Gagal menambah berita.');
            redirect('admin/add_news');
        }
    }
    
    public function edit_news($id) {
        // Mengambil data berita berdasarkan ID
        $data['news'] = $this->News_model->get_news_by_id($id);
        $this->load->view('admin/edit_news', $data);  // Tampilkan view edit_news dengan data berita
    }
    
    public function update_news($id) {
        // Update berita dengan data baru
        $data = array(
            'title' => $this->input->post('title'),
            'content' => $this->input->post('content'),
            'image_url' => $this->input->post('image_url')
        );
        if ($this->News_model->update_news($id, $data)) {
            redirect('admin/manage_news');
        } else {
            $this->session->set_flashdata('error', 'Gagal mengupdate berita.');
            redirect('admin/edit_news/'.$id);
        }
    }
    
    // Menghapus berita
    public function delete_news($id) {
        if ($this->News_model->delete_news($id)) {
            redirect('admin/manage_news');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus berita.');
            redirect('admin/manage_news');
        }
    }

    // Halaman utama admin, menampilkan semua ulasan
    public function review_list() {
        // Ambil ulasan dengan informasi kuliner
        $data['reviews'] = $this->Review_model->get_reviews_with_culinary();
        
        // Muat tampilan dengan data ulasan
        $this->load->view('admin/review_list', $data);
    }
    
    // Hapus ulasan berdasarkan ID
    public function delete_review($id) {
        // Memanggil model untuk menghapus review
        $this->Review_model->delete_review($id);
        // Set flash message untuk konfirmasi
        $this->session->set_flashdata('message', 'Review berhasil dihapus!');
        redirect('admin/review_list');
    }
    
}
