<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('News_model');
    }

    // Halaman utama untuk menampilkan berita
    public function index() {
        $data['news'] = $this->News_model->get_all_news();
        $this->load->view('admin/news_list', $data);
    }

    // Halaman untuk menambahkan berita
    public function add() {
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $data = [
                'title' => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'image_url' => $this->input->post('image_url'),
                'link_url' => $this->input->post('link_url')
            ];

            // Panggil model untuk menambahkan berita
            $this->News_model->add_news($data);

            // Redirect setelah berhasil
            redirect('admin/news');
        }

        // Jika bukan POST, tampilkan form tambah berita
        $this->load->view('admin/news_add');
    }

    // Halaman untuk mengedit berita
    public function edit($id) {
        $data['news'] = $this->News_model->get_news_by_id($id);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data_update = array(
                'title' => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'image_url' => $this->input->post('image_url'),
                'link_url' => $this->input->post('link_url')
            );

            $this->News_model->update_news($id, $data_update);
            redirect('news');
        }

        $this->load->view('admin/news_edit', $data);
    }

    // Menghapus berita
    public function delete($id) {
        $this->News_model->delete_news($id);
        redirect('news');
    }
}
?>
