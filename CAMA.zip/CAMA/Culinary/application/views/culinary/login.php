<?php $this->load->view('layouts/header'); ?>

<style>
    /* Styling untuk bagian video */
    .login-container video {
        object-fit: cover;
        width: 100%;
        height: 100%;
    }

    /* Efek animasi muncul */
    .fade-in {
        animation: fadeIn 1s ease-in-out;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Animasi alert */
    .alert {
        animation: slideIn 0.5s ease;
    }

    @keyframes slideIn {
        from {
            transform: translateX(-50%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Styling form login */
    .form-control {
        border-radius: 0.5rem;
        border: 1px solid #ddd;
    }

    .btn-dark {
        border-radius: 0.5rem;
        font-weight: bold;
        transition: all 0.3s ease-in-out;
    }

    .btn-dark:hover {
        background-color: #333;
        transform: scale(1.05);
    }

    /* Background warna putih pada form login */
    .login-container .col-md-6 {
        background-color: #f9f9f9;
        padding: 30px;
        border-radius: 0.5rem;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }

    /* Teks Register berwarna merah */
    .register-link {
        color: #e84949;
        font-weight: bold;
        text-decoration: none;
        transition: color 0.3s ease, transform 0.3s ease;
    }

    .register-link:hover {
        color: #d43636;
        transform: scale(1.1);
    }

    /* Responsif */
    @media (max-width: 768px) {
        .login-container video {
            display: none;
        }
        .login-container .col-md-6 {
            width: 100%;
            border-radius: 0;
            box-shadow: none;
        }
    }
</style>

<div class="container-fluid login-container vh-100 d-flex">
    <div class="row w-100 align-items-center">
        <!-- Bagian Video Samping -->
        <div class="col-md-6 d-none d-md-flex align-items-center justify-content-center bg-light p-0">
            <video src="<?= base_url('assets/images/makassar.mp4') ?>" autoplay loop muted></video>
        </div>

        <!-- Bagian Form Login -->
        <div class="col-md-6 d-flex align-items-center justify-content-center">
            <div class="w-75 fade-in">
                <div class="text-center mb-4">
                    <!-- Logo dan Nama Aplikasi -->
                    <img src="<?= base_url('assets/images/1.png') ?>" class="img-fluid mb-3" alt="Logo Culinary Makassar" style="max-width: 100px;">
                    <h2 class="fw-bold">Ca'ma Culinary</h2>
                </div>

                <!-- Form Login -->
                <?php echo form_open('culinary/login'); ?>
                
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger text-center">
                        <?= $error ?>
                    </div>
                <?php endif; ?>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email Anda" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password Anda" required>
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="remember_me" name="remember_me">
                    <label class="form-check-label" for="remember_me">Ingat Saya</label>
                </div>
                <button type="submit" class="btn btn-dark w-100">Log in</button>

                <?php echo form_close(); ?>

                <!-- Link Reset Password -->
                <div class="mt-3 text-center">
                    <p>Lupa password? <a href="<?= site_url('culinary/reset_password') ?>" class="register-link">Reset Password</a>.</p>
                </div>

                <!-- Link ke Halaman Register -->
                <div class="mt-3 text-center">
                    <p>Belum punya akun? <a href="<?= site_url('culinary/register') ?>" class="register-link">Register</a> sekarang.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('layouts/footer'); ?>