<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('layouts/header'); ?>
    <title>Kuliner</title>
    <style>
        /* Make the cards responsive and apply smooth hover effect */
        .card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
            transition: transform 0.3s ease-in-out;
            margin-bottom: 20px;
        }

        /* Hover effect to lift card */
        .card:hover {
            transform: translateY(-10px); /* Slight lift effect */
        }

        /* Image settings */
        .card-img-top {
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        /* Slight zoom effect on image hover */
        .card:hover .card-img-top {
            transform: scale(1.05); /* Zoom effect */
        }

        /* Card body: Ensure content fills space and button stays at the bottom */
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }

        .card-title, .card-text {
            margin-bottom: 10px;
        }

        /* Ensure View Details buttons align properly */
        .card-body .btn {
            margin-top: auto; /* Push the button to the bottom */
        }

        /* Pagination container style */
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            gap: 10px;
        }

        .pagination-container .btn {
            min-width: 40px;
            border-radius: 50%;
        }

        /* Responsive breakpoints */
        @media (max-width: 576px) {
            .card-img-top {
                height: 150px;
            }
        }

        @media (min-width: 577px) and (max-width: 768px) {
            .card-img-top {
                height: 180px;
            }
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center mb-5">Kuliner</h2>
        <div class="row g-3 culinary-list" data-items-per-page="8">
            <?php
                // Collect all culinary items in a single array
                $allCulinaries = [];
                foreach ($categories as $category) {
                    if (!empty($culinaries[$category->name])) {
                        $allCulinaries = array_merge($allCulinaries, $culinaries[$category->name]);
                    }
                }
            ?>

            <?php foreach ($allCulinaries as $index => $culinary): ?>
                <div class="col-lg-3 col-md-4 col-sm-6 culinary-item" style="opacity: <?= $index < 8 ? '1' : '0'; ?>; display: <?= $index < 8 ? 'block' : 'none'; ?>;">
                    <div class="card h-100 shadow-sm">
                        <img src="<?= base_url('uploads/' . htmlspecialchars($culinary->photo)) ?>" class="card-img-top" alt="<?= htmlspecialchars($culinary->name) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($culinary->name) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($culinary->description) ?></p>
                            <a href="<?= site_url('culinary/detail/' . $culinary->id) ?>" class="btn btn-primary w-100">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination Buttons -->
        <div class="pagination-container">
            <button class="btn btn-outline-secondary prev-btn" disabled>&lt;</button>
            <button class="btn btn-outline-secondary next-btn">&gt;</button>
        </div>
    </div>

    <?php $this->load->view('layouts/footer'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const list = document.querySelector('.culinary-list');
            const items = list.querySelectorAll('.culinary-item');
            const itemsPerPage = parseInt(list.dataset.itemsPerPage, 10);
            const totalPages = Math.ceil(items.length / itemsPerPage);
            let currentPage = 1;

            const paginationContainer = document.querySelector('.pagination-container');
            const prevButton = paginationContainer.querySelector('.prev-btn');
            const nextButton = paginationContainer.querySelector('.next-btn');

            const updatePagination = () => {
                items.forEach((item, index) => {
                    const start = (currentPage - 1) * itemsPerPage;
                    const end = currentPage * itemsPerPage;
                    if (index >= start && index < end) {
                        item.style.opacity = '1';
                        item.style.display = 'block';
                    } else {
                        item.style.opacity = '0';
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });

                prevButton.disabled = currentPage === 1;
                nextButton.disabled = currentPage === totalPages;
            };

            prevButton.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage--;
                    updatePagination();
                }
            });

            nextButton.addEventListener('click', () => {
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePagination();
                }
            });

            updatePagination();
        });
    </script>
</body>

</html>
