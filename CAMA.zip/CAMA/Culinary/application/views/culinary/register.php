<?php $this->load->view('layouts/header'); ?>

<style>
    /* Animasi fade-in */
    .fade-in {
        animation: fadeIn 1s ease-in-out;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Card Styling */
    .card {
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: scale(1.02);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
    }

    .card-header {
        background: linear-gradient(90deg, #e84949, #f05d5d);
        color: white;
        font-weight: bold;
        font-size: 1.5rem;
    }

    .card-body {
        padding: 20px;
    }

    .form-control {
        border-radius: 0.5rem;
        border: 1px solid #ddd;
    }

    .btn-dark {
        border-radius: 0.5rem;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .btn-dark:hover {
        background-color: #333;
        transform: scale(1.05);
    }

    .card-footer {
        background: #f9f9f9;
        border-top: 1px solid #ddd;
    }

    .card-footer a {
        color: #e84949;
        font-weight: bold;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .card-footer a:hover {
        color: #f05d5d;
    }

    /* Responsif */
    @media (max-width: 768px) {
        .card {
            margin: 20px;
        }
    }
</style>

<div class="container mt-5 fade-in">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    Register
                </div>
                <div class="card-body">
                    <?php echo form_open('user/register'); ?>
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username Anda" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email Anda" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password Anda" required>
                    </div>

                    <button type="submit" class="btn btn-dark w-100">Register</button>
                    
                    <?php echo form_close(); ?>
                </div>
                <div class="card-footer text-center">
                    <p>Sudah punya akun? <a href="<?= site_url('culinary/login') ?>">Login</a> sekarang.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('layouts/footer'); ?>
