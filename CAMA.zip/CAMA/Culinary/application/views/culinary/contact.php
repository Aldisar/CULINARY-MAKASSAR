<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Ca'ma: Culinary Makassar</title>
    
    <style>
        .contact-card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
            margin: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }

        .contact-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }

        .contact-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .bg-main-office {
            background-color: #f8f9fa;
        }

        .bg-phone-number {
            background-color: #e3f2fd;
        }

        .bg-instagram {
            background-color: #fce4ec;
        }

        .bg-email {
            background-color: #e8f5e9;
        }

        /* Styling untuk form */
        form {
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .btn-primary {
            border-radius: 0.5rem;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        /* Responsive grid spacing */
        @media (max-width: 768px) {
            .contact-card {
                margin-bottom: 20px;
            }
        }
    </style>
</head>

<body>
    <?php $this->load->view('layouts/header'); ?>

    <div class="container mt-5">
        <h1 class="text-center mb-5">Contact Us</h1>
        <div class="row justify-content-center">
            <!-- Our Main Office -->
            <div class="col-md-3">
                <a href="https://www.google.com/maps?q=Jalan+Mappala+blok+A+no+12" target="_blank" class="text-decoration-none">
                    <div class="contact-card text-center bg-main-office">
                        <i class="fas fa-map-marker-alt contact-icon text-danger"></i>
                        <h5 class="text-dark">Our Main Office</h5>
                        <p class="text-dark">Jalan Mappala blok A no 12</p>
                    </div>
                </a>
            </div>

            <!-- Phone Number -->
            <div class="col-md-3">
                <a href="tel:082193476630" class="text-decoration-none">
                    <div class="contact-card text-center bg-phone-number">
                        <i class="fas fa-phone contact-icon text-primary"></i>
                        <h5 class="text-dark">Phone Number</h5>
                        <p class="text-dark">082193476630</p>
                    </div>
                </a>
            </div>

            <!-- Instagram -->
            <div class="col-md-3">
                <a href="https://www.instagram.com/culinary_makassar_" target="_blank" class="text-decoration-none">
                    <div class="contact-card text-center bg-instagram">
                        <i class="fab fa-instagram contact-icon text-info"></i>
                        <h5 class="text-dark">Instagram</h5>
                        <p class="text-dark">@culinary_makassar_</p>
                    </div>
                </a>
            </div>

            <!-- Email -->
            <div class="col-md-3">
                <a href="mailto:cama@gmail.com" class="text-decoration-none">
                    <div class="contact-card text-center bg-email">
                        <i class="fas fa-envelope contact-icon text-success"></i>
                        <h5 class="text-dark">Email</h5>
                        <p class="text-dark">Ca'ma@gmail.com</p>
                    </div>
                </a>
            </div>
        </div>

        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <h4>Contact Form</h4>
                <form action="<?= site_url('contact/submit_message') ?>" method="POST">
                    <!-- CSRF Token -->
                    <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" />

                    <div class="mb-3">
                        <label for="name" class="form-label">Enter your Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your Name" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Enter a valid email address</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                    </div>

                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="4" placeholder="Enter your message" required></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <?php $this->load->view('layouts/footer'); ?>
    

</body>

</html>
