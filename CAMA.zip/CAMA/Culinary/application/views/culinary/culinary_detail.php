<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($culinary->name) ?> - Detail</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8f9fa;
    color: #333;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    margin: 0;
}

/* Container utama */
.container {
    flex: 1; /* Membuat container mengisi sisa ruang */
}

/* Footer */
footer {
    width: 100%; /* Footer penuh lebar */
    margin-top: auto; /* Footer selalu berada di bawah */
    background-color: #d9534f; /* Sesuaikan warna footer */
}

/* Menghilangkan padding kiri dan kanan pada footer container */
footer .container-fluid {
    padding-left: 0;
    padding-right: 0;
}

/* Bagian bawah footer yang berwarna hitam */
footer .bg-dark {
    background-color: #343a40;
}

/* Menata footer agar selalu berada di bagian bawah */
footer .text-center {
    text-align: center;
    padding: 20px 0;
}



        .hero-section {
            background-image: url('<?= base_url('uploads/' . htmlspecialchars($culinary->photo)) ?>');
            background-size: cover;
            background-position: center;
            height: 350px;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
        }

        .hero-text {
            position: relative;
            z-index: 2;
            text-align: center;
            padding: 20px;
        }

        .hero-text h1 {
            font-size: 2rem;
            font-weight: bold;
        }

        .hero-text p {
            font-size: 1.2rem;
            margin-top: 10px;
        }

        @media (max-width: 768px) {
            .hero-section {
                height: 250px;
            }

            .hero-text h1 {
                font-size: 1.5rem;
            }

            .hero-text p {
                font-size: 1rem;
            }
        }

        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .star-rating .fa-star {
            font-size: 1.2rem;
            color: #e6e6e6;
        }

        .star-rating .fa-star.checked {
            color: #ffc107;
        }
        .resep-container {
    max-height: 200px; /* Atur tinggi maksimum yang diinginkan */
    overflow-y: auto;  /* Menambahkan scroll vertikal jika konten lebih panjang dari tinggi maksimum */
}

    </style>
</head>

<body>
    <?php $this->load->view('layouts/header'); ?>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-text">
            <h1><?= htmlspecialchars($culinary->name) ?></h1>
            <p><?= htmlspecialchars($culinary->description) ?></p>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <!-- Left Section -->
            <div class="col-lg-8 col-md-12">
                <h3>Detail Kuliner</h3>
                <p><?= htmlspecialchars($culinary->description) ?></p>

                <h3 class="mt-4">Lokasi</h3>
                <p><?= htmlspecialchars($culinary->location) ?></p>

                <div class="my-4">
                <h3>Ringkasan Ulasan</h3>
                <?php if ($totalReviews > 0): ?>
                    <div>
                        <h1 class="display-5"><?= number_format($averageRating, 1) ?></h1>
                        <div class="star-rating">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?php if ($i <= floor($averageRating)): ?>
                                    <i class="fas fa-star checked"></i>  <!-- Bintang penuh -->
                                <?php elseif ($i - $averageRating < 1): ?>
                                    <i class="fas fa-star-half-alt checked"></i>  <!-- Bintang setengah -->
                                <?php else: ?>
                                    <i class="far fa-star"></i>  <!-- Bintang kosong -->
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <p><?= $totalReviews ?> ulasan</p>
                    </div>
                <?php else: ?>
                    <p>Belum ada ulasan untuk kuliner ini.</p>
                <?php endif; ?>
            </div>

            <h3>Review Pengguna</h3>
            <?php if (!empty($reviews)): ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <p><?= htmlspecialchars($review->comment) ?></p>
                            <div class="star-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= $review->rating): ?>
                                        <i class="fas fa-star checked"></i> <!-- Bintang penuh -->
                                    <?php else: ?>
                                        <i class="far fa-star"></i> <!-- Bintang kosong -->
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada review untuk kuliner ini.</p>
            <?php endif; ?>

            <?php if ($this->session->userdata('user_logged_in')): ?>
                <?php if ($user_reviewed): ?>
                    <p>Anda sudah memberikan review untuk kuliner ini.</p>
                <?php else: ?>
                    <h3>Tambahkan Review</h3>
                    <form id="review-form" action="<?= site_url('culinary/add_review/' . $culinary->id) ?>" method="post">
                        <!-- Menambahkan CSRF Token -->
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                        <div class="mb-3">
                            <label for="review_text" class="form-label">Review</label>
                            <textarea class="form-control" id="review_text" name="comment" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="rating" class="form-label">Rating</label>
                            <select class="form-select" id="rating" name="rating" required>
                                <option value="">Pilih rating Anda</option>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <option value="<?= $i ?>"><?= $i ?> - <?= str_repeat('★', $i) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Kirim Review</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <p>Silakan <a href="<?= site_url('culinary/login') ?>">login</a> untuk memberikan review.</p>
            <?php endif; ?>
        </div>
 

            <!-- Right Section -->
            <div class="col-lg-4 col-md-12 mt-4 mt-lg-0">
                <?php if (!empty($culinary->youtube_video_id)): ?>
                    <h3>Video Pengantar</h3>
                    <div class="ratio ratio-16x9 mb-4">
                        <iframe src="https://www.youtube.com/embed/<?= htmlspecialchars($culinary->youtube_video_id) ?>" allowfullscreen></iframe>
                    </div>
                <?php endif; ?>
                <!-- Google Maps Section -->
                <?php if (!empty($culinary->location)): ?>
                    <h3>Lokasi Kuliner</h3>
                    <div class="ratio ratio-16x9 mb-4">
                        <iframe src="https://www.google.com/maps?q=<?= urlencode($culinary->location) ?>&output=embed" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                <?php endif; ?>

                <?php if (!empty($culinary->ingredients)): ?>
    <h3>Resep</h3>
    <div class="card mb-3">
        <div class="card-body resep-container"> <!-- Tambahkan class resep-container di sini -->
            <ul class="list-unstyled">
                <?php foreach (explode(',', $culinary->ingredients) as $ingredient): ?>
                    <li class="mb-2"><?= htmlspecialchars(trim($ingredient)); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>

</div>
        </div>
    </div>
    <!-- Footer -->
    <?php $this->load->view('layouts/footer'); ?>


</body>

</html>
