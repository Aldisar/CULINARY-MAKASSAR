<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password - Ca'ma Culinary</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-100 d-flex align-items-center justify-content-center vh-100">
    <div class="reset-container w-75 max-w-md">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Update Password</h2>
            <p class="text-muted">Masukkan password baru Anda.</p>
        </div>

        <?php echo form_open('update-password/' . $token); ?>

        <div class="mb-3">
            <label for="password" class="form-label">Password Baru</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password baru" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Update Password</button>

        <?php echo form_close(); ?>
    </div>
</body>

</html>
