<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }
        body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .container {
            flex-grow: 1; /* Make sure the container expands to take available space */
        }
        .result-list {
            margin-top: 20px;
        }
        .result-list .card {
            margin-bottom: 15px;
        }
        .result-list .card-title {
            font-weight: bold;
        }

        /* Styling for "View Details" button */
        .btn-view-details {
            background-color: #007bff; /* Blue color */
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 5px; /* Rounded corners */
            width: 100%;
            text-align: center; /* Center the text */
            text-decoration: none; /* Remove underline */
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-view-details:hover {
            background-color: #0056b3; /* Darker blue on hover */
            transform: scale(1.05);
        }

    </style>
</head>
<body>
<?php $this->load->view('layouts/header'); ?>
    <div class="container">
        <h1 class="mt-5">Search Results</h1>
        
        <?php if (!empty($results)): ?>
            <div class="row g-3">
                <?php foreach ($results as $culinary): ?>
                    <?php if (is_object($culinary) && isset($culinary->photo) && isset($culinary->name)): ?>
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card h-100 shadow-sm">
                                <img src="<?= base_url('uploads/' . htmlspecialchars($culinary->photo)) ?>" class="card-img-top" alt="<?= htmlspecialchars($culinary->name) ?>">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($culinary->name) ?></h5>
                                    <p class="card-text"><?= htmlspecialchars($culinary->description) ?></p>
                                    <a href="<?= site_url('culinary/detail/' . $culinary->id) ?>" class="btn-view-details">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="mt-3">No results found for your query.</p>
        <?php endif; ?>
    </div>
    <?php $this->load->view('layouts/footer'); ?>
</body>
</html>
