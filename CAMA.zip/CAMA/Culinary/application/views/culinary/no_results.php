<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>No Results</title>
</head>
<body>
    <h1>No Results Found</h1>
    <p>No results found for your search query. Please try again with a different query.</p>
</body>
</html>
