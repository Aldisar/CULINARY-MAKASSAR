<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kuliner Berdasarkan Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Animasi scroll yang smooth */
        @keyframes scrollAnimation {
            0% {
                opacity: 0;
                transform: translateY(50px);
            }

            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Menambahkan animasi scroll pada kategori */
        .category-title {
            opacity: 0;
            margin-top: 40px;
            animation: scrollAnimation 1s ease-out forwards;
        }

        /* Mengatur efek 3D pada teks judul kategori dengan warna gelap */
        .category-title h3 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #333;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            display: inline-block;
            padding: 5px 20px;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }

        /* Memberikan ukuran gambar seragam dan animasi */
        .card-img-top {
            height: 200px;
            object-fit: cover;
            transition: transform 0.5s ease-in-out, opacity 0.5s ease-in-out;
            border-radius: 5px;
        }

        /* Efek hover pada gambar */
        .card:hover .card-img-top {
            transform: scale(1.1);
            opacity: 0.8;
        }

        /* Efek hover pada card */
        .card:hover {
            transform: translateY(-15px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        /* Deskripsi card dengan text overflow */
        .card-text {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        /* Responsif margin untuk kategori */
        @media (max-width: 768px) {
            .category-title {
                margin-top: 20px;
            }

            .category-title h3 {
                font-size: 2rem;
            }
        }

        /* Pagination */
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            gap: 10px;
        }

        .pagination-container .btn {
            min-width: 40px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <?php $this->load->view('layouts/header'); ?>

    <div class="container mt-5">
        <h2 class="text-center mb-5">Daftar Kuliner Berdasarkan Kategori</h2>

        <?php if (!empty($categories)): ?>
            <?php foreach ($categories as $category): ?>
                <div class="category-title" id="<?= strtolower(str_replace(' ', '_', htmlspecialchars($category->name))) ?>">
                    <h3><?= htmlspecialchars($category->name) ?></h3>
                    <div class="row g-3 culinary-list" data-items-per-page="8">
                        <?php if (!empty($culinaries[$category->name])): ?>
                            <?php foreach ($culinaries[$category->name] as $index => $culinary): ?>
                                <?php if (is_object($culinary) && isset($culinary->photo) && isset($culinary->name)): ?>
                                    <div class="col-lg-3 col-md-4 col-sm-6 culinary-item" style="display: <?= $index < 8 ? 'block' : 'none' ?>;">
                                        <div class="card h-100 shadow-sm">
                                            <img src="<?= base_url('uploads/' . htmlspecialchars($culinary->photo)) ?>" class="card-img-top" alt="<?= htmlspecialchars($culinary->name) ?>">
                                            <div class="card-body">
                                                <h5 class="card-title"><?= htmlspecialchars($culinary->name) ?></h5>
                                                <p class="card-text"><?= htmlspecialchars($culinary->description) ?></p>
                                                <a href="<?= site_url('culinary/detail/' . $culinary->id) ?>" class="btn btn-primary w-100">View Details</a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-center text-muted">Tidak ada kuliner untuk kategori ini.</p>
                        <?php endif; ?>
                    </div>
                    <div class="pagination-container">
                        <button class="btn btn-outline-secondary prev-btn" disabled>&lt;</button>
                        <button class="btn btn-outline-secondary next-btn">&gt;</button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">Tidak ada kategori kuliner yang tersedia.</p>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <?php $this->load->view('layouts/footer'); ?>

    <script>
        document.querySelectorAll('.culinary-list').forEach((list) => {
            const items = list.querySelectorAll('.culinary-item');
            const itemsPerPage = parseInt(list.dataset.itemsPerPage, 10);
            const totalPages = Math.ceil(items.length / itemsPerPage);
            let currentPage = 1;

            const paginationContainer = list.nextElementSibling;
            const prevButton = paginationContainer.querySelector('.prev-btn');
            const nextButton = paginationContainer.querySelector('.next-btn');

            const updatePagination = () => {
                items.forEach((item, index) => {
                    item.style.display = (index >= (currentPage - 1) * itemsPerPage && index < currentPage * itemsPerPage) ? 'block' : 'none';
                });

                prevButton.disabled = currentPage === 1;
                nextButton.disabled = currentPage === totalPages;
            };

            prevButton.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage--;
                    updatePagination();
                }
            });

            nextButton.addEventListener('click', () => {
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePagination();
                }
            });

            updatePagination();
        });
    </script>
</body>

</html>
