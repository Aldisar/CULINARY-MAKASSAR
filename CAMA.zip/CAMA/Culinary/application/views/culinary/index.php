<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <title>Daftar Kuliner Makassar</title>
  <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  
  <style>
    /* General Style */
html, body {
  font-family: 'Poppins', sans-serif;
  background-color: #f8f9fa;
  color: #333;
  display: flex;
  flex-direction: column;
  min-height: 100vh; /* Pastikan halaman mengisi seluruh tinggi layar */
  margin: 0; /* Pastikan tidak ada margin yang menyebabkan ruang kosong */
}

/* Konten utama (container) mengambil sisa ruang */
.container {
  flex-grow: 1; /* Konten utama akan mengisi ruang kosong yang tersisa */
}

/* Footer (join-us-section) */
.join-us-section {
  text-align: center;
  padding: 30px 20px;
  background-color: #f8f9fa;
  width: 100%;
  box-sizing: border-box;
  margin-top: auto; /* Pastikan footer di posisi bawah */
}
    /* Tombol Explore */
.btn-explore {
    display: inline-block;
    background-color: #ff6f61;
    color: white;
    padding: 12px 30px;
    font-size: 1.2rem;
    font-weight: bold;
    border-radius: 30px;
    margin-top: 20px;
    text-decoration: none;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

.btn-explore:hover {
    background-color: #e04e47;
    transform: scale(1.05);
}


    /* Section Styling */
    .section {
      background-color: #b23a48;
      color: white;
      padding: 20px;
      border-radius: 50px;
      margin: 20px 0;
    }

    .section h1 {
      font-size: 2em;
      font-weight: bold;
    }

    .section p {
      font-size: 1em;
    }

    .section img {
      max-width: 100%;
      height: auto;
    }

    /* Blog Section */
    .blog-section {
      background-color: #d9534f;
      color: white;
      padding: 40px 20px;
      text-align: center;
      margin-top: 50px;
    }


    .join-us-section button {
      background-color: #d9534f;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      margin-top: 20px;
    }

    /* Hero Section */
    .hero-section {
      background-image: url('<?= base_url('assets/images/LOSARI.jpg') ?>');
      background-size: cover;
      background-position: center;
      height: 600px;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
      animation: slide-background 10s infinite linear;
    }

    .hero-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.8));
      z-index: 1;
    }

    .hero-text {
      z-index: 2;
      text-align: center;
    }

    .hero-text h1 {
      font-size: 3.5rem;
      font-weight: bold;
      text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.8);
      margin-bottom: 20px;
      animation: text-fade 3s ease-in-out infinite alternate;
    }

    .hero-text p {
      font-size: 1.5rem;
      font-style: italic;
      animation: text-slide 3s ease-in-out infinite alternate;
    }

    /* Animations */
    @keyframes text-fade {
      0% {
        color: #f8c471;
        transform: scale(1);
      }
      100% {
        color: #ff6f61;
        transform: scale(1.1);
      }
    }

    @keyframes text-slide {
      0% {
        transform: translateY(0);
        opacity: 0.8;
      }
      100% {
        transform: translateY(10px);
        opacity: 1;
      }
    }

    @keyframes slide-background {
      0% {
        background-position: center top;
      }
      50% {
        background-position: center center;
      }
      100% {
        background-position: center bottom;
      }
    }

    /* Card Section */
    .card {
      border: none;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      overflow: hidden;
      border-radius: 0.5rem;
    }

    .card img {
      height: 200px;
      object-fit: cover;
      border-top-left-radius: 0.5rem;
      border-top-right-radius: 0.5rem;
      transition: transform 0.5s ease;
    }

    .card:hover img {
      transform: scale(1.1);
    }

    .card:hover {
      transform: scale(1.05);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    }

    .card-title {
      font-size: 1.3rem;
      font-weight: bold;
      text-align: center;
      margin-bottom: 10px;
      color: #333;
    }

    .btn-primary {
      background-color: #ff6f61;
      border: none;
      transition: background-color 0.3s ease, transform 0.2s ease;
      border-radius: 0.25rem;
    }

    .btn-primary:hover {
      background-color: #e04e47;
      transform: scale(1.05);
    }

    /* Container Styling */
    .container {
      max-width: 1200px;
      margin: 0 auto;
      flex-grow: 1; /* Make the main content area grow to fill the remaining space */
    }

/* Blog Section */
.blog-section {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  background-image: url('path-to-your-image.jpg'); /* Ganti dengan path gambar yang sesuai */
  background-size: cover;
  background-position: center;
  padding: 60px 20px;
  min-height: 500px;
  flex-direction: column; /* Menyusun konten secara vertikal */
  text-align: center;
  position: relative;
}

/* Blog Title */
.blog-title {
  background-color: rgba(255, 255, 255, 0.8); /* White background transparan */
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  text-align: center;
  max-width: 700px;
  margin: 0 auto 30px auto; /* Menempatkan judul di tengah dan memberi jarak ke bawah */
}

.blog-title h2 {
  font-size: 2.5rem;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 20px;
}

.blog-title p {
  font-size: 1.2rem;
  color: #7f8c8d;
  line-height: 1.6;
  max-width: 800px;
  margin: 0 auto;
}

/* News Container */
.news-container {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  flex-wrap: wrap; /* Membuat artikel bertambah ke samping */
  gap: 20px;
  max-width: 1200px; /* Menyesuaikan lebar container */
  margin: 0 auto;
}

/* Blog Card */
.blog-card {
  background-color: #ffffff;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  width: 100%;
  max-width: 350px;
  margin-bottom: 20px;
  flex-shrink: 0; /* Agar card tidak mengecil */
}

.blog-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

/* Blog Card Image */
.blog-card-img {
  width: 100%;
  height: 200px;
  overflow: hidden;
}

.blog-card-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* Blog Card Body */
.blog-card-body {
  padding: 20px;
  background-color: #ffffff;
}

.blog-card-body h5 {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 10px;
  color: #2980b9;
}

.blog-card-body p {
  font-size: 1rem;
  color: #555;
  line-height: 1.6;
}

.blog-card-body a {
  color: #e74c3c;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.3s ease;
}

.blog-card-body a:hover {
  color: #c0392b;
}

/* Responsif untuk tampilan mobile */
@media (max-width: 768px) {
  .blog-section {
    flex-direction: column; /* Stack items vertically on mobile */
    padding: 20px;
  }

  .blog-title {
    margin-bottom: 20px;
  }

  .news-container {
    grid-template-columns: 1fr;
  }

  .contain {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh; /* Full screen height */
        text-align: center;
        background-color: #f7fafc; /* Soft background color */
    }


    .visitor-container {
    position: fixed;
    bottom: 20px; /* Jarak dari bawah */
    right: 20px; /* Jarak dari kanan */
    z-index: 1000; /* Pastikan selalu terlihat di atas konten lain */
}

.visitor-info {
    display: flex;
    align-items: center;
    background-color: white;
    border-radius: 1rem;
    padding: 15px 20px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}

.icon-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-right: 10px;
}

.count-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.visitor-count {
    font-size: 1.5rem;
    font-weight: bold;
    color: #333;
}

}
  </style>
</head>
<body>
  <!-- Header -->
  <?php $this->load->view('layouts/header'); ?>

  <!-- Hero Section -->
<div class="hero-section">
    <div class="hero-overlay"></div>
    <div class="hero-text">
        <h1>Welcome to Culinary Makassar</h1>
        <p>Explore Your Culinary Adventure</p>
        <!-- Tombol Explore -->
        <a href="#kota-makassar" class="btn-explore">Explore</a>
    </div>
</div>

<!-- Kota Makassar Section -->
<div class="container" id="kota-makassar">
    <div class="section">
        <div class="row">
            <div class="col-md-8">
                <h1>KOTA MAKASSAR</h1>
                <p>Kuliner Kota Makassar adalah sebuah perjalanan rasa yang memanjakan setiap indera, di mana kekayaan cita rasa dan keanekaragaman hidangan saling berpadu dengan sempurna. Setiap sajian, baik yang tradisional maupun modern, menggambarkan perpaduan antara budaya dan sejarah yang mendalam, menciptakan pengalaman kuliner yang tak terlupakan. Di kota ini, setiap sudutnya menyimpan kelezatan yang tak hanya menggugah selera, tetapi juga membawa Anda lebih dekat pada jantung budaya lokal. Dengan beragam pilihan yang memikat, Makassar menjadi surga bagi siapa saja yang ingin menikmati berbagai hidangan lezat yang menggugah selera dan memuaskan setiap keinginan rasa..</p>
            </div>
            <div class="col-md-4 text-center">
                <img alt="Illustration of Makassar city" src="<?= base_url('assets/images/mks.png') ?>" height="150"/>
            </div>
        </div>
    </div>
</div>


  <!-- Kuliner Makassar Is the Best Section -->
  <div class="container section kuliner-makassar">
    <div class="row align-items-center">
      <!-- Text Content on Left -->
      <div class="col-md-6">
        <h2>KULINER MAKASSAR IS THE BEST</h2>
        <p>Kuliner Kota Makassar adalah sebuah perjalanan rasa yang memanjakan setiap indera, di mana kekayaan cita rasa dan keanekaragaman hidangan saling berpadu dengan sempurna. Setiap sajian, baik yang tradisional maupun modern, menggambarkan perpaduan antara budaya dan sejarah yang mendalam, menciptakan pengalaman kuliner yang tak terlupakan. Di kota ini, setiap sudutnya menyimpan kelezatan yang tak hanya menggugah selera, tetapi juga membawa Anda lebih dekat pada jantung budaya lokal. Dengan beragam pilihan yang memikat, Makassar menjadi surga bagi siapa saja yang ingin menikmati berbagai hidangan lezat yang menggugah selera dan memuaskan setiap keinginan rasa.</p>
      </div>
      <!-- Image on Right -->
      <div class="col-md-6">
        <img alt="Illustration of various Makassar dishes" src="<?= base_url('assets/images/kuliner.png') ?>" height="150"/>
      </div>
    </div>
  </div>

  <div class="blog-section">
    <div class="blog-title">
        <h2>Check out our blog</h2>
        <p>Stay up to date with Makassar's culinary scene! Our blog features articles on the latest trends, news, and events.</p>
    </div>
    
    <div class="news-container">
        <?php if (!empty($news)): ?>
            <?php foreach ($news as $article): ?>
                <article class="blog-card">
                    <div class="blog-card-img">
                        <img src="<?= !empty($article->image_url) ? htmlspecialchars($article->image_url) : 'default-image.jpg' ?>" alt="<?= htmlspecialchars($article->title) ?>">
                    </div>
                    <div class="blog-card-body">
                        <h5>
                            <?php if (!empty($article->link_url)): ?>
                                <a href="<?= htmlspecialchars($article->link_url) ?>" target="_blank"><?= htmlspecialchars($article->title) ?></a>
                            <?php else: ?>
                                <a href="<?= base_url('news/' . $article->id) ?>"><?= htmlspecialchars($article->title) ?></a>
                            <?php endif; ?>
                        </h5>
                        <p><?= htmlspecialchars($article->description) ?></p>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No news available.</p>
        <?php endif; ?>
    </div>
</div>


<!-- Join Us Section (Footer) -->
<?php if (!$this->session->userdata('user_id')): ?>
    <!-- Hanya tampil jika pengguna belum login -->
    <div class="join-us-section">
        <h2>Become Part of Our Culinary Journey</h2>
        <p>Join us to explore more about Makassar's culinary treasures!</p>
        <!-- Link to register page -->
        <a href="<?= site_url('culinary/register') ?>" class="btn btn-danger">Regist Now</a>
    </div>
<?php endif; ?>


  <!-- Kuliner Andalan Section -->
  <div class="container mt-5">
    <h2 class="text-center mb-5">★ Kuliner Andalan ★</h2>
    <div class="row g-4">
      <?php if (!empty($high_rating_culinaries)): ?>
        <?php foreach ($high_rating_culinaries as $culinary): ?>
          <div class="col-md-4 col-sm-6">
            <div class="card h-100">
              <img src="<?= base_url('uploads/' . $culinary->photo) ?>" class="card-img-top" alt="<?= htmlspecialchars($culinary->name) ?>">
              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($culinary->name) ?></h5>
                <p class="card-text"><?= htmlspecialchars($culinary->description) ?></p>
                <p class="card-text"><strong>Rating:</strong> <?= number_format($culinary->average_rating, 1) ?> ★</p>
                <a href="<?= site_url('culinary/detail/' . $culinary->id) ?>" class="btn btn-primary w-100">View Details</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="text-center">Belum ada kuliner dengan rating tinggi.</p>
      <?php endif; ?>
    </div>
  </div>
 
  <div class="contain">
  <div class="visitor-container">
    <div class="visitor-info">
        <div class="icon-container">
            <i class="fas fa-users fa-3x text-primary"></i> <!-- Ikon pengunjung -->
        </div>
        <div class="count-container">
            <p class="mb-0">Jumlah Pengunjung</p>
            <h2 class="visitor-count mb-0"><?= isset($view_count) ? $view_count : 0 ?></h2>
        </div>
    </div>
</div>

<!-- Tambahkan link font-awesome untuk ikon -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <!-- Footer -->
  <?php $this->load->view('layouts/footer'); ?>

</body>
</html>



