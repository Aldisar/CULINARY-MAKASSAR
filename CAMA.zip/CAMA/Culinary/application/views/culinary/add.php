<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kuliner - Ca'ma Culinary Makassar</title>
    <!-- AOS CSS -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

    <style>
        /* Tambahkan shadow dan background untuk form */
        .form-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .form-container h2 {
            font-weight: bold;
            color: #343a40;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
            transition: all 0.3s;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php $this->load->view('layouts/header'); ?>

    <!-- Form Tambah Kuliner -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="form-container" data-aos="fade-up" data-aos-duration="1000">
                    <h2 class="text-center mb-4">Tambah Kuliner Baru</h2>

                    <!-- Pesan Sukses/Error -->
                    <?php if ($this->session->flashdata('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?= $this->session->flashdata('success'); ?>
                        </div>
                    <?php elseif ($this->session->flashdata('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?= $this->session->flashdata('error'); ?>
                        </div>
                    <?php endif; ?>

                    <!-- Form -->
                    <?= form_open_multipart('culinary/add'); ?>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="100">
                        <label for="name" class="form-label">Nama Kuliner</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Masukkan nama kuliner" required>
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="200">
                        <label for="description" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="description" name="description" rows="4" placeholder="Jelaskan tentang kuliner" required></textarea>
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="300">
                        <label for="location" class="form-label">Lokasi</label>
                        <input type="text" class="form-control" id="location" name="location" placeholder="Masukkan lokasi kuliner">
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="400">
                        <label for="category_id" class="form-label">Kategori</label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <?php if (!empty($categories)): ?>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category->id; ?>"><?= htmlspecialchars($category->name); ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="">Kategori tidak tersedia</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
                        <label for="photo" class="form-label">Foto Kuliner</label>
                        <input type="file" class="form-control" id="photo" name="photo">
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="600">
                        <label for="youtube_video_id" class="form-label">Link Video YouTube</label>
                        <input type="url" class="form-control" id="youtube_video_id" name="youtube_video_id" placeholder="https://www.youtube.com/embed/YOUR_VIDEO_ID">
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="700">
                        <label for="google_maps_location" class="form-label">Embed Link Google Maps</label>
                        <textarea class="form-control" id="google_maps_location" name="google_maps_location" rows="3" placeholder="Masukkan embed link Google Maps"></textarea>
                    </div>
                    <div class="mb-3" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="800">
    <label for="ingredients" class="form-label">Resep</label>
    <textarea class="form-control" id="ingredients" name="ingredients" rows="5" placeholder="Masukkan resep kuliner (cara membuat)"></textarea>
</div>

                    <button type="submit" class="btn btn-primary w-100" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="900">Tambah Kuliner</button>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php $this->load->view('layouts/footer'); ?>

    
    <!-- AOS JS -->
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        // Inisialisasi AOS
        AOS.init({
            duration: 1200, // Durasi animasi dalam milidetik
            easing: 'ease-out-back', // Jenis easing untuk animasi
            once: true, // Hanya animasi sekali saat scroll ke dalam tampilan
            anchorPlacement: 'top-bottom', // Tentukan kapan animasi dimulai (misalnya: muncul saat bagian atas elemen mencapai bawah jendela)
        });
    </script>
</body>  

</html>
