<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Ca'ma Culinary</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .reset-container {
            max-width: 400px;
            padding: 20px;
            border-radius: 10px;
            background-color: #f9f9f9;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }

        .header-reset {
            background-color: #ef4444;
            border-radius: 10px 10px 0 0;
            padding: 15px;
        }

        .header-reset h2 {
            color: white;
            font-weight: bold;
            text-align: center;
        }

        .btn-primary {
            background-color: #1f2937;
            color: white;
            font-weight: bold;
            transition: all 0.3s ease-in-out;
        }

        .btn-primary:hover {
            background-color: #374151;
            transform: scale(1.05);
        }

        .form-control {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 8px 10px;
            width: 100%;
            margin-top: 5px;
        }

        .form-control:focus {
            outline: none;
            border-color: #ef4444;
            box-shadow: 0 0 5px rgba(239, 68, 68, 0.5);
        }
    </style>
</head>

<body <?php $this->load->view('layouts/header'); ?>>
    <div class="reset-container">
        <div class="header-reset">
            <h2>Reset Password</h2>
        </div>
        <div class="p-4">
            <p class="text-gray-500 text-center mb-4">Masukkan email dan password baru Anda.</p>

            <?php echo form_open('culinary/reset_password_action'); ?>
            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

            <?php if ($this->session->flashdata('error')) : ?>
                <div class="text-red-500 text-center mb-3">
                    <?= $this->session->flashdata('error') ?>
                </div>
            <?php elseif ($this->session->flashdata('success')) : ?>
                <div class="text-green-500 text-center mb-3">
                    <?= $this->session->flashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="mb-4">
                <label for="email" class="block font-medium text-gray-700">Email</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Masukkan email Anda" required>
            </div>
            <div class="mb-4">
                <label for="password" class="block font-medium text-gray-700">Password Baru</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Masukkan password baru" required>
            </div>

            <button type="submit" class="btn-primary w-full py-2 rounded">Reset Password</button>
            <?php echo form_close(); ?>

            <div class="mt-4 text-center">
                <p>Sudah punya akun? <a href="<?= site_url('culinary/login') ?>" class="text-red-500 font-semibold">Login</a> sekarang.</p>
            </div>
        </div>
    </div>
    <?php $this->load->view('layouts/footer'); ?>
</body>

</html>
