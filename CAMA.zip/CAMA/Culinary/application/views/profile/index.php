<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - Ca'ma Culinary Makassar</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* Set font global */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1f3f5;
            color: #333;
        }

        /* Styling untuk memastikan footer di bawah */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            animation: fadeIn 1.5s ease-out;
        }

        .main-content {
            flex: 1;
            background-color: #fff;
            border-radius: 10px;
            margin: 20px 0;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            opacity: 0;
            animation: slideInUp 1s forwards 0.5s; /* Efek slide-in dari bawah */
        }

        /* Styling untuk kontainer profil */
        .profile-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
            opacity: 0;
            animation: slideInUp 1s forwards 1s; /* Efek slide-in dari bawah */
        }

        h2 {
            font-weight: 600;
            color: #333;
        }

        /* Tabel Profil */
        table {
            font-size: 1.1rem;
            border-collapse: separate;
            border-spacing: 0 10px;
            opacity: 0;
            animation: fadeIn 1s forwards 1.5s; /* Fade-in tabel */
        }

        table th,
        table td {
            padding: 15px;
            text-align: left;
            vertical-align: middle;
        }

        table th {
            background-color: #f1f1f1;
            font-weight: 600;
        }

        table td {
            background-color: #f9f9f9;
        }

        /* Tombol Ganti Profil */
        .btn-primary {
            background-color: #0083b0;
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            opacity: 0;
            animation: fadeIn 1s forwards 2s; /* Fade-in tombol */
        }

        .btn-primary:hover {
            background-color: #006f8c;
            transform: translateY(-3px) scale(1.05); /* Efek hover */
        }

        /* Styling untuk footer */
        footer {
            background-color: #343a40;
            color: #fff;
            padding: 30px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        footer a {
            color: #ffc107;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        footer a:hover {
            color: #fff;
        }

        footer .social-icons i {
            margin: 0 15px;
            font-size: 1.7rem;
            transition: transform 0.3s ease, color 0.3s ease;
        }

        footer .social-icons i:hover {
            transform: scale(1.2);
            color: #ffc107;
        }

        /* Responsif */
        @media (max-width: 576px) {
            .profile-container {
                padding: 20px;
            }

            .btn-primary {
                width: 100%;
            }
        }

        /* Animasi */
        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        @keyframes slideInUp {
            0% {
                transform: translateY(50px);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php $this->load->view('layouts/header'); ?>

    <!-- Konten Utama -->
    <div class="main-content">
        <div class="container">
            <div class="profile-container">
                <h2 class="text-center mb-4">Profil Saya</h2>

                <!-- Pesan Sukses -->
                <?php if ($this->session->flashdata('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?= $this->session->flashdata('success'); ?>
                    </div>
                <?php endif; ?>

                <!-- Profil -->
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th scope="row">Nama</th>
                            <td><?= htmlspecialchars($user->username ?? 'Belum diisi') ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Email</th>
                            <td><?= htmlspecialchars($user->email ?? 'Belum diisi') ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Telepon</th>
                            <td><?= htmlspecialchars($user->phone ?? 'Belum diisi') ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Alamat</th>
                            <td><?= htmlspecialchars($user->address ?? 'Belum diisi') ?></td>
                        </tr>
                    </tbody>
                </table>

                <!-- Tombol Ganti Profil -->
                <div class="text-center mt-4">
                    <a href="<?= site_url('profile/edit') ?>" class="btn btn-primary">Ganti Profil</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php $this->load->view('layouts/footer'); ?>

    
    <!-- FontAwesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>
