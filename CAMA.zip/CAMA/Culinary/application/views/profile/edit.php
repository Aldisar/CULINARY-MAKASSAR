<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil - Ca'ma Culinary Makassar</title>
</head>
<body>
    <!-- Navbar -->
    <?php $this->load->view('layouts/header'); ?>

    <div class="container mt-5">
        <h2 class="mb-4">Edit Profil Saya</h2>

        <!-- Menampilkan pesan sukses jika ada -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success" role="alert">
                <?= $this->session->flashdata('success'); ?>
            </div>
        <?php endif; ?>

        <!-- Form untuk update profil -->
        <?= form_open('profile/update', ['id' => 'edit-profile-form']); ?> <!-- form_open() otomatis menambahkan CSRF token -->
        
            <div class="mb-3">
                <label for="username" class="form-label">Nama</label>
                <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user->username ?? '') ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user->email ?? '') ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="phone" class="form-label">Telepon</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($user->phone ?? '') ?>">
            </div>
            
            <div class="mb-3">
                <label for="address" class="form-label">Alamat</label>
                <textarea class="form-control" id="address" name="address" rows="3"><?= htmlspecialchars($user->address ?? '') ?></textarea>
            </div>

            <!-- Input untuk Password Baru dan Konfirmasi Password -->
            <div class="mb-3">
                <label for="new_password" class="form-label">Password Baru</label>
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Masukkan password baru">
            </div>
            
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Konfirmasi password baru">
            </div>

            <button type="submit" class="btn btn-success">Simpan Perubahan</button>
        <?= form_close(); ?> <!-- form_close() otomatis menambahkan CSRF token -->
    </div>

    <!-- Footer -->
    <?php $this->load->view('layouts/footer'); ?>

    <!-- Script untuk validasi Password -->
    <script>
        document.getElementById('edit-profile-form').addEventListener('submit', function(e) {
            var newPassword = document.getElementById('new_password').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword !== confirmPassword) {
                e.preventDefault(); // Hentikan pengiriman form
                alert('Password dan konfirmasi password tidak cocok.');
            }
        });
    </script>

</body>
</html>
