<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Daftar Kuliner Makassar</title>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-5">Daftar Kuliner Makassar</h1>
        <div class="row">
            <?php foreach ($culinaries as $culinary): ?>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="<?= base_url('uploads/'.$culinary->photo) ?>" class="card-img-top" alt="<?= $culinary->name ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?= $culinary->name ?></h5>
                        <p class="card-text"><?= $culinary->description ?></p>
                        <p class="card-text"><small class="text-muted">Lokasi: <?= $culinary->location ?></small></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
