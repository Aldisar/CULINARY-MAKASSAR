<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ca'ma: Culinary Makassar</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Navbar Styling */
        .navbar {
            background-color: #ff4d4d; /* Merah solid */
            padding: 1rem 2rem;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #ffffff !important;
            display: flex;
            align-items: center; /* Agar logo dan teks sejajar */
        }

        .navbar-brand img {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            border-radius: 50%; /* Membuat logo berbentuk lingkaran */
            transition: transform 0.3s ease;
        }

        .navbar-brand img:hover {
            transform: scale(1.1); /* Zoom in saat hover */
        }

        .navbar-nav .nav-link {
            font-size: 1rem;
            font-weight: 500;
            color: #ffffff !important; /* Teks putih */
            margin: 0 0.5rem;
            transition: color 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            color: #ffc107 !important; /* Hover warna kuning */
        }

        /* Tombol "Daftar" */
        .btn-register {
            color: #ff4d4d;
            background-color: #ffffff;
            border: 2px solid #ffffff;
            border-radius: 20px;
            padding: 0.5rem 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-register:hover {
            background-color: #ff6f6f;
            color: #ffffff;
        }

        /* Tombol "Masuk" */
        .btn-login {
            color: #ffffff;
            background-color: transparent;
            border: 2px solid #ffffff;
            border-radius: 20px;
            padding: 0.5rem 1rem;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            background-color: #ffffff;
            color: #ff4d4d;
        }

        /* Ikon Profil */
        .profile-icon {
            font-size: 1.5rem;
            color: #ffffff;
            transition: color 0.3s ease, transform 0.3s ease;
            margin-right: 1rem;
        }

        .profile-icon:hover {
            color: #ffc107;
            transform: scale(1.1);
        }

        /* Dropdown Menu */
        .dropdown-menu {
            border-radius: 10px;
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .dropdown-menu .dropdown-item {
            font-size: 1rem;
            color: #333;
        }

        .dropdown-menu .dropdown-item:hover {
            background-color: #ff4d4d;
            color: #ffffff;
        }

        /* Search Input */
        .search-bar {
            display: flex;
            align-items: center;
        }

        .search-bar input {
            border: none;
            padding: 0.5rem;
            border-radius: 20px;
            margin-right: 10px;
            width: 250px;
        }

        .search-bar button {
            background-color: #ff6f6f;
            border: none;
            border-radius: 20px;
            padding: 0.5rem 1rem;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-bar button:hover {
            background-color: #ff4d4d;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= site_url('culinary') ?>">
                <img src="<?= base_url('assets/images/1.PNG') ?>" alt="Logo">
                Ca'ma: Culinary Makassar
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= site_url('culinary') ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= site_url('culinary/add') ?>">Tambah Kuliner</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="<?= site_url('culinary/details_by_category') ?>" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Kategori
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?= site_url('culinary/details_by_category/makanan_berat') ?>">Makanan Berat</a></li>
<li><a class="dropdown-item" href="<?= site_url('culinary/details_by_category/makanan_ringan') ?>">Makanan Ringan</a></li>
<li><a class="dropdown-item" href="<?= site_url('culinary/details_by_category/minuman') ?>">Minuman</a></li>
<li><hr class="dropdown-divider"></li>
<li><a class="dropdown-item" href="<?= site_url('culinary/details_by_category') ?>">Lihat Semua</a></li>

                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?= site_url('culinary/contact') ?>">Contact Us</a></li>
                </ul>
                <!-- Search Form -->
                <div class="search-bar">
                    <form action="<?= site_url('culinary/search') ?>" method="get">
                        <input type="text" name="query" placeholder="Cari kuliner..." aria-label="Search">
                        <button type="submit"><i class="fas fa-search"></i> Cari</button>
                    </form>
                </div>
                <div class="d-flex align-items-center">
                    <?php if ($this->session->userdata('user_logged_in')): ?>
                        <a href="<?= site_url('profile') ?>" class="profile-icon"><i class="fas fa-user-circle"></i></a>
                        <a href="<?= site_url('culinary/logout') ?>" class="btn btn-register">Logout</a>
                    <?php else: ?>
                        <a href="<?= site_url('culinary/register') ?>" class="btn btn-register me-2">Daftar</a>
                        <a href="<?= site_url('culinary/login') ?>" class="btn btn-login">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>