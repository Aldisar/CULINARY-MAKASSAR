<!-- Footer -->
<footer class="bg-danger text-light mt-5">
    <div class="container-fluid px-5 py-5">
        <div class="row text-center mb-0">
            <!-- Location Section -->
            <div class="col-md-4">
                <h5 class="text-uppercase fw-bold text-white mb-3">Location</h5>
                <p>Jalan Mappala blok A no.12</p>
                <p>Makassar, Indonesia</p>
            </div>

            <!-- Social Media Section -->
            <div class="col-md-4">
                <h5 class="text-uppercase fw-bold text-white mb-3">Around the Web</h5>
                <div class="d-flex justify-content-center gap-3">
                    <a href="https://www.facebook.com" class="text-white" target="_blank">
                        <i class="fab fa-facebook fa-2x"></i>
                    </a>
                    <a href="https://www.twitter.com" class="text-white" target="_blank">
                        <i class="fab fa-twitter fa-2x"></i>
                    </a>
                    <a href="https://www.instagram.com" class="text-white" target="_blank">
                        <i class="fab fa-instagram fa-2x"></i>
                    </a>
                    <a href="https://www.linkedin.com" class="text-white" target="_blank">
                        <i class="fab fa-linkedin fa-2x"></i>
                    </a>
                </div>
            </div>

            <!-- About Section -->
            <div class="col-md-4">
                <h5 class="text-uppercase fw-bold text-white mb-3">About Ca'ma Culinary</h5>
                <p>Ca'ma Culinary adalah platform kuliner yang membantu Anda menjelajahi cita rasa terbaik dari Makassar.</p>
            </div>
        </div>
    </div>

    <!-- Copyright Section -->
    <div class="bg-dark text-center py-3">
        <p class="mb-0 text-white fw-bold" style="font-size: 1.2rem;">
            © 2023 Ca'ma Culinary Makassar
        </p>
    </div>
</footer>

<!-- CSS untuk memberikan jarak dan memastikan footer full-width -->
<style>
    footer {
        width: 100%; /* Pastikan footer mencakup seluruh lebar layar */
        margin-top: 30px; /* Jarak di atas footer */
    }

    .container-fluid {
        padding-left: 0; /* Menghilangkan padding kiri */
        padding-right: 0; /* Menghilangkan padding kanan */
    }

    .bg-dark {
        margin-top: 20px; /* Jarak antara bagian atas footer dengan bagian bawah */
    }

    .row {
        margin-bottom: 30px; /* Memberikan ruang bawah untuk isi footer */
    }

    .footer .text-center {
        padding: 20px 0;
        background-color: #343a40; /* Background untuk bagian bawah footer */
    }
</style>
