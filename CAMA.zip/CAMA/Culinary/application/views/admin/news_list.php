<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CA'MA Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Custom Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7fafc;
        }

        h2 {
            font-size: 2rem;
            font-weight: 600;
            color: #2d3748;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 1rem;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #edf2f7;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        table tr:hover {
            background-color: #f7fafc;
        }

        table tr td img {
            max-width: 100px;
            max-height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        a {
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        button {
            background-color: #3182ce;
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2b6cb0;
        }

        button:active {
            transform: scale(0.98);
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            background-color: #2d3748;
            color: white;
            position: fixed;
            top: 0;
            bottom: 0;
            padding-top: 20px;
        }

        .sidebar h4 {
            text-align: center;
            font-size: 1.25rem;
            background-color: #1a202c;
            padding: 10px 0;
        }

        .sidebar ul li {
            margin-bottom: 12px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: white;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #4a5568;
        }

        .sidebar a i {
            margin-right: 12px;
        }

        /* Button Edit and Delete */
        .action-btn {
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s ease;
        }

        .action-btn.edit {
            background-color: #f6ad55;
        }

        .action-btn.edit:hover {
            background-color: #dd6b20;
        }

        .action-btn.delete {
            background-color: #f56565;
        }

        .action-btn.delete:hover {
            background-color: #e53e3e;
        }

        .action-btn:active {
            transform: scale(0.98);
        }
    </style>
</head>
<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Konten Utama -->
        <div class="ml-60 w-full p-6">
            <h2 class="text-2xl font-semibold mb-4">Daftar Berita</h2>
            
            <!-- Button Tambah Berita -->
            <a href="<?= site_url('news/add') ?>" class="inline-block bg-blue-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-600 transition duration-300 mb-4">Tambah Berita</a>
            
            <!-- Tabel Berita -->
            <div class="overflow-x-auto mt-4">
                <table class="min-w-full bg-white rounded-lg shadow-md table-auto">
                    <thead>
                        <tr class="bg-gray-200">
                            <th class="py-2 px-4 text-left">Judul</th>
                            <th class="py-2 px-4 text-left">Deskripsi</th>
                            <th class="py-2 px-4 text-left">Link</th>
                            <th class="py-2 px-4 text-left">Gambar</th>
                            <th class="py-2 px-4 text-left">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($news as $item): ?>
                            <tr class="hover:bg-gray-100 transition duration-300">
                                <td class="py-2 px-4"><?= $item->title ?></td>
                                <td class="py-2 px-4"><?= $item->description ?></td>
                                <td class="py-2 px-4"><a href="<?= $item->link_url ?>" target="_blank" class="text-blue-500 hover:underline">Link</a></td>
                                <td class="py-2 px-4"><img src="<?= $item->image_url ?>" alt="image" class="w-20 h-20 object-cover rounded-md"></td>
                                <td class="py-2 px-4 flex space-x-4">
                                    <a href="<?= site_url('news/edit/' . $item->id) ?>" class="action-btn edit">Edit</a>
                                    <a href="<?= site_url('news/delete/' . $item->id) ?>" onclick="return confirm('Are you sure?')" class="action-btn delete">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</body>
</html>
