<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Daftar Ulasan Kuliner</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px; /* Adjust sidebar width */
            height: 100vh;
            background-color: #2d3748;
            color: white;
            padding-top: 20px;
        }

        .sidebar h4 {
            text-align: center;
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 15px;
        }

        .sidebar ul li a {
            display: flex;
            align-items: center;
            color: white;
            padding: 10px;
            text-decoration: none;
            font-size: 1rem;
        }

        .sidebar ul li a:hover {
            background-color: #4a5568;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        /* Content Area */
        .container {
            margin-left: 250px; /* Adjust to sidebar width */
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h3 {
            font-size: 1.75rem;
            margin-bottom: 20px;
            color: #333;
        }

        /* Flash message styling */
        .alert {
            font-size: 16px;
            padding: 10px;
            margin-bottom: 20px;
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 5px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th, .table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        /* Header styling */
        .table th {
            background-color: #333;
            color: #fff;
            font-size: 1rem;
        }

        /* Row Styling */
        .table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .table tr:hover {
            background-color: #f1f1f1;
        }

        /* Image styling */
        .table img {
            width: 120px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
        }

        /* Button styling */
        .btn-danger {
            background-color: #e74c3c;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }

        .btn-danger:hover {
            background-color: #c0392b;
        }

        /* Responsive styling */
        @media (max-width: 768px) {
            .table {
                font-size: 14px;
            }

            .table img {
                width: 100px;
                height: 70px;
            }

            .table th, .table td {
                padding: 8px;
            }

            .container {
                margin-left: 0;
            }

            .sidebar {
                width: 200px;
            }
        }

    </style>
</head>
<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    <div class="container">
        <h3>Daftar Ulasan Kuliner</h3>
        
        <!-- Flash Message -->
        <?php if($this->session->flashdata('message')): ?>
            <div class="alert">
                <?= $this->session->flashdata('message'); ?>
            </div>
        <?php endif; ?>
        
        <!-- Tabel Daftar Ulasan -->
        <table class="table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Pengguna</th>
                    <th>Rating</th>
                    <th>Ulasan</th>
                    <th>Nama Kuliner</th>
                    <th>Foto Kuliner</th>
                    <th>Tanggal</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($reviews as $review): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($review->username) ?></td>
                    <td><?= str_repeat('★', $review->rating) ?></td>
                    <td><?= htmlspecialchars($review->comment) ?></td>
                    <td><?= htmlspecialchars($review->culinary_name) ?></td>
                    <td>
                        <?php if ($review->culinary_photo && file_exists('uploads/' . $review->culinary_photo)): ?>
                            <img src="<?= base_url('uploads/' . $review->culinary_photo) ?>" alt="<?= htmlspecialchars($review->culinary_name) ?>">
                        <?php else: ?>
                            <img src="<?= base_url('uploads/culinary/default.jpg') ?>" alt="Default Image">
                        <?php endif; ?>
                    </td>
                    <td><?= date('d-m-Y H:i', strtotime($review->created_at)) ?></td>
                    <td>
                        <a href="<?= site_url('admin/delete_review/' . $review->id) ?>" class="btn-danger">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>
</html>
