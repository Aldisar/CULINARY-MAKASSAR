<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kuliner</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Main Content -->
        <div class="ml-64 p-8 w-full">
            <h2 class="text-2xl font-semibold mb-4">Tambah Kuliner</h2>

            <!-- Tampilkan Flashdata Success/Error -->
            <?php if ($this->session->flashdata('success')): ?>
                <div class="mb-4 text-green-500"><?= $this->session->flashdata('success') ?></div>
            <?php elseif ($this->session->flashdata('error')): ?>
                <div class="mb-4 text-red-500"><?= $this->session->flashdata('error') ?></div>
            <?php endif; ?>

            <!-- Form Tambah Kuliner -->
            <form action="<?= site_url('admin/simpan_kuliner') ?>" method="POST" enctype="multipart/form-data">
                <!-- CSRF Token -->
                <input type="hidden" name="<?= $this->security->get_csrf_token_name() ?>" value="<?= $this->security->get_csrf_hash() ?>" />
                
                <div class="grid grid-cols-1 gap-4 mb-4">
                    <!-- Nama Kuliner -->
                    <div>
                        <label for="name" class="block text-sm font-semibold text-gray-700">Nama Kuliner</label>
                        <input type="text" id="name" name="name" class="w-full mt-2 p-2 border border-gray-300 rounded-md" required>
                    </div>

                    <!-- Deskripsi Kuliner -->
                    <div>
                        <label for="description" class="block text-sm font-semibold text-gray-700">Deskripsi</label>
                        <textarea id="description" name="description" rows="4" class="w-full mt-2 p-2 border border-gray-300 rounded-md" required></textarea>
                    </div>

                    <!-- Kategori Kuliner -->
                    <div>
                        <label for="category_id" class="block text-sm font-semibold text-gray-700">Kategori</label>
                        <select id="category_id" name="category_id" class="w-full mt-2 p-2 border border-gray-300 rounded-md" required>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category->id ?>"><?= $category->name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Lokasi Kuliner -->
                    <div>
                        <label for="location" class="block text-sm font-semibold text-gray-700">Lokasi</label>
                        <input type="text" id="location" name="location" class="w-full mt-2 p-2 border border-gray-300 rounded-md" required>
                    </div>

                    <!-- Foto Kuliner -->
                    <div>
                        <label for="photo" class="block text-sm font-semibold text-gray-700">Foto Kuliner</label>
                        <input type="file" id="photo" name="photo" class="w-full mt-2 p-2 border border-gray-300 rounded-md" accept="image/*" required>
                    </div>

                    <!-- Bahan Kuliner -->
                    <div>
                        <label for="ingredients" class="block text-sm font-semibold text-gray-700">Resep</label>
                        <textarea id="ingredients" name="ingredients" rows="4" class="w-full mt-2 p-2 border border-gray-300 rounded-md" required></textarea>
                    </div>

                    <!-- YouTube Video ID -->
                    <div>
                        <label for="youtube_video_id" class="block text-sm font-semibold text-gray-700">YouTube Video ID</label>
                        <input type="text" id="youtube_video_id" name="youtube_video_id" class="w-full mt-2 p-2 border border-gray-300 rounded-md">
                    </div>

                    <!-- Google Maps Location -->
                    <div>
                        <label for="google_maps_location" class="block text-sm font-semibold text-gray-700">Google Maps Location</label>
                        <input type="text" id="google_maps_location" name="google_maps_location" class="w-full mt-2 p-2 border border-gray-300 rounded-md">
                    </div>
                </div>

                <!-- Tombol Simpan -->
                <div class="flex justify-end">
                    <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded-md hover:bg-blue-600">Simpan Kuliner</button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>
</html>
