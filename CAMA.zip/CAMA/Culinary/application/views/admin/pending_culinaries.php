<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Pending Kuliner</title>
</head>
<body>
    <div class="container mt-5">
        <h3 class="text-center mb-4">Pending Culinaires</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nama Kuliner</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($culinaries as $culinary): ?>
                <tr>
                    <td><?= $culinary->name ?></td>
                    <td><?= $culinary->description ?></td>
                    <td>
                        <a href="<?= site_url('admin/approve/'.$culinary->id) ?>" class="btn btn-success" onclick="return confirm('Approve kuliner ini?')">Approve</a>
                        <a href="<?= site_url('admin/reject/'.$culinary->id) ?>" class="btn btn-danger" onclick="return confirm('Reject kuliner ini?')">Reject</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
