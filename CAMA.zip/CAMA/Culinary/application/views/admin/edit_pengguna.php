<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pengguna - Ca'ma Culinary Makassar</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="ml-64 p-8 w-full">
            <h2 class="text-2xl font-semibold mb-6">Edit Pengguna</h2>

            <!-- Form Edit Pengguna -->
            <div class="max-w-lg bg-white p-6 rounded-lg shadow-lg">
            <form action="<?= site_url('admin/edit_pengguna/'.$user->id) ?>" method="post">
    <?= form_open() ?> <!-- Jika menggunakan form_open() -->
    <div class="mb-4">
        <label class="block text-gray-700 font-bold">Nama Pengguna:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user->username ?? '') ?>" class="border border-gray-300 rounded w-full py-2 px-3 mt-1 focus:outline-none focus:ring-2 focus:ring-blue-400" required>
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold">Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user->email ?? '') ?>" class="border border-gray-300 rounded w-full py-2 px-3 mt-1 focus:outline-none focus:ring-2 focus:ring-blue-400" required>
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold">Phone:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($user->phone ?? '') ?>" class="border border-gray-300 rounded w-full py-2 px-3 mt-1 focus:outline-none focus:ring-2 focus:ring-blue-400">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold">Address:</label>
        <textarea name="address" class="border border-gray-300 rounded w-full py-2 px-3 mt-1 focus:outline-none focus:ring-2 focus:ring-blue-400"><?= htmlspecialchars($user->address ?? '') ?></textarea>
    </div>
    <button type="submit" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded shadow-lg transition duration-300 ease-in-out">
        Simpan Perubahan
    </button>
</form>

            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>
