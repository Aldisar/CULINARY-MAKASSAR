<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Edit Berita - Admin Panel</title>
    <style>
        /* CSS Global */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7fafc;
        }

        .flex {
            display: flex;
        }

        .w-full {
            width: 100%;
        }

        /* Sidebar */
        .sidebar {
            background-color: #2d3748;
            color: white;
            width: 250px; /* Lebar sidebar */
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
            padding-bottom: 20px;
        }

        .sidebar h4 {
            font-size: 1.25rem;
            font-weight: bold;
            padding: 20px;
            background-color: #1a202c;
            text-align: center;
        }

        .sidebar nav {
            margin-top: 20px;
        }

        .sidebar ul {
            padding-left: 0;
        }

        .sidebar ul li {
            list-style: none;
        }

        .sidebar ul li a {
            padding: 10px;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
            transition: background-color 0.3s;
        }

        .sidebar ul li a:hover {
            background-color: #4a5568;
        }

        .sidebar ul li i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px; /* Memberikan ruang yang cukup untuk sidebar */
            padding: 20px;
            flex: 1;
        }

        .form-container {
            max-width: 800px;
            margin: auto;
            padding: 2rem;
            background-color: white;
            border-radius: 0.375rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        input, textarea {
            width: 100%;
            padding: 0.75rem;
            border-radius: 0.375rem;
            border: 1px solid #ccc;
        }

        textarea {
            resize: vertical;
            min-height: 150px;
        }

        button {
            background-color: #3182ce;
            color: white;
            padding: 0.75rem;
            border-radius: 0.375rem;
            width: 100%;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #2b6cb0;
        }

        label {
            display: block;
            font-size: 1rem;
            margin-bottom: 0.5rem;
        }

        /* Responsif */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                height: auto;
            }

            .main-content {
                margin-left: 0; /* Konten utama mengambil lebar penuh */
            }

            .sidebar ul li a {
                padding: 15px;
            }
        }
    </style>
</head>
<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="form-container">
                <h2>Edit Berita</h2>

                <!-- Form Edit Berita -->
                <?= form_open('news/edit/' . $news->id, ['class' => 'space-y-4']) ?>
                    <div class="form-group">
                        <label for="title" class="block text-gray-700 font-medium">Judul</label>
                        <input type="text" name="title" id="title" value="<?= $news->title ?>" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label for="description" class="block text-gray-700 font-medium">Deskripsi</label>
                        <textarea name="description" id="description" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?= $news->description ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="image_url" class="block text-gray-700 font-medium">URL Gambar</label>
                        <input type="text" name="image_url" id="image_url" value="<?= $news->image_url ?>" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label for="link_url" class="block text-gray-700 font-medium">Link URL</label>
                        <input type="text" name="link_url" id="link_url" value="<?= $news->link_url ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <button type="submit" class="w-full bg-blue-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-600 transition duration-300">Simpan</button>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</body>
</html>
