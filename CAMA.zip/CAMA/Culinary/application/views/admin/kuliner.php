<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kuliner Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .pagination-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .pagination-container .btn {
            min-width: 40px;
            border-radius: 50%;
        }

        .pagination-container .btn:disabled {
            background-color: #ccc;
        }
    </style>
</head>

<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="ml-64 p-8 w-full">
            <h2 class="text-2xl font-semibold mb-4">Daftar Produk Kuliner</h2>

            <!-- Flash message success or error -->
            <?php if ($this->session->flashdata('success')): ?>
                <div class="mb-4 text-green-500"><?= $this->session->flashdata('success') ?></div>
            <?php elseif ($this->session->flashdata('error')): ?>
                <div class="mb-4 text-red-500"><?= $this->session->flashdata('error') ?></div>
            <?php endif; ?>

            <!-- Add Culinary Button -->
            <div class="mb-4">
                <a href="<?= site_url('admin/tambah_kuliner') ?>" class="inline-block bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Tambah Kuliner</a>
            </div>

            <!-- Culinary List in Cards with Animation -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($culinaries as $kuliner): ?>
                    <div class="card bg-white shadow-lg rounded-lg overflow-hidden transform hover:scale-105 hover:shadow-2xl transition-all duration-300">
                        <img src="<?= base_url('uploads/' . $kuliner->photo) ?>" alt="<?= $kuliner->name ?>" class="w-full h-40 object-cover">
                        <div class="p-4">
                            <h3 class="text-xl font-semibold text-gray-800"><?= $kuliner->name ?></h3>
                            <p class="text-gray-600 text-sm mt-2"><?= substr($kuliner->description, 0, 100) ?>...</p>
                            <div class="mt-3 flex items-center justify-between">
                                <span class="text-sm text-gray-500"><?= $kuliner->location ?></span>
                            </div>
                        </div>
                        <div class="bg-gray-50 p-4 border-t border-gray-200">
                            <div class="flex justify-between items-center">
                                <a href="<?= site_url('admin/edit_kuliner/' . $kuliner->id) ?>" class="bg-yellow-500 text-white px-4 py-2 rounded-md hover:bg-yellow-600 transition">Edit</a>
                                <a href="<?= site_url('admin/delete_kuliner/' . $kuliner->id) ?>" class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition" onclick="return confirm('Yakin ingin menghapus kuliner ini?')">Hapus</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <div class="pagination-container">
                <button class="btn btn-outline-secondary prev-btn" <?= $current_page == 1 ? 'disabled' : '' ?>>&lt;</button>
                <button class="btn btn-outline-secondary next-btn" <?= $current_page == $total_pages ? 'disabled' : '' ?>>&gt;</button>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const prevButton = document.querySelector('.prev-btn');
        const nextButton = document.querySelector('.next-btn');
        const itemsPerPage = 9;  // Display 9 items per page
        let currentPage = <?= isset($current_page) ? $current_page : 1 ?>;  // Pastikan $current_page terdefinisi
        const totalItems = <?= count($culinaries) ?>;
        const totalPages = <?= isset($total_pages) ? $total_pages : 1 ?>;  // Pastikan $total_pages terdefinisi

        // Show or hide items based on the current page
        const updateItems = () => {
            const items = document.querySelectorAll('.card');
            items.forEach((item, index) => {
                const start = (currentPage - 1) * itemsPerPage;
                const end = currentPage * itemsPerPage;
                item.style.display = index >= start && index < end ? 'block' : 'none';
            });

            prevButton.disabled = currentPage === 1;
            nextButton.disabled = currentPage === totalPages;
        };

        prevButton.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                updateItems();
            }
        });

        nextButton.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                updateItems();
            }
        });

        updateItems();
    });
</script>

</body>

</html>
