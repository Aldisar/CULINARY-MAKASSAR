<?php $this->load->view('layouts/header'); ?>

<div class="container-fluid login-container mt-5">
    <div class="row vh-100">
        <!-- Bagian Gambar Samping -->
        <div class="col-md-6 p-0 d-none d-md-flex align-items-center justify-content-center bg-light">
            <img src="<?= base_url('assets/images/makanan.png') ?>" class="img-fluid" alt="Delicious food on a plate" style="max-height: 90vh;">
        </div>
        
        <!-- Bagian Form Login -->
        <div class="col-md-6 d-flex align-items-center justify-content-center">
            <div class="w-75">
                <div class="text-center mb-4">
                    <!-- Logo dan Nama Aplikasi -->
                    <img src="<?= base_url('assets/images/1.png') ?>" class="img-fluid mb-2" alt="Logo Culinary Makassar" style="max-width: 120px;">
                    <h2 class="fw-bold">Ca'ma Culinary</h2>
                </div>

                <!-- Form untuk login -->
                <?php echo form_open('culinary/login'); ?>
                
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger">
                        <?= $error ?>
                    </div>
                <?php endif; ?>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email Anda" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password Anda" required>
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="remember_me" name="remember_me">
                    <label class="form-check-label" for="remember_me">Ingat Saya</label>
                </div>
                <button type="submit" class="btn btn-dark w-100">Log in</button>

                <?php echo form_close(); ?>

                <div class="mt-3 text-center">
                    <p>Belum punya akun? <a href="<?= site_url('culinary/register') ?>" class="text-decoration-none text-dark fw-bold">Register</a> sekarang.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('layouts/footer'); ?>
