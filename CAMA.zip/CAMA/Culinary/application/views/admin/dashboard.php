<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Ca'ma Culinary Makassar</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        // Mendapatkan tanggal dan waktu saat ini
        function getCurrentDate() {
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            const today = new Date().toLocaleDateString('id-ID', options);
            document.getElementById('current-date').innerText = today;
        }
    </script>
</head>

<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="ml-64 p-8 w-full">
            <!-- Header -->
            <h2 class="text-2xl font-semibold mb-2">Hai Admin 😊, Semoga Harimu Baik!</h2>
            <p id="current-date" class="text-gray-500 mb-6 text-lg"></p>

            <!-- Summary Section -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div class="bg-blue-500 text-white p-6 rounded-lg shadow-md flex flex-col items-center">
                    <h3 class="text-lg font-semibold">Total Kuliner</h3>
                    <p class="text-4xl font-bold"><?= $total_kuliner; ?></p>
                </div>
                <div class="bg-green-500 text-white p-6 rounded-lg shadow-md flex flex-col items-center">
                    <h3 class="text-lg font-semibold">Views Pengunjung</h3>
                    <p class="text-4xl font-bold"><?= $login_page_views; ?></p>
                </div>
                <div class="bg-yellow-500 text-white p-6 rounded-lg shadow-md flex flex-col items-center">
                    <h3 class="text-lg font-semibold">Total Pengguna</h3>
                    <p class="text-4xl font-bold"><?= $total_pengguna; ?></p>
                </div>
                <div class="bg-red-500 text-white p-6 rounded-lg shadow-md flex flex-col items-center">
                    <h3 class="text-lg font-semibold">Total Kategori</h3>
                    <p class="text-4xl font-bold"><?= $total_kategori; ?></p>
                </div>
            </div>

            <!-- Recent Activities Section -->
            <h4 class="text-xl font-semibold mt-6 mb-4">User Activity Logs</h4>
            <div class="overflow-x-auto bg-white shadow-md rounded-lg">
                <table class="min-w-full bg-white border border-gray-200">
                    <thead>
                        <tr class="bg-gray-800 text-white text-left text-sm uppercase font-semibold">
                            <th class="py-3 px-5 border-b border-gray-300">ID</th>
                            <th class="py-3 px-5 border-b border-gray-300">User ID</th>
                            <th class="py-3 px-5 border-b border-gray-300">Activity</th>
                            <th class="py-3 px-5 border-b border-gray-300">Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($logs)) : ?>
                            <?php foreach ($logs as $log) : ?>
                                <tr class="hover:bg-gray-100">
                                    <td class="py-3 px-5 border-b border-gray-200"><?= $log->id ?></td>
                                    <td class="py-3 px-5 border-b border-gray-200"><?= $log->user_id ?></td>
                                    <td class="py-3 px-5 border-b border-gray-200"><?= $log->activity ?></td>
                                    <td class="py-3 px-5 border-b border-gray-200"><?= date('d-m-Y H:i:s', strtotime($log->created_at)) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-gray-500">No activity logs found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>
