<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Ca'ma Culinary Makassar</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Main content styling */
        .content {
            margin-left: 260px;
            padding: 20px;
        }

        .btn-custom {
            border-radius: 30px;
            padding: 0.5rem 1.5rem;
        }
    </style>
</head>

<body class="bg-gray-100" onload="getCurrentDate()">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-60 h-screen fixed">
            <h4 class="text-xl font-bold p-5 bg-gray-900 text-center">CA'MA Admin Panel</h4>
            <nav class="mt-4">
                <ul class="space-y-2">
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/dashboard') ?>">
                            <i class="fas fa-home mr-3"></i> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kategori') ?>">
                            <i class="fas fa-list mr-3"></i> Kategori
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/kuliner') ?>">
                            <i class="fas fa-utensils mr-3"></i> Produk Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/pengguna') ?>">
                            <i class="fas fa-users mr-3"></i> Pengguna
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/verifikasi') ?>">
                            <i class="fas fa-check-circle mr-3"></i> Verifikasi Kuliner
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/news') ?>">
                            <i class="fas fa-newspaper mr-3"></i> News List
                        </a>
                    </li>
                    <!-- Tambahkan Review List di sini -->
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/review_list') ?>">
                            <i class="fas fa-star mr-3"></i> Review List
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('culinary/logout') ?>">
                            <i class="fas fa-sign-out-alt mr-3"></i> Logout
                        </a>
                    </li>
                    <li>
                        <a class="flex items-center px-4 py-2 hover:bg-gray-700" href="<?= site_url('admin/contact_messages') ?>">
                            <i class="fas fa-envelope mr-3"></i> Pesan Masuk
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="content">
            <h3 class="text-2xl font-semibold mb-4">Kategori Produk</h3>
            <a href="<?= site_url('admin/tambah_kategori') ?>" class="bg-blue-500 text-white px-4 py-2 rounded mb-3 inline-block">Tambah Kategori</a>
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-800 text-white">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Kategori</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($categories as $index => $category): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap"><?= $index + 1 ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($category->name) ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex space-x-2">
                                        <a href="<?= site_url('admin/edit_kategori/'.$category->id) ?>" class="bg-gray-700 text-white px-3 py-1 rounded hover:bg-gray-600">Edit</a>
                                        <a href="<?= site_url('admin/delete_kategori/'.$category->id) ?>" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>
