<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function insert_message($data) {
        return $this->db->insert('contact_messages', $data);
    }

    public function get_all_messages() {
        $query = $this->db->get('contact_messages');
        return $query->result();
    }
}
?>
