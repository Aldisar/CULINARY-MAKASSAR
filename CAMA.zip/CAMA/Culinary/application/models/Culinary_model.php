<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Culinary_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Load database
    }

    public function count_all() {
        return $this->db->count_all('culinaries'); // Gantilah 'culinaries' dengan nama tabel yang sesuai
    }

    // Metode untuk mengambil semua kuliner dengan status 'approved'
public function get_all_approved() {
    $this->db->where('status', 'approved');
    $query = $this->db->get('culinaries');
    return $query->result();
}

// Metode untuk mengambil semua kuliner dengan status 'pending'
public function get_all_pending() {
    $this->db->where('status', 'pending');
    $query = $this->db->get('culinaries');
    return $query->result();
}


    // Metode untuk mengambil semua kuliner
    public function get_all() {
        $query = $this->db->get('culinaries');
        return $query->result();
    }

    // Metode untuk mengambil kuliner berdasarkan ID
    public function get_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('culinaries');
        return $query->row();
    }

    // Metode untuk menambahkan kuliner baru ke database
    public function insert($data) {
        if ($this->db->insert('culinaries', $data)) {
            return true;
        } else {
            log_message('error', 'Database Insert Error: ' . $this->db->last_query()); // Menyimpan query yang gagal
            return false;
        }
    }
    
    

    // Metode untuk memperbarui data kuliner berdasarkan ID
    public function update($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('culinaries', $data);
    }

    // Metode untuk memperbarui status kuliner (misal: 'approved' atau 'rejected')
    public function update_status($id, $status) {
        $this->db->where('id', $id);
        return $this->db->update('culinaries', array('status' => $status));
    }

    // Metode untuk menghapus kuliner dari database berdasarkan ID
    public function delete($id) {
        $this->db->where('id', $id);
        return $this->db->delete('culinaries');
    }

    // Metode untuk mencari kuliner berdasarkan nama
    public function search_by_name($keyword) {
        $this->db->like('name', $keyword);
        $query = $this->db->get('culinaries');
        return $query->result();
    }

    // Metode untuk mengambil semua kuliner yang dikelompokkan berdasarkan kategori
    public function get_all_grouped_by_category() {
        $this->db->select('culinaries.*, categories.name as category_name');
        $this->db->from('culinaries');  // Menggunakan tabel 'culinaries' sesuai dengan database
        $this->db->join('categories', 'culinaries.category_id = categories.id'); // Join dengan tabel 'categories'
        $this->db->where('culinaries.status', 'approved'); // Mengambil hanya yang sudah disetujui
        $this->db->order_by('categories.name', 'ASC');
        $query = $this->db->get();

        // Mengelompokkan hasil berdasarkan kategori
        $result = [];
        foreach ($query->result() as $row) {
            $result[$row->category_name][] = $row; // Mengelompokkan berdasarkan kategori
        }
        return $result;
    }
    public function search_culinaries($query) {
        // Menambahkan query untuk pencarian berdasarkan nama atau deskripsi
        $this->db->like('name', $query);  // Cari berdasarkan nama
        $this->db->or_like('description', $query);  // atau berdasarkan deskripsi
        $query = $this->db->get('culinaries'); // Ambil hasil query
        return $query->result(); // Kembalikan hasil pencarian
    }

    // Metode untuk mendapatkan review kuliner berdasarkan ID kuliner
    public function get_reviews_by_culinary_id($culinary_id) {
        $this->db->where('culinary_id', $culinary_id);
        $query = $this->db->get('reviews');
        return $query->result(); // Mengembalikan array dari semua review kuliner
    }

    // Metode untuk menambahkan review baru untuk kuliner
    public function add_review($data) {
        if ($this->db->insert('reviews', $data)) {
            return true;
        } else {
            log_message('error', 'Database Insert Error: ' . $this->db->last_query());
            return false;
        }
    }

    // Metode untuk mendapatkan kuliner dengan rating tertinggi
    public function get_top_culinaries($limit = 10) {
        $this->db->select('culinaries.*, AVG(reviews.rating) as avg_rating');
        $this->db->from('culinaries');
        $this->db->join('reviews', 'reviews.culinary_id = culinaries.id', 'left');
        $this->db->group_by('culinaries.id');
        $this->db->order_by('avg_rating', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }

    // Metode untuk menambahkan like pada kuliner
    public function add_like($culinary_id) {
        $this->db->set('likes', 'likes+1', FALSE);
        $this->db->where('id', $culinary_id);
        return $this->db->update('culinaries');
    }

    // Metode untuk menambahkan dislike pada kuliner
    public function add_dislike($culinary_id) {
        $this->db->set('dislikes', 'dislikes+1', FALSE);
        $this->db->where('id', $culinary_id);
        return $this->db->update('culinaries');
    }
    
    // Fungsi tambahan untuk operasi CRUD dasar
    public function get_all_kuliner() {
        return $this->db->get('culinaries')->result_array();
    }

    public function get_kuliner_by_id($id) {
        return $this->db->get_where('culinaries', ['id' => $id])->row_array();
    }
    
    public function get_high_rating_culinaries() {
        $this->db->select('culinaries.*, AVG(reviews.rating) as average_rating');
        $this->db->from('culinaries');
        $this->db->join('reviews', 'reviews.culinary_id = culinaries.id', 'left');
        $this->db->where('culinaries.status', 'approved');
        $this->db->group_by('culinaries.id');
        $this->db->having('average_rating >=', 4.5);
        $query = $this->db->get();
        return $query->result();
    }    

    public function get_all_culinaries() {
        $this->db->select('*');
        $this->db->from('culinaries');
        $query = $this->db->get();
        return $query->result(); // Mengembalikan semua data kuliner
    }

    public function get_categories() {
        $this->db->select('*');
        $this->db->from('categories'); // Pastikan tabelnya bernama 'categories'
        $query = $this->db->get();
        return $query->result(); // Mengembalikan semua data kategori
    }

    public function get_culinaries_grouped_by_category() {
        $this->db->select('c.name as category_name, cul.*');
        $this->db->from('culinaries cul');
        $this->db->join('categories c', 'cul.category_id = c.id', 'left');
        $this->db->order_by('c.name', 'ASC'); // Mengurutkan berdasarkan nama kategori
        $query = $this->db->get();
    
        $result = $query->result();
    
        // Kelompokkan data berdasarkan kategori
        $grouped_culinaries = [];
        foreach ($result as $row) {
            $grouped_culinaries[$row->category_name][] = $row;
        }
    
        return $grouped_culinaries;
    }    
    

    // Ambil kuliner berdasarkan ID
    public function get_culinary_by_id($id) {
        $this->db->select('*');
        $this->db->from('culinaries');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row(); // Mengembalikan satu data kuliner
    }

    // Menambahkan kuliner baru
    public function insert_culinary($data) {
        return $this->db->insert('culinaries', $data);
    }


    // Fungsi untuk melakukan update data kuliner
    public function update_culinary($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('culinaries', $data);  // Mengembalikan true jika berhasil
    }
    

    // Menghapus kuliner
    public function delete_culinary($id) {
        $this->db->where('id', $id);
        return $this->db->delete('culinaries');
    }

    // Fungsi untuk menghitung total kuliner yang disetujui (approved)
public function count_approved_culinaries() {
    $this->db->where('status', 'approved');
    $query = $this->db->get('culinaries');
    return $query->num_rows();  // Mengembalikan jumlah kuliner yang disetujui
}

public function get_kuliner($limit, $start) {
    $this->db->limit($limit, $start);
    $query = $this->db->get('kuliner');
    return $query->result();
}

public function get_total_kuliner_count() {
    return $this->db->count_all('kuliner');
}

public function get_approved_count() {
    $this->db->where('status', 'approved');
    $query = $this->db->get('culinaries'); // Replace with your actual table name
    return $query->num_rows();  // Returns the count of rows
}

}
