<?php
class Kuliner_model extends CI_Model {

    // Ambil semua data kuliner
    public function get_all_kuliner() {
        $query = $this->db->get('kuliner'); // Mengambil data dari tabel 'kuliner'
        return $query->result(); // Mengembalikan hasil sebagai array objek
    }

    // Ambil data kuliner berdasarkan ID
    public function get_kuliner_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('kuliner'); // Mengambil data dari tabel 'kuliner'
        return $query->row(); // Mengembalikan hasil sebagai satu objek
    }

    // Menambahkan kuliner baru
    public function insert_kuliner($data) {
        return $this->db->insert('kuliner', $data); // Menyimpan data ke tabel 'kuliner'
    }

    // Memperbarui data kuliner
    public function update_kuliner($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('kuliner', $data); // Memperbarui data kuliner berdasarkan ID
    }

    // Menghapus data kuliner berdasarkan ID
    public function delete_kuliner($id) {
        $this->db->where('id', $id);
        return $this->db->delete('kuliner'); // Menghapus kuliner berdasarkan ID
    }
}
?>
