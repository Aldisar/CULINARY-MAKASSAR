<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Load database
    }

    // Fungsi untuk menghitung semua pengguna
    public function count_all_users() {
        return $this->db->count_all('users'); // Menghitung total pengguna dalam tabel 'users'
    }

    // Fungsi untuk mengambil data pengguna berdasarkan ID
    public function get_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('users'); // Mengambil data dari tabel 'users' berdasarkan ID
        return $query->row(); // Mengembalikan satu baris data
    }

    // Fungsi untuk menyimpan data pengguna
    public function insert_user($data) {
        // Menggunakan Active Record untuk menyimpan data
        if ($this->db->insert('users', $data)) {
            return $this->db->insert_id(); // Mengembalikan ID user yang baru saja dibuat jika berhasil
        } else {
            return false; // Mengembalikan false jika gagal
        }
    }

    // Fungsi untuk mendapatkan semua data pengguna
    public function get_all_users() {
        $query = $this->db->get('users'); // Mengambil data dari tabel 'users'
        return $query->result(); // Mengembalikan hasilnya dalam bentuk array objek
    }

    // Fungsi untuk mendapatkan pengguna berdasarkan email
    public function get_by_email($email) {
        $this->db->where('email', $email);
        $query = $this->db->get('users'); // Mengambil data dari tabel 'users' berdasarkan email

        if ($query->num_rows() > 0) {
            return $query->row(); // Mengembalikan data pengguna jika ditemukan
        } else {
            return null; // Mengembalikan null jika tidak ada data pengguna dengan email tersebut
        }
    }

    // Fungsi untuk mendapatkan log aktivitas terbaru
    public function get_recent_logs($limit = 10) {
        $this->db->order_by('created_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get('user_activity_logs');
        return $query->result();
    }

    public function get_user_by_id($id) {
        return $this->db->get_where('users', ['id' => $id])->row();
    }
    
    public function update_user($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('users', $data);
    }
    

    // Fungsi untuk menyimpan log aktivitas
    public function insert_activity_log($data) {
        if ($this->db->insert('user_activity_logs', $data)) {
            if ($this->db->affected_rows() > 0) {
                log_message('info', 'User activity log successfully inserted into the user_activity_logs table.');
            } else {
                log_message('error', 'Insert was executed but no rows were affected in the user_activity_logs table.');
            }
        } else {
            log_message('error', 'Failed to insert user activity log into the user_activity_logs table.');
        }
    }

    // Fungsi untuk mengupdate data pengguna berdasarkan ID
    public function update($id, $data) {
        $this->db->where('id', $id);
        if ($this->db->update('users', $data)) {
            if ($this->db->affected_rows() > 0) {
                log_message('info', "User data with ID $id successfully updated.");
                return true;
            } else {
                log_message('error', "Update was executed but no rows were affected for user ID $id.");
                return false;
            }
        } else {
            log_message('error', "Failed to update user data with ID $id.");
            return false;
        }
    }

    // Fungsi untuk menghapus data pengguna berdasarkan ID
    public function delete($id) {
        $this->db->where('id', $id);
        if ($this->db->delete('users')) {
            if ($this->db->affected_rows() > 0) {
                log_message('info', "User data with ID $id successfully deleted.");
                return true;
            } else {
                log_message('error', "Delete was executed but no rows were affected for user ID $id.");
                return false;
            }
        } else {
            log_message('error', "Failed to delete user data with ID $id.");
            return false;
        }
    }

    public function get_user_by_email($email) {
        return $this->db->get_where('users', ['email' => $email])->row();
    }

    public function update_password($email, $password) {
        $this->db->where('email', $email);
        $this->db->update('users', [
            'password' => password_hash($password, PASSWORD_BCRYPT)
        ]);
        return $this->db->affected_rows() > 0;
    }
    
}
