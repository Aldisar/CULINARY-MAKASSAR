<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Message_model extends CI_Model {

    // Konstruktor untuk inisialisasi model
    public function __construct()
    {
        parent::__construct();
        $this->load->database();  // Memuat database
        $this->load->library('email');  // Memuat library email untuk mengirim balasan
    }

    // Method untuk mengambil pesan berdasarkan ID
    public function get_message_by_id($message_id)
    {
        // Mengambil pesan berdasarkan ID
        $this->db->where('id', $message_id);
        $query = $this->db->get('messages');
        return $query->row();  // Mengembalikan satu baris data pesan (objek)
    }

    // Method untuk membalas pesan (mengirim email balasan)
    public function reply_message($message_id, $reply_message)
    {
        // Ambil pesan asli berdasarkan ID
        $message = $this->get_message_by_id($message_id);
        
        if (!$message) {
            return false;  // Jika pesan tidak ditemukan
        }

        // Menyusun email balasan
        $subject = "Balasan Pesan Anda - CA'MA Admin";
        $message_body = "Hi " . $message->name . ",\n\n";
        $message_body .= "Terima kasih telah menghubungi kami. Berikut adalah balasan dari kami:\n\n";
        $message_body .= $reply_message . "\n\n";
        $message_body .= "Hormat kami,\nTim CA'MA";

        // Konfigurasi pengiriman email
        $this->email->from('admin@yourdomain.com', 'CA\'MA Admin');  // Ganti dengan email admin Anda
        $this->email->to($message->email);  // Email penerima balasan
        $this->email->subject($subject);
        $this->email->message($message_body);

        // Kirim email
        if ($this->email->send()) {
            return true;  // Email berhasil dikirim
        } else {
            return false;  // Gagal mengirim email
        }
    }

}

