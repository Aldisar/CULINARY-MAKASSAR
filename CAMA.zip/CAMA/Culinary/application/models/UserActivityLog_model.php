<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserActivityLog_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Fungsi untuk mendapatkan log aktivitas terbaru
    public function get_recent_logs($limit = 10) {
        $this->db->order_by('created_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get('user_activity_logs');
        return $query->result();
    }

    // Fungsi untuk menambahkan log aktivitas
    public function add_log($user_id, $activity) {
        $data = array(
            'user_id' => $user_id,
            'activity' => $activity,
            'created_at' => date('Y-m-d H:i:s')
        );
        return $this->db->insert('user_activity_logs', $data);
    }
}
