<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model {

    public function count_all() {
        return $this->db->count_all('categories'); // Gantilah 'categories' dengan nama tabel yang sesuai
    }

    public function __construct() {
        parent::__construct();
    }

    // Fungsi untuk mengambil semua kategori
    public function get_all() {
        $query = $this->db->get('categories');
        return $query->result();
    }

    // Fungsi untuk menambah kategori baru
    public function insert($data) {
        $this->db->insert('categories', $data);
    }

    // Fungsi untuk memperbarui kategori berdasarkan ID
    public function update($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('categories', $data);
    }

    // Fungsi untuk menghapus kategori berdasarkan ID
    public function delete($id) {
        $this->db->where('id', $id);
        $this->db->delete('categories');
    }

    // Fungsi untuk mendapatkan kategori berdasarkan ID
    public function get_by_id($id) {
        return $this->db->get_where('categories', array('id' => $id))->row();
    }
    public function get_all_categories() {
        $query = $this->db->get('categories');
        return $query->result(); // Mengembalikan semua data kategori
    }
}
