<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PageView_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Fungsi untuk mendapatkan jumlah view halaman
    public function get_view_count($page_name) {
        $this->db->select('view_count');
        $this->db->from('page_views');
        $this->db->where('page_name', $page_name);
        $query = $this->db->get();
    
        // Debugging untuk melihat apakah query mengembalikan data
        log_message('debug', 'Query result: ' . print_r($query->row(), true));
    
        // Pastikan query mengembalikan hasil
        if ($query->num_rows() > 0) {
            return $query->row()->view_count;
        } else {
            return 0;  // Kembalikan 0 jika tidak ada hasil
        }
    }
    

    // Fungsi untuk menambah jumlah view
    public function increment_view_count($page_name) {
        // Cek apakah halaman sudah ada di tabel
        $this->db->where('page_name', $page_name);
        $query = $this->db->get('page_views');

        if ($query->num_rows() > 0) {
            // Jika sudah ada, update jumlah view
            $this->db->set('view_count', 'view_count+1', FALSE);
            $this->db->where('page_name', $page_name);
            $this->db->update('page_views');
        } else {
            // Jika belum ada, buat entri baru dengan view_count 1
            $data = array(
                'page_name' => $page_name,
                'view_count' => 1
            );
            $this->db->insert('page_views', $data);
        }
    }
}
