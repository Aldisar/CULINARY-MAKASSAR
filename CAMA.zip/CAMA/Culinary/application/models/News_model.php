<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Mengambil semua berita
    public function get_all_news() {
        $query = $this->db->get('news');
        return $query->result();
    }

    // Mengambil berita berdasarkan ID
    public function get_news_by_id($id) {
        $query = $this->db->get_where('news', array('id' => $id));
        return $query->row();
    }

    // Menambahkan berita baru
    public function add_news($data) {
        return $this->db->insert('news', $data);
    }

    // Mengupdate berita
    public function update_news($id, $data) {
        return $this->db->update('news', $data, array('id' => $id));
    }

    // Menghapus berita
    public function delete_news($id) {
        return $this->db->delete('news', array('id' => $id));
    }
}
?>
