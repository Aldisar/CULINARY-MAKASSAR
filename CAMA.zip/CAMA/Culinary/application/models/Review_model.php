<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Review_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
    }

    // Fungsi untuk mendapatkan review berdasarkan culinary_id
    public function get_reviews_by_culinary_id($culinary_id) {
        // Mengambil review berdasarkan culinary_id dari tabel reviews
        $this->db->where('culinary_id', $culinary_id);
        $query = $this->db->get('reviews');
        return $query->result();
    }

    // Method untuk menambahkan review baru ke dalam tabel reviews
    public function insert($data) {
        // Menggunakan kolom 'comment' yang sesuai dengan struktur tabel
        return $this->db->insert('reviews', $data);
    }
    public function check_user_reviewed($culinary_id, $user_id) {
        $this->db->where('culinary_id', $culinary_id);
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('reviews');
        return $query->num_rows() > 0;  // Jika sudah ada review, kembalikan true
    }

    public function get_reviews_with_culinary($limit = NULL, $offset = NULL) {
        $this->db->select('reviews.*, culinaries.name as culinary_name, culinaries.photo as culinary_photo, users.username'); // Add users.username here
        $this->db->from('reviews');
        $this->db->join('culinaries', 'reviews.culinary_id = culinaries.id', 'left');
        $this->db->join('users', 'reviews.user_id = users.id', 'left'); // Join users table to get username
        $this->db->order_by('reviews.created_at', 'DESC');
        
        if ($limit) {
            $this->db->limit($limit, $offset);
        }
    
        $query = $this->db->get();
        return $query->result();
    }
    
    

    // Menghapus ulasan berdasarkan ID
    public function delete_review($id) {
        $this->db->where('id', $id);
        $this->db->delete('reviews');
    }
    
    
}
