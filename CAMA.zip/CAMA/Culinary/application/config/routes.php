<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'culinary';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['admin/login'] = 'admin/login';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/logout'] = 'admin/logout';
$route['admin/kategori'] = 'admin/kategori';
$route['admin/tambah_kategori'] = 'admin/tambah_kategori';
$route['admin/kuliner'] = 'admin/kuliner';
$route['admin/pengguna'] = 'admin/pengguna';
$route['admin/verifikasi'] = 'admin/verifikasi';
$route['culinary/login'] = 'culinary/login';
$route['culinary/details'] = 'culinary/details_by_category';
$route['profile'] = 'profile/index';
$route['profile/edit'] = 'profile/edit';
$route['profile/update'] = 'profile/update';
$route['admin/approve/(:num)'] = 'admin/approve/$1';
$route['admin/reject/(:num)'] = 'admin/reject/$1';
$route['admin/login'] = 'admin/login';
$route['admin/edit_kategori/(:num)'] = 'admin/edit_kategori/$1';
$route['admin/delete_kategori/(:num)'] = 'admin/delete_kategori/$1';
$route['culinary/detail/(:num)'] = 'culinary/detail/$1';
$route['culinary/add_review/(:num)'] = 'culinary/add_review/$1';
$route['culinary/detail/(:num)'] = 'culinary/detail/$1';
$route['culinary/register'] = 'culinary/register';
$route['contact'] = 'contact/index';
$route['contact/submit_message'] = 'contact/submit_message';
$route['admin/delete_pengguna/(:num)'] = 'admin/delete_pengguna/$1';
$route['culinary/search'] = 'culinary/search';
$route['search'] = 'culinary/search'; 
$route['admin/update_kuliner'] = 'admin/update_kuliner';
$route['admin/simpan_kuliner'] = 'admin/simpan_kuliner';
$route['admin/news'] = 'news/index';         
$route['admin/news/add'] = 'news/add';          
$route['admin/news/edit/(:num)'] = 'news/edit/$1'; 
$route['admin/news/delete/(:num)'] = 'news/delete/$1'; 
$route['news/add'] = 'news/add';  
$route['news/edit'] = 'news/edit'; 
$route['admin/reviews'] = 'admin/reviews'; 
$route['admin/review_list'] = 'admin/review_list';
$route['admin/delete_review/(:num)'] = 'admin/delete_review/$1';
$route['reset-password'] = 'culinary/reset_password';
$route['reset-password-action'] = 'culinary/reset_password_action';
